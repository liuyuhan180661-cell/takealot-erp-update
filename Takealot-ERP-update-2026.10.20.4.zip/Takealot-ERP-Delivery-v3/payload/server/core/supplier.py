#!/usr/bin/env python3
"""1688 货源配对核心（CONTRACT v5）。

设计约束（**不要违反**）
--------------------------------------------------------------------------------
1. **模型渠道不在代码里**。只从 `state/supplier.json` 读，三种模式：
     "openai" → POST `{base_url}/chat/completions`（任何 OpenAI 兼容端点；
                测试期指向本机代理就是免费通道，**这是配置、不是代码**）
     "hermes" → 调用本机 `hermes chat -q … --oneshot`（用客户自己配置的模型套餐）
     ""       → **不判定**：只取候选并标 `needs_review`
   → 客户机上没有任何免费通道也**照常可用**：取到候选入库、等模型或人工来判。
2. **1688 那条调用是唯一稀缺资源**（15~25s + 风控）。所以：
   - 候选取到就**落库缓存**，换规则/换模型**只重判不重搜**；
   - 搜索限速写进代码：间隔 ≥`min_gap_s`、单会话 ≤`max_per_session`，跨重启用状态文件计数。
3. 本模块**不被 plugin_api 导入**（避免循环）；它按需 `import plugin_api` 复用其状态读写。
"""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.parse
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36")
APPKEY = "12574478"
MTOP_API = "mtop.1688.pc.plugin.imageSearch.plugin.search"
UPLOAD_URL = "https://search.1688.com/service/uploadErpImgSearch"
DETAIL_URL = "https://detail.1688.com/offer/{0}.html"

CONFIG_FILE = "supplier.json"
RUN_STATE_FILE = "supplier_match_state.json"

DEFAULT_CONFIG: Dict[str, Any] = {
    # 判定规则版本 —— 结果里会写死这个值，升级规则时可据此筛出旧结果重判。
    # v2 = 经 N=386 实测的严格规则（precision 84.4%）：规格/件数差异**不**否决，
    #      但品牌 / 结构 / 品类 / 材质档位不同 = 不同款。
    "rule": "v2",
    "model": {
        "mode": "",              # "openai" | "hermes" | ""（不判定）
        "base_url": "",          # 例: https://api.deepseek.com 或 http://127.0.0.1:8645/v1
        "model": "",             # 例: deepseek-flash / stepfun/step-5-preview:free
        # 备用模型链：主模型抖动/限流时**立刻切下一个**（"打热就切"），切换记进
        # state/supplier_switch.jsonl。客户机上换成客户自己的套餐即可，与代码无关。
        "fallback_models": [],
        "key_env": "",           # 从环境变量取 key（推荐）
        "api_key": "",           # 直填 key（不推荐，优先 key_env）
        "timeout_s": 180,
        "temperature": 0,
    },
    "search": {
        "enabled": True,
        "pages": 3,              # 每页 20 条
        "min_gap_s": 20,         # 两次搜索的最小真实间隔（实测安全线 16.5s，留余量）
        "max_per_session": 25,   # 单会话上限（实测 22 次连发 0 拦截）
        "timeout_s": 45,
        "jar": "/tmp/erp-1688-imgsearch.jar",
        "candidates_keep": 15,   # 送去判定的候选条数（按 1688 相似度降序取前 N）
        "max_wait_s": 120,       # 批量任务为等限速窗口最多睡多久（防配置写错后无限等）
    },
    "batch": {"max_items": 25},
}

# ---------------------------------------------------------------- 状态与配置


def _api() -> Any:
    """拿到已加载的 plugin_api 模块。

    **不能写 ``import plugin_api``**：部署形态下核心文件在 ``server/core/``，那个目录不一定在
    sys.path 上（实测装出来的服务上会 ModuleNotFoundError）。所以：
    ① 先按名字找已加载的那份；② 再按“谁有 STATE_DIR + supplier_pair_put”找；③ 最后按路径加载。
    """
    mod = sys.modules.get("plugin_api")
    if mod is not None and hasattr(mod, "STATE_DIR"):
        return mod
    for cand in list(sys.modules.values()):
        if cand is not None and hasattr(cand, "STATE_DIR") and hasattr(cand, "supplier_pair_put"):
            return cand
    import importlib.util
    path = Path(__file__).resolve().parent / "plugin_api.py"
    spec = importlib.util.spec_from_file_location("plugin_api", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("拿不到 plugin_api 模块（找不到 %s）" % path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules.setdefault("plugin_api", mod)
    spec.loader.exec_module(mod)
    return mod


def state_dir() -> Path:
    try:
        return Path(_api().STATE_DIR)
    except Exception:
        return Path(os.path.expanduser("~/.takealot-erp/state"))


def _json_read(path: Path, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def _json_write(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def _num(mapping: Dict[str, Any], key: str, default: Any) -> Any:
    """取数值配置：**显式 0 必须生效**。

    坑：`cfg.get(k) or default` 会让「配 0 想关掉」静默回落默认值
    （实测：min_gap_s=0 想关闭限速，结果仍按 20s 拦）。这里只用 None 判缺失。
    """
    v = (mapping or {}).get(key)
    if v is None or v == "":
        return default
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _int(mapping: Dict[str, Any], key: str, default: int) -> int:
    return int(_num(mapping, key, default))


def _deep_merge(base: Dict[str, Any], over: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def config() -> Dict[str, Any]:
    """配置 = 默认值 ⊕ state/supplier.json（客户可只写差异部分）。"""
    raw = _json_read(state_dir() / CONFIG_FILE, {})
    return _deep_merge(DEFAULT_CONFIG, raw if isinstance(raw, dict) else {})


def run_state() -> Dict[str, Any]:
    st = _json_read(state_dir() / RUN_STATE_FILE, {})
    return st if isinstance(st, dict) else {}


def _save_run_state(st: Dict[str, Any]) -> None:
    _json_write(state_dir() / RUN_STATE_FILE, st)


# ---------------------------------------------------------------- 1688 图搜


def _curl(args: List[str], timeout: int = 60) -> str:
    # --noproxy: 本机 Clash TUN 会把回环请求也当代理拦掉（实测 502），
    # 所以访问 127.0.0.1/本地端点（如本机模型代理）必须显式绕过。
    cmd = ["curl", "-sS", "--max-time", str(timeout), "-A", UA,
           "--noproxy", "127.0.0.1,localhost"] + args
    p = subprocess.run(cmd, capture_output=True, text=True)
    return p.stdout


PACK_ROW_RE = re.compile(r'"pieceWeightScaleInfo"\s*:\s*\[\s*(\{[^{}]*\})')
PACK_UNIT_RE = re.compile(r'"unitWeight"\s*:\s*([\d.]+)')


CHROME_BINS = ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
               "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
               r"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe")


def pack_profile_dir() -> Path:
    """1688 抓取专用浏览器 profile（人工登录一次，cookie 长期复用）。"""
    return state_dir().parent / "browser-1688"


def fetch_offer_html_browser(offer_id: str, timeout: int = 90) -> str:
    """用本机 Chrome（独立 profile）渲染 1688 详情页，返回 DOM。

    为什么要这条通道：1688 详情页对匿名请求大多返回 4.8KB 登录墙，
    「商品件重尺」(productPackInfo) 只有登录后才渲染。人工在那个 profile 登录一次后，
    这里用 headless 复用 cookie。

    实现要点：`chrome --headless --dump-dom` **dump 完不会自己退出**（实测进程一直挂着），
    所以不能等 subprocess.run 结束 —— 要边写边看输出文件，出现 productPackInfo 或体积稳定就收工。
    """
    chrome = next((b for b in CHROME_BINS if os.path.exists(b)), "")
    if not chrome:
        return ""
    # 没登录过就没有 cookie：直接放弃，不要每条都启一次 headless 白等 90s
    cookie = pack_profile_dir() / "Default" / "Cookies"
    try:
        if not cookie.exists() or cookie.stat().st_size < 1024:
            return ""
    except OSError:
        return ""
    profile = pack_profile_dir()
    try:
        profile.mkdir(parents=True, exist_ok=True)
    except OSError:
        return ""
    lock = profile / "SingletonLock"
    if lock.exists():
        # 锁里是 hostname-pid：进程活着才是真占用，残留锁直接清掉
        try:
            pid = int(os.readlink(str(lock)).rsplit("-", 1)[-1])
            alive = subprocess.run(["ps", "-p", str(pid)], capture_output=True).returncode == 0
            if not alive:
                lock.unlink()
        except (OSError, ValueError):
            try:
                lock.unlink()
            except OSError:
                pass
    if lock.exists():
        return ""

    cmd = [chrome, "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
           "--user-data-dir={0}".format(profile), "--virtual-time-budget=15000",
           "--window-size=1440,900", "--dump-dom", DETAIL_URL.format(offer_id)]
    tmp_name = str(state_dir() / "supplier_work" / ("pack_{0}.html".format(offer_id)))
    try:
        Path(tmp_name).parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        tmp_name = "/tmp/pack_{0}.html".format(offer_id)
    html = ""
    try:
        with open(tmp_name, "w", encoding="utf-8") as fh:
            proc = subprocess.Popen(cmd, stdout=fh, stderr=subprocess.DEVNULL)
        deadline = time.time() + max(20, timeout)
        last_size = 0
        stable = 0
        while time.time() < deadline:
            time.sleep(2)
            try:
                size = os.path.getsize(tmp_name)
            except OSError:
                size = 0
            stable = stable + 1 if size == last_size and size > 0 else 0
            last_size = size
            if size > 200000 and stable >= 2:
                break            # 体积稳定两轮 = 渲染完了
            if size > 200000 and proc.poll() is not None:
                break
        try:
            proc.kill()
        except OSError:
            pass
        with open(tmp_name, encoding="utf-8", errors="replace") as fh:
            html = fh.read()
    except OSError:
        return ""
    try:
        os.unlink(tmp_name)
    except OSError:
        pass
    return html


def parse_offer_pack(html: str, offer_id: str) -> Dict[str, Any]:
    """从 1688 详情页 DOM/HTML 里解析「商品件重尺」；取不到返回 {}。"""
    if not html:
        return {}
    out: Dict[str, Any] = {"offerId": str(offer_id), "source": "1688-pack", "weightKg": None,
                           "lengthCm": None, "widthCm": None, "heightCm": None,
                           "volumeCm3": None, "raw": None}

    def _f(value: Any) -> float:
        try:
            return float(value or 0)
        except (TypeError, ValueError):
            return 0.0

    row: Dict[str, Any] = {}
    match = PACK_ROW_RE.search(html)
    if match:
        try:
            row = json.loads(match.group(1))
        except ValueError:
            row = {}
        length, width, height = _f(row.get("length")), _f(row.get("width")), _f(row.get("height"))
        weight_g, volume = _f(row.get("weight")), _f(row.get("volume"))
        # 单位坑：1688 有的卖家填 cm、有的填 mm（实测空气炸锅 520/324/630 其实是 mm）。
        # 判据：任一维 > 200 → 按 mm 处理，换算成 cm / cm³。
        if max(length, width, height) > 200:
            length, width, height = length / 10.0, width / 10.0, height / 10.0
            volume = volume / 1000.0
        # 常识校验：卖家常填错单位/填 0.25 这种明显无效值 —— 不可信就当没有（不猜）
        sane = all(1.0 <= v <= 200.0 for v in (length, width, height))
        if length and width and height and sane:
            out.update(lengthCm=round(length, 2), widthCm=round(width, 2), heightCm=round(height, 2),
                       volumeCm3=round(volume or length * width * height, 1))
        if weight_g and 1 <= weight_g <= 100000:      # 1g~100kg 之外视为填错
            out["weightKg"] = round(weight_g / 1000.0, 3)
        if row:
            out["raw"] = json.dumps(row, ensure_ascii=False)[:200]
    if out["weightKg"] is None:
        unit = PACK_UNIT_RE.search(html)
        if unit:
            try:
                out["weightKg"] = round(float(unit.group(1)), 3)
            except ValueError:
                pass
    if not (out["weightKg"] or out["lengthCm"]):
        return {}
    return out


PACK_CACHE_FILE = "supplier_pack_cache.json"
PACK_STATE_FILE = "supplier_pack_state.json"
LOGIN_URL = "https://login.1688.com/member/signin.htm"
#: 登录失效时自动弹窗的冷却时间：1688 会话本来就短（真人也会频繁失效），
#: 但绝不因为一次失败就反复弹窗骚扰客户。
LOGIN_POPUP_COOLDOWN_S = 6 * 3600


def pack_state() -> Dict[str, Any]:
    try:
        data = json.loads((state_dir() / PACK_STATE_FILE).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_pack_state(**kw: Any) -> None:
    data = pack_state()
    data.update({k: v for k, v in kw.items() if v is not None})
    try:
        path = state_dir() / PACK_STATE_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def looks_like_login_wall(html: str) -> bool:
    """判断拿回来的是不是 1688 登录墙（而不是商品页）。

    判据：正常详情页 2.8MB 且含 productPackInfo；登录墙约 4.8KB，正文出现登录相关字样。
    """
    if not html:
        return False
    if len(html) > 200000:
        return False
    text = html.lower()
    return len(html) < 12000 or "login.1688.com" in text or "passport" in text or "扫码登录" in html or "登录后" in html


def open_login_window(force: bool = False) -> bool:
    """弹出 1688 登录窗口（人工扫码一次）。

    只在**真的需要**时弹：登录墙 + 冷却期外 + 当前没有已开着的登录窗口。
    返回 True = 本次弹出去了。
    """
    profile = pack_profile_dir()
    lock = profile / "SingletonLock"
    if lock.exists():
        try:
            pid = int(os.readlink(str(lock)).rsplit("-", 1)[-1])
            alive = subprocess.run(["ps", "-p", str(pid)], capture_output=True).returncode == 0
        except (OSError, ValueError):
            alive = False
        if alive:
            return False          # 已经有一个窗口开着，别开第二个
    now = time.time()
    last = float(pack_state().get("loginPopupAt") or 0)
    if not force and now - last < LOGIN_POPUP_COOLDOWN_S:
        return False
    chrome = next((b for b in CHROME_BINS if os.path.exists(b)), "")
    if not chrome:
        return False
    try:
        profile.mkdir(parents=True, exist_ok=True)
        subprocess.Popen([chrome, "--user-data-dir={0}".format(profile), "--no-first-run",
                          "--no-default-browser-check", "--new-window", LOGIN_URL],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError:
        return False
    _save_pack_state(loginPopupAt=now, loginRequiredAt=now)
    return True
PACK_TTL_OK_S = 30 * 24 * 3600      # 抓到了：缓存 30 天
PACK_TTL_MISS_S = 7 * 24 * 3600     # 没抓到：7 天内不再试（防重复等 90s）


def _pack_cache() -> Dict[str, Any]:
    try:
        data = json.loads((state_dir() / PACK_CACHE_FILE).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _pack_cache_put(offer_id: str, payload: Dict[str, Any], ttl: Optional[int] = None) -> None:
    try:
        data = _pack_cache()
        data[str(offer_id)] = {"at": time.time(), "pack": payload or {},
                               "ttl": int(ttl) if ttl else None}
        if len(data) > 2000:
            for key in sorted(data, key=lambda k: data[k].get("at") or 0)[:500]:
                data.pop(key, None)
        path = state_dir() / PACK_CACHE_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def fetch_offer_pack(offer_id: str, timeout: int = 25) -> Dict[str, Any]:
    """抓 1688「商品件重尺」：先匿名 curl，失败/被登录墙挡就走本机 Chrome 已登录 profile。

    为什么值得抓：Takealot 的长宽高/重量不是必填，公开页常常没有；但官方履约费
    （DC 费）= 包装体积档 × 重量档，缺输入就算不出到手。1688 货源页的
    productPackInfo 是**卖家自己填的包装尺寸**，正好补这个缺口。取不到返回 {}，不猜。
    """
    offer_id = str(offer_id or "").strip()
    if not offer_id:
        return {}
    cached = _pack_cache().get(offer_id) or {}
    if isinstance(cached, dict) and cached.get("at"):
        age = time.time() - float(cached["at"])
        pack_cached = cached.get("pack") or {}
        if pack_cached and age < PACK_TTL_OK_S:
            return pack_cached
        miss_ttl = float(cached.get("ttl") or PACK_TTL_MISS_S)
        if not pack_cached and age < miss_ttl:
            return {}
    html = _curl(["-L", DETAIL_URL.format(offer_id)], timeout=timeout)
    pack = parse_offer_pack(html, offer_id)
    if pack:
        pack["via"] = "curl"
        _pack_cache_put(offer_id, pack)
        return pack
    # 匿名被挡（实测 4/5 是 4.8KB 登录墙）→ 用已登录的浏览器 profile 渲染一次
    dom = fetch_offer_html_browser(offer_id)
    pack = parse_offer_pack(dom, offer_id)
    if pack:
        pack["via"] = "browser"
        _pack_cache_put(offer_id, pack)
        _save_pack_state(lastOkAt=time.time(), loginRequiredAt=None)
        return pack
    # 拿不到 —— 分辨是「登录失效」还是「页面本来没件重尺」
    if looks_like_login_wall(html) or looks_like_login_wall(dom):
        _save_pack_state(loginRequiredAt=time.time())
        popped = open_login_window()
        # 登录墙期间只缓存 30 分钟：用户扫码后很快就能重试成功
        _pack_cache_put(offer_id, {}, ttl=1800)
        log.warning("takealot-erp: 1688 登录已失效%s，件重尺暂不可用（配对/成本不受影响）",
                    "，已弹出登录窗口" if popped else "（%s 内不再重复弹窗）" % "6h")
        return {}
    _pack_cache_put(offer_id, {})          # 负缓存：7 天内不再试
    return pack


def _read_token(jar: Path) -> Optional[str]:
    if not os.path.exists(jar):
        return None
    for line in open(jar, encoding="utf-8", errors="replace"):
        if "\t_m_h5_tk\t" in line:
            parts = line.strip().split("\t")
            if len(parts) > 6:
                return parts[6]
    return None


def _upload(image_bytes: bytes, jar: Path, timeout: int) -> str:
    b64 = base64.b64encode(image_bytes).decode()
    body = json.dumps({"imgBase64": b64, "searchType": "imageSearch",
                       "appName": "pcErpImage", "urlType": "main"})
    out = _curl(["-X", "POST", "-H", "Content-Type: application/json",
                 "-H", "Origin: https://s.1688.com", "-H", "Referer: https://s.1688.com/",
                 "-c", str(jar), "-b", str(jar), "-d", body, UPLOAD_URL], timeout)
    try:
        j = json.loads(out)
    except ValueError:
        raise RuntimeError("图搜上传返回非 JSON：%s" % out[:160])
    if j.get("code") != 0:
        raise RuntimeError("图搜上传失败：%s" % j.get("errMsg"))
    return j["data"]["imageId"]


def _search_page(image_id: str, page: int, jar: Path, timeout: int, page_size: int = 20) -> Dict[str, Any]:
    params = json.dumps({
        "searchScene": "imageEx", "serviceGroupName": "service.group.pc.image",
        "interfaceName": "imageExtraSearchService",
        "serviceParam.extendParam[subChannel]": "pc_image_plugin",
        "serviceParam.extendParam[imageId]": image_id,
        "serviceParam.extendParam[appName]": "imageExtra",
        "abRequest.level3Biz": "main", "abRequest.level2Biz": "image",
        "abRequest.level1Biz": "search",
        "serviceParam.extendParam[pageSize]": page_size,
        "serviceParam.extendParam[beginPage]": page,
    }, separators=(",", ":"))
    data = json.dumps({"params": params}, separators=(",", ":"))

    def call(sign: Optional[str] = None, t: Optional[str] = None) -> str:
        q = {"jsv": "2.7.4", "appKey": APPKEY, "t": t or str(int(time.time() * 1000)),
             "api": MTOP_API, "v": "1.1", "type": "json", "dataType": "json", "data": data}
        if sign:
            q["sign"] = sign
        url = "https://h5api.m.1688.com/h5/%s/1.1/?%s" % (MTOP_API, urllib.parse.urlencode(q))
        return _curl(["-c", str(jar), "-b", str(jar),
                      "-H", "Referer: https://search.1688.com/", url], timeout)

    tok = _read_token(jar)
    if not tok:
        r = json.loads(call())
        if "TOKEN_EMPTY" in (r.get("ret") or [""])[0]:
            tok = _read_token(jar)
    if not tok:
        raise RuntimeError("1688 未下发 _m_h5_tk（可能被风控）")
    token = tok.split("_")[0]
    t = str(int(time.time() * 1000))
    sign = hashlib.md5(("%s&%s&%s&%s" % (token, t, APPKEY, data)).encode()).hexdigest()
    r = json.loads(call(sign=sign, t=t))
    if "SUCCESS" not in (r.get("ret") or [""])[0]:
        raise RuntimeError("1688 mtop 失败：%s" % r.get("ret"))
    view = ((r.get("data") or {}).get("responseInfo") or {}).get("imageSearchOfferResultViewService")
    v = json.loads(view) if isinstance(view, str) else (view or {})
    d = v.get("data") or {}
    offers = []
    for o in d.get("offerList") or []:
        info = o.get("information") or {}
        tp = (o.get("tradePrice") or {}).get("offerPrice") or {}
        comp = o.get("company") or {}
        tq = o.get("tradeQuantity") or {}
        offers.append({
            "offerId": str(o.get("id") or ""),
            "title": info.get("subject") or info.get("simpleSubject") or "",
            "price": tp.get("valueString") or "",
            "img": (o.get("image") or {}).get("imgUrl") or "",
            "url": info.get("detailUrl") or DETAIL_URL.format(o.get("id")),
            "simScore": info.get("normalizationScore"),
            "company": comp.get("name") or "",
            "city": comp.get("city") or "",
            "isFactory": comp.get("isFactory"),
        })
    return {"total": d.get("totalCount"), "page": page, "offers": offers}


def search_candidates(image_url: str, cfg: Dict[str, Any], workdir: Path) -> Dict[str, Any]:
    """用图片 URL 去 1688 以图搜款 → {imageId, total, offers:[…]}。"""
    sc = cfg["search"]
    tmo = _int(sc, "timeout_s", 45)
    workdir.mkdir(parents=True, exist_ok=True)
    img_path = workdir / ("search-%d.jpg" % int(time.time() * 1000))
    _curl(["-o", str(img_path), image_url], tmo)
    if not img_path.exists() or img_path.stat().st_size < 1000:
        raise RuntimeError("主图下载失败（%s）" % image_url[:80])
    jar = Path(sc.get("jar") or DEFAULT_CONFIG["search"]["jar"])
    if os.path.exists(jar):
        os.remove(jar)                      # 每次新会话都换 jar，避免旧令牌串味
    image_id = _upload(img_path.read_bytes(), jar, tmo)
    offers: List[Dict[str, Any]] = []
    total = None
    for page in range(1, _int(sc, "pages", 3) + 1):
        r = _search_page(image_id, page, jar, tmo)
        total = r["total"]
        offers.extend(r["offers"])
    seen, uniq = set(), []
    for o in offers:
        if not o["offerId"] or o["offerId"] in seen:
            continue
        seen.add(o["offerId"])
        uniq.append(o)
    uniq.sort(key=lambda x: -(x.get("simScore") or 0))
    try:
        img_path.unlink()
    except OSError:
        pass
    return {"imageId": image_id, "total": total, "offers": uniq}


# ---------------------------------------------------------------- 模型判定

JUDGE_RULES = """你是跨境电商采购员。下面是【待采购商品】(境外电商，英文标题) 与 1688【候选货源】
(用我方商品主图以图搜得到，已按 1688 相似度降序，sim 越高越像)。

判定目标：候选**是不是同一个货源链接**（1688 一个链接内部通常有多个 SKU 规格）。

✅ 算同款：结构与用途一致（贴牌、换色、不同包装都算同款）。
   **规格差异不算不同款**：尺寸/容量/件数/色数不同仍算同款 —— 我方 listing 的规格很可能
   只是该链接里的某一个 SKU → confidence 给 low 即可。**候选"没写规格"绝不构成不同款。**
❌ 算不同款：**品牌/型号不同**（我方"得力Deli"vs 候选"蒙玛特"）；**结构/品类冲突**
   （方帐篷 vs 六角凉亭帐篷、两轮车 vs 三轮车、正版 vs 兼容仿品、专用件车型不匹配、
   电压/市场制式不同、材质档位不同如 9K金 vs 合金）。
   图搜常返回**同类目邻居**，这类一律判不同款。"""

JUDGE_OUT = ('只输出 JSON：{"ids":["商品ID",…最多3个;不同款给[]],"confidence":"high|low|none",'
             '"reason":"一句中文依据"}\n不要 markdown、不要解释。'
             '**只允许使用候选里出现过的商品ID，禁止编造。**')


def _judge_prompt(listing: str, candidates: List[Dict[str, Any]]) -> str:
    lines = [JUDGE_RULES, "", "【候选货源】"]
    for c in candidates:
        lines.append("%s | %s | ¥%s | sim=%s" % (
            c.get("offerId"), (c.get("title") or "")[:95], c.get("price") or "-",
            round(c.get("simScore") or 0, 3)))
    lines += ["", "【待采购商品】", listing, "", JUDGE_OUT]
    return "\n".join(lines)


# 「明确否决」措辞：模型在理由里断言这不是同款，却仍返回了候选 ID 时用它做护栏。
# ⚠️ 只能列**明确否定**，别把 `不同款`/`品类冲突` 单独放进来 —— 实测用宽松词扫 37 条
# 会误报 6 条，全是「规格差异不算不同款」「无品牌或品类冲突」这种**含否定词但语义相反**的反向表达。
_REJECT_RE = re.compile(
    r"不能(?:作为|算是|算|视为|当作)同款|不(?:是|属于)同款|并非同款|非同款|无同款货源|不存在同款"
)


def _parse_judgement(text: str) -> Dict[str, Any]:
    import re
    m = re.search(r"\{.*\}", text or "", re.S)
    if not m:
        return {}
    try:
        d = json.loads(m.group(0))
    except ValueError:
        return {}
    ids = d.get("ids")
    return {"ids": [str(x) for x in ids] if isinstance(ids, list) else [],
            "confidence": str(d.get("confidence") or "none"),
            "reason": str(d.get("reason") or "")[:300]}


def _model_chain(mc: Dict[str, Any]) -> List[str]:
    """判定模型链：主模型 + ``fallback_models``（去重、去空）。

    为什么要链：免费/自建通道会抖（实测 `upstream connection failed: Server disconnected`）。
    一次抖动**不能**让整批判定失败 —— 换下一个模型立刻继续（"打热就切"）。
    """
    out: List[str] = []
    for m in [mc.get("model")] + list(mc.get("fallback_models") or []):
        m = str(m or "").strip()
        if m and m not in out:
            out.append(m)
    return out


def _log_model_switch(model: str, exc: Any) -> None:
    """把「打热→切换」记进 state，作为可自证的证据（不静默降级）。"""
    try:
        path = state_dir() / "supplier_switch.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                                 "model": model, "error": str(exc)[:200]},
                                ensure_ascii=False) + "\n")
    except Exception:
        pass


def _judge_openai(prompt: str, mc: Dict[str, Any], model_id: Optional[str] = None) -> str:
    base = str(mc.get("base_url") or "").rstrip("/")
    key = str(mc.get("api_key") or "")
    if not key and mc.get("key_env"):
        key = os.environ.get(str(mc["key_env"]), "")
    body = json.dumps({"model": model_id or mc.get("model"), "temperature": mc.get("temperature", 0),
                       "messages": [{"role": "user", "content": prompt}]})
    out = _curl(["-X", "POST", "-H", "Content-Type: application/json",
                 "-H", "Authorization: Bearer " + key, "-d", body,
                 "%s/chat/completions" % base], _int(mc, "timeout_s", 180))
    try:
        r = json.loads(out)
        return (r["choices"][0]["message"].get("content") or "")
    except (ValueError, KeyError, IndexError):
        err = ""
        try:
            err = str((json.loads(out).get("error") or {}).get("message") or "")[:120]
        except Exception:
            err = out[:120]
        raise RuntimeError("模型返回异常：%s" % (err or "空响应"))


def _hermes_bin() -> str:
    """找到 hermes CLI 的真实路径。

    服务端由桌面入口 / launchd 拉起时 PATH 很短（常常没有 ~/.local/bin），
    直接 `subprocess.run(["hermes", ...])` 会 FileNotFoundError ——
    历史上这就表现为「配对全部待复核 · 模型链全部失败」，看着像模型问题，其实是找不到命令。
    """
    for cand in (os.environ.get("HERMES_BIN"),
                 shutil.which("hermes") if hasattr(shutil, "which") else None,
                 str(Path.home() / ".local/bin/hermes"),
                 "/usr/local/bin/hermes",
                 "/opt/homebrew/bin/hermes"):
        if cand and Path(cand).is_file() and os.access(cand, os.X_OK):
            return cand
    return "hermes"


def _judge_hermes(prompt: str, mc: Dict[str, Any], model_id: Optional[str] = None) -> str:
    """走本机 hermes CLI —— 用客户自己配置的模型套餐（渠道由客户运维决定）。"""
    cmd = [_hermes_bin(), "chat", "-q", prompt, "--oneshot", "--quiet"]
    mid = str(model_id or mc.get("model") or "")
    if mid:
        cmd += ["-m", mid]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=_int(mc, "timeout_s", 300))
    except FileNotFoundError:
        raise RuntimeError("找不到 hermes CLI（PATH 里没有，也找不到 ~/.local/bin/hermes）")
    if p.returncode != 0 and not (p.stdout or "").strip():
        raise RuntimeError("hermes CLI 退出码 {0}：{1}".format(p.returncode, (p.stderr or "").strip()[:160]))
    return p.stdout or ""


def judge(listing: str, candidates: List[Dict[str, Any]], cfg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """返回 {ids, confidence, reason}；未配置模型时返回 None（→ needs_review）。

    模型链逐级降级：主模型抖动/限流 → 换 ``fallback_models`` 里的下一个（"打热就切"），
    切换会记进 ``state/supplier_switch.jsonl``。全链都失败才抛异常（由调用方兜成 needs_review，
    **候选已缓存，下次只重判不重搜**）。
    """
    if not candidates:
        return {"ids": [], "confidence": "none", "reason": "1688 无候选"}
    mc = cfg.get("model") or {}
    mode = str(mc.get("mode") or "").strip().lower()
    if mode not in ("openai", "hermes"):
        return None
    prompt = _judge_prompt(listing, candidates)
    chain = _model_chain(mc) or [""]
    last: Optional[Exception] = None
    for idx, mid in enumerate(chain):
        try:
            text = (_judge_openai(prompt, mc, mid) if mode == "openai"
                    else _judge_hermes(prompt, mc, mid))
            return _parse_judgement(text)
        except Exception as exc:
            last = exc
            if idx < len(chain) - 1:
                _log_model_switch(mid or "(默认)", exc)     # 留证：切换过
            continue
    raise RuntimeError("模型链全部失败（%d 个）：%s" % (len(chain), str(last)[:160]))


# ---------------------------------------------------------------- 单条配对


def _rate_gate(cfg: Dict[str, Any], st: Dict[str, Any]) -> tuple:
    """搜索限速。返回 ``(reason, wait_s)``：

    - ``reason is None`` → 可以立刻搜；
    - ``wait_s > 0`` → **等这么多秒就能继续**（批量任务应当 sleep 后重试同一条，
      而不是把它标成 pending 跳过 —— 否则 ``--limit 20`` 一次只会配 1 条，
      实测踩过：任务 25 秒退出、19 条全标「限速中」）；
    - ``wait_s == 0`` 且 ``reason`` 非空 → 本会话到此为止（配额用尽，等下一轮）。
    """
    sc = cfg["search"]
    now = time.time()
    gap = _num(sc, "min_gap_s", 20)
    last = _num(st, "lastSearchAt", 0)
    if last and now - last < gap:
        return ("距上次 1688 搜索仅 %.0fs（<%.0fs）" % (now - last, gap), gap - (now - last))
    cap = _int(sc, "max_per_session", 25)
    if int(st.get("sessionCount") or 0) >= cap:
        return ("本会话已搜 %d 次（上限 %d）" % (int(st["sessionCount"]), cap), 0)
    return (None, 0)


def match_one(plid: str, listing: str, image_url: str, cfg: Dict[str, Any],
              workdir: Path) -> Dict[str, Any]:
    """给一条 listing 配对。返回写进配对表的记录。"""
    api = _api()
    sc = cfg["search"]
    old = api.supplier_pair_get(plid)
    # 人工指定优先：worker 绝不改写界面上手工填的货源。
    if isinstance(old, dict) and old.get("manual"):
        return old
    rec: Dict[str, Any] = {"rule": cfg.get("rule") or "v2", "status": "matching"}
    candidates = old.get("candidates") if isinstance(old.get("candidates"), list) else []
    _t_search = time.time()          # 分段计时：图搜
    _t_judge = _t_search             # 分段计时：模型判定

    # ① 取候选（有缓存就不重搜 —— 换规则/换模型只重判不重搜）
    if not candidates:
        if not sc.get("enabled", True):
            rec.update({"status": "needs_review", "reason": "1688 搜索已被配置关闭"})
            return api.supplier_pair_put(plid, rec)
        st = run_state()
        blocked, wait_s = _rate_gate(cfg, st)
        if blocked:
            rec.update({"status": "pending", "reason": "限速中：" + blocked, "waitS": round(wait_s, 1)})
            return api.supplier_pair_put(plid, rec)
        try:
            got = search_candidates(image_url, cfg, workdir)
        except Exception as exc:
            st["lastSearchAt"] = time.time()
            st["sessionCount"] = int(st.get("sessionCount") or 0) + 1
            st["lastError"] = "%s: %s" % (type(exc).__name__, str(exc)[:200])
            _save_run_state(st)
            rec.update({"status": "pending", "reason": "图搜失败：" + str(exc)[:160]})
            return api.supplier_pair_put(plid, rec)
        st["lastSearchAt"] = time.time()
        st["sessionCount"] = int(st.get("sessionCount") or 0) + 1
        st["lastOkAt"] = st["lastSearchAt"]
        st["lastError"] = ""
        _save_run_state(st)
        candidates = got["offers"]
        rec["candidates"] = candidates
        rec["candidatesFetchedAt"] = api._iso_now()
        rec["candidateTotal"] = got.get("total")
        rec["tSearchMs"] = int((time.time() - _t_search) * 1000)   # 图搜真实耗时（含网络）

    # ② 判定
    keep = _int(sc, "candidates_keep", 15)
    _t_judge = time.time()
    try:
        verdict = judge(listing, candidates[:keep], cfg)
    except Exception as exc:
        # 模型抖动/全链失败**不能**杀死这一批：候选已缓存，标 needs_review 下次只重判不重搜。
        rec.update({"status": "needs_review",
                    "reason": "判定模型失败（候选已缓存，下次只重判不重搜）：" + str(exc)[:150]})
        return api.supplier_pair_put(plid, rec)
    if verdict is None:
        rec["tJudgeMs"] = int((time.time() - _t_judge) * 1000)
        rec.update({"status": "needs_review",
                    "reason": "未配置判定模型（state/supplier.json → model.mode）"})
        return api.supplier_pair_put(plid, rec)
    rec["tJudgeMs"] = int((time.time() - _t_judge) * 1000)   # 模型判定真实耗时
    ids = [i for i in verdict["ids"] if any(str(c["offerId"]) == i for c in candidates)]
    if verdict["ids"] and not ids:
        rec.update({"status": "no_match", "reason": "模型给出的候选ID不在候选集内（已丢弃）"})
        return api.supplier_pair_put(plid, rec)
    if not ids:
        rec.update({"status": "no_match", "confidence": "none",
                    "reason": verdict.get("reason") or "无同款", "matchedAt": api._iso_now()})
        return api.supplier_pair_put(plid, rec)
    # ③ 自相矛盾护栏：模型**给了候选 ID，理由却明说"不是同款"** → 两个信号互相否定，谁都不采信。
    # 实测踩过（采集箱 1/37）：工具包这条 status=matched，理由却是「存在品类冲突，不能作为同款」。
    # 为什么必须护栏：假"已配对"是**危险方向** —— 会让人照着错链接去采购。
    if _REJECT_RE.search(str(verdict.get("reason") or "")):
        rec.update({"status": "needs_review", "contradiction": True,
                    "reason": "模型自相矛盾（给了链接但理由说不是同款），待人工确认："
                              + str(verdict.get("reason"))[:120],
                    "matchedAt": api._iso_now()})
        return api.supplier_pair_put(plid, rec)
    pick = next(c for c in candidates if str(c["offerId"]) == ids[0])
    rec.update({
        "status": "matched", "offerId": str(pick["offerId"]), "url": pick.get("url") or DETAIL_URL.format(pick["offerId"]),
        "title": pick.get("title") or "", "price": pick.get("price") or "",
        "imageUrl": pick.get("img") or "", "sim": pick.get("simScore"),
        "confidence": verdict.get("confidence") or "low",
        "reason": verdict.get("reason") or "", "matchedAt": api._iso_now(),
        "altIds": ids[1:3],
    })
    # 1688 货源的「件重尺」：Takealot 侧长宽高/重量不是必填，抓不到就用 1688 的包装信息补，
    # 补上之后履约费（DC 费）才算得出来。取不到就跳过，不影响配对结果。
    try:
        pack = fetch_offer_pack(rec.get("offerId") or "")
    except Exception:
        pack = {}
    if pack:
        rec["pack"] = pack
    saved = api.supplier_pair_put(plid, rec)
    # 配对成功 → 立刻把 1688 ¥ 价回填进采集箱行的核算（否则配了也不进成本，
    # 界面上「采购成本」永远是空的、到手算不出）。人工填过的成本不覆盖。
    try:
        api.collection_sync_supplier_cost(plid, rec.get("price"), offer_id=rec.get("offerId") or "",
                                          url=rec.get("url") or "", source_title=rec.get("title") or "")
        if pack:
            api.collection_sync_supplier_pack(plid, pack)
    except Exception as exc:      # 回填失败不能把配对结果弄丢
        api.supplier_pair_put(plid, dict(saved, costSyncError=str(exc)[:120]))
    return saved


def _pick_image(row: Dict[str, Any]) -> str:
    """优先用采集时存下的最大主图 —— 实测 280×280 缩略图会拖累图搜质量。"""
    images = row.get("images")
    if isinstance(images, list):
        fallback = ""
        for u in images:
            if not (isinstance(u, str) and u.startswith("http")):
                continue
            if "280x280" not in u:          # 非缩略图优先命中
                return u
            fallback = fallback or u
        if fallback:
            return fallback
    return str(row.get("imageUrl") or "")


def run(limit: Optional[int] = None, dry: bool = False,
        plids: Optional[List[str]] = None) -> Dict[str, Any]:
    """跑一轮配对：从采集箱取待配对行 → 逐条配对（受 1688 限速）。

    ``plids``：只做这几行（界面上「单点配对 / 单条链接配对」走这里）。
    指定行时**不看队列**——已配对的行也允许重跑（有候选缓存 → 只重判不重搜，不碰 1688）。
    人工指定的行仍受保护（``match_one`` 里不会改写）。
    """
    api = _api()
    cfg = config()
    st = run_state()
    # 「单会话 ≤25 次」= **一次运行**的预算，不是累计。
    # 缺陷记录：以前 sessionCount 从不重置 → 累计搜满 25 次后 worker 永久停摆（产品级隐患）。
    st["sessionStartedAt"] = api._iso_now()
    st["sessionCount"] = 0
    _save_run_state(st)

    queue = api.supplier_queue()["plids"]
    if plids:
        wanted = [api._plid_of(str(p)) for p in plids]
        todo = [p for p in wanted if p]
    else:
        if limit is None:
            limit = _int(cfg.get("batch") or {}, "max_items", 25)
        todo = queue[:max(0, int(limit))]
    workdir = state_dir() / "supplier_work"

    items_by_plid = {}
    for item in api._collection():
        # 行 → 键的映射必须和队列/配对表同一套（PLID 优先），否则队列里的 PLID
        # 在 items_by_plid 里查不到，会被误判成「该行不在采集箱里」。
        pid = api._row_plid(item)
        if pid and pid not in items_by_plid:
            items_by_plid[pid] = item
        for alias in api._row_pair_keys(item):
            items_by_plid.setdefault(alias, item)

    done: List[Dict[str, Any]] = []
    stopped_at = ""
    for plid in todo:
        item = items_by_plid.get(plid) or {}
        if not item:
            # 指定行（界面上单点配对）时可能出现：该 PLID 已经不在采集箱里了。
            # 照实说清楚 —— 别含糊成「无主图」，那会让人往图片问题上找。
            api.supplier_pair_put(plid, {"status": "needs_review", "rule": cfg.get("rule"),
                                         "reason": "该行不在采集箱里（可能已被删除或换了店铺作用域）"})
            done.append({"plid": plid, "status": "needs_review", "reason": "不在采集箱"})
            continue
        row = api._collection_row(item)
        listing = str(item.get("title") or row.get("title") or "")
        image_url = _pick_image(row or item)
        if dry:
            done.append({"plid": plid, "status": "dry", "image": bool(image_url), "listing": listing[:60]})
            continue
        if not image_url:
            api.supplier_pair_put(plid, {"status": "needs_review", "rule": cfg.get("rule"),
                                         "reason": "该行没有可用的主图"})
            done.append({"plid": plid, "status": "needs_review", "reason": "无主图"})
            continue
        # 限速是**排队**、不是"这条跳过"。批量任务里等待是免费的：
        # 等到窗口开再做同一条；会话配额用尽则本轮整体收工（下一轮再来）。
        rec: Dict[str, Any] = {}
        stopped = ""
        for _attempt in range(6):
            try:
                rec = match_one(plid, listing, image_url, cfg, workdir)
            except Exception as exc:
                # 单条的任何异常都不许掀翻整批 —— 批量任务必须能跑完并如实报出坏的那条。
                rec = {"status": "needs_review", "reason": "内部错误：%s" % str(exc)[:150]}
                break
            if rec.get("status") != "pending" or "限速" not in str(rec.get("reason") or ""):
                break
            wait_s = float(rec.get("waitS") or 0)
            if wait_s <= 0:
                stopped = str(rec.get("reason") or "")
                break
            time.sleep(min(wait_s + 1.0, float(_num(cfg.get("search") or {}, "max_wait_s", 120))))
        done.append({"plid": plid, "status": rec.get("status"), "offerId": rec.get("offerId"),
                     "confidence": rec.get("confidence"), "reason": (rec.get("reason") or "")[:80]})
        if stopped:
            stopped_at = stopped
            break
    return {"queue": len(queue), "processed": len(done), "results": done,
            "rule": cfg.get("rule"), "modelMode": (cfg.get("model") or {}).get("mode") or "(未配置)",
            "stopped": stopped_at}


if __name__ == "__main__":
    import sys
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    lim = int(args[0]) if args and args[0].isdigit() else 3
    sel = [sys.argv[i + 1] for i, a in enumerate(sys.argv) if a == "--plid" and i + 1 < len(sys.argv)]
    print(json.dumps(run(limit=lim, dry=("--dry" in sys.argv), plids=sel or None),
                     ensure_ascii=False, indent=2))
