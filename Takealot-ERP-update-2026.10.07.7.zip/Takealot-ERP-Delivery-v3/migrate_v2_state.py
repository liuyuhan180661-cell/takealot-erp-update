#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v2（Hermes 插件两半）→ v3（常驻服务端）店铺与配置迁移。

    <venv python> migrate_v2_state.py --from "%LOCALAPPDATA%\\hermes\\plugins\\takealot-erp\\state" [--dry-run]

做什么：
  · ``stores.json``：按 store id 合并店铺行；**带密钥的那一份优先**（v2 里 dpapi: 密文在
    同一台机器、同一个 Windows 用户下可以直接被 v3 解开 —— DPAPI 就是绑到用户账号的，
    所以不需要用户重新粘贴 Key，也不会有任何明文经过这个脚本）。
  · 其余本地数据按白名单搬：规则 / 定价策略 / 类目中文名 / 采集箱 / 草稿箱 /
    竞品快照 / 跟价账本 / 出价日志 / 速度缓存。
  · ``crawler`` 配置（**出口代理**）与 v2 插件目录 ``.env`` 里的 ``TAKEALOT_API_PROXY`` /
    ``DEEPSEEK_API_KEY`` 一起继承（只填 v3 还空着的那些）—— 丢了出口代理，升级后爬虫会
    回落到直连、在中国出口被 Cloudflare 403，表现成"升完级又抓不到了"。
  · **不搬** ``repricing_watch.json``（自动跟价授权）：换版后自动写价一律回到"未授权"，
    要开必须重新明确授权一次 —— 这是红线，不能靠迁移悄悄继承。

输出只有店铺名与"有没有密钥"，**永不打印密钥本身**（``.env`` 的值同样不回显，只报键名）。
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass

#: 按白名单搬的本地数据（旧文件名 → 新文件名，同名即原样）
COPY_FILES = ("rules.json", "pricing_strategy.json", "category_zh.json", "collection.json",
              "drafts.json", "competitors.json", "price_log.json", "offer_writes.json",
              "ai_analysis.json", "velocity_cache", "offers_cache", "repricing_watch_log.md",
              "ingest", "ingest_log.json")
#: 明确**不搬**的：授权状态与审计（换版后必须重新授权）
NEVER = ("repricing_watch.json",)
#: 从 v2 的 .env 继承的键（只填 v3 里还空着的；值永不回显）
ENV_KEYS = ("TAKEALOT_API_PROXY", "DEEPSEEK_API_KEY")


def merge_crawler(old: dict, new: dict) -> tuple[dict, str]:
    """把 v2 stores.json 里的 crawler 配置（**出口代理**）带过来。

    为什么必须带：出口代理是"客户机还能不能取到数"的前提。丢了它，升级后爬虫回落到
    direct → 中国出口被 Cloudflare 403 → 用户看到的是"升完级又抓不到了"。
    """
    out = {k: v for k, v in (new or {}).items()}
    old_cfg = old.get("crawler") if isinstance(old.get("crawler"), dict) else {}
    cur_cfg = out.get("crawler") if isinstance(out.get("crawler"), dict) else {}
    merged = dict(cur_cfg)
    note = ""
    for key, value in old_cfg.items():
        if key == "proxy":
            if not str(merged.get("proxy") or "").strip() and str(value or "").strip():
                merged["proxy"] = value
                note = "出口代理沿用 v2 的（值不回显）"
        elif key not in merged:
            merged[key] = value
    if merged:
        out["crawler"] = merged
    return out, note


def _is_placeholder(value: str) -> bool:
    """v2 文档里教的占位写法（``http://<proxy-host>:8899``）不能被当成真配置继承。"""
    text = value.strip().lower()
    return (not text) or "<" in text or ">" in text or "proxy-host" in text or "host:port" in text


def env_from_v2(src: Path) -> dict:
    """v2 的 ``.env`` 放在插件目录（state 的上一级），也可能直接放在 state 里。"""
    out: dict[str, str] = {}
    for path in (src.parent / ".env", src / ".env"):
        if not path.is_file():
            continue
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key, value = key.strip(), value.strip()
            if key in ENV_KEYS and not _is_placeholder(value):
                out.setdefault(key, value)
    return out


def merge_env_file(home: Path, inherited: dict) -> list[str]:
    """把继承来的键写进 ERP_HOME/.env —— **只填空的**，客户已填的一律不动。"""
    if not inherited:
        return []
    path = home / ".env"
    lines = path.read_text(encoding="utf-8").splitlines() if path.is_file() else []
    filled: list[str] = []
    seen: set[str] = set()
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, _, value = stripped.partition("=")
        key = key.strip()
        seen.add(key)
        if key in inherited and not value.strip():
            lines[i] = "{0}={1}".format(key, inherited[key])
            filled.append(key)
    for key, value in inherited.items():
        if key not in seen:
            lines.append("{0}={1}".format(key, value))
            filled.append(key)
    if filled:
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return filled


def key_kind(raw) -> str:
    s = str(raw or "")
    if s.startswith("dpapi:"):
        return "dpapi"
    if s.startswith("kc:"):
        return "keychain"
    return "plain" if s else "none"


def merge_stores(old: dict, new: dict) -> tuple[dict, list[str]]:
    """按 id 合并；同一家店两处都有时，**取带密钥的那一份**。"""
    by_id: dict[str, dict] = {}
    for row in (new.get("stores") or []):
        if isinstance(row, dict) and row.get("id"):
            by_id[str(row["id"])] = row
    notes: list[str] = []
    for row in (old.get("stores") or []):
        if not isinstance(row, dict) or not row.get("id"):
            continue
        sid = str(row["id"])
        cur = by_id.get(sid)
        if cur is None:
            by_id[sid] = row
            notes.append("加入店铺 {0}（{1}，密钥 {2}）".format(sid, row.get("name"), key_kind(row.get("_key"))))
        elif key_kind(row.get("_key")) != "none" and key_kind(cur.get("_key")) == "none":
            by_id[sid] = row
            notes.append("店铺 {0} 用旧配置覆盖（旧的有密钥）".format(sid))
    keyed = [s for s in by_id.values() if key_kind(s.get("_key")) != "none"]
    active = str(new.get("activeStoreId") or "")
    old_active = str(old.get("activeStoreId") or "")
    # 当前店的选择顺序：v2 当时用的那家（且它真有密钥）→ v3 现在的（且有密钥）→ 任一有密钥的 → 第一行
    if old_active in by_id and key_kind(by_id[old_active].get("_key")) != "none":
        active = old_active
    elif active not in by_id or key_kind(by_id.get(active, {}).get("_key")) == "none":
        active = (keyed[0]["id"] if keyed else (active or next(iter(by_id), "")))
    return {"activeStoreId": active, "stores": list(by_id.values())}, notes


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="src", required=True, help="v2 的 state 目录")
    ap.add_argument("--to", dest="dst", default="", help="v3 的 ERP_HOME（默认按平台惯例找）")
    ap.add_argument("--dry-run", action="store_true", help="只报会做什么，不落盘")
    args = ap.parse_args()

    src = Path(args.src).expanduser()
    if not src.is_dir():
        print("FAIL 找不到 v2 state 目录：{0}".format(src))
        return 1
    if args.dst:
        home = Path(args.dst).expanduser()
    else:
        env = next((os.environ.get(n, "").strip() for n in ("ERP_HOME", "TAKEALOT_ERP_HOME")
                    if os.environ.get(n, "").strip()), "")
        if env:
            home = Path(env)
        elif sys.platform == "win32":
            home = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")) / "TakealotERP"
        else:
            home = Path.home() / ".takealot-erp"
    dst = home / "state"
    print("== migrate v2 -> v3 ==")
    print("   from: {0}".format(src))
    print("   to:   {0}".format(dst))

    old_stores = json.loads((src / "stores.json").read_text(encoding="utf-8")) if (src / "stores.json").is_file() else {}
    new_file = dst / "stores.json"
    new_stores = json.loads(new_file.read_text(encoding="utf-8")) if new_file.is_file() else {}
    merged, notes = merge_stores(old_stores, new_stores)
    merged, proxy_note = merge_crawler(old_stores, merged)
    inherited_env = env_from_v2(src)

    print("-- stores.json")
    for n in notes:
        print("   · {0}".format(n))
    if proxy_note:
        print("   · {0}".format(proxy_note))
    print("   结果 {0} 家店，当前店 {1}".format(len(merged.get("stores") or []), merged.get("activeStoreId") or "(空)"))
    for s in merged.get("stores") or []:
        print("      {0}  {1}  密钥={2}".format(s.get("id"), s.get("name"), key_kind(s.get("_key"))))

    print("-- 本地数据（白名单）")
    copied: list[str] = []
    skipped: list[str] = []
    for name in COPY_FILES:
        p = src / name
        if not p.exists():
            continue
        copied.append(name)
    for name in NEVER:
        if (src / name).exists():
            skipped.append(name + "（授权状态，换版后必须重新授权）")
    print("   搬: {0}".format("、".join(copied) or "（无）"))
    print("   不搬: {0}".format("、".join(skipped) or "（无）"))
    print("-- .env（出口代理 / 模型 Key；只填 v3 还空着的键，值不回显）")
    print("   继承: {0}".format("、".join(inherited_env) or "（无）"))
    # 明确写一份"未授权"的跟价配置，避免旧授权被任何路径误继承
    print("   写入 repricing_watch.json: authorized=false（自动跟价回到未授权）")

    if args.dry_run:
        print("DRY-RUN：以上都没有落盘。")
        return 0

    dst.mkdir(parents=True, exist_ok=True)
    new_file.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")
    filled_env = merge_env_file(home, inherited_env)
    if filled_env:
        print("   .env 已填: {0}（原值非空的一律没动）".format("、".join(filled_env)))
    for name in copied:
        s, d = src / name, dst / name
        if s.is_dir():
            if d.exists():
                shutil.rmtree(d)
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)
    watch = dst / "repricing_watch.json"
    if watch.is_file():
        try:
            cur = json.loads(watch.read_text(encoding="utf-8"))
            cur["authorized"] = False
            cur["note"] = cur.get("note") or "migrated from v2: authorization intentionally reset"
            watch.write_text(json.dumps(cur, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
    else:
        watch.write_text(json.dumps({"authorized": False,
                                     "note": "migrated from v2: authorization intentionally reset"},
                                    ensure_ascii=False, indent=2), encoding="utf-8")
    print("RESULT 迁移完成（密钥未以明文经过本脚本；自动跟价未授权）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
