# 客户机 Python 版本 / 架构检查（给客户的 agent 读）

离线安装用的是**包内自带的 wheelhouse**（`payload/wheelhouse` 或 `payload/wheelhouse-win`）。
里面有纯 Python 轮子（任何机器都能装），也有**平台二进制轮子**——后者跟解释器的版本和架构
一一对应，装错了 `pip` 只会回一句 "No matching distribution found"，客户看不懂。

所以**装机前先检查一次**，不对就先装对应的 Python，别硬装。

---

## 1. 先跑这三条（结果贴给客户）

```bash
# ① 解释器版本与位数
python3 -c "import sys,platform;print(sys.version);print('64位' if sys.maxsize>2**32 else '32位')"
# ② 平台标签（Windows 会打印 win_amd64 / win32；macOS 会打印 macOS 版本 + x86_64/arm64）
python3 -c "import platform,sysconfig;print(platform.system(), platform.machine(), sysconfig.get_platform())"
# ③ 这个包里带的二进制轮子支持哪些组合（把 <解压目录> 换成实际路径）
ls <解压目录>/payload/wheelhouse*/pydantic_core-*.whl
```

判据：**第 ③ 条列出的每一个文件名里，必须至少有一个与你第 ① ② 条的结果完全对上**
（`cp312` 对 Python 3.12、`cp314` 对 3.14、`win_amd64` 对 64 位 Windows、
`macosx_*_x86_64` 对 Intel Mac、`macosx_*_arm64` 对 Apple Silicon）。

> 当前交付包带的组合（截至本文件写入时）：
> - Windows：`cp312-win_amd64` → **必须 Python 3.12（64 位）**
> - macOS：`cp314-macosx_10_12_x86_64` → **必须 Python 3.14（Intel）**
> 这条会随包变化，**以第 ③ 条实际列出的文件名为准**，不要背上面的数字。

---

## 2. 对不上怎么办（Windows，最常见）

目标是装一个 **Python 3.12 x64**（不改动机器上已有的其它版本）：

```powershell
# 方式 A：装到用户目录、不需要管理员（推荐）
winget install --id Python.Python.3.12 --scope user --silent
# 装完拿它的绝对路径建环境（装的是哪个版本，用它自己的解释器跑安装脚本）
& "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe" -c "import sys;print(sys.version)"

# 方式 B：官网安装包（勾选 "Add python.exe to PATH"）
# https://www.python.org/downloads/windows/  → 选 Windows installer (64-bit)
```

然后用**那个解释器**跑安装脚本（这一步很关键，否则又用了机器上默认的那个）：

```powershell
& "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe" <解压目录>\install.ps1
```

macOS（Intel 机器要 Python 3.14）：

```bash
/usr/local/bin/python3 -V            # 确认是 3.14
# 没有就用 brew 或官网 pkg 装 3.14，然后
ERP_PYTHON=/usr/local/bin/python3 bash <解压目录>/install.sh
```

---

## 3. 装的时候会看到什么

- 版本对得上：安装脚本会走**离线安装**（`--no-index --find-links wheelhouse`），不联网也能装完。
- 版本对不上但我们允许联网：会自动**回退联网安装**，并在屏幕上说明原因。
- 版本对不上且要求离线（客户机没网/被墙）：安装会在"装依赖"这一步**明确失败**并给出本文档的
  路径与本包支持的组合 —— 这属于**环境没准备好**，不是包坏了，按上面第 2 节装对应 Python 再来。

---

## 4. 为什么不做"全版本矩阵"

把 cp310–cp314 × win32/win64 × mac x86/arm64 的轮子全塞进包里，包体会从 **8 MB 涨到 40 MB 左右**，
而更新通道在国内依赖的备用下载通道（jsDelivr）对单文件有体积上限——**超了就等于把备用通道弄断**，
升级反而更容易失败。所以选择：包只带最常见的组合 + 本文档让 agent 在装机前把环境检查/补齐。

需要支持新的 Python 版本时，**加轮子**是正解（`pip download --only-binary=:all: --platform … --python-version …`
把 wheel 放进 `products/takealot-erp/build/wheelhouse-win/`），而不是放宽安装脚本的版本门槛。
