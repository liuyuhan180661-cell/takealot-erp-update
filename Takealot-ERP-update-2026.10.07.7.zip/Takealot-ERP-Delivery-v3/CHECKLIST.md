# Takealot ERP 工作台 · 验收清单（v3）

规矩：**只认命令输出**，不认"应该没问题"。每条都写了期望结果，不符就是没通过。
全部命令里的 `<ERP>` = `~/.takealot-erp`（Mac），`ERPPY` = `$ERP/venv/bin/python`。

## A. 装完立刻验（客户机本人做，5 分钟）

| # | 命令 | 期望结果 |
|---|---|---|
| A1 | `sh install.sh --offline` | 每步 `OK`，结尾 `RESULT 13/13 PASS` |
| A2 | `$ERPPY $ERP/server/cli.py status` | 打印端口/PID/版本/密钥库；**退出码 0**；没跑时退出码 3 |
| A3 | `$ERPPY $ERP/server/cli.py doctor` | `RESULT 13/13 PASS`（WARN 项不影响，FAIL 必须为 0） |
| A4 | `$ERPPY $ERP/server/cli.py doctor --json` | `"ok": true`，`failed: []` |
| A5 | 双击 `~/Applications/Takealot ERP 工作台.command` | 出现无地址栏窗口，顶栏右侧绿点 + `服务端 3.0.0 · :<端口>` |
| A6 | `lsof -nP -iTCP:18791 -sTCP:LISTEN` | 只有本机回环（`127.0.0.1`）一条，无 `*` |
| A7 | 关掉窗口后再 `status` | 仍然在跑（服务常驻，窗口只是看板） |

## B. 解耦证明（这一条是这次改造的核心）

| # | 命令 | 期望结果 |
|---|---|---|
| B1 | 退出所有 agent（Hermes/Codex 全关），再双击桌面入口 | 工作台照常打开、数据照常 |
| B2 | `ps -Ao command \| grep hermes` | 工作台相关的进程里**没有** agent 的进程 |
| B3 | 把 `/Applications/Hermes.app` 改名（临时），再双击入口 | 工作台照常打开（不依赖 agent 本体） |

## C. 数据与红线

| # | 命令 | 期望结果 |
|---|---|---|
| C1 | 界面 → 多店铺设置 → 录 Key → **点「设为当前」** | 页面数字开始出现；`$ERP/state/stores.json` 里 `_key` 是密文（macOS 钥匙串引用 `kc:` / Windows `dpapi:`），**明文 0 处** |
| C2 | `grep -c '"' $ERP/state/stores.json` 后人工看 `_key` 字段 | 不含完整 Seller Key |
| C3 | 断开网络后重开工作台 | 界面照常打开；只有"取实时数据"会失败，且**返回真实原因**（不出现编造的样例数字） |
| C4 | `erp doctor` 的「核心 sha256 与运行时记录一致」 | PASS（防半新半旧部署） |

## D. agent 侧（可选，挂了就验）

| # | 命令 | 期望结果 |
|---|---|---|
| D1 | `hermes mcp list` | `takealot-erp  ✓ enabled` |
| D2 | `hermes mcp test takealot-erp` | `Connected` + `Tools discovered: 20`（冷启动可能超时，重试一次） |
| D3 | 在 agent 里说「打开工作台」 | agent 调 `erp_workbench_open`（不是自己拼 URL），回话含真实端口 |
| D4 | 在 agent 里说「把某个商品价格改成 X」 | agent **拒绝**并引到界面（工具表里没有写平台的工具） |
| D5 | `tail -5 $ERP/logs/mcp-sessions.log` | 能看到 `spawn / initialize(client=…) / tools/list / tools/call` |

## E. 出问题时：先让 agent 自愈，再回传证据

**先让客户机上的 agent 用 `takealot-erp-selfheal` 技能**（随包自动装好）：它会按判据表定位（服务/本地桥/网络出口/店铺密钥/运行环境），
能自愈的当场修好并复验，修不了的按下面的"证据包"整理好交给你。

必须一起回传的东西（自愈技能里的证据包模板就是按这个顺序）：

1. `status` 与 `doctor --json` 的完整输出
2. `erp_diagnostics` 的 `summary` 与 `seller`/`public` 两行原文（平台侧是否可用只看这里）
3. `$ERP/logs/server.out` 尾部 30 行（agent 相关问题再加 `mcp-sessions.log` 尾部 10 行）
4. 你的系统版本与 Python 版本（`sw_vers` / `python3 -V`）

> **不要**回传：Seller Key、任何令牌、卡号、客户个人信息。
> `sha256 不匹配` 这类拒装提示属防投毒红线：**不要 `--force` 绕过**，原样回传即可。

> 交付方复验（不用客户机）：包内 `MANIFEST.md5` 逐文件校验 + `python3 scripts/scan_secrets.py <包>` 必须干净。
