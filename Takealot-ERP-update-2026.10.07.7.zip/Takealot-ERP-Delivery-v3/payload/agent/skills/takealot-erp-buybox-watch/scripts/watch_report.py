#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""买盒盯盘 · 日报（只读，不写任何价）

回答三个问题（每个数字都必须来自真实端点/账本，缺数据就说缺）：
  一、哪些曾经丢了买盒、现在抢回来了
  二、哪些一直在我们手上（稳定占优）
  三、哪些还没抢回来 / 抓不到竞品数据（要人工）

用法（客户机）：
    <hermes venv python> watch_report.py [--store store-2] [--hours 24]
退出码：0 = 报告正常；1 = 报告里含失败/未验证项（需人工看一眼）。

数据来源（缺一不可，都是本机已有的事实）：
  · state/repricing_watch.json      —— 授权范围（间隔、下探范围、店铺）
  · state/repricing_watch_log.md    —— 巡检账本（每轮写入/跳过/失败，逐行 append）
  · 后端 repricing_candidates()     —— 当前买盒归属 / 最低竞品价（读缓存，不快抓）
"""
import argparse
import datetime as dt
import json
import os
import re
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERMES = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "hermes")
PLUGIN = os.path.join(HERMES, "plugins", "takealot-erp")


# ── 布局自适应：v2（插件两半）/ v3（常驻服务端）──────────────────────────────
# v2：插件自带 plugin_api，直接 import（历史形态；客户机 box 就是这种）。
# v3：**不 import 内部模块**，改走常驻服务端的本机 HTTP API（与工作台界面同一条读写路径，
#     需 X-ERP-Token，只监听 127.0.0.1）。数字一样来自接口：零模拟、拿不到就照实报。
def _erp_home_v3():
    """v3 家目录：跟服务端 app.py 的 default_erp_home() 保持同一套规则。

    Windows 默认是 `%LOCALAPPDATA%\TakealotERP`（不是 ~/.takealot-erp）—— 漏了它，
    在 Windows 上就会「找不到 v3 服务端」而误报没装（真机踩过）。
    """
    win_default = os.path.join(os.environ.get("LOCALAPPDATA") or
                               os.path.join(os.path.expanduser("~"), "AppData", "Local"), "TakealotERP")
    for cand in (os.environ.get("ERP_HOME"), os.environ.get("TAKEALOT_ERP_HOME"),
                 win_default,
                 os.path.join(os.path.expanduser("~"), ".takealot-erp")):
        if cand and os.path.exists(os.path.join(cand, "runtime.json")):
            return cand
    return None


class _V3Api:
    """把脚本用到的调用映射到 v3 本机路由（只读脚本用）。"""

    def __init__(self, home):
        import json as _json
        self.home = home
        with open(os.path.join(home, "runtime.json"), encoding="utf-8") as fh:
            info = _json.load(fh)
        self.port = int(info.get("port") or 0)
        self.token = info.get("token") or ""

    @property
    def _state_dir(self):
        return os.path.join(self.home, "state")

    def _api_request(self, method, path, query=None, body=None, store_id=None, **_kw):
        import json as _json
        import urllib.parse
        import urllib.request
        q = dict(query or {})
        if store_id:
            q.setdefault("storeId", store_id)
        url = "http://127.0.0.1:{0}/api/plugins/takealot-erp{1}".format(self.port, path)
        if q:
            url += "?" + urllib.parse.urlencode({k: v for k, v in q.items() if v not in (None, "")})
        data = _json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, method=method.upper(),
                                     headers={"X-ERP-Token": self.token, "Content-Type": "application/json"})
        # 本机回环必须绕系统代理（Clash 之类会把 127.0.0.1 拦成 502）
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        try:
            with opener.open(req, timeout=180) as resp:
                return _json.loads(resp.read().decode("utf-8") or "{}"), resp.status
        except urllib.error.HTTPError as exc:
            try:
                return _json.loads(exc.read().decode("utf-8") or "{}"), exc.code
            except Exception:
                return {"ok": False, "error": "HTTP {0}".format(exc.code)}, exc.code
        except Exception as exc:
            return {"ok": False, "error": "{0}: {1}".format(type(exc).__name__, exc)}, 0

    def _settings(self):
        d, _ = self._api_request("GET", "/settings")
        return d or {}

    def _active_store(self):
        sid = self._settings().get("activeStoreId") or ""
        return {"id": sid} if sid else None

    def _store_row(self, store_id):
        for s in self._settings().get("stores") or []:
            if str(s.get("id")) == str(store_id):
                return s
        return None

    def fulfilment(self, storeId="", limit=200, **_kw):
        return self._api_request("GET", "/fulfilment", {"limit": limit}, None, storeId or None)[0]

    def orders_live(self, storeId="", limit=200, **_kw):
        return self._api_request("GET", "/orders/live", {"limit": limit}, None, storeId or None)[0]

    def repricing_candidates(self, storeId="", probe=0):
        return self._api_request("GET", "/repricing/candidates", {"probe": probe}, None, storeId or None)[0]


def _v3_alive(home) -> bool:
    """v3 服务端在不在跑（读 runtime.json 的端口探一下 TCP）。"""
    import json as _json
    import socket as _socket
    try:
        with open(os.path.join(home, "runtime.json"), encoding="utf-8") as fh:
            port = int((_json.load(fh) or {}).get("port") or 0)
        if not port:
            return False
        with _socket.socket() as s:
            s.settimeout(1.5)
            return s.connect_ex(("127.0.0.1", port)) == 0
    except Exception:
        return False


def _load_api():
    """**v3 优先**：服务端活着就用它（跟工作台界面同一条取数路径）。

    机器上可能同时留着 v2 插件（老客户升级现场就是这样）：谁优先不能靠"哪个目录在"，
    得看**哪个真能用**。真机踩过：v2 目录还在、但它的桥早停了 → 脚本挑到 v2 一路
    connection refused，而新的 v3 服务端明明在跑。所以顺序 = v3 在跑 → v3；否则 v2；否则 ABORT。
    """
    home = _erp_home_v3()
    if home and _v3_alive(home):
        return _V3Api(home)
    for cand in (PLUGIN, os.path.join(PLUGIN, "dashboard")):
        if os.path.exists(os.path.join(cand, "plugin_api.py")):
            sys.path.insert(0, cand)
            import plugin_api as A  # noqa: F401
            return A
    if home:
        return _V3Api(home)          # v3 装了但没在跑：照旧用它，报错会说清"先起服务"
    print("ABORT: 这台机器上找不到 ERP —— v2 插件（{0}）与 v3 服务端（~/.takealot-erp/runtime.json）都没有；"
          "什么都不读、什么都不写。".format(PLUGIN))
    sys.exit(2)


A = _load_api()

STATE = getattr(A, "_state_dir", None) or os.path.join(PLUGIN, "state")
LOG_NAME = "repricing_watch_log.md"
WATCH_NAME = "repricing_watch.json"

#: 账本行形如 `- 2026-09-30 22:14 | SKU | WROTE(已验证) | 199.0 -> 198 | 平台回读 198.0 | 原因`
LINE_RE = re.compile(r"^-\s*(\d{4}-\d{2}-\d{2} \d{2}:\d{2})\s*\|\s*([^|]*)\|\s*([^|]*)\|(.*)$")


def load_json(name, default):
    path = os.path.join(STATE, name)
    if not os.path.exists(path):
        return default
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return default


def read_ledger(hours):
    """返回窗口内的账本行 [(stamp, sku, result, rest)]。文件不存在 = 空，不编。"""
    path = os.path.join(STATE, LOG_NAME)
    if not os.path.exists(path):
        return [], path
    cut = dt.datetime.now() - dt.timedelta(hours=hours)
    rows = []
    with open(path, encoding="utf-8", errors="replace") as fh:
        for raw in fh:
            m = LINE_RE.match(raw.strip())
            if not m:
                continue
            try:
                stamp = dt.datetime.strptime(m.group(1), "%Y-%m-%d %H:%M")
            except ValueError:
                continue
            if stamp < cut:
                continue
            rows.append((m.group(1), m.group(2).strip(), m.group(3).strip(), m.group(4).strip()))
    return rows, path


def bucket(items, wrote_skus, lost_skus):
    """把候选分成四类。判定只用端点给的字段，不猜。"""
    back, held, stuck, blind = [], [], [], []
    for it in items:
        sku = str(it.get("sku") or "")
        is_held = it.get("buyboxHeld") is True
        low = it.get("lowestCompetitor")
        entry = {"sku": sku, "title": (it.get("title") or "")[:38],
                 "price": it.get("currentPrice"), "low": low,
                 "action": it.get("action"), "reason": it.get("reason"),
                 "listed": it.get("listed"), "crawled": it.get("crawled")}
        if is_held and sku in wrote_skus:
            back.append(entry)                     # 丢过 → 抢回来了
        elif is_held:
            held.append(entry)                     # 一直在手上
        elif low is None and not it.get("crawled"):
            blind.append(entry)                    # 连竞品价都没有 → 抓取通道问题
        else:
            stuck.append(entry)                    # 有对手、买盒在别人手上
    return back, held, stuck, blind


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", default="")
    ap.add_argument("--hours", type=int, default=24)
    args = ap.parse_args()

    cfg = load_json(WATCH_NAME, {})
    stores = [args.store] if args.store else list(cfg.get("storeIds") or [])
    ledger, log_path = read_ledger(args.hours)

    wrote_skus = {r[1] for r in ledger if r[2].startswith("WROTE(已验证)")}
    unverified = [r for r in ledger if r[2].startswith("WROTE(未验证")]
    failed = [r for r in ledger if r[2].startswith("FAILED")]
    skipped = [r for r in ledger if r[2] == "SKIPPED"]
    lost_skus = {r[1] for r in ledger if r[2].startswith("WROTE") or r[2] == "FAILED"}

    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    print("买盒盯盘日报 · {0} · 窗口 {1}h".format(now, args.hours))
    if cfg.get("authorized") is True:
        print("授权：间隔 {0}h ｜ 下探 {1}~{2} ｜ 保本底价 {3} ｜ 天花板 {4} ｜ 店铺 {5}".format(
            cfg.get("intervalHours"), cfg.get("minUndercut"), cfg.get("maxUndercut"),
            cfg.get("floorPrice") if cfg.get("floorPrice") is not None else "未设",
            cfg.get("ceilingPrice") if cfg.get("ceilingPrice") is not None else "未设",
            ", ".join(stores) or "（无）"))
    else:
        print("授权：**未授权**（state/{0} 里 authorized != true）——巡检不会写价".format(WATCH_NAME))
    print("账本：{0} ｜ 窗口内 {1} 行（写入 {2} / 跳过 {3} / 失败 {4}）".format(
        log_path, len(ledger), len(wrote_skus), len(skipped), len(failed) + len(unverified)))
    if not stores:
        print("店铺：未指定，也没在 {0} 里找到 storeIds —— 只报账本，不查当前买盒。".format(WATCH_NAME))

    total_stuck = total_held = 0
    for store in stores:
        cand = A.repricing_candidates(storeId=store) or {}
        if not cand.get("ok"):
            print("\n[{0}] 读候选失败：{1}（照实报，不当成 0）".format(store, cand.get("reason") or cand.get("error")))
            continue
        items = cand.get("items") or []
        back, held, stuck, blind = bucket(items, wrote_skus, lost_skus)
        total_stuck += len(stuck)
        total_held += len(held) + len(back)

        print("\n[{0}] 候选 {1} 条 ｜ 买盒在手 {2} ｜ 待夺回 {3} ｜ 无竞品数据 {4}".format(
            store, len(items), len(held) + len(back), len(stuck), len(blind)))

        print("  ① 丢失后已抢回（{0}）".format(len(back)))
        for r in back[:12]:
            print("     - {0} {1}｜现价 R{2} ｜对手 R{3}（本窗口写过价）".format(
                r["sku"], r["title"], r["price"], r["low"]))
        if not back:
            print("     - 无（窗口内没有『写过价且现在买盒在手』的记录）")

        print("  ② 稳定占优，无需动作（{0}）".format(len(held)))
        for r in held[:8]:
            print("     - {0} {1}｜现价 R{2}".format(r["sku"], r["title"], r["price"]))
        if len(held) > 8:
            print("     - …另有 {0} 条".format(len(held) - 8))

        print("  ③ 还没抢回来（{0}）—— 要人工看一眼".format(len(stuck)))
        for r in stuck[:12]:
            wrote = "本窗口写过价" if r["sku"] in wrote_skus else "未写过价"
            print("     - {0} {1}｜现价 R{2} ｜对手 R{3} ｜{4}｜{5}".format(
                r["sku"], r["title"], r["price"], r["low"], wrote, r["reason"] or r["action"] or ""))
        if not stuck:
            print("     - 无")

        print("  ④ 抓不到竞品数据（{0}）—— 先查通道，不是没对手".format(len(blind)))
        for r in blind[:8]:
            print("     - {0} {1}｜{2}".format(r["sku"], r["title"], r["action"] or "未抓取"))
        if not blind:
            print("     - 无")

    if failed or unverified:
        print("\nPROBLEMS（写入失败/未通过回读验证，逐条如下）：")
        for r in (failed + unverified)[:20]:
            print("  - {0} {1}｜{2}".format(r[0], r[1], r[3][:80]))

    print("\n结论：待夺回 {0} 条 ｜ 买盒在手 {1} 条 ｜ 窗口内写入 {2} 条 ｜ 失败/未验证 {3} 条".format(
        total_stuck, total_held, len(wrote_skus), len(failed) + len(unverified)))
    if not stores:
        print("（未查当前买盒：没有店铺作用域；以上只有账本数字。）")
    sys.exit(1 if (failed or unverified) else 0)


if __name__ == "__main__":
    main()
