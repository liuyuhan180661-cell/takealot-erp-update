---
name: takealot-erp-logistics-patrol
description: Use when 客户要 物流巡查 / 送仓单超时预警 / 签收与退货日报（Takealot ERP）。只读巡检，定时把「要马上处理」的 PO 和退货甩给用户。
---

# 物流巡查提醒（Takealot ERP）

只读技能：**不写平台、不动价格**，只把「快超时 / 已逾期 / 已签收 / 用户退货」讲清楚。

## 何时用
- 用户说「物流巡查」「送仓单要超时了吗」「哪些要马上处理」「今天签收和退货怎么样」「有没有退货」。
- 定时提醒：每天 08:30 与 15:30 各一次（见下）。

## 脚本自己认运行形态（**不要手改路径**）

脚本按运行环境自适应取数，两种形态都不用手动指定路径：

- **v3（常驻服务端，默认）**：不 import 内部模块，改走**本机 HTTP API**（`http://127.0.0.1:<port>/api/plugins/takealot-erp/*`，
  带 `runtime.json` 里的 `X-ERP-Token`，**必须绕系统代理**）——与工作台界面同一条取数路径，数字一样来自接口。
- **v2（Hermes 插件两半，历史形态）**：若旁边有 `plugin_api.py` → 直接 import，行为同以前。
- 两种都找不到 → `ABORT: …什么都不读` 并 `exit 2`（**不是** 0，别把"没装"说成"没异常"）。

实测（v3 装机实例、真店）：`物流巡查 · 店铺 1（store-2）` → 251 单 / 营收 R298,258 / 净利 R285,913.52 /
退货 7 单，`PROBLEMS` 段如实列出。

## 执行入口（平台无关；优先内置定时任务）
1. **首选**：`erp job run logistics-patrol` —— 走客户机自己的内置调度器，脚本在 `ERP_HOME/server/jobs/`
   （**随升级换新**），状态写 `ERP_HOME/state/jobs_status.json`，证据文件 `ERP_HOME/logs/jobs/logistics-patrol/<时间>.md`。
   agent **只许运行它并原样转述输出**，不许自己算单量、不许把「读取失败」讲成「没有异常」。
2. **要带自定义参数的一次性跑**：运行本技能自带脚本（在 `ERP_HOME/agent/skills/takealot-erp-logistics-patrol/scripts/`）：
```
<python> "<ERP_HOME>/agent/skills/takealot-erp-logistics-patrol/scripts/logistics_patrol.py" [--store <店>] [--days 7]
```
   解释器用 ERP_HOME 里的 venv（Win `<ERP_HOME>\venv\Scripts\python.exe`、mac/Linux `<ERP_HOME>/venv/bin/python`）。
   **不要写死任何 hermes 主目录路径。**
- 退出码 0 = 没有要马上处理的项目；1 = 有逾期 PO / 退货 / 读数失败（需人工）。
- 数据源：Seller API `/shipments`（`fulfilment()` 的 `stages.inbound/outbound.pos`）与 `/sales`（`orders_live()`）。
  读数失败时脚本会打 `读数失败：<原因>`，照实说，不要用 0 代替。

## 口径（写进报告，别自己发挥）
- `actionable`（要动作）= **未发运且未取消**；已发运 / 已取消 / 已收货都不算要动作。
- `daysToDue < 0` = 已逾期；`0 ≤ daysToDue ≤ --days` = 即将到期（默认 7 天）。
- 签收 = `Delivered` + `Collected`；退货 = `Returned`；在途 = `Shipped`；待发货 = `Awaiting Shipment`。
- 订单口径同 `/sales`：营收 = Σ(售价×数量)，平台费是平台已计费部分（**滞后**），净利未扣采购成本。
- 状态未认出的原始值**原样列出**，不翻译、不归类。

## 报告结构（固定四段）
1. **必须马上处理**：入仓 / 出库两条线各自的「逾期 N 张 ｜ X 天内到期 M 张 ｜ 无截止日 K 张」，逐张列 PO 号、类型、截止日、剩几天、目的区域、状态。
2. **已签收**：单量与金额（Delivered/Collected 分解）。
3. **用户退货**：逐条（订单号 / SKU / 标题 / 金额 / 日期）+ 合计。
4. **其它异常**：取消、在途未签收、未归类状态、数据截断/读数警告。

## 定时提醒（**跑在客户机自己身上**，不用 Hermes cron、不用 ssh 转发）
任务 `logistics-patrol` 已内置在 ERP 调度器里（每天 08:30 / 15:30），脚本在 `ERP_HOME/server/jobs/`：
```
erp job list                       # 排期 / 上次结果 / 下次时间 / 调度线程在不在跳
erp job run logistics-patrol       # 手动跑一轮（真数据；退出码 1 = 有要处理的）
```
自然语言入口：说「物流巡查」「现在就跑一次物流巡查」→ 命中词表落到上面命令。
每轮输出落 `ERP_HOME/logs/jobs/logistics-patrol/<时间>.md`，状态在 `ERP_HOME/state/jobs_status.json`；跑不动/连不上会**明确出声**（离线连续计数升级）。

## 硬规矩
- 只读；不碰 `.env`、不碰模型配置、不碰别的插件。
- 不把「没数据」说成「没问题」：`ok:false` 一律照原文报。
- 退货/逾期是**用户要付钱的事**，这类数字必须能在报告里一眼看到，别藏在段落中间。
