#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""物流巡查 · 定时提醒（只读）

回答四件事（数字全部来自 Seller API /shipments 与 /sales，缺数据就说缺）：
  一、必须马上处理：送仓 PO 已逾期 / N 天内到期 / 待发运（= 平台侧要动作的）
  二、已签收：订单状态 Delivered / Collected 的单量与金额
  三、用户退货：Returned 明细（订单号 / SKU / 标题 / 金额 / 日期）
  四、其它异常：Cancelled、状态未知、「已发运但未签收」的在途量

用法（客户机）：
    <hermes venv python> logistics_patrol.py [--store store-2] [--days 7] [--orders-limit 400]
退出码：0 = 正常；1 = 有逾期 PO 或读数失败（要马上处理）。

数据来源：
  · 后端 fulfilment(storeId=...)  → stages.inbound/outbound.pos[]（po/dueDate/daysToDue/actionable/stateLabel）
                                     stages.orders.summary（byStatus/gross/net）
  · 后端 orders_live(storeId=...) → items[]（orderId/sku/title/saleStatus/orderDate/quantity/gross/net）
口径：actionable = 未发运且未取消（已发运/已取消/已收货都不算要动作）；daysToDue < 0 = 已逾期。
"""
import argparse
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERMES = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "hermes")
PLUGIN = os.path.join(HERMES, "plugins", "takealot-erp")


# ── 布局自适应：v2（插件两半）/ v3（常驻服务端）──────────────────────────────
# v2：插件自带 plugin_api，直接 import（历史形态；客户机 box 就是这种）。
# v3：**不 import 内部模块**，改走常驻服务端的本机 HTTP API（与工作台界面同一条读写路径，
#     需 X-ERP-Token，只监听 127.0.0.1）。数字一样来自接口：零模拟、拿不到就照实报。
def _erp_home_v3():
    """v3 家目录：跟服务端 app.py 的 default_erp_home() 保持同一套规则。

    Windows 默认是 `%LOCALAPPDATA%\TakealotERP`（不是 ~/.takealot-erp）—— 漏了它，
    在 Windows 上就会「找不到 v3 服务端」而误报没装（真机踩过）。
    """
    win_default = os.path.join(os.environ.get("LOCALAPPDATA") or
                               os.path.join(os.path.expanduser("~"), "AppData", "Local"), "TakealotERP")
    for cand in (os.environ.get("ERP_HOME"), os.environ.get("TAKEALOT_ERP_HOME"),
                 win_default,
                 os.path.join(os.path.expanduser("~"), ".takealot-erp")):
        if cand and os.path.exists(os.path.join(cand, "runtime.json")):
            return cand
    return None


class _V3Api:
    """把脚本用到的调用映射到 v3 本机路由（只读脚本用）。"""

    def __init__(self, home):
        import json as _json
        self.home = home
        with open(os.path.join(home, "runtime.json"), encoding="utf-8") as fh:
            info = _json.load(fh)
        self.port = int(info.get("port") or 0)
        self.token = info.get("token") or ""

    @property
    def _state_dir(self):
        return os.path.join(self.home, "state")

    def _api_request(self, method, path, query=None, body=None, store_id=None, **_kw):
        import json as _json
        import urllib.parse
        import urllib.request
        q = dict(query or {})
        if store_id:
            q.setdefault("storeId", store_id)
        url = "http://127.0.0.1:{0}/api/plugins/takealot-erp{1}".format(self.port, path)
        if q:
            url += "?" + urllib.parse.urlencode({k: v for k, v in q.items() if v not in (None, "")})
        data = _json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, method=method.upper(),
                                     headers={"X-ERP-Token": self.token, "Content-Type": "application/json"})
        # 本机回环必须绕系统代理（Clash 之类会把 127.0.0.1 拦成 502）
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        try:
            with opener.open(req, timeout=180) as resp:
                return _json.loads(resp.read().decode("utf-8") or "{}"), resp.status
        except urllib.error.HTTPError as exc:
            try:
                return _json.loads(exc.read().decode("utf-8") or "{}"), exc.code
            except Exception:
                return {"ok": False, "error": "HTTP {0}".format(exc.code)}, exc.code
        except Exception as exc:
            return {"ok": False, "error": "{0}: {1}".format(type(exc).__name__, exc)}, 0

    def _settings(self):
        d, _ = self._api_request("GET", "/settings")
        return d or {}

    def _active_store(self):
        sid = self._settings().get("activeStoreId") or ""
        return {"id": sid} if sid else None

    def _store_row(self, store_id):
        for s in self._settings().get("stores") or []:
            if str(s.get("id")) == str(store_id):
                return s
        return None

    def fulfilment(self, storeId="", limit=200, **_kw):
        return self._api_request("GET", "/fulfilment", {"limit": limit}, None, storeId or None)[0]

    def orders_live(self, storeId="", limit=200, **_kw):
        return self._api_request("GET", "/orders/live", {"limit": limit}, None, storeId or None)[0]

    def repricing_candidates(self, storeId="", probe=0):
        return self._api_request("GET", "/repricing/candidates", {"probe": probe}, None, storeId or None)[0]


def _v3_alive(home) -> bool:
    """v3 服务端在不在跑（读 runtime.json 的端口探一下 TCP）。"""
    import json as _json
    import socket as _socket
    try:
        with open(os.path.join(home, "runtime.json"), encoding="utf-8") as fh:
            port = int((_json.load(fh) or {}).get("port") or 0)
        if not port:
            return False
        with _socket.socket() as s:
            s.settimeout(1.5)
            return s.connect_ex(("127.0.0.1", port)) == 0
    except Exception:
        return False


def _load_api():
    """**v3 优先**：服务端活着就用它（跟工作台界面同一条取数路径）。

    机器上可能同时留着 v2 插件（老客户升级现场就是这样）：谁优先不能靠"哪个目录在"，
    得看**哪个真能用**。真机踩过：v2 目录还在、但它的桥早停了 → 脚本挑到 v2 一路
    connection refused，而新的 v3 服务端明明在跑。所以顺序 = v3 在跑 → v3；否则 v2；否则 ABORT。
    """
    home = _erp_home_v3()
    if home and _v3_alive(home):
        return _V3Api(home)
    for cand in (PLUGIN, os.path.join(PLUGIN, "dashboard")):
        if os.path.exists(os.path.join(cand, "plugin_api.py")):
            sys.path.insert(0, cand)
            import plugin_api as A  # noqa: F401
            return A
    if home:
        return _V3Api(home)          # v3 装了但没在跑：照旧用它，报错会说清"先起服务"
    print("ABORT: 这台机器上找不到 ERP —— v2 插件（{0}）与 v3 服务端（~/.takealot-erp/runtime.json）都没有；"
          "什么都不读、什么都不写。".format(PLUGIN))
    sys.exit(2)


A = _load_api()


def canon(status):
    """平台原始状态 → 规范标签（Delivered/Returned/...），认不出就原样返回。"""
    try:
        return A._canonical_sale_status(status)
    except Exception:
        return str(status or "")


def po_line(r):
    due = r.get("dueDate") or "无截止日"
    d = r.get("daysToDue")
    when = "已逾期 {0} 天".format(-d) if isinstance(d, int) and d < 0 else (
        "还剩 {0} 天".format(d) if isinstance(d, int) else "—")
    return "  - {0}｜{1}｜{2}｜{3}｜{4}｜{5}".format(
        r.get("po") or r.get("shipmentId") or "无PO号", r.get("typeLabel") or "—",
        due, when, r.get("region") or "未标区域", r.get("stateLabel") or "—")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", default="")
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--orders-limit", type=int, default=400)
    args = ap.parse_args()

    store = args.store or str((A._active_store() or {}).get("id") or "")
    if not store:
        print("物流巡查：没有可用的店铺作用域（未绑定店铺/未指定 --store），本轮不读数。")
        sys.exit(0)
    name = (A._store_row(store) or {}).get("name") or store

    ful = A.fulfilment(storeId=store, limit=args.orders_limit) or {}
    live = A.orders_live(storeId=store, limit=args.orders_limit) or {}

    print("物流巡查 · 店铺 {0}（{1}）".format(name, store))
    problems = []

    # ---------- 一、必须马上处理 ----------
    print("\n一、必须马上处理（送仓 PO）")
    stages = ful.get("stages") or {}
    if not ful.get("ok"):
        print("  - 送仓单读数失败：{0}（照实报，不猜）".format(ful.get("error") or "未知原因"))
        problems.append("fulfilment 读取失败")
    else:
        for branch, label in (("inbound", "入仓/补货"), ("outbound", "出库/客户订单")):
            node = stages.get(branch) or {}
            pos = node.get("pos") or []
            act = [r for r in pos if r.get("actionable")]
            overdue = [r for r in act if isinstance(r.get("daysToDue"), int) and r["daysToDue"] < 0]
            soon = [r for r in act if isinstance(r.get("daysToDue"), int) and 0 <= r["daysToDue"] <= args.days]
            nodue = [r for r in act if not isinstance(r.get("daysToDue"), int)]
            print("  [{0}] 动作项 {1} 张：逾期 {2} ｜ {3} 天内到期 {4} ｜ 无截止日 {5}".format(
                label, len(act), len(overdue), args.days, len(soon), len(nodue)))
            for r in overdue:
                print(po_line(r))
            for r in soon:
                print(po_line(r))
            if overdue:
                problems.append("{0} {1} 张 PO 已逾期".format(label, len(overdue)))
        errs = ful.get("errors") or {}
        for k, v in errs.items():
            if v:
                print("  - 读数警告 [{0}]：{1}".format(k, str(v)[:110]))
                problems.append("读数警告 {0}".format(k))
        tr = ful.get("truncated") or {}
        if any(tr.values()):
            print("  - 注意：数据被截断 {0}（可能还有更多 PO/订单没返回）".format(tr))

    # ---------- 二 / 三 / 四：订单维度 ----------
    print("\n二、已签收 / 三、用户退货 / 四、其它状态")
    if not live.get("ok"):
        print("  - 订单读数失败：{0}（照实报，不猜）".format(live.get("error") or "未知原因"))
        problems.append("orders 读取失败")
    else:
        s = live.get("summary") or {}
        by = s.get("byStatus") or {}
        # 状态计数：先用规范标签归并（byStatus 可能是原始值）
        cnt = {}
        for k, v in by.items():
            cnt[canon(k)] = cnt.get(canon(k), 0) + int(v)
        delivered = cnt.get("Delivered", 0)
        collected = cnt.get("Collected", 0)
        returned = cnt.get("Returned", 0)
        cancelled = cnt.get("Cancelled", 0)
        awaiting = cnt.get("Awaiting Shipment", 0)
        shipped = cnt.get("Shipped", 0)
        print("  单量 {0} 单 / {1} 行 ｜ 营收 R{2} ｜ 净利 R{3}（未扣采购成本）".format(
            s.get("orders"), s.get("lines"), s.get("gross"), s.get("net")))
        print("  签收 {0}（Delivered {1} + Collected {2}）｜ 在途 {3}（Shipped）｜ 待发货 {4}（Awaiting Shipment）"
              "｜ **退货 {5}** ｜ 取消 {6}".format(
                  delivered + collected, delivered, collected, shipped, awaiting, returned, cancelled))
        unknown = {k: v for k, v in cnt.items()
                   if k not in ("Delivered", "Collected", "Returned", "Cancelled",
                                "Shipped", "Awaiting Shipment")}
        if unknown:
            print("  未归类的原始状态（原样列出，不翻译）：{0}".format(unknown))

        items = live.get("items") or []
        ret = [r for r in items if canon(r.get("saleStatus")) == "Returned"]
        print("  退货明细（{0} 条）：".format(len(ret)))
        for r in ret[:15]:
            print("    - {0}｜{1}｜{2}｜R{3}｜{4}".format(
                r.get("orderId"), r.get("sku"), (r.get("title") or "")[:30],
                r.get("gross"), r.get("orderDate")))
        if not ret:
            print("    - 无（本页订单里没有 Returned）")
        if len(ret) > 15:
            print("    - …另有 {0} 条".format(len(ret) - 15))
        if returned:
            problems.append("{0} 单退货".format(returned))

    # ---------- 结论 ----------
    print("\n结论：{0}".format(
        "有 {0} 项要马上处理".format(len(problems)) if problems else "没有需要马上处理的项目"))
    if problems:
        print("PROBLEMS：")
        for p in problems:
            print("  - " + p)
    print("门店后台：https://seller.takealot.com/")
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
