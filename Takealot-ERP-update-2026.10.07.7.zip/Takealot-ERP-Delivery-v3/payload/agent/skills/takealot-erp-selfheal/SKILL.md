---
name: takealot-erp-selfheal
description: "Takealot ERP 自愈排障：工作台报错、数据全零、任务不跑、更新失败、桥/端口异常时用它——先取证、再按判据修（服务·本地桥·网络出口·店铺密钥·运行环境），修完必须复验同一判据；修不了就带证据包上报，不猜、不越红线。"
version: 1.0.0
author: Takealot ERP
license: MIT
platforms: [macos, windows, linux]
metadata:
  hermes:
    tags: [takealot, erp, selfheal, triage, troubleshooting, ops]
    category: productivity
    related_skills: [takealot-erp-operator, openclaw-erp]
---

# Takealot ERP 自愈排障

用户说"打不开了 / 订单是空的 / 报错了 / 数据不对 / 更新失败"时用本技能。
目标：**能自愈的自己修好并复验；不能自愈的把证据备齐交给厂商**——不要现场猜、不要试错式乱改。

## 〇、四条不可越的线（先记住，再往下读）

1. **不动用户数据**：`ERP_HOME/state/` 里除了 `state/ingest/failed/`（可清）和自愈日志外，一律不改不删。
   采集箱的增删只走产品自己的接口（`DELETE /api/plugins/takealot-erp/collection/{id}`），不手改 JSON。
2. **不碰密钥**：Seller Key 由**用户在界面里**绑/换。你不输入、不转抄、不打印、不写文件。
3. **不写平台**：改价/改库存/上架/跟价授权只在**工作台界面**里由用户确认后做。你没有这些工具，也不要用 API 绕过。
4. **不绕安全**：`sha256 不匹配` 一律中止上报（**绝不用 `--force` 或任何手段绕过**）；不关证书校验；
   不把 `TAKEALOT_API_PROXY` 指向来路不明的地址；不改系统代理/Hosts/防火墙。
   **修不动的就上报**——"假装修好了"比不修更糟。

## 一、取证三步（任何症状都先做这三步，再决定动手）

工具优先用 **MCP**（宿主里挂着 `takealot-erp` 就能直接调）；没有 MCP 就用下面 CLI 形式的同一件事。

| # | 干什么 | MCP | 命令行（短命令；短命令不在时才用长形式） |
|---|---|---|---|
| 1 | 服务在不在、哪个端口、哪个店 | `erp_status` | `erp.cmd status`（Win）/ `cli/erp status`（Mac·Linux） |
| 2 | 本机 13 项自检 | `erp_doctor` | `erp.cmd doctor` / `cli/erp doctor` |
| 3 | **平台连通性 15 项**（关键） | `erp_diagnostics` | 无 CLI 等价；用 MCP，或让用户看工作台「诊断」面板 |

命令入口（**下文写 `erp <子命令>` 就按这里换成对应形式**）：
- Windows：`%LOCALAPPDATA%\TakealotERP\cli\erp.cmd <子命令>`
  短命令不可用时兜底：`%LOCALAPPDATA%\TakealotERP\venv\Scripts\python.exe %LOCALAPPDATA%\TakealotERP\server\cli.py <子命令>`
- macOS：`~/.takealot-erp/cli/erp <子命令>`
  兜底：`~/.takealot-erp/venv/bin/python ~/.takealot-erp/server/cli.py <子命令>`

**判据（记住这个分工，别搞混）**：
- `doctor` 13/13 全过 = **本机**没问题（服务在跑、鉴权、密钥库、入口…）≠ 平台能用。
- 平台能不能用，只看 `erp_diagnostics` 里 **`seller` 和 `public` 两行**：
  - `seller` pass = 至少有一个店的 Seller API 通；`fail` 时每店的 `evidence` 写明了原因。
  - `public` pass = 公开商品页取得到（`transport=direct|proxy|ingest`）。
- `erp_diagnostics` 的 `summary` 里 `failed` 是权威计数；**failed=0 才算平台侧健康**。

## 二、症状 → 判据 → 自愈动作（每一条做完都要复验）

### D1 工作台打不开 / 服务没在跑
- 判据：`status` 说"没在跑"，或 `http://127.0.0.1:<port>/healthz` 连不上。
- 动作：`cli.py open --port <port>`（会起服务并开窗口，端口从 `runtime.json` 读，缺省 18791）。Windows 上也可以双击桌面「Takealot ERP 工作台」。
- 复验：`healthz` 200 + `doctor` 的"服务端在跑"PASS。

### D2 服务在跑但工具报 404 / 行为像老版本 / 端口被占
- 判据：`doctor` 的"runtime.json 与实际实例一致"FAIL，或 `status` 的 pid 与端口上真实 pid 不一致。
  （老实例占着端口 = 新版本看着装上了却没生效。）
- 动作：`cli.py stop --erp-home <ERP_HOME>` → `cli.py open --port <port>`。
  `stop` 会顺手清掉**同一个 ERP_HOME 的残留实例**并收掉本地桥，属正常行为。
- 复验：`netstat` 里端口只有一个监听者 + `doctor` 该行 PASS + 再问一次用户的原始问题是否还在。

### D3 扩展采集的数据进不了账（本地桥 18790）
- 判据：`netstat -ano | findstr :18790`（Windows）/ `lsof -nP -iTCP:18790`（macOS）没有监听者；
  或 `erp_diagnostics` 的 `bridge` 行不是 `pass`；或 `state/ingest/done/` 长时间没有新文件。
- 动作：`cli.py stop` → `cli.py open`（桥由服务托管，重启服务即自动拉起）。
  仍不起：看 `ERP_HOME/logs/bridge.out` 末尾 50 行；桥端口被占就 `ERP_BRIDGE_PORT=<别的端口>` 起来后如实告知用户。
- 复验：18790 有监听 + `bridge` 行 `pass` + **让用户做一次扩展采集，确认 `state/ingest/done/` 出现新文件**
  （端口在听 ≠ 数据真的入账）。

### D4 平台数据取不到：三种"网络出口"症状（最常见，先说清是哪一种）
| 看到的东西 | 是什么 | 处置 |
|---|---|---|
| `URLError … [WinError 10061] 由于目标计算机积极拒绝` / `[Errno 61] Connection refused` | **配了代理但代理不可达**（客户没开 VPN / 代理只绑了回环） | 让客户开启自己的出口，或把 `.env` 的 `TAKEALOT_API_PROXY` 换成**从本机可达**的地址 |
| `403` + `<!DOCTYPE html>` / `Cloudflare` / "网关页" | **直连被 Cloudflare 挡**（没走代理，且本机网络不被接受） | 同上：需要一个能访问 Takealot 的出口 |
| 一直转圈到超时（`timeout`） | 出口不通/极慢 | 同上 |

- 动作：编辑 `<ERP_HOME>/.env` 的 `TAKEALOT_API_PROXY=http://<host>:<port>`（改成客户自己的），然后 **必须
  `cli.py stop` → `cli.py open`**——`.env` 的值会被服务进程缓存，不重启不生效。
- 复验：`erp_diagnostics` 的 `seller` 与 `public` 两行都 `pass`（`public` 的 `transport` 会显示走了哪条路）。
- 客户**没有**可用出口时：如实告知"这台机器需要一条能访问 Takealot 的网络线路（VPN/代理）"，并给替代路：
  在**能打开 takealot.com 的浏览器**里用扩展采集 → 桥 → `state/ingest/`，这条不依赖服务器的网络出口。
- 不要做的事：不要为了"看起来能用"去关闭证书校验；不要改客户的系统代理/VPN 设置。

### D5 明确是鉴权/密钥问题
- 判据：`401`，或平台回 **JSON 错误体**（`{"errors":[{"title":"Unauthorized"}]}` 这类），或 `requires: Seller Key` / `未绑 Key`。
- 动作：**引导用户在界面里**重绑或更换 Key（工作台 → 店铺设置 → 绑定/测试）。
- 复验：`erp_diagnostics` 的 `key_at_rest` 仍为 `pass`（密钥是密文）+ `seller` 行变 `pass`。
- 禁止：不要替用户输入 Key、不要把 Key 写进任何文件或日志、不要打印它。

### D6 数据是 0，但不确定算不算故障
- 先看工具的 `mode` 字段，别急着修：
  - `mode=live` 且 `ok=true` = 接口真的通了，**这家店就是没数据**（新店/无单），如实回答用户即可。
  - `mode=degraded` = 取数失败后**回退到最近一次成功的列表**（界面会标"degraded"）→ 按 `error`/`hint` 归到 D4 或 D5。
  - `mode=error` = 取数失败 → 按 `hint` 归到 D4 或 D5。
- 复验：修完再看 `mode` 是否回到 `live`。

### D7 自更新失败
- 判据（看 `cli.py update --check` 的输出）：
  - `取不到更新清单` → 通道不可达（国内 raw 有时抽风/DNS 被挡；CDN 也可能滞后）。
    动作：重试一次；仍不行就换通道：`cli.py update --check --channel https://gh-proxy.com/https://raw.githubusercontent.com/liuyuhan180661-cell/takealot-erp-update/main/`
    （或用 `ERP_UPDATE_CHANNEL=<通道>` 环境变量；另一个备用通道 `https://ghfast.top/<同上路径>`）。
  - `sha256 不匹配 —— 已拒装` → **红线**：中止，不动磁盘，带证据上报（这是防投毒设计，不是 bug）。
  - `通道没有更新的版本（本地 X ≥ 通道 Y）` → 正常：本机版本不落后，不用动（不要 `--force`）。
  - 下载中断（`Remote end closed` / 超时）→ 换通道重试（新版客户端会自动在多个通道里挑能下的那个）。
- 复验：`cli.py update --check` 报「已是最新（<版本>）」，且 `install.json` 的 `build` == 通道版本。

### D8 装不上依赖 / 解释器不匹配
- 判据：安装输出里出现"本包的离线轮子支持 …，当前解释器是 …"。
- 动作：**照 `<包根>/PYTHON-MATRIX.md`** 安装对应 Python（Windows 3.12 x64）后重跑安装；不要猜版本、不要乱装包。
- 复验：重跑安装 → `RESULT 13/13 PASS`。

### D9 窗口打不开（但服务是好的）
- 动作：直接用浏览器打开 `http://127.0.0.1:<port>/`（token 由服务注入，能正常用）；`--app` 档失败不影响功能。
- 复验：页面能出工作台即可。

### D10 定时任务"没跑"或退出码非 0
- 先看 `erp_jobs`：**「调度线程在跑（N 秒前还在跳）」才是判据**；`state/jobs_status.json` 有本轮记录即为在跑。
- **退出码 1 = "有要处理的事"，不是故障**（工具会自己这么写）。只有连续失败/退出码 ≥2 才按故障处理。
- 动作（确实没跑）：`cli.py stop` → `cli.py open`（调度随服务重启），再看 `logs/`。
- 复验：`erp_jobs` 心跳恢复 + 手动跑一次只读任务看退出码语义。

### D11 磁盘/日志异常
- 动作：只清 `ERP_HOME/logs/*.out` 的历史内容与 `state/ingest/failed/*`（清前把末尾 200 行存进自愈记录）；
  **不动** `state/` 其余内容。
- 复验：`doctor` 的"数据目录可写"PASS + 服务仍能取数。

### D12 state 目录不可写
- 判据：`doctor` 的"数据目录可写"FAIL。
- 动作：查磁盘是否满、目录权限/属主是否被改；**不要搬动或重建 state**（那是用户数据）。
- 复验：写入测试通过 + `doctor` 该行 PASS。

## 三、自愈要留痕（一行一条，追加进 `ERP_HOME/logs/selfheal.log`）

格式（UTC+本地时间都要，便于和厂商对时）：

```
2026-10-07 15:20:11 [D4] 症状=WinError 10061；动作=改 .env 代理→stop+open；复验=diagnostics seller/public 均 pass；结论=已修
```

## 四、修不了怎么上报（证据包，直接粘给厂商）

```
【ERP 自愈报告】
版本/平台 : <install.json 的 build> / <windows|macos>
现象      : <用户原话> + <首次出现时间>
已做      : <动作清单，含命令原文>
证据      : 1) doctor 的 RESULT 行
            2) erp_diagnostics 的 summary 与 seller/public 两行原文
            3) logs 末尾 50 行（server.out / bridge.out）
            4) runtime.json 的 port+pid（**不要贴 token**）
结论      : <能修/不能修> + <当前状态>
```

上报时**不要**包含：Seller Key、任何令牌、卡号、客户个人信息。

## 五、常见误判（别把这些当故障去"修"）

- `doctor` 13/13 ≠ 平台能用 —— 平台看 `erp_diagnostics` 的 `seller`/`public`。
- 定时任务退出码 1 ≠ 故障（= 有要处理的事）。
- 数据全 0 ≠ 坏（先看 `mode`：`live` + `ok` = 该店真没数据）。
- `install.json` 的 `build` 与包名不一致 → 老版本遗留，正常升级一次即对齐（`.6` 起包内版本戳与通道版本强制一致）。
- 停服务后 `netstat` 里 18790/18791 必须**都空**（桥不应留孤儿）；如果只有 18791 空而 18790 还在听，说明是旧版本或手动起的桥 → 按 D3 处理。
- 装了 Hermes/Codex 才有技能与 MCP；没装不影响工作台本体（桌面图标照样用）。

## 六、做完一句话汇报用户（不要静默修完就完）

模板：**「我查到是 <原因>，已经 <做了什么>，现在 <状态>；如果还不对，请把 <这一条现象> 发我。」**
