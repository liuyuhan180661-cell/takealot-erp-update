# Takealot ERP（工作台）—— 给 Codex 等宿主的项目指令片段

> **挂载分两步，各装一半（别混、别只做一步）**：
> 1. **MCP 工具面** —— Codex：`erp mcp config --host codex --write`（写 `~/.codex/config.toml` 的
>    `[mcp_servers.takealot-erp]`）；Hermes：`erp mcp config --host hermes --write`（内部就是 `hermes mcp add`）。
>    **它只写宿主的 MCP 配置，不写本文件。**
> 2. **侧栏入口 + 技能** —— `erp entry --host hermes --write`（侧栏插件 + 用户技能）或
>    `erp entry --host codex --write`（技能符号链接进 `~/.agents/skills/`，并把本片段写进 `~/.codex/AGENTS.md`）。
>    装 `erp setup` 时若检测到 Hermes/Codex 会自动做这两步；本片段以**受管区块**
>    `<!-- takealot-erp:start/end -->` 幂等替换，重复跑/升级不会越贴越多。
> 验证 MCP 那一步：`hermes mcp test takealot-erp`（能连上并报出发现的工具数）。

## 这是什么

本机有一个常驻的 Takealot ERP 工作台（本地服务 + 界面），通过 **MCP** 暴露一组 `erp_*` 工具。
**它不是网页 SaaS**：服务只监听 127.0.0.1，数据都在本机（`ERP_HOME`，Windows 默认
`%LOCALAPPDATA%\TakealotERP`、macOS 默认 `~/.takealot-erp`）。

## 两条铁律

1. **写平台在对话内受控：预览 → 用户确认 → 回读。** V3 的工具面里有受控写工具
   （`erp_repricing_preview` / `erp_repricing_apply` / `erp_offer_write` / `erp_offer_batch_write` /
   `erp_offer_create`，具体以工具表 / `hermes mcp test` 的实际为准），**不是**"工具全是只读"。固定三步：
   ① 先用 `*_preview` 或 `dryRun=true` 拿到「现值 → 目标值 + 依据」；② 逐条念给用户，**明确同意后才写**；
   ③ 写完独立回读，报成功 / 失败 / 跳过（带原因）。售价单次变动超过 30% 会被拒 —— 取得用户同意后带
   `confirmLargeChange=true` 重调。**上架 / 下架 / 发 loadsheet / 商品主数据（标题·图片·重量·类目）
   不在对话里做** —— 用 `erp_workbench_open` 把人引到界面。
   **自动跟价（买盒守护）** 是产品化的定时写入通道：**先问用户、拿到明确同意**（范围/金额由用户定）→
   `erp repricing authorize --store <店> --min <小> --max <大>` → `erp job enable buybox-round`；
   每轮留账本、逐条平台回读、可随时 `erp repricing revoke`。没授权时不写一个价。
2. **拿不到就说拿不到。** 工具返回 `ok:false` + 真实原因时照实转述，**不要编数字**、不要用
   「大概/通常」补值。

## 工具与用法

| 用户说 | 调用 |
|---|---|
| 打开工作台 / 打开中台 / 起 ERP | `erp_workbench_open`（服务没起就起，再开窗口；回话报端口与 URL） |
| 工作台在吗 / 端口多少 | `erp_status` |
| 自检 / 哪里不通 | `erp_doctor`（13 项，失败项带真实原因） |
| 今天几单 / 净利多少 | `erp_overview`、`erp_orders` |
| 库存 / 商品 / 缺货 | `erp_products` |
| 结算 / 对账 / 平台费 | `erp_finance` |
| 采集箱 / 跟卖池 | `erp_collection` |
| 出口通不通 / Key 对不对 | `erp_diagnostics` |
| 不确定用户指什么 | `erp_route`（传原话；命中给硬指令，没命中就说没命中，**不要猜**） |

受控**写**工具（必须先预览、用户确认、写后回读，见「两条铁律」第 1 条）：
`erp_repricing_preview` / `erp_repricing_apply`（跟价）、`erp_offer_write` / `erp_offer_batch_write`
（改价/库存/备货期/RRP）、`erp_offer_create`（跟卖建 offer）。上架/下架/loadsheet/商品主数据仍只在界面做。

参数：`storeId`（可选，默认用界面里当前店铺）、`limit`（订单/商品条数）。

## 定时任务 / 更新 / 抓取（**自然语言就是入口**）

定时任务**跑在客户机自己的常驻服务里**（不依赖 Hermes、不依赖我们任何一台机器；登录自启拉起 ——
Windows 是 HKCU Run，macOS 是 LaunchAgent）。
**agent 的能力是面板的超集**：面板能做的这里都要会，面板没有的这里也要有；
界面只是给「不熟提示词」的用户的手动兜底（**自动跟价在对话里授权即可**：
问用户同意 → `erp repricing authorize …` → `erp job enable buybox-round`）。

| 用户说 | 动作 |
|---|---|
| 有什么定时任务 / 任务都在跑吗 / 上次巡检结果 | 工具 `erp_jobs`（或 `erp job list`）：排期、上次退出码与摘要、下次时间、**调度线程在不在跳（心跳）** |
| 现在就跑一次物流巡查 / 跑一下订单巡检 | 先 `erp job list` 拿 id（**不要猜 id**），再 `erp job run <id>` |
| 帮我盯价 / 抢回购物车 / 授权跟价 | **对话授权**：先用一句话把范围问清楚（「下探 R{小}~R{大}、每 {N} 小时一轮」），用户明确同意后 `erp repricing authorize --store <店铺id> --min <小> --max <大> [--interval N]`，再 `erp job enable buybox-round`。**金额与范围要用户点头，不要自己定**；没得到同意就别授权。想先给人看会动哪些：`erp job run buybox-round` 或 `repricing_round.py --plan`（免授权、不写价） |
| 停止跟价 / 撤回授权 | `erp repricing revoke` + `erp job disable buybox-round`。**已调出去的价格不会自动变回来**（要还原得手工改价）—— 说清楚 |
| 关掉巡检任务 / 开关别的任务 | `erp job disable\|enable <id>`。写价任务（buybox-round）**要先有跟价授权**，否则会被拒并提示上面那条路 —— 绝不偷偷开 |
| 巡查频率 / 抢回速度要多快 | `erp job set buybox-round --interval <分钟> --args \"--stale-hours 4 --refresh-held <N>\"`。**默认 refresh-held 40**（全店约 10 小时覆盖），要更快就调大（200 ≈ 2 小时）；**不要写死**，按用户说的调 |
| 检查更新 / 升级到最新版 | `erp update --check` 先看；有新版再 `erp update`（会校验 sha256，校验不过拒装；升级会重启服务，**先告知用户**） |
| 启动爬虫 / 定时抓取 / 刷新目录 | `erp job run crawl-pull`（只读：刷公开页/目录缓存，不动平台数据） |
| PO 单跟踪 / 货什么时候到仓 | `erp job run po-tracking`（只读：逾期 / 临期，daysToDue<0=逾期） |

装完即有的任务：`logistics-patrol`(08:30/15:30) · `buybox-report`(09:00) · `order-patrol`(08:00) ·
`po-tracking`(09:30) · `crawl-pull`(每 6 小时) · `buybox-round`(每 2 小时，**默认停用，需对话授权**)。
每轮都写证据文件 `ERP_HOME/logs/jobs/<id>/<时间>.md`；**「没有消息」只能等于「跑了没事」**，不等于「没跑成」。
退出码语义：`0`=无异常、**`1`=有要处理的事（不是故障）**、`>=2`=真失败。

## 命令行等价物（没有 MCP 时）

```bash
erp open            # 起服务 + 开窗口
erp open --no-window
erp status          # 退出码 0=在跑、3=没跑
erp doctor          # 13 项自检
erp route "把工作台打开"
erp job list                  # 定时任务：排期/上次结果/下次/心跳
erp job run logistics-patrol  # 手动跑一轮（退出码 0=没事 1=有要处理的事）
erp job enable|disable <id>   # 开关（写价任务 buybox-round 要先有跟价授权，否则被拒）
erp update --check            # 看有没有新版本
erp update                    # 升级（sha256 校验不过拒装；会重启服务）
erp stop
```

## 排障

1. 先 `erp doctor`，修它报 FAIL 的那一项
2. 服务没起：`erp open --no-window`，再看 `ERP_HOME/logs/server.out` 尾部
3. `ok:true` 但没数据 = 真的没数据（没绑店铺/没订单），不是坏了
