@echo off
REM Takealot ERP local bridge - start script (ASCII only on purpose)
REM Serves the Chrome/Edge extension on http://127.0.0.1:18790
REM ERP_HOME layout (v3): venv + state live under %LOCALAPPDATA%\TakealotERP.
setlocal
set HERE=%~dp0
if "%ERP_HOME%"=="" set ERP_HOME=%LOCALAPPDATA%\TakealotERP
set VENV=%ERP_HOME%\venv\Scripts\python.exe
echo Starting Takealot ERP bridge on port 18790 ...
echo State dir: %ERP_HOME%\state
if exist "%VENV%" (
  "%VENV%" "%HERE%erp_bridge.py" --port 18790
) else (
  python "%HERE%erp_bridge.py" --port 18790
)
echo.
echo Bridge stopped. If it exited immediately, check that port 18790 is free:
echo   netstat -ano ^| findstr :18790
pause
