#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""定时抓取 / 启动爬虫（只读，不改平台数据）—— 把"跟价能算得出来"所需的数据抓齐。

为什么不是只刷目录：跟价要算目标价，必须知道**竞品最低价**；而竞品是**按商品（TSIN）抓**的。
所以这个任务要：
  ① 刷目录缓存（公开页/类目/属性）；
  ② 对店铺在售商品**逐个 TSIN 抓竞品**（限流：每轮最多 --limit 个，默认 40；优先抓"还没有竞品价"的）；
  ③ 抓完回头数一遍：`/repricing/candidates` 里**有多少条现在有竞品价了**
     —— 这个数字就是"跟价从无从下手变成能动手"的证据。

用法：  <ERP_HOME 的 venv python> crawl_pull.py [--store <id>] [--limit N | 0=只刷目录]
        <ERP_HOME 的 venv python> crawl_pull.py --target <PLID|TSIN|url>     # 只抓一个
退出码：0 = 全部成功；1 = 有失败项（数字照实报）；>=2 = 起不来/接口报错。
"""
from __future__ import annotations

import argparse
import datetime as dt
import sys
import time

import _erpclient as C


def home_dir(cli) -> str:
    return getattr(cli, "home", "") or ""


def _seen_file(home: str) -> str:
    import os as _os
    d = _os.path.join(home, "state")
    _os.makedirs(d, exist_ok=True)
    return _os.path.join(d, "competitor_seen.json")


def _load_seen(home: str) -> dict:
    import json as _json
    import os as _os
    if not home:
        return {}
    p = _seen_file(home)
    try:
        with open(p, encoding="utf-8") as fh:
            return _json.load(fh) or {}
    except Exception:
        return {}


def _save_seen(home: str, data: dict) -> None:
    import json as _json
    if not home:
        return
    try:
        with open(_seen_file(home), "w", encoding="utf-8") as fh:
            _json.dump(data, fh, ensure_ascii=False)
    except Exception:
        pass


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", default="")
    ap.add_argument("--target", default="")
    ap.add_argument("--limit", type=int, default=40, help="本轮最多抓几个 TSIN（0 = 只刷目录）")
    ap.add_argument("--sleep", type=float, default=0.8, help="每个之间间隔秒（别把对方打疼）")
    ap.add_argument("--force", action="store_true",
                    help="强制重抓（忽略爬虫 5 天缓存）。**默认不强制**：定时跑要复用缓存，别每轮重抓一遍")
    ap.add_argument("--recheck-days", type=float, default=3.0,
                    help="上次抓过但页面上没有竞品的 SKU，多少天内不再重复抓（默认 3 天）")
    args = ap.parse_args()

    try:
        cli = C.Client()
    except Exception as exc:
        C.die("读不到本机服务：{0}".format(exc))
    store = args.store or cli.active_store()

    print("定时抓取 · {0}{1}".format(dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
                                 "｜店铺 " + store if store else "｜全部店铺"))
    problems = []

    if args.target:
        res = cli.call("POST", "/crawler/pull", body={"target": args.target, "force": bool(args.force)}) or {}
        if res.get("ok") is False:
            C.die("抓 {0} 失败：{1}".format(args.target, str(res.get("error") or res)[:120]), 2)
        print("单目标抓取 {0}：完成".format(args.target))
        return 0

    # ① 目录缓存
    res = cli.call("POST", "/catalog/refresh", body={"limit": max(args.limit * 4, 200)}) or {}
    if res.get("ok") is False:
        problems.append("目录刷新失败：{0}".format(str(res.get("error") or res)[:110]))
        print("目录缓存刷新：失败 —— {0}".format(str(res.get("error") or res)[:110]))
    else:
        n = res.get("count") or res.get("total") or res.get("updated")
        print("目录缓存刷新：完成{0}".format("（{0} 条）".format(n) if n is not None else ""))

    # ② 逐 TSIN 抓竞品
    tracked = failed = 0
    if args.limit > 0:
        prods = cli.call("GET", "/products", query={"limit": 500}, store_id=store) or {}
        rows = prods.get("items") or []
        by_sku = {str(r.get("sku")): r for r in rows}
        targets = [str(r.get("tsin")) for r in rows if str(r.get("tsin") or "").startswith("TSIN")]
        cand = cli.call("GET", "/repricing/candidates", store_id=store) or {}
        seen = _load_seen(home_dir(cli))
        now = dt.datetime.now().timestamp()
        cooldown = max(0.0, args.recheck_days) * 86400
        missing = []
        skipped_cool = 0
        for i in (cand.get("items") or []):
            if i.get("lowestCompetitor") is not None:
                continue
            sku = str(i.get("sku"))
            rec = seen.get(sku) or {}
            # 抓过、当时页面上就是没有别的卖家（competitorCount 0 / 登记不上）→ 冷却期内别再抓，
            # 既省流量也别老拍人家页面；过了冷却再复查一次（卖家可能新进来了）。
            if rec.get("competitors") == 0 and (now - float(rec.get("at") or 0)) < cooldown:
                skipped_cool += 1
                continue
            missing.append(sku)
        if skipped_cool:
            print("  （{0} 个 SKU 上次抓过就确认没有竞品，冷却 {1:g} 天内跳过）".format(skipped_cool, args.recheck_days))
        priority = [str(by_sku[s].get("tsin")) for s in missing
                    if s in by_sku and str(by_sku[s].get("tsin") or "").startswith("TSIN")]
        pick = (priority or targets)[: args.limit]
        sku_of = {str(r.get("tsin")): str(r.get("sku")) for r in rows}
        last_err: list[str] = []
        print("竞品抓取：目标 {0} 个（在售 {1} 个，其中 {2} 个还没有竞品价）".format(
            len(pick), len(targets), len(missing)))
        for tsin in pick:
            # 两件事，顺序不能反（真机踩过：只调 /competitor/track 会 ok:false + source:none，
            # 因为它只是"登记"，**真抓取的入口是 /crawler/pull（按 PLID）**）：
            #   ① /crawler/pull  → 走出口代理抓公开页（拿竞品报价 / 评论增量）
            #   ② /competitor/track → 把这次快照登记成"在跟踪"，候选里才会有 lowestCompetitor
            plid = str((by_sku.get(sku_of.get(tsin)) or {}).get("plid") or "")
            fetch = cli.call("POST", "/crawler/pull", body={"target": plid or tsin, "force": bool(args.force)}) or {}
            got = bool(fetch.get("ok")) and bool(fetch.get("product"))
            if not got:
                failed += 1
                last_err.append("{0}: {1}".format(tsin, str(fetch.get("error") or fetch.get("mode") or "抓不到")[:70]))
                time.sleep(max(0.0, args.sleep))
                continue
            one = cli.call("POST", "/competitor/track", body={"tsin": tsin, "storeId": store}) or {}
            item = one.get("item") or {}
            comps = item.get("competitorCount")
            if comps is None:
                comps = item.get("offersCount")
            if one.get("ok") is False:
                failed += 1
                last_err.append("{0}: 抓到了但没登记上（页面上没可比报价/竞品）".format(tsin))
                seen[sku_of.get(tsin, tsin)] = {"at": dt.datetime.now().timestamp(), "competitors": 0}
            else:
                tracked += 1
                seen[sku_of.get(tsin, tsin)] = {"at": dt.datetime.now().timestamp(), "competitors": comps}
            time.sleep(max(0.0, args.sleep))
        _save_seen(home_dir(cli), seen)
        print("竞品抓取：成功 {0} 个 · 失败 {1} 个".format(tracked, failed))
        if failed:
            problems.append("竞品抓取有 {0} 个没成功：{1}".format(
                failed, "；".join(last_err[:3]) if last_err else "（原因未报）"))

    # ③ 回看：现在有多少条能跟价了（"闭环有没有接上"的证据）
    after = cli.call("GET", "/repricing/candidates", store_id=store) or {}
    items = after.get("items") or []
    withc = [i for i in items if i.get("lowestCompetitor") is not None]
    actionable = [i for i in withc if i.get("listed") and not i.get("buyboxHeld")]
    print("")
    print("SUMMARY: 候选 {0} 条 · 有竞品价 {1} 条 · 其中该动作（丢盒/未占优）{2} 条".format(
        len(items), len(withc), len(actionable)))
    if not withc:
        print("  ⚠️ 一条竞品价都没有：跟价算不出目标价（不是脚本坏了，是竞品数据没抓到）")

    if problems:
        print("PROBLEMS:")
        for p in problems:
            print("  - " + p)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
