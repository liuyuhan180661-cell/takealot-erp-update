#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Takealot ERP 的 MCP server（stdio）—— 通用 agent 接口层（形态 v3 · P3）。

一份实现，给所有宿主用：Hermes / Codex / Cursor / 任何支持 MCP 的 agent。
    python3 server/mcp_server.py            # stdio，宿主自己 spawn
    erp mcp config --host codex             # 打印该宿主该写什么配置

设计纪律（改之前先读）：

* **只读取数 + 一个启动入口 + 对话内受控写入**。V3 起，写平台的工具**在对话里执行**，
  但必须**受控**：先 preview / dryRun 拿到「现值 → 目标值 + 依据」→ 念给用户并取得明确确认 →
  写后独立回读（报成功 / 失败 / 被跳过（带原因）/ 需人工复核）。默认面实际注册的写工具共 4 个：
  `erp_repricing_apply`（按本店规则批量跟价）、`erp_offer_write`（改单个 offer：售价 / RRP /
  自营仓库存 / 备货期）、`erp_offer_batch_write`（≤50 行批量改）、`erp_offer_create`（跟卖建 offer）；
  配套只读预览是 `erp_repricing_preview`。它们的共同前置条件 = 上面那三步，且售价单次变动超 30%
  会被拒绝（要用户同意后带 `confirmLargeChange=true` 再调）。
  **上架 / 下架 / 发 loadsheet / 商品主数据（标题·图片·重量·类目）仍然只在工作台界面里做**
  —— 这是产品红线，不是技术限制。
* **取数走本机服务端**（`runtime.json` 里的端口 + token），服务没起就**静默起一个**（不开窗口）：
  用户问一句"今天几单"不该先被要求去点图标。
* **零模拟数据**：核心层返回 `ok:false` + 真实原因时，原样透出去，不编数字。
* 不实现协议里用不到的部分（resources / prompts / sampling），但被问到要老实回答空列表，
  不认识的方法回 -32601，绝不假装成功。
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


def force_utf8_stdio() -> None:
    """stdio 上跑的是 MCP 协议（JSON-RPC），**必须** UTF-8。

    Windows 中文版的 locale 是 cp936：不显式改，宿主读到的 JSON 会带编码错误
    （或我们自己 print 中文时直接 UnicodeEncodeError）。
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass


force_utf8_stdio()


def _bootstrap_ca() -> None:
    """把包内的 CA 信任库钉成进程级 ``SSL_CERT_FILE``（v3 自建 venv 默认没有信任库）。

    独立服务端（本进程 spawn 的 serve / cli 子进程）跑在包内自建 venv 里；macOS 的
    Homebrew Python ``cafile`` 是 None，而**裸 urlopen 的默认 context 只认它** →
    抓取 / AI 文案 / 自更新全在 TLS 握手失败。只 setdefault，客户显式设的
    SSL_CERT_FILE / TAKEALOT_CA_BUNDLE 优先。
    """
    try:
        import certifi

        ca = certifi.where()
    except Exception:
        return
    if os.path.isfile(ca):
        os.environ.setdefault("SSL_CERT_FILE", ca)
        os.environ.setdefault("REQUESTS_CA_BUNDLE", ca)


_bootstrap_ca()

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import app as srv  # noqa: E402  同目录的服务端模块
import cli as erp_cli  # noqa: E402  复用「启动/自检/路由」那唯一一份实现

SERVER_NAME = "takealot-erp"


def audit(event: str, **fields) -> None:
    """把「哪个宿主 spawn 了我们、握手说了什么、调了哪些工具」记到 ERP_HOME/logs/mcp-sessions.log。

    为什么要这个：能证明**宿主真的连上了**（不靠模型、不靠自述），也是产品要的审计面
    （自然语言→动作的链路必须可回查）。日志写不进去不该影响服务，所以全程吞异常。
    """
    try:
        home = _home()
        home.logs.mkdir(parents=True, exist_ok=True)
        rec = {"at": time.strftime("%Y-%m-%dT%H:%M:%S"), "pid": os.getpid(), "ppid": os.getppid(),
               "argv": sys.argv[1:], "event": event}
        rec.update(fields)
        with open(home.logs / "mcp-sessions.log", "a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass
SERVER_VERSION = getattr(srv, "VERSION", "3.0.0")
PROTOCOL_FALLBACK = "2024-11-05"

READ_ONLY_HINT = {"readOnlyHint": True}


# ---------------------------------------------------------------------------
# 与服务端对话（没起就静默起）
# ---------------------------------------------------------------------------

def _home() -> "srv.ErpHome":
    return srv.ErpHome(srv.default_erp_home())


def ensure_running(home=None) -> dict:
    """拿到在跑的实例；没起就起一个（不开窗口）。返回实例信息。"""
    home = home or _home()
    info = erp_cli.running(home)
    if info.get("running"):
        return info
    port = erp_cli.srv.pick_port(erp_cli.srv.DEFAULT_PORT)
    erp_cli.spawn_server(home, port)
    health = erp_cli.wait_health(port)
    if not health:
        raise RuntimeError("服务端起不来（{0} 秒内没有 /healthz）：看 {1}".format(40, home.logs / "server.out"))
    return {**home.read_runtime(), **health, "running": True}


def api(path: str, home=None, query: str = "") -> dict:
    """带 token 打核心 API。失败时把**真实原因**交给调用方（不吞、不编）。"""
    home = home or _home()
    info = ensure_running(home)
    rt = home.read_runtime()
    url = "http://127.0.0.1:{0}{1}{2}{3}".format(info.get("port"), srv.API_PREFIX, path, query)
    req = urllib.request.Request(url)
    req.add_header("X-ERP-Token", str(rt.get("token") or ""))
    try:
        # 回环不走系统代理（客户机一挂代理，走代理的 127.0.0.1 会被拦成 502）
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=90) as resp:
            return json.loads(resp.read().decode("utf-8") or "null")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")[:400]
        raise RuntimeError("核心 API {0} 返回 HTTP {1}：{2}".format(path, exc.code, body))
    except Exception as exc:
        raise RuntimeError("核心 API {0} 调用失败：{1}".format(path, exc))


def api_post(path: str, body: dict, home=None, timeout: int = 180) -> dict:
    """带 token 打核心 API（POST；写路径专用）。失败时把**真实原因**抛给调用方。"""
    home = home or _home()
    info = ensure_running(home)
    rt = home.read_runtime()
    url = "http://127.0.0.1:{0}{1}{2}".format(info.get("port"), srv.API_PREFIX, path)
    data = json.dumps(body or {}).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("X-ERP-Token", str(rt.get("token") or ""))
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8") or "null")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:400]
        raise RuntimeError("核心 API {0} 返回 HTTP {1}：{2}".format(path, exc.code, detail))
    except Exception as exc:
        raise RuntimeError("核心 API {0} 调用失败：{1}".format(path, exc))


# ---------------------------------------------------------------------------
# 对话写入的硬护栏（不可配置）
# ---------------------------------------------------------------------------
# 为什么要有：界面路径里用户能逐行看到明细；对话路径看不到细节，所以这里的边界必须更紧。
# 三条都**不开放配置**（本产品红线：智能跟价的参数只在本产品模板里，公开版=手工跟价）。
# 改动这里必须同步：workbuddy/toolmap.json + SKILL.md 的「高风险操作确认规则」。
REPRICE_MAX_DELTA_PCT = 30.0         # 单条调价幅度上限（%）：超过 = 疑似对手价异常 → 跳过那一条
REPRICE_READBACK_TOLERANCE = 0.01    # 回读价与目标价的容差（ZAR）：超出就报「需人工复核」

WRITE_HINT = {"readOnlyHint": False, "destructiveHint": True, "idempotentHint": False}


def _num_or_none(value):
    try:
        if value in (None, ""):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _reprice_review(item: dict) -> dict:
    """单条写前复核。返回给人看的结论：现价 / 目标价 / 幅度 / 能不能写 / 不能写的原因。"""
    cur = _num_or_none(item.get("currentPrice"))
    tgt = _num_or_none(item.get("targetPrice"))
    action = str(item.get("action") or "")
    why = None
    if cur is None or cur <= 0:
        why = "平台没给到现价（/offers 没有这条）→ 没有基准，不写"
    elif tgt is None or tgt <= 0:
        why = "规则算不出目标价（被挡了或没有对手价）→ 不写"
    elif action in ("floor_guard", "ceiling_guard", "hold"):
        why = "被规则挡住：{0}".format(item.get("reason") or action)
    else:
        pct = (tgt - cur) / cur * 100.0
        if abs(pct) > REPRICE_MAX_DELTA_PCT:
            why = ("单条幅度 {0:.1f}% 超过 {1:.0f}% 上限（疑似对手价异常或数据错误）"
                   "→ 不写；请到工作台界面逐行核对后再决定".format(abs(pct), REPRICE_MAX_DELTA_PCT))
    return {
        "sku": str(item.get("sku") or ""),
        "title": item.get("title") or "",
        "current": cur,
        "target": tgt,
        "deltaPct": (round((tgt - cur) / cur * 100.0, 2) if (cur and tgt) else None),
        "lowestCompetitor": item.get("lowestCompetitor"),
        "floorPrice": item.get("floorPrice"),
        "ceilingPrice": item.get("ceilingPrice"),
        "action": action,
        "basis": item.get("reason") or "",
        "writable": why is None,
        "why": why,
    }


def _resolve_store(store_id: str, home=None):
    """把「店铺」落到确定的一家：显式给了就用它；只给 active/空则读界面当前选中的店。

    写价绝不能落到不确定的店（后端也这么卡），所以这里读不到就明确报错。
    """
    sid = str(store_id or "").strip()
    if sid and sid not in ("active", "*", "all"):
        return sid, ""
    try:
        st = api("/settings", home)
    except Exception as exc:  # noqa: BLE001
        return "", "读不到店铺设置：{0}".format(exc)
    aid = str((st or {}).get("activeStoreId") or "").strip() if isinstance(st, dict) else ""
    if aid:
        return aid, "（没指明店铺，用界面当前选中的店：{0}）".format(aid)
    return "", "没有指定店铺，也读不到界面当前选中的店 → 写入不能落到不确定的店"


def repricing_preview(store_id: str, skus: list, home=None) -> dict:
    """给定 SKU 的跟价预览 + 写前复核结论。**只读，不写平台。**"""
    if not skus:
        return {"ok": False, "error": "必须点名要动哪些 SKU（不支持空列表=全店）"}
    sid, note = _resolve_store(store_id, home)
    if not sid:
        return {"ok": False, "error": note}
    cand = api("/repricing/candidates", home, "?storeId=" + urllib.parse.quote(sid))
    if not isinstance(cand, dict) or not cand.get("ok"):
        return {"ok": False, "error": str((cand or {}).get("reason") or "读不到跟价候选（服务返回异常）")}
    items = {str(i.get("sku")): i for i in (cand.get("items") or [])}
    rows, missing = [], []
    for sku in skus:
        it = items.get(str(sku))
        if it is None:
            missing.append({"sku": str(sku), "writable": False,
                            "why": "不在本店「可售且有价」的目录里（已下架 / 缺价格 / 目录没刷新）"})
            continue
        rows.append(_reprice_review(it))
    return {"ok": True, "storeId": cand.get("storeId"), "storeName": cand.get("storeName"),
            "storeNote": note, "autoEnabled": cand.get("autoEnabled"), "basis": cand.get("basis"),
            "rows": rows + missing,
            "writable": sum(1 for r in rows if r.get("writable"))}


# ---------------------------------------------------------------------------
# 写入面（与后端能力一一对应，不凭空造）
# ---------------------------------------------------------------------------
# 本店 offer 能写的字段 = 后端 plugin_api.OFFER_WRITE_RULES（改后端要同步这里）：
#   selling_price / rrp / seller_stock / minimum_leadtime_days
# **上架/下架写不了**：平台未给该账号开通 API 上下架（disable_listing_enabled=false），
# 只能走 Seller Portal / Loadsheet 人工 QC —— 所以对外描述里也不许宣称能上下架。
OFFER_WRITABLE = {
    "selling_price": "售价(ZAR)",
    "rrp": "建议零售价(ZAR)",
    "seller_stock": "卖家自营仓库存(件)",
    "minimum_leadtime_days": "备货期(天)",
}
LARGE_CHANGE_PCT = 30.0   # 售价变动超过它 → 必须先念给用户，带 confirmLargeChange 才放行
BATCH_MAX_ROWS = 50       # 与后端 BATCH_MAX_ROWS 一致


def _offer_fields(args: dict) -> dict:
    """从参数里挑出可写字段并转整数；不可写字段直接报错，绝不透传。"""
    out = {}
    for key in OFFER_WRITABLE:
        raw = args.get(key)
        if raw in (None, ""):
            continue
        try:
            out[key] = int(raw)
        except (TypeError, ValueError):
            raise ValueError("{0}（{1}）必须是整数".format(OFFER_WRITABLE[key], key))
    return out


def _large_change(changed, sku: str = "") -> list:
    """从写前复核结果里挑出「售价变动幅度过大」的项（坏数据 / 手滑的兜底）。

    兼容两种形状：单条写入的 changed 是 [{field, from, to}]；批量的 changed 是 {字段: {...}}。
    """
    hits = []

    def _check(frm, to):
        try:
            frm, to = float(frm), float(to)
        except (TypeError, ValueError):
            return
        if frm <= 0:
            return
        pct = (to - frm) / frm * 100.0
        if abs(pct) > LARGE_CHANGE_PCT:
            hits.append({"sku": sku, "from": frm, "to": to, "deltaPct": round(pct, 1)})

    if isinstance(changed, list):
        for row in changed:
            if isinstance(row, dict) and row.get("field") == "selling_price":
                _check(row.get("from"), row.get("to"))
    elif isinstance(changed, dict):
        sp = changed.get("selling_price")
        if isinstance(sp, dict):
            _check(sp.get("from"), sp.get("to"))
        elif sp is not None:
            _check(changed.get("selling_priceFrom"), sp)
    return hits


def _confirm_hint(big: list) -> str:
    lines = "、".join("SKU {0} R{1:,.2f}→R{2:,.2f}（{3:+.1f}%）".format(
        h.get("sku") or "?", h.get("from", 0), h.get("to", 0), h.get("deltaPct", 0)) for h in big)
    return ("售价变动超过 {0:.0f}%：{1}。先把这条幅度念给用户，拿到明确同意后，"
            "再带 confirmLargeChange=true 调一次。".format(LARGE_CHANGE_PCT, lines))


def offer_write(store_id: str, sku: str, fields: dict, *, dry_run: bool = False,
                confirm_large: bool = False, home=None) -> dict:
    """改一条 offer 的可写字段（售价 / RRP / 自营仓库存 / 备货期）。

    先走后端自己的 dryRun 拿「现价 → 目标价」，幅度过大又没有 confirmLargeChange 就**不写**。
    """
    sid, note = _resolve_store(store_id, home)
    if not sid:
        return {"ok": False, "error": note}
    if not sku:
        return {"ok": False, "error": "必须指明要改哪个 SKU"}
    if not fields:
        return {"ok": False, "error": "没有可写字段。可写：售价 / 建议零售价 / 自营仓库存 / 备货期"
                                      "（上下架、托管仓库存、重量标题都不可写——平台未开通或只能走 Loadsheet）"}
    body = dict(fields, storeId=sid)
    pre = api_post("/products/" + urllib.parse.quote(sku), dict(body, dryRun=True), home)
    if not isinstance(pre, dict) or pre.get("error") or pre.get("errors"):
        return {"ok": False, "stage": "写前校验", "storeNote": note, "sku": sku,
                "error": pre.get("error") or (pre.get("errors") or [""])[0] if isinstance(pre, dict) else "服务返回异常",
                "hint": (pre or {}).get("hint"), "writableKeys": list(OFFER_WRITABLE)}
    changed = pre.get("changed") or []
    big = _large_change(changed, sku)
    preview = {"sku": sku, "current": pre.get("current"), "changed": changed, "request": pre.get("request")}
    if big and not confirm_large:
        return {"ok": False, "needsConfirm": True, "largeChange": big, "preview": preview,
                "why": _confirm_hint(big), "storeNote": note}
    if dry_run:
        return {"ok": True, "dryRun": True, "preview": preview, "largeChange": big, "storeNote": note}
    res = api_post("/products/" + urllib.parse.quote(sku), dict(body, dryRun=False), home)
    if not isinstance(res, dict):
        return {"ok": False, "error": "写接口返回异常，未确认写入结果", "preview": preview}
    return {"ok": bool(res.get("ok")), "preview": preview, "changed": res.get("changed") or changed,
            "applied": res.get("applied"), "offer": res.get("offer"), "apiStatus": res.get("apiStatus"),
            "error": res.get("error"), "hint": res.get("hint"), "storeNote": note,
            "audit": "后端已落 state/offer_writes.json 与 state/price_log.json（可回查）"}


def offer_batch_write(store_id: str, rows: list, *, dry_run: bool = False,
                      confirm_large: bool = False, home=None) -> dict:
    """批量改价/改库存（每行一个 SKU，≤{0} 行）。后端会整批先校验、逐行串行写、逐行回读。""".format(BATCH_MAX_ROWS)
    sid, note = _resolve_store(store_id, home)
    if not sid:
        return {"ok": False, "error": note}
    norm = []
    for idx, row in enumerate(rows or [], 1):
        if not isinstance(row, dict):
            return {"ok": False, "error": "第 {0} 行不是对象".format(idx)}
        sku = str(row.get("sku") or "").strip()
        if not sku:
            return {"ok": False, "error": "第 {0} 行缺 sku".format(idx)}
        try:
            fields = _offer_fields(row)
        except ValueError as exc:
            return {"ok": False, "error": "第 {0} 行：{1}".format(idx, exc)}
        if not fields:
            return {"ok": False, "error": "第 {0} 行没有任何可写字段".format(idx)}
        norm.append(dict(fields, sku=sku))
    if not norm:
        return {"ok": False, "error": "rows 不能为空（每行：sku + 售价/库存/备货期/RRP 至少一项）"}
    if len(norm) > BATCH_MAX_ROWS:
        return {"ok": False, "error": "单次最多 {0} 行（你给了 {1} 行）：分批调用，或到工作台界面导入表格"
                                      .format(BATCH_MAX_ROWS, len(norm))}
    body = {"storeId": sid, "rows": norm}
    if not confirm_large and not dry_run:
        pre = api_post("/products/batch-write", dict(body, dryRun=True), home)
        big = []
        for row in (pre or {}).get("results") or []:
            big += _large_change(row.get("changed") or {}, str(row.get("sku") or ""))
        if big:
            return {"ok": False, "needsConfirm": True, "largeChange": big,
                    "preview": (pre or {}).get("results"), "why": _confirm_hint(big), "storeNote": note}
    res = api_post("/products/batch-write", dict(body, dryRun=dry_run), home)
    if not isinstance(res, dict):
        return {"ok": False, "error": "批量写接口返回异常，未确认写入结果"}
    return {"ok": bool(res.get("ok")), "dryRun": bool(res.get("dryRun")), "storeNote": note,
            "total": res.get("total"), "applied": res.get("appliedCount"), "failed": res.get("failedCount"),
            "blocked": res.get("blockedCount"), "limit": res.get("limit"), "maxRows": res.get("maxRows"),
            "warning": (res.get("warnings") or [None])[0], "error": res.get("error"), "hint": res.get("hint"),
            "results": res.get("results"),
            "audit": "后端已逐行落 state/offer_writes.json 与 state/price_log.json（含失败行）"}


def offer_create(store_id: str, sku: str, fields: dict, *, barcode: str = "", tsin: str = "",
                 dry_run: bool = False, home=None) -> dict:
    """跟卖：为某个商品在本店创建 offer（平台真实的 POST /offers）。"""
    sid, note = _resolve_store(store_id, home)
    if not sid:
        return {"ok": False, "error": note}
    if not sku:
        return {"ok": False, "error": "必须指明要对哪个 SKU 跟卖（没有 SKU 就无法定位商品）"}
    body = dict(fields, storeId=sid, dryRun=bool(dry_run))
    if barcode:
        body["barcode"] = str(barcode).strip()
    if tsin:
        body["tsin"] = str(tsin).strip()
    res = api_post("/products/" + urllib.parse.quote(sku) + "/offer", body, home)
    if not isinstance(res, dict):
        return {"ok": False, "error": "跟卖接口返回异常，未确认结果"}
    return {"ok": bool(res.get("ok")), "dryRun": bool(res.get("dryRun")), "storeNote": note, "sku": sku,
            "request": res.get("request"), "changed": res.get("changed"), "applied": res.get("applied"),
            "offer": res.get("offer"), "apiStatus": res.get("apiStatus"),
            "error": res.get("error"), "hint": res.get("hint"),
            "audit": "后端已落 OFFER_CREATE 审计（被拒也落）"}


def repricing_run(store_id: str, skus: list | None = None, home=None) -> dict:
    """按本店当前规则批量跟价。**不限条数**（skus 空 = 全量候选）。

    逐条独立：算不出来的、被触底/触顶挡住的、没现价的、**单条幅度超 30% 的**，
    只跳过那一条并报原因，不影响其它条（跟界面里手动跟价的行为一致）。
    一轮能真写的条数仍由店铺策略的 maxChangesPerRun 决定（后端限流保护）。
    """
    sid, note = _resolve_store(store_id, home)
    if not sid:
        return {"ok": False, "error": note}
    wanted = [str(s).strip() for s in (skus or []) if str(s).strip()]
    if len(set(wanted)) != len(wanted):
        return {"ok": False, "error": "SKU 列表里有重复项，请去重（避免重复写入）"}
    cand = api("/repricing/candidates", home, "?storeId=" + urllib.parse.quote(sid))
    if not isinstance(cand, dict) or not cand.get("ok"):
        return {"ok": False, "error": str((cand or {}).get("reason") or "读不到跟价候选（服务返回异常）")}
    items = {str(i.get("sku")): i for i in (cand.get("items") or [])}
    pool = [items[s] for s in wanted if s in items] if wanted else list(items.values())
    missing = [{"sku": s, "writable": False, "why": "不在本店「可售且有价」的目录里"} for s in wanted
               if s not in items]
    reviews = [_reprice_review(it) for it in pool]
    allowed = [r["sku"] for r in reviews if r.get("writable")]
    pre_skipped = [r for r in reviews if not r.get("writable")] + missing
    if not allowed:
        return {"ok": False, "storeId": sid, "storeNote": note,
                "error": "没有一条通过写前复核，一条都没写", "rows": reviews + missing}
    res = api_post("/repricing/run", {"storeId": sid, "skus": allowed}, home)
    if not isinstance(res, dict) or not res.get("ok"):
        return {"ok": False, "error": str((res or {}).get("reason") or "写价接口返回异常，未确认写入结果"),
                "raw": res}
    applied = {str(a.get("sku")): a for a in (res.get("applied") or [])}
    after = api("/repricing/candidates", home, "?storeId=" + urllib.parse.quote(sid))
    now = {str(i.get("sku")): _num_or_none(i.get("currentPrice"))
           for i in (after.get("items") or [])} if isinstance(after, dict) else {}
    rows = []
    for r in reviews:
        act = applied.get(r["sku"]) or {}
        readback = now.get(r["sku"])
        target = r.get("target")
        verified = readback is not None and target is not None and abs(readback - target) <= REPRICE_READBACK_TOLERANCE
        rows.append({**r, "result": act.get("result"), "resultReason": act.get("reason"),
                     "readback": readback, "verified": bool(verified),
                     "needsHumanCheck": bool(readback is not None and target is not None and not verified)})
    return {"ok": True, "storeId": sid, "storeName": cand.get("storeName"), "storeNote": note,
            "requested": len(wanted) if wanted else "全量候选",
            "wrote": len([1 for r in rows if r.get("result") == "WROTE"]),
            "skippedByRule": len([1 for r in rows if r.get("result") == "SKIPPED"]),
            "failed": len([1 for r in rows if r.get("result") == "FAILED"]),
            "skippedPreCheck": pre_skipped,
            "verified": len([1 for r in rows if r.get("verified")]),
            "cap": res.get("cap"), "crawled": res.get("crawled"),
            "rows": rows + pre_skipped,
            "audit": "每条动作（含跳过的）都在工作台「调价日志」里"}


# ---------------------------------------------------------------------------
# 形态（surface）过滤：不同宿主能看到的工具面不同
# ---------------------------------------------------------------------------
# 对外发布的宿主（WorkBuddy）看到的是「业务语义面」（含 V2 的两个跟价工具）；
# 本机 agent（Hermes / Codex / Cursor）保持全量。
#   不给 / 未知 surface      -> 全量，与历史行为完全一致
#   --surface workbuddy      -> 只暴露对外面，且把含内部措辞的描述换成业务语义
#   ERP_MCP_SURFACE=...      -> 同效（环境变量）
#
# 这是**安全边界**，不是展示层：tools/list 过滤 + tools/call 拒绝，两层都做。


def _surface_from_argv(argv: list) -> str:
    for i, a in enumerate(argv):
        if a == "--surface" and i + 1 < len(argv):
            return str(argv[i + 1]).strip()
        if str(a).startswith("--surface="):
            return str(a).split("=", 1)[1].strip()
    return ""


SURFACE = _surface_from_argv(sys.argv[1:]) or (os.environ.get("ERP_MCP_SURFACE") or "").strip()

SURFACE_ALLOW = {
    "workbuddy": frozenset({
        "erp_overview", "erp_orders", "erp_products", "erp_finance", "erp_collection",
        "erp_jobs", "erp_diagnostics", "erp_doctor", "erp_status", "erp_route",
        "erp_workbench_open",
        # 履约 / 上架草稿 / 单个商品公开页取数 / 跟卖-or-建档判定（只读；与老插件面补齐）
        "erp_fulfilment", "erp_listings", "erp_crawl_product", "erp_route_verdict",
        # V2/V3（对话内写入，走平台原生工具授权卡 + 各自的写前复核）
        "erp_repricing_preview", "erp_repricing_apply",
        "erp_offer_write", "erp_offer_batch_write", "erp_offer_create",
    }),
}

SURFACE_DESC = {
    "workbuddy": {
        "erp_route": {
            "title": "中文意图路由",
            "description":
                "把用户的中文说法映射到确定的落点（读数据 / 对话内受控写入 / 界面写入 / 运维），返回硬指令。"
                "**改价 / 改库存 / 备货期 / 建议零售价 / 跟价 / 跟卖在对话里就能做**"
                "（有对应的写工具；必须先预览、取得用户确认、写后回读）。"
                "上架 / 下架 / 发 loadsheet / 商品主数据（标题·图片·重量·类目）只能去工作台界面。"
                "**它只做「中文说法 → 落点映射」，不做跟卖 / 建档判定** —— 要判某个商品该跟卖还是建档，"
                "用 erp_route_verdict。命中不了就说没命中，不要猜。",
        },
        "erp_diagnostics": {
            "title": "环境自检明细",
            "description":
                "本机环境的逐项事实：出口通道、店铺接口可达性、密钥加密状态、数据目录（每项带实测证据）。"
                "只读。取不到数时返回 ok:false 与真实原因，照原样解释，不要编造。",
        },
        "erp_jobs": {
            "title": "定时任务",
            "description":
                "列出本机定时任务的排期、上次结果、下次执行时间与调度心跳。任务全部跑在用户自己的电脑上，"
                "不依赖任何外部机器。只读。",
        },
        "erp_crawl_product": {
            "title": "公开页商品取数（单个商品）",
            "description":
                "按链接 / PLID / TSIN 从**公开商品页**读取单个商品：商品事实、四个销量窗口（留评率→销量推算）、"
                "跟卖人数、竞品价。取数走本机服务端的**公开页取数通道**。只读、幂等：不写平台，也不自动进采集箱。"
                "取不到就返回 ok:false 与真实原因，不要编数字。",
        },
    },
}


def _apply_surface(defs: list) -> list:
    allow = SURFACE_ALLOW.get(SURFACE)
    if allow is not None:
        defs = [d for d in defs if d["name"] in allow]
    patch = SURFACE_DESC.get(SURFACE) or {}
    for d in defs:
        if d["name"] in patch:
            d.update(patch[d["name"]])
    return defs


def _assert_surface_allows(name: str) -> None:
    allow = SURFACE_ALLOW.get(SURFACE)
    if allow is not None and name not in allow:
        raise PermissionError(
            "工具 {0} 不在当前形态（{1}）的能力面内".format(name, SURFACE or "(full)")
        )


# ---------------------------------------------------------------------------
# 形态相关的路由落点：**词表不动，落点随宿主能力变**
# ---------------------------------------------------------------------------
# 背景：同一个中文词表服务两种宿主。本机宿主（Hermes / 工作台）的设计红线是「写平台只在界面做」，
# 所以 write-ui-only 意图把人引到界面；WorkBuddy 面有 erp_offer_write / erp_offer_batch_write /
# erp_repricing_apply / erp_offer_create 这些写工具（先预览 → 用户确认 → 写后回读），
# 改价 / 改库存 / 备货期 / RRP / 跟卖 在对话里就能做。如果沿用界面的说法，模型会被自己的工具指引
# 赶去界面，跟技能里的写流程自相矛盾（实测踩到过：erp_route 的描述还写着「改价会被指到工作台界面」）。
# 判据仍是**确定性子串/词表**，不交给模型猜。

#: WorkBuddy 面：对话内可写（有对应写工具）
WB_CHAT_WRITE_WORDS = (
    "改价", "调价", "降价", "涨价", "改库存", "改数量", "库存改成", "价格改成",
    "备货期", "rrp", "建议零售价", "跟卖", "批量改价", "跟价改价", "补货",
    "跟一下价", "改一下价", "改到", "重算",
)
#: 语序无关的写法（中文常说「全店的价都跟一下」「把价格改一下」，单个词表盖不住）
WB_CHAT_WRITE_GROUPS = (
    ("跟", "价"),
    ("改成", "价"),
    ("价格", "改"),
    ("价格", "重算"),
    ("售价", "改"),
    ("库存", "改"),
)
#: WorkBuddy 面：仍然只能在界面做（平台未开通 API / Listing 主数据 / 系统设置）
WB_UI_ONLY_WORDS = (
    "上架", "下架", "发布商品", "loadsheet", "标题", "图片", "主图", "重量", "类目", "描述",
)

_WB_CHAT_INSTRUCTION = (
    "在**对话里**完成（用户已在此形态授权写入）：\n"
    "・改价 / 改库存 / 备货期 / 建议零售价 → `erp_offer_write`（单个）或 `erp_offer_batch_write`（每行一个 SKU，≤50 行）\n"
    "・按规则批量跟价（不限条数） → `erp_repricing_apply`\n"
    "・跟卖（在本店为该商品建 offer） → `erp_offer_create`\n"
    "**流程固定三步**：① 先用 dryRun / 预览拿到「现值 → 目标值 + 依据」；② 逐条念给用户并问「确认吗？」，"
    "没明确同意不许写；③ 写完独立回读，报成功 / 失败 / 被跳过（带原因）/ 需人工复核。\n"
    "售价单次变动超 30% 时工具会拒 → 把幅度念给用户，同意后带 `confirmLargeChange=true` 重调。"
)
_WB_UI_ONLY_INSTRUCTION = (
    "界面动作：`erp_workbench_open` 打开工作台，并告诉用户「上架 / 下架 / 发 loadsheet / "
    "商品主数据（标题·图片·重量·类目）在工作台界面里做」。不要尝试绕过，也不要说对话能代替。"
)


def _route_for_surface(verdict: dict) -> dict:
    """把确定性词表的结果落到**当前宿主真能做到**的地方（只改落地话术，不改命中判断）。"""
    if SURFACE != "workbuddy" or not isinstance(verdict, dict):
        return verdict
    text = str(verdict.get("query") or "").lower()
    chat = [w for w in WB_CHAT_WRITE_WORDS if w in text]
    if not chat:
        chat = ["+".join(g) for g in WB_CHAT_WRITE_GROUPS if all(w in text for w in g)]
    ui = [w for w in WB_UI_ONLY_WORDS if w in text]
    verdict = dict(verdict)
    verdict["surface"] = SURFACE

    if chat and ui:
        verdict["landing"] = "split"
        verdict["instruction"] = (
            "这一句里有两类动作，**分开做**：\n· 可对话完成的（{0}）：\n{1}\n· 只能界面的（{2}）：{3}".format(
                "/".join(chat[:4]), _WB_CHAT_INSTRUCTION, "/".join(ui[:4]), _WB_UI_ONLY_INSTRUCTION))
        return verdict
    if chat:
        verdict["intent"] = "write-in-chat"
        verdict["landing"] = "chat"
        verdict["command"] = "erp_offer_write | erp_offer_batch_write | erp_repricing_apply | erp_offer_create"
        verdict["instruction"] = _WB_CHAT_INSTRUCTION
        return verdict
    if ui:
        verdict["landing"] = "ui"
        verdict["instruction"] = _WB_UI_ONLY_INSTRUCTION
        return verdict
    if not verdict.get("matched"):
        # 词表没命中：三分法里「写入只在界面」这句在 WorkBuddy 面不成立，换成真话
        verdict["landing"] = "unmatched"
        verdict["instruction"] = (
            "词表没命中：**不要猜**。按三分法处理 —— "
            "① 问数据（营收/订单/库存/财务/采集箱）→ 调对应的只读工具"
            "（erp_overview / erp_orders / erp_products / erp_finance / erp_collection / erp_diagnostics）；"
            "② 要写入 → 改价/改库存/备货期/跟价/跟卖**在对话里做，但必须先预览并取得用户确认**"
            "（写工具见 erp_repricing_apply / erp_offer_write / erp_offer_batch_write / erp_offer_create）；"
            "上架/下架/发 loadsheet/商品主数据 → 只能 `erp_workbench_open` 去界面；"
            "③ 运维（起/停/状态/自检）→ erp_status / erp_doctor / erp_diagnostics。"
        )
        return verdict
    # 命中的非写意图：也标出落点，别让模型自己去猜"这条算哪一类"
    verdict["landing"] = "intent:" + str(verdict.get("intent") or "unknown")
    return verdict


def tool_defs() -> list[dict]:
    S = dict  # 简写对齐

    def t(name, title, desc, props=None, required=None, annotations=None):
        return {
            "name": name,
            "title": title,
            "description": desc,
            "inputSchema": {"type": "object", "properties": props or {}, "required": required or [],
                            "additionalProperties": False},
            "annotations": annotations or READ_ONLY_HINT,
        }

    store = {"storeId": {"type": "string", "description": "店铺 id（可选；不给就用界面里当前选中的店）"}}
    defs = [
        t("erp_workbench_open", "打开 Takealot 工作台",
          "启动 ERP 工作台：服务没起就起，然后打开窗口（无地址栏的应用窗口，装不了就回落默认浏览器）。"
          "用户说「打开工作台 / 打开中台 / 启动 ERP」时用这个。写完把端口和 URL 报给用户。",
          {"openWindow": {"type": "boolean", "description": "是否同时打开窗口，默认 true；只想要服务在跑就传 false"}},
          annotations={"readOnlyHint": False, "openWorldHint": False}),
        t("erp_status", "工作台运行状态",
          "工作台（常驻服务端）在不在跑：端口、PID、版本、数据目录、密钥库。用户问「工作台在吗/端口多少」时用。"),
        t("erp_doctor", "工作台自检",
          "13 项端到端自检：服务在跑、鉴权、核心文件哈希、前端资产、密钥库、数据目录、桌面入口、Hermes/Codex 入口、浏览器。"
          "用户说「自检 / 哪里不通 / 体检」时用。失败项会带真实原因。"),
        t("erp_route", "中文意图路由（确定性）",
          "把中文说法映射到确定的落点（读工具 / 对话内受控写入 / 界面写入 / 运维（含**定时任务·更新·抓取**）/ 专项脚本），"
          "返回硬指令；WorkBuddy 面还会按宿主能力把落点标成 `landing: chat|ui|split`。"
          "定时任务类会给出 `erp job list|run|enable|disable`、`erp update` 这类确定性命令。"
          "改价 / 改库存 / 备货期 / 跟价 / 跟卖 → 有对应写工具，但必须先预览并取得用户确认；"
          "上架 / 下架 / 发 loadsheet / 商品主数据 → 只能去工作台界面。命中不了就说没命中，不要猜。"
          "**它只做「中文说法 → 落点映射」，不做跟卖 / 建档判定** —— 要判某个商品该跟卖还是建档，"
          "用 erp_route_verdict（两者不是一回事，别混用）。",
          {"text": {"type": "string", "description": "用户原话，例如「把工作台打开」"}}, ["text"]),
        t("erp_jobs", "定时任务（跑在客户机自己身上）",
          "列出定时任务：排期、上次跑的结果、下次什么时候、调度线程在不在跳（心跳）。"
          "任务跑在本机服务里，**不依赖任何外部机器**。用户问「有哪些定时任务 / 任务在不在跑 / 上次巡检结果」时用。"
          "要跑一轮用 erp job run <id>（读路径）。写价任务（buybox-round）默认停用，且必须先去工作台明确授权。"),
        t("erp_overview", "经营总览", "营收/净利/待发货/BuyBox/对账差异等 KPI 与风险提示。" + 说明, store),
        t("erp_orders", "订单与净利",
          "订单列表与逐单净利。" + 说明,
          {**store, "limit": {"type": "integer", "description": "最多返回几条（默认 20，最多 200）"}}),
        t("erp_products", "商品与库存",
          "店铺商品目录（含库存/价格）+ 销量推算。" + 说明,
          {**store, "limit": {"type": "integer", "description": "最多返回几条（默认 50）"}}),
        t("erp_finance", "财务与对账", "平台计费、结算与对账差异。" + 说明, store),
        t("erp_collection", "采集箱（跟卖池）",
          "采集箱里待跟卖/待上架的行与核算输入。" + 说明
          + "注意：跟卖只能改价格与库存，改完要在界面里提交。"),
        t("erp_diagnostics", "环境自检明细",
          "核心层的事实采集：出口通道、Seller API、密钥加密状态、公开爬取通道（含实测证据）。" + 说明),
        t("erp_fulfilment", "履约闭环（送仓单/出库批次）",
          "履约闭环：入仓送仓单 / 出库批次（/shipments）→ 分仓库存 → 关联订单。"
          "注意行在 stages.inbound/outbound.pos，没有平铺行列表。"
          "取数自本机服务端 /fulfilment（送仓单与订单走 Seller API，按 storeId 读）。" + 说明,
          {**store, "limit": {"type": "integer", "description": "每个阶段返回的批次行数（默认 20）"},
           "withStock": {"type": "boolean",
                         "description": "true 才拉全量 /offers 算库存（真店约 30 秒）；默认 false 用缓存"}}),
        t("erp_listings", "上架草稿箱",
          "上架草稿箱：按店铺过滤的草稿 items[] + 每条的就绪度 readiness（还缺哪些必填项）。"
          "取数自本机服务端 /listings/drafts。按店过滤后为空是**筛选结果**，不代表没有草稿"
          "（看清 filtered / unassignedIncluded / note 三个字段再说）。" + 说明, store),
        t("erp_crawl_product", "公开页商品取数（单个商品）",
          "按链接 / PLID / TSIN 从**公开商品页**读取单个商品：商品事实、四个销量窗口"
          "（留评率 → 销量推算）、跟卖人数、竞品价。取数自本机服务端 /crawler/pull（公开页只读取数）。"
          "只读、幂等：不写平台，也不自动进采集箱。" + 说明,
          {"target": {"type": "string", "description": "商品链接、PLID12345678 或 TSIN12345678（必填）"},
           "force": {"type": "boolean", "description": "true 跳过缓存重新取"},
           "cachedOnly": {"type": "boolean", "description": "true = 只读缓存，不联网"}},
          ["target"]),
        t("erp_route_verdict", "跟卖还是建档判定（只读）",
          "判定某个商品该**跟卖**还是**建档**：依据自有 Offer > 公开页确认 > 本地记录，"
          "回 route / routeReason / nextStep。取数自本机服务端 /listings/prefill（与界面同一份判定实现）。"
          "公开页取不到就明说不可判定，不猜。" + 说明,
          {"target": {"type": "string", "description": "商品链接、PLID12345678 或 TSIN12345678（必填）"},
           "force": {"type": "boolean", "description": "true 跳过缓存重新取"},
           **store},
          ["target"]),
        t("erp_repricing_preview", "跟价预览（不写平台）",
          "给定 SKU，返回现价、最低竞品价、按本店当前规则算出的目标价与依据，以及写前复核结论"
          "（能不能写、不能写的原因）。**只读**，不写平台。要动价之前先用它把差异念给用户。",
          {**store, "skus": {"type": "array", "items": {"type": "string"},
                             "description": "要点名的 SKU 列表（必填）"}}, ["skus"]),
        t("erp_repricing_apply", "执行跟价（写平台）",
          "按本店当前跟价规则批量写入平台并逐条回读校验 —— **会改真实价格**。不限条数（不点名就按全量候选）。"
          "逐条独立：算不出目标价 / 没有现价 / 被触底触顶挡 / 单条幅度超过 30% 的，只跳过那一条并报原因，"
          "不影响其它条（跟界面里手动跟价一致）。执行前必须先把「现价 → 目标价 + 依据」念给用户并得到明确同意。",
          {**store, "skus": {"type": "array", "items": {"type": "string"},
                             "description": "可选：只跟这几个 SKU；不给 = 全量候选"}},
          annotations=WRITE_HINT),
        t("erp_offer_write", "改商品（售价/库存/备货期/RRP）",
          "改**一个**商品的售价、建议零售价、卖家自营仓库存、备货期 —— **会写真实平台**。"
          "写前先算「现价 → 目标价」，售价变动超过 30% 会拒绝并要求先取得用户明确同意"
          "（再带 confirmLargeChange=true 调一次）。可先 dryRun=true 只看不写。"
          "不可写：上下架状态、Takealot 托管仓库存、重量/标题/图片（平台未开通 API 或只能走 Loadsheet 人工 QC）。",
          {**store, "sku": {"type": "string", "description": "要改的商品 SKU（必填）"},
           "selling_price": {"type": "integer", "description": "售价（整数 ZAR，最低 1）"},
           "rrp": {"type": "integer", "description": "建议零售价 RRP（整数 ZAR；清空 RRP 只能去 Seller Portal）"},
           "seller_stock": {"type": "integer", "description": "卖家自营仓可用库存（非负整数）"},
           "minimum_leadtime_days": {"type": "integer", "description": "备货期 0–30 天；-1 = FBT/现货托管"},
           "dryRun": {"type": "boolean", "description": "true = 只回显要改什么，不写平台"},
           "confirmLargeChange": {"type": "boolean",
                                  "description": "售价变动超过 30% 时必须显式传 true（先取得用户同意）"}},
          ["sku"], annotations=WRITE_HINT),
        t("erp_offer_batch_write", "批量改价/改库存",
          "一次改多个商品（每行一个 SKU，最多 50 行）：售价 / 建议零售价 / 自营仓库存 / 备货期 —— **会写真实平台**。"
          "后端整批先校验（有一行非法则一行都不发），再逐行串行写 + 逐行回读 + 逐行审计。"
          "行内售价变动超过 30% 会拒绝并要求先取得用户同意（再带 confirmLargeChange=true 调一次）。",
          {**store, "rows": {"type": "array", "description": "每行：{sku, selling_price?, rrp?, seller_stock?, minimum_leadtime_days?}",
                             "items": {"type": "object"}},
           "dryRun": {"type": "boolean", "description": "true = 只回显，不写平台"},
           "confirmLargeChange": {"type": "boolean", "description": "有行超过 30% 幅度时必须显式传 true"}},
          ["rows"], annotations=WRITE_HINT),
        t("erp_offer_create", "跟卖（新建 offer）",
          "对某个商品在**本店创建 offer**（平台真实的 POST /offers，即跟卖上架）—— **会写真实平台**。"
          "需要定位商品：给 barcode，或给 TSIN/PLID 由本机解析（解析不出来会明确说缺什么，不会猜条码）。"
          "库存写平台分配给本账号的卖家仓。可先 dryRun=true 只回显请求体。",
          {**store, "sku": {"type": "string", "description": "本店的商品 SKU（必填）"},
           "barcode": {"type": "string", "description": "商品条码（官方 schema 必填；也可以用 tsin 解析）"},
           "tsin": {"type": "string", "description": "平台 TSIN（与 barcode 二选一，用于解析条码）"},
           "selling_price": {"type": "integer", "description": "售价（整数 ZAR，最低 1）"},
           "seller_stock": {"type": "integer", "description": "卖家自营仓可用库存（非负整数）"},
           "minimum_leadtime_days": {"type": "integer", "description": "备货期 0–30 天"},
           "dryRun": {"type": "boolean", "description": "true = 只回显请求体，不写平台"}},
          ["sku"], annotations=WRITE_HINT),
    ]
    return _apply_surface(defs)


说明 = ("只读（不改平台）。写平台的动作（改价 / 改库存 / 备货期 / RRP / 跟价 / 跟卖）由对话内受控写工具执行："
       "先 preview / dryRun → 取得用户明确确认 → 写后回读（详见模块 docstring 的写工具清单）；"
       "上架 / 下架 / 发 loadsheet / 商品主数据（标题·图片·重量·类目）仍然只在工作台界面里做。"
       "取不到数时会返回 ok:false 与真实原因，照原样解释，不要编造数字。")


def _limit(args: dict, default: int, cap: int = 200) -> int:
    try:
        n = int(args.get("limit") or default)
    except (TypeError, ValueError):
        n = default
    return max(1, min(cap, n))


def _query(args: dict, limit_key: str = "", default_limit: int = 0) -> str:
    parts = []
    sid = str(args.get("storeId") or "").strip()
    if sid:
        parts.append("storeId=" + urllib.parse.quote(sid))
    if limit_key:
        parts.append("{0}={1}".format(limit_key, _limit(args, default_limit)))
    return ("?" + "&".join(parts)) if parts else ""


def _qs(pairs: dict) -> str:
    """按需拼查询串：丢掉空值 / False，布尔转小写（后端按 FastAPI 解析 query）。"""
    clean = {}
    for key, value in (pairs or {}).items():
        if value in (None, "", False):
            continue
        clean[key] = "true" if value is True else value
    return ("?" + urllib.parse.urlencode(clean)) if clean else ""


def call_tool(name: str, args: dict) -> str:
    """执行工具，返回给人/模型看的文本。异常向上抛，由协议层包成 isError。"""
    args = args or {}
    _assert_surface_allows(name)
    home = _home()

    if name == "erp_workbench_open":
        info, started = erp_cli.ensure_server(home, srv.DEFAULT_PORT)
        url = "http://127.0.0.1:{0}/".format(info.get("port"))
        win = None
        if args.get("openWindow", True) is not False:
            win = erp_cli.open_window(url, "app")
        return _text({
            "ok": True, "started": started, "url": url, "port": info.get("port"), "pid": info.get("pid"),
            "version": info.get("version"), "window": win,
            "note": "服务端已常驻；窗口只是看板，关掉窗口服务不会停。",
        })

    if name == "erp_status":
        info = erp_cli.running(home)
        rt = home.read_runtime()
        return _text({"ok": bool(info.get("running")), "running": bool(info.get("running")),
                      "port": info.get("port"), "pid": info.get("pid"), "version": info.get("version"),
                      "erpHome": str(home.root), "atRestBackend": info.get("atRestBackend"),
                      "detail": "在跑" if info.get("running") else "没在跑（任何取数工具都会自动把它起来）"})

    if name == "erp_doctor":
        rows = erp_cli.doctor_rows(home)
        fails = [{"name": n, "detail": d} for lv, n, d in rows if lv == "fail"]
        warns = [{"name": n, "detail": d} for lv, n, d in rows if lv == "warn"]
        return _text({"ok": not fails, "passed": len(rows) - len(fails) - len(warns), "total": len(rows),
                      "failed": fails, "warned": warns,
                      "checks": [{"level": lv, "name": n, "detail": d} for lv, n, d in rows]})

    if name == "erp_route":
        return _text(_route_for_surface(erp_cli.route(str(args.get("text") or ""), home)))

    if name == "erp_jobs":
        # 直接读本地状态文件（jobs.json + jobs_status.json + 心跳），**不走 HTTP**：
        # 走 HTTP 时，如果机器上还留着旧版本服务实例占着端口（老进程没有 /jobs 路由），
        # 工具会拿到 404 —— 明明任务好好的，却报"调不通"（真机踩到，客户机的 agent 当场指出来的）。
        try:
            import scheduler as _sched_mod
            data = _sched_mod.Scheduler(home.root, python=sys.executable).status()
        except Exception as _exc:
            return _text({"ok": False, "error": "{0}: {1}".format(type(_exc).__name__, _exc),
                          "erpHome": str(home.root),
                          "detail": "读不到定时任务状态（jobs.json 不在或读不懂）；erp job list 是同一个数据源"})
        if isinstance(data, dict) and data.get("jobs") is not None:
            # 只给需要的字段，别把整个状态文件倒给模型
            slim = {"ok": True, "running": data.get("running"), "runningWhy": data.get("runningWhy"),
                    "tickSeconds": data.get("tickSeconds"), "alertAfter": data.get("alertAfter"),
                    "jobs": [{k: j.get(k) for k in ("id", "name", "enabled", "kind", "scheduleText",
                                                    "nextRunAt", "lastRunAt", "lastExitCode", "lastOk",
                                                    "attention", "alert", "lastSummary", "running")}
                             for j in data.get("jobs") or []]}
            return _text(slim)
        return _text(data)

    if name == "erp_overview":
        return _text(api("/overview", home, _query(args)))
    if name == "erp_orders":
        return _text(api("/orders", home, _query(args, "limit", 20)))
    if name == "erp_products":
        return _text(api("/products", home, _query(args, "limit", 50)))
    if name == "erp_finance":
        return _text(api("/financial", home, _query(args)))
    if name == "erp_collection":
        return _text(api("/collection", home, _query(args)))
    if name == "erp_diagnostics":
        return _text(api("/diagnostics", home, _query(args)))

    if name == "erp_fulfilment":
        # 后端 /fulfilment：storeId + limit（每阶段批次行数）+ withStock（拉全量 /offers 算库存，约 30s）
        q = _query(args, "limit", 20)
        if args.get("withStock") is True:
            q += ("&" if q else "?") + "withStock=true"
        return _text(api("/fulfilment", home, q))
    if name == "erp_listings":
        return _text(api("/listings/drafts", home, _query(args)))
    if name == "erp_crawl_product":
        target = str(args.get("target") or "").strip()
        if not target:
            return _text({"ok": False, "error": "target 必填：商品链接 / PLID… / TSIN…（没有目标就先问用户，不要编）"})
        return _text(api("/crawler/pull", home, _qs(
            {"target": target, "force": args.get("force"), "cachedOnly": args.get("cachedOnly")})))
    if name == "erp_route_verdict":
        target = str(args.get("target") or "").strip()
        if not target:
            return _text({"ok": False, "error": "target 必填：商品链接 / PLID… / TSIN…"})
        data = api("/listings/prefill", home, _qs(
            {"target": target, "force": args.get("force"), "storeId": args.get("storeId")}))
        if not isinstance(data, dict):
            return _text({"ok": False, "error": "判定接口返回异常，未拿到跟卖/建档结论"})
        # 只取判定相关字段（draft 全文不进模型上下文）；与界面 /listings/prefill 是同一份判定实现
        view = {k: data.get(k) for k in ("ok", "target", "route", "exists", "routeSource",
                                         "routeReason", "nextStep", "matchKey", "sellerOffer")}
        view["sales"] = (data.get("crawl") or {}).get("sales")
        view["product"] = data.get("product")
        view["wroteAnything"] = False
        return _text(view)

    if name == "erp_repricing_preview":
        skus = [str(x).strip() for x in (args.get("skus") or []) if str(x).strip()]
        return _text(repricing_preview(str(args.get("storeId") or ""), skus, home))

    if name == "erp_repricing_apply":
        skus = [str(x).strip() for x in (args.get("skus") or []) if str(x).strip()]
        return _text(repricing_run(str(args.get("storeId") or ""), skus, home))

    if name == "erp_offer_write":
        try:
            fields = _offer_fields(args)
        except ValueError as exc:
            return _text({"ok": False, "error": str(exc), "writableKeys": list(OFFER_WRITABLE)})
        return _text(offer_write(str(args.get("storeId") or ""), str(args.get("sku") or ""), fields,
                                 dry_run=bool(args.get("dryRun")),
                                 confirm_large=bool(args.get("confirmLargeChange")), home=home))

    if name == "erp_offer_batch_write":
        return _text(offer_batch_write(str(args.get("storeId") or ""), args.get("rows") or [],
                                       dry_run=bool(args.get("dryRun")),
                                       confirm_large=bool(args.get("confirmLargeChange")), home=home))

    if name == "erp_offer_create":
        try:
            fields = _offer_fields(args)
        except ValueError as exc:
            return _text({"ok": False, "error": str(exc), "writableKeys": list(OFFER_WRITABLE)})
        return _text(offer_create(str(args.get("storeId") or ""), str(args.get("sku") or ""), fields,
                                  barcode=str(args.get("barcode") or ""), tsin=str(args.get("tsin") or ""),
                                  dry_run=bool(args.get("dryRun")), home=home))

    raise ValueError("未知工具：{0}".format(name))


#: MCP prompts —— 支持 `prompts/list` 的宿主（Claude Code 等）会把它变成斜杠命令入口。
#: 这是"没有侧栏可嵌"的宿主里最省事的入口形态：纯协议层，不依赖任何 UI 能力。
PROMPTS = [
    {
        "name": "open-workbench",
        "title": "打开 Takealot 工作台",
        "description": "启动并打开本地 ERP 工作台（独立窗口），报出端口、版本与自检结果。",
        "arguments": [],
    },
    {
        "name": "daily-brief",
        "title": "今天的经营快报",
        "description": "取经营总览 + 今日订单，汇总成一段话。取不到就如实说原因，不编数字。",
        "arguments": [{"name": "storeId", "description": "店铺 id（可选，默认界面里当前选中的店）", "required": False}],
    },
]


def prompt_messages(name: str, args: dict) -> dict:
    """把 prompt 渲染成宿主能直接喂给模型的消息。"""
    args = args or {}
    if name == "open-workbench":
        return {
            "description": "打开 Takealot ERP 工作台",
            "messages": [{"role": "user", "content": {"type": "text", "text":
                "用 takealot-erp 的 MCP 工具 erp_workbench_open（openWindow=true）把工作台打开，"
                "然后用 erp_status 报出端口与版本、用 erp_doctor 报出自检结果。不要自己拼 URL。"}}],
        }
    if name == "daily-brief":
        sid = str(args.get("storeId") or "").strip()
        extra = "，storeId 用 {0}".format(sid) if sid else "（不传 storeId，用界面里当前店铺）"
        return {
            "description": "今天的经营快报",
            "messages": [{"role": "user", "content": {"type": "text", "text":
                "用 takealot-erp 的工具 erp_overview 与 erp_orders{0} 汇总今天的营收、订单数、净利与风险提示；"
                "取不到数据就如实说明原因（例如没绑 Seller Key），**不要编数字**。".format(extra)}}],
        }
    raise ValueError("未知 prompt：{0}".format(name))


def _text(payload) -> str:
    if isinstance(payload, str):
        return payload
    return json.dumps(payload, ensure_ascii=False, indent=2, default=str)


# ---------------------------------------------------------------------------
# JSON-RPC / MCP 协议层（stdio，逐行）
# ---------------------------------------------------------------------------

def _reply(id_, result=None, error=None) -> None:
    msg = {"jsonrpc": "2.0", "id": id_}
    if error is not None:
        msg["error"] = error
    else:
        msg["result"] = result if result is not None else {}
    sys.stdout.write(json.dumps(msg, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def handle(msg: dict) -> None:
    method = msg.get("method")
    id_ = msg.get("id")
    params = msg.get("params") or {}

    if method == "initialize":
        ci = (params.get("clientInfo") or {})
        audit("initialize", client=ci.get("name"), clientVersion=ci.get("version"),
              protocolVersion=params.get("protocolVersion"))
        _reply(id_, {
            "protocolVersion": params.get("protocolVersion") or PROTOCOL_FALLBACK,
            "capabilities": {"tools": {"listChanged": False}, "prompts": {"listChanged": False}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION,
                           "title": "Takealot ERP（本机工作台 + 对话内受控写入）"},
            "instructions": ("Takealot 跨境 ERP。取数用下面的只读工具；改价 / 改库存 / 备货期 / RRP / 跟价 / 跟卖"
                             "有写工具且在对话内受控执行（先 preview/dryRun → 取得用户明确确认 → 写后回读）；"
                             "上架 / 下架 / 发 loadsheet / 商品主数据只在工作台界面里做。"
                             "取不到数据时工具会返回 ok:false 与真实原因，照实解释，不要编数字。"),
        })
        return

    if method in ("notifications/initialized", "initialized"):
        return  # 通知，无响应

    if method == "ping":
        _reply(id_, {})
        return

    if method == "tools/list":
        defs = tool_defs()
        audit("tools/list", count=len(defs))
        _reply(id_, {"tools": defs})
        return

    if method == "tools/call":
        name = params.get("name")
        audit("tools/call", tool=str(name))
        try:
            text = call_tool(str(name), params.get("arguments") or {})
            _reply(id_, {"content": [{"type": "text", "text": text}], "isError": False})
        except Exception as exc:
            _reply(id_, {"content": [{"type": "text", "text": "{0}: {1}".format(type(exc).__name__, exc)}],
                         "isError": True})
        return

    if method == "resources/list":
        _reply(id_, {"resources": []})
        return
    if method == "prompts/list":
        audit("prompts/list", count=len(PROMPTS))
        _reply(id_, {"prompts": PROMPTS})
        return

    if method == "prompts/get":
        pname = str(params.get("name") or "")
        audit("prompts/get", prompt=pname)
        try:
            _reply(id_, prompt_messages(pname, params.get("arguments") or {}))
        except Exception as exc:
            _reply(id_, error={"code": -32602, "message": "{0}: {1}".format(type(exc).__name__, exc)})
        return

    if id_ is not None:
        _reply(id_, error={"code": -32601, "message": "Method not found: {0}".format(method)})


def main() -> int:
    parent = "?"
    try:
        ppid = os.getppid()
        out = subprocess.run(["ps", "-p", str(ppid), "-o", "comm="], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip()
        parent = out or "?"
    except Exception:
        pass
    audit("spawn", parent_comm=parent, erp_home=str(_home().root))
    for raw in sys.stdin:
        line = raw.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            continue  # 脏行不该把整个连接带崩
        if isinstance(msg, list):  # 批量请求
            for m in msg:
                if isinstance(m, dict):
                    handle(m)
            continue
        if isinstance(msg, dict):
            try:
                handle(msg)
            except Exception as exc:  # 协议层不许静默死掉
                if msg.get("id") is not None:
                    _reply(msg.get("id"), error={"code": -32603, "message": str(exc)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
