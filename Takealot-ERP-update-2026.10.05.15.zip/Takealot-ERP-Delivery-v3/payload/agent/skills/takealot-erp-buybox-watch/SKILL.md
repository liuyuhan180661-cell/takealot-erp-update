---
name: takealot-erp-buybox-watch
description: Use when 客户要 24 小时盯盘 / 买盒守护 / 自动跟价巡检（Takealot ERP）。授权一次后按固定间隔自动巡检并写价，异常才叫醒用户。
---

# 24 小时买盒盯盘（Takealot ERP）

> 搭配跟价重构后的新逻辑用（`docs/REPRICING-SPEC.md`）：**勾选即自动、点即写入、没有试算**。
> 本 skill 让 agent 从「用户点一下」升级为「不间断定时巡检」，但**只问一次权限**。

## 何时用
- 用户说「24 小时盯着 / 帮我守买盒 / 自动跟价 / 别让对手抢走购物车」。
- 前提：客户机已装本插件、卖家 Key 已配、跟价页能用（能读到候选）。

## 第 0 步：一次授权（只问这一次，之后不再问）
一次问清三件事，缺一个都不要开始：
1. **多久巡一次**（默认 2 小时；最小 30 分钟，别更密）
2. **调价范围**：下探 `R__` ~ 最多 `R__`（例：R1 ~ R50）—— 下探 = 比最低竞品低多少；最多 = 单次不许砸穿多少
3. **允许直接写平台价吗**（本插件默认允许；明确告知"写入立即生效、没有试算"）

授权**在对话里完成**（客户要的是闭环：丢盒要立刻能压价抢回，卡一层"去界面点一下"就永远晚一步）。
先用一句话把范围问清楚，得到明确同意后再落盘 —— **不要自己定金额**：

```
erp repricing authorize --store store-2 --min 1 --max 50 --interval 2 --note "用户在对话里同意"
# 落盘 state/repricing_watch.json：
# {"authorized": true, "authorizedAt": "…", "authorizedVia": "conversation", "authorizedNote": "…",
#  "intervalHours": 2, "minUndercut": 1, "maxUndercut": 50, "maxChangesPerRun": 10,
#  "floorPrice": null, "ceilingPrice": null, "autoEnabled": true, "storeIds": ["store-2"]}
```
然后开定时任务 —— **不用 Hermes cron，用 ERP 自带的调度器**（跑在客户机自己的常驻服务里：
不依赖 Hermes、不依赖我们任何一台机器；服务由登录自启拉起，Windows 是 HKCU Run、macOS 是 LaunchAgent；
机器开着就跑，关机期间不跑、开机后继续，不补跑）：
```
erp job list                     # 看排期/上次结果/下次时间/「调度线程在不在跳」（心跳证据）
erp job enable buybox-round      # ⚠️ 写价任务：命令行**开不了**，必须先在工作台界面明确授权一次
```
正确顺序：① 让用户在工作台界面**明确授权一次自动跟价**（授权逐店、**升级安装不继承**）；
② 授权后再 `erp job enable buybox-round`（或让 agent 说「启用自动跟价」）。
脚本本体在 `ERP_HOME/server/jobs/`（**随升级自动换新**），排期在 `ERP_HOME/jobs/jobs.json`（**用户配置，升级不覆盖**）。
每轮输出都留证据：`ERP_HOME/logs/jobs/buybox-round/<时间>.md`。
告诉用户「已开始，授权范围 R1~R50，每 2 小时一次；说『停』我就停」。

## 每轮巡检（确定性步骤，不猜、不发挥）
1. 读 `state\repricing_watch.json`：`authorized` 非 true → 立刻停（不写任何价）。
2. 对每个 `storeIds`：`GET /repricing/candidates?storeId=<店>`（一次拿全，不要逐条轮询）。
3. 逐条判定：
   - `listed=false`（已下架）→ 跳过，不写。
   - `buyboxHeld=true` → 跳过（已处优势地位）。
   - `lowestCompetitor` 为空 → 记「未抓取」，调 `POST /buybox/enrich` 补一次，本轮不写。
   - 其余 = 需要跟价。
4. 目标价（与后端同一公式，写死）：
   `target = 最低竞品价 − 下探值`（下探值默认 `minUndercut`，即 R1）；
   再被 `floorPrice`（用户保本底价）与 `ceilingPrice`（天花板价）夹取；
   并按本轮授权再收一道：`target ≥ 现价 − maxUndercut`（单次不许砸穿）；
   夹取后仍 ≥ 现价、或落在边界外 → **不写**（交给后端记 `SKIPPED` + 原因）。
5. 写入：`POST /repricing/run {"storeId": <店>, "skus": [...]}`（只放本轮算得出且该写的 SKU）。
   单轮条数 ≤ `maxChangesPerRun`（默认 10），多出的**留到下一轮** —— 不许为了"一次做完"绕过限速。
6. 复核（必做，不许省）：对每条写过的 SKU `GET /offers/by_sku/{sku}`，回读价 == 目标价才算成功；
   不等 → 记 `FAILED` + 平台原文，下一轮重试一次；仍失败 → 叫醒用户。
7. 留痕：`GET /repricing/log?storeId=…&limit=50` 取本轮新增行，追加进 `state\repricing_watch_log.md`：
   `时间 · SKU · 旧价→新价 · 结果(WROTE/SKIPPED/FAILED) · 平台回读 · 原因`，一行一条。

## 证据铁律（防「没执行说执行了」）
**唯一允许的写入入口 = 本 skill 自带的脚本**：
`<hermes venv python> "%LOCALAPPDATA%\hermes\skills\takealot-erp-buybox-watch\scripts\repricing_round.py" --store <店>`

- agent 只许**运行它并原样转述它的输出**（`SUMMARY` / `PROBLEMS` 行）。不许自己算价、不许自己写总结、不许在脚本报错时美化措辞。
- 脚本内部的链路：读授权 → 拉候选 → 提交写入 → **再独立 GET 回读一次**（不信后端自述、也不信 agent 自述）→ 账本行 append 到 `state\repricing_watch_log.md`。
- **判定成功的唯一标准**：脚本打印 `WROTE(已验证)` 且 `SUMMARY` 里「失败/未验证」为 0（退出码 0）。
  出现 `WROTE(未验证!)`、`FAILED`、或退出码 1 → 必须如实说"未生效"，并附 `PROBLEMS` 原文。
- 任何「我已调价 / 已同步」的说法，必须**同时**给出三样：脚本输出、账本尾行、`state\offer_writes.json` 里该 SKU 的 `readbackPrice`。缺一即视为没执行。
- 脚本在无授权 / 无 storeIds 时会打印 `ABORT:` 并以退出码 2 结束 —— **这就是"没执行"，不许说成"已巡检"**。
- 平台侧证据以 `GET /offers/by_sku/{sku}` 的回读价为准；「接口返回 200」不算证据。

## 汇报纪律（默认静默，别刷屏）
- 正常轮次**不打扰用户**，只往日志文件累积。
- **「没有消息」只能等于「跑了、没事」，绝不能等于「没跑成」**：离线/连不上/脚本没起来一律要出声（见下「定时任务」）。
- 只在下列情况主动发一条消息（附证据，不写长篇）：
  ① 出现 `FAILED`，或平台 4xx/5xx；② 连续 2 轮买盒仍未夺回；③ 竞品价跌破保本底价导致无法跟；
  ④ 单轮触顶/触底 ≥ 3 条；⑤ 候选数骤降（数据通道疑似断，先查通道再动手）。
- 日报（用户要才发）：`今日调价 N 条：写入 M、跳过 K（原因 top2）、失败 J`。

## 暂停 / 改范围
- 用户说「停」：`erp repricing revoke`（撤回授权）+ `erp job disable buybox-round`（停任务）。
  **已调出去的价格不会自动变回来**，要还原得手工改价 —— 跟用户说清楚这一点。
- 用户改范围/改间隔：只改 `state\repricing_watch.json`（和 cron 的 schedule），不重建流程。

## v3 移植状态（写在最前面，别踩）

| 脚本 | v2 插件 | v3 服务端 |
|---|---|---|
| `watch_report.py`（日报，只读） | ✅ | ✅ 已自适应（走本机 API） |
| `repricing_round.py`（**唯一写价入口**） | ✅ | ✅ **已移植到 v3**：走本机 `GET /repricing/candidates` → `POST /repricing/save`（后端唯一写价路径）→ **脚本自己再 GET 回读一次** → 账本 `state/repricing_watch_log.md`；`--plan` 只看不写。**未授权仍 ABORT + exit 2** |

v3 上要开自动跟价，先做移植并在一台**有 Key 的 v3 机器**上验一遍（这是真金白银的写入，不许"没验就上"）：

1. 取数：`GET /repricing/candidates?storeId=<店>`（只读）。
2. 写价：走后端唯一写价路径（界面同一个 `/repricing/*` 写接口）+ `X-ERP-Token`；**不要** import 内部模块、不要自己拼 PATCH。
3. 回读：`GET /offers/by_sku/{sku}` 拿平台真实价 —— 「接口 200」不算证据。
4. 账本：`state/repricing_watch_log.md` 逐行 append；无授权（`repricing_watch.json` 里 `authorized != true`）必须 `ABORT`。
5. 移植完把上表的 ⛔ 换成 ✅ 并写上实测证据（真店 + 回读值），再开定时任务。

## 硬规矩
- **写价即时生效、没有试算、没有二次确认**：每轮动的都是真钱，授权前把范围讲清、写进文件。
- 不碰模型/供应商配置、不碰 `.env`、不碰用户其它插件与技能；只读写 `state\` 与调价相关端点。
- 未选定店铺的汇总视图**禁止写入**。
- 单轮上限与冷却（跟降/抬价冷却）是平台风控，不许绕过。
- 手工试写/还原规程照 `docs/REPRICING-SPEC.md` 第九节：只拿「目标价与现价差 ≤ R1」的 listing 或测试店试；
  还原用 `_api_request("PATCH", "/offers/by_sku/{sku}", None, {"selling_price": int(原价)}, store_id=...)`
  —— 注意签名是 `(method, path, query, body, ...)`，body 传错位置会被平台 400 拒且**误以为已还原**；还原后必须 GET 回读确认。

## 收工汇报（给用户的自证四件）
- `state\repricing_watch.json`（授权范围 + 间隔）
- `state\repricing_watch_log.md` 尾 10 行
- `state\offer_writes.json` 里本轮 `WROTE` 行的 `readbackPrice`
- 一句话：这轮写了哪些 SKU、各几块钱、平台回读价是多少

## 日报：丢失抢回 / 稳定占优（用户要就看，别自己算）
```
<hermes venv python> "%LOCALAPPDATA%\hermes\skills\takealot-erp-buybox-watch\scripts\watch_report.py" [--store <店>] [--hours 24]
```
- **只读**：读 `repricing_watch.json`（授权范围）+ `repricing_watch_log.md`（窗口内写入/跳过/失败）
  + `repricing_candidates()`（当前买盒归属），四类分桶：① 丢失后已抢回 ② 稳定占优 ③ 还没抢回来
  ④ 抓不到竞品数据（= 通道问题，不是"没对手"）。
- 判定只用端点字段：`buyboxHeld` / `lowestCompetitor` / `crawled`；「曾经丢过」的证据 = 窗口内有写价记录
  （只有丢盒才会写价，所以有 WROTE 行 = 当时不在我们手上）。
- 退出码 1 = 有 `FAILED` / `WROTE(未验证)` 行；**必须**把 PROBLEMS 段原文转述，不许说"已恢复正常"。
- 定时：日报任务 `buybox-report` 每天 09:00；巡检任务 `buybox-round` 每 2 小时（需授权）。

## 定时任务（**只有一种挂法**：客户机自己的内置调度器）
任务跑在 v3 常驻服务里（`source/server/scheduler.py`），脚本在 `ERP_HOME/server/jobs/`：
- 列/跑/开关：`erp job list` · `erp job run <id>` · `erp job enable|disable <id>`
- 自然语言入口（agent 直接用）：说「有什么定时任务」「现在就跑一次买盒巡检」「把自动跟价启用」
  会命中词表 → 落到上面这些确定性命令（`erp route "<原话>"` 可自查）。
- 每轮都写证据文件 + 状态，**没有消息只能等于「跑了没事」**，绝不等于「没跑成」。
- **调速**：`erp job set buybox-round --interval <分钟> --args "--stale-hours 4 --refresh-held <N>"`
  （自然语言入口：「巡查频率改成每 10 分钟」→ 命中词表 → 这条命令）。
  **默认 refresh-held 40**（在售 200 行 ≈ 10 小时覆盖一遍）；要更快就调大（200 ≈ 2 小时）。
  **别写死**：客户端的 agent 可以按生意节奏随机/自适应改（比如上新期勤、淡季疏）。

## 数据新鲜度（**不许拿旧卡误判「买盒还在我们手上」**）

跟价决策依赖两个数，来源**不一样**（后端候选接口自己声明、代码一致）：

| 数据 | 来源 | 新鲜度 |
|---|---|---|
| 我们的现价 `currentPrice` | 平台 `/offers` | 实时（≤60s） |
| **竞品最低价 / 购物车归属 `buyboxHeld`** | **公开页抓取卡**（`_cached_card` / `_buybox_held_from_card`） | **缓存，TTL 5 天** ← 风险点 |

所以规矩是（脚本已实现，别绕开）：

1. **候选行必须带卡龄**：`crawledAgeHours` / `crawledFresh` / `plid`（核心已暴露）。
2. **写价前新鲜度闸门**：本轮**要动的行**卡龄 > `--stale-hours`（默认 4h）→ **先强制重抓**，用新鲜数据重算；
   刷新后发现「其实都在我们手上」→ **本轮不动**（宁可不写，也不拿 5 天前的卡去压价）。
3. **占优行轮转刷新** `--refresh-held N`：对「我们当前占优」的行**最旧卡优先**每轮刷 N 个
   → 丢盒发现延迟 = 在售行数 ÷ N × 轮间隔（200 ÷ 40 × 2h ≈ 10 小时；N=200 时 ≈ 2 小时 = 轮间隔）。
4. **别改爬虫的 5 天 TTL**：那是销量推算（评论增量反推）的口径；要新鲜就靠第 2、3 条。

## ⚠️ 两组爬虫不是一回事，别混淆、别互相动

| | 谁 | 干什么 | 能不能动 |
|---|---|---|---|
| **跟价竞品爬虫** | 本机 v3 服务里的 `/crawler/*`（走出口代理抓**公开页**） | 竞品价 / 购物车归属 / 销量推算 | 我们的模块，按上面规矩用 |
| **CDP / portal 抓取** | `takealot-portal-cua`（BrowserSkill 驱动**卖家后台**界面） | 建/改 listing 的界面操作 | **另一套、目前是最佳状态 —— 不要动它、也不要用它去取竞品数据** |
- **唯独「连不上客户机」不算无事发生**：必须报「看门狗这次没跑」，连续离线（默认 6 次 ≈ 12h）
  升级成「🔴 已连续 N 次没工作，这段时间价格没有任何守护」。
  血泪教训：转发脚本原来一律静默，客户机离线 4 天、27 次执行全静默，用户以为在守价、其实一次都没跑。
