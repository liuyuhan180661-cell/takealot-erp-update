#!/usr/bin/env python3
"""服务端持久化核对：某条 submission 的 title / description 到底存没存进去。

**为什么必须有这个命令**：Draft.js 富文本可以被 JS 直接改页面状态（fiber 注入）或用
`bsk fill` 写进去，页面上读回一切正常 —— 但**存不进服务器**。唯一可信的判据就是
「从服务器重新读回来」。这个脚本就做这一件事。

用法：
  python3 verify_persisted.py            # 用列表里最新一条草稿
  python3 verify_persisted.py 5552510    # 指定 submission id

输出：title / description 的服务端长度 + 前 60 字，以及 PASS/FAIL 判定。
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tl_engine as E  # noqa: E402

FIELDS = ("title", "description")


def open_draft(sid):
    """打开草稿编辑页（列表链接是 /single-product/<id>，进去是摘要页，再点 Edit）。"""
    E.goto(f"https://sellers.takealot.com/single-product/{sid}")
    time.sleep(4)
    if not E._js("document.querySelectorAll('[data-fieldid]').length"):
        E._js("""(()=>{const b=Array.from(document.querySelectorAll('button'))
            .find(x=>x.innerText.trim()==='Edit'); if(b)b.click(); return true;})()""")
        for _ in range(24):
            time.sleep(1.5)
            if E._js("document.querySelectorAll('[data-fieldid]').length"):
                break
    return E._js("document.querySelectorAll('[data-fieldid]').length") or 0


def latest_draft_id():
    E.goto("https://sellers.takealot.com/catalogue/submissions")
    time.sleep(3)
    ids = E._js_json("""(()=>{const o=[];document.querySelectorAll('a[href*="/single-product/"]')
        .forEach(a=>{const m=(a.getAttribute('href')||'').match(/\\/single-product\\/(\\d+)/);
        if(m)o.push(m[1]);});return o.slice(0,5);})()""") or []
    return ids[0] if ids else None


def main():
    sid = sys.argv[1] if len(sys.argv) > 1 else None
    E.start_session()
    if not sid:
        sid = latest_draft_id()
        if not sid:
            print("FAIL 没在列表里找到草稿，传一个 submission id 进来")
            return 1
    n = open_draft(sid)
    print(f"草稿 {sid}：字段数={n}")
    if not n:
        print("FAIL 编辑页没渲染出字段（会话退化？重启会话再试）")
        return 1
    bad = []
    for fid in FIELDS:
        t = E._rich_truth(fid) or {}
        ln = t.get("len")
        head = (t.get("text") or "")[:60].replace("\n", "\\n")
        if fid == "title":
            # title 是平台的 AutoBuild 字段（`data-fieldtype="Title"`）：平台按属性自己生成标题，
            # 所以**服务端为空是正常的**（对照提交 5551654 / 5552834 都是 0）→ 只提示，不判 FAIL。
            flag = "✅" if ln else "⚠ 空（AutoBuild 字段：平台自生成，正常）"
        else:
            flag = "✅" if ln else "❌ 空（服务端没存）"
            if not ln:
                bad.append(fid)
        print(f"  {fid:<12} 服务端长度={ln}  {flag}  {head!r}")
    if bad:
        print(f"\n结论: FAIL —— {', '.join(bad)} 在服务端是空的。"
              "（页面内写进去不等于存进去；见 references/pitfalls.md G3）")
        return 1
    print("\n结论: PASS —— description 在服务端（title 若为空属 AutoBuild 正常）。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
