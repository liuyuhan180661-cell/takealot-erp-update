#!/usr/bin/env python3
"""A 场景：自编辑新建 listing。

用法:
  python3 create_listing.py facts_A_backpack.json            # 建草稿 → 断言 → 提交 → 核对
  python3 create_listing.py facts_A_backpack.json --no-submit # 只建草稿 + 断言，不提交

facts JSON 结构见 facts_A_backpack.json。
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tl_engine as E  # noqa: E402


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    facts = json.load(open(sys.argv[1], encoding="utf-8"))
    submit_it = "--no-submit" not in sys.argv
    E.start_session()
    try:
        report = E.create_listing(facts, submit_it=submit_it)
    finally:
        E.stop_cors()
    print(json.dumps(report, ensure_ascii=False, indent=1))
    out = os.path.join(os.path.expanduser(os.environ.get("TL_WORKDIR") or "~/.hermes/portal_cua"), "runs", f"{facts.get('name','listing')}.report.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    json.dump(report, open(out, "w"), ensure_ascii=False, indent=1)
    print(f"[A] report -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
