---
name: erp-self-update
description: Use when checking or applying an ERP update.
---

# ERP 自更新（检查更新 / 更新 / 回滚）

## 触发词

`检查更新` · `有没有新版本` · `更新 ERP` · `升级一下` · `回滚` · `退回上一版` · `更新失败怎么办`

## 流程（照做，别跳）

1. **找更新器**：按顺序找哪个存在用哪个
   - `%LOCALAPPDATA%\hermes\plugins\<插件 id>\delivery\selfupdate.py`
   - 本技能目录旁 `selfupdate.py`
   - 交付包解压目录里的同名文件

   **都没有 → 从公开通道下载它（这一步就是"给个地址让它自己拉"）**：
   ```
   https://cdn.jsdelivr.net/gh/<owner>/<repo>@main/selfupdate.py
   https://raw.githubusercontent.com/<owner>/<repo>/main/selfupdate.py      （jsDelivr 不通时用）
   ```
   下载后放到 `%LOCALAPPDATA%\hermes\plugins\<插件 id>\delivery\selfupdate.py` 即可（单文件即可运行；
   不需要其它依赖）。之后它就自给自足了 —— 更新包会把最新版更新器一起带过来。

2. **先检查（不动文件）**
   ```
   <Hermes venv python> selfupdate.py --repo <公开通道仓库 owner/repo>
   ```
   它会按 `jsDelivr → raw.githubusercontent → gh-proxy` 自动降级；成功会打印：远端版本 / 本机版本 / 包大小 / 变更说明 / 会改哪些文件。

3. **把结果念给用户**（版本从哪到哪、包多大、变了什么），**等用户确认**。

4. **用户确认后应用**
   ```
   ... --apply
   ```
   内部顺序：下载 → 整包 sha256+md5 校验 → 包内 MANIFEST 逐文件 md5 校验 → **自动备份** → 按白名单落盘 → 写版本记录 + 审计。

5. **应用后必须验证**（这是完成的唯一判据）
   - 跑 `selfcheck.ps1` → 期望 **9/9 PASS**；把实际结果告诉用户
   - 若这次更新动了浏览器扩展 → 让用户在 `chrome://extensions` 点一次「重新加载」
   - 界面半边（`plugin.js`）由桌面 App 热加载，无需重启

6. **失败或客户不满意** → `... --rollback`（文件与版本记录一起回退；`state/` 从不参与）

## 铁律

- **先 dry-run 再 apply**，不要替客户决定装不装
- **绝不碰 `state/`**（Seller Key 与业务数据）——更新器已用白名单限制，别绕过它手工覆盖文件
- 校验失败（整包指纹或逐文件 md5 不符）**一律中止**，不要"重试到成功"，也不要拿别处的包顶替
- 更新完只报 `selfcheck` 的**实际输出**，不许说"应该没问题"
- 三通道全不通就如实说网络不通，并在下一条回复里告诉用户可选项（换代理 / 走 gh-proxy / 稍后重试）
- 相同版本想重装用 `--force`（仍会做全部校验），不要为此改版本号

## 版本信息

- 当前版本查 `--status`（读 `state/installed.json`）
- 审计记录：`state/update_audit.jsonl`（谁、什么时候、从哪个版本到哪个版本、结果）
