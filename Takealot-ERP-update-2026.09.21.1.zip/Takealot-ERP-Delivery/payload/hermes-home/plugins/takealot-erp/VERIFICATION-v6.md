# VERIFICATION — 商品管理 v6 (批量写入 + 跟卖执行) + 多店（per-store）on the box

**Scope**: `POST /products/batch-write` (A), `POST /products/{sku}/offer` + `sellAction` (B),
the per-store refactor of every store-scoped read/write path (addendum 2), and the full-catalogue
pagination fix (`total`/`mapped`/`pages`/`truncated` + `/products/stats` agreement).
Only `dashboard/plugin_api.py` changed (the UI half is the parent's). CONTRACT 1–5 paths stay intact.

Two stores are bound server-side in `state/stores.json`:

| storeId             | shop                          | sellerId | seller warehouse | leadtime_enabled | offers |
|---------------------|-------------------------------|----------|------------------|------------------|--------|
| `store-apex-direct` | Apex Direct (Pty) Ltd (TEST)  | 29896840 | 57960            | false            | 31→34  |
| `store-2`           | 真实主店 “AHG” (REAL)          | 29903958 | 64191            | true             | 1321   |

## 1. The two commands (throwaway `hermes serve` on its own HERMES_HOME + known token)

```powershell
# (a) FULL sweep — real writes. The probe home's activeStoreId is pinned to the DISPOSABLE
#     test store, so the real shop is never written to. This is the parent's command.
powershell -ExecutionPolicy Bypass -File C:\Users\Fly\erp_sweep.ps1 18799 -OfferBarcode <barcode-for-跟卖>

# (b) READ-ONLY sweep against the REAL shop (same endpoints, ?storeId= proves the scoping)
powershell -ExecutionPolicy Bypass -File C:\Users\Fly\erp_sweep.ps1 18798 -ActiveStore store-2 -NoLiveWrites
```

`erp_sweep.ps1` now: copies the plugin (state included) into `C:\Users\Fly\erp-verify-<port>`, **pins the
throwaway copy's `activeStoreId`** (the user's real app/state is untouched), seeds the crawler drop
folder, starts the probe with `HERMES_DASHBOARD_SESSION_TOKEN=erp-verify-token`, runs
`C:\Users\Fly\erp-harness\check_erp.py` (v1…v4/v5 + the new v6 section), then tears the server down.

## 2. `POST /products/batch-write` — 批量改价/改库存

### 2.1 dryRun with a bad row: every row validated, ZERO API calls, ZERO audit writes

```text
POST /products/batch-write  {"dryRun":true,"rows":[
  {"sku":"<real sku>","selling_price":123},          # valid
  {"sku":"<real sku>","selling_price":0},            # bad price
  {"sku":"<real sku>","seller_stock":-5}]}           # bad stock
→ ok=false dryRun=true total=3 blockedCount=2 apiCalls=0 writesSent=0 changed=0 appliedCount=0
  reject row 2: ["第 2 行：售价 (ZAR)不能小于 1（整数 ZAR，最低 R 1），收到 0"]
  reject row 3: ["第 3 行：卖家自营仓库存不能小于 0（非负整数，写的是本店 Seller Warehouse 的可用数），收到 -5"]
  valid row 1 (nothing sent because a sibling row was invalid): {"sku":"…","ok":true,"apiStatus":null,"request":{}}
  hint: 校验未通过（中文本地校验）：2 行非法，**一行都没有发送**，也没有写审计日志（apiCalls=0）。修正后再提交。
```
Harness assertions: `blockedCount==2`, `apiCalls==0`, `writesSent==0`, both bad rows carry Chinese
errors and no `request` body, `state/offer_writes.json` row count unchanged, `state/price_log.json`
line count unchanged.

### 2.2 dryRun, all rows valid: the exact per-row PATCH bodies, still nothing sent

```text
dryRun row 1 sku=… request={"selling_price":199} changed={"selling_price":{"label":"售价 (ZAR)","api":"selling_price","from":69,"to":199}}
dryRun row 2 sku=… request={"selling_price":199} changed={"selling_price":{…,"from":350,"to":199}}
ok=true dryRun=true total=2 changed=2 writesSent=0 apiCalls=0（回读值来自 ≤60s 的 per-store offer 缓存）
```

### 2.3 the 50-row cap

```text
POST rows=[51 × {sku, selling_price:199}] (dryRun)
→ requested=51 total=50 clamped=true
  hint: "rows 超过单次上限 50：本次只处理前 50 行（收到 51 行）。 dryRun：只做中文本地校验并回显…"
```

### 2.4 a REAL 2-row write (sequential), per-row raw responses, audit, cache bust, then the RESTORE

```text
POST /products/batch-write {"rows":[{"sku":"9902290491593","selling_price":70},{"sku":"9902594708786","selling_price":5001}]}
→ ok=true appliedCount=2 failedCount=0 changed=2 writesSent=2 apiCalls=6 batchId=BW-20260919194928
  row 1: sku=9902290491593 69 → 70  apiStatus=200 request={"selling_price": 70}
    RAW PATCH status=200 reread status=200 re-read selling_price=70
    applied[0]=[{"field":"selling_price",…,"from":69,"to":70,"ok":true,"actual":70,"message":"已写入并回读确认：售价 (ZAR) R 69 → R 70"}]
  row 2: sku=9902594708786 5000 → 5001 apiStatus=200 request={"selling_price": 5001}
    RAW PATCH status=200 reread status=200 re-read selling_price=5001
  audit row (rowIndex 1): {"at":"2026-09-19 19:49","sku":"9902290491593","type":"BATCH_WRITE","batchId":"BW-20260919194928","rowIndex":1,"request":{"selling_price":70},"apiStatus":200,"ok":true,"source":"POST /products/batch-write","storeId":"store-apex-direct"}
  audit row (rowIndex 2): {…"sku":"9902594708786","rowIndex":2,"request":{"selling_price":5001},"apiStatus":200,"ok":true…}
  price_log[0]: {"time":"19:49:34","sku":"9902594708786","tsin":"TSIN95550487","type":"BATCH_WRITE","message":"批量写入·改价：售价 (ZAR) R 5000 → R 5001（PATCH /offers/by_sku/9902594708786，已回读确认）","storeId":"store-apex-direct"}
  /products reflects the batch immediately (cache busted)

POST /products/batch-write {"rows":[{"sku":"9902290491593","selling_price":69},{"sku":"9902594708786","selling_price":5000}]}
→ ok=true appliedCount=2
  restore row 1: 70 → 69    apiStatus=200 re-read=69   raw={"patch":{"status":200,"request":{"selling_price":69},"body":"{\"sku\": \"9902290491593\", …"}}
  restore row 2: 5001 → 5000 apiStatus=200 re-read=5000 raw={"patch":{"status":200,"request":{"selling_price":5000},"body":"{\"sku\": \"9902594708786\", …"}}
  account after restore (9902290491593): price=R69.0 (original R69)
  account after restore (9902594708786): price=R5000.0 (original R5000)
```
Harness assertions: `writesSent==2` (one PATCH per row, never parallel), per-row `raw.patch.status` +
`raw.reread.status` present, `applied[0].to/ok` correct, re-read `offer.selling_price` equals the target,
audit rows carry `type=BATCH_WRITE` + `rowIndex` + `storeId` + the request, `state/price_log.json` gained
one `BATCH_WRITE` line per row, `/products` mirrors the new price, and after the restore call the account
is byte-equal to where it started (`item.price == original`).

## 3. `POST /products/{sku}/offer` — 跟卖执行 (official `POST /offers`)

### 3.1 dryRun — the exact `CreateOfferRequest` body, nothing sent

```text
POST /products/9902290491593/offer {"dryRun":true,"selling_price":137,"seller_stock":2}
→ ok=true dryRun=true writesSent=0 apiStatus=null
  request    : {"barcode":"MPTALX12424284-0","selling_price":137,"seller_warehouse_stock":[{"seller_warehouse_id":57960,"quantity_available":2}]}
  resolution : {"barcode":"MPTALX12424284-0","barcodeSource":"own-offer(bysku)","tsin":"TSIN92289613","tsinSource":"own-offer.tsin_id"}
  warehouse  : {"warehouseId":57960,"source":"store-offers-cache（per-store，TTL 60s）","fromSku":"9902290491593"}
  warnings   : ["条码 …（来源：own-offer(bysku)）—— CreateOfferRequest 的必填字段", "本店已有一条该 SKU 的 offer…"]
```
Local rejections (no send, Chinese, audited: nothing):
`{"selling_price":0}` → 售价 (ZAR)不能小于 1；
`{"status":"buyable", …}` → 该字段不可写：上下架状态…disable_listing_enabled=false；
`{"unknown_key":1,…}` → 该字段不可写：不认识的字段 unknown_key。
An unresolvable target (no barcode anywhere) → 无法解析出该目录项的 **条码 barcode**（CreateOfferRequest 必填）…

### 3.2 a REAL create against the live account — HTTP 201 + re-read

```text
POST /products/PLID000000777/offer {"selling_price":5000,"barcode":"MPTALX20931969-2"}
    RAW POST /offers → HTTP 201
    request body sent   : {"barcode": "MPTALX20931969-2", "selling_price": 5000}
    raw response body   : {"success": true, "errors": [], "offer": {"sku": "9902594735751", "barcode": "MPTALX20931969-2",
                          "product_label": "9902594735751", "title": "Aircon Compressor Compatible with Mercedes - A0038304360",
                          "discount_percentage": 0.0, "status": "not_buyable", "created_at": "2026-09-19T15:49:44+02:00", …}}
    offer (re-read)     : GET /offers/by_sku/9902594735751 → the same Offer (platform-assigned SKU)
  CREATED: offer_id=259473575 sku=9902594735751 barcode=MPTALX20931969-2 price=5000 status=not_buyable
  /products now lists total=34 mapped=34
  audit row[0] (OFFER_CREATE): {"at":"2026-09-19 19:49","sku":"9902594735751","type":"OFFER_CREATE","offerId":259473575,
                                "request":{"barcode":"MPTALX20931969-2","selling_price":5000},"apiStatus":201,"ok":true,
                                "source":"POST /products/{sku}/offer","storeId":"store-apex-direct"}
```
> The 201 body is **wrapped** (`{"success":true,"errors":[],"offer":{…}}`) — the schema documents a bare
> Offer; the code unwraps both shapes and re-reads the offer the platform assigned. **The created 跟卖
> offers are left in place on the disposable test store**, as the contract asks:
> `9902594681676` (MPTALX34626520-0), `9902594708786` (MPTALX16842543-0), `9902594735751` (MPTALX20931969-2).

### 3.3 a duplicate create — the platform's refusal, verbatim, audited `ok:false`

```text
POST /products/PLID000000777/offer {"selling_price":350,"barcode":"MPTALX34626520-0"}   # already on the account
    RAW POST /offers → HTTP 400
    platform error   : Takealot API 400: {"success": false, "errors": ["cant-create-duplicate-gtin"]}
    raw response body: {"success": false, "errors": ["cant-create-duplicate-gtin"]}
  REFUSED BY PLATFORM (verbatim — this IS the result): Takealot API 400: {"success": false, "errors": ["cant-create-duplicate-gtin"]}
  audit row[0] (OFFER_CREATE): {…"apiStatus":400,"ok":false,"error":"Takealot API 400: {\"success\": false, \"errors\": [\"cant-create-duplicate-gtin\"]}"…}
```

### 3.4 `sellAction` in `GET /products/{sku}`

```text
sellAction: canCreateOffer=True alreadySelling=True
  reason  : 该条码本店已有 offer（SKU HGF0D8B4B466，Offer 258475989）：POST /offers 会因重复被拒，改价/改库存请用 PATCH /products/HGF0D8B4B466。
  defaults: {"barcode":"MPTALX33723115-0","barcodeSource":"own-offer(bysku)","tsin":"TSIN104805060",
             "suggestedPrice":2843,"rrp":4343,"sellerStock":50,"warehouseId":64191,
             "warehouseSource":"store-offers-cache（per-store，TTL 60s）","leadtimeEnabled":true}
```

## 4. 全量分页 — `total` is the whole account again

```text
GET /products?limit=100        → mode=live total=1321 mapped=1321 pages=2 truncated=False store=store-2 (真实主店)
GET /products/stats            → total=1321 mapped=1321 pages=2 sellable=1058 notSellable=26 disabled=237
                                 zeroStock=263 inStock=1058 | byOrigin={"own":1,"follow":4,"unknown":1316}
                                 | byStatus={"buyable":1058,"disabled_by_seller":215,"not_buyable":26,"disabled_by_takealot":22}
GET /products?limit=20&offset=20 → limit=20 offset=20 count=20 filtered=1321 hasMore=True
```
Before this change `total` was silently the page size (200 on a 1321-offer account). Now the offers list is
paginated to the end (`limit=1000` + `offer_id__gt` cursor, `continuation_token` honoured, capped at 20 000
rows / 25 pages with an honest `truncated` flag + hint), memoized per store for 60 s, and the mapped item
list is memoized for 5 s so a 1321-row account is not re-mapped on every request.

## 5. 多店 (addendum 2) — one endpoint, two `storeId`s, two different shops

```text
TWO-STORE SIDE BY SIDE (same endpoint, ?storeId=):
  store-apex-direct  Apex Direct (Pty) Lt   total=33     mapped=33     first_skus=["9902290491593","9902594708786","9902594681676"]
  store-2            真实主店                 total=1321   mapped=1321   first_skus=["HG3D6555DA08","HG88D230F6FA","HG099865CFD4"]
  per-store first SKUs differ: ["9902290491593","9902594708786"] vs ["HG3D6555DA08","HG88D230F6FA"]
  detail on store-apex-direct: found=True storeId=store-apex-direct seller=zhijiang leadtimeEnabled=False warehouseId=57960
  detail on store-2:           found=True storeId=store-2           seller=AHG      leadtimeEnabled=True  warehouseId=64191
```
Same process, per-store caches (direct engine probe):

```text
cache objects distinct: True | items: 32 vs 1321 | storeId: store-apex-direct vs store-2
own-offers index distinct: True | counts: 32 vs 1321 | first barcodes: ['0622356350907', …] vs ['0045496430634', …]
seller profile per store: {"a":{"storeId":"store-apex-direct","source":"live"},"b":{"storeId":"store-2","source":"live"}}
                          | sellerIds: 29896840 vs 29903958
collection per store: store-apex-direct count=3 | store-2 count=1       (filtered by assignedStoreId)
drafts per store    : {'store-apex-direct': 9, 'store-2': 0}            (filtered by draft.storeId)
buybox_log per store: {'store-apex-direct': 7, 'store-2': 7}            (rows without a store stay visible)
competitor per store: {'store-apex-direct': 4, 'store-2': 4}
overview / financial per store: storeId echoes the requested store
```

What changed for this:

* **one key resolver** — `_seller_key(store_id)` / `_key_configured(store_id)` / `_store_key_for(store_id)`,
  threaded through `_api_request(..., store_id=)`; a bound store with no key resolves to `None` (never
  borrows the other shop's key), and an unknown `storeId` is reported in `note`, never silently swapped.
* **per-store TTL caches** — `_OFFERS_BY_STORE`, `_OFFER_INDEX_BY_STORE`, `_CATALOG_BY_STORE`,
  `_SELLER_BY_STORE`, `_REGIONS_BY_STORE` (all keyed by store id); `_bust_offer_caches(store_id)` clears
  just the written store.
* **local state carries its store** — `competitors.json` rows and every `price_log.json` line now record
  `storeId`; `/collection` (assignedStoreId), `/listings/drafts` (storeId), `/competitor`, `/buybox/log`
  filter by the requested `storeId` when one is given, and rows without a store stay visible so nothing
  disappears (the response says how many were kept).
* **writes target the request's store** — `storeId` accepted in the batch-write body, the offer-create
  body and the PATCH body (default = active store); every audit row records which store it went to.

## 6. The write paths on the REAL shop — verified with dryRun, NOT with a write

The parent authorised real writes **only** on the disposable test account. On `store-2`
(`leadtime_enabled=true`) the same endpoints were exercised in **dryRun** only:

```text
POST /products/batch-write {"dryRun":true,"rows":[{"sku":"HGF0D8B4B466","seller_stock":51}]}
  → request={"seller_warehouse_stock": [{"seller_warehouse_id": 64191, "quantity_available": 51}]}  writesSent=0
POST /products/HGF0D8B4B466/offer {"dryRun":true,"selling_price":137,"seller_stock":51,"minimum_leadtime_days":3}
  → request={"barcode":"MPTALX33723115-0","selling_price":137,
             "seller_warehouse_stock":[{"seller_warehouse_id":64191,"quantity_available":51}],
             "minimum_leadtime_days":3}          validation.leadtime="sent"  writesSent=0
```
i.e. on this account the seller-warehouse-stock change is **not refused locally** the way the test account's
was (`cant-edit-soh-leadtime-disabled`), and the leadtime is passed through because
`leadtime_enabled=true`. Whether Takealot accepts the stock number can only be proven with a real write —
that was deliberately **not** done on the real shop, so it stays an open item for the parent to authorise.

## 7. Regression

Both passes end green with the same harness:

```text
(a) FULL / test store : endpoint calls: 146   VERIFY RESULT: ALL 146 ENDPOINT CALLS GREEN … (checker exit code: 0)
(b) READ-ONLY / real  : endpoint calls: 137   VERIFY RESULT: ALL 137 ENDPOINT CALLS GREEN … [read-only pass: no write was sent]
```
v1 (40 regression rows), crawler/valuation/multi-store, 新建 Listing v3 (official loadsheet headers), v4
(商品列表/详情/筛选/分页), v5 (公共主数据 + 自建/跟卖 + PATCH 写回 + 还原) and the new v6 section are all included;
`check_erp.py`'s account-size assumptions are now baseline-relative (they used to hardcode “31 offers”,
which broke the moment a real offer was created).

## 8. Honest gaps

* The **real shop** has never been written to by this round (only reads + dryRun). The stock-write
  acceptance on `leadtime_enabled=true` remains unproven by design.
* `POST /offers` for a **brand-new catalogue item** (barcode not in the Takealot catalogue) was not
  exercised: the platform answers those with a catalogue/QC error and the correct route is a Loadsheet —
  the loadsheet path already refuses to guess (v3 suite).
* `sellAction.canCreateOffer` is true whenever a barcode resolves and a key is configured; the duplicate
  case is surfaced in `reason` (the platform's refusal is reported verbatim rather than pre-empted).
* Crawl-card based origin inference is per PLID and the crawl cache belongs to the account that crawled;
  on `store-2` most offers report `origin.code=unknown` (no cached card) — that is the documented
  “unknown when there is no evidence” behaviour, not a regression.
