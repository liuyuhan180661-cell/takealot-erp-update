﻿# Takealot ERP · 点检清单（CHECKLIST）

> 文件名是 `CHECKLIST.md` 而不是中文名 —— 交付 zip 内**不允许出现中文文件名**（编码/解压工具兼容性）。这就是**点检清单**。
>
> **分两半**：**A 段是脚本自检**（跑一下就有结论，不用人看）；**B 段是真人点检**（界面观感、浏览器会话、真实表单命中率 —— 这三类 harness 到不了）。
> 路径里的 `<Root>` 默认是 `%LOCALAPPDATA%\hermes`。

---

## A. 脚本自检（不用人看，跑完把最后一行贴回来）

前置：Hermes App 已打开、本地桥已启动（双击 `<Root>\plugins\takealot-erp\dashboard\bridge\start_bridge.bat`，窗口别关）。

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\precheck.ps1     # 装之前跑
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1      # 装
powershell -NoProfile -ExecutionPolicy Bypass -File .\selfcheck.ps1    # 装完跑
```

`selfcheck.ps1` 的 9 项：

| # | 项 | PASS 的判据 | FAIL 时看哪 |
| --- | --- | --- | --- |
| 1 | 后端已挂载 | 本地端口 `/api/plugins/takealot-erp/health` 答 401/200 **且** `logs\gui.log` 有 `Mounted plugin API routes: /api/plugins/takealot-erp/` | 只答 401 只证明"有个 Hermes 后端活着"（路由受会话 token 保护，不暴露插件名），**必须**配上日志挂载行才算挂上 |
| 2 | 两半文件 md5 与包内清单一致 | 逐文件与 `MANIFEST.md5` 相同 | 重跑 `install.ps1` |
| 3 | `state` 目录可写 | 写入并删除探针文件成功 | 权限 / 磁盘；后端必须与目录属主同一个 Windows 账号 |
| 4 | Seller Key 已绑（**打码**） | 至少一个店已绑，且**无明文** | 见 INSTALL.md 第 4 节 ② |
| 5 | 出口 transport | `proxy` 或 `direct` | `blocked` = 出口被 Cloudflare 拦，换出口 |
| 6 | 本地桥 18790 在跑 | 127.0.0.1:18790 在监听（并回报 `/takealot/api/health`） | 双击 `start_bridge.bat` |
| 7 | 扩展目录在位 | `manifest.json` 可解析 + 6 个必需文件齐 | 重跑 `install.ps1`。（**注意**：目录在位 ≠ 浏览器已加载，那要靠 B 段自己看 `chrome://extensions`） |
| 8 | `data` 三个 JSON 齐 | attributes / brands / categories 三个都在 | 重跑 `install.ps1` |
| 9 | AI / 中译通道 Key | 有（只说有/无，不显示值） | 往 `.env` 写 `DEEPSEEK_API_KEY=...` 后重启 App |

**期望结果**：`RESULT 9/9 PASS`。
不为 9/9 时，把**整段输出**（含每个 FAIL 的 `-> 建议` 行）贴回来即可。

---

## B. 真人点检（点完把每条的实测结果发我）

前置：**双击 `<Root>\plugins\takealot-erp\dashboard\bridge\start_bridge.bat`** 启桥（窗口别关），扩展才连得上。
入口：Hermes App → 左栏 **Takealot 运营**。

### B0. 基本盘（先确认这三条）

- [ ] 左栏有 **Takealot 运营**，点开是 ERP 页面；顶部/左栏有店铺药丸，能切店；
- [ ] 页面**没有**"内置样例数据"字样，也没有任何凭空出现的数字 —— 没绑 Key 就该是空、并说明原因；
- [ ] 扩展图标点开显示 **本地桥已连接**。

### B1. 属性「严格按类目」（已自证，可复核）

「上架编排」→ 选中一行 → 类目三列里**点一个末级类目**（例：搜 `Play Swings`）。

- [ ] 标题带 `· #19219`；徽章显示 `必填 10 · 推荐 11 · 选填 38`、`该类目要求至少 3 张图片`、`官方要求颜色（可做颜色变体）`；
- [ ] **必填每条带 `*`**，控件按类型给（下拉 / 数字 / 文本 / 是-否），单位与说明来自官方数据；
- [ ] 下面按钮 `显示推荐与选填（推荐 11 · 选填 38）`，**默认折叠**；
- [ ] 试一个**未收录**类目（Cycling / Liquor / Beauty 那一类）→ 显示 `该类目属性未收录`，**下面不出现任何属性**（不拿别的类目的属性顶替）；
- [ ] 注意：必填清单是按**末级类目（taxonomy_id）**给的（官方就是挂在叶子上），**只选到部门是列不出必填的**。

### B2. 同步官方类目属性模板（**只有你能点**）

属性模板只在商家后台 `seller-api.takealot.com/v1/loadsheets/templates`（认**页面登录会话**，ERP 后端拿不到，只有扩展能抓）。覆盖度出厂是 **7/36**，点一次补满。

1. [ ] Chrome/Edge 打开 `https://seller.takealot.com/`（已登录）+ 已加载扩展；
2. [ ] 页面里的「Takealot 运营助手」抽屉 → 「草稿」tab →「**同步官方类目属性模板**」；
3. [ ] 预期：报出接受了几张装载表 / 总数（成功应接近 **36**）；
4. [ ] 抓到的**原始响应也会留档** `state\attributes_templates_raw.json` —— 万一官方形状变了，**我离线就能修，不用你再点第二次**（原始响应只存 body，请求头/Authorization/JWT/cookie 一个字都不存）；
5. [ ] 回 ERP 再选原来"未收录"的类目 → 应能看到该类目的必填/推荐/选填；
6. [ ] 失败就把界面给的原话发我（未登录 / 接口变了 / 网络）。

### B3. 类目树中文翻译（已自证：首次翻、二次走缓存）

「上架编排」类目搜索框输入 `Cameras` 或 `Headphones`：

- [ ] 第一次：行显示 `中文名 · English`，右侧 `翻译中…`（后台在翻，约 5–15 秒）；
- [ ] 等十几秒再搜同一个词 → **直接出现中文且不再显示"翻译中"**（走磁盘缓存 `state\category_zh.json`）；
- [ ] 实测样本：`Action Cameras → 运动相机`、`Trail Cameras → 追踪相机`、`Cameras → 相机`；
- [ ] 用的是本机 `.env` 里的 **`DEEPSEEK_API_KEY`**；没有 Key 时会**明说"未配置 LLM Key，不编造译文"**。

### B4. AI 文案：大输入框 + 参数描述（已自证，通道如实标注）

「上架编排」→ 当前行 → **AI 文案**卡片 → 大输入框里贴：

```
微波炉 长 56cm 宽 45cm 高 32cm 功率 1000W 容量 25L 不锈钢内胆 带玻璃转盘 白色
```

→ 点「一键生成并填入内容」。

- [ ] 实测输出：标题形如 `X Microwave with 25L Capacity and 1000W Rated Power`、副标题、正式英文描述、盒子里有什么（`1 x …` 逐行）；
- [ ] 卡片显示 `llm=deepseek / deepseek-chat` 与**依据**（basis：哪些规格来自你输入的原话）；
- [ ] **关键校验**：不写功率时输出里**不会出现任何 W 数字**；描述里的尺寸/容量只能来自你输入的那段。

### B5. 变体（已自证：9 主题 + 导出展开 1 父 + N 子）

「上架编排」→ 变体卡片：

- [ ] 主题下拉 **9 项**：无变体（单品）/ 颜色 / 尺寸 / 颜色+尺寸 / 包装数量 / 颜色+包装数量 / 儿童年龄范围 / 年龄范围+颜色 / 自定义；
- [ ] 选「颜色 + 尺寸」→「变体 1」：Colour、Size、变体 SKU（留空自动）、变体条码 GS1（可留空）、**该变体图片 URL（每行一个，留空则用主图）**、右上角「删」；「+ 添加变体」可加多条；
- [ ] 尺寸有官方 **18 个**候选（受控下拉）；**颜色官方数据里没有候选清单**（只有"要求颜色"这个标记）→ 走自由输入，这是**数据事实、不是漏做**；
- [ ] 「校验」：选了主题却没有变体行 / 某行缺轴 / 两行值重复 → 报错（与后端同源）；
- [ ] 「导出装载表」：展开成 **1 父行 + N 变体子行**（实测 1+3，子行填 `Variant.attribute.*` 与变体自己的图片）。

### B6. 「一键回填」在真实新建商品表单上的命中率（**只有你能测**）

面板会**逐个字段报命中名**；**0 命中会明说**"页面不是新建表单 / 结构可能变了"。

- [ ] 在真实新建商品表单上跑一次，把**命中率**和它的原话发我。
- 说明：这是 DOM 硬匹配，**Portal 改版就会失效** —— 所以它必须如实报命中，而不是假装填上了。

---

## C. 边界的明说（避免误解）

- 抓取与销量推算依赖**公开接口**；出口被 Cloudflare 拦时 `transport=blocked`，此时有两条内建备选（`POST /crawler/ingest`、`state\ingest\*.json` 投放目录），**不会编数据**。
- 官方 API **不提供**：订单行明细/买家地址/物流、竞品价格与销量（只有一个 `benchmark_price`）、类目元数据、评论评分、对账单级对账 —— 这就是抓取层和扩展存在的原因。
- `selfcheck.ps1` 只报 Key 的**有/无**与**打码值**，任何情况下都不打印明文。

---

### B7. 对话（自然语言）与 CDP —— 需要你点/说的话

在 Hermes 对话里逐条说，把结果发我：

1. `帮我抓取 <随便一个 takealot 商品链接>` → 期望：调用抓取工具、结果里带 `transport`（cdp/dom/api/blocked）、**没有编造的字段**；
2. `帮我找一下我的订单` → 期望：走**订单只读**（**不能**被误判成抓取）；
3. `扒一下这个链接 <链接>` → 期望：同样走抓取（同义词识别）；
4. `帮我把这个 SKU 改成 199` → 期望：**拒绝改数据**，并指到界面里的改价入口；
5. `先别采集这个` → 期望：**不触发抓取**；
6. 打开 `%LOCALAPPDATA%\hermes\plugins\takealot-erp\state\agent_intent_audit.jsonl` → 期望：上面每句话都有一行（原话/命中规则/意图/工具）。

**CDP（可选，不点也能用）**
7. 扩展详情里点「启用 CDP 抓取」→ 应弹权限确认；允许后再抓一次，`transport` 应变成 `cdp`；
8. 不开 CDP 时抓取应走 `dom`/`api`，且**失败时明确标 blocked**（不谎报成功）。

