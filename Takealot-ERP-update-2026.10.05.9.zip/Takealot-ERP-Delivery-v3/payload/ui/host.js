/**
 * host.js —— `@hermes/plugin-sdk` 的 web 兼容层（形态 v3 · P1）
 *
 * 界面半边 ui/plugin.js（7 029 行 / 12 个模块）只认这 20 个符号：
 *   atom Button Codicon EmptyState Input PALETTE_AREA ROUTES_AREA SIDEBAR_NAV_AREA Skeleton
 *   STATUSBAR_AREAS Textarea cn host queryClient useMutation useQuery useValue requestTheme
 *   useTheme THEMES_AREA
 * 再加 register(ctx) 拿到的 ctx.{rest, storage, os, i18n, registerMany}。
 *
 * 这一层把它们**真的实现**（不是 stub）：数据走本机服务端的 REST + token，状态用真
 * nanostores，查询用真 react-query v5（UI 用了 isPending/isLoading/refetch/staleTime/
 * refetchInterval/invalidateQueries，精简版顶不了），主题真的写 CSS 变量。
 *
 * 铁律：plugin.js 里出现过的宿主形状必须原样保留（useTheme 返回的是 ThemeContextValue
 * 对象，不是 `{name}`；早年被 stub 的假形状骗过一次 → React #31）。
 * 交付时这一层是我们自己的代码：宿主 SDK 再怎么变，改这一个文件即可。
 */

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { jsx, jsxs } from 'react/jsx-runtime'
import {
  QueryClient,
  QueryClientProvider,
  atom,
  computed,
  useMutation,
  useQuery,
  useStore
} from './vendor/query.js'

// ── 区域常量（与宿主同名同值） ─────────────────────────────────────────────
export const ROUTES_AREA = 'routes'
export const SIDEBAR_NAV_AREA = 'sidebarNav'
export const PALETTE_AREA = 'palette'
export const STATUSBAR_AREAS = { left: 'statusBar.left', right: 'statusBar.right' }
export const THEMES_AREA = 'themes'

// ── 基础工具 ───────────────────────────────────────────────────────────────
export function cn(...args) {
  const out = []
  const push = v => {
    if (!v) return
    if (typeof v === 'string') out.push(v)
    else if (Array.isArray(v)) v.forEach(push)
    else if (typeof v === 'object') for (const k of Object.keys(v)) if (v[k]) out.push(k)
  }
  args.forEach(push)
  return out.join(' ')
}

export { atom, computed, useStore }
export const useValue = store => useStore(store)
export { useQuery, useMutation, QueryClientProvider }

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false, refetchOnWindowFocus: false, staleTime: 0 }
  }
})

// ── 事件总线：页面 → 壳（导航 / 提示） ─────────────────────────────────────
const bus = {
  handlers: new Set(),
  on(fn) {
    this.handlers.add(fn)
    return () => this.handlers.delete(fn)
  },
  emit(ev) {
    for (const h of [...this.handlers]) {
      try {
        h(ev)
      } catch (e) {
        /* 壳的问题不该把页面带崩 */
      }
    }
  }
}
export const __bus = bus

export const host = {
  navigate: to => bus.emit({ type: 'navigate', to: String(to || '') }),
  notify: n => bus.emit({ type: 'notify', kind: (n && n.kind) || 'info', message: String((n && (n.message || n.title)) || '') }),
  notifyError: (e, m) =>
    bus.emit({
      type: 'notify',
      kind: 'error',
      message: String(m || (e && (e.message || e.detail)) || e || '出错了')
    }),
  state: {}
}

// ── 主题（真写 CSS 变量；TKL 主题由页面自己通过 THEMES_AREA 注册进来） ──────
const DEFAULT_THEME = {
  name: 'erp-default',
  label: '默认',
  description: '未选主题时的基础配色',
  colors: {
    background: '#f6f7fb', foreground: '#0f172a', card: '#ffffff', cardForeground: '#0f172a',
    muted: '#eef2f7', mutedForeground: '#64748b', popover: '#ffffff', popoverForeground: '#0f172a',
    primary: '#4f46e5', primaryForeground: '#ffffff', secondary: '#eef2ff', secondaryForeground: '#3730a3',
    accent: '#0ea5e9', accentForeground: '#ffffff', border: '#e3e8f0', input: '#e3e8f0', ring: '#6366f1'
  }
}

const themeAtom = atom({ name: DEFAULT_THEME.name, themes: [DEFAULT_THEME], mode: 'system' })

const kebab = k => String(k).replace(/[A-Z]/g, m => '-' + m.toLowerCase())

export function applyTheme(theme) {
  const root = document.documentElement
  const colors = (theme && theme.colors) || {}
  for (const key of Object.keys(colors)) root.style.setProperty(`--${kebab(key)}`, String(colors[key]))
  root.dataset.erpTheme = (theme && theme.name) || 'default'
}

export function requestTheme(name) {
  const st = themeAtom.get()
  const found = st.themes.find(t => t && t.name === name)
  if (!found) return false
  setTheme(name)
  return true
}

export function setTheme(name) {
  const st = themeAtom.get()
  const found = st.themes.find(t => t && t.name === name) || DEFAULT_THEME
  themeAtom.set({ ...st, name: found.name })
  applyTheme(found)
  try {
    localStorage.setItem('takealot-erp:theme', found.name)
  } catch (e) {
    /* 隐私模式下写不了，忽略 */
  }
}

export function registerTheme(theme) {
  const st = themeAtom.get()
  if (!theme || !theme.name) return
  if (st.themes.some(t => t && t.name === theme.name)) return
  themeAtom.set({ ...st, themes: [...st.themes, theme] })
}

export function useTheme() {
  const st = useStore(themeAtom)
  const theme = useMemo(
    () => st.themes.find(t => t && t.name === st.name) || DEFAULT_THEME,
    [st.name, st.themes]
  )
  return {
    theme,                                   // DesktopTheme 对象（有 .colors）
    themeName: st.name,
    mode: st.mode,
    resolvedMode: st.mode === 'dark' ? 'dark' : 'light',
    renderedMode: st.mode === 'dark' ? 'dark' : 'light',
    availableThemes: st.themes,
    setTheme,
    setMode: m => themeAtom.set({ ...themeAtom.get(), mode: m || 'system' }),
    previewTheme: t => t && t.colors && applyTheme(t),
    clearThemePreview: () => applyTheme(theme)
  }
}

// ── 图标（把 codicon 名映射成内联 SVG，不引字体文件、不联网） ───────────────
const ICONS = {
  globe: [['circle', { cx: 12, cy: 12, r: 9 }], ['path', { d: 'M3 12h18M12 3c2.5 2.6 2.5 15.4 0 18M12 3c-2.5 2.6-2.5 15.4 0 18' }]],
  dashboard: [['rect', { x: 3, y: 3, width: 7.5, height: 7.5, rx: 1.5 }], ['rect', { x: 13.5, y: 3, width: 7.5, height: 4.5, rx: 1.5 }],
    ['rect', { x: 3, y: 13.5, width: 7.5, height: 7.5, rx: 1.5 }], ['rect', { x: 13.5, y: 10.5, width: 7.5, height: 10.5, rx: 1.5 }]],
  package: [['path', { d: 'M3 7.5 12 3l9 4.5v9L12 21l-9-4.5z' }], ['path', { d: 'M3 7.5 12 12l9-4.5M12 12v9' }]],
  'list-unordered': [['path', { d: 'M8 6h13M8 12h13M8 18h13' }], ['circle', { cx: 3.5, cy: 6, r: 1.3 }],
    ['circle', { cx: 3.5, cy: 12, r: 1.3 }], ['circle', { cx: 3.5, cy: 18, r: 1.3 }]],
  'credit-card': [['rect', { x: 2.5, y: 5, width: 19, height: 14, rx: 2 }], ['path', { d: 'M2.5 10h19' }]],
  inbox: [['path', { d: 'M3 13.5 6.5 5h11L21 13.5V19a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 19z' }], ['path', { d: 'M3 13.5h5l1.5 2.5h5l1.5-2.5h5' }]],
  rocket: [['path', { d: 'M12 2.5c3.5 2 5.5 6 5.5 10.5L12 17l-5.5-4c0-4.5 2-8.5 5.5-10.5z' }], ['circle', { cx: 12, cy: 9, r: 2 }],
    ['path', { d: 'M9 17.5 7.5 21M15 17.5 16.5 21' }]],
  pulse: [['path', { d: 'M2.5 12h4l2.5-6 4 12 2.5-6h6' }]],
  graph: [['path', { d: 'M4 20V10M10 20V4M16 20v-8M22 20H2' }]],
  shield: [['path', { d: 'M12 2.8 20 6v6c0 4.4-3.2 7.6-8 9.2-4.8-1.6-8-4.8-8-9.2V6z' }]],
  'settings-gear': [['circle', { cx: 12, cy: 12, r: 3.2 }],
    ['path', { d: 'M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4 5.5 18.5' }]],
  truck: [['rect', { x: 2.5, y: 6.5, width: 11, height: 9, rx: 1.5 }], ['path', { d: 'M13.5 10h4l4 3.5v2h-8' }],
    ['circle', { cx: 7, cy: 18, r: 2 }], ['circle', { cx: 17, cy: 18, r: 2 }]],
  beaker: [['path', { d: 'M6 3h12M9 3v6.5L5.5 17a3 3 0 0 0 2.7 4.3h7.6A3 3 0 0 0 18.5 17L15 9.5V3' }], ['path', { d: 'M7.5 14h9' }]]
}

export function Codicon({ name, size, className, title }) {
  const shapes = ICONS[name] || ICONS.package
  const px = typeof size === 'string' && size.endsWith('rem') ? size : `${parseFloat(size) || 14}px`
  return jsx('svg', {
    className: cn('erp-icon', className),
    width: px, height: px, viewBox: '0 0 24 24', fill: 'none',
    stroke: 'currentColor', strokeWidth: 1.6, strokeLinecap: 'round', strokeLinejoin: 'round',
    'aria-hidden': 'true', 'data-codicon': name,
    ...(title ? { 'aria-label': String(title) } : {}),
    children: shapes.map((s, i) => jsx(s[0], { key: i, ...s[1] }))
  })
}

// ── UI 原语（真组件，样式在 ui/app.css） ───────────────────────────────────
export function Button({ children, onClick, variant = 'solid', size = 'md', disabled, type = 'button', className, title }) {
  return jsx('button', {
    type, onClick, disabled: !!disabled, title,
    className: cn('erp-btn', `erp-btn--${variant}`, `erp-btn--${size}`, className),
    children
  })
}

export function Input({ value, onChange, placeholder, type = 'text', size = 'md', disabled, className, onKeyDown, autoFocus, readOnly, name, min, max, step }) {
  return jsx('input', {
    className: cn('erp-input', `erp-input--${size}`, className),
    value: value === undefined || value === null ? '' : value,
    onChange, placeholder, type, disabled: !!disabled, onKeyDown, autoFocus: !!autoFocus,
    readOnly: !!readOnly, name, min, max, step
  })
}

export function Textarea({ value, onChange, placeholder, rows = 3, className, disabled }) {
  return jsx('textarea', {
    className: cn('erp-textarea', className),
    value: value === undefined || value === null ? '' : value,
    onChange, placeholder, rows, disabled: !!disabled
  })
}

export function Skeleton({ className }) {
  return jsx('div', { className: cn('erp-skeleton', className), children: jsx('span', { className: 'erp-sr' , children: '加载中' }) })
}

export function EmptyState({ title, description, icon, action, children, className }) {
  return jsxs('div', {
    className: cn('erp-empty', className),
    children: [
      icon ? jsx('div', { className: 'erp-empty__icon', children: typeof icon === 'string' ? jsx(Codicon, { name: icon, size: '1.6rem' }) : icon }) : null,
      title ? jsx('div', { className: 'erp-empty__title', children: title }) : null,
      description ? jsx('div', { className: 'erp-empty__desc', children: description }) : null,
      action || children || null
    ]
  })
}

export function Badge({ children, tone, className }) {
  return jsx('span', { className: cn('erp-badge', tone ? `erp-badge--${tone}` : null, className), children })
}

// ── ctx：register(ctx) 拿到的门面 ──────────────────────────────────────────
export function makeRest(apiPrefix, token) {
  const url = path => `${apiPrefix}${path.startsWith('/') ? path : '/' + path}`
  // 令牌用**可变引用**持有：服务端每次启动都换令牌（装包/升级/重启都会），
  // 已开着的窗口拿的是旧的 → 401。这里收到 401 就自取新令牌重试一次，
  // 用户不用刷新页面、更不会丢表单。（跨站页面读不到那个 JSON，见 app.py /token 注释。）
  const ref = typeof token === 'object' && token !== null ? token : { value: token || '' }
  let healing = null
  const refreshToken = async () => {
    if (!healing) {
      healing = (async () => {
        try {
          const res = await fetch(url('/token'), { cache: 'no-store' })
          const body = await res.json()
          if (body && body.ok && typeof body.token === 'string') ref.value = body.token
          return body && body.ok ? body.token : null
        } catch (e) {
          return null
        } finally {
          setTimeout(() => { healing = null }, 3000)
        }
      })()
    }
    return healing
  }
  const call = async (path, init, _retried) => {
    const opts = init || {}
    const res = await fetch(url(path), {
      method: opts.method || 'GET',
      headers: { 'Content-Type': 'application/json', 'X-ERP-Token': ref.value || '', ...(opts.headers || {}) },
      body: opts.body === undefined ? undefined : JSON.stringify(opts.body)
    })
    const text = await res.text()
    let body = null
    try {
      body = text ? JSON.parse(text) : null
    } catch (e) {
      body = { ok: false, error: 'bad-json', detail: text.slice(0, 400) }
    }
    // 证据留给自检：真实打过哪些接口、结果码多少（客户机可自证，不用信自述）
    try {
      window.__erp.requests.push({ path, method: opts.method || 'GET', status: res.status, at: Date.now() })
    } catch (e) {
      /* __erp 没注入就算了 */
    }
    if (!res.ok) {
      // 令牌过期（服务重启过）→ 自愈一次，用户无感
      if (res.status === 401 && !_retried && path !== '/token') {
        const fresh = await refreshToken()
        if (fresh) return call(path, init, true)
      }
      const err = new Error((body && (body.detail || body.error)) || `HTTP ${res.status}`)
      err.status = res.status
      err.detail = body && body.detail
      err.staleToken = !!(body && body.staleToken)
      err.payload = body
      throw err
    }
    return body
  }
  return call
}

export function makeStorage(prefix = 'takealot-erp:') {
  return {
    get(key, fallback) {
      try {
        const raw = localStorage.getItem(prefix + key)
        if (raw === null) return fallback === undefined ? null : fallback
        try {
          return JSON.parse(raw)
        } catch (e) {
          return raw
        }
      } catch (e) {
        return fallback === undefined ? null : fallback
      }
    },
    set(key, value) {
      try {
        localStorage.setItem(prefix + key, typeof value === 'string' ? value : JSON.stringify(value))
      } catch (e) {
        /* 写不进去不致命 */
      }
    },
    remove(key) {
      try {
        localStorage.removeItem(prefix + key)
      } catch (e) {
        /* ignore */
      }
    }
  }
}

export function makeOs() {
  return {
    notify: n => host.notify({ kind: 'info', message: String((n && (n.title || n.message)) || '') }),
    openExternal: url => {
      const win = window.open(String(url), '_blank', 'noopener')
      return Promise.resolve(!!win)
    },
    writeClipboard: text =>
      (navigator.clipboard
        ? navigator.clipboard.writeText(String(text)).then(() => true).catch(() => false)
        : Promise.resolve(false)),
    // 浏览器里没有系统文件选择器：明确返回 null，让页面走"手工粘贴/上传"那条路，
    // 不要假装成功（零模拟数据这条纪律对界面同样成立）。
    pickOpenPath: () => Promise.resolve(null),
    platform: 'web'
  }
}

/**
 * 造 ctx（壳在挂载前调用一次，然后 import plugin.js 并 register）。
 * 同时返回注册表与订阅函数，壳靠它把页面/导航/状态条/命令面板渲染出来。
 */
export function createHostContext({ apiPrefix, token, tokenRef }) {
  const registrations = []
  const listeners = new Set()
  const i18nDict = { locale: 'zh-CN', dict: {} }

  const notifyRegistry = () => {
    for (const fn of [...listeners]) {
      try {
        fn(registrations)
      } catch (e) {
        /* ignore */
      }
    }
  }

  const ctx = {
    rest: makeRest(apiPrefix, tokenRef || token),
    storage: makeStorage(),
    os: makeOs(),
    i18n: {
      get locale() {
        return i18nDict.locale
      },
      register(dict) {
        if (dict && typeof dict === 'object') i18nDict.dict = { ...i18nDict.dict, ...dict }
        return true
      },
      t(key) {
        const table = i18nDict.dict[i18nDict.locale] || i18nDict.dict.en || {}
        return table[key] || key
      }
    },
    registerMany(items) {
      const out = []
      for (const item of items || []) {
        if (!item) continue
        registrations.push(item)
        out.push(item.id)
        if (item.area === THEMES_AREA && item.data) registerTheme(item.data)
      }
      notifyRegistry()
      return out
    }
  }

  return {
    ctx,
    registrations,
    subscribe(fn) {
      listeners.add(fn)
      return () => listeners.delete(fn)
    },
    byArea(area) {
      return registrations.filter(r => r && r.area === area)
    },
    themes() {
      return themeAtom.get().themes
    }
  }
}
