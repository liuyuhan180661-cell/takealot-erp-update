// react 本体：单独一个入口，保证全局只有一份 React 实例
// （多入口 esbuild --splitting 把共享代码抽成 chunk，壳与插件共用同一份，
//  否则 hooks 的 dispatcher 会串成 "Invalid hook call"）。
//
// ⚠ 必须**逐个具名导出**，不能写 `export * from 'react'`：react 19 只有 CJS 构建，
// esbuild 对 CJS 的 `export *` 只生成一个运行时命名空间对象、**不生成 export 语句**，
// 浏览器拿到的就是一个空模块（症状：别的模块报 "does not provide an export named ..."）。
export {
  Children,
  Fragment,
  StrictMode,
  Suspense,
  cloneElement,
  createContext,
  createElement,
  createRef,
  forwardRef,
  isValidElement,
  lazy,
  memo,
  startTransition,
  use,
  useActionState,
  useCallback,
  useContext,
  useDebugValue,
  useDeferredValue,
  useEffect,
  useId,
  useImperativeHandle,
  useInsertionEffect,
  useLayoutEffect,
  useMemo,
  useOptimistic,
  useReducer,
  useRef,
  useState,
  useSyncExternalStore,
  useTransition,
  version
} from 'react'
