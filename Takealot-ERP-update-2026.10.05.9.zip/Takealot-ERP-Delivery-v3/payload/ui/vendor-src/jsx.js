// plugin.js 用 jsx()/jsxs() 直调（仓库约定：界面半边不写 JSX 语法、不需要构建）
export { jsx, jsxs, Fragment } from 'react/jsx-runtime'
