// 数据层：真 react-query v5（UI 里用了 isPending/isLoading/refetch/staleTime/refetchInterval
// 与 queryClient.invalidateQueries，必须是真实现，不能拿精简版顶替）
export * from '@tanstack/react-query'
// 状态原子：真 nanostores（plugin.js 直接 atom() + useValue()）
export { atom, computed } from 'nanostores'
export { useStore } from '@nanostores/react'
