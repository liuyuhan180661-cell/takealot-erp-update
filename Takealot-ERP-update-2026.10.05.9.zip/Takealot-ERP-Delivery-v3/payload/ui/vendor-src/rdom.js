// 只有壳需要：把 React 树挂到页面上
export { createRoot, hydrateRoot } from 'react-dom/client'
