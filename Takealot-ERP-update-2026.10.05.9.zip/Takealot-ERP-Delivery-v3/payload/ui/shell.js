/**
 * shell.js —— 工作台的 web 壳（形态 v3 · P1）
 *
 * 职责只有"宿主原来替我们做的那几件事"：把 plugin.js 注册的四个区域渲染出来
 *   ROUTES_AREA      → 主区（Takealot 中台那一页，12 个模块都在它自己的左栏里）
 *   SIDEBAR_NAV_AREA → 顶栏里的页面项
 *   STATUSBAR_AREAS  → 顶栏右侧的状态条（待发货 / BuyBox 计数）
 *   PALETTE_AREA     → Ctrl/Cmd+K 命令面板
 *   THEMES_AREA      → 主题（真的写 CSS 变量）
 * 外加：toast、服务端状态、错误收集（客户机自检要证据，不看自述）。
 *
 * 不写 JSX 语法：与 plugin.js 一样的 jsx()/jsxs() 直调 → 客户机零构建、零 node。
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { jsx, jsxs } from 'react/jsx-runtime'
import { createRoot } from 'react-dom/client'
import {
  Codicon,
  PALETTE_AREA,
  QueryClientProvider,
  ROUTES_AREA,
  SIDEBAR_NAV_AREA,
  STATUSBAR_AREAS,
  THEMES_AREA,
  __bus,
  applyTheme,
  createHostContext,
  host,
  queryClient,
  setTheme,
  useTheme
} from './host.js'

const BOOT = window.__ERP__ || { token: '', port: 0, apiPrefix: '/api/plugins/takealot-erp', version: '?' }

// ── 证据收集（客户机自检、冒烟测试都读它） ────────────────────────────────
window.__erp = window.__erp || { requests: [], errors: [], version: BOOT.version, palette: 0, modules: [] }
window.addEventListener('error', e => window.__erp.errors.push(String((e && e.message) || e)))
window.addEventListener('unhandledrejection', e =>
  window.__erp.errors.push('unhandledrejection: ' + String((e && e.reason && (e.reason.message || e.reason)) || '')))
const __consoleError = console.error.bind(console)
console.error = (...args) => {
  try {
    window.__erp.errors.push(args.map(a => (a && a.message) || String(a)).join(' '))
  } catch (e) {
    /* ignore */
  }
  __consoleError(...args)
}

// ── 顶栏 ──────────────────────────────────────────────────────────────────
function ServerChip() {
  const [info, setInfo] = useState(null)
  const [err, setErr] = useState('')
  useEffect(() => {
    let alive = true
    const load = () =>
      fetch('/healthz')
        .then(r => r.json())
        .then(d => alive && (setInfo(d), setErr('')))
        .catch(e => alive && setErr(String(e)))
    load()
    const t = setInterval(load, 30000)
    return () => {
      alive = false
      clearInterval(t)
    }
  }, [])
  const dot = err ? 'bad' : info ? 'good' : 'wait'
  const label = err ? '服务端不可达' : info ? `服务端 ${info.version} · :${info.port}` : '读服务端…'
  return jsxs('span', {
    className: 'erp-chip',
    title: info ? `ERP_HOME ${info.erpHome}\n密钥库 ${info.atRestBackend}` : err,
    children: [jsx('span', { className: `erp-dot erp-dot--${dot}` }), label]
  })
}

function ThemeButton() {
  const t = useTheme()
  const mine = t.availableThemes.filter(x => x && x.name !== 'erp-default')
  if (!mine.length) return null
  const current = mine.find(x => x.name === t.themeName)
  const cycle = () => {
    const idx = mine.findIndex(x => x.name === t.themeName)
    setTheme(mine[(idx + 1) % mine.length].name)
  }
  return jsx('button', {
    type: 'button', className: 'erp-chip erp-chip--btn', onClick: cycle,
    title: '切换界面主题（Takealot 现代配色 / 默认）',
    children: '外观：' + (current ? current.label : '默认')
  })
}

function Header({ registry, onPalette }) {
  const navs = registry.byArea(SIDEBAR_NAV_AREA)
  const right = registry.byArea(STATUSBAR_AREAS.right)
  return jsxs('header', {
    className: 'erp-header',
    children: [
      jsxs('div', {
        className: 'erp-header__left',
        children: [
          jsx(Codicon, { name: 'globe', size: '1rem' }),
          jsx('span', { className: 'erp-brand', children: 'Takealot 中台' }),
          ...(navs.length
            ? [jsx('span', { className: 'erp-header__nav', children: navs.map(n => (n.data && (n.data.label || n.data.path)) || n.id).join(' · ') })]
            : [])
        ]
      }),
      jsxs('div', {
        className: 'erp-header__right',
        children: [
          ...right.map(r => jsx('span', { className: 'erp-header__status', 'data-area-item': r.id, children: r.render ? r.render() : null }, r.id)),
          jsx(ThemeButton, {}),
          jsx('button', {
            type: 'button', className: 'erp-chip erp-chip--btn', onClick: onPalette,
            children: '命令 ⌘K'
          }),
          jsx(ServerChip, {})
        ]
      })
    ]
  })
}

// ── 命令面板（Ctrl/Cmd+K） ────────────────────────────────────────────────
function Palette({ open, onClose, registry }) {
  const [q, setQ] = useState('')
  const inputRef = useRef(null)
  useEffect(() => {
    if (open) {
      setQ('')
      setTimeout(() => inputRef.current && inputRef.current.focus(), 0)
    }
  }, [open])
  const items = useMemo(() => {
    const cmds = registry.byArea(PALETTE_AREA).map(it => {
      const d = it.data || {}
      return { id: it.id, label: d.label || it.id, keywords: (d.keywords || []).join(' '), run: d.run }
    })
    const pages = registry.byArea(ROUTES_AREA).map(it => ({
      id: 'page:' + it.id, label: '打开 ' + ((it.data && it.data.path) || it.id), keywords: it.data ? it.data.path : '', run: () => host.navigate((it.data && it.data.path) || '/')
    }))
    const all = [...cmds, ...pages]
    window.__erp.palette = all.length
    const needle = q.trim().toLowerCase()
    if (!needle) return all
    return all.filter(c => (c.label + ' ' + c.keywords).toLowerCase().includes(needle))
  }, [q, registry, open])
  if (!open) return null
  const run = item => {
    try {
      if (item && typeof item.run === 'function') item.run()
    } catch (e) {
      host.notify({ kind: 'error', message: String((e && e.message) || e) })
    }
    onClose()
  }
  return jsxs('div', {
    className: 'erp-palette-scrim',
    onMouseDown: e => e.target === e.currentTarget && onClose(),
    children: [
      jsxs('div', {
        className: 'erp-palette',
        children: [
          jsx('input', {
            ref: inputRef, className: 'erp-palette__input', value: q, placeholder: '输入命令（如 takealot / 中台）…',
            onChange: e => setQ(e.target.value),
            onKeyDown: e => {
              if (e.key === 'Escape') onClose()
              if (e.key === 'Enter') run(items[0])
            }
          }),
          jsx('div', {
            className: 'erp-palette__list',
            children: items.length
              ? items.map(it =>
                  jsx('button', {
                    key: it.id, type: 'button', className: 'erp-palette__item', onClick: () => run(it),
                    children: it.label
                  })
                )
              : jsx('div', { className: 'erp-palette__empty', children: '没有匹配的命令' })
          })
        ]
      })
    ]
  })
}

// ── toast ─────────────────────────────────────────────────────────────────
const KIND_ICON = { info: 'beaker', warn: 'shield', warning: 'shield', error: 'shield', success: 'pulse' }

function Toasts({ items, onDismiss }) {
  return jsx('div', {
    className: 'erp-toasts',
    children: items.map(t =>
      jsxs('div', {
        className: `erp-toast erp-toast--${t.kind}`, role: 'status',
        children: [
          jsx(Codicon, { name: KIND_ICON[t.kind] || 'beaker', size: '0.9rem' }),
          jsx('span', { className: 'erp-toast__msg', children: t.message }),
          jsx('button', { type: 'button', className: 'erp-toast__x', onClick: () => onDismiss(t.id), children: '✕' })
        ]
      }, t.id)
    )
  })
}

function App({ registry }) {
  const [paletteOpen, setPaletteOpen] = useState(false)
  const [toasts, setToasts] = useState([])
  const [, force] = useState(0)

  const pushToast = useCallback((kind, message) => {
    if (!message) return
    const id = Math.random().toString(36).slice(2)
    setToasts(list => [...list, { id, kind: kind || 'info', message }].slice(-4))
    setTimeout(() => setToasts(list => list.filter(t => t.id !== id)), kind === 'error' ? 9000 : 5000)
  }, [])

  useEffect(() => {
    const offBus = __bus.on(ev => {
      if (ev.type === 'notify') pushToast(ev.kind, ev.message)
      if (ev.type === 'navigate') {
        // 只有一个页面，导航 = 把工作台切到前台（并把 hash 对齐，便于分享/刷新）
        try {
          window.location.hash = String(ev.to || '').replace(/^\//, '')
        } catch (e) {
          /* ignore */
        }
      }
    })
    const offReg = registry.subscribe(() => force(n => n + 1))
    const onKey = e => {
      if ((e.ctrlKey || e.metaKey) && String(e.key).toLowerCase() === 'k') {
        e.preventDefault()
        setPaletteOpen(o => !o)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => {
      offBus()
      offReg()
      window.removeEventListener('keydown', onKey)
    }
  }, [registry, pushToast])

  const pages = registry.byArea(ROUTES_AREA)
  return jsxs('div', {
    className: 'erp-app',
    children: [
      jsx(Header, { registry, onPalette: () => setPaletteOpen(true) }),
      jsx('main', {
        className: 'erp-main',
        children: pages.length
          ? pages.map(p => jsx('div', { className: 'erp-page', 'data-page': p.id, children: p.render ? p.render() : null }, p.id))
          : jsx('div', { className: 'erp-boot', children: '正在装载工作台…' })
      }),
      jsx(Palette, { open: paletteOpen, onClose: () => setPaletteOpen(false), registry }),
      jsx(Toasts, { items: toasts, onDismiss: id => setToasts(list => list.filter(t => t.id !== id)) })
    ]
  })
}

// ── 启动 ──────────────────────────────────────────────────────────────────
async function boot() {
  // 令牌放可变引用：服务重启换了令牌时，host.js 自愈后这里也跟着新
  const tokenRef = { value: BOOT.token || '' }
  const registry = createHostContext({ apiPrefix: BOOT.apiPrefix, token: BOOT.token, tokenRef })

  // 先应用上次选的主题（没有就用页面自己注册的 TKL 主题，那是我们产品的外观）
  let saved = null
  try {
    saved = localStorage.getItem('takealot-erp:theme')
  } catch (e) {
    /* ignore */
  }

  const root = createRoot(document.getElementById('root'))
  root.render(jsx(QueryClientProvider, { client: queryClient, children: jsx(App, { registry }) }))

  try {
    const mod = await import('./plugin.js')
    const plugin = (mod && (mod.default || mod.plugin)) || null
    if (!plugin || typeof plugin.register !== 'function') {
      throw new Error('plugin.js 没有导出带 register() 的默认对象')
    }
    plugin.register(registry.ctx)
    // 注册完成后：主题（保存过的优先，其次产品自带主题）
    const themes = registry.themes()
    const pick = (saved && themes.find(t => t.name === saved)) || themes.find(t => t.name !== 'erp-default')
    if (pick) setTheme(pick.name)
    else applyTheme(themes[0])
    window.__erp.ready = true
    window.__erp.plugin = { id: plugin.id, name: plugin.name }
  } catch (e) {
    window.__erp.errors.push('boot: ' + String((e && e.message) || e))
    root.render(
      jsxs('div', {
        className: 'erp-boot erp-boot--bad',
        children: [
          jsx('div', { children: '工作台装载失败' }),
          jsx('pre', { children: String((e && e.stack) || e) })
        ]
      })
    )
  }
}

boot()
