# Takealot ERP（工作台）—— 给 Codex 等宿主的项目指令片段

> 用法：把本文件内容**追加**到 `~/.codex/AGENTS.md`（全局）或项目根 `AGENTS.md`。
> 生成的命令：`erp mcp config --host codex --write`（只追加，不覆盖你已有内容）。

## 这是什么

本机有一个常驻的 Takealot ERP 工作台（本地服务 + 界面），通过 **MCP** 暴露一组 `erp_*` 工具。
**它不是网页 SaaS**：服务只监听 127.0.0.1，数据都在本机（`ERP_HOME`，默认 `~/.takealot-erp`）。

## 两条铁律

1. **读在对话，写在界面。** `erp_*` 工具全是只读；改价、改库存、上架、发 loadsheet 一律只在
   工作台界面里做 —— 工具表里没有这类工具，别试图绕。
2. **拿不到就说拿不到。** 工具返回 `ok:false` + 真实原因时照实转述，**不要编数字**、不要用
   「大概/通常」补值。

## 工具与用法

| 用户说 | 调用 |
|---|---|
| 打开工作台 / 打开中台 / 起 ERP | `erp_workbench_open`（服务没起就起，再开窗口；回话报端口与 URL） |
| 工作台在吗 / 端口多少 | `erp_status` |
| 自检 / 哪里不通 | `erp_doctor`（13 项，失败项带真实原因） |
| 今天几单 / 净利多少 | `erp_overview`、`erp_orders` |
| 库存 / 商品 / 缺货 | `erp_products` |
| 结算 / 对账 / 平台费 | `erp_finance` |
| 采集箱 / 跟卖池 | `erp_collection` |
| 出口通不通 / Key 对不对 | `erp_diagnostics` |
| 不确定用户指什么 | `erp_route`（传原话；命中给硬指令，没命中就说没命中，**不要猜**） |

参数：`storeId`（可选，默认用界面里当前店铺）、`limit`（订单/商品条数）。

## 定时任务 / 更新 / 抓取（**自然语言就是入口**）

定时任务**跑在客户机自己的常驻服务里**（不依赖 Hermes、不依赖我们任何一台机器；登录自启拉起 ——
Windows 是 HKCU Run，macOS 是 LaunchAgent）。
**agent 的能力是面板的超集**：面板能做的这里都要会，面板没有的这里也要有；
界面只是给「不熟提示词」的用户的手动兜底（写价/自动跟价必须在界面里授权与操作）。

| 用户说 | 动作 |
|---|---|
| 有什么定时任务 / 任务都在跑吗 / 上次巡检结果 | 工具 `erp_jobs`（或 `erp job list`）：排期、上次退出码与摘要、下次时间、**调度线程在不在跳（心跳）** |
| 现在就跑一次物流巡查 / 跑一下订单巡检 | 先 `erp job list` 拿 id（**不要猜 id**），再 `erp job run <id>` |
| 关掉巡检任务 / 把自动跟价启用 | `erp job disable\|enable <id>`。**写价任务（buybox-round）命令行开不了** —— 会被明确拒绝并要求先去工作台做一次授权；照它说的做，绝不绕过 |
| 检查更新 / 升级到最新版 | `erp update --check` 先看；有新版再 `erp update`（会校验 sha256，校验不过拒装；升级会重启服务，**先告知用户**） |
| 启动爬虫 / 定时抓取 / 刷新目录 | `erp job run crawl-pull`（只读：刷公开页/目录缓存，不动平台数据） |
| PO 单跟踪 / 货什么时候到仓 | `erp job run po-tracking`（只读：逾期 / 临期，daysToDue<0=逾期） |

装完即有的任务：`logistics-patrol`(08:30/15:30) · `buybox-report`(09:00) · `order-patrol`(08:00) ·
`po-tracking`(09:30) · `crawl-pull`(每 6 小时) · `buybox-round`(每 2 小时，**默认停用，需界面授权**)。
每轮都写证据文件 `ERP_HOME/logs/jobs/<id>/<时间>.md`；**「没有消息」只能等于「跑了没事」**，不等于「没跑成」。
退出码语义：`0`=无异常、**`1`=有要处理的事（不是故障）**、`>=2`=真失败。

## 命令行等价物（没有 MCP 时）

```bash
erp open            # 起服务 + 开窗口
erp open --no-window
erp status          # 退出码 0=在跑、3=没跑
erp doctor          # 13 项自检
erp route "把工作台打开"
erp job list                  # 定时任务：排期/上次结果/下次/心跳
erp job run logistics-patrol  # 手动跑一轮（退出码 0=没事 1=有要处理的事）
erp job enable|disable <id>   # 开关（写价任务命令行开不了，要先在界面授权）
erp update --check            # 看有没有新版本
erp update                    # 升级（sha256 校验不过拒装；会重启服务）
erp stop
```

## 排障

1. 先 `erp doctor`，修它报 FAIL 的那一项
2. 服务没起：`erp open --no-window`，再看 `~/.takealot-erp/logs/server.out` 尾部
3. `ok:true` 但没数据 = 真的没数据（没绑店铺/没订单），不是坏了
