/**
 * Takealot ERP —— 宿主侧「启动入口」插件（形态 v3）
 *
 * 定位：**只做入口，不做业务界面**。业务界面在独立窗口里（无地址栏的 --app 窗口），
 * 这里的侧栏项只负责：看状态（在线/端口/版本/最近谁连过）+ 一键打开工作台。
 *
 * 为什么不在对话里嵌业务界面：① 客户明确要独立窗口的观感；② 服务端是常驻的，界面
 * 不该跟着宿主进程生死；③ 少一层宿主 SDK 依赖，宿主升级不带着业务界面一起碎。
 *
 * 通信：服务端有一组**无 token 的窄端点**（/healthz、/launcher/summary、/launcher/open），
 * 只回本机回环、只返回端口/版本这类非敏感信息、不含密钥与店铺数据；写操作（改价/上架）永远
 * 只在独立窗口的界面里做。宿主侧栏拿不到 token，也不需要拿。
 *
 * 安装位置（macOS）：~/.hermes/desktop-plugins/takealot-erp-launcher/plugin.js
 *                 （Windows）：%LOCALAPPDATA%\hermes\desktop-plugins\takealot-erp-launcher\plugin.js
 * 装完跑一次 `erp plugin --host hermes`（或界面里 reload 插件）即可看到侧栏项。
 */

import { useEffect, useState } from 'react'
import { jsx, jsxs } from 'react/jsx-runtime'
import {
  Button,
  Codicon,
  EmptyState,
  PALETTE_AREA,
  ROUTES_AREA,
  SIDEBAR_NAV_AREA,
  cn,
  host
} from '@hermes/plugin-sdk'

const ID = 'takealot-erp-launcher'
const PAGE_PATH = '/takealot'
const PORT_CANDIDATES = [18791, 18792, 18793, 18794, 18795, 18796, 18797, 18798, 18799, 18800]

// ── 与服务端对话（自动认端口：候选表里第一个应答的就是它） ──────────────────
async function findBase() {
  for (const port of PORT_CANDIDATES) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/launcher/summary`, { cache: 'no-store' })
      if (res.ok) {
        const data = await res.json()
        if (data && data.service === 'takealot-erp') return { base: `http://127.0.0.1:${port}`, data }
      }
    } catch (e) {
      /* 这个端口没有 —— 试下一个 */
    }
  }
  return { base: null, data: null }
}

async function askOpen(base, mode) {
  const res = await fetch(`${base}/launcher/open`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-ERP-Launcher': '1' },
    body: JSON.stringify({ mode })
  })
  return res.json()
}

function Row({ label, value }) {
  return jsxs('div', {
    className: 'flex items-baseline justify-between gap-3 py-1 text-[0.75rem]',
    children: [
      jsx('span', { className: 'text-(--ui-text-quaternary)', children: label }),
      jsx('span', { className: 'tabular-nums', children: value })
    ]
  })
}

function LauncherPanel() {
  const [state, setState] = useState({ loading: true })
  const [busy, setBusy] = useState('')

  const refresh = async () => {
    setState({ loading: true })
    const { base, data } = await findBase()
    setState({ loading: false, base, data })
  }

  useEffect(() => {
    refresh()
    const t = setInterval(refresh, 20000)
    return () => clearInterval(t)
  }, [])

  const open = async mode => {
    if (!state.base) return
    setBusy(mode)
    try {
      const r = await askOpen(state.base, mode)
      host.notify({ kind: r && r.ok ? 'info' : 'warning',
                    message: r && r.ok ? `工作台窗口已打开（${r.url}）` : `打开失败：${(r && r.error) || '未知原因'}` })
    } catch (e) {
      host.notify({ kind: 'error', message: String((e && e.message) || e) })
    }
    setBusy('')
  }

  const d = state.data
  const online = !!d

  return jsxs('div', {
    className: 'flex h-full min-h-0 flex-col gap-3 p-4 text-sm',
    children: [
      jsxs('div', {
        className: 'flex items-center gap-2',
        children: [
          jsx(Codicon, { name: 'globe', size: '1rem' }),
          jsx('span', { className: 'text-[0.9375rem] font-semibold', children: 'Takealot ERP 工作台' }),
          jsx('span', {
            className: cn('ml-1 inline-block h-2 w-2 rounded-full', online ? 'bg-green-500' : 'bg-amber-500')
          }),
          jsx('span', {
            className: 'text-[0.75rem] text-(--ui-text-quaternary)',
            children: online ? '服务端在线' : (state.loading ? '检查中…' : '服务端未启动')
          })
        ]
      }),

      online
        ? jsxs('div', {
            className: 'rounded border border-(--ui-stroke-secondary) p-3',
            children: [
              jsx(Row, { label: '地址', value: d.port ? `http://127.0.0.1:${d.port}/` : '—' }),
              jsx(Row, { label: '版本', value: `${d.version || '?'}（核心 ${d.coreVersion || '?'}）` }),
              jsx(Row, { label: '已运行', value: `${Math.floor((d.uptimeSec || 0) / 60)} 分钟` }),
              jsx(Row, { label: '密钥库', value: d.atRestBackend || '—' }),
              jsx(Row, { label: '前端资产', value: `${d.uiAssets || 0} 个文件` }),
              jsx(Row, {
                label: '连过的 agent',
                value: (d.audit && d.audit.clients && d.audit.clients.length) ? d.audit.clients.join('、') : '还没有'
              }),
              jsx(Row, { label: '工具调用次数', value: String((d.audit && d.audit.calls) || 0) })
            ]
          })
        : jsx(EmptyState, {
            title: '工作台没在跑',
            description: '在对话里说「打开工作台」（agent 会调 erp_workbench_open），或双击桌面上的「Takealot ERP 工作台」。',
            className: 'py-3'
          }),

      jsxs('div', {
        className: 'flex flex-wrap items-center gap-2',
        children: [
          jsx(Button, {
            size: 'sm', variant: 'solid', disabled: !online || busy === 'app',
            onClick: () => open('app'), children: busy === 'app' ? '正在打开…' : '打开工作台'
          }),
          jsx(Button, {
            size: 'sm', variant: 'outline', disabled: !online || busy === 'browser',
            onClick: () => open('browser'), children: '用浏览器打开'
          }),
          jsx(Button, { size: 'sm', variant: 'ghost', onClick: refresh, children: '刷新' })
        ]
      }),

      jsx('div', {
        className: 'mt-auto text-[0.6875rem] text-(--ui-text-quaternary)',
        children: '业务界面在独立窗口里（不在对话内）。改价 / 改库存 / 上架只在那个界面里做 —— 对话侧的工具都是只读的。'
      })
    ]
  })
}

export default {
  id: ID,
  name: 'Takealot ERP 入口',
  description: '一键打开 Takealot ERP 工作台（常驻服务端 + 独立窗口）。业务界面不在对话里。',
  register(ctx) {
    ctx.registerMany([
      {
        id: 'page',
        area: ROUTES_AREA,
        data: { path: PAGE_PATH },
        render: () => jsx(LauncherPanel, {})
      },
      {
        id: 'nav',
        area: SIDEBAR_NAV_AREA,
        order: 41,
        data: { path: PAGE_PATH, label: 'Takealot ERP', codicon: 'globe' }
      },
      {
        id: 'open',
        area: PALETTE_AREA,
        data: {
          id: 'takealot.launcher',
          label: 'Takealot: 打开工作台',
          keywords: ['takealot', 'erp', '工作台', '启动'],
          run: () => host.navigate(PAGE_PATH)
        }
      }
    ])
  }
}
