#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""定时任务脚本共用的小客户端：只跟**本机 v3 服务**说话（127.0.0.1 + X-ERP-Token）。

规则（都是踩出来的）：
  · 本机回环必须绕过系统代理（Clash/公司代理会把 127.0.0.1 拦成 502）；
  · 家目录 Windows 是 %LOCALAPPDATA%\TakealotERP，macOS/Linux 是 ~/.takealot-erp，也认 ERP_HOME；
  · **零模拟**：取不到就返回 ok=False + 真实原因，绝不编数字。
"""
from __future__ import annotations

import json
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

API = "/api/plugins/takealot-erp"


def erp_home() -> str | None:
    win_default = os.path.join(os.environ.get("LOCALAPPDATA") or
                               os.path.join(os.path.expanduser("~"), "AppData", "Local"), "TakealotERP")
    for cand in (os.environ.get("ERP_HOME"), os.environ.get("TAKEALOT_ERP_HOME"),
                 win_default, os.path.join(os.path.expanduser("~"), ".takealot-erp")):
        if cand and os.path.exists(os.path.join(cand, "runtime.json")):
            return cand
    return None


class Client:
    def __init__(self, home: str | None = None):
        self.home = home or erp_home()
        if not self.home:
            raise RuntimeError("找不到 ERP 家目录（没装，或 ERP_HOME 没指对）")
        with open(os.path.join(self.home, "runtime.json"), encoding="utf-8") as fh:
            info = json.load(fh) or {}
        self.port = int(info.get("port") or 0)
        self.token = info.get("token") or ""
        if not self.port:
            raise RuntimeError("runtime.json 里没有端口（服务没起过？）")

    def call(self, method: str, path: str, *, query: dict | None = None, body: dict | None = None,
             store_id: str = "", timeout: float = 180):
        import urllib.error
        import urllib.parse
        import urllib.request
        q = dict(query or {})
        if store_id:
            q.setdefault("storeId", store_id)
        url = "http://127.0.0.1:{0}{1}{2}".format(self.port, API, path)
        if q:
            url += "?" + urllib.parse.urlencode({k: v for k, v in q.items() if v not in (None, "")})
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, method=method.upper(),
                                     headers={"X-ERP-Token": self.token, "Content-Type": "application/json"})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        try:
            with opener.open(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8") or "{}")
        except urllib.error.HTTPError as exc:
            try:
                return json.loads(exc.read().decode("utf-8") or "{}")
            except Exception:
                return {"ok": False, "error": "HTTP {0}".format(exc.code)}
        except Exception as exc:
            return {"ok": False, "error": "{0}: {1}（服务没起？出口代理把 127.0.0.1 拦了？）".format(type(exc).__name__, exc)}

    # 常用只读
    def settings(self) -> dict:
        return self.call("GET", "/settings") or {}

    def active_store(self) -> str:
        return str(self.settings().get("activeStoreId") or "")

    def orders(self, store_id="", limit=200) -> dict:
        return self.call("GET", "/orders/live", query={"limit": limit}, store_id=store_id) or {}

    def fulfilment(self, store_id="", limit=200) -> dict:
        return self.call("GET", "/fulfilment", query={"limit": limit}, store_id=store_id) or {}


def money(v) -> str:
    try:
        return "R{0:,.2f}".format(float(v))
    except Exception:
        return "R?"


def die(msg: str, code: int = 2):
    """**不假装成功**：拿不到数据就用非零退出码 + 真实原因（调度器会把它记成失败/离线）。"""
    print(msg)
    raise SystemExit(code)
