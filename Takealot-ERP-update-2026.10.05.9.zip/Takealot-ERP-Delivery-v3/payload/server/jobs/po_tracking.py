#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PO / 送仓单跟踪（只读）—— 定时任务：盯"货什么时候该到仓、有没有逾期"。

数据来自本机服务 /fulfilment（stages.inbound/outbound.pos[]）。
口径：actionable = 未发运且未取消；daysToDue < 0 = 已逾期。
用法：  <venv python> po_tracking.py [--store <id>] [--days N]
退出码：0 = 没有逾期/临期；1 = 有逾期或 N 天内到期；>=2 = 读数失败。
"""
from __future__ import annotations

import argparse
import datetime as dt
import sys

import _erpclient as C


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", default="")
    ap.add_argument("--days", type=int, default=7)
    args = ap.parse_args()

    try:
        cli = C.Client()
    except Exception as exc:
        C.die("读不到本机服务：{0}".format(exc))

    store = args.store or cli.active_store()
    data = cli.fulfilment(store_id=store)
    if not data or data.get("ok") is False or not data.get("stages"):
        C.die("送仓数据读不到：{0}".format((data or {}).get("error") or "接口没有返回 stages"))

    pos = []
    for stage in ("inbound", "outbound"):
        for row in ((data.get("stages") or {}).get(stage) or {}).get("pos") or []:
            row = dict(row)
            row["_stage"] = stage
            pos.append(row)

    overdue = [p for p in pos if isinstance(p.get("daysToDue"), (int, float)) and p["daysToDue"] < 0]
    soon = [p for p in pos if isinstance(p.get("daysToDue"), (int, float)) and 0 <= p["daysToDue"] <= args.days]
    actionable = [p for p in pos if p.get("actionable")]

    print("PO / 送仓单跟踪 · {0}".format(dt.datetime.now().strftime("%Y-%m-%d %H:%M")))
    print("店铺：{0}｜共 {1} 张 PO（要动作 {2} 张）".format(data.get("storeName") or store or "汇总",
                                                     len(pos), len(actionable)))
    print()
    print("一、已逾期：{0} 张".format(len(overdue)))
    for p in sorted(overdue, key=lambda x: x.get("daysToDue") or 0)[:15]:
        print("    - {0}｜{1}｜到期 {2}（逾期 {3} 天）｜{4}".format(
            p.get("po"), p.get("stateLabel") or p.get("state"), str(p.get("dueDate"))[:10],
            abs(int(p.get("daysToDue") or 0)), p.get("_stage")))
    print()
    print("二、{0} 天内到期：{1} 张".format(args.days, len(soon)))
    for p in sorted(soon, key=lambda x: x.get("daysToDue") or 0)[:15]:
        print("    - {0}｜{1}｜到期 {2}（还剩 {3} 天）｜{4}".format(
            p.get("po"), p.get("stateLabel") or p.get("state"), str(p.get("dueDate"))[:10],
            int(p.get("daysToDue") or 0), p.get("_stage")))
    if not pos:
        print("（接口返回 0 张 PO —— 如果你确实有送仓单，那是读数问题，不是「没有」）")
    print()
    problems = len(overdue) + len(soon)
    print("结论：{0}".format("有 {0} 张要马上处理".format(problems) if problems else "没有逾期/临期"))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
