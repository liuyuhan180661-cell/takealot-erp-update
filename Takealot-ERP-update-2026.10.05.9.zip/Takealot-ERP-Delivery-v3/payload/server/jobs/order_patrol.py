#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""订单巡检（只读）—— 定时任务：每天早上看一眼"有没有该我动手的单"。

回答三件事（数字全部来自本机服务的 /orders/live，缺数据就说缺）：
  一、待发货 / 需要我处理的（状态属于平台侧要动作的）
  二、亏钱的单（净利 < 0）—— 这类单每卖一单亏一单，必须让人看见
  三、窗口内汇总（单量 / 营收 / 净利 / 退货）

用法：  <ERP_HOME 的 venv python> order_patrol.py [--store <id>] [--days N] [--limit N]
退出码：0 = 没发现要处理的；1 = 有要处理/要看的（待发货、亏损单、退货）；>=2 = 读数失败。
"""
from __future__ import annotations

import argparse
import datetime as dt
import sys

import _erpclient as C


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", default="")
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--limit", type=int, default=300)
    args = ap.parse_args()

    try:
        cli = C.Client()
    except Exception as exc:
        C.die("读不到本机服务：{0}".format(exc))

    store = args.store or cli.active_store()
    data = cli.orders(store_id=store, limit=args.limit)
    if not data or data.get("ok") is False or not (data.get("items") is not None):
        C.die("订单读不到：{0}".format((data or {}).get("error") or "接口没有返回 items（这不是「没有订单」，是读数问题）"))

    items = data.get("items") or []
    since = dt.datetime.now().astimezone() - dt.timedelta(days=args.days)
    rows = []
    for it in items:
        try:
            when = dt.datetime.fromisoformat(str(it.get("orderDate") or "").replace("Z", "+00:00"))
        except Exception:
            when = None
        if when and when < since:
            continue
        rows.append(it)

    todo_states = ("New Lead Time Order", "Confirmed Shipment", "Preparing for Customer", "Inter DC Transfer")
    todo = [r for r in rows if str(r.get("saleStatus") or "") in todo_states]
    losses = []
    for r in rows:
        try:
            if float(r.get("net") or 0) < 0:
                losses.append(r)
        except Exception:
            pass
    returned = [r for r in rows if "return" in str(r.get("saleStatus") or "").lower()]
    gross = sum(float(r.get("gross") or 0) for r in rows)
    net = sum(float(r.get("net") or 0) for r in rows)

    print("订单巡检 · {0} · 窗口 {1} 天{2}".format(dt.datetime.now().strftime("%Y-%m-%d %H:%M"), args.days,
                                              "" if store else "（全部店铺）"))
    print("店铺：{0}".format(data.get("storeName") or store or "全部店铺（汇总）"))
    print()
    print("一、要处理的：{0} 单".format(len(todo)))
    for r in todo[:12]:
        print("    - {0}｜{1}｜{2}｜{3}".format(r.get("orderId"), r.get("saleStatus"), r.get("title") or r.get("sku"),
                                              C.money(r.get("gross"))))
    if len(todo) > 12:
        print("    （还有 {0} 单，去工作台「订单与净利」看全量）".format(len(todo) - 12))
    print()
    print("二、亏损单：{0} 单".format(len(losses)))
    for r in losses[:12]:
        print("    - {0}｜{1}｜{2}｜净 {3}".format(r.get("orderId"), r.get("title") or r.get("sku"),
                                              C.money(r.get("gross")), C.money(r.get("net"))))
    print()
    print("三、窗口汇总：{0} 单（{1} 件）｜营收 {2}｜净利 {3}｜退货 {4} 单".format(
        len(rows), sum(int(r.get("quantity") or 0) for r in rows), C.money(gross), C.money(net), len(returned)))
    problems = len(todo) + len(losses)
    print()
    print("结论：{0}".format("有 {0} 项要处理".format(problems) if problems else "没有要马上处理的"))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
