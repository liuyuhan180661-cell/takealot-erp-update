#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""平台相关的"打开窗口"能力 —— app.py（服务端）与 cli.py（命令行）共用这一份。

为什么要单独一个文件：服务端要能自己开窗口（给宿主的侧栏入口用），命令行也要能；
两份实现必然走岔，所以只留一份。
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import webbrowser
from pathlib import Path


def _windows_session_id() -> int | None:
    """当前进程的 Windows 会话号；非 Windows 返回 None。

    为什么关心它：ssh/服务宿主把进程起在**会话 0**（Services）里，那里起的 GUI 进程
    （Edge/Chrome 的 --app 窗口）**用户永远看不见** —— 表现是「服务说已打开，屏幕上什么都没有」。
    真机（Win10 + ssh 装完）踩过：连续 6 次点击都 `opened: true` 而窗口开在会话 0。
    """
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        pid = ctypes.windll.kernel32.GetCurrentProcessId()
        sid = ctypes.c_ulong(0)
        if ctypes.windll.kernel32.ProcessIdToSessionId(pid, ctypes.byref(sid)):
            return int(sid.value)
    except Exception:
        pass
    return None


def _launch_in_user_session(cmdline: str) -> bool:
    """把一条命令投到**已登录用户的交互式会话**里执行（Windows）。

    做法：建一个一次性计划任务（`/it` = 交互式，当前用户即可，不要管理员）→ 运行 → 删掉。
    这是从会话 0 里唯一不依赖管理员权限就能把 GUI 送到用户桌面的办法。
    """
    import time
    import uuid

    name = "TakealotERP-OpenWindow-" + uuid.uuid4().hex[:8]
    try:
        subprocess.run(["schtasks", "/create", "/tn", name, "/tr", cmdline, "/sc", "once",
                        "/st", "23:59", "/it", "/f"], capture_output=True, timeout=30)
        run = subprocess.run(["schtasks", "/run", "/tn", name], capture_output=True, timeout=30)
        time.sleep(1.5)
        return run.returncode == 0
    except Exception:
        return False
    finally:
        try:
            subprocess.run(["schtasks", "/delete", "/tn", name, "/f"], capture_output=True, timeout=20)
        except Exception:
            pass


def _win_browser_paths() -> list[tuple[str, str]]:
    """Windows 上 Edge/Chrome **不在 PATH** 里（`shutil.which` 找不到）——

    必须按标准安装位置找，否则 `--app` 档位在 Windows 上永远回落成普通浏览器窗口（真机踩过）。
    """
    pf = os.environ.get("ProgramFiles") or r"C:\Program Files"
    pf86 = os.environ.get("ProgramFiles(x86)") or r"C:\Program Files (x86)"
    local = os.environ.get("LOCALAPPDATA") or ""
    table = [
        ("Microsoft Edge", [os.path.join(pf86, r"Microsoft\Edge\Application\msedge.exe"),
                            os.path.join(pf, r"Microsoft\Edge\Application\msedge.exe")]),
        ("Google Chrome", [os.path.join(pf, r"Google\Chrome\Application\chrome.exe"),
                           os.path.join(pf86, r"Google\Chrome\Application\chrome.exe")] +
                          ([os.path.join(local, r"Google\Chrome\Application\chrome.exe")] if local else [])),
        ("Brave", [os.path.join(pf, r"BraveSoftware\Brave-Browser\Application\brave.exe"),
                   os.path.join(pf86, r"BraveSoftware\Brave-Browser\Application\brave.exe")]),
    ]
    found: list[tuple[str, str]] = []
    for label, cands in table:
        for p in cands:
            if p and Path(p).is_file():
                found.append((label, p))
                break
    return found


def browser_candidates() -> list[tuple[str, str]]:
    """[(显示名, 路径)] —— 优先 Chromium 系（`--app` 才好用，无地址栏独立窗口）。"""
    if sys.platform == "darwin":
        found = []
        for label, path in (("Google Chrome", "/Applications/Google Chrome.app"),
                            ("Microsoft Edge", "/Applications/Microsoft Edge.app"),
                            ("Brave", "/Applications/Brave Browser.app"),
                            ("Chromium", "/Applications/Chromium.app")):
            if Path(path).exists():
                found.append((label, path))
        return found
    if sys.platform == "win32":
        found = _win_browser_paths()
        if not found:                      # 兜底：真在 PATH 里的（绿色版/自己加的）
            for label, n in (("Microsoft Edge", "msedge.exe"), ("Google Chrome", "chrome.exe")):
                p = shutil.which(n)
                if p:
                    found.append((label, p))
        return found
    found = []
    for label, names in (("Google Chrome", ["google-chrome", "google-chrome-stable"]),
                         ("Chromium", ["chromium", "chromium-browser"]),
                         ("Microsoft Edge", ["microsoft-edge"])):
        for n in names:
            p = shutil.which(n)
            if p:
                found.append((label, p))
    return found


def open_window(url: str, mode: str = "browser") -> dict:
    """打开工作台窗口。mode='app' → Chromium --app（无地址栏、独立任务栏项）；装不了就回落默认浏览器。

    Windows 会话 0 特判：那里起的 GUI 用户看不见，绝不能谎报成功 ——
    改成**投到已登录用户的交互式会话**里开；投不进去就如实回报 + 给出可操作提示。
    """
    if sys.platform == "win32" and _windows_session_id() == 0:
        for label, path in browser_candidates():
            if _launch_in_user_session('"{0}" --app={1}'.format(path, url) if mode == "app" else '"{0}" {1}'.format(path, url)):
                return {"opened": True, "mode": mode, "browser": label, "session": "interactive",
                        "note": "服务端在会话 0；窗口已投到你的登录会话打开"}
        return {"opened": False, "mode": mode, "reason": "session-0", "url": url,
                "hint": ("服务端跑在非交互会话（会话 0），它开的窗口不会显示在你的桌面上。"
                         "请双击桌面的「Takealot ERP 工作台」(或 %LOCALAPPDATA%\\TakealotERP\\start-workbench.cmd) "
                         "把工作台起到你的登录会话里。")}
    if mode == "app":
        for label, path in browser_candidates():
            try:
                if sys.platform == "darwin":
                    subprocess.Popen(["open", "-na", path, "--args", "--app=" + url])
                else:
                    subprocess.Popen([path, "--app=" + url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return {"opened": True, "mode": "app", "browser": label}
            except Exception:
                continue
        mode = "browser"
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", url])
        else:
            webbrowser.open(url)
        return {"opened": True, "mode": "browser"}
    except Exception as exc:
        return {"opened": False, "mode": mode, "error": str(exc), "url": url}
