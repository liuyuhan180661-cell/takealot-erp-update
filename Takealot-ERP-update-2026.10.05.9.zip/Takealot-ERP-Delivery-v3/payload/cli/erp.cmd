@echo off
rem Takealot ERP workbench - Windows command launcher (twin of cli/erp on macOS).
rem
rem   erp cmd            -> where ERP_HOME / how to use it
rem   erp cmd "open"     -> start the server and open the workbench
rem   erp cmd status     -> is it running, on which port
rem   erp cmd doctor     -> 13-item end-to-end self-check
rem
rem Pure ASCII on purpose (cmd.exe code pages mangle non-ASCII batch files).

setlocal
set "HERE=%~dp0"
set "HOME_DIR=%HERE%.."
set "PY=%HOME_DIR%\venv\Scripts\python.exe"
set "CLI=%HOME_DIR%\server\cli.py"

if not exist "%CLI%" (
  echo ERP_HOME looks wrong: cannot find "%CLI%"
  echo Run this launcher from the installed copy ^(ERP_HOME\cli\erp.cmd^).
  exit /b 1
)

if not exist "%PY%" set "PY=python"

"%PY%" "%CLI%" --erp-home "%HOME_DIR%" %*
exit /b %ERRORLEVEL%
