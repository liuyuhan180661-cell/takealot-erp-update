#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v2（Hermes 插件两半）→ v3（常驻服务端）店铺与配置迁移。

    <venv python> migrate_v2_state.py --from "%LOCALAPPDATA%\\hermes\\plugins\\takealot-erp\\state" [--dry-run]

做什么：
  · ``stores.json``：按 store id 合并店铺行；**带密钥的那一份优先**（v2 里 dpapi: 密文在
    同一台机器、同一个 Windows 用户下可以直接被 v3 解开 —— DPAPI 就是绑到用户账号的，
    所以不需要用户重新粘贴 Key，也不会有任何明文经过这个脚本）。
  · 其余本地数据按白名单搬：规则 / 定价策略 / 类目中文名 / 采集箱 / 草稿箱 /
    竞品快照 / 跟价账本 / 出价日志 / 速度缓存。
  · **不搬** ``repricing_watch.json``（自动跟价授权）：换版后自动写价一律回到"未授权"，
    要开必须重新明确授权一次 —— 这是红线，不能靠迁移悄悄继承。

输出只有店铺名与"有没有密钥"，**永不打印密钥本身**。
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass

#: 按白名单搬的本地数据（旧文件名 → 新文件名，同名即原样）
COPY_FILES = ("rules.json", "pricing_strategy.json", "category_zh.json", "collection.json",
              "drafts.json", "competitors.json", "price_log.json", "offer_writes.json",
              "ai_analysis.json", "velocity_cache", "offers_cache", "repricing_watch_log.md",
              "ingest", "ingest_log.json")
#: 明确**不搬**的：授权状态与审计（换版后必须重新授权）
NEVER = ("repricing_watch.json",)


def key_kind(raw) -> str:
    s = str(raw or "")
    if s.startswith("dpapi:"):
        return "dpapi"
    if s.startswith("kc:"):
        return "keychain"
    return "plain" if s else "none"


def merge_stores(old: dict, new: dict) -> tuple[dict, list[str]]:
    """按 id 合并；同一家店两处都有时，**取带密钥的那一份**。"""
    by_id: dict[str, dict] = {}
    for row in (new.get("stores") or []):
        if isinstance(row, dict) and row.get("id"):
            by_id[str(row["id"])] = row
    notes: list[str] = []
    for row in (old.get("stores") or []):
        if not isinstance(row, dict) or not row.get("id"):
            continue
        sid = str(row["id"])
        cur = by_id.get(sid)
        if cur is None:
            by_id[sid] = row
            notes.append("加入店铺 {0}（{1}，密钥 {2}）".format(sid, row.get("name"), key_kind(row.get("_key"))))
        elif key_kind(row.get("_key")) != "none" and key_kind(cur.get("_key")) == "none":
            by_id[sid] = row
            notes.append("店铺 {0} 用旧配置覆盖（旧的有密钥）".format(sid))
    keyed = [s for s in by_id.values() if key_kind(s.get("_key")) != "none"]
    active = str(new.get("activeStoreId") or "")
    old_active = str(old.get("activeStoreId") or "")
    # 当前店的选择顺序：v2 当时用的那家（且它真有密钥）→ v3 现在的（且有密钥）→ 任一有密钥的 → 第一行
    if old_active in by_id and key_kind(by_id[old_active].get("_key")) != "none":
        active = old_active
    elif active not in by_id or key_kind(by_id.get(active, {}).get("_key")) == "none":
        active = (keyed[0]["id"] if keyed else (active or next(iter(by_id), "")))
    return {"activeStoreId": active, "stores": list(by_id.values())}, notes


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="src", required=True, help="v2 的 state 目录")
    ap.add_argument("--to", dest="dst", default="", help="v3 的 ERP_HOME（默认按平台惯例找）")
    ap.add_argument("--dry-run", action="store_true", help="只报会做什么，不落盘")
    args = ap.parse_args()

    src = Path(args.src).expanduser()
    if not src.is_dir():
        print("FAIL 找不到 v2 state 目录：{0}".format(src))
        return 1
    if args.dst:
        home = Path(args.dst).expanduser()
    else:
        env = next((os.environ.get(n, "").strip() for n in ("ERP_HOME", "TAKEALOT_ERP_HOME")
                    if os.environ.get(n, "").strip()), "")
        if env:
            home = Path(env)
        elif sys.platform == "win32":
            home = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")) / "TakealotERP"
        else:
            home = Path.home() / ".takealot-erp"
    dst = home / "state"
    print("== migrate v2 -> v3 ==")
    print("   from: {0}".format(src))
    print("   to:   {0}".format(dst))

    old_stores = json.loads((src / "stores.json").read_text(encoding="utf-8")) if (src / "stores.json").is_file() else {}
    new_file = dst / "stores.json"
    new_stores = json.loads(new_file.read_text(encoding="utf-8")) if new_file.is_file() else {}
    merged, notes = merge_stores(old_stores, new_stores)

    print("-- stores.json")
    for n in notes:
        print("   · {0}".format(n))
    print("   结果 {0} 家店，当前店 {1}".format(len(merged.get("stores") or []), merged.get("activeStoreId") or "(空)"))
    for s in merged.get("stores") or []:
        print("      {0}  {1}  密钥={2}".format(s.get("id"), s.get("name"), key_kind(s.get("_key"))))

    print("-- 本地数据（白名单）")
    copied: list[str] = []
    skipped: list[str] = []
    for name in COPY_FILES:
        p = src / name
        if not p.exists():
            continue
        copied.append(name)
    for name in NEVER:
        if (src / name).exists():
            skipped.append(name + "（授权状态，换版后必须重新授权）")
    print("   搬: {0}".format("、".join(copied) or "（无）"))
    print("   不搬: {0}".format("、".join(skipped) or "（无）"))
    # 明确写一份"未授权"的跟价配置，避免旧授权被任何路径误继承
    print("   写入 repricing_watch.json: authorized=false（自动跟价回到未授权）")

    if args.dry_run:
        print("DRY-RUN：以上都没有落盘。")
        return 0

    dst.mkdir(parents=True, exist_ok=True)
    new_file.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")
    for name in copied:
        s, d = src / name, dst / name
        if s.is_dir():
            if d.exists():
                shutil.rmtree(d)
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)
    watch = dst / "repricing_watch.json"
    if watch.is_file():
        try:
            cur = json.loads(watch.read_text(encoding="utf-8"))
            cur["authorized"] = False
            cur["note"] = cur.get("note") or "migrated from v2: authorization intentionally reset"
            watch.write_text(json.dumps(cur, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
    else:
        watch.write_text(json.dumps({"authorized": False,
                                     "note": "migrated from v2: authorization intentionally reset"},
                                    ensure_ascii=False, indent=2), encoding="utf-8")
    print("RESULT 迁移完成（密钥未以明文经过本脚本；自动跟价未授权）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
