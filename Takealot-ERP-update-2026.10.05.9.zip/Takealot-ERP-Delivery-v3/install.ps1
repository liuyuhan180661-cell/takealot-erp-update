# Takealot ERP - Windows one-click install (form v3: resident server + workbench)
#
#   powershell -ExecutionPolicy Bypass -File install.ps1
#   powershell -ExecutionPolicy Bypass -File install.ps1 -Offline
#   powershell -ExecutionPolicy Bypass -File install.ps1 -ErpHome D:\takealot-erp
#
# It only does three things: find a Python 3.10+ -> hand the job to
# payload\server\cli.py setup -> print the self-check result.
# All the real logic lives in cli.py (the macOS twin of this file is install.sh).
#
# NOTE: this file is intentionally PURE ASCII. PowerShell 5.1 mis-parses non-ASCII
# without a BOM, and cmd.exe code pages mangle it further.

[CmdletBinding()]
param(
  [switch]$Offline,
  [switch]$NoStart,
  [switch]$NoShortcut,
  [string]$ErpHome = "",
  [string]$Python = ""
)

$ErrorActionPreference = "Stop"

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload = Join-Path $Here "payload"
$Cli = Join-Path $Payload "server\cli.py"

if (-not (Test-Path $Cli)) {
  Write-Host "Package incomplete: cannot find payload\server\cli.py" -ForegroundColor Red
  Write-Host "Unzip the whole delivery package first, then run this file inside it."
  exit 1
}

function Test-PythonVersion {
  param([string]$Exe)
  if (-not $Exe) { return $false }
  try {
    $code = "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"
    & $Exe -c $code 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
  } catch { return $false }
}

function Find-ErpPython {
  $cands = New-Object System.Collections.Generic.List[string]
  if ($Python) { $cands.Add($Python) }
  # 1) the py launcher (python.org installs ship it)
  $pyLauncher = Join-Path $env:LOCALAPPDATA "Programs\Python\Launcher\py.exe"
  if (Test-Path $pyLauncher) { $cands.Add($pyLauncher) }
  # 2) python.org default install locations, newest first
  foreach ($root in @("$env:LOCALAPPDATA\Programs\Python", "$env:ProgramFiles", "${env:ProgramFiles(x86)}")) {
    if ($root -and (Test-Path $root)) {
      Get-ChildItem -Path $root -Filter "Python3*" -Directory -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending | ForEach-Object {
          $exe = Join-Path $_.FullName "python.exe"
          if (Test-Path $exe) { $cands.Add($exe) }
        }
    }
  }
  # 3) whatever is on PATH
  foreach ($name in @("python", "python3")) {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd) { $cands.Add($cmd.Source) }
  }

  foreach ($c in $cands) {
    if (Test-PythonVersion $c) { return $c }
  }
  return ""
}

$py = Find-ErpPython
if (-not $py) {
  Write-Host "Python 3.10+ not found." -ForegroundColor Red
  Write-Host ""
  Write-Host "Install it first (python.org, tick 'Add python.exe to PATH'):"
  Write-Host "    https://www.python.org/downloads/windows/"
  Write-Host "Then run this file again."
  exit 1
}

Write-Host "Using Python: $py"

$cliArgs = @($Cli, "setup", "--source", $Payload)
if ($Offline) { $cliArgs += "--offline" }
if ($NoStart) { $cliArgs += "--no-start" }
if ($NoShortcut) { $cliArgs += "--no-shortcut" }
if ($ErpHome) { $cliArgs += @("--erp-home", $ErpHome) }
$cliArgs += @("--python", $py)

& $py @cliArgs
$rc = $LASTEXITCODE
if ($rc -ne 0) {
  Write-Host ""
  Write-Host "Install failed (exit $rc). Send back the lines printed above - each FAIL names its own reason." -ForegroundColor Yellow
}
exit $rc
