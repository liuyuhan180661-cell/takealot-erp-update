#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Windows 交付验收（客户机可自证，纯 ASCII 输出，不联网）。

    <venv>\\Scripts\\python.exe verify_windows.py [--erp-home C:\\...\\TakealotERP]

查 8 件事，每条都 print PASS/FAIL + 实测值，最后一行 RESULT n/n PASS|FAIL：

  1. ERP_HOME 存在且布局齐（server / ui / venv / state）
  2. runtime.json 有 port + token，且端口真在跑（/healthz 200）
  3. 带 token 打 /api → 200；不带 token → 401（鉴权真的在起作用）
  4. 密钥库 = dpapi（Key 不落明文）
  5. 桌面入口 .cmd 在位
  6. 宿主入口插件（Hermes 侧栏）在位
  7. MCP 走 stdio 握手成功 + 工具表非空 + **工具表里没有写平台的工具**（红线）
  8. 全程 stdout 是 UTF-8（Windows 中文版 locale=cp936 时最容易在这里炸）
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass

RESULTS: list[tuple[bool, str, str]] = []


def check(ok: bool, name: str, detail: str = "") -> None:
    RESULTS.append((bool(ok), name, detail))
    print("  {0} {1}{2}".format("PASS" if ok else "FAIL", name, "  - " + detail if detail else ""))


def default_home() -> Path:
    env = next((os.environ.get(n, "").strip() for n in ("ERP_HOME", "TAKEALOT_ERP_HOME")
                if os.environ.get(n, "").strip()), "")
    if env:
        return Path(env)
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "TakealotERP"
    return Path.home() / ".takealot-erp"


def http(url: str, token: str = "", timeout: float = 8.0) -> tuple[int, str]:
    req = urllib.request.Request(url, headers={"X-ERP-Token": token} if token else {})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # 本机回环必须绕代理
    try:
        with opener.open(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        return exc.code, ""
    except Exception as exc:
        return 0, str(exc)[:120]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--erp-home", default="")
    args = ap.parse_args()
    home = Path(args.erp_home).expanduser() if args.erp_home else default_home()
    print("== Takealot ERP Windows acceptance ==")
    print("   ERP_HOME: {0}".format(home))

    # 1) 布局
    missing = [n for n in ("server", "ui", "venv", "state") if not (home / n).is_dir()]
    check(not missing, "ERP_HOME layout (server/ui/venv/state)", "missing: " + ", ".join(missing) if missing else str(home))

    # 2) runtime.json + 端口探活
    rt = {}
    rj = home / "runtime.json"
    if rj.is_file():
        try:
            rt = json.loads(rj.read_text(encoding="utf-8"))
        except Exception as exc:
            rt = {"_error": str(exc)}
    port = int(rt.get("port") or 0)
    token = str(rt.get("token") or "")
    check(bool(port and token), "runtime.json has port + token", "port={0} token={1}".format(port, "yes" if token else "no"))
    health = http("http://127.0.0.1:{0}/healthz".format(port)) if port else (0, "")
    check(health[0] == 200, "server answers /healthz", "HTTP {0}".format(health[0]))

    # 3) 鉴权
    ok_200 = http("http://127.0.0.1:{0}/api/plugins/takealot-erp/settings".format(port), token)
    no_401 = http("http://127.0.0.1:{0}/api/plugins/takealot-erp/settings".format(port), "")
    check(ok_200[0] == 200, "core API with token -> 200", "HTTP {0}".format(ok_200[0]))
    check(no_401[0] == 401, "core API without token -> 401", "HTTP {0}".format(no_401[0]))

    # 4) 密钥库
    backend = ""
    try:
        sys.path.insert(0, str(home / "server"))
        sys.path.insert(0, str(home / "server" / "core"))
        import plugin_api as A  # type: ignore

        backend = A._at_rest_backend()
    except Exception as exc:
        backend = "import-failed: {0}".format(exc)[:80]
    check(backend in ("dpapi", "keychain"), "key store protects the Seller Key", backend)

    # 5) 桌面入口
    desk = Path(os.environ.get("USERPROFILE") or Path.home()) / "Desktop"
    entry = list(desk.glob("Takealot ERP*")) if desk.is_dir() else []
    check(bool(entry), "desktop entry in place", str(entry[0]) if entry else "not found in " + str(desk))

    # 6) 宿主入口插件
    plugins = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")) / "hermes" / "desktop-plugins"
    launcher = plugins / "takealot-erp-launcher" / "plugin.js"
    check(launcher.is_file(), "Hermes sidebar launcher plugin", str(launcher))

    # 7) MCP 握手（stdio）
    tools: list[str] = []
    mcp = home / "server" / "mcp_server.py"
    if mcp.is_file():
        try:
            py = home / "venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
            runner = str(py) if py.is_file() else sys.executable
            init = {"jsonrpc": "2.0", "id": 1, "method": "initialize",
                    "params": {"protocolVersion": "2024-11-05", "capabilities": {},
                               "clientInfo": {"name": "verify-windows", "version": "1.0"}}}
            listing = {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
            payload = json.dumps(init) + "\n" + json.dumps(listing) + "\n"
            env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", ERP_HOME=str(home))
            proc = subprocess.run([runner, str(mcp)], input=payload, capture_output=True, text=True,
                                  encoding="utf-8", errors="replace", env=env, timeout=90)
            for line in (proc.stdout or "").splitlines():
                line = line.strip()
                if not line.startswith("{"):
                    continue
                try:
                    msg = json.loads(line)
                except Exception:
                    continue
                if msg.get("id") == 2:
                    tools = [t.get("name", "") for t in (msg.get("result") or {}).get("tools") or []]
        except Exception as exc:
            tools = []
            print("   (mcp probe error: {0})".format(str(exc)[:120]))
    check(bool(tools), "MCP handshake + tools/list", "{0} tools: {1}".format(len(tools), ", ".join(tools[:12])))
    writeish = [t for t in tools if any(k in t.lower() for k in ("set", "update", "write", "price", "stock", "publish", "push"))]
    check(bool(tools) and not writeish, "no platform-writing tool in the MCP table (red line)",
          "suspicious: " + ", ".join(writeish) if writeish else "read-only surface")

    failed = [r for r in RESULTS if not r[0]]
    print("")
    print("RESULT {0}/{1} {2}".format(len(RESULTS) - len(failed), len(RESULTS), "PASS" if not failed else "FAIL"))
    for _, name, detail in failed:
        print("  FAIL {0}  {1}".format(name, detail))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
