# Takealot ERP 工作台 · 安装说明（v3 · 常驻服务端形态）

一句话：**你的电脑上会常驻一个小服务，工作台在浏览器窗口里打开，数据只在本机。**
它不依赖任何 AI 工具 —— 想用 Hermes / Codex / Cursor 的对话能力就顺手挂上，不挂也照样能用。

- 支持：**macOS 12+** 与 **Windows 10/11**（两边都已在真机上跑通 13/13 自检 + 真实店铺取数）
- 需要：Python 3.10+（macOS 自带的 3.9 不够；Windows 装 python.org 的 3.12，记得勾 "Add python.exe to PATH"）
- 数据目录（下面记作 `ERP_HOME`）：macOS `~/.takealot-erp`；**Windows `%LOCALAPPDATA%\TakealotERP`**
- 服务地址：`http://127.0.0.1:18791/`（只监听本机回环，不对外）

---

## 一、安装（3 步，约 2 分钟）

```bash
# ① 解压交付包
unzip Takealot-ERP-*.zip -d ~/Downloads && cd ~/Downloads/Takealot-ERP-Delivery-v3

# ② 一键装（离线：加 --offline，只用包内 wheelhouse，不联网）
sh install.sh

# ③ 看最后一行
```

**期望结果**（第 ② 步的输出，逐项都要是 `OK`，最后是自检全绿）：

```
── erp setup（…/payload → /Users/<你>/.takealot-erp）
  OK   venv（自包含，不依赖任何 agent 宿主的解释器）
  OK   装依赖（离线（包内 wheelhouse））
  OK   安装文件进 ERP_HOME  — 59 个文件
  OK   安装清单
  OK   .env 占位
  OK   桌面入口（双击即用）  — /Users/<你>/Applications/Takealot ERP 工作台.command
── 装完自检
  PASS 服务端在跑（端口探活）…
  RESULT 13/13 PASS
```

装坏了怎么办：任何一步 `FAIL`，把它打印的那行原样发回来即可；`erp doctor` 随时能重看这 13 项。

## 二、打开工作台

- **双击** `~/Applications/Takealot ERP 工作台.command`（没有地址栏的独立窗口）
- 或命令行：`~/.takealot-erp/venv/bin/python ~/.takealot-erp/server/cli.py open --app`
- 只想开普通浏览器窗口：把 `--app` 去掉

**期望**：窗口打开后顶栏右侧有个绿点 +「服务端 3.0.0 · :18791」。窗口关掉服务不会停（它是常驻的）。

## 三、绑定店铺（第一次用必做）

1. 工作台左侧 → **多店铺设置** → 填店铺名 + Seller 的 `X-API-Key` → **点「设为当前」**（绑定 ≠ 启用，必须点这一下）
2. 回到**经营总览**，右上角选到这家店 → 数字开始出现

**期望**：Key 在磁盘上是密文（macOS 钥匙串 / Windows DPAPI），自检里「密钥已加密存储」为 PASS。

> 出口代理：如果你的网络需要代理才能访问 Takealot，编辑 `~/.takealot-erp/.env` 里的
> `TAKEALOT_API_PROXY=http://127.0.0.1:7890`（换成你自己的），然后重开工作台。

## 四、想让 agent 帮你操作（可选，一条命令装好入口）

工作台通过 **MCP** 对外提供只读工具 + 一个「打开工作台」入口。**写操作（改价/库存/上架）永远只在界面里做**，
工具表里没有这类工具 —— 这是设计，不是缺陷。

一条命令按宿主把入口装好（`--json` 给机器看）：

```bash
ERP=~/.takealot-erp/venv/bin/python; CLI=~/.takealot-erp/server/cli.py

# Hermes：左侧栏多一个「Takealot ERP」项（点一下就有状态卡 + 打开工作台按钮）+ 用户技能
$ERP $CLI mcp config --host hermes --write      # MCP 工具通道
$ERP $CLI entry --host hermes --write           # 侧栏入口 + 技能

# Codex：技能（~/.agents/skills，官方 Agent Skills 标准，符号链接）+ MCP + AGENTS.md 片段
$ERP $CLI entry --host codex --write
codex mcp list                                  # 期望：takealot-erp  enabled

# 装完自检
$ERP $CLI doctor
```

**期望**：在 agent 里说「打开工作台」（或「今天几单」），它会调 `erp_workbench_open` / `erp_orders`，
而不是去猜 URL；审计记录在 `~/.takealot-erp/logs/mcp-sessions.log`。

### 各宿主的入口形态（都已核实官方文档，不是猜的）

| 宿主 | 你在哪儿点 / 怎么唤起 |
|---|---|
| **Hermes** | 左侧栏「Takealot ERP」（状态卡 + 打开工作台按钮）；命令面板搜「Takealot」；对话里说「把工作台打开」 |
| **Codex**（CLI / app / VS Code 扩展） | 技能（`~/.agents/skills`）+ 对话里说「打开工作台」；Codex 没有第三方 UI 扩展点，所以没有侧栏项 |
| **Claude Code** | 会读我们的 MCP prompts（`open-workbench` / `daily-brief`）→ 变成斜杠命令；或对话里直说 |
| **VS Code / Cursor / Windsurf** | 目前靠命令面板 / MCP；**侧栏**要另出一个 VS Code 扩展（还没做，需要就提） |
| **任何支持 MCP 的宿主** | 工具 `erp_workbench_open`（打开工作台）、`erp_orders` / `erp_overview` … |
| **不挂 agent** | 双击桌面图标，或命令行 `cli.py open` |

**Codex 用什么模型：推荐官方订阅（ChatGPT 登录）**，什么都不用配 —— 入口（技能 + MCP）与模型通道无关，
走官方也不会有人来重写 `~/.codex/config.toml`。

> 不想订阅时才用本地网关（如 CC Switch / 自建代理），这时注意两件事：
> ① 它会重写 `~/.codex/config.toml`，我们的 MCP 段被冲掉就重跑 `$ERP $CLI entry --host codex --write`（幂等）；
> ② 经它代理 DeepSeek 一类**思考模型**时，第二轮可能因 `reasoning_content` 没回传报 400 →
> 加 `-c model_reasoning_effort='"none"'` 绕开（或换非思考模型）。

**Codex 实测跑通的一句话**（本机验证：Codex 会话里说这句话 → 工作台自己起来，MCP 工具真的被调用）：

```bash
codex exec --skip-git-repo-check --json --dangerously-bypass-approvals-and-sandbox \
  -c model_reasoning_effort='"none"' \
  "打开 Takealot ERP 工作台：用 MCP 工具 erp_workbench_open（openWindow=true），然后报出端口和版本。"
```
> 两个宿主侧小坑（不是工作台的问题）：① 走本地代理（Clash 等）时给 codex 加 `NO_PROXY=127.0.0.1,localhost`，
> 否则回环请求会被代理拦成 502；② 用 DeepSeek 思考模式的模型时加 `-c model_reasoning_effort='"none"'`，
> 否则第二轮会因 `reasoning_content` 没回传而 400。模型太弱（flash 档）会不调 MCP 而改走命令行兜底——
> 效果一样能起工作台，但看不到干净的 MCP 调用记录。

## 五、常见问题

| 现象 | 原因 / 处理 |
|---|---|
| `sh install.sh` 报 Python 版本太低 | 装 Python 3.10+（`brew install python@3.12`），或 `ERP_PYTHON=/path/to/python3 sh install.sh` |
| 依赖装不上（公司网络/离线） | 用 `sh install.sh --offline`（包内 wheelhouse）；仍失败就 `--index-url https://pypi.tuna.tsinghua.edu.cn/simple` |
| 双击 `.command` 提示"无法打开" | 从压缩包直接解压出来的文件可能带 quarantine：`xattr -dr com.apple.quarantine ~/Applications/Takealot*.command` 后重试 |
| 端口 18791 被占用 | `cli.py open` 会自动往上找口（18792…）；`cli.py status` 会告诉你实际端口 |
| 界面打开是空白 | 先看自检里「服务端在跑」是否 PASS；再看 `~/.takealot-erp/logs/server.out` 尾部 |
| 想确认"真的没连外网" | 服务只绑 `127.0.0.1`；`lsof -nP -iTCP:18791` 只应看到本机 |

## 六、升级与卸载

- **升级**：拿到新包 → `sh install.sh` 再跑一次（幂等；`state/` 用户数据不会被覆盖）→ `cli.py doctor`
- **卸载**：删 `~/.takealot-erp` 与 `~/Applications/Takealot ERP 工作台.command`；
  钥匙串里残留的 Key 条目：`security delete-generic-password -s takealot-erp -a <账户>`（可选）

## 七、Windows（已实测）

同一套机制（同一个服务端、同一份前端、同一条 MCP），差别只在安装入口与几处平台细节。

### 安装（3 步）

```powershell
# ① 解压（右键 zip → 全部提取，或）
Expand-Archive -Path $HOME\Downloads\Takealot-ERP-*.zip -DestinationPath $HOME\Downloads\erp

# ② 一键装（离线：只用包内 wheelhouse-win，不联网）
cd $HOME\Downloads\erp\Takealot-ERP-Delivery-v3
powershell -ExecutionPolicy Bypass -File install.ps1 -Offline

# ③ 期望最后一行
#   RESULT 13/13 PASS
```

装完 `ERP_HOME` = `%LOCALAPPDATA%\TakealotERP`，桌面多一个 **`Takealot ERP 工作台.cmd`**（双击即用）。
命令行入口：`%LOCALAPPDATA%\TakealotERP\cli\erp.cmd status|doctor|open|stop`。

**自证验收（客户机上跑，10 项，纯只读）**：

```powershell
& "$env:LOCALAPPDATA\TakealotERP\venv\Scripts\python.exe" "$env:LOCALAPPDATA\TakealotERP\verify_windows.py"
# 期望：RESULT 10/10 PASS
```
它查：布局、runtime.json、/healthz、带/不带 token 的 200/401、密钥库=dpapi、桌面入口、
Hermes 侧栏插件、MCP 握手 + 工具表（并断言工具表里**没有**写平台的工具）。

### 出口代理（国内机器必看）

Takealot 前面是 Cloudflare，**国内直连会被 403 拦**。配代理的地方就一个：

```powershell
notepad "$env:LOCALAPPDATA\TakealotERP\.env"      # 改成：
TAKEALOT_API_PROXY=http://127.0.0.1:7897            # 你自己的代理端口
```
改完重启工作台（`erp.cmd stop` → `erp.cmd open`）。**注意**：`.env` 现在会被服务端在启动时灌进环境，
所以 crawler 与 Seller API 都看得到（旧版本只认环境变量，`.env` 里配了也不生效 —— 已在 2026.10.04 修掉；
若你手上是更早的包，请改用"系统环境变量"或换新包）。

### 升级 / 重装

**直接再跑一次 `install.ps1` 就行**（幂等）：它会先停服务、换文件、再起服务（Windows 上服务不先停，
`server/` 目录被占用会装不进去 —— 已在 2026.10.04 修）。`state/` 属于用户数据，永不被覆盖。

**从旧版（Hermes 插件形态 / v2）迁店铺与配置**：

```powershell
& "$env:LOCALAPPDATA\TakealotERP\venv\Scripts\python.exe" migrate_v2_state.py `
    --from "$env:LOCALAPPDATA\hermes\plugins\takealot-erp\state"
```
按 store id 合并（带密钥的那份优先）、搬规则/采集箱/草稿/账本白名单文件；
**不搬自动跟价授权** —— 换版后一律回到"未授权"，要开必须重新明确授权一次。

### 卸载

删 `%LOCALAPPDATA%\TakealotERP` 与桌面的 `Takealot ERP 工作台.cmd`；密钥在
DPAPI 密文里，随目录一起删除即失效（换机器要重新粘贴 Key）。
