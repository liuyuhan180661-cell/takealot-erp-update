#!/bin/sh
# Takealot ERP 工作台 —— 解压后的唯一安装动作（macOS / Linux）
#
#   sh install.sh                 # 装到默认数据目录（~/ 下的 .takealot-erp），装完自动自检
#   sh install.sh --offline       # 只用包内 wheelhouse 装依赖（不联网也能装）
#   sh install.sh --erp-home /path/to/home
#
# 它只做三件事：找个 python3 → 把活交给 payload/server/cli.py setup → 打印自检结果。
# 逻辑全在 cli.py 里（Windows 侧对应 install.ps1，Windows 阶段再补）。
set -e

HERE="$(cd "$(dirname "$0")" && pwd)"
CLI="$HERE/payload/server/cli.py"

[ -f "$CLI" ] || { echo "包不完整：找不到 payload/server/cli.py" >&2; exit 1; }

PY="${ERP_PYTHON:-$(command -v python3 || true)}"
[ -n "$PY" ] || { echo "找不到 python3：请先装 Python 3.10+（或用 ERP_PYTHON 指一个）" >&2; exit 1; }

# 版本门槛：3.10+（f-string/typing 用法需要）
"$PY" - <<'EOF' || { echo "Python 版本太低（需要 3.10+）" >&2; exit 1; }
import sys
sys.exit(0 if sys.version_info >= (3, 10) else 1)
EOF

exec "$PY" "$CLI" setup --source "$HERE/payload" "$@"
