/**
 * Takealot ERP — Hermes desktop plugin (UI half).
 *
 * Installs at: %LOCALAPPDATA%\hermes\desktop-plugins\takealot-erp\plugin.js
 * Plain ESM, loaded uncompiled. Only @hermes/plugin-sdk + react + react/jsx-runtime
 * resolve — UI is jsx()/jsxs() calls, never JSX syntax.
 *
 * DATA: everything comes from the plugin's own Python backend through ctx.rest
 * (/api/plugins/takealot-erp/...). The Seller X-API-Key lives server-side only and
 * never crosses into the renderer; `mode: 'demo' | 'live'` is what the UI reports.
 */

import {
  atom,
  Button,
  Codicon,
  EmptyState,
  Input,
  PALETTE_AREA,
  ROUTES_AREA,
  SIDEBAR_NAV_AREA,
  Skeleton,
  STATUSBAR_AREAS,
  Textarea,
  cn,
  host,
  queryClient,
  useMutation,
  useQuery,
  useValue,
  requestTheme,
  useTheme,
  THEMES_AREA
} from '@hermes/plugin-sdk'
import { Children, Fragment, useEffect, useState } from 'react'
import { jsx, jsxs } from 'react/jsx-runtime'

// ── 现代审美：自带主题 + 本页局部样式（都是叠加，不破坏宿主其他界面） ──────────
const TKL_THEME = {
  name: 'takealot-studio',
  label: 'Takealot Studio',
  description: '为跨境中台调过的现代配色：柔和背景、靛蓝主色、清晰层级（含深色版）',
  colors: {
    background: '#f6f7fb',
    foreground: '#0f172a',
    card: '#ffffff',
    cardForeground: '#0f172a',
    muted: '#eef2f7',
    mutedForeground: '#64748b',
    popover: '#ffffff',
    popoverForeground: '#0f172a',
    primary: '#4f46e5',
    primaryForeground: '#ffffff',
    secondary: '#eef2ff',
    secondaryForeground: '#3730a3',
    accent: '#0ea5e9',
    accentForeground: '#ffffff',
    border: '#e3e8f0',
    input: '#e3e8f0',
    ring: '#6366f1',
    midground: '#6366f1',
    destructive: '#e11d48',
    destructiveForeground: '#ffffff',
    sidebarBackground: '#ffffff',
    sidebarBorder: '#e9eef5',
    userBubble: '#eef2ff',
    userBubbleBorder: '#dfe4ff'
  },
  darkColors: {
    background: '#0b1020',
    foreground: '#e6edf7',
    card: '#121a2b',
    cardForeground: '#e6edf7',
    muted: '#1a2337',
    mutedForeground: '#94a3b8',
    popover: '#121a2b',
    popoverForeground: '#e6edf7',
    primary: '#7c8cff',
    primaryForeground: '#0b1020',
    secondary: '#1a2337',
    secondaryForeground: '#c7d2fe',
    accent: '#38bdf8',
    accentForeground: '#06121f',
    border: '#22304a',
    input: '#22304a',
    ring: '#7c8cff',
    midground: '#7c8cff',
    destructive: '#f43f5e',
    destructiveForeground: '#ffffff',
    sidebarBackground: '#0e1526',
    sidebarBorder: '#1c2740',
    userBubble: '#1a2337',
    userBubbleBorder: '#243050'
  },
  typography: {
    fontSans: '-apple-system, BlinkMacSystemFont, "Segoe UI Variable", "Segoe UI", "PingFang SC", "Microsoft YaHei", "Hiragino Sans GB", "Noto Sans SC", system-ui, sans-serif',
    fontMono: '"SF Mono", "JetBrains Mono", "Cascadia Mono", Consolas, "Liberation Mono", monospace'
  }
}

// 局部样式：只作用于 .tkl 作用域，圆角/阴影/表格间距/滚动条，配色仍走宿主 token，
// 所以深浅色主题切换时自动跟随。
const TKL_CSS = `
.tkl { font-size: 13.5px; line-height: 1.5; letter-spacing: .005em; }

  /* 清爽白底：宿主面板底色是 accent 16% 混合出来的（--ui-bg-primary），整片淡蓝紫像卡 bug。
     这里在插件作用域内把填充 token 覆盖为白/极浅灰，并给卡片、表头、指标卡显式白底 + 轻阴影，
     强调色只留在文字与细条上（左侧 active 条、Pill、按钮），不再整块铺色。 */
  .tkl {
    --ui-bg-primary: #ffffff;
    --ui-bg-secondary: #ffffff;
    --ui-bg-tertiary: #fafbfd;
    --ui-bg-quaternary: #f7f9fc;
    --ui-row-hover-background: #f7f9fc;
    --ui-row-active-background: #eef2f7;
  }

.tkl .tkl-card {
  border-radius: 14px;
  border: 1px solid var(--ui-stroke-secondary);
  background: color-mix(in srgb, var(--ui-bg-primary, #fff) 92%, transparent);
  box-shadow: 0 1px 2px rgba(15, 23, 42, .04), 0 10px 28px -18px rgba(15, 23, 42, .18);
  padding: 14px 16px;
}
.tkl .tkl-card-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 10px; }
.tkl .tkl-card-title { font-size: 13px; font-weight: 600; letter-spacing: .01em; }
.tkl .tkl-table { width: 100%; border-collapse: separate; border-spacing: 0; }
.tkl .tkl-table thead th {
  position: sticky; top: 0; z-index: 1;
  background: color-mix(in srgb, var(--ui-bg-primary, #fff) 88%, transparent);
  backdrop-filter: blur(8px);
  font-size: 10.5px; font-weight: 600; letter-spacing: .04em;
  color: var(--ui-text-quaternary); text-transform: none;
  padding: 8px 10px; border-bottom: 1px solid var(--ui-stroke-secondary);
}
.tkl .tkl-table tbody td {
  padding: 9px 10px;
  border-bottom: 1px solid color-mix(in srgb, var(--ui-stroke-secondary) 55%, transparent);
  vertical-align: middle;
}
.tkl .tkl-table tbody tr { transition: background .12s ease; }
.tkl .tkl-table tbody tr:hover { background: var(--chrome-action-hover); }
.tkl img { border-radius: 10px; }
.tkl button { border-radius: 9px; transition: background .12s ease, border-color .12s ease, color .12s ease; }
.tkl input, .tkl select, .tkl textarea { border-radius: 9px; }
.tkl .tkl-metric {
  border-radius: 14px; padding: 12px 14px;
  border: 1px solid var(--ui-stroke-secondary);
  background: linear-gradient(180deg, color-mix(in srgb, var(--ui-bg-primary, #fff) 96%, transparent), color-mix(in srgb, var(--ui-bg-primary, #fff) 80%, transparent));
}
.tkl .tkl-metric-value { font-size: 19px; font-weight: 650; letter-spacing: -.01em; font-variant-numeric: tabular-nums; }
.tkl .tkl-rail-item { border-radius: 10px; }
.tkl .tkl-rail-item[data-active="1"] { background: var(--chrome-action-hover); box-shadow: inset 2px 0 0 var(--ui-accent); }
.tkl .tkl-chip { border-radius: 999px; }
.tkl ::-webkit-scrollbar { width: 10px; height: 10px; }
.tkl ::-webkit-scrollbar-thumb { background: color-mix(in srgb, var(--ui-text-quaternary) 32%, transparent); border-radius: 999px; border: 3px solid transparent; background-clip: content-box; }
.tkl ::-webkit-scrollbar-thumb:hover { background: color-mix(in srgb, var(--ui-text-quaternary) 48%, transparent); background-clip: content-box; }

/* ── 白底覆盖放在最后：同等特异度下后出现者生效 ────────────────────────────────
   上面原有规则用 color-mix(--ui-bg-primary …) 铺色，宿主把 --ui-bg-primary 定为
   accent 16% 混合（淡蓝紫）。这三条必须在样式表末尾，才能真正覆盖它们。 */
.tkl .tkl-card {
  background: #ffffff;
  border: 1px solid color-mix(in srgb, var(--ui-stroke-secondary) 88%, transparent);
  box-shadow: 0 1px 2px rgba(15, 23, 42, .05), 0 1px 3px rgba(15, 23, 42, .03);
}
.tkl .tkl-card:hover { box-shadow: 0 2px 6px rgba(15, 23, 42, .07), 0 1px 3px rgba(15, 23, 42, .04); }
.tkl .tkl-table thead th {
  background: #ffffff;
  border-bottom: 1px solid color-mix(in srgb, var(--ui-stroke-secondary) 80%, transparent);
}
.tkl .tkl-metric {
  background: #ffffff;
  border: 1px solid color-mix(in srgb, var(--ui-stroke-secondary) 88%, transparent);
  box-shadow: 0 1px 2px rgba(15, 23, 42, .04);
}
`
const ID = 'takealot-erp'
const ROOT = [ID]

// ── wired at register() ────────────────────────────────────────────────────
let rest = null
let osDoor = null
let storage = null

const ZAR = n => 'R ' + (Math.round((Number(n) || 0) * 100) / 100).toFixed(2)
const PCT = n => (Number(n) || 0).toFixed(1) + '%'
const NUM = n => Number(n || 0).toLocaleString('en-ZA')
// 订单日期：Takealot 给的是带偏移的 ISO（+02:00 = 南非时间 SAST）。直接按 ISO 里的字面量显示，
// 不要用本机时区去猜——否则北京时间凌晨会看到"昨天"的单而以为没更新。
const SAST = v => {
  const m = String(v || '').match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/)
  return m ? `${m[2]}-${m[3]} ${m[4]}:${m[5]}` : String(v || '').slice(0, 10)
}
// 同一条时间换算成"本机时间"（客户机在北京时即北京时间），用于消除时区困惑
const BJT = v => {
  const m = String(v || '').match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/)
  if (!m) return '—'
  const d = new Date(`${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:00+02:00`)
  const p = x => String(x).padStart(2, '0')
  return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}
const stamp = v => {
  if (!v) return '—'
  const d = new Date(v)
  if (Number.isNaN(d.getTime())) return String(v)
  const p = x => String(x).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}
const shortTime = v => {
  if (!v) return '—'
  const s = String(v)
  return s.length > 8 ? s.slice(-8) : s
}
const msg = e => {
  const m = e && (e.message || e.detail || e.error)
  return typeof m === 'string' ? m : '请求失败'
}

function useApi(path, key, options) {
  return useQuery({
    queryKey: [...ROOT, key || path, path],
    queryFn: () => rest(path),
    refetchOnWindowFocus: false,
    staleTime: 10_000,
    enabled: !options || options.enabled !== false
  })
}

function usePost(path) {
  return useMutation({ mutationFn: body => rest(path, { method: 'POST', body: body || {} }) })
}

// ── 类目中文（首次 AI 翻 → 磁盘缓存；二次直接命中，不刷新） ──────────────
// /meta/categories?...&zh=1 每行会带 nameZh / pathZh，并回一个 zh 摘要
// （cached / missing / translating / reason）。翻译本身在后端后台线程里做，
// 界面这边只负责：显示「中文名 · English」、把进度说出来、预热当前页。
const ZH_WARMED = new Set()

function catLabel(item) {
  const zh = item && item.nameZh ? String(item.nameZh).trim() : ''
  const en = String((item && (item.name || item.path)) || '')
  return zh ? `${zh} · ${en}` : en
}

function zhHint(data) {
  const z = (data && data.zh) || null
  if (!z) return ''
  if (z.translating) return '翻译中…'
  if (Number(z.missing) > 0) return `中文待翻译 ${z.missing}`
  return ''
}

// 预热当前页：把这一页类目路径的所有段丢给 POST /meta/categories/translate。
// 后端在后台线程翻并写 state/category_zh.json，所以这里不 await、失败也不影响渲染；
// 下次同样的搜索直接命中缓存，不会再打 LLM（这就是「二次不刷新」）。
function zhPrewarm(kind, items) {
  const texts = []
  ;(items || []).forEach(x => {
    String((x && x.path) || '').split(' -> ').forEach(seg => {
      const t = seg.trim()
      if (t && texts.indexOf(t) === -1) texts.push(t)
    })
  })
  if (!texts.length) return
  const stamp = `${kind}:${texts.join('|')}`
  if (ZH_WARMED.has(stamp)) return
  ZH_WARMED.add(stamp)
  try {
    const r = rest('/meta/categories/translate', { method: 'POST', body: { texts: texts.slice(0, 200) } })
    if (r && typeof r.catch === 'function') r.catch(() => {})
  } catch (e) {
    /* 预热失败无所谓：下次请求还会带 zh=1 再试 */
  }
}

function useZhPrewarm(kind, items) {
  useEffect(() => {
    zhPrewarm(kind, items)
  }, [kind, items])
}

function refresh() {
  queryClient.invalidateQueries({ queryKey: ROOT })
}

// ── primitives ─────────────────────────────────────────────────────────────

function Card({ title, extra, children, className }) {
  return jsxs('div', {
    className: cn(
      'tkl-card','rounded-lg border border-(--ui-stroke-secondary)', className),
    children: [
      title
        ? jsxs('div', {
            className: 'flex items-center justify-between gap-2 border-b border-(--ui-stroke-secondary) px-3 py-2',
            children: [
              jsx('div', { className: 'text-[0.8125rem] font-medium', children: title }),
              extra || null
            ]
          })
        : null,
      jsx('div', { className: 'p-3', children: Children.toArray(children) })
    ]
  })
}

function Pill({ tone, children }) {
  const tones = {
    good: 'text-(--ui-accent) border-(--ui-accent)',
    bad: 'text-red-400 border-red-400/60',
    warn: 'text-amber-400 border-amber-400/60',
    mute: 'text-(--ui-text-quaternary) border-(--ui-stroke-secondary)'
  }
  return jsx('span', {
    className: cn(
      'inline-flex items-center gap-1 rounded border px-1.5 py-px text-[0.6875rem] leading-4 whitespace-nowrap',
      tones[tone] || tones.mute
    ),
    children
  })
}

function Metric({ label, value, sub, tone }) {
  return jsxs('div', {
    className: 'rounded-lg border border-(--ui-stroke-secondary) p-3',
    children: [
      jsx('div', { className: 'text-[0.6875rem] tracking-wide text-(--ui-text-quaternary) uppercase', children: label }),
      jsx('div', {
        className: cn(
          'mt-1 text-lg font-semibold tabular-nums',
          tone === 'good' && 'text-(--ui-accent)',
          tone === 'bad' && 'text-red-400'
        ),
        children: value
      }),
      sub ? jsx('div', { className: 'mt-0.5 text-[0.6875rem] text-(--ui-text-quaternary)', children: sub }) : null
    ]
  })
}

function Grid({ cols, children, className }) {
  const map = { 2: 'sm:grid-cols-2', 3: 'sm:grid-cols-2 lg:grid-cols-3', 4: 'sm:grid-cols-2 lg:grid-cols-4', 6: 'sm:grid-cols-3 lg:grid-cols-6' }
  return jsx('div', { className: cn('grid gap-2', map[cols] || map[3], className), children: Children.toArray(children) })
}

function Th({ children, right, className }) {
  return jsx('th', {
    className: cn(
      'border-b border-(--ui-stroke-secondary) px-2.5 py-1.5 text-[0.6875rem] font-normal text-(--ui-text-quaternary) whitespace-nowrap',
      right ? 'text-right' : 'text-left',
      className
    ),
    children
  })
}

function Td({ children, right, mono, className, span, onClick, title }) {
  return jsx('td', {
    colSpan: span,
    onClick,
    title,
    className: cn(
      'border-b border-(--ui-stroke-secondary) px-2.5 py-1.5 align-middle',
      right && 'text-right tabular-nums',
      mono && 'font-mono text-[0.75rem]',
      className
    ),
    children
  })
}

// 外部链接：SDK 的 host 上没有 openExternal（它在 ctx.os 上），所以统一走这里。
// ctx.os.openExternal 是 result-shaped：缺失能力时返回 false，而不是抛异常。
function openPortal(url) {
  const target = String(url || '')
  if (!target) return
  try {
    if (osDoor && typeof osDoor.openExternal === 'function') {
      const res = osDoor.openExternal(target)
      if (res && typeof res.then === 'function') {
        res.then(ok => {
          if (!ok) host.notify({ kind: 'warn', message: `无法打开浏览器，请手动访问 ${target}` })
        }).catch(() => host.notify({ kind: 'warn', message: `无法打开浏览器，请手动访问 ${target}` }))
      }
      return
    }
    if (typeof window !== 'undefined' && typeof window.open === 'function') {
      window.open(target, '_blank')
      return
    }
    host.notify({ kind: 'warn', message: `请手动访问 ${target}` })
  } catch (e) {
    host.notify({ kind: 'warn', message: `无法打开浏览器，请手动访问 ${target}` })
  }
}

// 内联展开时把被点击行滚进视口（同一个 SKU 只自动滚一次，避免每次渲染都跳）。
let _detailScrolled = ''
function scrollDetailIntoView(node, sku) {
  if (!node || !sku || _detailScrolled === sku) return
  _detailScrolled = sku
  try {
    node.scrollIntoView({ block: 'nearest', behavior: 'smooth' })
  } catch (e) {
    try { node.scrollIntoView() } catch (e2) { /* 老渲染器忽略 */ }
  }
}

function Table({ head, children, className }) {
  // tkl-table 让本页表格享受现代样式（宿主表格组件无法从外部加类，所以这里包一层）
  return jsx('div', {
    className: cn('overflow-x-auto', className),
    children: jsx('table', {
      className: 'tkl-table w-full border-collapse text-[0.8125rem]',
      children: [
        jsx('thead', { key: 'h', children: jsx('tr', { children: Children.toArray(head) }) }),
        jsx('tbody', { key: 'b', children: Children.toArray(children) })
      ]
    })
  })
}

function Field({ label, children, className }) {
  return jsxs('label', {
    className: cn('flex flex-col gap-1 text-[0.6875rem] text-(--ui-text-quaternary)', className),
    children: [label, children]
  })
}

function ErrorBox({ error, onRetry }) {
  return jsxs('div', {
    className: 'flex items-center justify-between gap-3 rounded-lg border border-red-400/50 px-3 py-2 text-[0.8125rem] text-red-400',
    children: [
      jsx('div', { className: 'min-w-0 truncate', children: `加载失败：${msg(error)}` }),
      jsx(Button, { size: 'xs', variant: 'outline', onClick: onRetry, children: '重试' })
    ]
  })
}

function Async({ query, children }) {
  if (query.isLoading) {
    return jsxs('div', {
      className: 'space-y-2',
      children: [0, 1, 2].map(i => jsx(Skeleton, { key: i, className: 'h-20 w-full rounded-lg' }))
    })
  }
  if (query.isError) {
    return jsx(ErrorBox, { error: query.error, onRetry: () => query.refetch() })
  }
  if (!query.data) {
    return jsx(EmptyState, { title: '暂无数据', description: '后端未返回内容' })
  }
  return children(query.data)
}

function Bar({ label, value, max, tone }) {
  const pct = max > 0 ? Math.min(100, Math.round((Number(value) / max) * 100)) : 0
  return jsxs('div', {
    className: 'space-y-1',
    children: [
      jsxs('div', {
        className: 'flex items-baseline justify-between text-[0.75rem]',
        children: [
          jsx('span', { className: 'text-(--ui-text-tertiary)', children: label }),
          jsx('span', { className: 'tabular-nums', children: ZAR(value) })
        ]
      }),
      jsx('div', {
        className: 'h-1.5 w-full overflow-hidden rounded bg-(--ui-bg-tertiary)',
        children: jsx('div', {
          className: cn('h-full rounded', tone === 'bad' ? 'bg-red-400/70' : 'bg-(--ui-accent)'),
          style: { width: pct + '%' }
        })
      })
    ]
  })
}

// 趋势图：鼠标悬停显示当天「单量 / 金额 / 净额」。数值来自后端真实聚合（trend[].units / revenue /
// netProfit）；缺字段时显示 "—"，不拿 0 冒充。
function TrendChart({ rows, height }) {
  const data = (rows || []).map(r => ({
    date: String(r.date || ''),
    units: r.units === undefined || r.units === null ? null : Number(r.units),
    orders: r.orders === undefined || r.orders === null ? null : Number(r.orders),
    revenue: Number(r.revenue) || 0,
    net: r.netProfit === undefined || r.netProfit === null ? null : Number(r.netProfit)
  }))
  const [hover, setHover] = useState(null)
  if (data.length < 2) {
    return jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '数据不足（至少需要两天）' })
  }
  const vals = data.map(d => d.revenue)
  const max = Math.max(...vals, 1)
  const min = Math.min(...vals, 0)
  const span = max - min || 1
  const step = 100 / (vals.length - 1)
  const coords = vals.map((v, i) => [i * step, 30 - ((v - min) / span) * 28])
  const line = coords.map(c => `${c[0].toFixed(2)},${c[1].toFixed(2)}`).join(' ')
  const area = `0,30 ${line} 100,30`
  const pick = e => {
    const box = e.currentTarget.getBoundingClientRect()
    const ratio = Math.min(1, Math.max(0, (e.clientX - box.left) / Math.max(1, box.width)))
    setHover(Math.round(ratio * (data.length - 1)))
  }
  const cur = hover === null ? data.length - 1 : hover
  const row = data[cur] || {}
  const reading = hover === null ? '最新一天' : String(row.date || '')
  const leftPct = Math.min(96, Math.max(4, (cur / (data.length - 1)) * 100))
  return jsxs('div', {
    className: 'space-y-1',
    children: [
      jsxs('div', {
        className: 'flex flex-wrap items-center justify-between gap-2 text-[0.6875rem]',
        children: [
          jsx('div', { className: 'text-(--ui-text-quaternary)', children: reading }),
          jsxs('div', {
            className: 'flex flex-wrap items-center gap-3 tabular-nums',
            children: [
              jsxs('span', { children: ['单量 ', jsx('b', { children: row.units === null || row.units === undefined ? '—' : NUM(row.units) })] }),
              jsxs('span', { children: ['金额 ', jsx('b', { children: ZAR(row.revenue) })] }),
              jsxs('span', { children: ['净额 ', jsx('b', { children: row.net === null ? '—' : ZAR(row.net) })] })
            ]
          })
        ]
      }),
      jsxs('div', {
        className: 'relative',
        onMouseMove: pick,
        onMouseLeave: () => setHover(null),
        children: [
          jsx('svg', {
            className: 'w-full text-(--ui-accent)',
            viewBox: '0 0 100 30',
            preserveAspectRatio: 'none',
            style: { height: (height || 48) + 'px' },
            children: [
              jsx('polygon', { key: 'a', points: area, fill: 'currentColor', opacity: 0.10 }),
              jsx('polyline', {
                key: 'l',
                points: line,
                fill: 'none',
                stroke: 'currentColor',
                strokeWidth: 1.4,
                vectorEffect: 'non-scaling-stroke'
              })
            ]
          }),
          hover === null
            ? null
            : jsxs('div', {
                className: 'pointer-events-none absolute inset-y-0 z-10',
                style: { left: leftPct + '%' },
                children: [
                  jsx('div', { className: 'h-full w-px bg-(--ui-accent) opacity-60' }),
                  jsx('div', {
                    className: 'absolute left-1/2 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-(--ui-accent)',
                    style: { top: Math.max(0, Math.min(100, (coords[cur][1] / 30) * 100)) + '%' }
                  }),
                  jsxs('div', {
                    className: 'absolute left-1/2 -translate-x-1/2 whitespace-nowrap rounded border border-(--ui-stroke-secondary) bg-(--ui-bg-primary, #fff) px-1.5 py-0.5 text-[0.625rem] shadow-sm',
                    style: { top: '-1.75rem' },
                    children: [
                      jsx('div', { children: String(row.date || '').slice(5) }),
                      jsx('div', { className: 'tabular-nums', children: `单量 ${row.units === null || row.units === undefined ? '—' : NUM(row.units)} · ${ZAR(row.revenue)}` })
                    ]
                  })
                ]
              })
          ]
      })
    ]
  })
}

function Spark({ points, height }) {
  const vals = (points || []).map(p => Number(p) || 0)
  if (vals.length < 2) {
    return jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '数据不足' })
  }
  const max = Math.max(...vals, 1)
  const min = Math.min(...vals, 0)
  const span = max - min || 1
  const step = 100 / (vals.length - 1)
  const coords = vals.map((v, i) => [i * step, 30 - ((v - min) / span) * 28])
  const line = coords.map(c => `${c[0].toFixed(2)},${c[1].toFixed(2)}`).join(' ')
  const area = `0,30 ${line} 100,30`
  return jsx('svg', {
    className: 'w-full text-(--ui-accent)',
    viewBox: '0 0 100 30',
    preserveAspectRatio: 'none',
    style: { height: (height || 44) + 'px' },
    children: [
      jsx('polygon', { key: 'a', points: area, fill: 'currentColor', opacity: 0.12 }),
      jsx('polyline', {
        key: 'l',
        points: line,
        fill: 'none',
        stroke: 'currentColor',
        strokeWidth: 1.4,
        vectorEffect: 'non-scaling-stroke'
      })
    ]
  })
}

// ── modules ────────────────────────────────────────────────────────────────

const LEVEL_TONE = { error: 'bad', warn: 'warn', info: 'mute' }

// ── shared store state (the app's own pattern: nanostores over props) ───────

const $storeId = atom('')
const $module = atom('')
const $analyticsTarget = atom('')
const $productsFocus = atom('')
const $listingPrefill = atom('')

function useStores() {
  const q = useApi('/settings', 'settings:stores')
  const d = q.data || {}
  return { stores: d.stores || [], activeStoreId: d.activeStoreId || '', mode: d.mode, keyConfigured: d.keyConfigured }
}

function StorePick({ value, onChange, label, compact }) {
  const { stores } = useStores()
  return jsxs(label ? 'label' : 'span', {
    className: label ? 'flex flex-col gap-1 text-[0.6875rem] text-(--ui-text-quaternary)' : 'inline-flex',
    children: [
      label || null,
      jsx('select', {
        value: value || '',
        onChange: e => onChange(e.target.value),
        className: cn('rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-0.5 text-[0.75rem]', compact ? 'w-32' : 'w-full'),
        children: [jsx('option', { value: '', children: stores.length ? '不指定（全店共用）' : '未绑定店铺' })].concat(
          stores.map(s => jsx('option', { key: s.id, value: s.id, children: s.name }))
        )
      })
    ]
  })
}

// The 「绑定店铺」 switch: scopes 经营总览 (and the collection view) to one store.
function StoreSwitcher() {
  const active = useValue($storeId)
  const { stores, activeStoreId } = useStores()
  const setActive = usePost('/settings/active')
  const current = active || activeStoreId || ''
  const choose = id => {
    $storeId.set(id)
    if (storage) {
      storage.set('storeId', id)
    }
    setActive.mutate({ storeId: id }, { onSuccess: () => queryClient.invalidateQueries({ queryKey: ROOT }) })
  }
  return jsxs('div', {
    className: 'mt-2 space-y-1 rounded border border-(--ui-stroke-secondary) p-2',
    children: [
      jsxs('div', {
        className: 'flex items-center justify-between text-[0.6875rem] text-(--ui-text-quaternary)',
        children: [jsx('span', { children: '切换店铺（点击即切）' }), jsx('span', { children: `${stores.length} 个` })]
      }),
      stores.length
        ? jsxs('div', {
            className: 'space-y-1',
            children: stores
              .map(s => {
                const isOn = s.id === current
                return jsx(
                  'button',
                  {
                    type: 'button',
                    key: s.id,
                    title: `${s.name} · ${s.keyMasked || ''} · ${s.status === 'connected' ? '已连接' : '未校验'}`,
                    onClick: () => choose(s.id),
                    className: cn(
                      'flex w-full items-center gap-1.5 rounded border px-1.5 py-1 text-left text-[0.75rem] transition-colors',
                      isOn
                        ? 'border-(--ui-accent) bg-(--chrome-action-hover) text-(--ui-accent)'
                        : 'border-(--ui-stroke-secondary) text-(--ui-text-tertiary) hover:bg-(--chrome-action-hover)'
                    ),
                    children: [
                      jsx('span', {
                        className: cn('h-1.5 w-1.5 shrink-0 rounded-full', s.status === 'connected' ? 'bg-(--ui-accent)' : 'bg-amber-400')
                      }),
                      jsx('span', { className: 'min-w-0 flex-1 truncate', children: s.name }),
                      isOn ? jsx('span', { className: 'text-[0.625rem]', children: '当前' }) : null
                    ]
                  },
                  s.id
                )
              })
              .concat(
                jsx(
                  'button',
                  {
                    type: 'button',
                    key: '__all__',
                    onClick: () => choose(''),
                    className: cn(
                      'flex w-full items-center gap-1.5 rounded border px-1.5 py-1 text-left text-[0.75rem]',
                      !current ? 'border-(--ui-accent) text-(--ui-accent)' : 'border-(--ui-stroke-secondary) text-(--ui-text-quaternary) hover:bg-(--chrome-action-hover)'
                    ),
                    children: [jsx('span', { className: 'h-1.5 w-1.5 shrink-0 rounded-full bg-(--ui-text-quaternary)' }), jsx('span', { children: '全部店铺（汇总）' })]
                  },
                  '__all__'
                )
              )
          })
        : jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '未绑定（去「多店铺设置」添加）' })
    ]
  })
}


function Overview() {
  const storeId = useValue($storeId)
  const q = useApi(`/overview?storeId=${encodeURIComponent(storeId)}`, `overview:${storeId}`)
  return jsx(Async, {
    query: q,
    children: d => {
      const k = d.kpis || {}
      return jsxs('div', {
        className: 'space-y-3',
        children: [
          jsxs('div', {
            className: 'flex flex-wrap items-center gap-2 text-[0.75rem] text-(--ui-text-tertiary)',
            children: [
              jsx(Pill, {
                tone: storeId ? 'good' : 'mute',
                children: `绑定店铺：${d.activeStoreName || ((d.stores || []).find(s => s.id === d.activeStoreId) || {}).name || '全部店铺（汇总）'}`
              }),
              jsx('span', { children: d.mode === 'live' ? 'Seller API 实时数据' : '当前为样例数据（绑定 Key 后转实时）' }),
              jsx('span', { children: '在左侧「绑定店铺」中切换' })
            ]
          }),
          jsx(Grid, {
            cols: 6,
            children: [
              jsx(Metric, { label: '营收', value: ZAR(k.revenue), sub: `${NUM(k.orders)} 单 / ${NUM(k.unitsSold)} 件` }),
              jsx(Metric, { label: '净利润', value: ZAR(k.netProfit), tone: 'good', sub: `净利率 ${PCT(k.margin)}` }),
              jsx(Metric, { label: '待发货', value: NUM(k.awaitingShipment), sub: '需 48h 内交接 DC' }),
              jsx(Metric, { label: 'BuyBox 持有', value: `${NUM(k.buyboxHeld)}/${NUM(k.buyboxTotal)}`, sub: '跟价信号正常' }),
              jsx(Metric, {
                label: '对账差异',
                value: ZAR(k.discrepancyTotal),
                tone: k.discrepancyTotal > 0 ? 'bad' : undefined,
                sub: k.discrepancyTotal > 0 ? '存在被多收的履约费' : '本期账单干净'
              }),
              jsx(Metric, { label: '亏损单', value: NUM(k.lossCount), tone: k.lossCount > 0 ? 'bad' : undefined, sub: 'DC 费/成本倒挂' })
            ]
          }),
          jsxs('div', {
            className: 'grid gap-3 lg:grid-cols-[1.6fr_1fr]',
            children: [
              jsx(Card, {
                title: '近 14 天营收走势（按南非时间 SAST 分桶 · UTC+2）',
                extra: jsx(Pill, { tone: d.mode === 'live' ? 'good' : 'mute', children: d.mode === 'live' ? '实时数据' : '内置样例数据' }),
                children: jsxs('div', {
                  className: 'space-y-3',
                  children: [
                    jsx(TrendChart, { rows: d.trend || [], height: 56 }),
                    jsx('div', {
                      className: 'flex justify-between text-[0.6875rem] text-(--ui-text-quaternary)',
                      children: (d.trend || [])
                        .filter((_, i) => i % 3 === 0)
                        .map(t => jsx('span', { key: t.date, children: String(t.date).slice(5) }))
                    }),
                    jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: '日期按店铺所在时区（南非 SAST = UTC+2，比本机时间早 6 小时）分桶：本机凌晨的单会算在 SAST 的前一天，所以"最新一天 0 单"并不代表数据没更新。' }),
                    jsx('div', {
                      className: 'grid gap-2 sm:grid-cols-2',
                      children: (d.feeBreakdown || []).map(b => jsx(Bar, { key: b.label, label: b.label, value: b.amount, max: k.revenue }))
                    })
                  ]
                })
              }),
              jsx(Card, {
                title: '风险提示',
                children: (d.alerts || []).length
                  ? jsx('ul', {
                      className: 'space-y-2',
                      children: (d.alerts || []).map((a, i) =>
                        jsxs('li', {
                          key: i,
                          className: 'flex items-start gap-2',
                          children: [
                            jsx(Pill, { tone: LEVEL_TONE[a.level] || 'mute', children: a.level === 'error' ? '严重' : a.level === 'warn' ? '注意' : '提示' }),
                            jsxs('div', {
                              className: 'min-w-0',
                              children: [
                                jsx('div', { className: 'text-[0.8125rem]', children: a.title }),
                                jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: a.detail })
                              ]
                            })
                          ]
                        })
                      )
                    })
                  : jsx(EmptyState, { title: '无风险提示', description: '当前账期没有异常' })
              })
            ]
          }),
          jsxs('div', {
            className: 'grid gap-3 lg:grid-cols-2',
            children: [
              jsx(Card, {
                title: '最近订单（时间 = 南非时间 SAST）',
                extra: jsx(Button, { size: 'xs', variant: 'ghost', onClick: refresh, children: '刷新' }),
                children: jsx(Table, {
                  head: [jsx(Th, { key: 'd', children: '时间 (SAST)' }), jsx(Th, { key: 'o', children: '订单号' }), jsx(Th, { key: 't', children: '商品' }), jsx(Th, { key: 'p', right: true, children: '售价' }), jsx(Th, { key: 'n', right: true, children: '净利' }), jsx(Th, { key: 's', children: '状态' })],
                  children: (d.recentOrders || []).map(o =>
                    jsxs(
                      'tr',
                      {
                        key: o.orderId,
                        children: [
                          jsx(Td, { className: 'text-[0.75rem] tabular-nums text-(--ui-text-tertiary)', title: `本机时间 ${BJT(o.orderDateRaw || o.orderDate)}`, children: SAST(o.orderDateRaw || o.orderDate) }),
                          jsx(Td, { mono: true, children: o.orderId }),
                          jsx(Td, { className: 'max-w-[18rem] truncate', title: o.title, children: o.title }),
                          jsx(Td, { right: true, children: ZAR(o.sellingPrice) }),
                          jsx(Td, { right: true, className: o.isLoss ? 'text-red-400' : 'text-(--ui-accent)', children: ZAR(o.netProfit) }),
                          jsx(Td, { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: o.saleStatus || o.status || '—' })
                        ]
                      }
                    )
                  )
                })
              }),
              jsx(Card, {
                title: 'BuyBox 概览',
                children: jsx(Table, {
                  head: [jsx(Th, { key: 's', children: 'SKU' }), jsx(Th, { key: 'm', right: true, children: '我的价' }), jsx(Th, { key: 'c', right: true, children: '竞品价' }), jsx(Th, { key: 'a', children: '状态' })],
                  children: (d.buybox || []).map(b =>
                    jsxs(
                      'tr',
                      {
                        key: b.sku,
                        children: [
                          jsx(Td, { mono: true, children: b.sku }),
                          jsx(Td, { right: true, children: ZAR(b.myPrice) }),
                          jsx(Td, { right: true, children: ZAR(b.competitorPrice) }),
                          jsx(Td, {
                            children: jsx(Pill, {
                              tone: b.hasBuybox ? 'good' : b.action === 'floor_guard' ? 'warn' : 'bad',
                              children: b.hasBuybox ? '持有' : b.action === 'floor_guard' ? '底价保护' : '丢失'
                            })
                          })
                        ]
                      }
                    )
                  )
                })
              })
            ]
          })
        ]
      })
    }
  })
}

// 订单状态桶：绑定 Takealot 真实 sale_status（Confirmed Shipment = 待发货、
// New Lead Time Order = 直邮待发货、Shipped Shipment / Shipped to Customer = 已发货）。
// 之前用的是 awaiting_shipment/shipped/delivered 这类后端不存在的 id，于是点哪个桶都返回同一批，
// 看起来"两个状态显示相同数据"。现在计数与筛选都按真实行在前端算。
const ORDER_RAW = {
  toShip: ['Confirmed Shipment'],
  leadtime: ['New Lead Time Order'],
  shipped: ['Shipped Shipment', 'Shipped to Customer']
}
// 后端会把原始状态规范化（Confirmed Shipment 与 New Lead Time Order 都变成 Awaiting Shipment），
// 所以优先用后端保留的原始值 saleStatus 匹配；只有它缺失时才退回规范值 status。
const ORDER_CANON = {
  toShip: ['Awaiting Shipment'],
  leadtime: [],
  shipped: ['Shipped', 'Delivered']
}
const ORDER_STATUSES = [].concat.apply([], Object.values(ORDER_RAW)).concat([].concat.apply([], Object.values(ORDER_CANON)))
const orderStatusOf = o => String((o && o.saleStatus) || (o && o.status) || '')
const orderMatches = (o, kind) => {
  const raw = String((o && o.saleStatus) || '')
  const list = raw ? ORDER_RAW[kind] : ORDER_CANON[kind]
  return list.includes(raw || String((o && o.status) || ''))
}
const ORDER_BUCKETS = [
  { id: '', label: '全部', match: () => true },
  { id: 'to_ship', label: '待发货', match: o => orderMatches(o, 'toShip') },
  { id: 'leadtime', label: '直邮待发货', match: o => orderMatches(o, 'leadtime') },
  { id: 'shipped', label: '已发货', match: o => orderMatches(o, 'shipped') },
  { id: 'other', label: '其他状态', match: o => !ORDER_STATUSES.includes(orderStatusOf(o)) }
]
const ORDER_BUCKET_OF = o => (ORDER_BUCKETS.find(b => b.id && b.match(o)) || { id: 'other' }).id
// 净利率：后端不再返回 marginPercent，用 净利 /（单价 × 数量）自算
const orderMargin = o => {
  const gross = (Number(o && o.sellingPrice) || 0) * (Number(o && o.quantity) || 1)
  const net = Number(o && o.netProfit)
  if (!gross || !isFinite(net)) return o && o.marginPercent
  return (net / gross) * 100
}

// ── 实时订单（Seller API /sales） ───────────────────────────────────────────
// 客户在 Seller Portal 上看到的那批订单。费用字段可能滞后为 0，所以「我方核算」只在
// 类目已知时给数字（后端会带 feeRateKnown），否则显示"—"并说明。
function LiveOrders({ storeId }) {
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const query = `/orders/live?storeId=${encodeURIComponent(storeId)}&q=${encodeURIComponent(q)}&status=${encodeURIComponent(status)}`
  const live = useApi(query, `liveorders:${storeId}:${q}:${status}`, { enabled: !!storeId })
  const d = live.data || {}
  const sm = d.summary || {}
  const items = d.items || []
  return jsxs('div', {
    className: 'space-y-2',
    children: [
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-2',
        children: [
          jsx('div', { className: 'text-[0.8125rem]', children: '实时订单（Seller API /sales）' }),
          (() => {
            const raw = (items || []).map(x => String(x.orderDateRaw || x.orderDate || '')).filter(Boolean).sort()
            const latest = raw[raw.length - 1] || ''
            const sastToday = SAST(new Date(Date.now() + 2 * 3600 * 1000).toISOString()).slice(0, 10)
            const nToday = raw.filter(x => x.slice(0, 10) === sastToday).length
            return jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `最新一单 ${latest ? SAST(latest) : '—'} (SAST) · 今日(SAST ${sastToday}) ${nToday} 单 · 全部 ${raw.length} 单｜本机凌晨的单会落在 SAST 前一天` })
          })(),
          jsx(Pill, { tone: d.ok ? 'good' : 'warn', children: d.ok ? `已取 ${NUM(d.total)} 行` : '未取到' }),
          d.storeName ? jsx(Pill, { tone: 'mute', children: d.storeName }) : null,
          jsx('div', { className: 'w-48', children: jsx(Input, { size: 'sm', value: q, placeholder: '订单号 / SKU', onChange: e => setQ(e.target.value) }) }),
          jsx('select', {
            value: status,
            onChange: e => setStatus(e.target.value),
            className: 'rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.6875rem]',
            children: [jsx('option', { value: '', children: '全部状态' })]
              .concat(Object.keys(sm.byStatus || {}).map(k => jsx('option', { key: k, value: k, children: k })))
          }),
          jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => live.refetch && live.refetch(), children: '刷新' })
        ]
      }),
      !storeId
        ? jsx('div', { className: 'rounded border border-(--ui-stroke-secondary) p-2 text-[0.75rem] text-(--ui-text-quaternary)', children: '汇总视图下不显示实时订单（每家店是独立账号的数据）：请用顶栏选定店铺。' })
        : null,
      d.error
        ? jsx('div', { className: 'rounded border border-red-400/60 p-2 text-[0.75rem] text-red-400', children: d.error })
        : null,
      d.ok
        ? jsxs('div', {
            className: 'space-y-2',
            children: [
              jsx(Grid, {
                cols: 5,
                children: [
                  jsx(Metric, { label: '订单数', value: NUM(sm.orders), sub: `${NUM(sm.lines)} 行 · ${NUM(sm.units)} 件` }),
                  jsx(Metric, { label: '销售额（含税）', value: ZAR(sm.gross) }),
                  jsx(Metric, { label: '平台已计费', value: ZAR(sm.platformFees) }),
                  jsx(Metric, { label: '净额', value: ZAR(sm.net), tone: (sm.net || 0) >= 0 ? 'good' : 'bad' }),
                  jsx(Metric, {
                    label: '费用核对',
                    value: sm.feeVariance == null ? '—' : ZAR(sm.feeVariance),
                    sub: sm.ratedLines ? `${NUM(sm.ratedLines)} 行类目已知` : '类目未知，不给数字',
                    tone: sm.feeVariance == null ? 'mute' : Math.abs(sm.feeVariance) < 1 ? 'good' : 'warn'
                  })
                ]
              }),
              jsx(Table, {
                head: [
                  Th('订单号'), Th('产品 / SKU'), Th('状态'), Th('数量', { right: true }),
                  Th('售价', { right: true }), Th('平台费', { right: true }), Th('我方核算', { right: true }),
                  Th('净额', { right: true }), Th('时间'), Th('出货区域')
                ],
                children: items.map(r =>
                  jsxs('tr', {
                    key: r.orderItemId || r.orderId + r.sku,
                    children: [
                      jsx(Td, { mono: true, children: r.orderId }),
                      jsxs(Td, { children: [
                        jsx('div', { className: 'max-w-[18rem] truncate text-[0.8125rem]', title: r.title, children: r.title || '—' }),
                        jsx('div', { className: 'font-mono text-[0.6875rem] text-(--ui-text-quaternary)', children: r.sku })
                      ] }),
                      jsx(Td, { children: jsx(Pill, { tone: /Ship|Deliver/i.test(r.saleStatus) ? 'good' : 'mute', children: r.saleStatus || '—' }) }),
                      jsx(Td, { right: true, mono: true, children: NUM(r.quantity) }),
                      jsx(Td, { right: true, mono: true, children: ZAR(r.sellingPrice) }),
                      jsx(Td, { right: true, mono: true, children: ZAR(r.platformFees) }),
                      jsx(Td, { right: true, mono: true, children: r.expectedSuccessFee == null ? '—' : ZAR(r.expectedSuccessFee) }),
                      jsx(Td, { right: true, mono: true, children: ZAR(r.net) }),
                      jsx(Td, { children: jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: (r.orderDate || '').replace('T', ' ').slice(0, 16) }) }),
                      jsx(Td, { children: jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: r.stockSourceRegion || r.salesRegion || '—' }) })
                    ]
                  })
                )
              }),
              jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: d.hint || '' })
            ]
          })
        : null
    ]
  })
}

// ── 实时对账（/balances + /transactions + /sales） ──────────────────────────
function LiveFinance({ storeId }) {
  const live = useApi(`/financial/live?storeId=${encodeURIComponent(storeId)}`, `livefin:${storeId}`, { enabled: !!storeId })
  const [exporting, setExporting] = useState(false)
  const [exportMsg, setExportMsg] = useState('')
  const [enriching, setEnriching] = useState(false)
  const [enrichMsg, setEnrichMsg] = useState('')
  const doEnrichOrdered = async () => {
    const need = ((live.data || {}).needsCategory || {})
    const skus = need.skus || []
    if (!storeId) {
      host.notify({ kind: 'warn', message: '请先选定店铺' })
      return
    }
    if (!skus.length) {
      host.notify({ kind: 'info', message: '没有需要补全的 SKU（有订单的 SKU 都已有类目）' })
      return
    }
    const batch = skus.slice(0, need.enrichLimit || 20)
    setEnriching(true)
    setEnrichMsg('')
    try {
      const r = await rest('/products/enrich', { method: 'POST', body: { skus: batch, storeId } })
      const okCount = (r && (r.enriched ?? r.okCount ?? (r.results || []).filter(x => x.ok).length)) || 0
      setEnrichMsg(`已补全 ${batch.length} 个 SKU：成功 ${okCount}${need.count > batch.length ? ` · 还剩 ${need.count - batch.length} 个，再点一次继续` : ' · 已全部补完'}`)
      if (live.refetch) live.refetch()
    } catch (e) {
      setEnrichMsg(`补全失败：${msg(e)}`)
    } finally {
      setEnriching(false)
    }
  }
  const doExport = async () => {
    if (!storeId) {
      host.notify({ kind: 'warn', message: '导出必须选定店铺：汇总视图下无法确定是哪一家' })
      return
    }
    setExporting(true)
    setExportMsg('')
    try {
      const r = await rest('/financial/reconcile/export', { method: 'POST', body: { storeId } })
      if (r && r.ok) {
        const rows = Object.keys(r.rows || {}).map(k => `${k} ${r.rows[k]} 行`).join(' · ')
        setExportMsg(`已导出：${r.path}（${Math.round((r.bytes || 0) / 1024)} KB · ${rows}）`)
        host.notify({ kind: 'info', message: '对账工作簿已导出' })
      } else {
        setExportMsg(`导出失败：${(r && r.error) || '未知'}`)
      }
    } catch (e) {
      setExportMsg(`导出失败：${msg(e)}`)
    } finally {
      setExporting(false)
    }
  }
  const d = live.data || {}
  const b = d.balances || {}
  const lg = d.ledger || {}
  const od = d.orders || {}
  const types = lg.byType || []
  return jsxs('div', {
    className: 'space-y-2',
    children: [
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-2',
        children: [
          jsx('div', { className: 'text-[0.8125rem]', children: '实时对账（/balances + /transactions + /sales）' }),
          jsx(Pill, { tone: d.ok ? 'good' : 'warn', children: d.ok ? '已取实时数据' : '未取到' }),
          b.consistent != null ? jsx(Pill, { tone: b.consistent ? 'good' : 'bad', children: b.consistent ? '余额自检通过' : '余额三件套不平' }) : null,
          jsx(Button, { size: 'xs', variant: 'outline', disabled: exporting || !storeId, onClick: doExport, children: exporting ? '导出中…' : '导出对账表 (xlsx)' }),
          jsx(Button, {
            size: 'xs',
            variant: 'outline',
            disabled: enriching || !storeId || !((d.needsCategory || {}).count),
            onClick: doEnrichOrdered,
            children: enriching ? '补全中…' : `补全有订单的 SKU 类目${((d.needsCategory || {}).count) ? `（${(d.needsCategory || {}).count}）` : ''}`
          }),
          jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => live.refetch && live.refetch(), children: '刷新' })
        ]
      }),
      d.error ? jsx('div', { className: 'rounded border border-red-400/60 p-2 text-[0.75rem] text-red-400', children: d.error }) : null,
      exportMsg ? jsx('div', { className: 'break-all font-mono text-[0.6875rem] text-(--ui-text-quaternary)', children: exportMsg }) : null,
      enrichMsg ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: enrichMsg }) : null,
      d.ok
        ? jsxs('div', {
            className: 'space-y-2',
            children: [
              jsx(Grid, {
                cols: 4,
                children: [
                  jsx(Metric, { label: '当前余额', value: ZAR(b.current), sub: b.note || '', tone: (b.current || 0) >= 0 ? 'good' : 'bad' }),
                  jsx(Metric, { label: '可用', value: ZAR(b.available) }),
                  jsx(Metric, { label: '冻结/待结', value: ZAR(b.heldBack) }),
                  jsx(Metric, { label: '订单侧费用（平台/我方）',
                                value: `${ZAR(od.platformFees)} / ${od.expectedSuccessFee == null ? '—' : ZAR(od.expectedSuccessFee)}`,
                                sub: od.variance == null ? '类目未知，不给差额' : `差额 ${ZAR(od.variance)}` })
                ]
              }),
              jsxs('div', {
                className: 'grid gap-3 md:grid-cols-2',
                children: [
                  jsx(Card, {
                    title: `交易流水按类型（${NUM(lg.rows)} 笔 · 贷 ${ZAR(lg.credits)} / 借 ${ZAR(lg.debits)}）`,
                    children: jsx(Table, {
                      head: [Th('类型'), Th('笔数', { right: true }), Th('金额', { right: true }), Th('最近')],
                      children: types.length
                        ? types.map(t => jsxs('tr', {
                            key: t.type,
                            children: [
                              jsx(Td, { children: jsx('div', { className: 'font-mono text-[0.75rem]', children: t.type }) }),
                              jsx(Td, { right: true, mono: true, children: NUM(t.count) }),
                              jsx(Td, { right: true, mono: true, children: ZAR(t.amount) }),
                              jsx(Td, { children: jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: (t.lastAt || '').replace('T', ' ').slice(0, 16) }) })
                            ]
                          }))
                        : [jsxs('tr', { children: [jsx(Td, { children: jsx('div', { className: 'text-[0.75rem] text-(--ui-text-quaternary)', children: '没有流水记录' }) }), jsx(Td, {}), jsx(Td, {}), jsx(Td, {})] })]
                    })
                  }),
                  jsx(Card, {
                    title: `费用核对（逐单差额 Top ${NUM((d.varianceRows || []).length)}）`,
                    children: jsx(Table, {
                      head: [Th('订单'), Th('SKU'), Th('售价', { right: true }), Th('平台费', { right: true }), Th('我方核算', { right: true }), Th('差额', { right: true })],
                      children: (d.varianceRows || []).length
                        ? (d.varianceRows || []).map(r => jsxs('tr', {
                            key: r.orderId + r.sku,
                            children: [
                              jsx(Td, { mono: true, children: r.orderId }),
                              jsx(Td, { mono: true, children: r.sku }),
                              jsx(Td, { right: true, mono: true, children: ZAR(r.sellingPrice) }),
                              jsx(Td, { right: true, mono: true, children: ZAR(r.platformFees) }),
                              jsx(Td, { right: true, mono: true, children: ZAR(r.expected) }),
                              jsx(Td, { right: true, mono: true, children: ZAR(r.variance) })
                            ]
                          }))
                        : [jsxs('tr', { children: [jsx(Td, { children: jsx('div', { className: 'text-[0.75rem] text-(--ui-text-quaternary)', children: od.expectedSuccessFee == null ? '类目未知，暂不核算（先在商品管理里补全类目）' : '没有超过 R1 的差额' }) }), jsx(Td, {}), jsx(Td, {}), jsx(Td, {}), jsx(Td, {}), jsx(Td, {})] })]
                    })
                  })
                ]
              }),
              ((d.needsCategory || {}).rows || []).length
                ? jsx(Card, {
                    title: `有订单但缺类目（${NUM((d.needsCategory || {}).count)} 个 SKU）`,
                    extra: jsx('span', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: '补全后逐单费用核对才会出数字' }),
                    children: jsxs('div', {
                      className: 'space-y-2',
                      children: [
                        jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: (d.needsCategory || {}).hint || '' }),
                        jsx(Table, {
                          head: [Th('SKU'), Th('商品'), Th('订单数', { right: true }), Th('TSIN')],
                          children: ((d.needsCategory || {}).rows || []).slice(0, 12).map(r =>
                            jsxs('tr', {
                              key: r.sku,
                              children: [
                                jsx(Td, { mono: true, children: r.sku }),
                                jsx(Td, { children: jsx('div', { className: 'max-w-[20rem] truncate text-[0.8125rem]', title: r.title, children: r.title || '—' }) }),
                                jsx(Td, { right: true, mono: true, children: NUM(r.orders) }),
                                jsx(Td, { mono: true, children: r.tsin || '—' })
                              ]
                            })
                          )
                        })
                      ]
                    })
                  })
                : null,
              (d.months || []).length
                ? jsx(Card, {
                    title: `月度汇总（真实流水 · ${NUM((d.months || []).length)} 个月）`,
                    extra: jsx('span', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: d.monthsSource || '' }),
                    children: jsx(Table, {
                      head: [Th('月份'), Th('订单行', { right: true }), Th('销售额', { right: true }), Th('贷方', { right: true }),
                             Th('借方', { right: true }), Th('净额', { right: true }), Th('流水笔数', { right: true })],
                      children: (d.months || []).map(m =>
                        jsxs('tr', {
                          key: m.month,
                          children: [
                            jsx(Td, { children: jsx('div', { className: 'font-mono text-[0.8125rem]', children: m.month }) }),
                            jsx(Td, { right: true, mono: true, children: NUM(m.salesRows) }),
                            jsx(Td, { right: true, mono: true, children: ZAR(m.salesGross) }),
                            jsx(Td, { right: true, mono: true, children: ZAR(m.credits) }),
                            jsx(Td, { right: true, mono: true, children: ZAR(m.debits) }),
                            jsx(Td, { right: true, mono: true, children: ZAR(m.net) }),
                            jsx(Td, { right: true, mono: true, children: NUM(m.txCount) })
                          ]
                        })
                      )
                    })
                  })
                : null,
              (d.anomalies || []).length
                ? jsx(Card, {
                    title: `异常项（${(d.anomalies || []).length}）`,
                    children: jsxs('div', {
                      className: 'space-y-1',
                      children: (d.anomalies || []).map((a, i) => jsxs('div', {
                        className: 'text-[0.75rem]',
                        children: [
                          jsx('span', { className: 'text-amber-400', children: `【${a.kind}】` }),
                          jsx('span', { children: ` ${a.detail || ''}` }),
                          jsx('span', { className: 'text-(--ui-text-quaternary)', children: a.amount != null ? `（${ZAR(a.amount)}）` : '' })
                        ]
                      }, i))
                    })
                  })
                : null,
              jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: (d.hint || '') + (lg.note || d.ledgerNote ? ` ${lg.note || d.ledgerNote}` : '') })
            ]
          })
        : null
    ]
  })
}

function Orders() {
  const storeId = useValue($storeId)
  const [status, setStatus] = useState('')
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(null)
  // status 不传给后端：真实过滤按 sale_status 在前端做（后端 status 参数用的是另一套取值）
  const list = useApi(`/orders?q=${encodeURIComponent(q)}&storeId=${encodeURIComponent(storeId)}`, `orders:${storeId}:${q}`)
  const detail = useApi(`/orders/${open}?storeId=${encodeURIComponent(storeId)}`, `order:${open}:${storeId}`, { enabled: !!open })
  return jsxs('div', {
    className: 'space-y-3',
    children: [
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-2',
        children: [
          jsx('div', { className: 'w-56', children: jsx(Input, { size: 'sm', value: q, placeholder: '搜索订单号 / SKU / 标题', onChange: e => setQ(e.target.value) }) }),
          jsx(Button, { size: 'xs', variant: 'outline', onClick: refresh, children: '刷新' }),
          jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '状态桶按真实 sale_status 过滤，计数来自当前数据' })
        ]
      }),
      jsx(LiveOrders, { storeId }),
      jsx(Async, {
        query: list,
        children: d => {
          if (d.ok === false) {
            return jsx(Card, {
              title: '订单与净利',
              children: jsx(EmptyState, {
                title: '暂时读不到真实订单',
                description: `${d.error || '未绑定 Seller Key 或出口不通'}${d.requires ? `（需要：${d.requires}）` : ''}`
              })
            })
          }
          const allItems = d.items || []
          const counts = {}
          ORDER_BUCKETS.forEach(b => { counts[b.id] = allItems.filter(x => b.match(x)).length })
          const bucket = ORDER_BUCKETS.find(b => b.id === status)
          const items = bucket ? allItems.filter(x => bucket.match(x)) : allItems
          const revenue = items.reduce((a, x) => a + (Number(x.sellingPrice) || 0) * (Number(x.quantity) || 1), 0)
          const fees = items.reduce((a, x) => a + (Number(x.platformDeductions) || 0), 0)
          const net = items.reduce((a, x) => a + (Number(x.netProfit) || 0), 0)
          const loss = items.filter(x => x.isLoss).length
          return jsxs('div', {
            className: cn('grid gap-3', open ? 'lg:grid-cols-[1.7fr_1fr]' : ''),
            children: [
              jsxs('div', {
                className: 'space-y-3',
                children: [
                  jsx('div', {
                    className: 'flex flex-wrap items-center gap-2',
                    children: ORDER_BUCKETS.map(b =>
                      jsx(Button, {
                        key: b.id || 'all',
                        size: 'xs',
                        variant: status === b.id ? 'secondary' : 'ghost',
                        onClick: () => setStatus(b.id),
                        children: `${b.label} ${NUM(counts[b.id] || 0)}`
                      })
                    )
                  }),
                  jsx(Grid, {
                    cols: 4,
                    children: [
                      jsx(Metric, { label: '订单数', value: NUM(items.length), sub: `亏损 ${NUM(loss)} 单` }),
                      jsx(Metric, { label: '销售额', value: ZAR(revenue) }),
                      jsx(Metric, { label: '平台扣费', value: ZAR(fees) }),
                      jsx(Metric, {
                        label: '净利润',
                        value: ZAR(net),
                        tone: net >= 0 ? 'good' : 'bad',
                        sub: `净利率 ${revenue ? PCT((net / revenue) * 100) : '—'}`
                      })
                    ]
                  }),
                  (d.byStore || []).length
                    ? jsx(Card, {
                        title: '分店明细（汇总视图）',
                        children: jsx(Table, {
                          head: [Th('店铺'), Th('订单数', { right: true }), Th('销售额', { right: true }), Th('净利润', { right: true })],
                          children: (d.byStore || []).map(b =>
                            jsxs('tr', {
                              key: b.storeId,
                              children: [
                                jsx(Td, { children: jsx('div', { className: 'text-[0.8125rem]', children: b.storeId }) }),
                                jsx(Td, { right: true, mono: true, children: NUM(b.orders) }),
                                jsx(Td, { right: true, mono: true, children: ZAR(b.revenue) }),
                                jsx(Td, { right: true, mono: true, children: ZAR(b.net) })
                              ]
                            })
                          )
                        })
                      })
                    : null,
                  jsx(Card, {
                    title: status
                      ? `订单明细 · ${(ORDER_BUCKETS.find(b => b.id === status) || {}).label}（${NUM(items.length)} 单 · 真实 /sales）`
                      : `订单明细（${NUM(items.length)} 单 · 真实 /sales · 点任意行看扣减明细）`,
                    children: jsx(Table, {
                      head: [
                        jsx(Th, { key: 'd', children: '时间 (SAST)' }),
                        jsx(Th, { key: 'o', children: '订单号' }),
                        jsx(Th, { key: 'g', children: '商品' }),
                        jsx(Th, { key: 'p', right: true, children: '售价' }),
                        jsx(Th, { key: 'f', right: true, children: '平台已计费' }),
                        jsx(Th, { key: 'e', right: true, children: '预估佣金' }),
                        jsx(Th, { key: 'n', right: true, children: '净利' }),
                        jsx(Th, { key: 'm', right: true, children: '净利率' }),
                        jsx(Th, { key: 's', children: '状态' }),
                        jsx(Th, { key: 'v', children: '扣减明细' })
                      ],
                      children: items.map(o =>
                        jsxs(
                          'tr',
                          {
                            key: o.orderId,
                            className: cn('cursor-pointer hover:bg-(--chrome-action-hover)', open === o.orderId && 'bg-(--chrome-action-hover)'),
                            onClick: () => setOpen(o.orderId),
                            children: [
                              jsx(Td, { className: 'text-[0.75rem] tabular-nums text-(--ui-text-tertiary)', title: `本机时间 ${BJT(o.orderDateRaw || o.orderDate)}`, children: SAST(o.orderDateRaw || o.orderDate) }),
                              jsx(Td, { mono: true, children: o.orderId }),
                              jsx(Td, { className: 'max-w-[16rem] truncate', title: `${o.title} · ${o.sku}`, children: o.title }),
                              jsx(Td, { right: true, children: ZAR(o.sellingPrice) }),
                              jsx(Td, { right: true, className: 'text-(--ui-text-tertiary)', title: o.feesBilled ? '平台已计费' : '平台结算时才计费，当前为 0 属正常', children: ZAR(o.platformDeductions) }),
                              jsx(Td, { right: true, className: 'text-amber-400', title: o.estimateBasis || '', children: o.estimatedSuccessFee == null ? '—' : ZAR(o.estimatedSuccessFee) }),
                              jsx(Td, { right: true, className: o.isLoss ? 'text-red-400' : 'text-(--ui-accent)', children: ZAR(o.netProfit) }),
                              jsx(Td, { right: true, children: PCT(orderMargin(o)) }),
                              jsx(Td, { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: o.status }),
                              jsx(Td, { children: jsx(Pill, { tone: open === o.orderId ? 'good' : 'mute', children: open === o.orderId ? '已展开 ↓' : '点击查看 →' }) })
                            ]
                          }
                        )
                      )
                    })
                  })
                ]
              }),
              open
                ? jsx(Card, {
                    title: `订单 ${open}`,
                    extra: jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => setOpen(null), children: '收起' }),
                    children: jsx(Async, {
                      query: detail,
                      children: o =>
                        jsxs('div', {
                          className: 'space-y-2 text-[0.8125rem]',
                          children: [
                            jsxs('div', { className: 'flex flex-wrap items-center gap-2 text-[0.75rem]', children: [
                              jsx('span', { className: 'text-(--ui-text-tertiary)', children: '下单时间' }),
                              jsx('span', { className: 'tabular-nums', children: SAST(o.orderDateRaw || o.orderDate) + ' (SAST)' }),
                              jsx('span', { className: 'text-(--ui-text-quaternary)', children: '· 本机 ' + BJT(o.orderDateRaw || o.orderDate) }),
                              jsx(Pill, { tone: o.feesBilled ? 'good' : 'warn', children: o.feesBilled ? '平台已计费' : '平台尚未计费' })
                            ] }),
                            jsx('div', { className: 'text-(--ui-text-secondary)', children: o.title }),
                            jsxs('div', {
                              className: 'flex flex-wrap gap-1',
                              children: [
                                jsx(Pill, { tone: 'mute', children: o.sku }),
                                jsx(Pill, { tone: 'mute', children: o.tsin }),
                                jsx(Pill, { tone: 'mute', children: o.dcTier }),
                                jsx(Pill, { tone: o.isLoss ? 'bad' : 'good', children: ZAR(o.netProfit) })
                              ]
                            }),
                            !o.feesBilled
                              ? jsx('div', { className: 'rounded border border-amber-400/50 px-2.5 py-1.5 text-[0.75rem] text-amber-400', children: '平台在结算时才计费：下表"平台已计费"项为 0 属正常；带「预估」的行是按类目/默认费率算的，仅供决策参考。' })
                              : null,
                            o.estimateBasis
                              ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '预估口径：' + o.estimateBasis })
                              : null,
                            jsx('div', {
                              className: 'divide-y divide-(--ui-stroke-secondary) rounded border border-(--ui-stroke-secondary)',
                              children: (o.lines || []).map((l, i) =>
                                jsxs(
                                  'div',
                                  {
                                    className: 'px-2.5 py-1.5',
                                    children: [
                                      jsxs('div', {
                                        className: 'flex items-baseline justify-between gap-2',
                                        children: [
                                          jsx('span', {
                                            className: cn('text-(--ui-text-tertiary)',
                                              l.kind === 'net' && 'text-(--ui-text-secondary)',
                                              l.kind === 'estimate' && 'text-amber-400/90',
                                              l.kind === 'cost' && 'text-(--ui-text-quaternary)'),
                                            children: l.label
                                          }),
                                          jsx('span', {
                                            className: cn('tabular-nums',
                                              l.kind === 'net' && 'text-(--ui-accent)',
                                              l.kind === 'estimate' && 'text-amber-400',
                                              l.kind === 'cost' && 'text-(--ui-text-quaternary)'),
                                            children: l.amount === null || l.amount === undefined ? '—' : ZAR(l.amount)
                                          })
                                        ]
                                      }),
                                      l.note
                                        ? jsx('div', { className: 'mt-0.5 text-[0.625rem] leading-snug text-(--ui-text-quaternary)', children: l.note })
                                        : null
                                    ]
                                  },
                                  i
                                )
                              )
                            }),
                            jsxs('div', {
                              className: 'grid grid-cols-2 gap-2 text-[0.75rem] text-(--ui-text-quaternary)',
                              children: [
                                jsx('div', { children: `成功费率 ${o.successFeeRate}` }),
                                jsx('div', { children: `计费重 ${o.chargeableWeightKg} kg` }),
                                jsx('div', { children: `保本价 ${ZAR(o.breakEvenPrice)}` }),
                                jsx('div', { children: `20% 目标价 ${ZAR(o.recommendedPrice20)}` })
                              ]
                            }),
                            o.warning
                              ? jsx('div', { className: 'rounded border border-amber-400/50 px-2.5 py-1.5 text-[0.75rem] text-amber-400', children: o.warning })
                              : null,
                            o.note ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: o.note }) : null
                          ]
                        })
                    })
                  })
                : null
            ]
          })
        }
      })
    ]
  })
}

function Financial() {
  const storeId = useValue($storeId)
  const [q, setQ] = useState('')
  const query = useApi(`/financial?q=${encodeURIComponent(q)}&storeId=${encodeURIComponent(storeId)}`, `financial:${storeId}:${q}`)
  return jsxs('div', {
    className: 'space-y-3',
    children: [
      jsxs('div', {
        className: 'flex items-center gap-2',
        children: [
          jsx('div', { className: 'w-64', children: jsx(Input, { size: 'sm', value: q, placeholder: '搜索结算单 / 订单号', onChange: e => setQ(e.target.value) }) }),
          jsx(Button, { size: 'xs', variant: 'outline', onClick: refresh, children: '刷新' })
        ]
      }),
      jsx(LiveFinance, { storeId }),
      jsx(Async, {
        query,
        children: d => {
          const s = d.summary || {}
          const r = d.reconcile || {}
          return jsxs('div', {
            className: 'space-y-3',
            children: [
              jsx(Grid, {
                cols: 4,
                children: [
                  jsx(Metric, { label: '总销售额', value: ZAR(s.grossSales) }),
                  jsx(Metric, { label: '平台扣费', value: ZAR(s.platformFees) }),
                  jsx(Metric, { label: '实结金额', value: ZAR(s.netPayout), tone: 'good' }),
                  jsx(Metric, {
                    label: '疑似多收',
                    value: ZAR(s.overcharged),
                    tone: s.overcharged > 0 ? 'bad' : undefined,
                    sub: r.status
                  })
                ]
              }),
              jsxs('div', {
                className: 'grid gap-3 lg:grid-cols-2',
                children: [
                  jsxs('div', {
                    className: 'space-y-3',
                    children: [
                      jsx(Card, {
                        title: '月度结算',
                        children: jsx(Table, {
                          head: [jsx(Th, { key: 'm', children: '月份' }), jsx(Th, { key: 's', right: true, children: '销售额' }), jsx(Th, { key: 'f', right: true, children: '平台费' }), jsx(Th, { key: 'n', right: true, children: '净结算' })],
                          children: (d.months || []).map(m =>
                            jsxs(
                              'tr',
                              {
                                children: [
                                  jsx(Td, { children: m.month }),
                                  jsx(Td, { right: true, children: ZAR(m.sales) }),
                                  jsx(Td, { right: true, className: 'text-(--ui-text-tertiary)', children: ZAR(m.fees) }),
                                  jsx(Td, { right: true, children: ZAR(m.net) })
                                ]
                              },
                              m.month
                            )
                          )
                        })
                      }),
                      jsx(Card, {
                        title: '结算单',
                        children: jsx(Table, {
                          head: [jsx(Th, { key: 'i', children: '结算单号' }), jsx(Th, { key: 'p', children: '账期' }), jsx(Th, { key: 'g', right: true, children: '销售额' }), jsx(Th, { key: 'd', right: true, children: 'DC 费' }), jsx(Th, { key: 'n', right: true, children: '实结' }), jsx(Th, { key: 's', children: '状态' })],
                          children: (d.statements || []).map(st =>
                            jsxs(
                              'tr',
                              {
                                children: [
                                  jsx(Td, { mono: true, children: st.statementId }),
                                  jsx(Td, { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: `${st.periodStart} ~ ${st.periodEnd}` }),
                                  jsx(Td, { right: true, children: ZAR(st.grossSales) }),
                                  jsx(Td, { right: true, children: ZAR(st.dcFees) }),
                                  jsx(Td, { right: true, children: ZAR(st.netPayout) }),
                                  jsx(Td, { children: jsx(Pill, { tone: st.status === '已核对' || st.status === '已结算' ? 'good' : 'mute', children: st.status }) })
                                ]
                              },
                              st.statementId
                            )
                          )
                        })
                      })
                    ]
                  }),
                  jsx(Card, {
                    title: '履约费对账（StatementReconciler）',
                    extra: jsx(Pill, { tone: r.discrepancyCount > 0 ? 'bad' : 'good', children: r.status || '—' }),
                    children: jsxs('div', {
                      className: 'space-y-2',
                      children: [
                        jsxs('div', {
                          className: 'text-[0.75rem] text-(--ui-text-quaternary)',
                          children: `已审计 ${NUM(r.totalAuditedRows)} 行 · 差异 ${NUM(r.discrepancyCount)} 笔 · 合计被多收 ${ZAR(r.totalOverchargedZAR)}`
                        }),
                        (r.discrepancies || []).length
                          ? jsx('div', {
                              className: 'space-y-2',
                              children: (r.discrepancies || []).map((x, i) =>
                                jsxs(
                                  'div',
                                  {
                                    className: 'rounded border border-red-400/40 p-2.5',
                                    children: [
                                      jsxs('div', {
                                        className: 'flex items-center justify-between gap-2',
                                        children: [
                                          jsx('span', { className: 'font-mono text-[0.75rem]', children: x.orderId }),
                                          jsx(Pill, { tone: 'bad', children: `多收 ${ZAR(x.overchargedAmount)}` })
                                        ]
                                      }),
                                      jsx('div', { className: 'mt-1 text-[0.75rem] text-(--ui-text-tertiary)', children: x.description }),
                                      jsxs('div', {
                                        className: 'mt-0.5 text-[0.6875rem] text-(--ui-text-quaternary)',
                                        children: `实收 ${ZAR(x.actualCharged)} · 理论 ${ZAR(x.expectedAmount)}`
                                      }),
                                      jsx('div', { className: 'mt-1 text-[0.6875rem] text-amber-400', children: x.suggestedAction })
                                    ]
                                  },
                                  i
                                )
                              )
                            })
                          : jsx(EmptyState, { title: '账单干净', description: '平台扣费与理论测算一致' })
                      ]
                    })
                  })
                ]
              })
            ]
          })
        }
      })
    ]
  })
}

function Collection() {
  const [url, setUrl] = useState('')
  const [cost, setCost] = useState('')
  const [price, setPrice] = useState('')
  const [picked, setPicked] = useState([])
  const [bulkStore, setBulkStore] = useState('')
  // 采集箱是**全店共用**的一个池子；「分派到店铺」只是行上的标签，不是可见性门槛。
  // 这里给一个显式作用域开关：默认跟随顶栏绑定的店铺，但有未分派行时必须能一眼看见，
  // 并能一键只看未分派（后端 collection() 现在把未分派行也算进店铺视图并回报 unassignedIncluded）。
  const [scopeOverride, setScopeOverride] = useState('')
  // 合并「选品/销量分析」后：深度分析不再跳到另一个模块，而是在这一行里展开（下拉即看，数字取自缓存）。
  const [openId, setOpenId] = useState('')
  const queuedTarget = useValue($analyticsTarget) || (storage && storage.get('analyticsTarget', '')) || ''
  // 一键上架：默认 dryRun 预览（先看清每一格会「上架 / 跳过 + 原因」），确认后才真写平台
  const [pub, setPub] = useState(null)
  const storeId = useValue($storeId)
  const scopeId = scopeOverride || storeId
  const q = useApi(`/collection?storeId=${encodeURIComponent(scopeId)}`, `collection:${scopeId}`)
  // 深链目标是否已经在这个箱子里（不在 → 顶部就地分析；不再有独立模块可跳）
  const boxTargets = (((q.data || {}).items) || []).map(x => x.tsin || x.sourceUrl).filter(Boolean)
  const add = usePost('/collection/add')
  const promote = usePost('/collection/promote')
  const assign = usePost('/collection/assign')
  const reanalyze = usePost('/collection/reanalyze')
  const refreshOne = usePost('/collection/refresh')
  const publish = usePost('/collection/publish-all')
  // 跟卖池写入口：平台侧只接受 price/stock；成本/汇率/汇损/头程/重量/尺寸是本地核算输入
  // （费率条件的输入），也走这个端点，但不会产生任何平台写请求。
  const updPool = usePost('/collection/update')
  const done = m => {
    refresh()
    host.notify({ kind: 'info', message: m })
  }
  const fail = e => host.notify({ kind: 'error', message: msg(e) })
  const toggle = id => setPicked(p => (p.includes(id) ? p.filter(x => x !== id) : p.concat(id)))
  const allIds = rows => (rows || []).map(x => x.id)
  const crawlTag = c => {
    if (!c) return jsx(Pill, { tone: 'mute', children: '未采集' })
    const mode = c.mode || 'demo'
    // 抓不到不都是"通道未通"：目标解析不到（TSIN 对不上 PLID）要如实说，否则会往网络问题上找
    const why = String(c.error || '')
    const unresolved = mode === 'blocked' && /resolve|not found/i.test(why)
    return jsx(Pill, {
      tone: mode === 'live' ? 'good' : mode === 'blocked' ? 'warn' : 'mute',
      title: why || undefined,
      children: mode === 'live'
        ? (c.transport === 'ingest' ? '中继数据' : '公开 API')
        : mode === 'blocked' ? (unresolved ? '目标解析不到' : '通道未通') : '样例估算'
    })
  }

  return jsxs('div', {
    className: 'space-y-3',
    children: [
      queuedTarget && !boxTargets.includes(queuedTarget)
        ? jsx(Card, {
            title: '快速分析（这个目标还没进采集箱：看完销量/跟卖/AI 可一键采集进来）',
            children: jsx(Analytics, { preset: queuedTarget })
          })
        : null,
      jsx(Card, {
        title: '采集商品（粘贴 Takealot 链接 / TSIN / PLID，采集箱全店共用）',
        children: jsxs('div', {
          className: 'flex flex-wrap items-end gap-2',
          children: [
            jsx('div', { className: 'min-w-[22rem] flex-1', children: jsx(Input, { value: url, placeholder: 'https://www.takealot.com/... 或 TSIN1234567 / PLID73910245', onChange: e => setUrl(e.target.value) }) }),
            jsx('div', { className: 'w-28', children: jsx(Input, { value: cost, placeholder: '采购成本', onChange: e => setCost(e.target.value) }) }),
            jsx('div', { className: 'w-28', children: jsx(Input, { value: price, placeholder: '预估售价', onChange: e => setPrice(e.target.value) }) }),
            jsx('div', { className: 'w-40', children: jsx(StorePick, { value: bulkStore, onChange: setBulkStore, label: '采集即分派（可选）' }) }),
            jsx(Button, {
              size: 'sm',
              disabled: add.isPending || !url.trim(),
              onClick: () =>
                add.mutate(
                  { url: url.trim(), cost: Number(cost) || undefined, price: Number(price) || undefined, storeId: bulkStore || undefined },
                  {
                    onSuccess: r => {
                      setUrl('')
                      setCost('')
                      setPrice('')
                      done((r && r.crawl && r.crawl.mode === 'live') ? '已采集（含公开数据与销量推算）' : '已加入采集箱（抓取通道未通，先用估算值）')
                    },
                    onError: fail
                  }
                ),
              children: add.isPending ? '采集中…' : '采集并加入'
            })
          ]
        })
      }),
      jsx(Async, {
        query: q,
        children: d => {
          const s = d.stats || {}
          const conflicts = d.conflicts || []
          const items = d.items || []
          // 本次会话刚跑过就用本次结果，否则回放落盘的「上次一键上架结果」（重开 App 也看得到）
          const pubView = pub || d.lastPublish || null
          const pubFromState = !pub && !!d.lastPublish
          return jsxs('div', {
            className: 'space-y-3',
            children: [
              conflicts.length
                ? jsx('div', {
                    className: 'rounded border border-amber-400/60 px-3 py-2 text-[0.8125rem] text-amber-400',
                    children: `⚠ 发现 ${conflicts.length} 个 TSIN 被分派到多个店铺，会自相残杀：${conflicts.map(c => `${c.tsin}（${(c.stores || []).join(' / ')}）`).join('；')}`
                  })
                : null,
              (scopeId === 'unassigned' || (scopeId && scopeId !== 'all' && Number(d.unassignedIncluded) > 0))
                ? jsx('div', {
                    className: 'flex flex-wrap items-center justify-between gap-2 rounded border border-sky-400/50 px-3 py-2 text-[0.8125rem]',
                    children: [
                      jsx('span', {
                        children: scopeId === 'unassigned'
                          ? `当前只显示未分派店铺的采集行（${NUM(s.count)} 行）：这些行还没分派，跟价 / 上架前先分派到店铺。`
                          : `另有 ${NUM(d.unassignedIncluded)} 行未分派店铺的行，已一并显示（采集箱全店共用，分派只是给行打标签）。`
                      }),
                      jsx(Button, {
                        size: 'xs',
                        variant: 'ghost',
                        onClick: () => setScopeOverride(scopeId === 'unassigned' ? '' : 'unassigned'),
                        children: scopeId === 'unassigned' ? '回到本店视图' : '只看未分派'
                      })
                    ]
                  })
                : null,
              jsx(Grid, {
                cols: 4,
                children: [
                  jsx(Metric, { label: '采集箱商品', value: NUM(s.count), sub: `未分派 ${NUM(s.unassigned)} · 已分派 ${NUM(s.assigned)}` }),
                  jsx(Metric, { label: '采购成本合计', value: ZAR(s.totalCost) }),
                  jsx(Metric, { label: '平均毛利率', value: PCT(s.avgMargin), tone: s.avgMargin >= 20 ? 'good' : 'bad' }),
                  jsxs('div', {
                    className: 'flex flex-wrap items-end gap-2',
                    children: [
                      jsx('div', { className: 'w-36', children: jsx(StorePick, { value: bulkStore, onChange: setBulkStore, label: '批量分派到店铺' }) }),
                      jsx(Button, {
                        size: 'sm',
                        variant: 'outline',
                        disabled: !picked.length || assign.isPending,
                        onClick: () => assign.mutate({ ids: picked, storeId: bulkStore || null }, {
                          onSuccess: r => {
                            setPicked([])
                            done(storeId ? '已分派' + ((r.conflicts || []).length ? '（有冲突，见上方提示）' : '') : '已取消分派')
                          },
                          onError: fail
                        }),
                        children: '应用分派'
                      }),
                      jsx(Button, {
                        size: 'sm',
                        disabled: !picked.length || promote.isPending || !bulkStore,
                        onClick: () => promote.mutate({ ids: picked, storeId: bulkStore }, {
                          onSuccess: r => { setPicked([]); done(`已为店铺生成 ${r.count} 条上架草稿`) },
                          onError: fail
                        }),
                        children: '转上架草稿'
                      }),
                      jsx(Button, {
                        size: 'sm',
                        variant: 'ghost',
                        disabled: !picked.length || reanalyze.isPending,
                        onClick: () => reanalyze.mutate({ ids: picked, withAi: true }, { onSuccess: r => done(`已重新分析 ${(r.items || []).length} 个商品`), onError: fail }),
                        children: '重新分析'
                      }),
                      jsx(Button, {
                        size: 'sm',
                        disabled: !items.length || publish.isPending,
                        onClick: () =>
                          publish.mutate(
                            { ids: picked.length ? picked : undefined, dryRun: true },
                            {
                              onSuccess: r => {
                                setPub(r)
                                host.notify({ kind: 'info', message: r.message || '已生成上架预览' })
                              },
                              onError: fail
                            }
                          ),
                        children: publish.isPending ? '预演中…' : `一键上架（全店${picked.length ? ` · 已选 ${picked.length}` : ''}）`
                      }),
                      jsxs('div', {
                        className: 'flex items-center gap-2',
                        children: [
                          jsx(Pill, { tone: 'mute', children: `已选 ${picked.length}` }),
                          jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => setPicked(picked.length === items.length ? [] : allIds(items)), children: picked.length === items.length && items.length ? '取消全选' : '全选' })
                        ]
                      })
                    ]
                  })
                ]
              }),
              pubView
                ? jsx(Card, {
                    title: `一键上架${pubView.dryRun ? '（预览，未写入平台）' : '（已写入平台）'}${pubFromState ? ' · 上次运行 ' + (pubView.at || '') : ''} · ${pubView.message || ''}`,
                    children: jsxs('div', {
                      className: 'space-y-2 text-[0.8125rem]',
                      children: [
                        jsxs('div', {
                          className: 'flex flex-wrap items-center gap-2',
                          children: [
                            jsx(Pill, { tone: (pubView.summary || {}).created ? 'good' : 'mute', children: `已上架 ${NUM((pubView.summary || {}).created || 0)}` }),
                            jsx(Pill, { tone: (pubView.summary || {}).preview ? 'good' : 'mute', children: `将上架 ${NUM((pubView.summary || {}).preview || 0)}` }),
                            jsx(Pill, { tone: (pubView.summary || {}).skipped ? 'warn' : 'mute', children: `跳过 ${NUM((pubView.summary || {}).skipped || 0)}` }),
                            jsx(Pill, { tone: (pubView.summary || {}).failed ? 'bad' : 'mute', children: `失败 ${NUM((pubView.summary || {}).failed || 0)}` }),
                            jsx(Pill, { tone: (pubView.summary || {}).partial ? 'warn' : 'mute', children: `平台未接受部分字段 ${NUM((pubView.summary || {}).partial || 0)}` }),
                            jsx('span', {
                              className: 'text-[0.75rem] text-(--ui-text-quaternary)',
                              children: `店铺 ${(pubView.storeIds || []).map(id => (pubView.storeNames || {})[id] || id).join(' / ')} · 已上架判断读的是各店 live /offers`
                            }),
                            pubView.dryRun
                              ? jsx(Button, {
                                  size: 'sm',
                                  disabled: publish.isPending,
                                  onClick: () =>
                                    publish.mutate(
                                      { ids: picked.length ? picked : undefined, dryRun: false },
                                      {
                                        onSuccess: r => {
                                          setPub(r)
                                          refresh()
                                          host.notify({ kind: 'info', message: r.message || '一键上架完成' })
                                        },
                                        onError: fail
                                      }
                                    ),
                                  children: publish.isPending ? '写入中…' : '确认上架（真正写入平台）'
                                })
                              : null,
                            jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => setPub(null), children: '关闭' })
                          ]
                        }),
                        ...(pubView.items || []).map(it =>
                          jsxs(
                            'div',
                            {
                              key: it.id,
                              className: 'rounded border border-(--ui-stroke-secondary) p-2',
                              children: [
                                jsxs('div', {
                                  className: 'flex items-center justify-between gap-2',
                                  children: [
                                    jsx('span', { className: 'font-medium', children: (it.title || it.id).slice(0, 96) }),
                                    jsx('span', {
                                      className: 'shrink-0 tabular-nums text-(--ui-text-tertiary)',
                                      children: `${ZAR(it.price)} · ${it.tsin || it.barcode || ''}`
                                    })
                                  ]
                                }),
                                ...(it.stores || []).map((c, i) =>
                                  jsxs(
                                    'div',
                                    {
                                      key: `${it.id}-${i}`,
                                      className: 'flex items-start gap-2 text-[0.75rem]',
                                      children: [
                                        jsx(Pill, {
                                          tone: c.status === 'created' || c.status === 'preview' ? 'good' : c.status === 'skipped' ? 'warn' : 'bad',
                                          children: `${c.storeName || c.storeId} ${({ created: '已上架', preview: '将上架', skipped: '跳过', failed: '失败' }[c.status]) || c.status}`
                                        }),
                                        jsx('span', { className: 'text-(--ui-text-tertiary)', children: c.reason || '' })
                                      ]
                                    },
                                    i
                                  )
                                )
                              ]
                            },
                            it.id
                          )
                        ),
                        ...(pubView.notes || []).map((n, i) =>
                          jsx('div', { key: `pub-note-${i}`, className: 'text-[0.75rem] text-(--ui-text-quaternary)', children: n })
                        )
                      ]
                    })
                  })
                : null,
              jsx(Card, {
                title: '采集箱明细 = 跟卖池（内容只读：跟卖只能改价格与库存；要改标题/图片/描述请「转入新建草稿」）',
                children: items.length
                  ? jsx(Table, {
                      head: [
                        jsx(Th, { key: 'c', children: '' }),
                        jsx(Th, { key: 't', children: '商品' }),
                        jsx(Th, { key: 'v', children: '销量推算 / 跟卖' }),
                        jsx(Th, { key: 'p', right: true, children: '售价 / 成本' }),
                        jsx(Th, { key: 'ps', right: true, children: '跟卖：价格 / 库存' }),
                        jsx(Th, { key: 'n', right: true, children: '预估净利' }),
                        jsx(Th, { key: 'st', children: '分派店铺' }),
                        jsx(Th, { key: 's', children: '状态' }),
                        jsx(Th, { key: 'a', children: '操作' })
                      ],
                      children: items.map(it => {
                        const crawl = it.crawl || null
                        const sales = crawl && crawl.sales
                        // 深链（从商品管理/竞品跳进来）直接展开对应那一行；手点则用 openId
                        const open = openId === it.id || (!openId && !!queuedTarget && (it.tsin === queuedTarget || it.sourceUrl === queuedTarget))
                        return jsxs(Fragment, {
                          children: [
                          jsxs(
                          'tr',
                          {
                            children: [
                              jsx(Td, { children: jsx('input', { type: 'checkbox', checked: picked.includes(it.id), onChange: () => toggle(it.id) }) }),
                              jsx(Td, {
                                className: 'max-w-[24rem]',
                                children: jsxs('div', {
                                  className: 'flex gap-2',
                                  children: [
                                    jsx(Thumb, { src: it.imageUrl || (it.images || [])[0] }),
                                    jsxs('div', {
                                      className: 'min-w-0 space-y-0.5',
                                      children: [
                                        jsx('div', { className: 'truncate', title: it.title, children: it.title || '（未取到标题）' }),
                                        jsx('div', {
                                          className: 'truncate text-[0.6875rem] text-(--ui-text-quaternary)',
                                          children: `${it.brand || '—'} · ${it.categoryPath || it.category || '—'} · ${it.tsin}`
                                        }),
                                        it.description
                                          ? jsx('div', {
                                              className: 'line-clamp-2 text-[0.6875rem] text-(--ui-text-tertiary)',
                                              title: it.description,
                                              children: it.description
                                            })
                                          : jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '暂无全文：点「重新抓取」回填图片与文案' }),
                                        (it.images || []).length
                                          ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `${it.images.length} 张图片已采集` })
                                          : null,
                                        // 三角形下拉放在标题下方（原来挤在右侧窄格里，太不显眼）
                                        jsx('button', {
                                          type: 'button',
                                          className: 'mt-0.5 text-left text-[0.6875rem] text-(--ui-text-secondary) hover:text-(--ui-accent)',
                                          onClick: () => setOpenId(open ? '' : it.id),
                                          children: `${open ? '\u25bc' : '\u25b6'} 核算与利润`
                                        })
                                      ]
                                    })
                                  ]
                                })
                              }),
                              jsx(Td, {
                                className: 'text-[0.75rem]',
                                children: sales
                                  ? jsxs('div', {
                                      children: [
                                        jsx('div', { children: `月销 ${NUM(sales.estimated_monthly_sales)} · 日均 ${sales.estimated_daily_sales}` }),
                                        jsxs('div', {
                                          className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                                          children: `留评率 ${PCT((crawl.rate || {}).reviewRate * 100)}（${(crawl.rate || {}).rateSource || 'default'}）· 跟卖 ${NUM((crawl.product || {}).sellerCount)}`
                                        })
                                      ]
                                    })
                                  : jsxs('div', {
                                      className: 'space-y-1',
                                      children: [crawlTag(crawl), jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '选中后点「重新分析」' })]
                                    })
                              }),
                              jsx(Td, { right: true, children: jsxs('div', { children: [ZAR(it.estSalePrice), jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `成本 ${ZAR(it.cost)}` })] }) }),
                              jsx(Td, {
                                children: jsx(PoolPriceStock, {
                                  item: it,
                                  busy: updPool.isPending,
                                  onSave: v =>
                                    updPool.mutate({ id: it.id, price: v.price, stock: v.stock }, {
                                      onSuccess: () => done('价格/库存已保存（跟卖口径：只写这两项）'),
                                      onError: fail
                                    })
                                })
                              }),
                              jsx(Td, {
                                right: true,
                                children: jsx(PoolPnl, { item: it, open: open, onToggle: () => setOpenId(open ? '' : it.id) })
                              }),
                              jsx(Td, {
                                children: jsxs('div', {
                                  className: 'space-y-1',
                                  children: [
                                    jsx(StorePick, {
                                      value: it.assignedStoreId || '',
                                      compact: true,
                                      onChange: v => assign.mutate({ ids: [it.id], storeId: v || null }, { onSuccess: () => done('分派已更新'), onError: fail })
                                    }),
                                    it.assignedStoreName ? jsx(Pill, { tone: 'good', children: it.assignedStoreName }) : null,
                                    it.listedStores && it.listedStores.length
                                      ? jsxs('div', {
                                          className: 'space-y-0.5',
                                          children: [
                                            jsx(Pill, { tone: 'good', children: `已在 ${it.listedStores.length} 家店上架` }),
                                            jsx('div', {
                                              className: 'text-[0.625rem] text-(--ui-text-quaternary)',
                                              children: it.listedStores
                                                .map(s => `${s.storeName || s.storeId}（Offer ${s.offerId || '—'}）`)
                                                .join(' / ')
                                            })
                                          ]
                                        })
                                      : null
                                  ]
                                })
                              }),
                              jsx(Td, {
                                children: jsxs('div', {
                                  className: 'space-y-1',
                                  children: [
                                    jsxs('div', {
                                      className: 'flex flex-wrap gap-1',
                                      children: [
                                        jsx(Pill, {
                                          tone: it.state === 'promoted' ? 'good' : 'mute',
                                          children: it.state === 'promoted' ? `已转草稿 ${it.draftId || ''}` : '跟卖池'
                                        }),
                                        jsx(Pill, { tone: 'mute', children: it.intent === 'new' ? '新建品' : '跟卖品' })
                                      ]
                                    }),
                                    jsx(Pill, { tone: it.status === 'promoted' ? 'good' : 'mute', children: it.status === 'promoted' ? '已上架' : it.status === 'ready' ? '可上架' : '待完善' }),
                                    it.sellRoute
                                      ? jsx(Pill, {
                                          tone: it.sellRoute.route === 'offer' ? 'good' : 'warn',
                                          children: it.sellRoute.targetLabel || (it.sellRoute.route === 'offer' ? '可跟卖' : '需建档')
                                        })
                                      : null
                                  ]
                                })
                              }),
                              jsx(Td, {
                                children: jsxs('div', {
                                  className: 'flex flex-wrap gap-1',
                                  children: [
                                    jsx(Button, {
                                      size: 'xs',
                                      variant: 'ghost',
                                      disabled: promote.isPending || it.state === 'promoted',
                                      onClick: () =>
                                        promote.mutate({ ids: [it.id] }, {
                                          onSuccess: r => done(`已转入新建草稿箱：${((r || {}).created || [{}])[0].id || ''}（在「上架编排」里继续编辑）`),
                                          onError: fail
                                        }),
                                      children: it.state === 'promoted' ? '已转草稿' : '转入新建草稿'
                                    }),
                                    jsx(Button, {
                                      size: 'xs',
                                      variant: 'outline',
                                      onClick: () => {
                                        const route = it.sellRoute || {}
                                        if (route.route === 'offer') {
                                          $productsFocus.set(it.sku || '')
                                          $module.set('products')
                                          done(`该商品平台已在售：已跳到「商品管理」按 SKU ${it.sku || it.tsin} 跟卖`)
                                        } else {
                                          $listingPrefill.set(route.targetUrl || it.productTargetUrl || it.tsin || '')
                                          $module.set('listings')
                                          done('新品：已带入「上架编排」并按官方字段预填')
                                        }
                                      },
                                      children: (it.sellRoute || {}).route === 'offer' ? '去跟卖' : '去建档'
                                    }),
                                    jsx(Button, {
                                      size: 'xs',
                                      variant: 'ghost',
                                      disabled: refreshOne.isPending,
                                      onClick: () =>
                                        refreshOne.mutate({ ids: [it.id] }, {
                                          onSuccess: () => done('已重新抓取：图片与全文已回填'),
                                          onError: fail
                                        }),
                                      children: '重新抓取'
                                    }),
                                    jsx(Button, {
                                      size: 'xs',
                                      variant: open ? 'outline' : 'ghost',
                                      title: '就在这一行看：销量推算 / 跟卖结构 / AI 价值（数字取自缓存，要最新点「重新分析（联网）」）',
                                      onClick: () => setOpenId(open ? '' : it.id),
                                      children: open ? '收起分析 ▴' : '分析 ▾'
                                    }),
                                    jsx(Button, {
                                      size: 'xs',
                                      variant: 'ghost',
                                      onClick: () => promote.mutate({ ids: [it.id], storeId: it.assignedStoreId || bulkStore }, { onSuccess: () => done('已生成草稿'), onError: fail }),
                                      children: '上架'
                                    }),
                                    jsx(Button, {
                                      size: 'xs',
                                      variant: 'ghost',
                                      onClick: () => rest(`/collection/${it.id}`, { method: 'DELETE' }).then(() => done('已移除'), fail),
                                      children: '移除'
                                    })
                                  ]
                                })
                              })
                            ]
                          },
                          it.id
                        ),
                          open
                            ? jsx('tr', {
                                children: jsx('td', {
                                  colSpan: 9,
                                  className: 'border-t border-(--ui-stroke-secondary) px-3 py-3',
                                  children: jsxs('div', {
                                    className: 'space-y-3',
                                    children: [
                                      jsx(PoolProfit, {
                                        item: it,
                                        busy: updPool.isPending,
                                        onSaveCosts: v =>
                                          updPool.mutate(Object.assign({ id: it.id }, v), {
                                            onSuccess: () => done('核算参数已保存（本地账本；平台侧只有价格/库存会写）'),
                                            onError: fail
                                          })
                                      }),
                                      jsx(Analytics, { embedded: true, preset: it.plid || it.sourceUrl || it.tsin || '', item: it })
                                    ]
                                  })
                                })
                              })
                            : null
                          ]
                        }, 'row-' + it.id)
                      })
                    })
                  : jsx(EmptyState, { title: '采集箱是空的', description: '粘贴一个 Takealot 链接或 TSIN 开始采集' })
              })
            ]
          })
        }
      })
    ]
  })
}

// ── 上架编排：类目三列选择 → 官方字段行编辑 → 校验 → 导出官方装载表 ─────────────
const WARRANTY_TYPES = ['Supplier', 'Limited', 'Full', 'Lifetime']
const PRODUCT_TYPES = ['Single', 'Variant Parent', 'Variant Child']
const LIMITS = { title: 75, subtitle: 110, features: 200, barcode: 20, images: 20 }

// ── 变体（变体主题 → 按主题出现的属性列 → 每行自己的 SKU / 条码 / 图片）──────────
// 参考实现：OpenListing TakealotPublishForm。主题表、轴的官方列名与候选全部来自后端
// GET /meta/variant-themes（真实数据），前端不预置任何颜色/尺寸/年龄候选。   VARIANT-EDITOR-PATCH-v1
const VARIANT_HINT =
  '按 Takealot 官方逻辑：先选【变体主题】，主题决定下面出现哪些属性列（颜色=受控下拉、包装数量=数字、年龄段=候选）。留空=无变体单品。导出时自动展开成 1 父行 + N 变体子行。'
const FIELD_CLS = 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1.5 py-1 text-[0.8125rem]'

const blankVariantModel = () => ({ theme: '', themeLabel: '', customName: '', customNames: [], axes: [], rows: [] })

const variantModel = row => {
  const v = (row && row.variants) || {}
  if (Array.isArray(v) || typeof v !== 'object') return blankVariantModel()
  return {
    theme: String(v.theme || ''),
    themeLabel: String(v.themeLabel || ''),
    customName: String(v.customName || ''),
    customNames: (Array.isArray(v.customNames) && v.customNames.length ? v.customNames : v.customName ? [v.customName] : [])
      .map(x => String(x || ''))
      .slice(0, 2),
    axes: Array.isArray(v.axes) ? v.axes : [],
    rows: Array.isArray(v.rows) ? v.rows : []
  }
}
// 兼容老形状（采集箱转入 / 预填造的 variantThemes + variants 数组）→ 不丢已填的变体
const variantModelFromDraft = d => {
  const model = variantModel({ variants: d && d.variants })
  if (model.axes.length || model.rows.length) return model
  const themes = Array.isArray(d && d.variantThemes) ? d.variantThemes.filter(Boolean).slice(0, 2) : []
  const rows = Array.isArray(d && d.variants) ? d.variants.map(variantRowView) : []
  return {
    ...blankVariantModel(),
    axes: themes.map(t => ({ key: String(t), label: String(t), columnName: String(t), required: true })),
    rows: rows
  }
}
const variantImageLines = text => String(text || '').split('\n').map(s => s.trim()).filter(Boolean)
const isHttpUrl = u => /^https?:\/\/\S+$/i.test(String(u || '').trim())
const variantRowView = r => ({
  values: (r && r.values) || {},
  sku: String((r && r.sku) || ''),
  barcode: String((r && r.barcode) || ''),
  imagesText: Array.isArray(r && r.images) ? r.images.join('\n') : String((r && r.imagesText) || '')
})
// 后端主题表 → 轴列（列名=官方字段名；有 options 的用受控下拉）
const variantAxesFor = (meta, themeKey, customNames) => {
  const def = ((meta && meta.themes) || []).find(t => String(t.key) === String(themeKey || ''))
  if (!def) return []
  if (String(themeKey || '') === 'custom') {
    return (customNames || []).filter(Boolean).map(n => ({ key: n, label: n, columnName: n, required: true, options: [], inputType: 'text', reason: '', resolved: true }))
  }
  return (def.axes || []).map(a => ({
    key: String(a.key || ''),
    label: a.displayName || a.label || a.key,
    columnName: a.columnName || a.fieldId || a.key,
    required: a.required !== false,
    options: Array.isArray(a.options) ? a.options : [],
    inputType: a.inputType || ((a.options || []).length ? 'select' : 'text'),
    reason: a.reason || '',
    resolved: a.resolved !== false
  }))
}
// 渲染用轴列：草稿里存的轴（key/列名）为主，控件信息走主题表；取不到主题表就给文本输入
const variantAxesResolved = (model, meta) => {
  const custom = (model.customNames || []).filter(Boolean)
  const fromMeta = variantAxesFor(meta, model.theme, custom)
  const own = Array.isArray(model.axes) ? model.axes : []
  if (!own.length) return fromMeta
  if (!fromMeta.length) return own.map(a => ({ ...a, required: a.required !== false, options: [], inputType: 'text', resolved: false }))
  return own.map(a => {
    const hit = fromMeta.find(m => String(m.key) === String(a.key) || (a.columnName && String(m.columnName) === String(a.columnName)))
    return hit
      ? { ...hit, key: String(a.key), label: a.label || hit.label, columnName: a.columnName || hit.columnName, required: a.required !== false }
      : { ...a, required: a.required !== false, options: [], inputType: 'text', resolved: false }
  })
}
// 变体本地检查（与服务端 /listings/validate 的 VARIANT_* 同义，先在界面提示）
function variantIssues(row) {
  const model = variantModel(row)
  const axes = model.axes
  const out = []
  const rows = model.rows.map(variantRowView)
  const filled = rows.filter(r => Object.values(r.values).some(v => String(v || '').trim()))
  if (model.theme === 'custom' && !model.customNames.filter(Boolean).length) out.push('自定义主题要填轴名（列名=轴名）')
  if (axes.length && !filled.length) out.push('已选变体主题，但还没有变体行（至少 1 行）')
  if (!axes.length && filled.length) out.push('有变体行但没有变体主题：轴值落不到装载表列')
  const seen = {}
  filled.forEach((r, i) => {
    axes.filter(a => a.required !== false).forEach(a => {
      if (!String(r.values[a.key] || '').trim()) out.push(`变体 ${i + 1} 缺「${a.label}」值`)
    })
    const sig = axes.map(a => String(r.values[a.key] || '').trim().toLowerCase()).join('|')
    if (sig && seen[sig]) out.push(`变体 ${i + 1} 的轴值与变体 ${seen[sig]} 重复`)
    seen[sig] = i + 1
    variantImageLines(r.imagesText).forEach(u => {
      if (!isHttpUrl(u)) out.push(`变体 ${i + 1} 图片 URL 非法：${u.slice(0, 36)}`)
    })
  })
  return out
}
const variantExportPlan = row => {
  const model = variantModel(row)
  const filled = model.rows.map(variantRowView).filter(r => Object.values(r.values).some(v => String(v || '').trim()))
  return {
    hasVariants: model.axes.length > 0 && filled.length > 0,
    variants: model.axes.length ? filled.length : 0,
    rows: model.axes.length && filled.length ? filled.length + 1 : 1
  }
}
const variantPayload = row => {
  const model = variantModel(row)
  return {
    theme: model.theme,
    themeLabel: model.themeLabel,
    customName: model.customName,
    customNames: model.customNames.slice(0, 2),
    axes: model.axes.map(a => ({ key: String(a.key || ''), label: String(a.label || a.key || ''), columnName: String(a.columnName || a.key || ''), required: a.required !== false })),
    rows: model.rows.map(variantRowView).map(v => ({
      values: Object.fromEntries(Object.entries(v.values).map(([k, val]) => [k, val == null ? '' : String(val)])),
      sku: v.sku.trim(),
      barcode: v.barcode.trim(),
      images: variantImageLines(v.imagesText)
    }))
  }
}

const blankRow = () => ({
  sku: '',
  productType: 'Single',
  variantGroup: '',
  title: '',
  subtitle: '',
  description: '',
  features: '',
  brand: '',
  barcode: '',
  whatsInTheBox: '',
  imagesText: '',
  videoUrl: '',
  warrantyType: 'Supplier',
  warrantyPeriod: 12,
  categoryPath: '',
  mainCategory: '',
  lowestCategory: '',
  // 必填属性是按叶子类目（taxonomy_id）给的，必须随行保存
  taxonomyId: '',
  attributes: {},
  variants: blankVariantModel(),
  price: '',
  qty: 10,
  status: 'draft'
})

const rowImages = row =>
  String(row.imagesText || '')
    .split(/[\n,]/)
    .map(s => s.trim())
    .filter(Boolean)
    .slice(0, LIMITS.images)

const isAssignedBarcode = bc => /^MPTALX[\w-]*/i.test(String(bc || '').trim())
const isYouTube = u => /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\//i.test(String(u || '').trim())

function localIssues(row) {
  const out = []
  if (!String(row.title || '').trim()) out.push('标题 Title 必填')
  else if (row.title.length > LIMITS.title) out.push(`标题超限 ${row.title.length}/${LIMITS.title}`)
  if (row.subtitle && row.subtitle.length > LIMITS.subtitle) out.push(`副标题超限 ${row.subtitle.length}/${LIMITS.subtitle}`)
  const f = String(row.features || '').trim()
  if (!f) out.push('关键卖点 Key Selling Features 必填')
  else if (f.length < LIMITS.features) out.push(`卖点不足 ${f.length}/${LIMITS.features} 字符`)
  if (!row.lowestCategory && !row.categoryPath) out.push('未选择末级类目')
  const imgs = rowImages(row)
  if (!imgs.length) out.push('至少 1 张封面主图')
  if (!WARRANTY_TYPES.includes(row.warrantyType)) out.push('保修类型不合法')
  const m = Number(row.warrantyPeriod)
  if (!(m >= 6 && m <= 180)) out.push('保修月数需 6–180')
  if (row.warrantyType === 'Lifetime' && m < 60) out.push('Lifetime 保修需 ≥60 月')
  if (String(row.barcode || '').length > LIMITS.barcode) out.push(`条码超长 >${LIMITS.barcode}`)
  return out.concat(variantIssues(row))
}

const rowWarnings = row => {
  const out = []
  if (isAssignedBarcode(row.barcode)) out.push('MPTALX 占位码是 Takealot 生成的，新品不能复用（导出时留空由平台生成）')
  if (row.videoUrl && !isYouTube(row.videoUrl)) out.push('视频链接非 YouTube，Takealot 只接受 YouTube')
  if (String(row.features || '').trim().length >= LIMITS.features && String(row.features).length < 240) out.push('卖点刚过线，建议补足规格参数更易过审')
  return out
}

function LField({ label, hint, counter, bad, children, className }) {
  return jsxs('label', {
    className: cn('flex flex-col gap-1', className),
    children: [
      jsxs('div', {
        className: 'flex items-baseline justify-between gap-2 text-[0.6875rem]',
        children: [
          jsx('span', { className: 'text-(--ui-text-quaternary)', children: label }),
          counter ? jsx('span', { className: cn('tabular-nums', bad ? 'text-red-400' : 'text-(--ui-text-quaternary)'), children: counter }) : null
        ]
      }),
      children,
      hint ? jsx('div', { className: cn('text-[0.6875rem]', bad ? 'text-red-400' : 'text-(--ui-text-quaternary)'), children: hint }) : null
    ]
  })
}

// ── 变体编辑器：主题下拉 + 按主题出现的轴列 + 每行自己的 SKU/条码/图片 ──────────
function VariantEditor({ meta, model, onChange }) {
  const themes = (meta && meta.themes) || []
  const customNames = model.customNames
  const axes = variantAxesResolved(model, meta)
  const rows = model.rows.map(variantRowView)
  const labelOf = key => {
    const def = themes.find(t => String(t.key) === String(key))
    return (def && def.label) || ''
  }
  const commit = next => {
    const theme = next.theme === undefined ? model.theme : next.theme
    const names = ((next.customNames === undefined ? customNames : next.customNames) || []).slice(0, 2)
    onChange({ ...model, ...next, customNames: names, themeLabel: labelOf(theme), axes: variantAxesFor(meta, theme, names) })
  }
  const setRow = (i, changes) => commit({ rows: rows.map((r, j) => (j === i ? { ...r, ...changes } : r)) })
  const plan = variantExportPlan({ variants: model })
  const problems = variantIssues({ variants: model })
  const metaWarnings = ((meta && meta.warnings) || []).slice(0, 3)
  const noMeta = !themes.length

  const card = (r, i) => {
    const lines = variantImageLines(r.imagesText)
    const badLines = lines.filter(u => !isHttpUrl(u))
    return jsxs(
      'div',
      {
        className: 'space-y-2 rounded border border-(--ui-stroke-secondary) p-2',
        children: [
          jsxs('div', {
            className: 'flex items-center justify-between gap-2',
            children: [
              jsx('div', { className: 'text-[0.75rem] font-medium', children: `变体 ${i + 1}` }),
              jsx(Button, {
                size: 'xs',
                variant: 'ghost',
                title: '删除这个变体',
                onClick: () => commit({ rows: rows.filter((_, j) => j !== i) }),
                children: '删'
              })
            ]
          }),
          jsx('div', {
            className: 'grid gap-2 sm:grid-cols-2 lg:grid-cols-4',
            children: axes
              .map(a =>
                jsx(LField, {
                  key: `axis-${a.key}`,
                  label: a.required === false ? a.label : `${a.label} *`,
                  hint: a.resolved === false ? '官方数据没有这一列，手填' : a.reason ? '官方无候选，手填' : null,
                  children: (a.options || []).length
                    ? jsx('select', {
                        value: String(r.values[a.key] || ''),
                        onChange: e => setRow(i, { values: { ...r.values, [a.key]: e.target.value } }),
                        className: FIELD_CLS,
                        children: [jsx('option', { key: 'none', value: '', children: '—' })].concat(
                          a.options.map((o, k) => jsx('option', { key: `o${k}`, value: String(o.label), children: String(o.label) }))
                        )
                      })
                    : jsx(Input, {
                        type: a.inputType === 'number' ? 'number' : 'text',
                        value: String(r.values[a.key] || ''),
                        placeholder: a.inputType === 'number' ? '如 2' : '手填该轴的值',
                        onChange: e => setRow(i, { values: { ...r.values, [a.key]: e.target.value } })
                      })
                })
              )
              .concat([
                jsx(LField, {
                  key: 'sku',
                  label: '变体 SKU（留空自动）',
                  children: jsx(Input, { value: r.sku, onChange: e => setRow(i, { sku: e.target.value }) })
                }),
                jsx(LField, {
                  key: 'barcode',
                  label: '变体条码 GS1（可留空）',
                  children: jsx(Input, {
                    value: r.barcode,
                    placeholder: '留空由 Takealot 生成',
                    onChange: e => setRow(i, { barcode: e.target.value })
                  })
                })
              ])
          }),
          jsx(LField, {
            label: '该变体图片 URL（每行一个，留空则用主图）',
            counter: `${lines.length} 个 URL`,
            bad: badLines.length > 0,
            hint: badLines.length
              ? `每行一个公网 http(s) URL；这 ${badLines.length} 行不是合法 URL：${badLines.slice(0, 2).join(' / ')}`
              : '每行一个公网 http(s) URL；留空则用主行的图片',
            children: jsx(Textarea, {
              rows: 2,
              value: r.imagesText,
              placeholder: 'https://…/green.file',
              onChange: e => setRow(i, { imagesText: e.target.value })
            })
          })
        ]
      },
      `variant-${i}`
    )
  }

  return jsxs('div', {
    className: 'space-y-2 rounded border border-(--ui-stroke-secondary) p-3',
    children: [
      jsxs('div', {
        className: 'flex flex-wrap items-center justify-between gap-2',
        children: [
          jsx('div', { className: 'text-[0.8125rem] font-medium', children: '产品变体 Variants（可选）' }),
          jsx(Pill, {
            tone: plan.hasVariants ? 'good' : 'mute',
            children: plan.hasVariants ? `导出将生成 ${plan.rows} 行（1 父 + ${plan.variants} 变体）` : '无变体：导出 1 行（Single）'
          })
        ]
      }),
      jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: VARIANT_HINT }),
      jsx(LField, {
        label: '变体主题 Variant Theme',
        hint: (meta && meta.taxonomyName)
          ? `主题与轴来自官方数据：装载表 ${meta.loadsheetId}（${meta.loadsheetName}） · 类目 ${meta.taxonomyName}`
          : '主题与轴的官方列名/候选来自 GET /meta/variant-themes（选定末级类目后自动取到）',
        children: jsx('select', {
          value: model.theme,
          onChange: e => commit({ theme: e.target.value }),
          className: FIELD_CLS,
          children: (noMeta ? [{ key: '', label: '无变体（单品）' }] : themes).map(t =>
            jsx('option', { key: String(t.key) || 'none', value: String(t.key), children: t.label })
          )
        })
      }),
      model.theme === 'custom'
        ? jsxs('div', {
            className: 'grid gap-2 sm:grid-cols-2',
            children: [0, 1].map(i =>
              jsx(LField, {
                key: `custom-axis-${i}`,
                label: i === 0 ? '自定义轴 1（列名 = 轴名）' : '自定义轴 2（可选）',
                children: jsx(Input, {
                  value: customNames[i] || '',
                  placeholder: i === 0 ? '如 Material' : '如 Style',
                  onChange: e => {
                    const next = [customNames[0] || '', customNames[1] || '']
                    next[i] = e.target.value
                    commit({ customNames: next })
                  }
                })
              })
            )
          })
        : null,
      axes.length
        ? jsxs('div', {
            className: 'space-y-2',
            children: [
              jsx('div', {
                className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                children: `属性列（导出列名 = 官方字段名）：${axes.map(a => a.columnName).join(' · ')}`
              })
            ]
              .concat(rows.map((r, i) => card(r, i)))
              .concat([
                jsx(Button, {
                  key: 'add-variant',
                  size: 'xs',
                  variant: 'outline',
                  onClick: () => commit({ rows: rows.concat([{ values: {}, sku: '', barcode: '', imagesText: '' }]) }),
                  children: '+ 添加变体'
                })
              ])
          })
        : jsx('div', {
            className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
            children: '留空＝无变体单品（导出 1 行 Single）。选好主题后这里出现该主题的属性列。'
          }),
      jsxs('div', {
        className: 'space-y-1',
        children: [
          noMeta
            ? jsx('div', {
                className: 'text-[0.6875rem] text-amber-400',
                children: '变体主题表取不到（/meta/variant-themes 无响应）：轴列名与候选给空，不编。'
              })
            : null
        ]
          .concat(metaWarnings.map((w, i) => jsx('div', { key: `mw${i}`, className: 'text-[0.6875rem] text-amber-400', children: w })))
          .concat([
            problems.length
              ? jsx('ul', {
                  className: 'ml-4 list-disc space-y-0.5 text-[0.6875rem] text-red-400',
                  children: problems.map((p, i) => jsx('li', { children: p }, i))
                })
              : jsx('div', {
                  className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                  children: plan.hasVariants
                    ? `变体就绪：导出 ${plan.rows} 行（1 父 + ${plan.variants} 变体），父行轴列留空`
                    : '未启用变体：按单品导出（1 行）'
                })
          ])
      })
    ]
  })
}


const savedWorkbench = () => {
  try {
    const saved = storage && storage.get('listingsWorkbench', null)
    return Array.isArray(saved) && saved.length ? saved.map(r => ({ ...blankRow(), ...r, variants: variantModel(r) })) : null
  } catch (e) {
    return null
  }
}
const savedPick = key => {
  try {
    return (storage && storage.get(key, '')) || ''
  } catch (e) {
    return ''
  }
}

function Listings() {
  const storeId = useValue($storeId)
  const [rows, setRows] = useState(() => savedWorkbench() || [blankRow()])
  const [active, setActive] = useState(0)
  // 部门/装载表选择落盘：重进上架编排不用重选；渲染 harness 也能用 state 里的
  // listingsDept / listingsLoadsheet 直接把某个装载表的类目页打开来验证。
  const [dept, setDept] = useState(() => (storage && storage.get('listingsDept', '')) || '')
  const [lsId, setLsId] = useState(() => (storage && storage.get('listingsLoadsheet', '')) || '')
  useEffect(() => {
    if (!storage) return
    storage.set('listingsDept', dept)
    storage.set('listingsLoadsheet', lsId)
  }, [dept, lsId])
  const [leafQ, setLeafQ] = useState('')
  const [prefillTarget, setPrefillTarget] = useState('')
  const [aiKeywords, setAiKeywords] = useState('')
  const [aiSpec, setAiSpec] = useState('')
  const [aiSpecResult, setAiSpecResult] = useState(null)
  const [checked, setChecked] = useState(null)
  const [prefillNote, setPrefillNote] = useState('')
  const [pickedDrafts, setPickedDrafts] = useState([])
  const [dupes, setDupes] = useState(null)
  const [dupeBusy, setDupeBusy] = useState(false)
  const [batchMsg, setBatchMsg] = useState('')
  const toggleDraft = id => setPickedDrafts(p => (p.includes(id) ? p.filter(x => x !== id) : p.concat(id)))
  const runDuplicates = async ids => {
    setDupeBusy(true)
    setBatchMsg('')
    try {
      const r = await rest('/listings/duplicates', { method: 'POST', body: { ids: ids || [], storeId } })
      setDupes(r)
      const n = r && r.total
      setBatchMsg(n ? `发现 ${n} 处重复/冲突（下方明细）` : '没有发现重复或冲突')
    } catch (e) {
      setBatchMsg(`检测失败：${msg(e)}`)
    } finally {
      setDupeBusy(false)
    }
  }
  const deleteDrafts = async ids => {
    if (!ids.length) return
    setBatchMsg('')
    try {
      const r = await rest('/listings/drafts/delete', { method: 'POST', body: { ids } })
      setBatchMsg(r && r.ok ? `已删除 ${r.count} 个草稿` : `删除未完成：${(r && r.error) || '未知'}`)
      setPickedDrafts([])
      refresh()
    } catch (e) {
      setBatchMsg(`删除失败：${msg(e)}`)
    }
  }

  // 未保存的编排行落 storage：刷新/切模块回来不丢（变体行也一起）
  useEffect(() => {
    try {
      storage && storage.set('listingsWorkbench', rows)
    } catch (e) {
    }
  }, [rows])
  const catalog = useApi('/meta/catalog', 'catalog')
  const leaves = useApi(`/meta/categories?loadsheet=${encodeURIComponent(lsId)}&q=${encodeURIComponent(leafQ)}&limit=40&zh=1`, `leaves:${lsId}:${leafQ}`, {
    enabled: !!lsId
  })
  // 搜完就把这一页丢给后端预热（后台线程），下次同类搜索直接命中缓存。
  useZhPrewarm('leaves', leaves.data && leaves.data.items)
  const drafts = useApi(`/listings/drafts?storeId=${encodeURIComponent(storeId)}`, `drafts:${storeId}`)
  const row = rows[active] || rows[0]
  const activeCat = row.categoryPath || row.lowestCategory || ''
  // 必填清单是按叶子类目（taxonomyId）给的：带上它，后端才能给该类的 required
  // 变体主题表（真实数据）：主题决定出现哪些轴列，列名/候选都来自后端
  const variantMeta = useApi(
    `/meta/variant-themes?loadsheetId=${encodeURIComponent(lsId)}&taxonomyId=${encodeURIComponent(row.taxonomyId || '')}`,
    `variantThemes:${lsId}:${row.taxonomyId || ''}`
  )
  const attrs = useApi(
    `/meta/attributes?category=${encodeURIComponent(activeCat)}&taxonomyId=${encodeURIComponent(row.taxonomyId || '')}`,
    `attrs:${activeCat}:${row.taxonomyId || ''}`,
    { enabled: !!activeCat }
  )
  const [prefillBusy, setPrefillBusy] = useState(false)
  // 选填属性默认折叠：官方选填字段动辄上百个，全展开没法用
  const [showOptional, setShowOptional] = useState(false)
  // Shared by the 预填 button and the cross-module landing ($listingPrefill).
  const runPrefill = async target => {
    const value = String(target || '').trim()
    if (!value) return
    setPrefillBusy(true)
    try {

                const r = await rest(`/listings/prefill?target=${encodeURIComponent(value)}&force=1`)
                if (!r || !r.ok) {
                  setPrefillNote((r && r.hint) || '预填失败：抓取通道不可用')
                  return
                }
                const d = r.draft || {}
                setRows(prev => {
                  const next = prev.slice()
                  next[active] = {
                    ...next[active],
                    ...d,
                    imagesText: (d.images || []).join('\n'),
                    variants: variantModelFromDraft(d)
                  }
                  return next
                })
                setPrefillNote(
                  r.route === 'offer'
                    ? `该商品在 Takealot 已存在（需走跟卖）：改库存与价格即可，不要新建装载表——新表会撞已有目录。`
                    : `未在平台找到同款：按新品刊登，字段已按官方装载表预填。`
                )
                host.notify({ kind: 'info', message: r.route === 'offer' ? '已在平台存在：建议走跟卖' : '已按新品预填' })
                  } catch (e) {
      fail(e)
    } finally {
      setPrefillBusy(false)
    }
  }
  const listingPrefill = useValue($listingPrefill)
  useEffect(() => {
    if (!listingPrefill) return
    setPrefillTarget(listingPrefill)
    $listingPrefill.set('')
    runPrefill(listingPrefill)
  }, [listingPrefill])
  const aiM = usePost('/ai/listing-copy')
  const aiSpecM = usePost('/ai/listing-copy-from-spec')
  const validM = usePost('/listings/validate')
  const saveM = usePost('/listings/draft')
  const fail = e => host.notify({ kind: 'error', message: msg(e) })

  const patch = (index, changes) => setRows(prev => prev.map((r, i) => (i === index ? { ...r, ...changes } : r)))
  const patchActive = changes => patch(active, changes)

  const payloadRow = r => ({
    ...r,
    price: Number(r.price) || undefined,
    qty: Number(r.qty) || 1,
    warrantyPeriod: Number(r.warrantyPeriod) || 12,
    images: rowImages(r),
    variants: variantPayload(r),
    storeId: r.storeId || storeId || undefined
  })

  // Two shapes: saved drafts export by id, unsaved workbench rows export inline.
  const exportPayload = async ({ ids, rowIndexes, filename }) => {
    try {
      let path = null
      if (rest.os && rest.os.pickSavePath) {
        path = await rest.os.pickSavePath({
          title: '导出 Takealot 官方装载表',
          defaultPath: filename || 'takealot-new-listing-loadsheet.xlsx',
          filters: [{ name: 'Excel', extensions: ['xlsx'] }]
        })
      }
      const body = { path: path || undefined }
      if (ids && ids.length) body.ids = ids
      else body.rows = (rowIndexes || rows.map((_, i) => i)).map(i => payloadRow(rows[i]))
      const r = await rest('/listings/loadsheet', { method: 'POST', body })
      host.notify({ kind: 'info', message: `装载表已生成：${r.path}（${r.rows} 行 / ${r.bytes} 字节）` })
    } catch (e) {
      fail(e)
    }
  }

  return jsxs('div', {
    className: 'space-y-3',
    children: [
      jsxs('div', {
        className: 'flex flex-wrap items-end gap-2',
        children: [
          jsx('div', { className: 'min-w-[16rem] flex-1', children: jsx(Input, { value: prefillTarget, placeholder: '预填：粘贴商品链接 / TSIN / PLID（走抓取，自动判断跟卖或新品）', onChange: e => setPrefillTarget(e.target.value) }) }),
          jsx(Button, {
            size: 'sm',
            disabled: prefillBusy || !prefillTarget.trim(),
            onClick: () => runPrefill(prefillTarget),
            children: prefillBusy ? '预填中…' : '预填'
          }),
          jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => setRows(prev => prev.concat(blankRow())) , children: '+ 新建行' }),
          jsx(Button, {
            size: 'sm',
            variant: 'outline',
            disabled: validM.isPending,
            onClick: () =>
              validM.mutate({ rows: rows.map(payloadRow) }, {
                onSuccess: r => {
                  setChecked(r)
                  host.notify({ kind: r.blockedCount ? 'error' : 'info', message: `校验完成：就绪 ${r.readyCount} 行，待修 ${r.blockedCount} 行` })
                },
                onError: fail
              }),
            children: validM.isPending ? '校验中…' : '校验全部'
          }),
          jsx(Button, { size: 'sm', disabled: !rows.length, onClick: () => exportPayload({}), children: '导出官方装载表' })
        ]
      }),
      prefillNote ? jsx('div', { className: 'rounded border border-(--ui-accent) px-3 py-2 text-[0.75rem] text-(--ui-accent)', children: prefillNote }) : null,
      jsxs('div', {
        className: 'grid gap-3 xl:grid-cols-[19rem_1fr]',
        children: [
          jsx(Card, {
            title: '类目三列（部门 → 装载表 → 末级类目）',
            extra: jsx(Pill, { tone: 'mute', children: '10,281 节点' }),
            children: jsx(Async, {
              query: catalog,
              children: c =>
                jsxs('div', {
                  className: 'space-y-2',
                  children: [
                    jsx('select', {
                      value: dept,
                      onChange: e => {
                        setDept(e.target.value)
                        setLsId('')
                      },
                      className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]',
                      children: [jsx('option', { value: '', children: '1. 选择部门 Department' })].concat(
                        (c.departments || []).map(d => jsx('option', { key: d.id, value: d.name, children: `${d.name}（${(d.loadsheets || []).length} 张装载表）` }))
                      )
                    }),
                    jsx('select', {
                      value: lsId,
                      onChange: e => setLsId(e.target.value),
                      className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]',
                      children: [jsx('option', { value: '', children: '2. 选择装载表 Loadsheet' })].concat(
                        (((c.departments || []).find(d => d.name === dept) || {}).loadsheets || []).map(s =>
                          jsx('option', { key: s.id, value: String(s.id), children: `${s.name}（${s.leafCount} 末级）` })
                        )
                      )
                    }),
                    jsxs('div', {
                      className: 'flex items-center gap-2',
                      children: [
                        jsx('div', {
                          className: 'flex-1',
                          children: jsx(Input, { size: 'sm', value: leafQ, placeholder: '过滤末级类目…', onChange: e => setLeafQ(e.target.value) })
                        }),
                        zhHint(leaves.data)
                          ? jsx('span', {
                              className: 'shrink-0 text-[0.6875rem] text-(--ui-text-quaternary)',
                              children: zhHint(leaves.data)
                            })
                          : null
                      ]
                    }),
                    lsId
                      ? jsx(Async, {
                          query: leaves,
                          children: l =>
                            jsx('div', {
                              className: 'max-h-64 space-y-0.5 overflow-auto',
                              children: (l.items || []).length
                                ? (l.items || []).map(x =>
                                    jsx(
                                      'button',
                                      {
                                        key: x.path,
                                        type: 'button',
                                        onClick: () => patchActive({ categoryPath: x.path, lowestCategory: x.name, mainCategory: dept, taxonomyId: String(x.id || x.nodeId || ''), attributes: {} }),
                                        className: cn(
                                          'block w-full truncate rounded px-1.5 py-1 text-left text-[0.6875rem] hover:bg-(--chrome-action-hover)',
                                          activeCat === x.path ? 'text-(--ui-accent)' : 'text-(--ui-text-tertiary)'
                                        ),
                                        title: x.pathZh || x.path,
                                        children: catLabel(x)
                                      },
                                      x.path
                                    )
                                  )
                                : jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '无匹配末级类目' })
                            })
                        })
                      : null
                  ]
                })
            })
          }),
          jsx(Card, {
            title: `新建 Listing 字段（第 ${active + 1} / ${rows.length} 行）`,
            extra: jsxs('div', {
              className: 'flex items-center gap-2',
              children: [
                jsx('div', { className: 'w-44', children: jsx(Input, { size: 'sm', value: aiKeywords, placeholder: 'AI 关键词（选填）', onChange: e => setAiKeywords(e.target.value) }) }),
                jsx(Button, {
                  size: 'xs',
                  disabled: aiM.isPending,
                  onClick: () =>
                    aiM.mutate(
                      {
                        keywords: aiKeywords.trim() || row.title || row.categoryPath || 'product',
                        category: activeCat,
                        language: 'en',
                        limits: { maxTitle: LIMITS.title, maxSubtitle: LIMITS.subtitle, minFeatures: LIMITS.features }
                      },
                      {
                        onSuccess: a =>
                          patchActive({
                            title: (a.title || '').slice(0, LIMITS.title),
                            subtitle: (a.subtitle || '').slice(0, LIMITS.subtitle),
                            features: a.features || (a.bullets || []).map(b => `- ${b}`).join('\n'),
                            whatsInTheBox: row.whatsInTheBox || a.boxContents || '',
                            barcode: row.barcode
                          }),
                        onError: fail
                      }
                    ),
                  children: aiM.isPending ? '生成中…' : 'AI 按官方限制生成文案'
                })
              ]
            }),
            children: jsxs('div', {
              className: 'space-y-3',
              children: [
                // ── AI 文案：大输入框（粘参数描述）→ 一键填入 标题/副标题/描述/盒子里有什么 ──
                // 红线：只用 spec 里真实出现的规格；抽不到的字段留空 + 列进 missing，不编造。
                jsxs('div', {
                  className: 'space-y-2 rounded border border-(--ui-stroke-secondary) p-3',
                  children: [
                    jsx(LField, {
                      label: 'AI 文案 · 产品参数描述（粘贴规格，AI 只写里面真实出现的规格）',
                      hint: '例：微波炉 长宽高 56x45x32cm 功率 1000W 容量 25L 不锈钢内胆 带转盘 —— 抽不到的规格一律留空并列出，不会编造',
                      children: jsx(Textarea, {
                        rows: 6,
                        className: 'min-h-[8rem]',
                        value: aiSpec,
                        placeholder: '把产品参数描述直接粘进来，例如：\n微波炉 长宽高 56x45x32cm 功率 1000W 容量 25L 不锈钢内胆 带转盘',
                        onChange: e => setAiSpec(e.target.value)
                      })
                    }),
                    jsxs('div', {
                      className: 'flex flex-wrap items-center gap-2',
                      children: [
                        jsx(Button, {
                          size: 'sm',
                          disabled: aiSpecM.isPending || !aiSpec.trim(),
                          onClick: () =>
                            aiSpecM.mutate(
                              {
                                spec: aiSpec,
                                categoryPath: row.categoryPath || activeCat || '',
                                brand: row.brand || '',
                                price: Number(row.price) || undefined,
                                keywords: String(aiKeywords || '').split(/[,，\s]+/).filter(Boolean)
                              },
                              {
                                onSuccess: r => {
                                  setAiSpecResult(r || null)
                                  if (!r || !r.ok) {
                                    fail(new Error((r && r.error) || (r && r.basis && r.basis[0]) || '按参数描述生成失败'))
                                    return
                                  }
                                  patchActive({
                                    title: (r.title || '').slice(0, LIMITS.title),
                                    subtitle: (r.subtitle || '').slice(0, LIMITS.subtitle),
                                    description: r.description || '',
                                    whatsInTheBox: r.whatsInTheBox || r.boxContents || '',
                                    features: (r.bullets || []).length ? (r.bullets || []).map(b => `- ${b}`).join('\n') : row.features
                                  })
                                  host.notify({
                                    kind: 'info',
                                    message: `已填入 ${(r.filled || []).join('/') || '（无）'}`
                                      + ((r.missing || []).length ? `；未编造、留空：${(r.missing || []).slice(0, 4).join('、')}` : '')
                                  })
                                },
                                onError: fail
                              }
                            ),
                          children: aiSpecM.isPending ? '生成中…' : '一键生成并填入内容'
                        }),
                        aiSpecResult
                          ? jsx(Pill, {
                              tone: aiSpecResult.llm === 'agnes' ? 'good' : 'warn',
                              children: aiSpecResult.llm === 'agnes'
                                ? `文案来源：AI（${aiSpecResult.llmModel || 'agnes'}）`
                                : aiSpecResult.llm === 'template'
                                  ? '文案来源：模板（LLM 调用失败，非 AI）'
                                  : '文案来源：模板（未配置 LLM Key，非 AI）'
                            })
                          : null,
                        aiSpecResult ? jsx(Pill, { tone: 'mute', children: `依据 ${(aiSpecResult.basis || []).length} 条` }) : null
                      ]
                    }),
                    aiSpecResult
                      ? jsxs('div', {
                          className: 'space-y-1 rounded border border-(--ui-stroke-secondary) p-2 text-[0.6875rem] text-(--ui-text-tertiary)',
                          children: [
                            jsx('div', { className: 'text-(--ui-text-secondary)', children: '生成依据（逐条对着参数描述原文；抽不到的字段留空）' }),
                            jsx('ul', {
                              className: 'ml-4 list-disc space-y-0.5',
                              children: (aiSpecResult.basis || []).map((b, i) => jsx('li', { children: b }, i))
                            }),
                            jsx('div', { children: `已填入 filled：${(aiSpecResult.filled || []).join('、') || '（无）'}` }),
                            jsx('div', { children: `缺失 missing（未编造，留空）：${(aiSpecResult.missing || []).join('、') || '（无）'}` }),
                            (aiSpecResult.guardDropped || []).length
                              ? jsx('div', { className: 'text-red-400', children: `守卫生效，已删除编造规格：${(aiSpecResult.guardDropped || []).join('、')}` })
                              : null
                          ]
                        })
                      : jsx('div', {
                          className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                          children: '点「一键生成并填入内容」后会在这里逐条列出：依据（对着参数描述原文）、已填入 filled、缺失 missing（未编造，留空）、被守卫删除的编造规格。'
                        })
                  ]
                }),
                jsxs('div', {
                  className: 'grid gap-3 lg:grid-cols-2',
                  children: [
                    jsx(LField, {
                      label: '标题 Title（官方硬限 ≤75）',
                      counter: `${String(row.title || '').length}/${LIMITS.title}`,
                      bad: String(row.title || '').length > LIMITS.title,
                      hint: String(row.title || '').length > LIMITS.title ? `已超标 ${String(row.title).length - LIMITS.title} 字符，Takealot 会直接拒收` : null,
                      children: jsx(Input, { value: row.title, placeholder: '[Brand] + [Product Type] + [Key Spec] + [Pack Count]', onChange: e => patchActive({ title: e.target.value }) })
                    }),
                    jsx(LField, {
                      label: '副标题 Subtitle（≤110，选填）',
                      counter: `${String(row.subtitle || '').length}/${LIMITS.subtitle}`,
                      bad: String(row.subtitle || '').length > LIMITS.subtitle,
                      children: jsx(Input, { value: row.subtitle, onChange: e => patchActive({ subtitle: e.target.value }) })
                    })
                  ]
                }),
                jsx(LField, {
                  label: '关键卖点 Key Selling Features（官方要求 ≥200 字符）',
                  counter: `${String(row.features || '').trim().length}/${LIMITS.features}`,
                  bad: String(row.features || '').trim().length < LIMITS.features,
                  hint: '一行一个卖点，建议以 “-” 开头：特性 + 规格参数；低于 200 字符会被审核打回',
                  children: jsx(Textarea, { rows: 5, value: row.features, onChange: e => patchActive({ features: e.target.value }) })
                }),
                jsx(LField, {
                  label: '描述 Description（正式英文段落，可继续编辑）',
                  counter: `${String(row.description || '').length} 字符`,
                  children: jsx(Textarea, {
                    rows: 6,
                    className: 'min-h-[8rem]',
                    value: row.description,
                    placeholder: '正式英文段落；「一键生成并填入内容」会写在这里，之后可继续编辑',
                    onChange: e => patchActive({ description: e.target.value })
                  })
                }),
                jsxs('div', {
                  className: 'grid gap-3 lg:grid-cols-3',
                  children: [
                    jsx(LField, { label: '品牌 Brand', children: jsx(Input, { value: row.brand, onChange: e => patchActive({ brand: e.target.value }) }) }),
                    jsx(LField, {
                      label: '条码 Barcode（GTIN/EAN-13）',
                      counter: `${String(row.barcode || '').length}/${LIMITS.barcode}`,
                      bad: isAssignedBarcode(row.barcode) || String(row.barcode || '').length > LIMITS.barcode,
                      hint: isAssignedBarcode(row.barcode) ? '这是 Takealot 生成的 MPTALX 占位码，新品不能复用' : null,
                      children: jsx(Input, { value: row.barcode, onChange: e => patchActive({ barcode: e.target.value }) })
                    }),
                    jsx(LField, { label: '你的内部 SKU（可选）', children: jsx(Input, { value: row.sku, onChange: e => patchActive({ sku: e.target.value }) }) })
                  ]
                }),
                jsxs('div', {
                  className: 'grid gap-3 lg:grid-cols-3',
                  children: [
                    jsx(LField, {
                      label: '产品类型 Product Type',
                      children: jsx('select', {
                        value: row.productType,
                        onChange: e => patchActive({ productType: e.target.value }),
                        className: 'rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.8125rem]',
                        children: PRODUCT_TYPES.map(t => jsx('option', { key: t, value: t, children: t }))
                      })
                    }),
                    jsx(LField, {
                      label: '变体父 SKU',
                      hint: variantExportPlan(row).hasVariants
                        ? '有变体时自动取你的内部 SKU（留空用标题）：子行都指它'
                        : '选了变体主题后自动生成（父行 Variant Parent / 子行 Variant Child）',
                      children: jsx(Input, {
                        value: variantExportPlan(row).hasVariants ? String(row.sku || row.title || '') : '',
                        disabled: true,
                        placeholder: '自动'
                      })
                    }),
                    jsx(LField, { label: '视频链接（仅 YouTube）', children: jsx(Input, { value: row.videoUrl, onChange: e => patchActive({ videoUrl: e.target.value }) }) })
                  ]
                }),
                jsxs('div', {
                  className: 'grid gap-3 lg:grid-cols-4',
                  children: [
                    jsx(LField, {
                      label: '保修类型',
                      children: jsx('select', {
                        value: row.warrantyType,
                        onChange: e => patchActive({ warrantyType: e.target.value }),
                        className: 'rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.8125rem]',
                        children: WARRANTY_TYPES.map(t => jsx('option', { key: t, value: t, children: t }))
                      })
                    }),
                    jsx(LField, { label: '保修月数（6–180）', children: jsx(Input, { value: String(row.warrantyPeriod), onChange: e => patchActive({ warrantyPeriod: e.target.value }) }) }),
                    jsx(LField, { label: '售价 ZAR', children: jsx(Input, { value: String(row.price ?? ''), onChange: e => patchActive({ price: e.target.value }) }) }),
                    jsx(LField, { label: '库存数量', children: jsx(Input, { value: String(row.qty ?? ''), onChange: e => patchActive({ qty: e.target.value }) }) })
                  ]
                }),
                jsxs('div', {
                  className: 'grid gap-3 lg:grid-cols-2',
                  children: [
                    jsx(LField, {
                      label: `图片 URL（每行一个，封面主图必填，最多 ${LIMITS.images} 张）`,
                      counter: `${rowImages(row).length} 张`,
                      bad: rowImages(row).length === 0,
                      hint: '公网 http(s) URL，600–5000px；Takealot CDN 的 {size} 会自动归一到 zoom',
                      children: jsx(Textarea, { rows: 4, value: row.imagesText, onChange: e => patchActive({ imagesText: e.target.value }) })
                    }),
                    jsx(LField, {
                      label: "包装清单 What's in the Box（每行一项）",
                      children: jsx(Textarea, { rows: 5, className: 'min-h-[7rem]', value: row.whatsInTheBox, placeholder: '1 x Main Product\n1 x Charging Cable', onChange: e => patchActive({ whatsInTheBox: e.target.value }) })
                    }),
                    jsx(VariantEditor, {
                      meta: variantMeta.data,
                      model: variantModel(row),
                      onChange: next => patchActive({ variants: next })
                    })
                  ]
                }),
                jsxs('div', {
                  className: 'space-y-1',
                  children: [
                    jsx('div', {
                      className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                      children: `类目属性（必填按末级类目给${activeCat ? ' · ' + activeCat : ''}${row.taxonomyId ? ' · #' + row.taxonomyId : ''}）`
                    }),
                    !activeCat
                      ? jsx('div', { className: 'text-[0.75rem] text-(--ui-text-quaternary)', children: '先在上方选择末级类目，这里会列出该类的必填属性（选填默认折叠）。' })
                      : jsx(Async, {
                          query: attrs,
                          children: a =>
                            jsxs('div', {
                              className: 'space-y-2',
                              children: [
                                jsx(AttrCoverageNote, { a }),
                                (a.required || []).length
                                  ? jsx(AttrGrid, { items: a.required, row, patchActive })
                                  : jsx('div', {
                                      className: 'text-[0.75rem] text-(--ui-text-quaternary)',
                                      children: a.covered === false
                                        ? '属性模板未收录：这里不显示属性（不会拿别的类目的属性顶替）。'
                                        : a.needsTaxonomy
                                          ? '请点上方类目结果里的末级类目（要 taxonomyId 才能列出必填）。'
                                          : '该类目没有额外必填属性。'
                                    }),
                                (a.optional || []).length || (a.recommended || []).length
                                  ? jsxs('div', {
                                      className: 'space-y-2',
                                      children: [
                                        jsx(Button, {
                                          size: 'xs',
                                          variant: 'ghost',
                                          onClick: () => setShowOptional(v => !v),
                                          children: showOptional
                                            ? `收起推荐与选填（推荐 ${(a.recommended || []).length} · 选填 ${(a.optional || []).length}）`
                                            : `显示推荐与选填（推荐 ${(a.recommended || []).length} · 选填 ${(a.optional || []).length}）`
                                        }),
                                        showOptional && (a.recommended || []).length
                                          ? jsxs('div', {
                                              className: 'space-y-1',
                                              children: [
                                                jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '官方建议填（recommendeds）' }),
                                                jsx(AttrGrid, { items: a.recommended, row, patchActive })
                                              ]
                                            })
                                          : null,
                                        showOptional ? jsx(AttrGrid, { items: a.optional, row, patchActive }) : null
                                      ]
                                    })
                                  : null
                              ]
                            })
                        })
                  ]
                }),
                jsxs('div', {
                  className: 'flex flex-wrap items-center gap-2',
                  children: [
                    jsx(Pill, { tone: localIssues(row).length ? 'bad' : 'good', children: localIssues(row).length ? `本地检查：${localIssues(row).length} 项待修` : '本地检查通过' }),
                    rowWarnings(row).map((w, i) => jsx(Pill, { key: `w${i}`, tone: 'warn', children: w }, `w${i}`)),
                    jsx(Button, {
                      size: 'sm',
                      disabled: saveM.isPending,
                      onClick: () =>
                        saveM.mutate(payloadRow(row), {
                          onSuccess: () => {
                            refresh()
                            host.notify({ kind: 'info', message: '草稿已保存' })
                          },
                          onError: fail
                        }),
                      children: '存为草稿'
                    }),
                    jsx(Button, { size: 'sm', variant: 'outline', disabled: !rows.length, onClick: () => exportPayload({ rowIndexes: [active] }), children: '导出本行' }),
                    rows.length > 1
                      ? jsx(Button, {
                          size: 'xs',
                          variant: 'ghost',
                          onClick: () => {
                            setRows(prev => prev.filter((_, i) => i !== active))
                            setActive(0)
                          },
                          children: '删除本行'
                        })
                      : null
                  ]
                }),
                localIssues(row).length
                  ? jsx('ul', { className: 'ml-4 list-disc space-y-0.5 text-[0.75rem] text-red-400', children: localIssues(row).map((x, i) => jsx('li', { children: x }, i)) })
                  : null
              ]
            })
          })
        ]
      }),
      checked
        ? jsx(Card, {
            title: '服务端校验（官方规则）',
            extra: jsx(Pill, { tone: checked.blockedCount ? 'bad' : 'good', children: `就绪 ${checked.readyCount} · 待修 ${checked.blockedCount}` }),
            children: jsx(Table, {
              head: [jsx(Th, { key: 'i', children: '行' }), jsx(Th, { key: 't', children: '标题' }), jsx(Th, { key: 's', children: '状态' }), jsx(Th, { key: 'd', children: '问题' })],
              children: (checked.rows || []).map((r, i) =>
                jsxs(
                  'tr',
                  {
                    children: [
                      jsx(Td, { children: `#${r.index + 1}` }),
                      jsx(Td, { className: 'max-w-[16rem] truncate', children: (rows[r.index] || {}).title || '—' }),
                      jsx(Td, { children: jsx(Pill, { tone: r.ok ? 'good' : 'bad', children: r.ok ? '可导出' : '待修' }) }),
                      jsx(Td, {
                        className: 'text-[0.75rem]',
                        children: ((r.errors || []).length ? r.errors : (r.warnings || [])).join('；') || '—'
                      })
                    ]
                  },
                  i
                )
              )
            })
          })
        : null,
      jsx(Card, {
        title: '已存草稿 · 批量上架',
        extra: jsxs('div', {
          className: 'flex flex-wrap items-center gap-2',
          children: [
            jsx(Pill, { tone: 'mute', children: `已选 ${pickedDrafts.length}` }),
            jsx(Button, {
              size: 'xs',
              variant: 'outline',
              disabled: !pickedDrafts.length,
              onClick: () => exportPayload({ ids: pickedDrafts }),
              children: `批量导出装载表${pickedDrafts.length ? `（${pickedDrafts.length}）` : ''}`
            }),
            jsx(Button, {
              size: 'xs',
              variant: 'outline',
              disabled: dupeBusy,
              onClick: () => runDuplicates(pickedDrafts.length ? pickedDrafts : []),
              children: dupeBusy ? '检测中…' : `重复检测${pickedDrafts.length ? '（选中）' : '（全部）'}`
            }),
            jsx(Button, {
              size: 'xs',
              variant: 'ghost',
              disabled: !pickedDrafts.length,
              onClick: () => deleteDrafts(pickedDrafts),
              children: '批量删除'
            }),
            jsx(Button, { size: 'xs', variant: 'ghost', onClick: refresh, children: '刷新' })
          ]
        }),
        children: jsx(Async, {
          query: drafts,
          children: d =>
            (d.items || []).length
              ? jsxs('div', {
                  className: 'space-y-2',
                  children: [
                    d.summary
                      ? jsxs('div', {
                          className: 'flex flex-wrap items-center gap-2 text-[0.6875rem] text-(--ui-text-quaternary)',
                          children: [
                            jsx(Pill, { tone: (d.summary.blocked || 0) ? 'warn' : 'good', children: `${d.summary.ready}/${d.summary.drafts} 就绪` }),
                            jsx('span', { children: '就绪度与「校验全部」同源（含 portal 阻断项）；条码/TSIN 已在售会命中重复检测。' })
                          ]
                        })
                      : null,
                    jsx(Table, {
                  head: [
                    jsx(Th, {
                      key: 'pick',
                      children: jsx('input', {
                        type: 'checkbox',
                        checked: Boolean((d.items || []).length) && pickedDrafts.length === (d.items || []).length,
                        onChange: () => setPickedDrafts(pickedDrafts.length === (d.items || []).length ? [] : (d.items || []).map(x => x.id))
                      })
                    }),
                    jsx(Th, { key: 't', children: '标题' }),
                    jsx(Th, { key: 'c', children: '类目 / 条码' }),
                    jsx(Th, { key: 'p', right: true, children: '售价' }),
                    jsx(Th, { key: 'r', children: '就绪度' }),
                    jsx(Th, { key: 's', children: '合规' }),
                    jsx(Th, { key: 'a', children: '' })
                  ],
                  children: (d.items || []).map(x =>
                    jsxs(
                      'tr',
                      {
                        key: x.id,
                        children: [
                          jsx(Td, { children: jsx('input', { type: 'checkbox', checked: pickedDrafts.includes(x.id), onChange: () => toggleDraft(x.id) }) }),
                          jsx(Td, { className: 'max-w-[20rem]', children: jsxs('div', { className: 'truncate', title: x.title, children: [
                            x.title,
                            jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `${x.brand || '—'} · ${stamp(x.updatedAt)}` }),
                            // 新建草稿箱的来源：从跟卖池转来的要一眼可辨（区别于从零新建）
                            jsx('div', { className: 'mt-0.5', children: jsx(Pill, {
                              tone: String(x.source || '').indexOf('collection:') === 0 ? 'warn' : 'mute',
                              children: String(x.source || '').indexOf('collection:') === 0
                                ? `从采集箱转入 ${String(x.source).split(':')[1]}`
                                : '手工新建'
                            }) })
                          ] }) }),
                          jsx(Td, { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: jsxs('div', { children: [x.categoryPath || x.category || '—', jsx('div', { className: 'font-mono text-[0.6875rem]', children: x.barcode || x.tsin || '—' })] }) }),
                          jsx(Td, { right: true, children: ZAR(x.price) }),
                          jsx(Td, {
                            children: jsxs('div', {
                              className: 'space-y-0.5',
                              children: [
                                jsx(Pill, { tone: ((x.readiness || {}).ok ? 'good' : 'warn'), children: (x.readiness || {}).label || '—' }),
                                ((x.readiness || {}).missing || []).length
                                  ? jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: '缺：' + (x.readiness.missing || []).join('、') })
                                  : null
                              ]
                            })
                          }),
                          jsx(Td, { children: (x.compliance || {}).hits && (x.compliance || {}).hits.length ? jsx(Pill, { tone: 'bad', children: `风险 ${x.compliance.hits.length}` }) : jsx(Pill, { tone: 'good', children: '通过' }) }),
                          jsx(Td, {
                            children: jsxs('div', {
                              className: 'flex gap-1',
                              children: [
                                jsx(Button, {
                                  size: 'xs',
                                  variant: 'ghost',
                                  onClick: () => {
                                    setRows(prev => {
                                      const next = prev.slice()
                                      next[active] = { ...blankRow(), ...x, imagesText: (x.images || []).join('\n') }
                                      return next
                                    })
                                    host.notify({ kind: 'info', message: '已载入到当前行' })
                                  },
                                  children: '载入'
                                }),
                                jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => exportPayload({ ids: [x.id], filename: `takealot-draft-${x.id}.xlsx` }), children: '导出' }),
                                jsx(Button, {
                                  size: 'xs',
                                  variant: 'ghost',
                                  onClick: () => rest(`/listings/drafts/${x.id}`, { method: 'DELETE' }).then(() => { refresh(); host.notify({ kind: 'info', message: '已删除草稿' }) }, fail),
                                  children: '删除'
                                })
                              ]
                            })
                          })
                        ]
                      },
                      x.id
                    )
                  )
                    }),
                    batchMsg ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: batchMsg }) : null,
                    dupes
                      ? jsx(Card, {
                          title: `重复 / 冲突检测（检查 ${NUM(dupes.checked)} 个草稿 · 命中 ${NUM(dupes.total)}）`,
                          children: jsxs('div', {
                            className: 'space-y-2',
                            children: [
                              jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: dupes.hint || '' }),
                              (dupes.againstOffers || []).length
                                ? jsxs('div', {
                                    className: 'space-y-1',
                                    children: [
                                      jsx('div', { className: 'text-[0.75rem] font-medium', children: '与本店在售 offer 冲突（不要新建，应改价/跟卖）' }),
                                      (dupes.againstOffers || []).map((c, i) => jsx('div', { key: i, className: 'text-[0.6875rem] text-amber-400', children: `${c.draftId || '—'} · ${c.field} ${c.value} → 已有 SKU ${c.offerSku}：${c.advice || ''}` }))
                                    ]
                                  })
                                : null,
                              (dupes.withinDrafts || []).length
                                ? jsxs('div', {
                                    className: 'space-y-1',
                                    children: [
                                      jsx('div', { className: 'text-[0.75rem] font-medium', children: '草稿之间重复' }),
                                      (dupes.withinDrafts || []).map((c, i) => jsx('div', { key: i, className: 'text-[0.6875rem] text-(--ui-text-tertiary)', children: `${c.key} ${c.value} 出现 ${c.count} 次：${(c.drafts || []).map(d => d.id).join('、')}` }))
                                    ]
                                  })
                                : null,
                              (dupes.againstCollection || []).length
                                ? jsxs('div', {
                                    className: 'space-y-1',
                                    children: [
                                      jsx('div', { className: 'text-[0.75rem] font-medium', children: '与采集箱重复' }),
                                      (dupes.againstCollection || []).map((c, i) => jsx('div', { key: i, className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `${c.draftId} · TSIN ${c.tsin} ← 采集箱 ${c.collectionId}：${c.note || ''}` }))
                                    ]
                                  })
                                : null,
                              !dupes.total ? jsx('div', { className: 'text-[0.75rem] text-emerald-400', children: '没有发现重复或冲突' }) : null
                            ]
                          })
                        })
                      : null
                  ]
                })
              : jsx(EmptyState, { title: '还没有草稿', description: '用上方表单或 AI 生成文案后「存为草稿」' })
        })
      })
    ]
  })
}

// 属性控件：按官方 fieldType 给控件；单位/说明/选项都来自数据，不猜。
function AttrGrid({ items, row, patchActive }) {
  if (!items || !items.length) return null
  return jsx('div', {
    className: 'grid gap-2 sm:grid-cols-2 lg:grid-cols-3',
    children: items.map(f => {
      const key = f.displayName || f.fieldId
      const value = (row.attributes || {})[key] || ''
      const opts = f.options || []
      const number = f.fieldType === 'Float' || f.fieldType === 'Integer'
      const boolean = f.fieldType === 'Boolean'
      const choose = (opts.length && (f.fieldType === 'Dropdown' || f.fieldType === 'MultiDropdown')) || boolean
      const options = boolean && !opts.length ? [{ label: 'Yes', code: 'Yes' }, { label: 'No', code: 'No' }] : opts
      const set = v => patchActive({ attributes: { ...(row.attributes || {}), [key]: v } })
      return jsx(LField, {
        key: f.fieldId || key,
        label: f.required ? `${key} *` : f.recommended ? `${key} · 推荐` : key,
        hint: [f.hint || f.description || '', f.unit ? `单位 ${f.unit}` : ''].filter(Boolean).join(' · '),
        children: choose
          ? jsx('select', {
              className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-2 py-1 text-[0.75rem]',
              value,
              onChange: e => set(e.target.value),
              children: [jsx('option', { value: '', children: '—' }, 'empty')].concat(
                options.map(o => jsx('option', { key: o.code || o.label, value: o.label, children: o.label }))
              )
            })
          : jsx(Input, {
              size: 'sm',
              value,
              placeholder: number ? (f.unit ? `数字（${f.unit}）` : '数字') : '',
              onChange: e => set(e.target.value)
            })
      })
    })
  })
}

// 覆盖情况：未收录 / 缺 taxonomy / 有必填字段无定义 —— 都如实说，不展示别的类目的属性。
function AttrCoverageNote({ a }) {
  if (!a) return null
  const out = []
  if (a.needsTaxonomy) out.push(jsx(Pill, { key: 'n', tone: 'warn', children: '请选末级类目' }))
  if (a.covered === false) out.push(jsx(Pill, { key: 'u', tone: 'bad', children: '该类目属性未收录' }))
  if ((a.counts || {}).undefinedRequired) out.push(jsx(Pill, { key: 'd', tone: 'warn', children: `${a.counts.undefinedRequired} 个必填项官方未给定义` }))
  const minImg = a.minimumImages || (a.imageRequired || []).length
  if (minImg) out.push(jsx(Pill, { key: 'i', tone: 'mute', children: `该类目要求至少 ${minImg} 张图片` }))
  if (a.requiresColour) out.push(jsx(Pill, { key: 'c', tone: 'mute', children: '官方要求颜色（可做颜色变体）' }))
  if (!out.length && a.covered) out.push(jsx(Pill, { key: 'ok', tone: 'good', children: `必填 ${(a.counts || {}).required || 0} · 推荐 ${(a.counts || {}).recommended || 0} · 选填 ${(a.counts || {}).optional || 0}` }))
  return jsxs('div', {
    className: 'space-y-1',
    children: [
      jsx('div', { className: 'flex flex-wrap items-center gap-1', children: out }),
      a.note ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: a.note }) : null,
      a.basis ? jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: a.basis }) : null
    ]
  })
}

function CategoryAttrs() {
  const [kw, setKw] = useState('')
  const [cat, setCat] = useState('')
  const cats = useApi(`/meta/categories?q=${encodeURIComponent(kw)}&limit=12&zh=1`, `cats:${kw}`)
  useZhPrewarm('cats', cats.data && cats.data.items)
  // 选品侧：类目按钮带上 taxonomyId（用 || 分隔存），必填清单才拿得到
  const catBits = String(cat || '').split('||')
  const attrs = useApi(
    `/meta/attributes?category=${encodeURIComponent(catBits[0] || '')}&taxonomyId=${encodeURIComponent(catBits[1] || '')}`,
    `attrs:${cat}`,
    { enabled: !!cat }
  )
  return jsxs('div', {
    className: 'space-y-2',
    children: [
      jsxs('div', {
        className: 'flex items-center gap-2',
        children: [
          jsx('div', {
            className: 'flex-1',
            children: jsx(Input, { size: 'sm', value: kw, placeholder: '搜索 Takealot 类目（中文或英文）', onChange: e => setKw(e.target.value) })
          }),
          zhHint(cats.data)
            ? jsx('span', {
                className: 'shrink-0 text-[0.6875rem] text-(--ui-text-quaternary)',
                children: zhHint(cats.data)
              })
            : null
        ]
      }),
      jsx(Async, {
        query: cats,
        children: d =>
          (d.items || []).length
            ? jsx('div', {
                className: 'flex flex-wrap gap-1',
                children: (d.items || []).map(c =>
                  jsx(
                    'button',
                    {
                      key: c.path,
                      type: 'button',
                      onClick: () => setCat(`${c.path}||${c.nodeId || c.id || ''}`),
                      className: cn(
                        'rounded border px-1.5 py-0.5 text-left text-[0.6875rem] hover:bg-(--chrome-action-hover)',
                        cat === c.path ? 'border-(--ui-accent) text-(--ui-accent)' : 'border-(--ui-stroke-secondary) text-(--ui-text-tertiary)'
                      ),
                      children: catLabel(c)
                    },
                    c.path
                  )
                )
              })
            : jsx('div', {
                className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                children: kw.trim() ? '无匹配类目，试试 Earphones / Kitchen / Camping / Phone Case' : '输入类目关键词开始搜索'
              })
      }),
      cat
        ? jsx(Async, {
            query: attrs,
            children: d =>
              jsxs('div', {
                className: 'text-[0.75rem]',
                children: [
                  jsx('div', {
                    className: 'mb-1 text-(--ui-text-quaternary)',
                    children: d.covered === false
                      ? `${d.loadsheetName || d.category || ''} · 属性模板未收录（不拿别的类目顶替）`
                      : `${d.taxonomyName || d.category || ''} · 必填 ${(d.counts || {}).required || 0} / 选填 ${(d.counts || {}).optional || 0}`
                  }),
                  d.note ? jsx('div', { className: 'mb-1 text-[0.6875rem] text-(--ui-text-quaternary)', children: d.note }) : null,
                  jsx('div', {
                    className: 'max-h-56 space-y-1 overflow-auto',
                    children: ((d.required || []).concat(d.optional || []).length ? (d.required || []).concat(d.optional || []) : (d.fields || [])).map(f =>
                      jsxs(
                        'div',
                        {
                          className: 'flex items-center justify-between gap-2 border-b border-(--ui-stroke-secondary) py-1',
                          children: [
                            jsx('span', { children: f.displayName || f.name || f.fieldId || '' }),
                            jsxs('div', {
                              className: 'flex items-center gap-1',
                              children: [
                                jsx(Pill, { tone: 'mute', children: f.fieldType || f.type || '—' }),
                                f.required ? jsx(Pill, { tone: 'warn', children: '必填' }) : null
                              ]
                            })
                          ]
                        },
                        f.name
                      )
                    )
                  })
                ]
              })
          })
        : null
    ]
  })
}

// ── 跟价策略引擎（按店） ─────────────────────────────────────────────────────
// 与上方「一键跟价」（本地演示数据 + 单条规则）不同：这里跑的是真店实时 offer +
// 公网竞价证据，判定基准是**最低竞品价**（BuyBox 价可能就是我们自己），
// 独家/已更低/无参考价都会明确写"不用调"，并附保护底价来源。
function PricingStrategy({ storeId }) {
  const strategyQ = useApi(`/buybox/strategy?storeId=${encodeURIComponent(storeId)}`, `strategy:${storeId}`)
  const [form, setForm] = useState(null)
  const [busy, setBusy] = useState(false)
  const [res, setRes] = useState(null)
  const [msg, setMsg] = useState('')
  const stored = (strategyQ.data || {}).strategy || {}
  const s = form || stored
  const set = (k, v) => setForm(f => ({ ...(f || stored), [k]: v }))
  const dirty = Boolean(form)

  const save = async () => {
    setBusy(true)
    setMsg('')
    try {
      const r = await rest('/buybox/strategy', { method: 'POST', body: { ...s, storeId } })
      setMsg(r && r.ok ? r.message || '已保存' : `保存失败：${(r && r.error) || '未知'}`)
      setForm(null)
      strategyQ.refetch && strategyQ.refetch()
      host.notify({ kind: r && r.ok ? 'info' : 'error', message: (r && (r.message || r.error)) || '保存失败' })
    } catch (e) {
      setMsg(`保存失败：${msg(e)}`)
    } finally {
      setBusy(false)
    }
  }

  const run = async dryRun => {
    if (!storeId) {
      host.notify({ kind: 'warn', message: '汇总视图不能跟价：请先在顶栏选定一家店' })
      return
    }
    setBusy(true)
    setMsg('')
    try {
      const r = await rest('/buybox/run', { method: 'POST', body: { storeId, dryRun: !!dryRun } })
      setRes(r)
      if (!r || r.ok === false) {
        setMsg((r && r.error) || '运行失败')
      } else {
        const sm = r.summary || {}
        setMsg(dryRun
          ? `试算：${sm.candidates} 个候选中 ${sm.ready} 个可调、${sm.blocked} 个被拦（未写入）`
          : `执行：已写入 ${sm.written} 个，逐行已回读`
        )
      }
    } catch (e) {
      setMsg(`运行失败：${msg(e)}`)
    } finally {
      setBusy(false)
    }
  }

  const rows = (res && res.rows) || []
  const ready = rows.filter(r => r.status === 'ready')
  const modeLabel = { undercut_percent: '低于竞价 X%', undercut_fixed: '低于竞价固定 ZAR', match: '与竞价持平' }

  return jsxs('div', {
    className: 'space-y-3',
    children: [
      jsx(Card, {
        title: `跟价策略（按店保存 · ${stored.storeName || storeId || '未选定店铺'}）`,
        extra: jsxs('div', {
          className: 'flex flex-wrap items-center gap-2',
          children: [
            jsx(Pill, { tone: s.enabled ? 'good' : 'mute', children: s.enabled ? '已启用' : '未启用' }),
            jsx(Button, { size: 'xs', variant: 'outline', disabled: busy || !storeId, onClick: save, children: dirty ? '保存策略 *' : '保存策略' }),
            jsx(Button, { size: 'xs', variant: 'outline', disabled: busy || !storeId, onClick: () => run(true), children: '按策略试算' }),
            jsx(Button, { size: 'xs', disabled: busy || !storeId || !ready.length, onClick: () => run(false), children: `执行可调的行${ready.length ? `（${ready.length}）` : ''}` })
          ]
        }),
        children: jsxs('div', {
          className: 'space-y-3',
          children: [
            !storeId
              ? jsx('div', { className: 'rounded border border-amber-400/60 bg-amber-400/10 p-2 text-[0.75rem]', children: '当前是汇总视图：跟价必须选定一家店（写入不能落到不确定的店）。请用顶栏/左栏切换。' })
              : null,
            jsxs('div', {
              className: 'flex flex-wrap items-end gap-3',
              children: [
                jsxs('label', { className: 'w-40 space-y-1', children: [
                  jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '模式' }),
                  jsx('select', {
                    value: String(s.mode || 'undercut_percent'),
                    onChange: e => set('mode', e.target.value),
                    className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]',
                    children: Object.keys(modeLabel).map(k => jsx('option', { key: k, value: k, children: modeLabel[k] }))
                  })
                ] }),
                jsxs('label', { className: 'w-28 space-y-1', children: [
                  jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: s.mode === 'undercut_fixed' ? '差额 ZAR' : '幅度 %' }),
                  jsx('input', { value: String(s.value ?? ''), onChange: e => set('value', e.target.value), className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]' })
                ] }),
                jsxs('label', { className: 'w-32 space-y-1', children: [
                  jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '保护底价 ZAR' }),
                  jsx('input', { value: String(s.floorPrice ?? ''), placeholder: '留空则用成本推算', onChange: e => set('floorPrice', e.target.value), className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]' })
                ] }),
                jsxs('label', { className: 'w-32 space-y-1', children: [
                  jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '最低净利率 %' }),
                  jsx('input', { value: String(s.floorMarginPercent ?? ''), onChange: e => set('floorMarginPercent', e.target.value), className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]' })
                ] }),
                jsxs('label', { className: 'w-32 space-y-1', children: [
                  jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '单次最大幅度 %' }),
                  jsx('input', { value: String(s.maxChangePercent ?? ''), onChange: e => set('maxChangePercent', e.target.value), className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]' })
                ] }),
                jsxs('label', { className: 'w-28 space-y-1', children: [
                  jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '每轮最多改' }),
                  jsx('input', { value: String(s.maxChangesPerRun ?? ''), onChange: e => set('maxChangesPerRun', e.target.value), className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]' })
                ] }),
                jsxs('label', { className: 'w-28 space-y-1', children: [
                  jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '冷却（分钟）' }),
                  jsx('input', { value: String(s.minIntervalMinutes ?? ''), onChange: e => set('minIntervalMinutes', e.target.value), className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]' })
                ] }),
                jsxs('label', { className: 'w-28 space-y-1', children: [
                  jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '每轮取证数' }),
                  jsx('input', { value: String(s.maxCandidatesPerRun ?? ''), onChange: e => set('maxCandidatesPerRun', e.target.value), className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]' })
                ] }),
                jsxs('label', { className: 'flex items-center gap-2 pt-4 text-[0.75rem]', children: [
                  jsx('input', { type: 'checkbox', checked: Boolean(s.enabled), onChange: e => set('enabled', e.target.checked) }),
                  jsx('span', { children: '启用（未启用时只能试算，不能写入）' })
                ] }),
                jsxs('label', { className: 'flex items-center gap-2 pt-4 text-[0.75rem]', children: [
                  jsx('input', { type: 'checkbox', checked: s.respectRRP !== false, onChange: e => set('respectRRP', e.target.checked) }),
                  jsx('span', { children: '不超过 RRP' })
                ] }),
                // 优势抬价：客户只碰这一个开关。步进/上界/冷却/每日上限/陈旧阈值全部写死在引擎里，
                // 不暴露成可配置项 —— 参数越多，非技术操作员越可能把自己设进坑里。
                jsxs('label', { className: 'flex items-center gap-2 pt-4 text-[0.75rem]', children: [
                  jsx('input', { type: 'checkbox', checked: Boolean(s.raiseEnabled), onChange: e => set('raiseEnabled', e.target.checked) }),
                  jsx('span', { children: '持有 BuyBox 时自动抬价（涨利润）' })
                ] })
              ]
            }),
            jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '判定基准是「最低竞品价」（BuyBox 价可能来自我们自己，拿它当基准会砍自己）。独家在售 / 已低于竞品 / 无竞品参考价 / 触底价 / 冷却中 → 一律拦下并在下表写明原因。' }),
            s.raiseEnabled
              ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `抬价规则（不可改，避免误设）：仅当确实持有 BuyBox 且比最低竞品低 R2 以上时抬；每轮只抬一步 +3%；上界 = min(最低竞品 − R0.01, 上限价)；同一 SKU 6 小时才抬一次，每店每日最多 20 次；竞品数据超过 3 天没更新则不抬（先补数据）。无竞品参考价（独家在售）不抬。` })
              : null,
            msg ? jsx('div', { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: msg }) : null
          ]
        })
      }),
      rows.length
        ? jsx(Card, {
            title: `本轮结果（${rows.length} 行 · ${ready.length} 可调 · ${rows.length - ready.length} 被拦）`,
            children: jsx(Table, {
              head: [
                Th('SKU / 商品'),
                Th('现价', { right: true }),
                Th('最低竞品', { right: true }),
                Th('BuyBox 价', { right: true }),
                Th('建议价', { right: true }),
                Th('底价来源'),
                Th('结论')
              ],
              children: rows.map(r =>
                jsxs('tr', {
                  key: r.sku,
                  children: [
                    jsxs(Td, { children: [
                      jsx('div', { className: 'truncate text-[0.8125rem]', title: r.title, children: r.title || r.sku }),
                      jsx('div', { className: 'font-mono text-[0.6875rem] text-(--ui-text-quaternary)', children: r.sku })
                    ] }),
                    jsx(Td, { right: true, mono: true, children: ZAR(r.current) }),
                    jsx(Td, { right: true, mono: true, children: r.lowest ? ZAR(r.lowest) : '—' }),
                    jsx(Td, { right: true, mono: true, children: r.buybox ? ZAR(r.buybox) : '—' }),
                    jsx(Td, { right: true, mono: true, children: r.proposed ? ZAR(r.proposed) : '—' }),
                    jsx(Td, { children: jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: r.floorSource || (r.floor ? ZAR(r.floor) : '—') }) }),
                    jsx(Td, { children: jsxs('div', { className: 'space-y-0.5', children: [
                      jsx('div', { className: cn('text-[0.75rem]', r.status === 'ready' ? 'text-emerald-400' : 'text-(--ui-text-tertiary)'), children: r.status === 'ready' ? (r.action === 'raise' ? '抬价' : '调价') : '不动' }),
                      jsx('div', { className: 'max-w-md text-[0.6875rem] text-(--ui-text-quaternary)', children: r.reason || '—' }),
                      r.apiStatus ? jsx('div', { className: 'font-mono text-[0.625rem] text-(--ui-text-quaternary)', children: `API ${r.apiStatus}${r.reread != null ? ` · 回读 ${ZAR(r.reread)}` : ''}${r.apiError ? ` · ${r.apiError}` : ''}` }) : null
                    ] }) })
                  ]
                })
              )
            })
          })
        : null
    ]
  })
}

function Buybox() {
  const storeId = useValue($storeId)
  const [dryRun, setDryRun] = useState(true)
  const [edits, setEdits] = useState({})
  // 候选一多就找不到那一条 = 操作员眼里的「不能对单个 listing 跟价」，所以搜索/筛选/排序是主入口，
  // 不是可选装饰：SKU / TSIN / PLID / 条码 / 标题 都能搜（空格分词 = AND）。
  const [q, setQ] = useState('')
  const [only, setOnly] = useState('all')
  const [sort, setSort] = useState('gap')
  const [sel, setSel] = useState([])
  const qs = `storeId=${encodeURIComponent(storeId)}&q=${encodeURIComponent(q)}&only=${encodeURIComponent(only)}&sort=${encodeURIComponent(sort)}&limit=200`
  const q_ = useApi(`/buybox?${qs}`, `buybox:${storeId}:${q}:${only}:${sort}`)
  const logs = useApi(`/buybox/log?storeId=${encodeURIComponent(storeId)}`, `buyboxlog:${storeId}`)
  const apply = usePost('/buybox/apply')
  const rule = usePost('/buybox/rules')
  const enrich = usePost('/buybox/enrich')
  // 目录已经改成"先用快照 + 后台刷新"，所以这里必须给一个"现在就要最新"的同步通路：
  // 否则操作员点什么都只是重发读请求，静默拿到同一份旧数据。
  const catRefresh = usePost('/catalog/refresh')
  const [catBusy, setCatBusy] = useState(false)
  const refreshCatalog = () => {
    setCatBusy(true)
    catRefresh.mutate({ storeId }, {
      onSuccess: r => {
        refresh()
        host.notify({ kind: 'info', message: `目录已刷新：${NUM(r.count)} 条，用时 ${r.seconds}s` })
      },
      onError: fail,
      onSettled: () => setCatBusy(false)
    })
  }
  const [enrichLimit, setEnrichLimit] = useState(5)
  const [enrichInfo, setEnrichInfo] = useState(null)
  const fail = e => host.notify({ kind: 'error', message: msg(e) })
  const done = m => {
    refresh()
    host.notify({ kind: 'info', message: m })
  }
  const setEdit = (sku, field, v) => setEdits(p => ({ ...p, [sku]: { ...(p[sku] || {}), [field]: v } }))
  const targetOf = b => Number((edits[b.sku] || {}).targetPrice ?? b.targetPrice ?? 0)
  const edited = b => (edits[b.sku] || {}).targetPrice !== undefined
  const toggleSel = sku => setSel(p => (p.includes(sku) ? p.filter(x => x !== sku) : p.concat(sku)))
  // 手填的目标价随「skus」一起发给后端（后端把它当 manual 覆盖规则价，仍过底价熔断 + 偏差闸）。
  // 写回确认用「再点一次」而不是 window.confirm：Electron 沙箱渲染器里 confirm 不可靠。
  const [armed, setArmed] = useState('')
  const runApply = (skus, label, key) => {
    const targets = {}
    skus.forEach(sku => {
      const v = Number((edits[sku] || {}).targetPrice)
      if (!Number.isNaN(v) && v > 0) targets[sku] = v
    })
    if (!dryRun && armed !== key) {
      setArmed(key)
      host.notify({ kind: 'warn', message: `试算模式已关（会真写 Takealot）：再点一次「${label}」即执行，共 ${skus.length} 条${Object.keys(targets).length ? `，其中 ${Object.keys(targets).length} 条用你手填的价格` : ''}。` })
      return
    }
    setArmed('')
    apply.mutate(
      { skus, targets, dryRun, storeId },
      {
        onSuccess: r => {
          setSel([])
          const bl = (r.blocked || []).length
          const sk = (r.skipped || []).length
          done(`${dryRun ? '试算' : '执行'}完成：处理 ${r.count} 条${bl ? `，拦下 ${bl}` : ''}${sk ? `，跳过 ${sk}（无竞品数据）` : ''}`)
        },
        onError: fail
      }
    )
  }
  const armedHint = key => (!dryRun && armed === key ? ' ⚠ 再点一次即写入' : '')
  const facetLabel = k => ({ all: '全部', actionable: '可跟价', raise: '有抬价空间', lost: '已丢失 BuyBox', held: '持有', floor: '熔断保护', nodata: '没抓过（可补数据）', noCompetitor: '已抓·无竞品', auto: '自动跟价' }[k] || k)
  const facetTone = k => (k === 'lost' ? 'bad' : (k === 'actionable' || k === 'raise') ? 'good' : k === 'floor' ? 'warn' : 'mute')

  return jsxs('div', {
    className: 'space-y-3',
    children: [
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-2',
        children: [
          jsx('div', { className: 'min-w-[18rem] flex-1', children: jsx(Input, { value: q, placeholder: '搜 SKU / TSIN / PLID / 条码 / 标题（空格分词，如 "t-shirt navy"）', onChange: e => setQ(e.target.value) }) }),
          q ? jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => { setQ(''); setOnly('all') }, children: '清空' }) : null,
          jsx('div', { className: 'w-44', children: jsx('select', { value: sort, onChange: e => setSort(e.target.value), className: 'rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-0.5 text-[0.75rem]', children: [['gap', '按亏损额排序（大的在前）'], ['myPriceDesc', '我的价 高→低'], ['myPriceAsc', '我的价 低→高'], ['title', '按商品名']].map(([v, t]) => jsx('option', { key: v, value: v, children: t })) }) }),
          jsx(Button, { size: 'xs', variant: dryRun ? 'secondary' : 'outline', onClick: () => setDryRun(v => !v), children: dryRun ? '试算模式：开（不写回）' : '试算模式：关（写回 Takealot）' }),
          jsx(Button, { size: 'xs', variant: 'ghost', onClick: refresh, children: '刷新' })
        ]
      }),
      jsx(PricingStrategy, { storeId }),
      jsx(Async, {
        query: q_,
        children: d => {
          const items = d.candidates || []
          const facets = d.facets || {}
          return jsxs('div', {
            className: 'space-y-3',
            children: [
              jsxs('div', {
                className: 'flex flex-wrap items-center gap-1',
                children: [
                  jsx('span', { className: 'mr-1 text-[0.75rem] text-(--ui-text-quaternary)', children: `命中 ${NUM(d.filtered)} / 共 ${NUM(d.total)} 条` }),
                  d.catalog && (d.catalog.stale || d.catalog.fromSnapshot || d.catalog.mappedStale)
                    ? jsx(Pill, {
                        tone: d.catalog.stale ? 'warn' : 'mute',
                        children: [
                          d.catalog.fromSnapshot ? `目录来自快照（${NUM(d.catalog.count)} 条）` : `目录数据 ${NUM(Math.round(d.catalog.ageSeconds || 0))} 秒前`,
                          d.catalog.refreshing ? '后台拉最新中' : '',
                          d.catalog.mappedStale ? `映射后台重建中（当前是 ${NUM(Math.round(d.catalog.mappedAgeSeconds || 0))} 秒前的映射）` : '',
                          '页面不用等'
                        ].filter(Boolean).join(' · ')
                      })
                    : null,
                  jsx(Button, {
                    size: 'xs', variant: 'ghost', disabled: catBusy,
                    onClick: refreshCatalog,
                    children: catBusy ? '刷新目录中（约 30~55 秒）…' : '刷新目录'
                  }),
                  Object.keys(facets).map(k => jsx(Pill, {
                    key: k,
                    tone: only === k ? facetTone(k) : 'mute',
                    children: jsx('button', { type: 'button', onClick: () => setOnly(k), className: 'cursor-pointer', children: `${facetLabel(k)} ${NUM(facets[k])}` })
                  })),
                  d.filtered > items.length ? jsx(Pill, { tone: 'warn', children: `只显示前 ${NUM(items.length)} 条，用搜索或筛选缩小范围` }) : null,
                  jsxs('div', { className: 'ml-auto flex items-center gap-2', children: [
                    jsx('div', { className: 'w-32', children: jsx('select', { value: String(enrichLimit), onChange: e => setEnrichLimit(Number(e.target.value)), className: 'rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-0.5 text-[0.75rem]', children: [[5, '5 条（≈1.5 分钟）'], [10, '10 条（≈3 分钟）'], [20, '20 条（≈6 分钟）'], [40, '40 条（≈12 分钟）']].map(([n, t]) => jsx('option', { key: String(n), value: String(n), children: t })) }) }),
                    jsx(Button, {
                      size: 'xs',
                      variant: 'outline',
                      title: '对当前筛选结果抓一次公开页，补上「最低竞品价 / BuyBox 归属」（不改价，走出口代理，有预算上限）',
                      disabled: enrich.isPending || !items.length,
                      onClick: () => enrich.mutate(
                        { storeId, q, only, sort, limit: enrichLimit, budget: 25 },
                        {
                          onSuccess: r => {
                            setEnrichInfo(r)
                            refresh()
                            host.notify({ kind: r.crawled ? 'info' : 'warn', message: `补数据：成功 ${r.crawled} / 本轮 ${r.requested} 条${(r.failed || []).length ? `，失败 ${r.failed.length}` : ''}${r.remaining ? `，还剩 ${r.remaining} 条` : ''}（${r.elapsedSeconds}s）` })
                          },
                          onError: fail
                        }
                      ),
                      children: enrich.isPending ? '抓取中…' : '补竞品数据'
                    })
                  ] })
                ]
              }),
              enrichInfo
                ? jsx(Card, {
                    title: `上一轮补数据：成功 ${NUM(enrichInfo.crawled)} / ${NUM(enrichInfo.requested)} 条${enrichInfo.remaining ? ` · 还剩 ${NUM(enrichInfo.remaining)} 条` : ''}`,
                    children: jsxs('div', {
                      className: 'space-y-1 text-[0.75rem]',
                      children: [
                        jsx('div', { className: 'text-(--ui-text-quaternary)', children: `${enrichInfo.basis} 用时 ${enrichInfo.elapsedSeconds}s / 预算 ${enrichInfo.budgetSeconds}s。` }),
                        (enrichInfo.results || []).map(r => jsx('div', { className: 'flex flex-wrap items-center gap-2', children: [
                          jsx('span', { className: 'font-mono', children: r.sku }),
                          r.mode === 'live' ? jsx(Pill, { tone: 'good', children: '抓到' }) : jsx(Pill, { tone: 'warn', children: r.mode || '无数据' }),
                          jsx('span', { children: `竞品 ${r.competitorPrice === null || r.competitorPrice === undefined ? '—' : ZAR(r.competitorPrice)} · 判定 ${r.action || '—'} · 目标价 ${r.targetPrice === null || r.targetPrice === undefined ? '—' : ZAR(r.targetPrice)}` }),
                          r.note ? jsx('span', { className: 'text-(--ui-text-quaternary)', children: r.note }) : null
                        ] })),
                        (enrichInfo.failed || []).map(f => jsx('div', { className: 'text-amber-400', children: `${f.sku} · ${f.plid} 抓取失败：${f.reason}` })),
                        (enrichInfo.notRun || []).length ? jsx('div', { className: 'text-amber-400', children: `预算用尽未抓：${(enrichInfo.notRun || []).map(n => n.sku).join('、')}` }) : null,
                        (enrichInfo.noPlid || []).length ? jsx('div', { className: 'text-amber-400', children: `无 PLID 无法抓：${(enrichInfo.noPlid || []).map(n => n.sku).join('、')}` }) : null,
                        jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => setEnrichInfo(null), children: '收起' })
                      ]
                    })
                  })
                : null,
              items.length
                ? jsxs('div', { className: 'flex flex-wrap items-center gap-2', children: [
                      jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => setSel(sel.length === items.length ? [] : items.map(b => b.sku)), children: sel.length === items.length && items.length ? '取消全选' : '全选当前' }),
                      jsx(Pill, { tone: 'mute', children: `已选 ${NUM(sel.length)}` }),
                      jsx(Button, { size: 'xs', variant: 'outline', disabled: !sel.length, onClick: () => runApply(sel, '对选中跟价', 'sel'), children: `对选中跟价${armedHint('sel')}` }),
                      jsx(Button, { size: 'xs', variant: 'ghost', disabled: !items.length, onClick: () => runApply(items.map(b => b.sku), '对当前筛选结果跟价', 'all'), children: `对当前筛选结果跟价${armedHint('all')}` })
                    ] })
                : null,
              jsx(Grid, {
                cols: 3,
                children: [
                  jsx(Metric, { label: 'BuyBox 持有', value: `${NUM(d.held)}/${NUM(d.total)}`, tone: 'good' }),
                  jsx(Metric, { label: '跟价规则', value: NUM((d.rules || []).length), sub: '底价 / 上限 / 自动开关' }),
                  jsx(Metric, { label: '最近调价记录', value: NUM(((logs.data || {}).logs || []).length), sub: 'PATCH /offers/by_sku/{sku}' })
                ]
              }),
              jsx(Card, {
                title: '跟价候选（规则：比最低竞品低 R1，触达底价即熔断）',
                children: jsx(Table, {
                  head: [
                    jsx(Th, { key: 'x', children: '' }),
                    jsx(Th, { key: 's', children: 'SKU / 商品' }),
                    jsx(Th, { key: 'm', right: true, children: '我的价' }),
                    jsx(Th, { key: 'c', right: true, children: '最低竞品' }),
                    jsx(Th, { key: 't', right: true, children: '目标价' }),
                    jsx(Th, { key: 'f', right: true, children: '底价' }),
                    jsx(Th, { key: 'h', children: '状态' }),
                    jsx(Th, { key: 'a', children: '操作' })
                  ],
                  children: (d.candidates || []).map(b =>
                    jsxs(
                      'tr',
                      {
                        children: [
                          jsx(Td, { children: jsx('input', { type: 'checkbox', checked: sel.includes(b.sku), onChange: () => toggleSel(b.sku) }) }),
                          jsx(Td, { children: jsxs('div', { children: [jsx('div', { className: 'max-w-[16rem] truncate', title: b.title, children: b.title }), jsx('div', { className: 'font-mono text-[0.6875rem] text-(--ui-text-quaternary)', children: `${b.sku} · ${b.tsin || '—'}${b.plid ? ` · PLID${b.plid}` : ''} · ${b.competitorSeller || '—'}` })] }) }),
                          jsx(Td, { right: true, children: ZAR(b.myPrice) }),
                          jsx(Td, { right: true, children: ZAR(b.competitorPrice) }),
                          jsx(Td, {
                            right: true,
                            children: jsx('input', {
                              value: (edits[b.sku] || {}).targetPrice !== undefined ? edits[b.sku].targetPrice : (b.targetPrice === null || b.targetPrice === undefined ? '' : String(b.targetPrice)),
                              placeholder: b.targetPrice === null || b.targetPrice === undefined ? '手填' : '',
                              onChange: e => setEdit(b.sku, 'targetPrice', e.target.value),
                              className: 'w-20 rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-0.5 text-right text-[0.75rem]' + (edited(b) ? ' border-(--ui-accent)' : '')
                            })
                          }),
                          jsx(Td, {
                            right: true,
                            children: jsx('input', {
                              value: (edits[b.sku] || {}).floorPrice !== undefined ? edits[b.sku].floorPrice : String(b.floorPrice),
                              onChange: e => setEdit(b.sku, 'floorPrice', e.target.value),
                              className: 'w-20 rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-0.5 text-right text-[0.75rem]'
                            })
                          }),
                          jsx(Td, {
                            children: jsxs('div', {
                              className: 'flex flex-wrap gap-1',
                              children: [
                                jsx(Pill, { tone: b.hasBuybox ? 'good' : 'bad', children: b.hasBuybox ? '持有' : '丢失' }),
                                b.action === 'floor_guard' ? jsx(Pill, { tone: 'warn', children: '熔断' }) : null,
                                b.action === 'raise'
                                  ? jsx(Pill, { tone: 'good', title: b.note, children: `可抬价 +R${(Number(b.targetPrice || 0) - Number(b.myPrice || 0)).toFixed(2)}（+${NUM(b.raiseStepPercent || 3)}%）` })
                                  : null,
                                b.autoReprice ? jsx(Pill, { tone: 'mute', children: '自动' }) : null
                              ]
                            })
                          }),
                          jsx(Td, {
                            children: jsxs('div', {
                              className: 'flex gap-1',
                              children: [
                                jsx(Button, {
                                  size: 'xs',
                                  variant: 'outline',
                                  onClick: () => rule.mutate({ sku: b.sku, floorPrice: Number((edits[b.sku] || {}).floorPrice ?? b.floorPrice), ceilingPrice: b.ceilingPrice, auto: true }, { onSuccess: () => done(`${b.sku} 规则已保存`), onError: fail }),
                                  children: '存规则'
                                }),
                                jsx(Button, {
                                  size: 'xs',
                                  variant: 'secondary',
                                  title: edited(b) ? '用手填的目标价改价（仍过底价熔断与偏差闸）' : '先在「目标价」列填一个数，这个按钮才会亮',
                                  disabled: !edited(b) || apply.isPending,
                                  onClick: () => runApply([b.sku], `按手填目标价跟价 ${b.sku}`, `sku:${b.sku}`),
                                  children: `按此价调价${armedHint(`sku:${b.sku}`)}`
                                }),
                                jsx(Button, {
                                  size: 'xs',
                                  variant: 'ghost',
                                  title: b.action === 'raise'
                                    ? `按规则抬价：一步最多 +${NUM(b.raiseStepPercent || 3)}%，上界 R${NUM(b.raiseUpper || 0)}（不越过最低竞品）`
                                    : '用规则算出的目标价（最低竞品 − R1）',
                                  disabled: apply.isPending,
                                  onClick: () => runApply([b.sku], `按规则目标价跟价 ${b.sku}`, `sku:${b.sku}`),
                                  children: `${b.action === 'raise' ? '按规则抬价' : '按规则调价'}${armedHint(`sku:${b.sku}`)}`
                                })
                              ]
                            })
                          })
                        ]
                      },
                      b.sku
                    )
                  )
                })
              }),
              jsxs('div', {
                className: 'grid gap-3 lg:grid-cols-2',
                children: [
                  jsx(Card, {
                    title: '调价日志',
                    children: jsx(Async, {
                      query: logs,
                      children: lg =>
                        (lg.logs || []).length
                          ? jsx('div', {
                              className: 'max-h-72 space-y-1.5 overflow-auto text-[0.75rem]',
                              children: (lg.logs || []).map((l, i) =>
                                jsxs(
                                  'div',
                                  {
                                    className: 'flex items-start gap-2 border-b border-(--ui-stroke-secondary) pb-1.5',
                                    children: [
                                      jsx('span', { className: 'font-mono text-[0.6875rem] text-(--ui-text-quaternary)', children: shortTime(l.time) }),
                                      jsx(Pill, { tone: l.type === 'FLOOR_GUARD_TRIGGERED' ? 'warn' : l.type === 'BLOCKED' ? 'bad' : 'good', children: l.type }),
                                      jsx('span', { className: 'min-w-0 flex-1', children: l.message })
                                    ]
                                  },
                                  i
                                )
                              )
                            })
                          : jsx(EmptyState, { title: '暂无调价记录', description: '执行一次跟价后这里会留痕' })
                    })
                  }),
                  jsx(Card, {
                    title: '规则说明',
                    children: jsxs('div', {
                      className: 'space-y-1 text-[0.75rem] text-(--ui-text-tertiary)',
                      children: [
                        jsx('div', { children: '① 目标价 = 最低竞品价 − R1；② 目标价低于底价 ⇒ 不跟价，保留利润并由熔断保护；' }),
                        jsx('div', { children: '③ 写回走服务端 PATCH /offers/by_sku/{sku}，Seller Key 永不出现在这个界面；' }),
                        jsx('div', { children: '④ 每次调价写入 price_change_log，可在财务模块对账。' }),
                        jsx('div', { children: '⑤ 单条跟价：在「目标价」列填数 → 点「按此价调价」（手填价覆盖规则价，仍过底价熔断，偏差超 50% 会被拦下防手滑）；不填就点「按规则调价」。' }),
                        jsx('div', { children: '⑥ 批量：勾选若干行 → 「对选中跟价」，或对整个筛选结果执行；搜索框支持 SKU / TSIN / PLID / 条码 / 标题（空格分词 = 同时包含），筛选与排序都不影响已选行。' }),
                        jsx('div', { children: '⑦ 「补竞品数据」= 对当前筛选结果抓一次公开页（不改价、不碰 Seller Key），把「最低竞品价 / BuyBox 归属」补进缓存；每轮有条数上限与 25s 预算，抓完当场重算目标价与判定，还剩多少会写在本轮结果里。' })
                      ]
                    })
                  })
                ]
              })
            ]
          })
        }
      })
    ]
  })
}

function Competitor() {
  const storeId = useValue($storeId)
  const [url, setUrl] = useState('')
  const q = useApi(`/competitor?storeId=${encodeURIComponent(storeId)}`, `competitor:${storeId}`)
  const track = usePost('/competitor/track')
  const fail = e => host.notify({ kind: 'error', message: msg(e) })
  return jsxs('div', {
    className: 'space-y-3',
    children: [
      jsx(Card, {
        title: '追踪竞品（公开 API 快照，不涉及 Seller Key）',
        children: jsxs('div', {
          className: 'flex flex-wrap items-end gap-2',
          children: [
            jsx('div', { className: 'min-w-[22rem] flex-1', children: jsx(Input, { value: url, placeholder: '粘贴 Takealot 商品链接或 TSIN / PLID', onChange: e => setUrl(e.target.value) }) }),
            jsx(Button, {
              size: 'sm',
              disabled: track.isPending || !url.trim(),
              onClick: () => track.mutate({ url: url.trim() }, { onSuccess: () => { setUrl(''); refresh(); host.notify({ kind: 'info', message: '已加入竞品监控' }) }, onError: fail }),
              children: track.isPending ? '抓取中…' : '加入监控'
            })
          ]
        })
      }),
      jsx(Async, {
        query: q,
        children: d =>
          (d.items || []).length
            ? jsx('div', {
                className: 'grid gap-3 lg:grid-cols-2',
                children: (d.items || []).map(c =>
                  jsxs(
                    'div',
                    {
                      className: 'space-y-2 rounded-lg border border-(--ui-stroke-secondary) p-3',
                      children: [
                        jsxs('div', {
                          className: 'flex items-start justify-between gap-2',
                          children: [
                            jsxs('div', {
                              className: 'min-w-0',
                              children: [
                                jsx('div', { className: 'truncate text-[0.8125rem] font-medium', title: c.title, children: c.title }),
                                jsx('div', { className: 'font-mono text-[0.6875rem] text-(--ui-text-quaternary)', children: `${c.tsin} · ${c.brand || '—'} · ${c.category || '—'}` })
                              ]
                            }),
                            jsx(Pill, { tone: c.source === 'public-api' ? 'good' : 'mute', children: c.source === 'public-api' ? '公开 API' : '样例快照' })
                          ]
                        }),
                        jsx(Grid, {
                          cols: 4,
                          children: [
                            jsx(Metric, { label: '我的价', value: ZAR(c.myPrice) }),
                            jsx(Metric, { label: 'BuyBox 价', value: ZAR(c.buyboxPrice), sub: c.buyboxSeller || '—' }),
                            jsx(Metric, { label: '最低报价', value: ZAR(c.lowestOffer), sub: `${NUM(c.offersCount)} 个跟卖` }),
                            jsx(Metric, { label: '价差区间', value: ZAR(c.offerSpread), sub: c.estVelocityNote || '' })
                          ]
                        }),
                        jsx(Spark, { points: (c.priceHistory || []).map(p => p.price) }),
                        jsxs('div', {
                          className: 'flex items-center justify-between text-[0.6875rem] text-(--ui-text-quaternary)',
                          children: [
                            jsx('span', { children: `预估月销 ${NUM(c.estMonthlySales)} 件 · 评价 ${NUM(c.reviews)} · 评分 ${c.rating || '—'}` }),
                            jsx(Button, {
                              size: 'xs',
                              variant: 'outline',
                              onClick: () => {
                                $analyticsTarget.set(c.tsin)
                                $module.set('collection')
                              },
                              children: '深度分析'
                            }),
                            jsx(Button, {
                              size: 'xs',
                              variant: 'ghost',
                              onClick: () => rest(`/competitor/${c.tsin}`, { method: 'DELETE' }).then(() => { refresh(); host.notify({ kind: 'info', message: '已取消监控' }) }, fail),
                              children: '取消监控'
                            })
                          ]
                        })
                      ]
                    },
                    c.tsin
                  )
                )
              })
            : jsx(EmptyState, { title: '还没有监控竞品', description: '粘贴链接即可抓取 BuyBox、跟卖数与价格走势' })
      })
    ]
  })
}

function Compliance() {
  const [text, setText] = useState('')
  const [category, setCategory] = useState('')
  const storeId = useValue($storeId)
  const q = useApi(`/compliance/rules?storeId=${encodeURIComponent(storeId)}`, `rules:${storeId}`)
  const check = usePost('/compliance/check')
  const r = check.data
  return jsxs('div', {
    className: 'grid gap-3 lg:grid-cols-[1.4fr_1fr]',
    children: [
      jsxs('div', {
        className: 'space-y-3',
        children: [
          jsx(Card, {
            title: '标题 / 卖点合规体检',
            children: jsxs('div', {
              className: 'space-y-2',
              children: [
                jsx(Textarea, {
                  rows: 5,
                  value: text,
                  placeholder: '粘贴待上架的标题或五点描述…',
                  onChange: e => setText(e.target.value)
                }),
                jsxs('div', {
                  className: 'flex flex-wrap items-end gap-2',
                  children: [
                    jsx('div', { className: 'w-56', children: jsx(Input, { value: category, placeholder: '类目（可选）', onChange: e => setCategory(e.target.value) }) }),
                    jsx(Button, {
                      size: 'sm',
                      disabled: check.isPending || !text.trim(),
                      onClick: () => check.mutate({ text: text.trim(), category: category.trim() || undefined }),
                      children: check.isPending ? '检测中…' : '开始检测'
                    }),
                    check.isError ? jsx(Pill, { tone: 'bad', children: msg(check.error) }) : null
                  ]
                }),
                r
                  ? jsxs('div', {
                      className: 'space-y-2',
                      children: [
                        jsxs('div', {
                          className: 'flex items-center gap-2',
                          children: [
                            jsx(Pill, { tone: r.verdict === 'pass' ? 'good' : r.verdict === 'block' ? 'bad' : 'warn', children: r.verdict === 'pass' ? '通过' : r.verdict === 'block' ? '禁止上架' : '需修改' }),
                            jsx('span', { className: 'text-[0.75rem] text-(--ui-text-quaternary)', children: `合规分 ${r.score}` })
                          ]
                        }),
                        (r.hits || []).length
                          ? jsx(Table, {
                              head: [jsx(Th, { key: 'w', children: '命中' }), jsx(Th, { key: 'k', children: '类型' }), jsx(Th, { key: 's', children: '级别' }), jsx(Th, { key: 'a', children: '建议' })],
                              children: (r.hits || []).map((h, i) =>
                                jsxs(
                                  'tr',
                                  {
                                    children: [
                                      jsx(Td, { mono: true, children: h.word }),
                                      jsx(Td, { children: h.kind }),
                                      jsx(Td, { children: jsx(Pill, { tone: h.severity === 'high' ? 'bad' : h.severity === 'medium' ? 'warn' : 'mute', children: h.severity }) }),
                                      jsx(Td, { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: h.advice })
                                    ]
                                  },
                                  i
                                )
                              )
                            })
                          : jsx('div', { className: 'rounded border border-(--ui-accent) px-2.5 py-1.5 text-[0.8125rem] text-(--ui-accent)', children: '未命中风险词，可直接上架' }),
                        (r.suggestions || []).length
                          ? jsx('ul', {
                              className: 'ml-4 list-disc space-y-0.5 text-[0.75rem] text-(--ui-text-tertiary)',
                              children: (r.suggestions || []).map((s, i) => jsx('li', { children: s }, i))
                            })
                          : null
                      ]
                    })
                  : null
              ]
            })
          }),
          jsx(Card, {
            title: '为什么需要它',
            children: jsxs('div', {
              className: 'space-y-1 text-[0.75rem] text-(--ui-text-tertiary)',
              children: [
                jsx('div', { children: 'Takealot / 南非消费者保护法对绝对化用语、医疗功效宣称、未授权品牌词判定很严，轻则下架重则扣款。' }),
                jsx('div', { children: '检测在本地完成（词库 + 品牌库），文案不外传；需要改写时再交给 AI 文案模块。' })
              ]
            })
          })
        ]
      }),
      jsx(Card, {
        title: '词库与品牌库',
        children: jsx(Async, {
          query: q,
          children: d =>
            jsxs('div', {
              className: 'space-y-2 text-[0.75rem]',
              children: [
                jsxs('div', {
                  className: 'flex flex-wrap gap-1',
                  children: (d.words || []).map((w, i) =>
                    jsx(Pill, { tone: w.severity === 'high' ? 'bad' : w.severity === 'medium' ? 'warn' : 'mute', children: w.kind ? `${w.word}（${w.kind}）` : w.word }, `w${i}`)
                  )
                }),
                jsx('div', { className: 'text-(--ui-text-quaternary)', children: `覆盖类目：${(d.categories || []).join('、') || '—'}` })
              ]
            })
        })
      })
    ]
  })
}

function Settings() {
  const [name, setName] = useState('')
  const [apiKey, setApiKey] = useState('')
  const [region, setRegion] = useState('ZA')
  const me = useApi('/settings', 'settings')
  const fees = useApi('/meta/fees', 'fees')
  const addStore = usePost('/settings/store')
  const test = usePost('/settings/test')
  const setActive = usePost('/settings/active')
  const [formMsg, setFormMsg] = useState(null)
  const fail = e => host.notify({ kind: 'error', message: msg(e) })
  const done = m => {
    refresh()
    host.notify({ kind: 'info', message: m })
  }
  return jsxs('div', {
    className: 'space-y-3',
    children: [
      jsx(Async, {
        query: me,
        children: d =>
          jsxs('div', {
            className: 'space-y-3',
            children: [
              jsxs('div', {
                className: 'flex flex-wrap items-center gap-2',
                children: [
                  jsx(Pill, { tone: d.mode === 'live' ? 'good' : 'warn', children: d.mode === 'live' ? '已接官方 Seller API v1' : '当前为内置样例数据' }),
                  jsx(Pill, { tone: 'mute', children: `key：${d.keyConfigured ? '已配置' : '未配置'}` }),
                  jsx(Pill, { tone: 'mute', children: `VAT ${PCT((d.vatRate || 0) * 100)}` }),
                  jsx(Pill, { tone: 'mute', children: `DC 默认 ${(d.dcDefaults || {}).warehouse || 'JHB'} · ${(d.dcDefaults || {}).weightKg || 0.2}kg` })
                ]
              }),
              jsx(Card, {
                title: '多店铺绑定',
                extra: jsx(Pill, { tone: 'mute', children: '一个 Seller 仅一个有效 Key，换新 Key 会吊销旧 Key' }),
                children: (d.stores || []).length
                  ? jsx(Table, {
                      head: [jsx(Th, { key: 'n', children: '店铺' }), jsx(Th, { key: 'k', children: 'Key' }), jsx(Th, { key: 'r', children: '区域' }), jsx(Th, { key: 's', children: '状态' }), jsx(Th, { key: 'c', children: '最近校验' }), jsx(Th, { key: 'a', children: '' })],
                      children: (d.stores || []).map(s =>
                        jsxs(
                          'tr',
                          {
                            children: [
                              jsx(Td, { children: jsxs('div', { children: [s.name, jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: s.note || s.id })] }) }),
                              jsx(Td, { mono: true, children: s.keyMasked }),
                              jsx(Td, { children: s.region }),
                              jsx(Td, { children: jsx(Pill, { tone: s.status === 'connected' ? 'good' : s.status === 'error' ? 'bad' : 'warn', children: s.status === 'connected' ? '已连接' : s.status === 'error' ? '校验失败' : '未校验' }) }),
                              jsx(Td, { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: stamp(s.lastChecked) }),
                              jsx(Td, {
                                children: jsxs('div', {
                                  className: 'flex gap-1',
                                  children: [
                                    jsx(Button, {
                                      size: 'xs',
                                      variant: 'ghost',
                                      disabled: test.isPending,
                                      onClick: () => test.mutate({ id: s.id }, { onSuccess: r => done(r.message || '校验完成'), onError: fail }),
                                      children: '测试连接'
                                    }),
                                    s.active
                                      ? jsx(Pill, { tone: 'good', children: '当前店铺' })
                                      : jsx(Button, {
                                          size: 'xs',
                                          variant: 'outline',
                                          disabled: setActive.isPending,
                                          onClick: () => setActive.mutate({ storeId: s.id }, { onSuccess: r => done(r.message || `已切换到 ${s.name}`), onError: fail }),
                                          children: '设为当前'
                                        }),
                                    jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => rest(`/settings/store/${s.id}`, { method: 'DELETE' }).then(() => done('已解绑'), fail), children: '解绑' })
                                  ]
                                })
                              })
                            ]
                          },
                          s.id
                        )
                      )
                    })
                  : jsx(EmptyState, { title: '还没有绑定店铺', description: '填入 Takealot Seller API Key 后可切换为实时数据' })
              }),
              jsxs('div', {
                className: 'grid gap-3 lg:grid-cols-2',
                children: [
                  jsx(Card, {
                    title: '绑定新店铺',
                    children: jsxs('div', {
                      className: 'space-y-2',
                      children: [
                        jsx(Field, { label: '店铺名称', children: jsx(Input, { value: name, placeholder: '如 Apex Direct', onChange: e => setName(e.target.value) }) }),
                        jsx(Field, { label: 'Seller API Key（X-API-Key，仅存服务端）', children: jsx(Input, { value: apiKey, type: 'password', placeholder: '粘贴官方 Key', onChange: e => setApiKey(e.target.value) }) }),
                        jsx(Field, { label: '区域', children: jsx(Input, { value: region, onChange: e => setRegion(e.target.value) }) }),
                        jsx(Button, {
                          size: 'sm',
                          disabled: addStore.isPending || (!apiKey.trim() && !name.trim()),
                          onClick: () =>
                            addStore.mutate(
                              { name: name.trim(), apiKey: apiKey.trim(), region: region.trim() || 'ZA' },
                              {
                                onSuccess: r => {
                                  const st = (r && r.store) || {}
                                  setName('')
                                  setApiKey('')
                                  setFormMsg({
                                    ok: true,
                                    text: `${(r && r.message) || '店铺已保存'}（${st.name || ''} · ${st.keyMasked || ''} · ${st.status === 'connected' ? '已连接' : '待校验'}）`
                                  })
                                  refresh()
                                  host.notify({ kind: 'info', message: '店铺已绑定：记得点该行的「设为当前」开始使用' })
                                },
                                onError: e => {
                                  const text = msg(e)
                                  setFormMsg({ ok: false, text })
                                  host.notify({ kind: 'error', message: text })
                                }
                              }
                            ),
                          children: addStore.isPending ? '校验中…（实时调用 Takealot，最长 20 秒）' : '保存并校验'
                        }),
                        !apiKey.trim() && !name.trim()
                          ? jsx('div', { className: 'text-[0.6875rem] text-amber-400', children: '粘贴 Seller API Key 后即可保存（店铺名称可留空，默认 Takealot Store）' })
                          : null,
                        formMsg
                          ? jsx('div', {
                              className: cn('rounded border px-2 py-1 text-[0.75rem]', formMsg.ok ? 'border-(--ui-accent) text-(--ui-accent)' : 'border-red-400/60 text-red-400'),
                              children: formMsg.text
                            })
                          : null,
                        jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `状态目录：${d.stateDir || '—'}` }),
                        jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `插件目录：${d.packageDir || '—'}` })
                      ]
                    })
                  }),
                  jsx(Card, {
                    title: '类目成功费率（官方费率表）',
                    children: jsx(Async, {
                      query: fees,
                      children: f =>
                        jsxs('div', {
                          className: 'space-y-1 text-[0.75rem]',
                          children: [
                            jsxs('div', {
                              className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                              children: `成功费按「含 VAT 售价」的百分比计算，平台按含 VAT 入账（×1.15）；共 ${Object.keys(f.categoryRates || {}).length} 个主类目`
                            }),
                            jsx('div', {
                              className: 'max-h-64 space-y-1 overflow-auto',
                              children: Object.entries(f.categoryRates || {}).map(([main, rows], i) =>
                                jsxs(
                                  'div',
                                  {
                                    className: 'border-b border-(--ui-stroke-secondary) py-1',
                                    children: [
                                      jsx('div', { className: 'text-(--ui-text-secondary)', children: main }),
                                      jsx('div', {
                                        className: 'flex flex-wrap gap-x-3 gap-y-0.5 text-[0.6875rem] text-(--ui-text-tertiary)',
                                        children: (Array.isArray(rows) ? rows : []).map((r, j) =>
                                          jsx(
                                            'span',
                                            {
                                              className: 'tabular-nums',
                                              children: `${r.sub} ${r.ratePercent}${r.condition ? ` (${r.condition})` : ''}`
                                            },
                                            j
                                          )
                                        )
                                      })
                                    ]
                                  },
                                  i
                                )
                              )
                            }),
                            jsxs('div', {
                              className: 'space-y-0.5 text-[0.6875rem] text-(--ui-text-quaternary)',
                              children: [
                                jsx('div', { children: `履约费：官方按体积档 × 重量档 × 类目分组定价（不含 VAT）× 1.15 入账；仓储费按体积档、35 天内动销 R0` }),
                                jsx('div', { children: `月订阅 ${ZAR(((f.otherFees || {}).subscriptionMonthly || {}).amount)}（不含 VAT）× 1.15 = ${ZAR((((f.otherFees || {}).subscriptionMonthly || {}).amount || 0) * 1.15)}` }),
                                jsx('div', { children: `最低成功费：平台不设下限（商家后台导出里 R39 的订单实收 R5.38 = 4.68×1.15），本工具同样不设下限` }),
                                jsx('div', { children: `数据来源：${(f.meta || {}).source || ''} → ${f.source || ''}` })
                              ]
                            })
                          ]
                        })
                    })
                  })
                ]
              })
            ]
          })
      })
    ]
  })
}

// ── shell ──────────────────────────────────────────────────────────────────

// ── 选品与销量分析：公开数据 → 评论窗口 → 留评率换算销量 → 跟卖结构 → AI 价值判断 ──
// 采集箱与「选品/销量分析」合并后：同一个组件整页可用（embedded=false），
// 也能直接内联进采集箱某一行的展开区（embedded=true，目标由该行给出）。
// 内联时成本/头程沿用行里的核算参数，数字口径与行内一致；数字优先读缓存，不自动联网。
function Analytics({ embedded = false, preset = '', item = null } = {}) {
  const queued = useValue($analyticsTarget)
  const storeId = useValue($storeId)
  const [target, setTarget] = useState(preset || queued || (storage && storage.get('analyticsTarget', '')) || '')
  const [cost, setCost] = useState(item && item.cost != null ? String(item.cost) : '')
  const [freight, setFreight] = useState(item && item.freight != null ? String(item.freight) : '')
  const [res, setRes] = useState(null)
  const [ai, setAi] = useState(null)
  const status = useApi('/crawler/status', 'crawlerstatus')
  const pullM = usePost('/crawler/pull')
  const aiM = usePost('/ai/listing-analysis')
  const addM = usePost('/collection/add')
  const fail = e => host.notify({ kind: 'error', message: msg(e) })
  const [draftRes, setDraftRes] = useState(null)
  const [draftBusy, setDraftBusy] = useState(false)
  const runDraft = async dryRun => {
    const value = String(target || '').trim()
    if (!value) {
      host.notify({ kind: 'warn', message: '先填目标（链接 / TSIN / PLID）' })
      return
    }
    if (!storeId) {
      host.notify({ kind: 'warn', message: '请先选定店铺（汇总视图下无法确定建到哪家店）' })
      return
    }
    setDraftBusy(true)
    setDraftRes(null)
    try {
      const r = await rest('/analytics/draft', { method: 'POST', body: { target: value, storeId, dryRun: !!dryRun } })
      setDraftRes(r)
      host.notify({
        kind: r && r.ok ? 'info' : 'warn',
        message: r && r.ok
          ? dryRun
            ? '试算完成：未写草稿'
            : `已建档 ${r.draftId || ''}`
          : (r && (r.error || (r.advice || {}).action)) || '未完成'
      })
      if (r && r.ok && !dryRun) refresh()
    } catch (e) {
      fail(e)
    } finally {
      setDraftBusy(false)
    }
  }

  const run = force =>
    pullM.mutate(
      { target: target.trim(), force: !!force },
      {
        onSuccess: r => {
          setRes(r)
          setAi(null)
          if (r.mode === 'blocked') {
            host.notify({ kind: 'warning', message: '抓取通道未通：' + (r.hint || '需要配置中继代理') })
          }
        },
        onError: fail
      }
    )

  // Hydrate from the cache-only read so a hand-off target shows its numbers
  // immediately instead of an empty panel.
  const cachedQ = useApi(`/crawler/pull?target=${encodeURIComponent(target)}&cachedOnly=1`, `cached:${target}`, { enabled: !!target.trim() })
  const shown = res || ((cachedQ.data && cachedQ.data.ok && cachedQ.data.product) ? cachedQ.data : null)
  const aiCachedQ = useApi(`/ai/listing-analysis?target=${encodeURIComponent(target)}&storeId=${encodeURIComponent(storeId)}&cachedOnly=1`, `aicache:${target}:${storeId}`, {
    enabled: !!target.trim()
  })
  const aiShown = ai || ((aiCachedQ.data && aiCachedQ.data.ok && aiCachedQ.data.verdict) ? aiCachedQ.data : null)
  const st = status.data || {}
  const p = (shown || {}).product || {}
  const sales = (shown || {}).sales || {}
  const w = (shown || {}).windows || {}
  const rate = (shown || {}).rate || {}
  const offers = p.offers || []

  return jsxs('div', {
    className: 'space-y-3',
    children: [
      embedded ? null : jsx('div', {
        className: cn(
          'flex flex-wrap items-center gap-2 rounded border px-3 py-2 text-[0.75rem]',
          st.transport === 'blocked' ? 'border-amber-400/60 text-amber-400' : 'border-(--ui-stroke-secondary) text-(--ui-text-tertiary)'
        ),
        children: [
          jsx(Pill, { tone: st.transport === 'blocked' ? 'warn' : 'good', children: st.transport === 'blocked' ? '抓取通道未通' : `抓取通道 ${st.transport || '待探测'}` }),
          jsx('span', { children: st.proxyConfigured ? `中继代理 ${st.proxy}` : '未配置中继代理（TAKEALOT_API_PROXY）' }),
          jsx('span', { children: `缓存 ${NUM(st.cacheEntries)} 条` }),
          jsx('span', { className: 'min-w-0 flex-1 truncate', children: st.hint || '' })
        ]
      }),
      jsx(Card, {
        title: '据此建档（新建 Listing / 跟卖判定）',
        extra: jsxs('div', {
          className: 'flex flex-wrap items-center gap-2',
          children: [
            jsx(Button, { size: 'xs', variant: 'outline', disabled: draftBusy || !String(target || '').trim() || !storeId, onClick: () => runDraft(true), children: draftBusy ? '处理中…' : '试算（不写草稿）' }),
            jsx(Button, { size: 'xs', disabled: draftBusy || !String(target || '').trim() || !storeId, onClick: () => runDraft(false), children: '执行建档' })
          ]
        }),
        children: jsxs('div', {
          className: 'space-y-2',
          children: [
            jsx('div', {
              className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
              children: '把当前目标直接变成上架草稿（抓取到的类目/图片 + AI 文案），与「上架编排」同一份数据。若该商品在 Takealot 上已存在，会先被拦下并指引跟卖——新建装载表会被平台以 cant-create-duplicate-gtin 拒收。'
            }),
            draftRes && draftRes.blocked
              ? jsxs('div', {
                  className: 'space-y-1 rounded border border-amber-400/60 bg-amber-400/10 p-2 text-[0.75rem]',
                  children: [
                    jsx('div', { children: `已拦下：${draftRes.error || ''}` }),
                    jsx('div', { children: `建议动作：${((draftRes.advice || {}).action) || '跟卖/改价'}` }),
                    (draftRes.advice || {}).sku ? jsx('div', { children: `自有 SKU：${draftRes.advice.sku}${(draftRes.advice || {}).offerId ? ` · Offer ${draftRes.advice.offerId}` : ''}` }) : null,
                    (draftRes.advice || {}).locate ? jsx('div', { className: 'text-amber-400', children: draftRes.advice.locate }) : null,
                    jsx('div', { children: `去哪做：${((draftRes.advice || {}).where) || ''}` }),
                    (draftRes.advice || {}).reason ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `依据：${draftRes.advice.reason}` }) : null
                  ]
                })
              : null,
            draftRes && draftRes.ok
              ? jsxs('div', {
                  className: 'space-y-1 rounded border border-(--ui-stroke-secondary) p-2 text-[0.75rem]',
                  children: [
                    jsx('div', { children: `${draftRes.dryRun ? '试算' : '已建档'}：路由 ${draftRes.route || '—'} · 文案来源 ${((draftRes.copy || {}).source) || '—'} · 卖点 ${NUM(((draftRes.copy || {}).featuresLength))} 字` }),
                    jsx('div', { className: 'text-(--ui-text-tertiary)', children: (draftRes.copy || {}).title || '' }),
                    draftRes.draftId ? jsx('div', { children: `草稿号：${draftRes.draftId}（去「上架编排」校验/导出）` }) : null,
                    ((draftRes.readiness || {}).errors || []).length
                      ? jsx('div', { className: 'text-amber-400', children: `建档后仍未就绪：${(draftRes.readiness.errors || []).join('；')}` })
                      : null,
                    (draftRes.warnings || []).length
                      ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `提醒：${(draftRes.warnings || []).join('；')}` })
                      : null
                  ]
                })
              : null
          ]
        })
      }),
      jsx(Card, {
        title: '采集并测算（公开 API，不涉及 Seller Key）',
        children: jsxs('div', {
          className: 'flex flex-wrap items-end gap-2',
          children: [
            embedded
              ? jsx('div', { className: 'min-w-[12rem] flex-1 text-[0.75rem] text-(--ui-text-quaternary)', children: `目标：${target}（本行商品）` })
              : jsx('div', {
                  className: 'min-w-[20rem] flex-1',
                  children: jsx(Input, {
                    value: target,
                    placeholder: '商品链接 / TSIN1234567 / PLID73910245',
                    onChange: e => {
                      setTarget(e.target.value)
                      if (storage) {
                        storage.set('analyticsTarget', e.target.value)
                      }
                    }
                  })
                }),
            embedded ? null : jsx('div', { className: 'w-28', children: jsx(Input, { value: cost, placeholder: '采购成本', onChange: e => setCost(e.target.value) }) }),
            embedded ? null : jsx('div', { className: 'w-28', children: jsx(Input, { value: freight, placeholder: '头程运费', onChange: e => setFreight(e.target.value) }) }),
            jsx(Button, { size: 'sm', disabled: pullM.isPending || !target.trim(), onClick: () => run(true), children: pullM.isPending ? '分析中…' : (embedded ? '重新分析（联网）' : '采集并测算') }),
            jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => run(false), children: '只看缓存' }),
            embedded ? null : jsx(Button, {
              size: 'xs',
              variant: 'outline',
              disabled: addM.isPending || !target.trim(),
              onClick: () =>
                addM.mutate(
                  { url: target.trim(), cost: Number(cost) || undefined, price: p.price || undefined, storeId: storeId || undefined },
                  { onSuccess: () => host.notify({ kind: 'info', message: '已加入采集箱' }), onError: fail }
                ),
              children: '加入采集箱'
            })
          ]
        })
      }),
      shown
        ? jsxs('div', {
            className: 'space-y-3',
            children: [
              jsxs('div', {
                className: 'grid gap-3 lg:grid-cols-[1.4fr_1fr]',
                children: [
                  jsx(Card, {
                    title: '商品公开数据',
                    extra: jsxs('div', {
                      className: 'flex items-center gap-2',
                      children: [
                        jsx(Pill, { tone: shown.mode === 'live' ? 'good' : shown.mode === 'blocked' ? 'warn' : 'mute', children: shown.mode === 'live' ? (shown.transport === 'ingest' ? '中继数据' : '公开 API') : shown.mode === 'blocked' ? '通道未通' : '样例数据' }),
                        shown.cached ? jsx(Pill, { tone: 'mute', children: '缓存命中' }) : null
                      ]
                    }),
                    children: jsxs('div', {
                      className: 'space-y-2 text-[0.8125rem]',
                      children: [
                        jsx('div', { className: 'font-medium', children: p.title || '—' }),
                        jsxs('div', {
                          className: 'flex flex-wrap gap-1',
                          children: [
                            jsx(Pill, { tone: 'mute', children: `PLID${p.plid || '—'}` }),
                            jsx(Pill, { tone: 'mute', children: p.tsin || '—' }),
                            jsx(Pill, { tone: 'mute', children: p.brand || '无品牌' }),
                            jsx(Pill, { tone: 'mute', children: p.categoryL1 || '—' }),
                            (p.badges || []).map((b, i) => jsx(Pill, { key: `b${i}`, tone: 'warn', children: b.value || b.type })),
                            p.inStock ? jsx(Pill, { tone: 'good', children: '有货' }) : jsx(Pill, { tone: 'bad', children: '缺货' })
                          ]
                        }),
                        jsxs('div', {
                          className: 'grid grid-cols-2 gap-2 text-[0.75rem] text-(--ui-text-tertiary)',
                          children: [
                            jsx('div', { children: `售价 ${ZAR(p.price)}（${p.prettyPrice || ''}）` }),
                            jsx('div', { children: `评分 ${p.rating || '—'} / ${NUM(p.reviewCount)} 条评价` }),
                            jsx('div', { className: 'col-span-2', children: `类目路径 ${p.categoryPath || '—'}` }),
                            jsx('div', { children: `发货 ${p.deliveryDays ? p.deliveryDays + ' 天' : '—'}${p.fulfillment ? ' · ' + p.fulfillment : ''}` }),
                            jsx('div', { children: `仓库 ${(p.warehouses || []).join(' / ') || '—'}` })
                          ]
                        }),
                        (p.attributes || []).length
                          ? jsx('div', {
                              className: 'flex flex-wrap gap-1 text-[0.6875rem] text-(--ui-text-quaternary)',
                              children: p.attributes.slice(0, 8).map((a, i) => jsx(Pill, { key: `a${i}`, tone: 'mute', children: `${a.name}: ${String(a.value).slice(0, 18)}` }))
                            })
                          : null
                      ]
                    })
                  }),
                  jsx(Card, {
                    title: '销量推算（评论窗口 ÷ 类目留评率）',
                    children: jsxs('div', {
                      className: 'space-y-2',
                      children: [
                        jsx(Grid, {
                          cols: 4,
                          children: [
                            jsx(Metric, { label: '月销', value: NUM(sales.estimated_monthly_sales), sub: `日均 ${sales.estimated_daily_sales}` }),
                            jsx(Metric, { label: '月销额', value: sales.estimated_monthly_revenue ? ZAR(sales.estimated_monthly_revenue) : '—', sub: '按当前售价' }),
                            jsx(Metric, { label: '7 天', value: NUM(sales.sales_7d), sub: '按月销平滑' }),
                            jsx(Metric, { label: '留评率', value: PCT((rate.reviewRate || 0) * 100), sub: rate.rateSource || 'default' })
                          ]
                        }),
                        jsx(Table, {
                          head: [
                            jsx(Th, { key: 'w', children: '窗口' }),
                            jsx(Th, { key: 'r', right: true, children: '新增评论' }),
                            jsx(Th, { key: 's', right: true, children: '推算销量' }),
                            jsx(Th, { key: 'd', right: true, children: '日均' })
                          ],
                          children: [
                            ['7 天', w.reviews_7d, sales.sales_7d],
                            ['30 天', w.reviews_30d, sales.sales_30d],
                            ['90 天', w.reviews_90d, sales.sales_90d],
                            ['180 天', w.reviews_180d, sales.sales_180d]
                          ].map(([label, rv, sv]) =>
                            jsxs(
                              'tr',
                              {
                                children: [
                                  jsx(Td, { children: label }),
                                  jsx(Td, { right: true, children: NUM(rv) }),
                                  jsx(Td, { right: true, className: 'text-(--ui-accent)', children: NUM(sv) }),
                                  jsx(Td, { right: true, className: 'text-(--ui-text-tertiary)', children: NUM(Math.round((Number(sv) || 0) / (Number(String(label).replace(/\D/g, '')) || 1) * 10) / 10) })
                                ]
                              },
                              label
                            )
                          )
                        }),
                        jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: rate.rateNote || '' }),
                        Number(w.reviews_30d) === 0
                          ? jsx('div', {
                              className: 'rounded border border-amber-400/50 px-2 py-1 text-[0.6875rem] text-amber-400',
                              children: '近 30 天无新增评论：月销按 0 计（可能是新 listing 或动销已停滞），请结合 90/180 天窗口与跟卖情况判断。'
                            })
                          : null,
                        jsx('div', {
                          className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                          children: `翻取 ${NUM(w.pagesFetched)} 页评论 · 累计采样 ${NUM(w.total)} 条${w.truncated ? ' · 命中翻页上限，180 天未数全' : ''}`
                        })
                      ]
                    })
                  })
                ]
              }),
              jsx(Card, {
                title: '跟卖结构（BuyBox 归属与竞品报价）',
                extra: jsx(Pill, { tone: p.isExclusive ? 'good' : 'warn', children: p.isExclusive ? '独家（无跟卖）' : `跟卖 ${NUM(p.sellerCount)} 家` }),
                children: jsxs('div', {
                  className: 'space-y-2',
                  children: [
                    jsxs('div', {
                      className: 'flex flex-wrap gap-2 text-[0.75rem] text-(--ui-text-tertiary)',
                      children: [
                        jsx('span', { children: `BuyBox 持有：${p.buyboxSeller || '—'}` }),
                        jsx('span', { children: `最低竞品价：${p.lowestCompetitorPrice ? ZAR(p.lowestCompetitorPrice) : '—'}` }),
                        jsx('span', { children: `报价区间：${p.price ? ZAR(p.price) : '—'} ~ ${p.lowestCompetitorPrice ? ZAR(p.lowestCompetitorPrice) : '—'}` })
                      ]
                    }),
                    offers.length
                      ? jsx(Table, {
                          head: [
                            jsx(Th, { key: 's', children: '卖家' }),
                            jsx(Th, { key: 'p', right: true, children: '报价' }),
                            jsx(Th, { key: 'c', children: '成色' }),
                            jsx(Th, { key: 'r', right: true, children: '评分' }),
                            jsx(Th, { key: 'k', children: '库存 / 仓库' })
                          ],
                          children: offers.slice(0, 12).map((o, i) =>
                            jsxs(
                              'tr',
                              {
                                children: [
                                  jsx(Td, { children: jsxs('div', { className: 'flex items-center gap-1', children: [o.sellerName || '—', o.isTakealot ? jsx(Pill, { tone: 'mute', children: 'Takealot 自营' }) : null] }) }),
                                  jsx(Td, { right: true, children: ZAR(o.price) }),
                                  jsx(Td, { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: o.condition || '—' }),
                                  jsx(Td, { right: true, children: o.sellerRating ? String(o.sellerRating) : '—' }),
                                  jsx(Td, { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: `${o.inStock ? '有货' : '缺货'} ${(o.warehouses || []).join('/')}` })
                                ]
                              },
                              i
                            )
                          )
                        })
                      : jsx('div', { className: 'text-[0.75rem] text-(--ui-text-quaternary)', children: '该 listing 目前只有卖家自己在卖（公开接口未返回其他报价）。' })
                  ]
                })
              }),
              jsx(Card, {
                title: 'AI 价值分析',
                extra: jsxs('div', {
                  className: 'flex items-center gap-2',
                  children: [
                    aiShown && aiShown.ai === false ? jsx(Pill, { tone: 'warn', children: '规则兜底' }) : null,
                    jsx(Button, {
                      size: 'xs',
                      disabled: aiM.isPending,
                      onClick: () =>
                        aiM.mutate(
                          { target: target.trim(), storeId: storeId || undefined, cost: Number(cost) || undefined, freight: Number(freight) || undefined },
                          { onSuccess: setAi, onError: fail }
                        ),
                      children: aiM.isPending ? '分析中…' : '生成价值分析'
                    })
                  ]
                }),
                children: aiShown
                  ? jsxs('div', {
                      className: 'space-y-2 text-[0.8125rem]',
                      children: [
                        jsxs('div', {
                          className: 'flex flex-wrap items-center gap-2',
                          children: [
                            jsx(Pill, { tone: aiShown.score >= 70 ? 'good' : aiShown.score >= 45 ? 'warn' : 'bad', children: `${aiShown.verdict} · ${aiShown.score} 分` }),
                            jsx(Pill, { tone: 'mute', children: `竞争 ${(aiShown.competition || {}).level || '—'}` }),
                            jsx(Pill, { tone: 'mute', children: `跟卖 ${NUM(aiShown.sellerCount)}` }),
                            jsx(Pill, { tone: 'mute', children: `月销 ${NUM(aiShown.monthlySales)}` }),
                            jsx(Pill, { tone: 'mute', children: aiShown.model || '规则' })
                          ]
                        }),
                        jsx('div', { className: 'text-(--ui-text-secondary)', children: aiShown.summary }),
                        jsx(Grid, {
                          cols: 4,
                          children: [
                            jsx(Metric, { label: '保本价', value: ZAR((aiShown.priceBand || {}).floor) }),
                            jsx(Metric, { label: '建议价（20% 目标）', value: ZAR((aiShown.priceBand || {}).recommended), tone: 'good' }),
                            jsx(Metric, { label: '当前售价', value: ZAR((aiShown.priceBand || {}).current) }),
                            jsx(Metric, { label: '建议价净利率', value: PCT(aiShown.marginAtRecommended) })
                          ]
                        }),
                        (aiShown.actions || []).length
                          ? jsx('ul', { className: 'ml-4 list-disc space-y-0.5 text-[0.75rem] text-(--ui-text-secondary)', children: (aiShown.actions || []).map((x, i) => jsx('li', { children: x }, i)) })
                          : null,
                        jsxs('div', {
                          className: 'grid gap-2 sm:grid-cols-2',
                          children: [
                            jsxs('div', {
                              className: 'space-y-0.5',
                              children: [
                                jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '风险' }),
                                (aiShown.risks || []).map((x, i) => jsx('div', { className: 'text-[0.75rem] text-red-400', children: `· ${x}` }, i))
                              ]
                            }),
                            jsxs('div', {
                              className: 'space-y-0.5',
                              children: [
                                jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '机会' }),
                                (aiShown.opportunities || []).map((x, i) => jsx('div', { className: 'text-[0.75rem] text-(--ui-accent)', children: `· ${x}` }, i))
                              ]
                            })
                          ]
                        })
                      ]
                    })
                  : jsx('div', {
                      className: 'text-[0.75rem] text-(--ui-text-quaternary)',
                      children: '用当前采集到的公开数据 + 费用模型，让模型给出「值得跟卖 / 可以上新 / 观望 / 不建议」的结论、建议价区间与风险清单。'
                    })
              })
            ]
          })
        : jsx(EmptyState, {
            title: '还没有采集目标',
            description: '输入商品链接 / TSIN / PLID 后点「采集并测算」：评论窗口 → 留评率 → 月销，跟卖人数与报价结构，再交给 AI 判断这个 listing 值不值得做'
          })
    ]
  })
}

// ── 商品管理：全店商品映射 + 详情映射（公共主数据 / 卖家可编辑写入表） ──────
function Thumb({ src, size = 'h-10 w-10' }) {
  if (!src) {
    return jsx('div', {
      className: cn(size, 'flex shrink-0 items-center justify-center rounded border border-(--ui-stroke-secondary) text-[0.5625rem] text-(--ui-text-quaternary)'),
      children: '无图'
    })
  }
  return jsx('img', {
    src,
    alt: '',
    loading: 'lazy',
    className: cn(size, 'shrink-0 rounded border border-(--ui-stroke-secondary) object-cover')
  })
}

// 采集箱（跟卖池）里唯一可写的两项：价格与库存。
// 平台侧 CreateOfferRequest 是 additionalProperties:false，只有 barcode/sku +
// 价格 + 仓库库存可写，标题/图片/描述不在集合里 —— 所以界面也只给这两个输入框。
// 采集箱一行展开后的「核算与利润」：横向铺开（参考 eMAG：标签在上、数值在下，
// 扣项标红、到手标绿），输入格跟着一行，不再挤在右侧窄格里。
function PoolProfit({ item, onSaveCosts, busy }) {
  const p = item.profit || {}
  const rows = Array.isArray(p.breakdown) ? p.breakdown : []
  const warnings = Array.isArray(p.warnings) ? p.warnings : []
  const toHand = p.toHandZar === null || p.toHandZar === undefined ? null : p.toHandZar
  const money = v => (v === null || v === undefined ? '未定' : ZAR(v))
  // 一个指标块：标签（小、灰）+ 数值（等宽数字）；扣项红、到手/利润绿
  const block = (label, value, tone, key) =>
    jsxs(
      'div',
      {
        key: key,
        className: 'min-w-[8.5rem] flex-1',
        children: [
          jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: label }),
          jsx('div', {
            className: cn('tabular-nums font-medium', tone === 'neg' ? 'text-red-400' : tone === 'pos' ? 'text-(--ui-accent)' : ''),
            children: value
          })
        ]
      }
    )
  const line = (row, i) =>
    block(
      row.label,
      row.amount === null || row.amount === undefined ? '未定' : `${row.sign < 0 ? '-' : '+'}${ZAR(Math.abs(row.amount))}`,
      row.sign < 0 ? 'neg' : 'pos',
      `pl-${i}`
    )
  return jsxs('div', {
    className: 'space-y-2 rounded border border-(--ui-stroke-secondary) p-2 text-[0.75rem]',
    children: [
      jsxs('div', {
        className: 'flex flex-wrap items-baseline justify-between gap-2',
        children: [
          jsx('div', {
            className: 'font-medium',
            children: '核算与利润（本地账本：平台看不到；到手已扣平台费、成本、头程、汇损）'
          }),
          jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: '再点一次「▼ 核算与利润」收起' })
        ]
      }),
      jsxs('div', {
        className: 'flex flex-wrap gap-x-4 gap-y-2 rounded border border-(--ui-stroke-secondary) p-2',
        children: [
          ...rows.map(line),
          block('到手（扣完平台费与成本）', money(p.toHandZar), toHand !== null && toHand < 0 ? 'neg' : 'pos', 'pl-tohand'),
          block('利润率', p.marginPercent === null || p.marginPercent === undefined ? '未定' : PCT(p.marginPercent), 'pos', 'pl-margin'),
          block('平台费合计', money(p.platformFeesTotal), '', 'pl-fees'),
          block('成本合计（含汇损）', money(p.totalCostsZar), '', 'pl-costs'),
          p.breakEvenPrice === null || p.breakEvenPrice === undefined
            ? null
            : block('保本价 / 20% 目标价', `${ZAR(p.breakEvenPrice)} / ${money(p.recommendedPrice20)}`, '', 'pl-bep'),
          block(
            '汇损系数 / 结汇率',
            `${PCT((p.exchangeLossCoeff || 0) * 100)}${p.exchangeRateZarPerRmb ? ` · ${p.exchangeRateZarPerRmb}（1 ZAR）` : ' · 未填'}`,
            '',
            'pl-fx'
          )
        ]
      }),
      p.vatNote ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: p.vatNote }) : null,
      p.basis ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: p.basis }) : null,
      ...warnings.map((w, i) => jsx('div', { key: `pw-${i}`, className: 'text-amber-400', children: w })),
      jsx(PoolCostEditor, { item: item, onSave: onSaveCosts, busy: busy })
    ]
  })
}

// 采集箱行内窄格里的结论（明细在行的展开区横向铺开）
function PoolPnl({ item, open, onToggle }) {
  const p = item.profit || {}
  const toHand = p.toHandZar === null || p.toHandZar === undefined ? null : p.toHandZar
  return jsxs('button', {
    type: 'button',
    // 窄格靠自己定最小宽度，不靠表格挤：金额一旦折行（R 单独一行）整列就散了
    className: 'min-w-[7.5rem] whitespace-nowrap text-right align-top',
    onClick: onToggle,
    children: [
      jsx('div', {
        className: cn('tabular-nums whitespace-nowrap font-medium',
                      toHand !== null && toHand < 0 ? 'text-red-400' : 'text-(--ui-accent)'),
        children: toHand === null ? '到手未定' : `${ZAR(toHand)} · ${PCT(p.marginPercent)}`
      }),
      jsx('div', {
        className: 'whitespace-nowrap tabular-nums text-[0.625rem] text-(--ui-text-quaternary)',
        // 行里只放结论；口径解释交给 title，行内不再套括号长注（会挤成四行）
        title: '毛利粗算 = 售价 − 平台费（成功费 + 履约费 + 跨仓费），不含采购成本 / 头程 / 汇损。'
          + '按采购价填好核算参数后，看上面的「到手」才是净利。',
        children: (p.grossProfitZar === null || p.grossProfitZar === undefined)
          ? '毛利未定'
          : `毛利 ${ZAR(p.grossProfitZar)}`
      }),
      jsx('div', {
        className: 'whitespace-nowrap text-[0.625rem] text-(--ui-text-quaternary)',
        children: open ? '\u25bc 收起' : '\u25b6 明细与成本'
      })
    ]
  })
}

// 「核算参数」编辑器：成本/币种/汇率/汇损/头程/重量/尺寸 —— 都是本地账本。
// 为什么放在这里：官方履约费按「体积 cm³ 档 × 重量档 × 类目分组」定价，成功率还有
// 按售价分档的规则 —— 这些就是费率条件。缺了输入就只能显示「未定」，所以必须可填。
function PoolCostEditor({ item, onSave, busy }) {
  const a = item.accounting || {}
  const s = v => (v === null || v === undefined ? '' : String(v))
  const pf = item.profit || {}
  // 界面口径：卖家看「1 CNY = ? ZAR」（跟采购价一个方向，不用自己先换算）。
  // 账本里存的是反向的 1 ZAR = ? CNY，两个方向互为倒数 —— 只存一份，避免两处口径打架。
  // 2.5 只是预填起点（= 1 ZAR ≈ 0.4 CNY），随时可改；改了会随这一起存进本机账本。
  const initPerZar = (() => {
    const stored = a.exchangeRateZarPerRmb || pf.exchangeRateZarPerRmb
    if (stored && Number(stored) > 0) return Math.round((1 / Number(stored)) * 1000) / 1000
    return 2.5
  })()
  const initCogsRmb = a.costRmb ? s(a.costRmb)
    : (a.cost && initPerZar ? s(Math.round((Number(a.cost) / initPerZar) * 100) / 100) : '')
  const initHeadRmb = a.headLogisticsRmb ? s(a.headLogisticsRmb)
    : (a.headLogisticsZar && initPerZar ? s(Math.round((Number(a.headLogisticsZar) / initPerZar) * 100) / 100) : '')
  const initLoss = (a.exchangeLossCoeff !== null && a.exchangeLossCoeff !== undefined) ? s(a.exchangeLossCoeff)
    : (pf.exchangeLossCoeff !== null && pf.exchangeLossCoeff !== undefined ? s(pf.exchangeLossCoeff) : '0.2')
  const [f, setF] = useState({
    cnyPerZar: s(initPerZar),
    exchangeLossCoeff: initLoss,
    costRmb: initCogsRmb,
    headLogisticsRmb: initHeadRmb,
    weightKg: s(a.weightKg),
    lengthCm: s(a.lengthCm),
    widthCm: s(a.widthCm),
    heightCm: s(a.heightCm)
  })
  const set = (k, v) => setF(prev => ({ ...prev, [k]: v }))
  const num = k => (f[k] === '' ? null : Number(f[k]))
  const dirty =
    s(initPerZar) !== f.cnyPerZar ||
    initLoss !== f.exchangeLossCoeff ||
    initCogsRmb !== f.costRmb ||
    initHeadRmb !== f.headLogisticsRmb ||
    s(a.weightKg) !== f.weightKg ||
    s(a.lengthCm) !== f.lengthCm ||
    s(a.widthCm) !== f.widthCm ||
    s(a.heightCm) !== f.heightCm
  const cell = (label, key, placeholder, width) =>
    jsxs(
      'div',
      {
        className: cn('flex items-center gap-1', width || ''),
        children: [
          jsx('span', { className: 'text-(--ui-text-quaternary)', children: label }),
          jsx('div', { className: 'w-16', children: jsx(Input, { size: 'sm', value: f[key], placeholder: placeholder, onChange: e => set(key, e.target.value) }) })
        ]
      },
      key
    )
  const perZar = f.cnyPerZar && Number(f.cnyPerZar) > 0 ? Number(f.cnyPerZar) : null
  const zar = v => (v === '' || v === null || v === undefined || !perZar ? '—' : ZAR(Math.round(Number(v) * perZar * 100) / 100))
  const rateHint = perZar
    ? `= 1 ZAR ≈ ${(Math.round((1 / perZar) * 1000) / 1000)} CNY（预填值，按你实际结汇改）`
    : '填了汇率才能把 ¥ 折成 R'
  // 「¥ 输入 → 自动折 R」并排：卖家按采购价直接填，不用自己先换算一道
  const pair = (label, key) =>
    jsxs(
      'div',
      {
        className: 'flex items-center gap-1',
        children: [
          jsx('span', { className: 'text-(--ui-text-quaternary)', children: label }),
          jsx('span', { className: 'text-(--ui-text-quaternary)', children: '¥' }),
          jsx('div', { className: 'w-20', children: jsx(Input, { size: 'sm', value: f[key], placeholder: '¥', onChange: e => set(key, e.target.value) }) }),
          jsx('span', { className: 'text-(--ui-text-quaternary)', children: '\u21cc R' }),
          jsx('span', { className: 'w-16 tabular-nums', children: zar(f[key]) })
        ]
      },
      key
    )
  const volume = num('lengthCm') && num('widthCm') && num('heightCm')
    ? Math.round(num('lengthCm') * num('widthCm') * num('heightCm') * 10) / 10
    : a.volumeCm3 || null
  const missingDims = !num('lengthCm') || !num('widthCm') || !num('heightCm')
  return jsxs('div', {
    className: 'mt-1 space-y-1 border-t border-(--ui-stroke-secondary) pt-1',
    children: [
      jsx('div', {
        className: 'text-(--ui-text-quaternary)',
        children: '核算参数（本地账本：平台看不到，可随时改）：采购成本与头程按你实际支付的 ¥ 填，右边自动折成 R'
      }),
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-x-3 gap-y-1',
        children: [
          cell('汇率（1 CNY = ? ZAR）', 'cnyPerZar', '2.5', ''),
          cell('汇损系数', 'exchangeLossCoeff', '0.2', ''),
          jsx('span', { className: 'text-(--ui-text-quaternary)', children: rateHint })
        ]
      }),
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-x-3 gap-y-1',
        children: [pair('采购成本', 'costRmb'), pair('头程（发往 Takealot DC）', 'headLogisticsRmb')]
      }),
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-x-2 gap-y-1',
        children: [
          cell('重量kg', 'weightKg', 'kg', ''),
          cell('长', 'lengthCm', 'cm', ''),
          cell('宽', 'widthCm', 'cm', ''),
          cell('高', 'heightCm', 'cm', ''),
          jsx('span', {
            className: 'text-(--ui-text-quaternary)',
            children: volume ? `体积 ${NUM(volume)} cm³` : '体积未定'
          })
        ]
      }),
      jsxs('div', {
        className: 'flex items-center justify-between gap-2',
        children: [
          jsx('div', {
            className: cn('text-(--ui-text-quaternary)', missingDims ? 'text-amber-400' : ''),
            children: a.dimensionSource
              ? `尺寸来源：${a.dimensionSource}${a.dimensionRaw ? `（页面原文 ${a.dimensionRaw}）` : ''}`
              : missingDims ? '没重量/尺寸 → 履约费档位算不出来（上面会显示未定）' : ''
          }),
          jsx(Button, {
            size: 'xs',
            variant: 'outline',
            disabled: busy || !dirty,
            onClick: () =>
              onSave({
                // 账本存「¥ 采购成本 + 反向汇率」；cost 同时写一份 ZAR 等价，方便其它地方按 ZAR 读
                costRmb: num('costRmb'),
                costCurrency: 'RMB',
                cost: num('costRmb') !== null && perZar ? Math.round(Number(num('costRmb')) * perZar * 100) / 100 : null,
                exchangeRateZarPerRmb: perZar ? Math.round((1 / perZar) * 10000) / 10000 : null,
                exchangeLossCoeff: num('exchangeLossCoeff'),
                headLogisticsRmb: num('headLogisticsRmb'),
                headLogisticsZar: num('headLogisticsRmb') !== null && perZar ? Math.round(Number(num('headLogisticsRmb')) * perZar * 100) / 100 : null,
                weightKg: num('weightKg'),
                lengthCm: num('lengthCm'),
                widthCm: num('widthCm'),
                heightCm: num('heightCm')
              }),
            children: '保存核算参数'
          })
        ]
      })
    ]
  })
}

function PoolPriceStock({ item, onSave, busy }) {
  const [price, setPrice] = useState(item.price === null || item.price === undefined ? '' : String(item.price))
  const [stock, setStock] = useState(item.stock === null || item.stock === undefined ? '' : String(item.stock))
  const dirty = String(item.price || '') !== price || String(item.stock === null || item.stock === undefined ? '' : item.stock) !== stock
  if (item.state === 'promoted') {
    return jsxs('div', {
      className: 'space-y-0.5 text-[0.6875rem]',
      children: [
        jsx('div', { className: 'tabular-nums', children: `${ZAR(item.price)} · 库存 ${item.stock === null || item.stock === undefined ? '—' : NUM(item.stock)}` }),
        jsx('div', { className: 'text-(--ui-text-quaternary)', children: `已转草稿 ${item.draftId || ''}` })
      ]
    })
  }
  return jsxs('div', {
    className: 'space-y-1',
    children: [
      jsxs('div', {
        className: 'flex items-center gap-1',
        children: [
          jsx('span', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '价' }),
          jsx('div', { className: 'w-20', children: jsx(Input, { size: 'sm', value: price, placeholder: '售价', onChange: e => setPrice(e.target.value) }) }),
          jsx('span', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '库存' }),
          jsx('div', { className: 'w-16', children: jsx(Input, { size: 'sm', value: stock, placeholder: '库存', onChange: e => setStock(e.target.value) }) })
        ]
      }),
      jsx(Button, {
        size: 'xs',
        variant: 'outline',
        disabled: busy || !dirty,
        onClick: () => onSave({ price: price === '' ? null : price, stock: stock === '' ? null : stock }),
        children: '保存价格/库存'
      }),
      jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '跟卖不改内容（成本/汇率/重量在右侧明细里改）' })
    ]
  })
}

function StockCells({ stock }) {
  const regions = (stock || {}).regions || []
  if (!regions.length) return jsx('span', { className: 'text-(--ui-text-quaternary)', children: '—' })
  return jsxs('div', {
    className: 'space-y-0.5',
    children: regions.slice(0, 3).map(r =>
      jsxs(
        'div',
        {
          className: 'flex items-center gap-1 text-[0.6875rem]',
          children: [
            jsx('span', { className: 'w-8 text-(--ui-text-quaternary)', children: r.region }),
            jsx('span', { className: cn('tabular-nums', (r.available || 0) > 0 ? 'text-(--ui-accent)' : 'text-red-400'), children: NUM(r.available) }),
            (r.onWay || 0) > 0 ? jsx('span', { className: 'text-(--ui-text-quaternary)', children: `在途 ${NUM(r.onWay)}` }) : null,
            (r.sold30 || 0) > 0 ? jsx('span', { className: 'text-(--ui-text-quaternary)', children: `30天出 ${NUM(r.sold30)}` }) : null
          ]
        },
        r.region
      )
    )
  })
}

const STATUS_TONES = { buyable: 'good', not_buyable: 'warn', disabled_by_seller: 'bad', disabled_by_takealot: 'bad' }

// 佣金率：后端给的是小数（0.11 = 11%），别直接接 '%'
const pctRate = r => (r === null || r === undefined ? '—' : ((Number(r) <= 1 ? Number(r) * 100 : Number(r)).toFixed(1) + '%'))

// 自建 vs 跟卖：没有平台字段，是推断——所以把依据一起显示出来。
function OriginTag({ origin }) {
  if (!origin || !origin.code) return null
  const tone = origin.code === 'own' ? 'good' : origin.code === 'follow' ? 'warn' : 'mute'
  const label = origin.label || (origin.code === 'own' ? '自建' : origin.code === 'follow' ? '跟卖' : '待定')
  const parts = [label]
  if (origin.likely) parts.push(origin.likely === 'own' ? '倾向自建' : '倾向跟卖')
  if (origin.exclusive) parts.push('独占买盒')
  if (origin.competitorCount) parts.push(`${origin.competitorCount} 家竞争`)
  return jsx(Pill, { tone, children: parts.join(' · ') })
}

function KV({ label, children, className }) {
  return jsxs('div', {
    className: cn('flex gap-2 text-[0.8125rem]', className),
    children: [
      jsx('span', { className: 'w-32 shrink-0 text-(--ui-text-quaternary)', children: label }),
      jsx('span', { className: 'min-w-0 flex-1', children })
    ]
  })
}

// ── 内容完整度 → 抓取补全 → AI 文案 → 建上架草稿 ───────────────────────────────
function ContentPipeline({ storeId, stats, onDone }) {
  const [limit, setLimit] = useState('5')
  const [dryRun, setDryRun] = useState(true)
  const [busy, setBusy] = useState(false)
  const [res, setRes] = useState(null)
  const [msg, setMsg] = useState('')
  const missingText = (stats || {}).missingText
  const missingImage = (stats || {}).missingImage
  const run = async () => {
    if (!storeId) {
      host.notify({ kind: 'warn', message: '请先选定店铺（汇总视图下无法确定写到哪家店）' })
      return
    }
    setBusy(true)
    setMsg('')
    try {
      const r = await rest('/products/content-run', { method: 'POST', body: { storeId, limit: Number(limit) || 5, dryRun } })
      setRes(r)
      const sm = (r && r.summary) || {}
      setMsg(
        r && r.ok
          ? dryRun
            ? `试算：${sm.considered} 个候选，其中 ${sm.withCategory} 个有类目、${sm.withImages} 个有图；未写入草稿`
            : `已建档 ${sm.drafted} 个（其中 ${sm.readyAfter} 个已就绪），可在「上架编排」里批量校验/导出`
          : `失败：${(r && r.error) || '未知'}`
      )
      if (r && r.ok && !dryRun && onDone) onDone()
    } catch (e) {
      setMsg(`失败：${msg(e)}`)
    } finally {
      setBusy(false)
    }
  }
  const rows = (res && res.rows) || []
  return jsxs('div', {
    className: 'space-y-2',
    children: [
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-2',
        children: [
          jsx('div', { className: 'text-[0.8125rem]', children: '内容完整度 → 一键建档' }),
          jsx(Pill, { tone: (missingText || missingImage) ? 'warn' : 'good', children: `缺文案 ${NUM(missingText)} · 缺图 ${NUM(missingImage)}` }),
          jsxs('label', { className: 'flex items-center gap-1 text-[0.6875rem] text-(--ui-text-quaternary)', children: [
            jsx('span', { children: '本轮最多' }),
            jsx('input', { value: limit, onChange: e => setLimit(e.target.value), className: 'w-12 rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-0.5 text-[0.6875rem]' })
          ] }),
          jsx(Button, { size: 'xs', variant: dryRun ? 'secondary' : 'outline', onClick: () => setDryRun(v => !v), children: dryRun ? '试算模式：开' : '试算模式：关（写草稿）' }),
          jsx(Button, { size: 'xs', variant: 'outline', disabled: busy || !storeId, onClick: run, children: busy ? '处理中…' : dryRun ? '试算计划与文案' : '执行并建档' })
        ]
      }),
      jsx('div', {
        className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
        children: '流程：抓取公开页补类目/图片 → 生成标题/卖点/包装清单（AI，无 Key 时用模板）→ 写入草稿（同一份 state，上架编排里可直接校验、批量导出）。每条建完立刻跑就绪度自检，缺什么会原话写出。'
      }),
      msg ? jsx('div', { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: msg }) : null,
      rows.length
        ? jsx(Table, {
            head: [Th('SKU'), Th('缺口'), Th('类目（抓取）'), Th('图', { right: true }), Th('卖点字数', { right: true }), Th('草稿'), Th('未就绪原因')],
            children: rows.map(r =>
              jsxs('tr', {
                key: r.sku,
                children: [
                  jsxs(Td, { children: [
                    jsx('div', { className: 'font-mono text-[0.75rem]', children: r.sku }),
                    jsx('div', { className: 'max-w-[16rem] truncate text-[0.6875rem] text-(--ui-text-quaternary)', title: (r.preview || {}).title, children: (r.preview || {}).title || '—' })
                  ] }),
                  jsx(Td, { children: (r.gaps || []).length ? jsx(Pill, { tone: 'warn', children: (r.gaps || []).join('/') }) : jsx(Pill, { tone: 'good', children: '完整' }) }),
                  jsx(Td, { children: jsx('div', { className: 'max-w-[20rem] truncate text-[0.6875rem] text-(--ui-text-tertiary)', title: r.categoryPath, children: r.categoryPath || '—' }) }),
                  jsx(Td, { right: true, mono: true, children: NUM(r.images) }),
                  jsx(Td, { right: true, mono: true, children: NUM(r.featuresLength) }),
                  jsx(Td, { children: r.draftId ? jsx(Pill, { tone: 'good', children: r.draftId }) : jsx('span', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '未写' }) }),
                  jsx(Td, { children: jsx('div', { className: 'max-w-[22rem] text-[0.6875rem] text-amber-400', children: (r.errors || []).join('；') || '—' }) })
                ]
              })
            )
          })
        : null
    ]
  })
}

function Products() {
  const storeId = useValue($storeId)
  const focus = useValue($productsFocus)
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const [content, setContent] = useState('')
  const [stock, setStock] = useState('')
  const [sort, setSort] = useState('title')
  const [open, setOpenRaw] = useState(() => focus || (storage && storage.get('productsOpen', '')) || '')
  const setOpen = next => {
    _detailScrolled = ''   // 重新打开同一个 SKU 时允许再次滚动
    setOpenRaw(next)
    if (storage) {
      storage.set('productsOpen', next || '')
    }
  }
  const [pages, setPages] = useState(1)
  const [picked, setPicked] = useState([])
  const [bulkEdits, setBulkEdits] = useState({})
  const [bulkRes, setBulkRes] = useState(null)
  const [bulkBusy, setBulkBusy] = useState(false)
  const [bulkOpen, setBulkOpen] = useState(false)
  const [edits, setEdits] = useState({})
  const [writeRes, setWriteRes] = useState(null)
  const [busy, setBusy] = useState(false)
  const [offerPrice, setOfferPrice] = useState('')
  const [offerStock, setOfferStock] = useState('0')
  const [offerRes, setOfferRes] = useState(null)
  const [offerBusy, setOfferBusy] = useState(false)
  // 「刷新」必须真的去重拉目录：后端改成"先用快照、后台刷新"之后，普通读请求是秒开但可能是旧数据，
  // 旧实现的 refresh() 只是重发一次读请求 = 静默拿到同一份旧数据，操作员会以为按钮坏了。
  const catRefresh = usePost('/catalog/refresh')
  const [catBusy, setCatBusy] = useState(false)
  const refreshCatalog = () => {
    setCatBusy(true)
    catRefresh.mutate({ storeId: storeId || 'all' }, {
      onSuccess: r => {
        refresh()
        host.notify({ kind: 'info', message: `目录已刷新：${NUM(r.count)} 条，用时 ${r.seconds}s` })
      },
      onError: e => host.notify({ kind: 'error', message: msg(e) }),
      onSettled: () => setCatBusy(false)
    })
  }

  useEffect(() => {
    if (!focus) return
    setOpen(focus)
    $productsFocus.set('')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focus])

  const submitOffer = async dryRun => {
    setOfferBusy(true)
    setOfferRes(null)
    try {
      const body = { storeId, dryRun: !!dryRun }
      if (String(offerPrice).trim()) body.selling_price = Number(offerPrice)
      if (String(offerStock).trim()) body.seller_stock = Number(offerStock)
      const r = await rest(`/products/${encodeURIComponent(open)}/offer`, { method: 'POST', body })
      setOfferRes(r)
      const created = (r && r.created) || {}
      host.notify({
        kind: r && r.ok ? 'info' : 'error',
        message: r && r.ok
          ? dryRun
            ? `试算通过：将 POST /offers（条码 ${((r.request || {}).barcode) || '—'}）`
            : `已创建本店 Offer${created.offerId ? ` #${created.offerId}` : ''}${created.sku ? `（SKU ${created.sku}）` : ''}`
          : `跟卖未完成：${(r && (r.error || (r.errors || [])[0])) || '平台拒绝'}`
      })
      if (r && r.ok && !dryRun) {
        if (list && list.refresh) list.refresh()
        if (detail && detail.refresh) detail.refresh()
      }
    } finally {
      setOfferBusy(false)
    }
  }

  const query =
    `/products?storeId=${encodeURIComponent(storeId || 'all')}&q=${encodeURIComponent(q)}&status=${status}` +
    `&content=${content}&stock=${stock}&sort=${sort}&limit=${pages * 100}`
  const list = useApi(query, `products:${storeId || 'all'}:${q}:${status}:${content}:${stock}:${sort}:${pages}`)
  const detail = useApi(
    `/products/${encodeURIComponent(open)}?storeId=${encodeURIComponent(storeId)}`,
    `product:${open}:${storeId}`,
    { enabled: !!open }
  )
  // 详情渲染：表格内点击 → 内联展开在被点击行正下方（点哪看哪，不会"看起来没反应"）；
  // 从采集箱/选品深链跳进来（focus）→ 顶部面板。两处共用这一份渲染。
  const renderDetail = () =>
jsx(Async, {
            query: detail,
            children: dd => {
              if (dd.found === false) {
                // 多店下最常见的“详情打不开”：该 SKU 属于另一个店铺
                return jsx(Card, {
                  title: `商品详情 · ${open}`,
                  extra: jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => setOpen(''), children: '关闭' }),
                  children: jsx(EmptyState, {
                    title: '该 SKU 不在当前店铺的 Offer 列表',
                    description: `${(dd.hint || '它可能属于另一家店铺——用顶栏/左栏切换店铺后再打开；或先「批量抓取补全」。')}`
                  })
                })
              }
              const it = dd.item || {}
              const det = dd.detail || {}
              const sa = dd.sellAction || {}
              const master = dd.master || it.master || {}
              const origin = dd.origin || it.origin || null
              const editable = dd.editable || {}
              const readStock = dd.readonlyStock || {}
              const caps = editable.capabilities || {}
              const fields = editable.fields || []
              const local = dd.local || it.local || {}
              const group = kind =>
                jsx('div', {
                  className: 'flex gap-2',
                  children: fields
                    .filter(f => (f.group || 'price') === kind)
                    .map(f => {
                      const writable = !!f.writable
                      const value = editValue(f.key, f.value)
                      return jsxs(
                        'label',
                        {
                          className: 'flex-1 space-y-1',
                          children: [
                            jsxs('div', {
                              className: 'flex items-baseline justify-between text-[0.6875rem]',
                              children: [
                                jsx('span', { className: writable ? 'text-(--ui-text-tertiary)' : 'text-(--ui-text-quaternary)', children: f.label }),
                                writable ? null : jsx('span', { className: 'text-(--ui-text-quaternary)', children: '只读' })
                              ]
                            }),
                            jsx(Input, {
                              value: writable ? String(value ?? '') : String(f.value ?? ''),
                              disabled: !writable,
                              placeholder: writable ? '' : '不可写',
                              onChange: e => edit(f.key, e.target.value)
                            }),
                            f.note
                              ? jsx('div', {
                                  className: cn('text-[0.625rem]', f.platformRefusesWhileLeadtimeDisabled ? 'text-amber-400' : 'text-(--ui-text-quaternary)'),
                                  children: f.note
                                })
                              : null,
                            f.platformRefusesWhileLeadtimeDisabled
                              ? jsx('div', { className: 'text-[0.625rem] text-amber-400', children: '注意：该账号 leadtime_enabled=false，平台会拒回库存写入（cant-edit-soh-leadtime-disabled）——需在 Seller Portal 改库存。' })
                              : null
                          ]
                        },
                        f.key
                      )
                    })
                })
              return jsxs('div', {
                className: 'space-y-3',
                children: [
                  jsx(Card, {
                    title: `Takealot 商品详情与全量 Listing 映射 · ${it.sku || open}`,
                    extra: jsxs('div', {
                      className: 'flex items-center gap-2',
                      children: [
                        jsx(OriginTag, { origin }),
                        jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => setOpen(''), children: '关闭' })
                      ]
                    }),
                    children: jsxs('div', {
                      className: 'space-y-3',
                      children: [
                        jsx('div', {
                          className: 'font-mono text-[0.75rem] text-(--ui-text-quaternary)',
                          children: `Offer ID: ${it.offerId || '—'} · TSIN: ${it.tsin || '—'} · SKU: ${it.sku || '—'}`
                        }),
                        jsx('div', {
                          className: 'rounded border border-(--ui-stroke-secondary) p-3',
                          children: jsxs('div', {
                            className: 'space-y-3',
                            children: [
                              jsxs('div', {
                                className: 'flex items-center justify-between',
                                children: [
                                  jsx('div', { className: 'text-[0.8125rem]', children: '1. Listing 映射全部目录内容（公共主数据）' }),
                                  master.publicUrl
                                    ? jsx('button', {
                                        type: 'button',
                                        className: 'text-[0.75rem] text-(--ui-accent)',
                                        onClick: () => {
                                          if (rest.clipboard && rest.clipboard.write) rest.clipboard.write(master.publicUrl)
                                          host.notify({ kind: 'info', message: `前台官方页面：${master.publicUrl}` })
                                        },
                                        children: '在前台官方页面查看 ↗'
                                      })
                                    : null
                                ]
                              }),
                              jsxs('div', {
                                className: 'grid gap-3 lg:grid-cols-[9rem_1fr]',
                                children: [
                                  jsxs('div', {
                                    className: 'space-y-2',
                                    children: [
                                      jsx(Thumb, { src: it.imageUrl, size: 'h-32 w-32' }),
                                      jsx('div', {
                                        className: 'flex flex-wrap gap-1',
                                        children: (det.images || master.images || []).slice(0, 5).map((src, i) => jsx(Thumb, { key: `${src}-${i}`, src, size: 'h-8 w-8' }))
                                      })
                                    ]
                                  }),
                                  jsxs('div', {
                                    className: 'space-y-1.5',
                                    children: [
                                      jsx(KV, { label: '商品标题', children: master.title || it.title }),
                                      jsx(KV, { label: '品牌（Brand）', children: master.brand || 'Generic / Standard' }),
                                      jsx(KV, { label: '挂载类目', children: master.category || master.categoryPath || '—' }),
                                      jsx(KV, {
                                        label: '官方类目佣金',
                                        children: jsx('span', {
                                          className: 'text-amber-400',
                                          children: master.commissionRate || master.commissionRatePercent ? jsxs('span', {
                                          children: [
                                            `${master.commissionRatePercent ? master.commissionRatePercent + '%' : pctRate(master.commissionRate)} (Success Fee)`,
                                            master.commissionAmount ? ` ≈ ${ZAR(master.commissionAmount)}` : '',
                                            master.commissionMinApplied ? ' · 已套用最低费下限（平台实际不设下限，请复核）' : '',
                                            jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: `${master.commissionBasis || '按官方费率表核算（data/takealot_fees_official.json）'}${master.commissionCategory ? ' · 类目 ' + master.commissionCategory : ''}` })
                                          ]
                                        }) : '—'
                                        })
                                      }),
                                      jsx(KV, { label: '官方 TSIN', children: jsx('span', { className: 'font-mono', children: master.tsin || it.tsin || '—' }) }),
                                      jsx(KV, {
                                        label: '国际条形码',
                                        children: jsxs('span', {
                                          className: 'font-mono',
                                          children: [
                                            master.barcode || it.barcode || '—',
                                            master.barcodeAssigned || /^MPTAL/i.test(String(master.barcode || it.barcode || ''))
                                              ? jsx('span', { className: 'ml-1 text-(--ui-text-quaternary)', children: '（Takealot 分配）' })
                                              : null
                                          ]
                                        })
                                      }),
                                      jsx(KV, {
                                        label: '包装尺寸与重量',
                                        children: (master.dimensions && master.dimensions.lengthCm)
                                          ? `${master.dimensions.lengthCm}×${master.dimensions.widthCm}×${master.dimensions.heightCm} cm · ${master.weightKg || '—'} kg`
                                          : '未采集'
                                      }),
                                      jsx(KV, {
                                        label: 'FBT 仓储档位',
                                        children: master.storageTier ? jsxs('span', {
                                          children: [
                                            `${master.storageTier.label || master.storageTier.code}${master.storageTier.monthlyFee ? `（R ${master.storageTier.monthlyFee}/月）` : ''}`,
                                            jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: master.storageTier.basis || '按尺寸/体积重估算（API 无仓储档位字段）' })
                                          ]
                                        }) : '—'
                                      }),
                                      jsx(KV, { label: '评分 / 评论', children: master.rating ? `${master.rating}/5 · ${NUM(master.reviews)} 条` : '未采集' }),
                                      jsx(KV, { label: 'Listing 质量分', children: String(master.listingQuality ?? it.listingQuality ?? '—') })
                                    ]
                                  })
                                ]
                              })
                            ]
                          })
                        }),
                        jsx('div', {
                          className: 'rounded border border-(--ui-stroke-secondary) p-3',
                          children: jsxs('div', {
                            className: 'space-y-3',
                            children: [
                              jsx('div', { className: 'text-[0.8125rem]', children: '2. 卖家可编辑参数与库存写入表' }),
                              jsx('div', {
                                className: 'text-[0.75rem] text-(--ui-text-quaternary)',
                                children: '可写：售价、划线原价 RRP、自发货库存、备货发货时效。平台托管仓库存（JHB/CPT/DBN）在本 API 只读。'
                              }),
                              jsx('div', {
                                className: 'flex flex-wrap gap-3',
                                children: fields.filter(f => f.kind === 'select' || f.key === 'status').map(f =>
                                  jsxs('label', {
                                    className: 'w-48 space-y-1',
                                    children: [
                                      jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: f.writable ? f.label : `${f.label}（只读）` }),
                                      jsx('select', {
                                        value: String(f.value ?? ''),
                                        disabled: !f.writable,
                                        onChange: e => edit(f.key, e.target.value),
                                        className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]',
                                        children: (f.options || [{ value: String(f.value ?? ''), label: String(f.valueLabel || f.value || '—') }]).map(o =>
                                          jsx('option', { key: String(o.value), value: String(o.value), children: o.label })
                                        )
                                      }),
                                      f.note ? jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: f.note }) : null
                                    ]
                                  }, f.key)
                                )
                              }),
                              jsxs('div', {
                                className: 'grid gap-3 md:grid-cols-3',
                                children: [
                                  group('price'),
                                  group('stock'),
                                  group('logistics')
                                ]
                              }),
                              (readStock.takealot || []).length
                                ? jsxs('div', {
                                    className: 'rounded border border-(--ui-stroke-secondary) p-2',
                                    children: [
                                      jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '平台托管仓库存（只读）' }),
                                      jsx(Table, {
                                        head: [
                                          jsx(Th, { key: 'r', children: '区域' }),
                                          jsx(Th, { key: 'a', right: true, children: '可用' }),
                                          jsx(Th, { key: 'i', right: true, children: '入库中' }),
                                          jsx(Th, { key: 'o', right: true, children: '在途' }),
                                          jsx(Th, { key: 's', right: true, children: '30天出库' }),
                                          jsx(Th, { key: 'c', right: true, children: '覆盖' })
                                        ],
                                        children: (readStock.takealot || []).map(r =>
                                          jsxs('tr', {
                                            children: [
                                              jsx(Td, { children: `${r.region}${r.regionId ? ` (#${r.regionId})` : ''}` }),
                                              jsx(Td, { right: true, className: 'tabular-nums', children: NUM(r.available) }),
                                              jsx(Td, { right: true, className: 'tabular-nums', children: NUM(r.receiving) }),
                                              jsx(Td, { right: true, className: 'tabular-nums', children: NUM(r.onWay) }),
                                              jsx(Td, { right: true, className: 'tabular-nums', children: NUM(r.sold30) }),
                                              jsx(Td, { right: true, className: 'tabular-nums', children: `${r.coverDays || 0} 天` })
                                            ]
                                          }, r.region)
                                        )
                                      }),
                                      readStock.note ? jsx('div', { className: 'mt-1 text-[0.625rem] text-(--ui-text-quaternary)', children: readStock.note }) : null
                                    ]
                                  })
                                : null,
                              jsxs('div', {
                                className: 'flex flex-wrap items-center gap-2',
                                children: [
                                  jsx(Button, { size: 'sm', disabled: busy || !storeId, onClick: () => submitWrite(false), title: storeId ? '' : '汇总视图下不可写入：请先选定具体店铺', children: busy ? '同步中…' : '保存修改并同步到 Takealot' }),
                                  jsx(Button, { size: 'sm', variant: 'outline', disabled: busy, onClick: () => submitWrite(true), children: '试算（不写入）' }),
                                  caps.leadtimeEnabled === false ? jsx(Pill, { tone: 'warn', children: '该账号未开通 API 备货时效写入' }) : null,
                                  caps.disableListingEnabled === false ? jsx(Pill, { tone: 'warn', children: '该账号未开通 API 上下架（请在 Seller Portal 操作）' }) : null
                                ]
                              }),
                              writeRes
                                ? jsx('div', {
                                    className: cn('rounded border p-2 text-[0.75rem]', writeRes.ok ? 'border-(--ui-accent)' : 'border-red-400/60'),
                                    children: jsxs('div', {
                                      className: 'space-y-1',
                                      children: [
                                        jsxs('div', {
                                          children: [
                                            writeRes.dryRun ? '试算结果：' : '写入结果：',
                                            writeRes.ok ? '成功' : `失败（${writeRes.error || '未知'}）`,
                                            writeRes.apiStatus ? ` · API ${writeRes.apiStatus}` : ''
                                          ]
                                        }),
                                        jsx('div', {
                                          className: 'font-mono text-[0.6875rem] text-(--ui-text-tertiary)',
                                          children: `请求体 ${JSON.stringify(writeRes.request || {})}`
                                        }),
                                        (writeRes.applied || []).length
                                          ? jsx('div', { children: (writeRes.applied || []).map(a => `${a.field}：${a.from} → ${a.to}`).join('；') })
                                          : null,
                                        (writeRes.warnings || []).map((w, i) => jsx('div', { key: i, className: 'text-amber-400', children: w })),
                                        writeRes.offer
                                          ? jsx('div', {
                                              className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                                              children: `回读：售价 ${ZAR(writeRes.offer.selling_price)} · RRP ${ZAR(writeRes.offer.rrp)} · 自发货库存 ${NUM(((writeRes.offer.seller_warehouse_stock || [])[0] || {}).quantity_available)} · 状态 ${writeRes.offer.status}`
                                            })
                                          : null
                                      ]
                                    })
                                  })
                                : null,
                              jsx('div', {
                                className: 'text-[0.625rem] text-(--ui-text-quaternary)',
                                children: '修改后的价格与库存将通过 Takealot Seller API 立即生效；上下架与平台仓库存需在 Seller Portal 操作。'
                              })
                            ]
                          })
                        }),
                        jsxs('div', {
                          className: 'space-y-2 rounded border border-(--ui-stroke-secondary) p-2',
                          children: [
                            jsxs('div', {
                              className: 'flex flex-wrap items-center justify-between gap-2',
                              children: [
                                jsx('div', { className: 'text-[0.8125rem]', children: '3. 跟卖落点（在 Takealot 上创建本店 Offer）' }),
                                sa.canCreateOffer
                                  ? jsx(Pill, { tone: 'good', children: '可执行' })
                                  : jsx(Pill, { tone: 'warn', children: '不可执行' })
                              ]
                            }),
                            jsx('div', {
                              className: 'text-[0.75rem] text-(--ui-text-quaternary)',
                              children: sa.reason || sa.hint || '后端未给出判据'
                            }),
                            sa.defaults
                              ? jsx('div', {
                                  className: 'font-mono text-[0.6875rem] text-(--ui-text-tertiary)',
                                  children: `条码 ${sa.defaults.barcode || '—'} · TSIN ${sa.defaults.tsin || '—'} · 建议售价 ${ZAR(sa.defaults.suggestedPrice)} · 仓库 ${sa.defaults.warehouseId ?? '—'}`
                                })
                              : null,
                            jsxs('div', {
                              className: 'flex flex-wrap items-end gap-3',
                              children: [
                                jsxs('label', {
                                  className: 'w-32 space-y-1',
                                  children: [
                                    jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '跟卖售价 (ZAR)' }),
                                    jsx('input', {
                                      value: offerPrice,
                                      placeholder: String(sa.defaults ? (sa.defaults.suggestedPrice ?? '') : ''),
                                      onChange: e => setOfferPrice(e.target.value),
                                      className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]'
                                    })
                                  ]
                                }),
                                jsxs('label', {
                                  className: 'w-28 space-y-1',
                                  children: [
                                    jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '自发货库存' }),
                                    jsx('input', {
                                      value: offerStock,
                                      onChange: e => setOfferStock(e.target.value),
                                      className: 'w-full rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]'
                                    })
                                  ]
                                }),
                                jsx(Button, {
                                  size: 'xs',
                                  variant: 'outline',
                                  disabled: offerBusy || !sa.canCreateOffer || !storeId,
                                  onClick: () => submitOffer(true),
                                  children: '试算（不创建）'
                                }),
                                jsx(Button, {
                                  size: 'xs',
                                  disabled: offerBusy || !sa.canCreateOffer || !storeId,
                                  onClick: () => submitOffer(false),
                                  children: offerBusy ? '提交中…' : '执行跟卖'
                                })
                              ]
                            }),
                            offerRes
                              ? jsxs('div', {
                                  className: cn('space-y-1 rounded border p-2 text-[0.75rem]', offerRes.ok ? 'border-(--ui-accent)' : 'border-red-400/60'),
                                  children: [
                                    jsxs('div', {
                                      children: [
                                        offerRes.dryRun ? '试算结果：' : '创建结果：',
                                        offerRes.ok ? '成功' : '未完成',
                                        offerRes.apiStatus ? ` · API ${offerRes.apiStatus}` : ' · 未发出请求'
                                      ]
                                    }),
                                    jsx('div', {
                                      className: 'font-mono text-[0.6875rem] text-(--ui-text-tertiary)',
                                      children: `请求体 ${JSON.stringify(offerRes.request || {})}`
                                    }),
                                    offerRes.resolution
                                      ? jsx('div', {
                                          className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                                          children: `解析：条码来源 ${offerRes.resolution.barcodeSource || '—'} · TSIN ${offerRes.resolution.tsin || '—'}（${offerRes.resolution.tsinSource || '—'}）`
                                        })
                                      : null,
                                    (offerRes.created || {}).offerId
                                      ? jsx('div', { children: `已创建：Offer #${offerRes.created.offerId} · SKU ${offerRes.created.sku}` })
                                      : null,
                                    (offerRes.errors || []).map((e, i) => jsx('div', { key: i, className: 'text-red-400', children: String(e) })),
                                    (offerRes.warnings || []).map((w, i) => jsx('div', { key: i, className: 'text-amber-400', children: w }))
                                  ]
                                })
                              : null,
                            jsx('div', {
                              className: 'text-[0.625rem] text-(--ui-text-quaternary)',
                              children: '跟卖 = 用同一目录商品（条码/TSIN）在本店创建 Offer，价格与库存由你定；平台拒绝时会把原话显示在这里（例如 cant-create-duplicate-gtin 表示该条码本店已在售）。'
                            })
                          ]
                        }),
                        jsx('div', {
                          className: 'grid gap-3 md:grid-cols-2',
                          children: [
                            jsx('div', {
                              className: 'rounded border border-(--ui-stroke-secondary) p-2',
                              children: jsxs('div', {
                                className: 'space-y-1',
                                children: [
                                  jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '商品全文（爬取）' }),
                                  jsx('div', { className: 'max-h-48 overflow-auto whitespace-pre-wrap text-[0.75rem] text-(--ui-text-tertiary)', children: det.description || '（尚未采集到描述：点列表里的「补全」）' })
                                ]
                              })
                            }),
                            jsx('div', {
                              className: 'rounded border border-(--ui-stroke-secondary) p-2',
                              children: jsxs('div', {
                                className: 'space-y-1',
                                children: [
                                  jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '判定依据（自建 / 跟卖）' }),
                                  origin
                                    ? jsxs('div', {
                                        className: 'space-y-0.5 text-[0.75rem]',
                                        children: [
                                          jsx('div', { children: origin.reason || '—' }),
                                          (origin.signals || []).map((s, i) =>
                                            jsx('div', { key: i, className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `· ${s.source}：${s.detail}` })
                                          )
                                        ]
                                      })
                                    : jsx('div', { className: 'text-[0.75rem] text-(--ui-text-quaternary)', children: '未判定（缺公开卡片数据）' })
                                ]
                              })
                            })
                          ]
                        }),
                        jsxs('div', {
                          className: 'flex flex-wrap items-center gap-2 text-[0.6875rem] text-(--ui-text-quaternary)',
                          children: [
                            local.draftId ? jsx(Pill, { tone: 'good', children: `已有草稿 ${local.draftId}` }) : jsx(Pill, { tone: 'mute', children: '无草稿' }),
                            local.inCollection ? jsx(Pill, { tone: 'mute', children: '采集箱中' }) : null,
                            (local.complianceHits || []).length ? jsx(Pill, { tone: 'bad', children: `合规命中 ${local.complianceHits.length}` }) : jsx(Pill, { tone: 'good', children: '合规无命中' }),
                            local.lastPriceChange ? jsx(Pill, { tone: 'mute', children: `最近调价 ${local.lastPriceChange}` }) : null,
                            jsx(Button, {
                              size: 'xs',
                              variant: 'outline',
                              onClick: () => {
                                $listingPrefill.set(it.plid || it.tsin || '')
                                $module.set('listings')
                                host.notify({ kind: 'info', message: '已按该商品预填「上架编排」' })
                              },
                              children: '按此商品建档（预填装载表）'
                            }),
                            jsx('span', { children: `数据来源：${(det.crawl || {}).transport || '缓存'} · ${(det.crawl || {}).fetchedAt || '未采集'}` })
                          ]
                        })
                      ]
                    })
                  })
                ]
              })
            }
          })

  const enrich = usePost('/products/enrich')
  const fail = e => host.notify({ kind: 'error', message: msg(e) })

  const runEnrich = (payload, label) =>
    enrich.mutate(payload, {
      onSuccess: r => {
        refresh()
        host.notify({ kind: r.failed ? 'error' : 'info', message: `${label}：成功 ${r.enriched}，失败 ${r.failed}` })
      },
      onError: fail
    })

  const togglePick = sku => setPicked(p => (p.includes(sku) ? p.filter(x => x !== sku) : p.concat(sku)))
  const bulkSet = (sku, key, value) => setBulkEdits(prev => ({ ...prev, [sku]: { ...(prev[sku] || {}), [key]: value } }))
  const bulkRows = () =>
    picked.map(sku => {
      const bag = bulkEdits[sku] || {}
      const row = { sku }
      if (String(bag.selling_price || '').trim()) row.selling_price = bag.selling_price
      if (String(bag.seller_stock || '').trim()) row.seller_stock = bag.seller_stock
      if (String(bag.rrp || '').trim()) row.rrp = bag.rrp
      return row
    })
  const submitBulk = async dryRun => {
    const rows = bulkRows().filter(r => Object.keys(r).length > 1)
    if (!rows.length) {
      host.notify({ kind: 'warn', message: '先给选中的商品填新价或新库存' })
      return
    }
    setBulkBusy(true)
    setBulkRes(null)
    try {
      const r = await rest('/products/batch-write', { method: 'POST', body: { rows, dryRun: !!dryRun, storeId } })
      setBulkRes(r)
      host.notify({
        kind: r && r.ok ? 'info' : 'error',
        message: dryRun
          ? `试算：${r.changed || rows.length} 行可写，${(r.results || []).filter(x => !x.ok).length} 行有问题`
          : `已同步 ${r.appliedCount || 0} 行，失败 ${r.failedCount || 0} 行`
      })
      if (!dryRun) {
        setBulkEdits({})
        setPicked([])
        refresh()
      }
    } catch (e) {
      fail(e)
    } finally {
      setBulkBusy(false)
    }
  }

  const edit = (key, value) => setEdits(prev => ({ ...prev, [open]: { ...(prev[open] || {}), [key]: value } }))
  const editValue = (key, fallback) => {
    const bag = edits[open] || {}
    return key in bag ? bag[key] : fallback
  }

  const submitWrite = async dryRun => {
    const changed = {}
    for (const f of ((detail.data || {}).editable || {}).fields || []) {
      if (!f.writable) continue
      const bag = edits[open] || {}
      if (f.key in bag && String(bag[f.key]) !== String(f.value)) changed[f.key] = bag[f.key]
    }
    if (!Object.keys(changed).length) {
      host.notify({ kind: 'warn', message: '没有改动：先改价格 / 库存 / 时效' })
      return
    }
    setBusy(true)
    setWriteRes(null)
    try {
      const r = await rest(`/products/${encodeURIComponent(open)}`, {
        method: 'PATCH',
        body: { ...changed, dryRun: !!dryRun, storeId }
      })
      setWriteRes(r)
      const applied = (r && r.applied) || []
      host.notify({
        kind: r && r.ok ? 'info' : 'error',
        message:
          r && r.ok
            ? dryRun
              ? `试算通过：将写入 ${applied.map(a => `${a.field} ${a.from}→${a.to}`).join('，') || Object.keys(changed).join('，')}`
              : `已同步到 Takealot：${applied.map(a => `${a.field} ${a.from}→${a.to}`).join('，')}`
            : (r && r.error) || '写入失败'
      })
      if (!dryRun) {
        setEdits(prev => ({ ...prev, [open]: {} }))
        refresh()
      }
    } catch (e) {
      fail(e)
    } finally {
      setBusy(false)
    }
  }

  return jsxs('div', {
    className: 'space-y-3',
    children: [
      jsx(Async, {
        query: list,
        children: d => {
          const stats = d.stats || {}
          return jsxs('div', {
            className: 'space-y-3',
            children: [
              jsx(Grid, {
                children: [
                  jsx(Metric, { label: '全店商品', value: NUM(d.total), sub: `当前筛选 ${NUM(d.filtered)} 条${d.catalog && d.catalog.stale ? ` · 目录数据 ${NUM(Math.round(d.catalog.ageSeconds || 0))} 秒前（后台刷新中，页面不用等）` : ''}` }),
                  jsx(Metric, {
                    label: '自建 / 跟卖 / 待定',
                    value: `${NUM((stats.byOrigin || {}).own)} / ${NUM((stats.byOrigin || {}).follow)} / ${NUM((stats.byOrigin || {}).unknown)}`,
                    sub: stats.byOriginSignal ? `判据：${Object.keys(stats.byOriginSignal).slice(0, 2).join('、')}` : '公开页无卡片时为待定'
                  }),
                  jsx(Metric, { label: '可售 / 不可售', value: `${NUM(stats.sellable)} / ${NUM(stats.notSellable)}`, sub: `平台下架 ${NUM(stats.disabled)}` }),
                  jsx(Metric, { label: '零库存 SKU', value: NUM(stats.zeroStock), sub: '需补货或下架', tone: (stats.zeroStock || 0) > 0 ? 'warn' : null }),
                  jsx(Metric, { label: '30 天出库', value: NUM(stats.sold30), sub: '全店合计' }),
                  jsx(Metric, { label: '缺主图 / 缺条码', value: `${NUM(stats.missingImage)} / ${NUM(stats.missingBarcode)}`, sub: '上架前需补' }),
                  jsx(Metric, { label: '缺文案数', value: NUM(stats.missingText), sub: '标题或描述为空' })
                ]
              }),
              jsx(Card, {
                title: '内容闭环',
                children: jsx(ContentPipeline, {
                  storeId,
                  stats: (list.data || {}).stats || {},
                  onDone: () => {
                    if (list.refetch) list.refetch()
                  }
                })
              }),
              bulkOpen && picked.length
                ? jsx(Card, {
                    title: `批量改价 / 改库存 · 已选 ${picked.length} 个`,
                    extra: jsxs('div', {
                      className: 'flex flex-wrap gap-2',
                      children: [
                        jsx(Button, { size: 'xs', variant: 'outline', disabled: bulkBusy || !storeId, onClick: () => submitBulk(true), title: storeId ? '' : '汇总视图下不可写入：请先选定具体店铺', children: '试算（不写入）' }),
                        jsx(Button, { size: 'xs', disabled: bulkBusy || !storeId, onClick: () => submitBulk(false), title: storeId ? '' : '汇总视图下不可写入：请先选定具体店铺', children: bulkBusy ? '同步中…' : '执行并同步到 Takealot' }),
                        jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => setBulkOpen(false), children: '收起' })
                      ]
                    }),
                    children: jsxs('div', {
                      className: 'space-y-2',
                      children: [
                        jsx('div', {
                          className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                          children: '只填要改的字段，留空的行不提交；价格 ≥ R1、库存 ≥ 0。平台拒绝的写入（如账号未开通 leadtime）会在结果里原样回显，不会假装成功。'
                        }),
                        jsx(Table, {
                          head: [
                            jsx(Th, { key: 'p', children: '商品' }),
                            jsx(Th, { key: 'now', right: true, children: '当前价 / 库存' }),
                            jsx(Th, { key: 'np', children: '新价 ZAR' }),
                            jsx(Th, { key: 'ns', children: '新库存（自发货）' }),
                            jsx(Th, { key: 'nr', children: 'RRP（可选）' }),
                            jsx(Th, { key: 'r', children: '结果' })
                          ],
                          children: picked.map(sku => {
                            const it = (d.items || []).find(x => x.sku === sku) || {}
                            const bag = bulkEdits[sku] || {}
                            const res = ((bulkRes || {}).results || []).find(r => String(r.sku) === String(sku))
                            const stockNow = ((it.stock || {}).sellerAvailable !== undefined)
                              ? (it.stock || {}).sellerAvailable
                              : ((((it.stock || {}).regions || [])[0] || {}).available)
                            return jsxs(
                              'tr',
                              {
                                children: [
                                  jsx(Td, {
                                    className: 'max-w-[18rem]',
                                    children: jsxs('div', {
                                      children: [
                                        it.storeName ? jsx(Pill, { tone: 'mute', children: it.storeName }) : null,
                                        jsx('div', { className: 'truncate', title: it.title, children: it.title || sku }),
                                        jsx('div', { className: 'font-mono text-[0.6875rem] text-(--ui-text-quaternary)', children: sku })
                                      ]
                                    })
                                  }),
                                  jsx(Td, { right: true, className: 'tabular-nums text-[0.75rem]', children: `${ZAR(it.price)} / ${NUM(stockNow)}` }),
                                  jsx(Td, {
                                    children: jsx('div', { className: 'w-24', children: jsx(Input, { value: String(bag.selling_price || ''), placeholder: String(it.price || ''), onChange: e => bulkSet(sku, 'selling_price', e.target.value) }) })
                                  }),
                                  jsx(Td, {
                                    children: jsx('div', { className: 'w-24', children: jsx(Input, { value: String(bag.seller_stock || ''), placeholder: String(stockNow === undefined ? '' : stockNow), onChange: e => bulkSet(sku, 'seller_stock', e.target.value) }) })
                                  }),
                                  jsx(Td, {
                                    children: jsx('div', { className: 'w-24', children: jsx(Input, { value: String(bag.rrp || ''), placeholder: String(it.rrp || ''), onChange: e => bulkSet(sku, 'rrp', e.target.value) }) })
                                  }),
                                  jsx(Td, {
                                    className: 'text-[0.6875rem]',
                                    children: res
                                      ? res.ok
                                        ? jsx('span', {
                                            className: 'text-(--ui-accent)',
                                            children: (res.applied || []).map(a => `${a.field} ${a.from}→${a.to}`).join('，') || `API ${res.apiStatus || ''}`
                                          })
                                        : jsx('span', {
                                            className: 'text-red-400',
                                            title: JSON.stringify(res.errors || res.error || []),
                                            children: (res.errors || []).join('；') || res.error || `API ${res.apiStatus || ''}`
                                          })
                                      : Object.keys(bag).length
                                        ? jsx('span', { className: 'text-(--ui-text-quaternary)', children: '待试算' })
                                        : jsx('span', { className: 'text-(--ui-text-quaternary)', children: '未填写' })
                                  })
                                ]
                              },
                              sku
                            )
                          })
                        }),
                        bulkRes
                          ? jsxs('div', {
                              className: cn('rounded border px-2 py-1 text-[0.75rem]', bulkRes.ok ? 'border-(--ui-accent)' : 'border-red-400/60'),
                              children: [
                                jsx('div', {
                                  children: `${bulkRes.dryRun ? '试算' : '执行'}：可写 ${bulkRes.changed || 0} 行 · 写入成功 ${bulkRes.appliedCount || 0} · 失败 ${bulkRes.failedCount || 0}${bulkRes.hint ? ' · ' + bulkRes.hint : ''}`
                                }),
                                bulkRes.error ? jsx('div', { className: 'text-red-400', children: bulkRes.error }) : null
                              ]
                            })
                          : null
                      ]
                    })
                  })
                : null,
      (focus && open === focus) || (open && !(d.items || []).some(x => String(x.sku) === String(open)))
        ? jsxs('div', {
            className: 'space-y-2',
            children: [
              focus && open === focus
                ? null
                : jsx('div', {
                    className: 'text-[0.6875rem] text-amber-400',
                    children: '该 SKU 不在当前列表里（被筛选或分页隐藏）：详情显示在这里；在列表里搜索它可以看到行内展开。'
                  }),
              renderDetail()
            ]
          })
        : null,
              d.scopedFromActive && d.requestedStoreId
                ? jsx('div', {
                    className: 'rounded border border-amber-400/60 bg-amber-400/10 p-2 text-[0.75rem]',
                    children: `界面请求的店铺 ${d.requestedStoreId} 不存在（可能已删除）：当前显示的是「${d.storeName || d.storeId}」的数据。请用顶栏或左栏重新选择店铺。`
                  })
                : null,
              d.aggregate
                ? jsx('div', {
                    className: 'rounded border border-(--ui-stroke-secondary) bg-(--chrome-action-hover) p-2 text-[0.75rem]',
                    children: `汇总视图 · ${d.scopeNote || '本地记录跨店合并'}　·　写入类操作已停用：请先在顶栏选定一个具体店铺（汇总时无法确定要写到哪家店）。`
                  })
                : null,
              jsx(Card, {
                title: `全店商品映射 · 已显示 ${(d.items || []).length} / 全店 ${NUM(d.total)}（Seller API 实时 · 库存含分仓）`,
                extra: jsxs('div', {
                  className: 'flex flex-wrap items-end gap-2',
                  children: [
                    jsx('div', { className: 'w-52', children: jsx(Input, { size: 'sm', value: q, placeholder: '搜索 标题 / SKU / TSIN / 条码', onChange: e => setQ(e.target.value) }) }),
                    jsx('select', {
                      value: status,
                      onChange: e => setStatus(e.target.value),
                      className: 'rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]',
                      children: [
                        jsx('option', { value: '', children: '全部状态' }),
                        jsx('option', { value: 'buyable', children: '可售' }),
                        jsx('option', { value: 'not_buyable', children: '不可售' }),
                        jsx('option', { value: 'disabled_by_seller', children: '卖家下架' }),
                        jsx('option', { value: 'disabled_by_takealot', children: '平台下架' })
                      ]
                    }),
                    jsx('select', {
                      value: content,
                      onChange: e => setContent(e.target.value),
                      className: 'rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]',
                      children: [
                        jsx('option', { value: '', children: '内容完整度' }),
                        jsx('option', { value: 'missing', children: '有缺项' }),
                        jsx('option', { value: 'missing-image', children: '缺主图' }),
                        jsx('option', { value: 'missing-barcode', children: '缺条码' }),
                        jsx('option', { value: 'missing-text', children: '缺文案' }),
                        jsx('option', { value: 'complete', children: '完整' })
                      ]
                    }),
                    jsx('select', {
                      value: stock,
                      onChange: e => setStock(e.target.value),
                      className: 'rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]',
                      children: [
                        jsx('option', { value: '', children: '全部库存' }),
                        jsx('option', { value: 'zero', children: '零库存' }),
                        jsx('option', { value: 'in', children: '有库存' })
                      ]
                    }),
                    jsx('select', {
                      value: sort,
                      onChange: e => setSort(e.target.value),
                      className: 'rounded border border-(--ui-stroke-secondary) bg-transparent px-1 py-1 text-[0.75rem]',
                      children: [
                        jsx('option', { value: 'title', children: '按标题' }),
                        jsx('option', { value: 'price', children: '按售价' }),
                        jsx('option', { value: 'stock', children: '按库存' }),
                        jsx('option', { value: 'updated', children: '按更新时间' })
                      ]
                    }),
                    jsx(Button, {
                      size: 'xs', variant: 'ghost', disabled: catBusy,
                      onClick: refreshCatalog,
                      children: catBusy ? '刷新中（全店目录，约 30~55 秒）…' : (d.catalog && d.catalog.stale ? `刷新目录（数据 ${NUM(Math.round(d.catalog.ageSeconds || 0))} 秒前）` : '刷新目录')
                    }),
                    d.hasMore || (d.items || []).length >= pages * 100
                      ? jsx(Button, { size: 'xs', variant: 'outline', onClick: () => setPages(p => p + 1), children: `加载更多（+100）` })
                      : null,
                    pages > 1
                      ? jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => setPages(1), children: '只看前 100' })
                      : null,
                    jsx(Button, {
                      size: 'xs',
                      variant: 'outline',
                      disabled: enrich.isPending,
                      onClick: () => runEnrich({ all: true, limit: 20 }, '批量补全前 20 个'),
                      children: enrich.isPending ? '补全中…' : '批量抓取补全'
                    }),
                    jsx(Button, {
                      size: 'xs',
                      variant: 'outline',
                      disabled: !picked.length,
                      onClick: () => {
                        setBulkRes(null)
                        setBulkOpen(true)
                      },
                      children: `批量改价 / 改库存（已选 ${picked.length}）`
                    }),
                    picked.length ? jsx(Button, { size: 'xs', variant: 'ghost', onClick: () => { setPicked([]); setBulkEdits({}); setBulkRes(null) }, children: '清空选择' }) : null
                  ]
                }),
                children: (d.items || []).length
                  ? jsx(Table, {
                      head: [
                        jsx(Th, { key: 'pick', children: '' }),
                        jsx(Th, { key: 'img', children: '' }),
                        jsx(Th, { key: 't', children: '商品 / 来源' }),
                        jsx(Th, { key: 'p', right: true, children: '售价 / 佣金' }),
                        jsx(Th, { key: 's', children: '状态 / BuyBox' }),
                        jsx(Th, { key: 'k', children: '库存（分仓）' }),
                        jsx(Th, { key: 'd', right: true, children: '30天' }),
                        jsx(Th, { key: 'r', children: '数据' }),
                        jsx(Th, { key: 'q', children: '完整度' }),
                        jsx(Th, { key: 'a', children: '操作' })
                      ],
                      children: (d.items || []).map(it => {
                        const en = it.enrichment || {}
                        const st = it.stock || {}
                        const ct = it.content || {}
                        const master = it.master || {}
                        const missing = ct.missing || []
                        const dims = it.dimensions || {}
                        return [
                          jsxs(
                          'tr',
                          {
                            className: open === it.sku ? 'tkl-row-open bg-(--chrome-action-hover)' : undefined,
                            children: [
                              jsx(Td, { children: jsx('input', { type: 'checkbox', checked: picked.includes(it.sku), onChange: () => togglePick(it.sku) }) }),
                              jsx(Td, { children: jsx(Thumb, { src: it.imageUrl }) }),
                              jsx(Td, {
                                className: 'max-w-[22rem]',
                                children: jsxs('div', {
                                  className: 'space-y-1',
                                  children: [
                                    jsxs('div', {
                                      className: 'flex flex-wrap items-center gap-1',
                                      children: [
                                        jsx(OriginTag, { origin: it.origin }),
                                        it.origin && it.origin.buyboxHeld ? jsx(Pill, { tone: 'good', children: '已得 Buy Box' }) : null
                                      ]
                                    }),
                                    jsx('div', { className: 'truncate', title: it.title, children: it.title || '（无标题）' }),
                                    jsx('div', { className: 'font-mono text-[0.6875rem] text-(--ui-text-quaternary)', children: it.sku }),
                                    jsx('div', {
                                      className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                                      children: `${it.tsin || '无 TSIN'}${it.barcode ? ` · ${it.barcode}` : ''}`
                                    }),
                                    jsxs('div', {
                                      className: 'text-[0.6875rem] text-(--ui-text-quaternary)',
                                      children: [
                                        dims.lengthCm ? `${dims.lengthCm}×${dims.widthCm}×${dims.heightCm}cm` : '尺寸未采',
                                        it.weightKg ? ` (${it.weightKg}kg)` : '',
                                        en.categoryPath ? ` · ${en.categoryPath.split(' > ').slice(-1)[0]}` : ''
                                      ]
                                    })
                                  ]
                                })
                              }),
                              jsx(Td, {
                                right: true,
                                children: jsxs('div', {
                                  children: [
                                    ZAR(it.price),
                                    jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: master.commissionRate ? `佣金 ${pctRate(master.commissionRate)}` : (it.rrp ? `RRP ${ZAR(it.rrp)}` : '—') }),
                                    it.rrp ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `RRP ${ZAR(it.rrp)}` }) : null
                                  ]
                                })
                              }),
                              jsx(Td, {
                                children: jsxs('div', {
                                  className: 'space-y-0.5',
                                  children: [
                                    jsx(Pill, { tone: STATUS_TONES[it.status] || 'mute', children: it.statusLabel || it.status }),
                                    it.origin && it.origin.competitorCount
                                      ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `${it.origin.competitorCount} 家竞争` })
                                      : null,
                                    it.vacation ? jsx(Pill, { tone: 'warn', children: '休假中' }) : null
                                  ]
                                })
                              }),
                              jsx(Td, { children: jsx(StockCells, { stock: st }) }),
                              jsx(Td, { right: true, className: 'tabular-nums', children: NUM(st.totalSold30) }),
                              jsx(Td, {
                                className: 'text-[0.75rem]',
                                children: en.rating ? jsxs('div', { children: [`${en.rating}/5`, jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `${NUM(en.reviews)} 评论 · 跟卖 ${NUM(en.sellerCount)}` })] }) : jsx('span', { className: 'text-(--ui-text-quaternary)', children: '未采集' })
                              }),
                              jsx(Td, {
                                children: missing.length
                                  ? jsx('div', { className: 'flex flex-wrap gap-1', children: missing.slice(0, 2).map(m => jsx(Pill, { key: m, tone: 'warn', children: m })) })
                                  : jsx(Pill, { tone: 'good', children: `完整 ${ct.score || 100}` })
                              }),
                              jsx(Td, {
                                children: jsxs('div', {
                                  className: 'flex flex-wrap gap-1',
                                  children: [
                                    jsx(Button, { size: 'xs', variant: 'outline', onClick: () => setOpen(open === it.sku ? '' : it.sku), children: open === it.sku ? '收起' : '商品详情' }),
                                    jsx(Button, { size: 'xs', variant: 'ghost', disabled: enrich.isPending, onClick: () => runEnrich({ skus: [it.sku], force: true }, `补全 ${it.sku}`), children: '补全' }),
                                    jsx(Button, {
                                      size: 'xs',
                                      variant: 'ghost',
                                      onClick: () => {
                                        $analyticsTarget.set(it.tsin || it.plid || '')
                                        $module.set('collection')
                                        host.notify({ kind: 'info', message: '已带到采集箱并展开分析' })
                                      },
                                      children: '分析'
                                    })
                                  ]
                                })
                              })
                            ]
                          },
                          it.sku
                        ),
                          open === it.sku && !(focus && open === focus)
                            ? jsx('tr', {
                                key: `d-${it.sku}`,
                                className: 'tkl-inline-detail',
                                children: jsx('td', {
                                  colSpan: 10,
                                  className: 'tkl-detail-cell p-0',
                                  ref: node => scrollDetailIntoView(node, it.sku),
                                  children: renderDetail()
                                })
                              })
                            : null
                        ]
                      })
                    })
                  : jsx(EmptyState, { title: '没有匹配的商品', description: '换个筛选条件，或先「批量抓取补全」' })
              })
            ]
          })
        }
      }),
    ]
  })
}
const MODULES = [
  { id: 'overview', label: '经营总览', codicon: 'dashboard' },
  { id: 'products', label: '商品管理', codicon: 'package' },
  { id: 'orders', label: '订单与净利', codicon: 'list-unordered' },
  { id: 'financial', label: '财务与对账', codicon: 'credit-card' },
  { id: 'collection', label: '采集箱', codicon: 'inbox' },
  // 「选品与销量分析」已并入采集箱（行内展开分析），不再单独占一个模块。
  { id: 'listings', label: '上架编排', codicon: 'rocket' },
  { id: 'buybox', label: 'BuyBox 跟价', codicon: 'pulse' },
  { id: 'competitor', label: '竞品监控', codicon: 'graph' },
  { id: 'compliance', label: '合规检测', codicon: 'shield' },
  { id: 'settings', label: '多店铺设置', codicon: 'settings-gear' },
  { id: 'fulfilment', label: '履约闭环', codicon: 'truck' },
  { id: 'diagnostics', label: '环境自检', codicon: 'beaker' }
]

// ── 环境自检（换机部署第一步） ─────────────────────────────────────────────────
// 判断全部来自后端事实采集（GET /diagnostics）：新机器上"哪里不通"不该靠猜。
const DIAG_LEVEL = {
  pass: { label: '通过', cls: 'text-emerald-400' },
  warn: { label: '警告', cls: 'text-amber-400' },
  fail: { label: '失败', cls: 'text-red-400' },
  info: { label: '提示', cls: 'text-(--ui-text-quaternary)' }
}

function Diagnostics() {
  const storeId = useValue($storeId)
  const [runKey, setRunKey] = useState(0)
  const [copied, setCopied] = useState('')
  const query = `/diagnostics?storeId=${encodeURIComponent(storeId)}`
  const q = useApi(query, `diagnostics:${storeId}:${runKey}`)
  const d = q.data || {}
  const checks = d.checks || []
  const sum = d.summary || {}

  const copy = async () => {
    const text = d.report || ''
    if (!text) {
      setCopied('还没有报告：先点「重新自检」')
      return
    }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text)
        setCopied('已复制到剪贴板（不含 Key，可直接贴给别人）')
        host.notify({ kind: 'info', message: '诊断报告已复制' })
      } else {
        setCopied('这个环境不支持自动复制：请手动全选下方「报告全文」')
      }
    } catch (e) {
      setCopied(`复制失败（${e && e.message ? e.message : e}）：请手动全选下方「报告全文」`)
    }
  }

  const levelOf = c => DIAG_LEVEL[c.level] || DIAG_LEVEL.info

  return jsxs('div', {
    className: 'space-y-3',
    children: [
      jsxs(Card, {
        title: '环境自检 · 换机部署第一步',
        extra: jsxs('div', {
          className: 'flex gap-2',
          children: [
            jsx(Button, { size: 'xs', variant: 'outline', disabled: q.isLoading, onClick: () => { setCopied(''); setRunKey(k => k + 1) }, children: q.isLoading ? '自检中…' : '重新自检' }),
            jsx(Button, { size: 'xs', onClick: copy, children: '复制诊断报告' })
          ]
        }),
        children: jsxs('div', {
          className: 'space-y-2',
          children: [
            jsxs('div', {
              className: 'flex flex-wrap items-center gap-2',
              children: [
                jsx(Pill, { tone: (sum.failed || 0) > 0 ? 'bad' : (sum.warned || 0) > 0 ? 'warn' : 'good', children: `通过 ${sum.passed ?? 0} / 警告 ${sum.warned ?? 0} / 失败 ${sum.failed ?? 0}` }),
                jsx('span', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `后端 ${d.version || '—'} · 出口 ${d.proxy || '未配置'} · ${d.checkedAt || ''}` })
              ]
            }),
            jsx('div', {
              className: 'text-[0.75rem] text-(--ui-text-quaternary)',
              children: '报告里不会出现 Seller Key（只有 TKL••••xxxx 这种打码形式）。新机器上如果出现「失败」，把报告贴出来即可定位到具体环节。'
            }),
            copied ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-tertiary)', children: copied }) : null
          ]
        })
      }),
      jsx(Card, {
        title: `检查项（${checks.length}）`,
        children: jsx(Table, {
          head: [Th('结果'), Th('检查项'), Th('结论'), Th('证据 / 建议')],
          children: checks.map(c =>
            jsxs('tr', {
              key: c.id,
              className: 'align-top',
              children: [
                jsx(Td, { children: jsx('span', { className: cn('text-[0.75rem] font-medium', levelOf(c).cls), children: levelOf(c).label }) }),
                jsx(Td, { children: jsx('div', { className: 'text-[0.8125rem]', children: c.label }) }),
                jsx(Td, { children: jsx('div', { className: 'text-[0.75rem] text-(--ui-text-tertiary)', children: c.detail || '—' }) }),
                jsx(Td, {
                  children: jsxs('div', {
                    className: 'space-y-1',
                    children: [
                      c.level !== 'pass' && c.evidence != null
                        ? jsx('div', { className: 'max-w-xl break-all font-mono text-[0.6875rem] text-(--ui-text-quaternary)', children: String(typeof c.evidence === 'string' ? c.evidence : JSON.stringify(c.evidence)).slice(0, 400) })
                        : null,
                      c.level !== 'pass' && c.hint
                        ? jsx('div', { className: 'max-w-xl text-[0.6875rem] text-amber-400', children: c.hint })
                        : null
                    ]
                  })
                })
              ]
            })
          )
        })
      }),
      (d.stores || []).length
        ? jsx(Card, {
            title: `店铺实测（${d.stores.length}）`,
            children: jsx(Table, {
              head: [Th('店铺'), Th('storeId'), Th('Key'), Th('结果'), Th('耗时'), Th('详情')],
              children: (d.stores || []).map(r =>
                jsxs('tr', {
                  key: r.storeId,
                  children: [
                    jsx(Td, { children: jsx('div', { className: 'text-[0.8125rem]', children: r.storeName || '—' }) }),
                    jsx(Td, { children: jsx('div', { className: 'font-mono text-[0.6875rem] text-(--ui-text-quaternary)', children: r.storeId }) }),
                    jsx(Td, { children: jsx('div', { className: 'font-mono text-[0.6875rem]', children: r.key || '—' }) }),
                    jsx(Td, { children: jsx('span', { className: cn('text-[0.75rem] font-medium', r.ok ? 'text-emerald-400' : 'text-red-400'), children: r.ok ? '可调用' : '失败' }) }),
                    jsx(Td, { children: jsx('div', { className: 'text-right text-[0.75rem] tabular-nums', children: r.ms != null ? `${r.ms} ms` : '—' }) }),
                    jsx(Td, { children: jsx('div', { className: 'max-w-md text-[0.6875rem] text-(--ui-text-tertiary)', children: r.ok ? (r.detail || '—') : String(r.evidence || r.detail || '—').slice(0, 200) }) })
                  ]
                })
              )
            })
          })
        : null,
      jsxs(Card, {
        title: '报告全文（可手动全选复制）',
        children: [
          jsx('textarea', {
            readOnly: true,
            value: d.report || '',
            className: 'h-56 w-full resize-y rounded border border-(--ui-stroke-secondary) bg-transparent p-2 font-mono text-[0.6875rem] leading-relaxed'
          }),
          jsx('div', { className: 'mt-1 text-[0.625rem] text-(--ui-text-quaternary)', children: '店铺行里只出现打码 Key；如果 Key 状态显示为明文，重启一次后端会自动迁移为 DPAPI 密文。' })
        ]
      }),
      jsxs(Card, {
        title: '交付前清单',
        children: jsxs('div', {
          className: 'space-y-1 text-[0.75rem]',
          children: [
            jsx('div', { children: `1. 出口代理换成客户自己的（当前：${d.proxy || '未配置'}）——设置 TAKEALOT_API_PROXY 后重启后端；直连会被 Cloudflare 403。` }),
            jsx('div', { children: '2. 每个店在「多店铺设置」里点「保存并校验」，确认状态为 connected 且 Key 打码正确。' }),
            jsx('div', { children: '3. 商品管理点一次「刷新」，确认全店商品数与 Seller Portal 一致。' }),
            jsx('div', { children: '4. 选品/采集箱任抓一个商品，确认公开爬取通道 transport 不是 direct（direct 说明出口没走代理）。' }),
            jsx('div', { children: '5. 上架编排导出一次装载表，确认是 41 列且能用 Excel 打开。' }),
            jsx('div', { children: '6. 低配机器建议设 HERMES_PROBE_TIMEOUT_MS=90000（用户级环境变量）：桌面端启动时探测 CLI 的预算是 15 秒，机器忙时超时会掉进「首次运行向导」并停住不拉后端。' }),
            jsx('div', { children: '7. 备份 state 目录（含加密后的店铺 Key 与审计/日志）；换机迁移时整目录拷过去即可，Key 需要用同一个 Windows 账号解密。' })
          ]
        })
      })
    ]
  })
}

// ── 履约闭环 ─────────────────────────────────────────────────────────────────
// 一条线：货怎么进去（送仓单/PO）→ 到仓后多少可售（卖家仓 vs DC）→ 怎么出去（客户订单批次 PO）→ 订单明细。
// 全部真实数据：/shipments（PO）+ /offers（分仓库存）+ /sales（订单）。
// 诚实边界：批次与订单只能按「区域+日期」近似对齐（/sales 没有 PO 字段），所以 matched/unmatched 分开列。
const BRANCH_TONE = {
  inbound: 'text-emerald-400',
  outbound: 'text-sky-400',
  mixed: 'text-amber-400'
}

function PO_TABLE(pos, emptyText) {
  if (!pos || !pos.length) {
    return jsx('div', { className: 'px-1 py-3 text-[0.75rem] text-(--ui-text-quaternary)', children: emptyText || '暂无送仓单' })
  }
  return jsx(Table, {
    head: [
      jsx(Th, { key: 'po', children: 'PO 单号' }),
      jsx(Th, { key: 't', children: '类型' }),
      jsx(Th, { key: 'r', children: '目的区域' }),
      jsx(Th, { key: 'd', children: '截止日期' }),
      jsx(Th, { key: 's', children: '状态' }),
      jsx(Th, { key: 'a', children: '动作' })
    ],
    children: pos.map((r, i) => jsxs('tr', {
      key: String(r.shipmentId || i),
      children: [
        jsx(Td, { mono: true, children: String(r.po || '') }),
        jsx(Td, { className: BRANCH_TONE[r.branch] || '', children: r.typeLabel }),
        jsx(Td, { children: r.refRegion || r.region || '—' }),
        jsx(Td, { children: `${r.dueDate || '—'}${r.daysToDue !== null && r.daysToDue !== undefined ? `（${r.daysToDue >= 0 ? '还剩 ' + r.daysToDue + ' 天' : '已过期 ' + Math.abs(r.daysToDue) + ' 天'}）` : ''}` }),
        jsx(Td, { children: `${r.stateLabel || ''}${r.shipped ? ' · 已交运' : ''}` }),
        jsx(Td, {
          className: r.actionable ? 'text-amber-400' : 'text-(--ui-text-quaternary)',
          children: r.actionable ? '待处理（未交运）' : r.cancelled ? '已取消' : '无需动作'
        })
      ]
    }))
  })
}

function Fulfilment() {
  const storeId = useValue($storeId)
  const [runKey, setRunKey] = useState(0)
  const [withStock, setWithStock] = useState(false)
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  // 默认快路径：PO + 订单（1-3 秒）。库存只有在 /offers 缓存存在时才算；
  // 冷缓存要分页拉全量（真店 30 秒），所以放在显式按钮后面。
  const query = `/fulfilment?storeId=${encodeURIComponent(storeId)}&limit=200&withStock=${withStock ? 1 : 0}&_r=${runKey}`
  const m = useApi(query, `fulfilment:${storeId}:${runKey}`)
  const d = m.data || {}
  if (m.error) return jsx(ErrorBox, { error: m.error, onRetry: () => setRunKey(k => k + 1) })
  if (!d.ok) {
    return jsx(Card, {
      title: '履约闭环',
      children: jsxs('div', { className: 'space-y-2 text-[0.8125rem]', children: [
        jsx('div', { className: 'text-amber-400', children: d.error || `后端返回空结果（未带原因）：店铺=${storeId || '（未指定）'}，请点刷新；若仍为空，去「环境自检」看后端连通性` }),
        jsx('div', { className: 'text-[0.75rem] text-(--ui-text-quaternary)', children: '入仓单与订单都是账号级数据，请先在顶栏选定一家店铺（汇总视图下无法确定取哪家）。' })
      ] })
    })
  }
  const st = d.stages || {}
  const inbound = st.inbound || {}
  const outbound = st.outbound || {}
  const stock = st.stock || {}
  const orders = st.orders || {}
  const osum = orders.summary || {}
  const lk = d.linkage || {}
  const seller = stock.seller || {}
  const dc = stock.takealot || {}
  const rows = (orders.items || []).filter(o => {
    const hitQ = !q || [o.orderId, o.sku, o.title].join(' ').toLowerCase().includes(q.toLowerCase())
    const hitS = !status || o.saleStatus === status
    return hitQ && hitS
  })
  const tile = (label, value, sub, tone) => jsxs('div', {
    className: 'rounded-lg border border-(--ui-stroke-secondary) px-3 py-2',
    children: [
      jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: label }),
      jsx('div', { className: cn('text-[1.125rem] font-semibold', tone || ''), children: value }),
      jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: sub })
    ]
  })
  return jsxs('div', {
    className: 'space-y-3',
    children: [
      jsxs('div', { className: 'flex flex-wrap items-center justify-between gap-2', children: [
        jsxs('div', { children: [
          jsx('div', { className: 'text-[0.9375rem] font-semibold', children: `履约闭环 · ${d.storeName || d.storeId}` }),
          jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `数据来源：Seller API /shipments + /sales + /offers · ${d.checkedAt || ''}` })
        ] }),
        jsxs('div', { className: 'flex items-center gap-2', children: [
          jsx(Button, { size: 'xs', variant: 'outline', onClick: () => setRunKey(k => k + 1), children: '刷新' }),
          jsx(Button, { size: 'xs', variant: 'outline', onClick: () => openPortal(d.portal || 'https://seller.takealot.com/'), children: '前往 Seller Portal（预约送仓时段）' })
        ] })
      ] }),
      jsxs('div', { className: 'grid grid-cols-2 gap-2 md:grid-cols-4', children: [
        tile('① 入仓待处理', `${NUM((inbound.summary || {}).actionable)} / ${NUM((inbound.summary || {}).total)}`, '未交运 / 全部送仓单（含补货）'),
        tile('② 可售库存', NUM(stock.available), `卖家仓 ${NUM(seller.available)} · DC ${NUM(dc.available)}`),
        tile('③ DC 在途 / 入库中', `${NUM(stock.onWay)} / ${NUM(stock.receiving)}`, `${NUM(stock.offersWithInbound)} 个 listing 有货在路上`),
        tile('④ 出库待处理', `${NUM((outbound.summary || {}).actionable)} / ${NUM((outbound.summary || {}).total)}`, `订单 ${NUM(osum.total)} 单 · 净额 ${ZAR(osum.net)}`)
      ] }),
      jsx(Card, {
        title: '① 入仓（送仓单 / PO）—— 货怎么进去',
        extra: jsx('span', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `replenishment=补货 · mixed=集货含补货 · ${JSON.stringify((inbound.summary || {}).byState || {})}` }),
        children: jsxs('div', { className: 'space-y-2', children: [
          PO_TABLE(inbound.pos, '暂无入仓类送仓单'),
          jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '「已收全量」= 货已进 DC 并转为可售库存；「已发运」但未交运的才是要动作的。预约送货时段没有 API，点右上角去 Portal。' })
        ] })
      }),
      jsx(Card, {
        title: '② 库存（卖家仓 vs Takealot DC）',
        children: jsxs('div', { className: 'space-y-2', children: [
          jsx(Table, {
            head: [jsx(Th, { key: 'r', children: '仓库 / 区域' }), jsx(Th, { key: 'a', right: true, children: '可售' }), jsx(Th, { key: 'i', right: true, children: '入库中' }), jsx(Th, { key: 'o', right: true, children: '在途' }), jsx(Th, { key: 's', right: true, children: '30 天销' })],
            children: (stock.byRegion || []).slice(0, 12).map((r, i) => jsxs('tr', {
              key: i,
              children: [
                jsx(Td, { className: r.warehouse === 'seller' ? 'text-amber-400' : '', children: r.region }),
                jsx(Td, { right: true, children: NUM(r.available) }),
                jsx(Td, { right: true, children: NUM(r.receiving) }),
                jsx(Td, { right: true, children: NUM(r.onWay) }),
                jsx(Td, { right: true, children: NUM(r.sold30) })
              ]
            }))
          }),
          stock.cached
            ? jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: '卖家仓（黄色）走 Leadtime 直邮发货；DC（JHB/CPT/DBN）库存是送仓到货后才有的。在途 = 已发出但 DC 还没入库。' })
            : jsxs('div', { className: 'flex flex-wrap items-center gap-2 rounded border border-amber-400/60 bg-amber-400/10 p-2 text-[0.75rem]', children: [
                jsx('div', { className: 'flex-1', children: stock.note || '库存未计算（本店商品列表缓存为空）' }),
                jsx(Button, {
                  size: 'xs',
                  disabled: !!(m.isPending || m.isFetching || m.isLoading),
                  onClick: () => {
                    setWithStock(true)
                    host.notify({ kind: 'info', message: '开始补全库存：要分页拉全量 /offers，真店约 30 秒，请勿关页面' })
                  },
                  children: (m.isPending || m.isFetching || m.isLoading) ? '抓取中…' : '补全库存（约 30 秒）'
                })
              ] })
        ] })
      }),
      jsx(Card, {
        title: '③ 出库批次（客户订单 PO）—— 货怎么出去',
        children: jsxs('div', { className: 'space-y-2', children: [
          PO_TABLE(outbound.pos, '暂无出库类送仓单'),
          jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: 'Takealot 会把客户订单按区域+日期打成 PO（reference 形如 PO-卖家号-日期-区域-序号）。未交运的批次就是待发货。' })
        ] })
      }),
      jsx(Card, {
        title: '④ 订单明细（/sales）',
        extra: jsxs('div', { className: 'flex flex-wrap items-center gap-2', children: [
          jsx('input', {
            value: q, placeholder: '订单号 / SKU / 标题',
            onChange: e => setQ(e.target.value),
            className: 'w-40 rounded border border-(--ui-stroke-secondary) bg-transparent px-2 py-1 text-[0.75rem]'
          }),
          jsx(Button, { size: 'xs', variant: status ? 'outline' : 'default', onClick: () => setStatus(''), children: `全部 ${NUM(osum.total)}` }),
          ...Object.entries(osum.byStatus || {}).map(([k, v]) => jsx(Button, { size: 'xs', variant: status === k ? 'default' : 'outline', onClick: () => setStatus(k), children: `${k} ${NUM(v)}` }))
        ] }),
        children: jsxs('div', { className: 'space-y-2', children: [
          jsx(Table, {
            head: [jsx(Th, { key: 'o', children: '订单号' }), jsx(Th, { key: 's', children: 'SKU' }), jsx(Th, { key: 't', children: '商品' }), jsx(Th, { key: 'q', right: true, children: '数量' }), jsx(Th, { key: 'g', right: true, children: '售价' }), jsx(Th, { key: 'n', right: true, children: '净额' }), jsx(Th, { key: 'r', children: '区域' }), jsx(Th, { key: 'st', children: '状态' }), jsx(Th, { key: 'd', children: '日期' })],
            children: rows.slice(0, 120).map((o, i) => jsxs('tr', {
              key: `${o.orderId}-${o.orderItemId}-${i}`,
              children: [
                jsx(Td, { mono: true, children: o.orderId }),
                jsx(Td, { mono: true, children: o.sku }),
                jsx(Td, { className: 'max-w-[16rem] truncate', title: o.title, children: o.title }),
                jsx(Td, { right: true, children: NUM(o.quantity) }),
                jsx(Td, { right: true, children: ZAR(o.sellingPrice) }),
                jsx(Td, { right: true, children: ZAR(o.net) }),
                jsx(Td, { children: o.salesRegion || '—' }),
                jsx(Td, { className: o.saleStatus === 'New Lead Time Order' ? 'text-amber-400' : '', children: o.saleStatus }),
                jsx(Td, { children: String(o.orderDate || '').slice(0, 10) })
              ]
            }))
          }),
          jsx('div', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `显示 ${NUM(rows.length)} / ${NUM(osum.total)} 单 · 件数 ${NUM(osum.units)} · 售价合计 ${ZAR(osum.gross)} · 净额合计 ${ZAR(osum.net)}` })
        ] })
      }),
      jsx(Card, {
        title: '⑤ 批次 ↔ 订单对齐（近似，非外键）',
        extra: jsx('span', { className: 'text-[0.6875rem] text-(--ui-text-quaternary)', children: `对得上 ${NUM(lk.matchedKeys)} · 对不上 ${NUM(lk.unmatchedKeys)}` }),
        children: jsxs('div', { className: 'space-y-2', children: [
          jsx('div', { className: 'text-[0.75rem] text-amber-400', children: lk.note || '' }),
          jsx(Table, {
            head: [jsx(Th, { key: 'k', children: '对齐' }), jsx(Th, { key: 'r', children: '区域' }), jsx(Th, { key: 'd', children: '日期' }), jsx(Th, { key: 'p', children: '批次 PO' }), jsx(Th, { key: 't', children: '类型' }), jsx(Th, { key: 's', children: 'PO 状态' }), jsx(Th, { key: 'o', right: true, children: '订单' }), jsx(Th, { key: 'u', right: true, children: '件' }), jsx(Th, { key: 'n', right: true, children: '净额' }), jsx(Th, { key: 'x', children: '说明' })],
            children: [...(lk.matched || []), ...(lk.unmatched || [])].map((r, i) => jsxs('tr', {
              key: i,
              children: [
                jsx(Td, { className: r.link === 'matched' ? 'text-emerald-400' : 'text-amber-400', children: r.link === 'matched' ? '已对齐' : r.link === 'orders-only' ? '只有订单' : '只有批次' }),
                jsx(Td, { children: r.region || '—' }),
                jsx(Td, { children: r.date || '—' }),
                jsx(Td, { mono: true, children: r.po ? String(r.po) : '—' }),
                jsx(Td, { children: (r.poTypes || []).join(' / ') || '—' }),
                jsx(Td, { children: r.poState || '—' }),
                jsx(Td, { right: true, children: NUM(r.orders) }),
                jsx(Td, { right: true, children: NUM(r.units) }),
                jsx(Td, { right: true, children: ZAR(r.netValue) }),
                jsx(Td, { className: 'max-w-[22rem] truncate text-(--ui-text-quaternary)', title: r.note, children: r.note || '' })
              ]
            }))
          })
        ] })
      })
    ]
  })
}

const VIEWS = {
  overview: Overview,
  fulfilment: Fulfilment,
  products: Products,
  orders: Orders,
  financial: Financial,
  collection: Collection,
  // 旧深链/存档里的 'listing' 一律落到采集箱（那一行会自动展开分析）
  listing: Collection,
  listings: Listings,
  buybox: Buybox,
  competitor: Competitor,
  compliance: Compliance,
  settings: Settings,
  diagnostics: Diagnostics
}

// 外观：本页样式已现代风；再给一个「一键应用」把整个 App 换成同款配色主题。
// 注意：useTheme() 返回的是 ThemeContextValue —— { theme: DesktopTheme 对象, themeName: string, setTheme, availableThemes }。
// 早期版本写成 `theme.name || theme.theme`，于是把**整个主题对象**塞进了 children → React #31
// "Objects are not valid as a React child (found: object with keys {name,label,description,colors,...})"。
// 铁律：children 只放 string / number / 元素 / null，取名字一律先做 typeof 判定。
function ThemeFooter() {
  const ctxTheme = useTheme() || {}
  const current = typeof ctxTheme.themeName === 'string' ? ctxTheme.themeName : ''
  const themes = Array.isArray(ctxTheme.availableThemes) ? ctxTheme.availableThemes : []
  const known = themes.some(t => t && t.name === TKL_THEME.name)
  const isMine = current === TKL_THEME.name
  const label = (themes.find(t => t && t.name === current) || {}).label
  const [msg, setMsg] = useState('')
  const apply = () => {
    let ok = false
    try {
      if (typeof ctxTheme.setTheme === 'function') {
        ctxTheme.setTheme(TKL_THEME.name)
        ok = true
      }
    } catch (e) {
      ok = false
    }
    if (!ok && typeof requestTheme === 'function') ok = requestTheme(TKL_THEME.name) !== false
    const text = !known
      ? '主题已提交，但当前主题列表里还没看到它（App 需重新加载一次才会出现）'
      : ok
        ? '已应用（设置 → 外观 里可随时改回；深色会跟随系统）'
        : '主题未能切换，但本页现代样式不受影响'
    setMsg(text)
    host.notify({ kind: ok ? 'info' : 'warning', message: text })
  }
  return jsxs('div', {
    className: 'mt-auto space-y-1 rounded border border-(--ui-stroke-secondary) p-2',
    children: [
      jsxs('div', {
        className: 'flex items-center justify-between text-[0.6875rem] text-(--ui-text-quaternary)',
        children: [
          jsx('span', { children: '外观' }),
          jsx('span', { children: isMine ? 'Takealot Studio' : (typeof label === 'string' && label ? label : '跟随应用') })
        ]
      }),
      isMine
        ? jsx(Pill, { tone: 'good', children: '已使用现代主题' })
        : jsx(Button, { size: 'xs', variant: 'outline', onClick: apply, children: '应用现代主题' }),
      msg ? jsx('div', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: msg }) : null
    ]
  })
}

// 顶栏常驻：一键切换店铺（每个店的数据都不一样——跟卖/商品/物流）
function QuickStoreSwitch() {
  const active = useValue($storeId)
  const { stores, activeStoreId } = useStores()
  const setActive = usePost('/settings/active')
  const current = active || activeStoreId || ''
  const choose = id => {
    $storeId.set(id)
    if (storage) {
      storage.set('storeId', id)
    }
    setActive.mutate({ storeId: id }, { onSuccess: () => queryClient.invalidateQueries({ queryKey: ROOT }) })
  }
  if (!stores.length) return null
  const onStore = stores.find(s => s.id === current)
  return jsxs('div', {
    className: 'flex items-center gap-1 rounded border border-(--ui-stroke-secondary) px-1 py-0.5',
    children: [
      jsx('span', { className: 'text-[0.625rem] text-(--ui-text-quaternary)', children: onStore ? '当前店铺' : '全部店铺' }),
      stores.map(s =>
        jsx(
          'button',
          {
            type: 'button',
            key: s.id,
            title: `${s.name}（点击切换）`,
            onClick: () => choose(s.id),
            className: cn(
              'max-w-[9rem] truncate rounded px-1.5 py-0.5 text-[0.6875rem]',
              s.id === current ? 'bg-(--chrome-action-hover) text-(--ui-accent)' : 'text-(--ui-text-tertiary) hover:text-(--ui-text-secondary)'
            ),
            children: s.name
          },
          s.id
        )
      ),
      jsx('button', {
        type: 'button',
        onClick: () => choose(''),
        title: '全部店铺（汇总）',
        className: cn('rounded px-1.5 py-0.5 text-[0.6875rem]', !current ? 'bg-(--chrome-action-hover) text-(--ui-accent)' : 'text-(--ui-text-quaternary)'),
        children: '汇总'
      })
    ]
  })
}

function StatusChip() {
  const q = useQuery({
    queryKey: [...ROOT, 'overview', 'chip'],
    queryFn: () => rest('/overview'),
    refetchInterval: 60_000,
    staleTime: 30_000
  })
  const k = (q.data || {}).kpis
  if (!k) {
    return null
  }
  return jsxs('button', {
    type: 'button',
    className: cn(
      'inline-flex h-full items-center gap-1.5 rounded-none px-1.5 text-[0.6875rem] tabular-nums transition-colors',
      'text-(--ui-text-tertiary) hover:bg-(--chrome-action-hover) hover:text-foreground'
    ),
    onClick: () => host.navigate('/takealot'),
    children: [
      jsx(Codicon, { name: 'globe', size: '0.7rem' }),
      jsx('span', { children: `待发货 ${NUM(k.awaitingShipment)} · BuyBox ${NUM(k.buyboxHeld)}/${NUM(k.buyboxTotal)}` })
    ]
  })
}

function TakealotPage() {
  const module = useValue($module) || 'overview'
  const View = VIEWS[module] || Overview
  const open = id => {
    $module.set(id)
    if (storage) {
      storage.set('module', id)
    }
  }
  return jsxs('div', {
    className: 'tkl flex h-full min-h-0 text-sm',
    children: [
      jsx('style', { children: TKL_CSS }),
      jsxs('div', {
        className: 'flex w-44 shrink-0 flex-col gap-0.5 border-r border-(--ui-stroke-secondary) p-2',
        children: [
          jsxs('div', {
            className: 'flex items-center gap-1.5 px-1.5 pb-2',
            children: [
              jsx(Codicon, { name: 'globe', size: '0.9rem' }),
              jsx('div', { className: 'text-[0.8125rem] font-semibold', children: 'Takealot 中台' })
            ]
          }),
          MODULES.map(m =>
            jsxs(
              'button',
              {
                key: m.id,
                type: 'button',
                onClick: () => open(m.id),
                'data-active': module === m.id ? '1' : '0',
                className: cn(
                  'tkl-rail-item flex items-center gap-2 px-2 py-1.5 text-left text-[0.8125rem] transition-colors',
                  module === m.id
                    ? 'bg-(--chrome-action-hover) text-foreground'
                    : 'text-(--ui-text-tertiary) hover:bg-(--chrome-action-hover) hover:text-foreground'
                ),
                children: [jsx(Codicon, { name: m.codicon, size: '0.85rem' }), jsx('span', { className: 'truncate', children: m.label })]
              },
              m.id
            )
          ),
          jsx(StoreSwitcher, {}),
          jsx(ThemeFooter, {}),
          jsx('div', { className: 'px-1.5 pt-1 text-[0.625rem] text-(--ui-text-quaternary)', children: '数据源：官方 Seller API v1 / 公开爬取 / 内置样例' })
        ]
      }),
      jsxs('div', {
        className: 'min-w-0 flex-1 overflow-auto p-3',
        children: [
          // 常驻顶栏：模块名 + 一键切换店铺（每个店数据不同，切换必须随手可点）
          jsxs('div', {
            className: 'mb-2 flex flex-wrap items-center justify-between gap-2',
            children: [
              jsx('div', {
                className: 'text-[0.8125rem] text-(--ui-text-tertiary)',
                children: (MODULES.find(m => m.id === module) || {}).label || ''
              }),
              jsx(QuickStoreSwitch, {})
            ]
          }),
          jsx(View, { key: module })
        ]
      })
    ]
  })
}

export default {
  id: ID,
  name: 'Takealot ERP',
  description: 'Takealot 跨境中台：经营总览、订单净利、财务对账、采集箱、上架编排、BuyBox 跟价、竞品监控、合规检测与多店铺设置。',
  register(ctx) {
    rest = ctx.rest
    storage = ctx.storage
    rest.os = ctx.os
    osDoor = ctx.os
    $module.set(storage.get('module', 'overview') || 'overview')
    $storeId.set(storage.get('storeId', '') || '')

    ctx.i18n.register({
      en: { nav: 'Takealot', open: 'Open Takealot ERP' },
      'zh-CN': { nav: 'Takealot 运营', open: '打开 Takealot 中台' },
      'zh-TW': { nav: 'Takealot 營運', open: '開啟 Takealot 中台' }
    })

    ctx.registerMany([
      { id: 'theme', area: THEMES_AREA, data: TKL_THEME },
      { id: 'page', area: ROUTES_AREA, data: { path: '/takealot' }, render: () => jsx(TakealotPage, {}) },
      { id: 'nav', area: SIDEBAR_NAV_AREA, order: 40, data: { path: '/takealot', label: 'Takealot 运营', codicon: 'globe' } },
      { id: 'status', area: STATUSBAR_AREAS.right, order: 70, render: () => jsx(StatusChip, {}) },
      {
        id: 'open',
        area: PALETTE_AREA,
        data: { id: 'takealot.open', label: 'Takealot: 打开中台', keywords: ['takealot', 'erp', '订单', '跟价'], run: () => host.navigate('/takealot') }
      }
    ])
  }
}
