# B 复刻 / 新建改编：作业手册（2026-09-26 定版）

**口径（用户定）**：文案**由模型编写**；用户只提供**差异参数**（价格/规格等覆盖值）；**没给参数就按源链接上的参数重塑**；
全程**无需用户有感操作** —— 客户只要说"把这条链接改编成我们的 listing"。

## 链路（四步，两个脚本 + 模型写内容）

```bash
# ① 抽取（脚本，已验）：PDP → manifest
python3 extract_listing.py "https://www.takealot.com/xxx/PLIDxxxxxxxx" my_src

# ② 生成骨架（脚本，结构由它保证）：manifest → facts 骨架（字段名/图片档位/条码位都从类目清单来）
python3 replicate_facts.py ~/.hermes/portal_cua/manifests/src_PLIDxxxxxxxx.json my_name \
    --category "Consumer Electronics/Electronic Accessories/Cellphone Cables"

# ③ 模型填内容（唯一由模型产出的部分）：读 facts 里的 `_material`（源标题/价格/原文 4000 字）
#    写 rich_fields.title / rich_fields.description + 各属性值。差异参数有就用，没有就沿用源。
#    ❗ 事实类字段（尺寸/重量/材质/保修）**不许编**：源里没有就留空，让守门脚本报出来。

# ④ 守门（脚本，别跳过）：
python3 check_facts.py <facts.json>          # 离线：结构/必填/字段名/图片档位/条码口径/照抄风险
python3 check_facts.py <facts.json> --live   # 在线：让引擎**真去选一遍**每个下拉值（~2 分钟）

# ⑤ 跑（写值侧已验 5551654 477 字）
python3 create_listing.py <facts.json>
python3 verify_persisted.py <SID>            # 唯一验收判据
```

## 为什么必须有守门（B 的失败全在这五类，都是可静态查的）

1. 字段名不在该类目里（拼错 / 换类目了没更新清单）
2. **下拉值平台根本没有** —— 实测坑：`option 'USB Type-C Cable' not found`，而当时没人知道平台到底有哪些值
3. 必填没填够（该类目 10 项，条码也在其中）
4. 图片 URL 用了 `s-pdpxl`(459px) → **<600px 平台不报错，只把 Submit 静默禁用**
5. 文案照抄源站（判重风险；`check_facts.py` 会用 `_material` 原文比对 ≥40 字整段）

## ⚠️ 两个还没闭环的地方（别当成"已经全自动"）

### 1. 包装尺寸 / 重量在**买家页根本不存在**
它们是**卖家侧物流属性**，PDP 从不公开（实测 TROO 线材源页的规格表只有：线长、保修、连接器类型、箱内清单）。
而 Cable 类目把它们列为必填 → **B 拿不到这两个数就提交不了**。两条出路：
- **（推荐）客户维护一份"品类默认规格表"**（如 cables: 12×8×2 cm / 60 g）——填一次，之后零人工；
- 或在差异参数里逐条给（每次都要人）。

> 判断口径：**B 的零人工有前提 = 源带规格 或 客户给默认表**。缺这两样时，引擎会停在守门那一步并列出缺什么（fail-fast，不猜）。

### 2. `Attribute.cable_type` 这类**可搜索 combobox** 还没打通
字段结构实测：`[data-fieldid] > .ZorkInput__input-selector > .ZorkAriaSelect__input > INPUT[role=combobox]`
+ 屏幕阅读器提示"有 30 个选项可用"。现象：**JS 原生 click 打不开**（点外层 div 和点 input 都试过，`[role=option]` 始终 0），
只能走 bsk 真点击开；而选项**点开后才渲染** → 于是"读选项列表"会读出假的 `(Optional)`（假阴性）。
现状：普通下拉（如 `Attribute.connector_type`=USB）引擎能真选上 ✓；这类 combobox **不保证能选上** ✗。
→ 待办：把 combobox 纳入引擎的下拉快路（真点击开 + 输入前缀过滤 + 真点击选 + 读回断言），再跑一条真复刻验证。

## 验收纪律（照旧）

- 唯一判据 = `verify_persisted.py <SID>` 回读**服务端**；草稿不落富文本，验草稿会得到假阴性。
- 图片走 **URL 直塞**（≈3.8s/张，零下载）；失败自动退回本地下载 + drop。
- 一条 ≈5.5 分钟（富文本 152 ms/字占大头）。
