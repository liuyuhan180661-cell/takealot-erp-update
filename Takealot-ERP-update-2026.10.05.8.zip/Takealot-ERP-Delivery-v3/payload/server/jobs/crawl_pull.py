#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""定时抓取 / 启动爬虫（只读，不改平台数据）—— 把"跟价能算得出来"所需的数据抓齐。

为什么不是只刷目录：跟价要算目标价，必须知道**竞品最低价**；而竞品是**按商品（TSIN）抓**的。
所以这个任务要：
  ① 刷目录缓存（公开页/类目/属性）；
  ② 对店铺在售商品**逐个 TSIN 抓竞品**（限流：每轮最多 --limit 个，默认 40；优先抓"还没有竞品价"的）；
  ③ 抓完回头数一遍：`/repricing/candidates` 里**有多少条现在有竞品价了**
     —— 这个数字就是"跟价从无从下手变成能动手"的证据。

用法：  <ERP_HOME 的 venv python> crawl_pull.py [--store <id>] [--limit N | 0=只刷目录]
        <ERP_HOME 的 venv python> crawl_pull.py --target <PLID|TSIN|url>     # 只抓一个
退出码：0 = 全部成功；1 = 有失败项（数字照实报）；>=2 = 起不来/接口报错。
"""
from __future__ import annotations

import argparse
import datetime as dt
import sys
import time

import _erpclient as C


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", default="")
    ap.add_argument("--target", default="")
    ap.add_argument("--limit", type=int, default=40, help="本轮最多抓几个 TSIN（0 = 只刷目录）")
    ap.add_argument("--sleep", type=float, default=0.8, help="每个之间间隔秒（别把对方打疼）")
    args = ap.parse_args()

    try:
        cli = C.Client()
    except Exception as exc:
        C.die("读不到本机服务：{0}".format(exc))
    store = args.store or cli.active_store()

    print("定时抓取 · {0}{1}".format(dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
                                 "｜店铺 " + store if store else "｜全部店铺"))
    problems = []

    if args.target:
        res = cli.call("POST", "/crawler/pull", body={"target": args.target, "force": True}) or {}
        if res.get("ok") is False:
            C.die("抓 {0} 失败：{1}".format(args.target, str(res.get("error") or res)[:120]), 2)
        print("单目标抓取 {0}：完成".format(args.target))
        return 0

    # ① 目录缓存
    res = cli.call("POST", "/catalog/refresh", body={"limit": max(args.limit * 4, 200)}) or {}
    if res.get("ok") is False:
        problems.append("目录刷新失败：{0}".format(str(res.get("error") or res)[:110]))
        print("目录缓存刷新：失败 —— {0}".format(str(res.get("error") or res)[:110]))
    else:
        n = res.get("count") or res.get("total") or res.get("updated")
        print("目录缓存刷新：完成{0}".format("（{0} 条）".format(n) if n is not None else ""))

    # ② 逐 TSIN 抓竞品
    tracked = failed = 0
    if args.limit > 0:
        prods = cli.call("GET", "/products", query={"limit": 500}, store_id=store) or {}
        rows = prods.get("items") or []
        by_sku = {str(r.get("sku")): r for r in rows}
        targets = [str(r.get("tsin")) for r in rows if str(r.get("tsin") or "").startswith("TSIN")]
        cand = cli.call("GET", "/repricing/candidates", store_id=store) or {}
        missing = [str(i.get("sku")) for i in (cand.get("items") or []) if i.get("lowestCompetitor") is None]
        priority = [str(by_sku[s].get("tsin")) for s in missing
                    if s in by_sku and str(by_sku[s].get("tsin") or "").startswith("TSIN")]
        pick = (priority or targets)[: args.limit]
        print("竞品抓取：目标 {0} 个（在售 {1} 个，其中 {2} 个还没有竞品价）".format(
            len(pick), len(targets), len(missing)))
        for tsin in pick:
            one = cli.call("POST", "/competitor/track", body={"tsin": tsin, "storeId": store}) or {}
            if one.get("ok") is False:
                failed += 1
            else:
                tracked += 1
            time.sleep(max(0.0, args.sleep))
        print("竞品抓取：成功 {0} 个 · 失败 {1} 个".format(tracked, failed))
        if failed:
            problems.append("竞品抓取有 {0} 个没成功（个别商品页抓不到是会有的）".format(failed))

    # ③ 回看：现在有多少条能跟价了（"闭环有没有接上"的证据）
    after = cli.call("GET", "/repricing/candidates", store_id=store) or {}
    items = after.get("items") or []
    withc = [i for i in items if i.get("lowestCompetitor") is not None]
    actionable = [i for i in withc if i.get("listed") and not i.get("buyboxHeld")]
    print("")
    print("SUMMARY: 候选 {0} 条 · 有竞品价 {1} 条 · 其中该动作（丢盒/未占优）{2} 条".format(
        len(items), len(withc), len(actionable)))
    if not withc:
        print("  ⚠️ 一条竞品价都没有：跟价算不出目标价（不是脚本坏了，是竞品数据没抓到）")

    if problems:
        print("PROBLEMS:")
        for p in problems:
            print("  - " + p)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
