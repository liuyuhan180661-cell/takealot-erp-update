#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""24h 买盒盯盘 —— 一轮巡检的**唯一写价入口**（v3：走本机常驻服务，不再 import 插件内部模块）。

设计原则：**报告里的每个数字都必须来自本脚本的输出**。
agent 只许运行本脚本并原样转述；不许自己算价、不许自己写总结、不许凭接口响应声称成功。

用法：
    <ERP_HOME 的 venv python> repricing_round.py --store store-2
    <ERP_HOME 的 venv python> repricing_round.py                 # 用 state/repricing_watch.json 里的 storeIds
    <ERP_HOME 的 venv python> repricing_round.py --plan          # 只看"会动哪些"，一个价都不写
退出码：0 = 本轮无异常；1 = 有未验证/失败/越界项（需 agent 汇报）；2 = **没执行**（未授权/缺店铺等）。

每一步都留证据：
  1) 候选来自 GET /repricing/candidates（真端点）
  2) 写入走 POST /repricing/save（后端唯一写价路径：策略 + 立即写平台，逐条审计）
  3) 本脚本**再独立 GET /repricing/candidates 回读**一次（不信后端自述，也不信 agent 自述）
  4) 账本行 append 到 state/repricing_watch_log.md（UTF-8）；后端侧另有一份「调价日志」GET /repricing/log
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys

import _erpclient as C

WATCH = "repricing_watch.json"


def load_watch(home: str) -> dict:
    path = os.path.join(home, "state", WATCH)
    if not os.path.exists(path):
        C.die("ABORT: 未找到 {0} —— 没有授权就不许写价".format(path), 2)
    with open(path, encoding="utf-8") as fh:
        return json.load(fh) or {}


def readback(cli, skus: list[str], store: str) -> dict:
    """独立回读：当前价 + 买盒归属（同一份数据，界面也是看这个）。"""
    data = cli.call("GET", "/repricing/candidates", store_id=store) or {}
    out = {}
    for it in data.get("items") or []:
        sku = str(it.get("sku"))
        if sku in skus:
            out[sku] = {"price": it.get("price"), "buyboxHeld": it.get("buyboxHeld"),
                        "lowestCompetitor": it.get("lowestCompetitor")}
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", default="")
    ap.add_argument("--skus", default="")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--plan", action="store_true", help="只看计划，不写平台")
    args = ap.parse_args()

    try:
        cli = C.Client()
    except Exception as exc:
        C.die("读不到本机服务：{0}".format(exc), 2)
    home = cli.home

    cfg = load_watch(home)
    if cfg.get("authorized") is not True:
        C.die("ABORT: {0} 里 authorized != true（还没授权），拒绝写入".format(WATCH), 2)
    stores = [args.store] if args.store else [str(s) for s in (cfg.get("storeIds") or [])]
    if not stores:
        C.die("ABORT: 授权里没有 storeIds（不知道给哪家店跟价）", 2)

    max_round = int(args.limit or cfg.get("maxChangesPerRun") or 10)
    floor = cfg.get("floorPrice")
    ceiling = cfg.get("ceilingPrice")
    undercut = float(cfg.get("minUndercut") or 1.0)
    stamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    ledger, problems = [], []
    total_write = total_skip = total_fail = 0

    for store in stores:
        cand = cli.call("GET", "/repricing/candidates", store_id=store) or {}
        items = cand.get("items") or []
        if cand.get("ok") is False or (not items and cand.get("error")):
            problems.append("{0}: 候选读不到（{1}）".format(store, str(cand.get("error"))[:90]))
            continue
        need = []
        for it in items:
            if args.skus and str(it.get("sku")) not in args.skus.split(","):
                continue
            if not it.get("listed") or it.get("buyboxHeld") or it.get("lowestCompetitor") is None:
                continue
            need.append(it)
        need = need[:max_round]
        if not need:
            print("[{0}] {1}: 本轮无需动作（候选 {2} 条：已有买盒 / 无竞品数据 / 未上架）".format(stamp, store, len(items)))
            continue
        skus = [str(i.get("sku")) for i in need]
        print("[{0}] {1}: 本轮提交 {2} 条 → {3}".format(stamp, store, len(skus), ",".join(skus)))
        if args.plan:
            for i in need:
                print("    - {0}｜现价 {1}｜竞品最低 {2}｜（计划：按授权 {3}~{4} 跟价）".format(
                    i.get("sku"), i.get("price"), i.get("lowestCompetitor"),
                    cfg.get("minUndercut"), cfg.get("maxUndercut")))
            continue

        res = cli.call("POST", "/repricing/save", body={
            "storeId": store, "scope": "selection", "skus": skus,
            "floorPrice": floor, "undercutAmount": undercut, "ceilingPrice": ceiling,
            "maxChangesPerRun": max_round, "autoEnabled": bool(cfg.get("autoEnabled")),
        }) or {}
        if res.get("ok") is False:
            problems.append("{0}: 写价被后端拒绝（{1}）".format(store, str(res.get("reason") or res.get("error"))[:120]))
            continue
        rows = res.get("applied") or []
        after = readback(cli, skus, store)
        for row in rows:
            sku = str(row.get("sku"))
            result, newp = row.get("result"), row.get("newPrice")
            if result == "WROTE":
                got = (after.get(sku) or {}).get("price")
                held = (after.get(sku) or {}).get("buyboxHeld")
                ok = got is not None and newp is not None and abs(float(got) - float(newp)) < 0.01
                total_write += 1 if ok else 0
                if not ok:
                    total_fail += 1
                    problems.append("{0} 声称写入 {1} 但平台回读 {2}".format(sku, newp, got))
                ledger.append("{0} | {1} | {2} | {3} -> {4} | 平台回读 {5} | 买盒={6} | {7}".format(
                    stamp, sku, "WROTE(已验证)" if ok else "WROTE(未验证!)", row.get("oldPrice"), newp,
                    got, held, str(row.get("reason") or "")[:60]))
            elif result == "SKIPPED":
                total_skip += 1
                ledger.append("{0} | {1} | SKIPPED | {2} | {3}".format(
                    stamp, sku, row.get("oldPrice"), str(row.get("reason") or "")[:80]))
            else:
                total_fail += 1
                problems.append("{0} 结果 {1}: {2}".format(sku, result, str(row.get("reason") or "")[:80]))
                ledger.append("{0} | {1} | FAILED | {2}".format(stamp, sku, str(row.get("reason") or "")[:80]))

    state_dir = os.path.join(home, "state")
    os.makedirs(state_dir, exist_ok=True)
    ledger_path = os.path.join(state_dir, "repricing_watch_log.md")
    with open(ledger_path, "a", encoding="utf-8") as fh:
        for line in ledger:
            fh.write("- " + line + "\n")

    # 静默模式：本轮无事发生就一个字都不打印（看门狗模式：没有输出 = 不打扰用户），
    # 从结构上杜绝"没执行说执行了"。（--plan 除外：那本来就是给人看的。）
    if not ledger and not problems and not args.plan:
        return 0

    if ledger or problems:
        print("")
        print("SUMMARY: 写入 {0} 条 · 跳过 {1} 条 · 失败/未验证 {2} 条".format(total_write, total_skip, total_fail))
        print("LEDGER: {0}".format(ledger_path))
        if problems:
            print("PROBLEMS:")
            for p in problems:
                print("  - " + p)
            return 1
        if not ledger:
            print("NOTE: 本轮没有任何需要动作的 listing（不是失败）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
