#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Takealot ERP 常驻服务端（形态 v3 · 独立进程，不依赖任何 agent 宿主）。

    python3 server/app.py --port 18791            # 前台跑，Ctrl-C 停
    python3 server/app.py --port 0                # 自动挑一个空闲端口（写进 runtime.json）
    ERP_HOME=~/.takealot-erp python3 server/app.py

它做四件事，没有第五件：

1. **挂载核心 API**：按文件位置导入 ``plugin/dashboard/plugin_api.py``（15 747 行 / 78 路由，
   零宿主依赖），挂在 ``/api/plugins/takealot-erp`` —— URL 与旧形态一致，所以界面资产
   （``ui/plugin.js``）一行都不用改。
2. **托管工作台前端**：``/`` 出 ``ui/index.html``，``/ui/*`` 出界面资产（react 兼容层 + plugin.js）。
3. **本地鉴权**：启动生成一次性 token 写进 ``ERP_HOME/runtime.json``（0600）；``/api/*`` 必须带
   ``X-ERP-Token``，否则 401。只监听 127.0.0.1，不对外。
4. **确定性地告诉外界我在哪**：端口、pid、启动时间、版本写 ``runtime.json``，日志写
   ``ERP_HOME/logs/server.log``。launcher / CLI / MCP / 任何 agent 都只读这个文件，不猜端口。

设计约束（改动前读一遍）：

* **不是 Windows 服务**，也永远不要做成服务：Seller Key 用 DPAPI / macOS 钥匙串加密，
  必须以**登录用户**身份运行才能解密；装成 SYSTEM 服务 = Key 解不开 + 要管理员权限。
* **只读 runtime.json，不写别人的东西**：本进程只拥有 ERP_HOME。
* **零模拟数据**：取不到就如实报错，不凑样例数字（核心层自己的纪律，这里不添加任何演示分支）。
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import logging
import os
import secrets
import socket
import subprocess
import sys
import threading
import time
from typing import Callable, Optional


def force_utf8_stdio() -> None:
    """服务端日志也走 UTF-8（Windows 中文版 locale=cp936，中文日志会 UnicodeEncodeError）。"""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass


force_utf8_stdio()


def _bootstrap_ca() -> None:
    """把包内的 CA 信任库钉成进程级 ``SSL_CERT_FILE``（v3 自建 venv 默认没有信任库）。

    独立服务端跑在包内自建 venv 里；macOS 的 Homebrew Python 的
    ``ssl.get_default_verify_paths().cafile`` 是 None，而**裸 urlopen 的默认 context
    只认它** → 抓取 / AI 文案 / 自更新这类没接自定义 context 的 HTTPS 全在 TLS 握手
    失败（表现成「抓不到 / 更新坏了」，容易被误读成 Cloudflare 403）。只 setdefault，
    客户显式设的 SSL_CERT_FILE / TAKEALOT_CA_BUNDLE 优先。
    """
    try:
        import certifi

        ca = certifi.where()
    except Exception:
        return
    if os.path.isfile(ca):
        os.environ.setdefault("SSL_CERT_FILE", ca)
        os.environ.setdefault("REQUESTS_CA_BUNDLE", ca)


_bootstrap_ca()
from datetime import datetime
from pathlib import Path

SERVER_DIR = Path(__file__).resolve().parent
SOURCE_DIR = SERVER_DIR.parent


def _resolve_core_dir() -> Path:
    """核心代码在哪：交付布局（<server>/core/）优先，源码树（../plugin/dashboard/）兜底。

    形态 v3 起，客户机上的目录是自包含的（ERP_HOME/server/core/...）；开发树里核心还在
    老位置（source/plugin/dashboard/）—— 两处都认，避免为了打包而搬家（搬一次就多一份走岔的机会）。
    """
    candidates = [SERVER_DIR / "core", SOURCE_DIR / "plugin" / "dashboard"]
    for cand in candidates:
        if (cand / "plugin_api.py").is_file():
            return cand
    return candidates[0]


CORE_DIR = _resolve_core_dir()
CORE_API = CORE_DIR / "plugin_api.py"

SERVICE = "takealot-erp"
VERSION = "3.0.0"
#: 构建号（出包日期.序号）。自更新靠它判断"通道上的是不是新的"：
#: VERSION 是产品版本（很少动），BUILD 每次出包必变 —— 用 BUILD 比对才不会"改了代码却判成已最新"。
BUILD = "2026.10.07.13"
API_PREFIX = "/api/plugins/takealot-erp"
DEFAULT_PORT = 18791
#: main() 发现同一个 ERP_HOME 已有实例在跑时的退出码。
#: 注意：这是"我不用起"的**正常**结果，不是崩溃 —— launchd/计划任务的 KeepAlive 只认
#: 退出码，若把它当失败，自启就会每 30 秒重启一次、永远停不下来（真机实测
#: LastExitStatus=768 即退出码 3）。cmd_serve 见到这个码会翻成 0。
EXIT_ALREADY_RUNNING = 3
PORT_SPAN = 10

log = logging.getLogger("takealot-erp.server")

_ERP_HOME_ENV = ("TAKEALOT_ERP_HOME", "ERP_HOME")


# ---------------------------------------------------------------------------
# ERP_HOME / runtime.json
# ---------------------------------------------------------------------------

def default_erp_home() -> Path:
    """各平台的默认数据目录（绝不落在 agent 宿主的家目录里）。"""
    env = next((os.environ.get(n, "").strip() for n in _ERP_HOME_ENV if os.environ.get(n, "").strip()), "")
    if env:
        return Path(env).expanduser()
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "TakealotERP"
    return Path.home() / ".takealot-erp"


class ErpHome:
    """erp 家目录的句柄：目录布局 + runtime.json 读写（都在这一处，别处不许拼路径）。"""

    def __init__(self, root: Path) -> None:
        self.root = root.expanduser().resolve()
        self.state = self.root / "state"
        self.logs = self.root / "logs"
        self.ui = self.root / "ui"
        self.data = self.root / "data"
        self.exports = self.state / "exports"
        self.runtime_file = self.root / "runtime.json"
        self.log_file = self.logs / "server.log"

    def ensure(self) -> None:
        for d in (self.root, self.state, self.logs, self.exports):
            d.mkdir(parents=True, exist_ok=True)

    # runtime.json -----------------------------------------------------------
    def read_runtime(self) -> dict:
        try:
            with open(self.runtime_file, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def write_runtime(self, payload: dict) -> Path:
        self.ensure()
        # 临时名必须带 pid：同 home 两个进程同时起（反复 setup / 自启 / 多入口）会共用
        # ".json.tmp"，先跑完的那个把它 rename 走，后者 os.replace 就找不到源文件 →
        # FileNotFoundError 让启动直接崩（真机日志里就是这个）。pid 后缀一次性解决。
        tmp = self.runtime_file.with_suffix(".json.{0}.tmp".format(os.getpid()))
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
        try:
            os.replace(tmp, self.runtime_file)
        except OSError:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        try:  # POSIX：只有当前用户可读（Windows 上 chmod 是 no-op，DPAPI 兜住密钥）
            os.chmod(self.runtime_file, 0o600)
        except OSError:
            pass
        return self.runtime_file


# ---------------------------------------------------------------------------
# 端口 / 单实例
# ---------------------------------------------------------------------------

def _port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", port))
        except OSError:
            return False
    return True


def pick_port(preferred: int, span: int = PORT_SPAN) -> int:
    """0 → 系统给一个空闲端口；否则从 preferred 起向上找第一个能绑的口。"""
    if preferred == 0:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            return int(s.getsockname()[1])
    for port in range(preferred, preferred + max(1, span)):
        if _port_free(port):
            return port
    raise SystemExit(
        "端口 {0}–{1} 全被占用：别的程序占着这一段（拿 netstat -ano | findstr {0} 看是谁），"
        "或换个 --port 再起。".format(preferred, preferred + span - 1)
    )


def running_instance(home: ErpHome) -> dict:
    """如果 runtime.json 指的实例真的活着，返回它的信息，否则空 dict。

    判定标准是**端口上有应答**，不是"文件存在"：崩溃后留下的 runtime.json 不算活着。
    """
    info = home.read_runtime()
    port = info.get("port")
    if not isinstance(port, int) or port <= 0:
        return {}
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1.2)
        if s.connect_ex(("127.0.0.1", port)) != 0:
            return {}
    return info


# ---------------------------------------------------------------------------
# 本地桥（扩展用，127.0.0.1:18790）：由服务托管
# ---------------------------------------------------------------------------

#: SIGTERM 时要收尾的东西。**atexit 在信号路径下不会跑**（我们的 SIGTERM 处理器把信号
#: 交回默认处理后进程直接死），所以桥这类子进程必须在这里收 —— 否则服务一停，桥变成孤儿
#: 继续占着 18790（真机踩到：上一轮安装的桥把端口占了，新服务反而绑不上）。
_ON_TERM_HOOKS: list = []


class BridgeSupervisor:
    """把扩展要用的本地桥挂在服务下：起它、看着它、随服务一起退。

    为什么必须托管：老形态里桥是扩展侧的独立进程，靠人双击 `start_bridge.bat` 起 ——
    客户机上**从来没人起过**，于是「扩展采集 → 桥 → state/ingest → 后端入账」整条路是断的
    （真机证据：state/ingest 的 done/ 与 failed/ 一直是空的）。
    桥自己只绑回环，写入端点也已加来源（Origin）白名单校验；这里只管生命周期。

    关闭方式：环境变量 ERP_BRIDGE=0；换端口：ERP_BRIDGE_PORT。
    """

    def __init__(self, home: ErpHome, port: int = 18790, log_fn: Optional[Callable[[str], None]] = None) -> None:
        self.home = home
        self.port = port
        self.log = log_fn or log.info
        self.proc: Optional[subprocess.Popen] = None
        self.thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    @property
    def script(self) -> Path:
        return self.home.root / "server" / "bridge" / "erp_bridge.py"

    def enabled(self) -> bool:
        if (os.environ.get("ERP_BRIDGE") or "").strip() in ("0", "off", "false"):
            return False
        return self.script.is_file()

    def _spawn(self) -> Optional[subprocess.Popen]:
        log_path = self.home.logs / "bridge.out"
        try:
            fh = open(log_path, "ab")
        except OSError:
            fh = subprocess.DEVNULL  # type: ignore[assignment]
        env = dict(os.environ)
        env["ERP_HOME"] = str(self.home.root)
        env.setdefault("PYTHONUNBUFFERED", "1")
        cmd = [sys.executable, str(self.script), "--port", str(self.port), "--state", str(self.home.state)]
        kw: dict = {"stdout": fh, "stderr": fh, "stdin": subprocess.DEVNULL,
                    "cwd": str(self.home.root), "env": env}
        if os.name == "posix":
            kw["start_new_session"] = True   # 脱离服务进程组：服务被 Ctrl-C 时先由我们 stop()
        try:
            return subprocess.Popen(cmd, **kw)
        except Exception as exc:  # noqa: BLE001
            self.log("桥起不来：{0}: {1}".format(type(exc).__name__, exc))
            return None

    def _run(self) -> None:
        failures = 0
        while not self._stop.is_set():
            started = time.time()
            self.proc = self._spawn()
            if self.proc is None:
                failures += 1
            else:
                self.log("桥已起：127.0.0.1:{0}（state={1}）".format(self.port, self.home.state))
                self.proc.wait()
                ran = time.time() - started
                if self._stop.is_set():
                    return
                # 活过 30 秒算正常退出（多半是端口被占/手动停），短命才算异常
                failures = 0 if ran > 30 else failures + 1
                self.log("桥退出（code={0}，存活 {1:.0f}s）".format(self.proc.returncode, ran))
            if failures >= 5:
                # 不无限重试：端口被别的程序占着这类问题要人看见（日志 + doctor 都会显示未监听）
                self.log("桥连续 {0} 次起不来，不再重试（查 18790 是否被占用，见 logs/bridge.out）".format(failures))
                return
            self._stop.wait(min(30, 2 ** failures))

    def start(self) -> None:
        if not self.enabled():
            self.log("桥未启用（ERP_BRIDGE=0 或没装 server/bridge/erp_bridge.py）")
            return
        self.thread = threading.Thread(target=self._run, name="erp-bridge", daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self._stop.set()
        proc = self.proc
        if proc is None or proc.poll() is not None:
            return
        try:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------------------
# 核心 API（按文件位置导入，保持"一份实现"）
# ---------------------------------------------------------------------------

def load_core_api(home: ErpHome):
    """导入 plugin_api.py —— 必须在 import 之前把 ERP_HOME 设好（它在 import 时定 STATE_DIR）。"""
    os.environ["TAKEALOT_ERP_HOME"] = str(home.root)
    if not CORE_API.is_file():
        raise SystemExit("找不到核心 API：{0}（服务端和核心代码必须在同一棵树里）".format(CORE_API))
    name = "erp_core_plugin_api"
    cached = sys.modules.get(name)
    if cached is not None:
        return cached
    spec = importlib.util.spec_from_file_location(name, str(CORE_API))
    if spec is None or spec.loader is None:
        raise SystemExit("无法为 {0} 建 spec".format(CORE_API))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def core_fingerprint() -> dict:
    try:
        raw = CORE_API.read_bytes()
    except OSError as exc:
        return {"path": str(CORE_API), "error": str(exc)}
    return {
        "path": str(CORE_API),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
    }


def ui_dir(home: ErpHome) -> Path:
    """前端资产目录：交付布局（ERP_HOME/ui）优先，源码树（source/ui）兜底。"""
    if (home.ui / "index.html").is_file():
        return home.ui
    return SOURCE_DIR / "ui"


# ---------------------------------------------------------------------------
# 日志
# ---------------------------------------------------------------------------

def setup_logging(home: ErpHome, verbose: bool) -> None:
    home.ensure()
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stderr)]
    try:
        handlers.append(logging.FileHandler(home.log_file, encoding="utf-8"))
    except OSError:
        pass
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=handlers,
        force=True,
    )


# ---------------------------------------------------------------------------
# app
# ---------------------------------------------------------------------------

def build_app(home: ErpHome, port: int, token: str, core):
    import hmac as _hmac

    from fastapi import FastAPI, HTTPException, Request
    from fastapi.responses import HTMLResponse, JSONResponse
    from fastapi.staticfiles import StaticFiles

    # ⚠ 本模块头上有 `from __future__ import annotations`，FastAPI 解析类型注解时用的是**模块全局**，
    # 而 Request 是在这个函数里 import 的 → 端点写成 `request: Request` 时注解解析不到，
    # FastAPI 会把 request 当成一个必填 query 参数（实测报 422）。显式挂进模块全局才对。
    globals().setdefault("Request", Request)

    started_at = time.time()
    app = FastAPI(title="Takealot ERP", version=VERSION, docs_url=None, redoc_url=None, openapi_url=None)

    @app.middleware("http")
    async def _local_token(request: Request, call_next):  # noqa: ANN001
        path = request.url.path
        # 令牌自愈端点本身不能要求令牌（页面就是拿它来换新令牌的）
        if path.startswith("/api/") and not path.startswith("/api/erp/local-health") \
                and not path.endswith("/token"):
            given = request.headers.get("x-erp-token") or ""
            if not given or not _hmac.compare_digest(given, token):
                return JSONResponse(
                    {"ok": False, "error": "unauthorized", "staleToken": True,
                     "detail": "缺少或错误的 X-ERP-Token：服务每次启动都会换令牌（装包/升级/重启都会），"
                               "已开着的窗口拿的是旧令牌。刷新页面（⌘R / F5）后重试；"
                               "token 在 " + str(home.runtime_file) + " 里"},
                    status_code=401,
                )
        return await call_next(request)

    @app.get(API_PREFIX + "/token")
    async def _current_token() -> JSONResponse:
        """把**当前**令牌回给同源页面，供"服务重启后旧窗口自愈"用。

        为什么安全：① 只监听回环；② 响应是 JSON，跨站 <script>/no-cors fetch 读不到内容（没有 CORS 头），
        别的网站拿不到它；③ 本机进程本来就能直接读 runtime.json，所以没多开任何口子。
        同理，宿主 renderer（跨源）也拿不到它 —— 这正是启动器插件走无令牌窄端点 /launcher/* 的原因。
        """
        return JSONResponse({"ok": True, "token": token})

    @app.get("/healthz")
    async def healthz():  # noqa: ANN202
        """无鉴权探活：launcher / doctor / 任何 agent / 宿主插件用它判断「工作台是不是已经在跑」。"""
        data = {
            "ok": True,
            "service": SERVICE,
            "version": VERSION,
            "port": port,
            "pid": os.getpid(),
            "startedAt": datetime.fromtimestamp(started_at).strftime("%Y-%m-%dT%H:%M:%S"),
            "uptimeSec": int(time.time() - started_at),
            "erpHome": str(home.root),
            "stateDir": str(home.state),
            "apiPrefix": API_PREFIX,
            "uiDir": str(ui_dir(home)),
            "coreVersion": getattr(core, "VERSION", None),
            "atRestBackend": _at_rest_backend(),
        }
        resp = JSONResponse(data)
        resp.headers["Access-Control-Allow-Origin"] = "*"  # 只含端口/版本/路径，无密钥
        resp.headers["Cache-Control"] = "no-store"
        return resp

    # ── 给宿主侧栏入口用的端点（无 token，但只回环 + 自定义头约束 + 不含密钥/业务数据）──
    # 为什么需要：宿主插件跑在别的 renderer 里，它拿不到 runtime.json 里的 token；
    # 而这个入口只需要"看状态 + 开窗口"两件事，所以给它一个**窄接口**，别把 token 散出去。
    # 安全模型：① 只监听 127.0.0.1；② POST 必须带 X-ERP-Launcher 头（网页无法伪造：会触发
    # CORS 预检，而预检里我们只回自己允许的头）；③ 这两个端点不返回任何密钥/订单/店铺数据。
    LAUNCHER_ORIGIN = "*"  # 只用于无凭据的只读状态与"开窗口"，不带 cookie/token

    def _cors(resp):
        resp.headers["Access-Control-Allow-Origin"] = LAUNCHER_ORIGIN
        resp.headers["Access-Control-Allow-Headers"] = "X-ERP-Launcher, Content-Type"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.options("/launcher/{rest:path}")
    async def _launcher_preflight(rest: str):  # noqa: ANN202
        return _cors(JSONResponse({"ok": True}))

    @app.get("/launcher/summary")
    async def launcher_summary():  # noqa: ANN202
        rt = home.read_runtime()
        audit = {"clients": [], "lastAt": None, "calls": 0}
        try:
            log = home.logs / "mcp-sessions.log"
            if log.is_file():
                for line in log.read_text(encoding="utf-8", errors="replace").splitlines()[-200:]:
                    try:
                        rec = json.loads(line)
                    except ValueError:
                        continue
                    if rec.get("client"):
                        audit["clients"] = sorted(set(audit["clients"]) | {rec["client"]})
                    if rec.get("event") == "tools/call":
                        audit["calls"] += 1
                        audit["lastAt"] = rec.get("at")
        except OSError:
            pass
        return _cors(JSONResponse({
            "ok": True, "service": SERVICE, "version": VERSION, "port": port, "pid": os.getpid(),
            "uptimeSec": int(time.time() - started_at), "erpHome": str(home.root),
            "atRestBackend": _at_rest_backend(), "coreVersion": getattr(core, "VERSION", None),
            "uiAssets": sum(1 for p in ui_dir(home).rglob("*") if p.is_file()),
            "audit": audit,
            "launcher": {"openUrl": "/launcher/open", "header": "X-ERP-Launcher: 1"},
        }))

    @app.post("/launcher/open")
    async def launcher_open(request: Request):  # noqa: ANN202
        if request.headers.get("x-erp-launcher") != "1":
            return _cors(JSONResponse({"ok": False, "error": "missing-launcher-header",
                                       "detail": "这个端点只给本机宿主入口用：必须带 X-ERP-Launcher: 1"},
                                      status_code=403))
        try:
            body = await request.json()
        except Exception:
            body = {}
        mode = "app" if (body or {}).get("mode", "app") == "app" else "browser"
        import platform_ui as _pui
        result = _pui.open_window("http://127.0.0.1:{0}/".format(port), mode)
        log.info("launcher/open：{0}".format(result))
        return _cors(JSONResponse({"ok": bool(result.get("opened")), "url": "http://127.0.0.1:{0}/".format(port),
                                   "port": port, "pid": os.getpid(), "window": result}))

    index_file = ui_dir(home) / "index.html"
    assets_dir = ui_dir(home)

    @app.get("/", response_class=HTMLResponse)
    async def index():  # noqa: ANN202
        """首页 = 工作台外壳，并把本次启动的 token 注入进去。

        token 只出现在本机回环页面里（页面自己再拿它做 X-ERP-Token 头），
        别处（日志、邮件、截图）都不该出现它。
        """
        try:
            html = index_file.read_text(encoding="utf-8")
            bootstrap = {
                "token": token,
                "port": port,
                "apiPrefix": API_PREFIX,
                "version": VERSION,
                "coreVersion": getattr(core, "VERSION", None),
            }
            if "__ERP_BOOTSTRAP__" in html:
                html = html.replace("__ERP_BOOTSTRAP__", json.dumps(bootstrap, ensure_ascii=False))
            else:  # 自定义前端没放占位符时，注入到 <head> 开头，别让页面拿不到 token
                html = html.replace("<head>", "<head><script>window.__ERP__=%s;</script>" % json.dumps(bootstrap, ensure_ascii=False), 1)
        except OSError:
            return HTMLResponse(
                "<!doctype html><meta charset='utf-8'><title>Takealot ERP</title>"
                "<body style='font:14px/1.6 system-ui;padding:24px'>"
                "<h1>Takealot ERP 服务端已就绪</h1>"
                "<p>但没找到工作台前端（ui/index.html）。服务端活着的证据：<a href='/healthz'>/healthz</a></p>"
                "</body>",
                status_code=200,
            )
        return HTMLResponse(html)

    if assets_dir.is_dir():
        app.mount("/ui", StaticFiles(directory=str(assets_dir)), name="ui")

    app.include_router(core.router, prefix=API_PREFIX)

    # ---- 定时任务（内置调度器：跟服务一起活，客户机零配置；Mac/Windows 同一份）----
    def _jobs_home() -> Path:
        raw = os.environ.get("ERP_HOME") or ""
        return Path(raw) if raw else Path(default_erp_home())

    def _sched():
        got = getattr(app.state, "scheduler", None)
        if got is None:
            raise RuntimeError("调度器没起来（服务启动时的报错在 server.out 里）")
        return got

    def _need_token(request: Request) -> None:
        """和核心 API 同一把令牌：本地窗口靠它，别人拿不到就不给动任务。"""
        want = os.environ.get("ERP_TOKEN") or ""
        if want and request.headers.get("X-ERP-Token", "") != want:
            raise HTTPException(status_code=401, detail="缺/错 X-ERP-Token")

    @app.get(API_PREFIX + "/jobs")
    def api_jobs(request: Request):
        _need_token(request)
        return _sched().status()

    @app.post(API_PREFIX + "/jobs/{job_id}/run")
    def api_jobs_run(job_id: str, request: Request):
        _need_token(request)
        jobs = [j for j in _sched().jobs() if str(j.get("id")) == job_id]
        if not jobs:
            raise HTTPException(status_code=404, detail="没有这个任务：%s" % job_id)
        return _sched().run_job(jobs[0], manual=True)

    @app.post(API_PREFIX + "/jobs/{job_id}/toggle")
    def api_jobs_toggle(job_id: str, request: Request):
        _need_token(request)
        sched = _sched()
        items = sched.jobs()
        hit = False
        for j in items:
            if str(j.get("id")) == job_id:
                j["enabled"] = not bool(j.get("enabled", True))
                hit = True
        if not hit:
            raise HTTPException(status_code=404, detail="没有这个任务：%s" % job_id)
        sched.write_jobs(items)
        return sched.status()

    @app.get(API_PREFIX + "/jobs/{job_id}/log")
    def api_jobs_log(job_id: str, request: Request, lines: int = 120):
        _need_token(request)
        sched = _sched()
        rec = [r for r in sched.status()["jobs"] if r["id"] == job_id]
        path = (rec[0].get("lastLogFile") if rec else "") or ""
        if not path or not Path(path).is_file():
            return {"ok": False, "error": "这个任务还没有跑过（没有输出可看）"}
        text = Path(path).read_text(encoding="utf-8", errors="replace")
        return {"ok": True, "file": path, "text": "\n".join(text.splitlines()[-max(1, lines):])}
    return app


def _at_rest_backend() -> str:
    """复用核心层的判定，避免两处各说一套。"""
    core = sys.modules.get("erp_core_plugin_api")
    fn = getattr(core, "_at_rest_backend", None)
    if callable(fn):
        try:
            return str(fn())
        except Exception:
            return "unknown"
    return "unknown"


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Takealot ERP 常驻服务端")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT, help="默认 18791；0 = 自动挑空闲端口")
    ap.add_argument("--host", default="127.0.0.1", help="只允许回环地址（默认 127.0.0.1）")
    ap.add_argument("--erp-home", default=None, help="数据目录（默认平台标准位置，可用 ERP_HOME 覆盖）")
    ap.add_argument("--force", action="store_true", help="已有实例在跑时也强行再起一个（会各自用不同端口）")
    ap.add_argument("--token", default=None, help="指定 token（默认每次启动随机生成）")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args(argv)

    if args.host not in ("127.0.0.1", "localhost", "::1"):
        raise SystemExit("只允许回环地址：这个服务端持有 Seller Key，绝不对局域网/外网开放")

    home = ErpHome(Path(args.erp_home) if args.erp_home else default_erp_home())
    setup_logging(home, args.verbose)
    home.ensure()

    # 解释器自检（现场可诊断）：服务本该跑在 ERP_HOME/venv 里（依赖 + CA 信任库都在这），
    # 被别的解释器拉起时缺什么就报什么，而不是等取数/导出莫名其妙失败。
    venv_py = home.root / "venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if venv_py.is_file() and Path(sys.executable).resolve() != venv_py.resolve():
        log.warning("服务跑在 %s，不是 ERP_HOME 的 venv（%s）—— 依赖/CA 信任库可能不全；"
                    "正常入口（erp open、开机自启）不会这样", sys.executable, venv_py)

    existing = running_instance(home)
    if existing and not args.force:
        print(json.dumps({
            "ok": True, "alreadyRunning": True,
            "port": existing.get("port"), "pid": existing.get("pid"),
            "url": "http://127.0.0.1:{0}/".format(existing.get("port")),
            "erpHome": str(home.root),
            "detail": "这个数据目录已经有实例在跑（要再起一个用 --force）",
        }, ensure_ascii=False, indent=2))
        return EXIT_ALREADY_RUNNING

    core = load_core_api(home)
    core_fp = core_fingerprint()

    port = pick_port(args.port)
    token = args.token or secrets.token_hex(16)
    # 核心 API 与 /api/jobs 共用这把令牌；本机脚本（定时任务、探针）也用它。
    os.environ["ERP_TOKEN"] = token
    app = build_app(home, port, token, core)

    payload = {
        "service": SERVICE,
        "version": VERSION,
        "port": port,
        "host": args.host,
        "pid": os.getpid(),
        "token": token,
        "startedAt": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "erpHome": str(home.root),
        "stateDir": str(home.state),
        "apiPrefix": API_PREFIX,
        "uiDir": str(ui_dir(home)),
        "url": "http://127.0.0.1:{0}/".format(port),
        "core": core_fp,
        "atRestBackend": _at_rest_backend(),
    }
    path = home.write_runtime(payload)

    def _clear_runtime() -> None:
        """退出时把 runtime.json 撤掉：留一个死端口比没有更误导人。"""
        try:
            cur = home.read_runtime()
            if int(cur.get("pid") or 0) == os.getpid():
                home.runtime_file.unlink(missing_ok=True)
        except OSError:
            pass

    import atexit
    import signal as _signal

    atexit.register(_clear_runtime)

    def _on_term(signum, _frame):  # noqa: ANN001
        """SIGTERM 也要清（Ctrl-C 走 KeyboardInterrupt，SIGTERM 不会）。

        注意这是**尽力而为**，不是正确性的依据：Windows 上杀进程是 TerminateProcess，
        根本没有清理机会。所以判定「有没有实例在跑」永远以**端口探活**为准
        （见 running_instance），残留的 runtime.json 不算数。
        """
        _clear_runtime()
        for hook in list(_ON_TERM_HOOKS):
            try:
                hook()
            except Exception:
                pass
        try:
            _signal.signal(signum, _signal.SIG_DFL)
            os.kill(os.getpid(), signum)
        except Exception:
            raise SystemExit(0)

    try:
        _signal.signal(_signal.SIGTERM, _on_term)
    except Exception:
        pass

    log.info("Takealot ERP %s 起来：http://127.0.0.1:%s/ （ERP_HOME=%s，核心 sha256=%s…）",
             VERSION, port, home.root, (core_fp.get("sha256") or "?")[:12])
    log.info("runtime.json → %s（token 只在这里，别外发）", path)

    try:
        import uvicorn
    except ImportError:
        raise SystemExit("缺 uvicorn：在服务端自己的 venv 里 pip install uvicorn fastapi")

    # 定时任务线程：起在服务进程里（不依赖 Hermes、不依赖我们的机器；只有服务这一个 runner）
    try:
        import scheduler as _sched_mod

        def _sched_log(msg: str) -> None:
            try:
                with (home.logs / "jobs.log").open("a", encoding="utf-8") as fh:
                    fh.write("[%s] %s\n" % (datetime.now().isoformat(timespec="seconds"), msg))
            except Exception:
                pass

        app.state.scheduler = _sched_mod.Scheduler(home.root, python=sys.executable, log=_sched_log)
        app.state.scheduler.start()
    except Exception as _exc:
        print("[scheduler] 起不来（服务照跑，但定时任务不会跑）：%s: %s" % (type(_exc).__name__, _exc))

    # 本地桥（扩展采集用）：跟服务同生命周期。老形态靠人双击 .bat 起，客户机上从来没起过 ——
    # 托管之后「扩展 → 桥 → state/ingest → 后端入账」这条路才真的通。
    bridge: Optional[BridgeSupervisor] = None
    try:
        bridge = BridgeSupervisor(home, port=int((os.environ.get("ERP_BRIDGE_PORT") or "18790")))
        app.state.bridge = bridge
        bridge.start()
    except Exception as _exc:
        print("[bridge] 起不来（服务照跑；扩展的采集入库会不可用）：%s: %s" % (type(_exc).__name__, _exc))

    if bridge is not None:
        atexit.register(bridge.stop)
        _ON_TERM_HOOKS.append(bridge.stop)   # SIGTERM 路径也要收（atexit 在那里不跑）

    config = uvicorn.Config(app, host=args.host, port=port, log_level="warning", access_log=False, lifespan="on")
    server = uvicorn.Server(config)

    # 后台线程：事件循环一起来就把开机预热让给核心层自己的 daemon 线程，这里只等信号。
    def _serve() -> None:
        server.run()

    if threading.current_thread() is threading.main_thread():
        try:
            server.run()
        except KeyboardInterrupt:
            log.info("收到 Ctrl-C，正在停 …")
        finally:
            if bridge is not None:
                bridge.stop()
            _clear_runtime()
        return 0
    _serve()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
