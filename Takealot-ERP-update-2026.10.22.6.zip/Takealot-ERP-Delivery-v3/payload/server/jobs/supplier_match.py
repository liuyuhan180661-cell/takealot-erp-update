#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""定时 1688 货源配对（写**本地**配对表；打 1688 图搜；**绝不写平台**）。

为什么必须一小批一小批跑
--------------------------------------------------------------------------------
1688 那条调用 15~25s/条，且有**打热阈值**（实测安全线：真实间隔 ≥16.5s、单会话 ≤25 次）。
所以本任务每轮只配一小批（``--limit``，默认 10），跑完就退，等下一次排期再来；限速本身由
``supplier.py`` 的 rate gate 兜（跨重启用 state 计数，不会因为重启而清零）。

判定模型从 ``state/supplier.json`` 读（**渠道与产品解耦**）：
  · mode="openai" → 任意 OpenAI 兼容端点（客户自己的模型套餐）
  · mode="hermes" → 本机 hermes CLI（客户自己配置的模型）
  · 未配置       → 不会失败：候选照常入库，行标 needs_review，等模型或人工来判

用法：  <ERP_HOME 的 venv python> supplier_match.py [--limit N] [--dry]
退出码：0 = 跑完（含"没配上"这种正常结果）；2 = 起不来/接口报错。
"""
from __future__ import annotations

import argparse

import _erpclient as C


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=10, help="本轮最多配几条（默认 10）")
    ap.add_argument("--dry", action="store_true", help="只演练不写状态（排查用）")
    args = ap.parse_args()

    try:
        cli = C.Client()
    except Exception as exc:
        C.die("连不上本机 ERP 服务：{0}".format(exc))
        return 2

    # 同步跑：本任务自己就是一个独立进程，没有"不能阻塞对话"的约束。
    # 对话里那条路径走的是异步（POST /supplier/match 不带 sync）。
    res = cli.call("POST", "/supplier/match",
                   body={"limit": args.limit, "sync": True, "dry": bool(args.dry)},
                   timeout=1800)
    if not res.get("ok"):
        print("配对启动失败：{0}".format(res.get("error")))
        return 2

    result = res.get("result") or {}
    rows = result.get("results") or []
    print("规则={0} 判定模型={1} 队列={2} 本轮已处理={3}".format(
        result.get("rule"), result.get("modelMode"), result.get("queue"), result.get("processed")))
    for r in rows:
        print("  {0:<14} {1:<13} {2}".format(r.get("plid"), r.get("status") or "-",
                                             (r.get("reason") or "")[:64]))
    matched = [r for r in rows if r.get("status") == "matched"]
    no_match = [r for r in rows if r.get("status") == "no_match"]
    other = [r for r in rows if r.get("status") not in ("matched", "no_match", "dry")]
    print("小结：已配对 {0} ｜ 未找到 {1} ｜ 待配对/待复核 {2} ｜ 队列剩余 {3}".format(
        len(matched), len(no_match), len(other),
        max(0, int(result.get("queue") or 0) - int(result.get("processed") or 0))))
    if not (result.get("modelMode") or "").strip():
        print("提示：还没配置判定模型（state/supplier.json → model.mode）。"
              "候选已经取回并落库，配好模型后**只需重判、不会重搜 1688**。")
    if other:
        print("提示：待复核的行可以在采集箱「1688 货源」列里手工粘链接指定。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
