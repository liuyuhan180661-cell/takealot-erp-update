#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""定时抓取 / 启动爬虫（只读，不改平台数据）—— 把"跟价能算得出来"所需的数据抓齐。

为什么不是只刷目录：跟价要算目标价，必须知道**竞品最低价**；而竞品是**按商品（TSIN）抓**的。
所以这个任务要：
  ① 刷目录缓存（公开页/类目/属性）；
  ② 对店铺在售商品**逐个 TSIN 抓竞品**（优先抓"还没有竞品价"的）；
  ③ 抓完回头数一遍：`/repricing/candidates` 里**有多少条现在有竞品价了**
     —— 这个数字就是"跟价从无从下手变成能动手"的证据。

抓谁（默认只抓有动销的）：`--moving-days 30` 只保留「Seller API QuantitySold30Days > 0」的行。
真店实测 1534 个 offer 里只有约 100 个 30 天内有动销 —— 把抓取预算花在会动的行上，
零动销行几天也不会变。要老行为（在售行全量）就 `--moving-days 0`。

用法：  <ERP_HOME 的 venv python> crawl_pull.py [--store <id>] [--limit N | 0=只刷目录]
        <ERP_HOME 的 venv python> crawl_pull.py --moving-days 30 --all   # 全量：一轮抓完动销行
        <ERP_HOME 的 venv python> crawl_pull.py --target <PLID|TSIN|url> # 只抓一个
退出码：0 = 全部成功（含"本轮预算用尽、下轮接着抓"）；1 = 有失败项 / 该抓却什么都没抓到；
        >=2 = 起不来 / 接口报错。
"""
from __future__ import annotations

import argparse
import datetime as dt
import sys
import time

import _erpclient as C

#: 目录分页上限（防呆）。真店 1534 个 offer，留足余量；超了会明确报出来，不静默截断。
MAX_PRODUCTS_DEFAULT = 5000
PAGE_SIZE = 200          # 服务端硬上限（/products 的 page_size = min(limit, 200)）


def home_dir(cli) -> str:
    return getattr(cli, "home", "") or ""


def _seen_file(home: str) -> str:
    import os as _os
    d = _os.path.join(home, "state")
    _os.makedirs(d, exist_ok=True)
    return _os.path.join(d, "competitor_seen.json")


def _load_seen(home: str) -> dict:
    import json as _json
    import os as _os
    if not home:
        return {}
    p = _seen_file(home)
    try:
        with open(p, encoding="utf-8") as fh:
            return _json.load(fh) or {}
    except Exception:
        return {}


def _save_seen(home: str, data: dict) -> None:
    import json as _json
    if not home:
        return
    try:
        with open(_seen_file(home), "w", encoding="utf-8") as fh:
            _json.dump(data, fh, ensure_ascii=False)
    except Exception:
        pass


def _num(v) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def all_catalog_rows(cli, store: str, cap: int = MAX_PRODUCTS_DEFAULT) -> dict:
    """把店铺目录**分页取全**。

    真机踩过：`GET /products?limit=500` 服务端会截到 200（page_size = min(limit, 200)），
    老版本只取一页 → 抓取目标集被静默砍到前 200 行（真店 1534 行，漏掉 87%）。
    这里显式翻页，并把"取了多少/有没有到防呆上限"如实带回去。
    """
    rows: list = []
    offset, first, truncated = 0, None, False
    pages = 0
    while True:
        res = cli.call("GET", "/products", query={"limit": PAGE_SIZE, "offset": offset},
                       store_id=store) or {}
        if first is None:
            first = res
        items = res.get("items") or []
        rows.extend(items)
        pages += 1
        if not res.get("hasMore") or not items:
            break
        offset += PAGE_SIZE
        if len(rows) >= cap:
            truncated = True
            break
    out = dict(first or {})
    out["items"] = rows
    out["pagesFetched"] = pages
    out["truncatedByUs"] = truncated
    out["allRows"] = len(rows)
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", default="")
    ap.add_argument("--target", default="")
    ap.add_argument("--limit", type=int, default=40, help="本轮最多抓几个 TSIN（0 = 只刷目录）")
    ap.add_argument("--all", action="store_true",
                    help="不设条数上限：一轮把筛选后的目标抓完（受 --max-seconds 保护，跑不完下轮接着抓）")
    ap.add_argument("--moving-days", type=int, default=0,
                    help="只抓「N 天内有动销」的行（0 = 关闭，老行为）。Seller API 只暴露 30 天窗口，"
                         "所以只认 30（其它值按 30 口径执行并说明）")
    ap.add_argument("--sleep", type=float, default=0.8, help="每个之间间隔秒（别把对方打疼）")
    ap.add_argument("--force", action="store_true",
                    help="强制重抓（忽略爬虫 5 天缓存）。**默认不强制**：定时跑要复用缓存，别每轮重抓一遍")
    ap.add_argument("--recheck-days", type=float, default=3.0,
                    help="上次抓过但页面上没有竞品的 SKU，多少天内不再重复抓（默认 3 天）")
    ap.add_argument("--max-seconds", type=float, default=1500.0,
                    help="本轮时间预算（默认 1500s，任务超时是 1800s）：用尽就干净停下，并报还剩几条")
    ap.add_argument("--max-products", type=int, default=MAX_PRODUCTS_DEFAULT,
                    help="目录分页上限（防呆；超出会明确报出来，不静默截断）")
    args = ap.parse_args()

    try:
        cli = C.Client()
    except Exception as exc:
        C.die("读不到本机服务：{0}".format(exc))
    store = args.store or cli.active_store()
    started = time.time()

    moving = args.moving_days > 0
    if args.moving_days and args.moving_days != 30:
        print("提示：Seller API 只有 30 天销量窗口（QuantitySold30Days），"
              "--moving-days {0} 按 30 天口径执行".format(args.moving_days))
    print("定时抓取 · {0}{1}".format(dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
                                 "｜店铺 " + store if store else "｜全部店铺"))
    print("筛选：{0}".format("只抓 30 天内有动销的行" if moving else "不做动销筛选（在售行全量）"))
    problems: list = []

    if args.target:
        res = cli.call("POST", "/crawler/pull", body={"target": args.target, "force": bool(args.force)}) or {}
        if res.get("ok") is False:
            C.die("抓 {0} 失败：{1}".format(args.target, str(res.get("error") or res)[:120]), 2)
        print("单目标抓取 {0}：完成".format(args.target))
        return 0

    # ① 目录缓存。storeId **必须放 body**：/catalog/refresh 只读 body，query 里传的会被忽略
    #    —— 踩过：不传时它刷的是界面当前选中店，看起来"刷了"，其实刷的是另一家店。
    res = cli.call("POST", "/catalog/refresh", body={"storeId": store}, store_id=store) or {}
    if res.get("ok") is False:
        problems.append("目录刷新失败：{0}".format(str(res.get("error") or res)[:110]))
        print("目录缓存刷新：失败 —— {0}".format(str(res.get("error") or res)[:110]))
    else:
        print("目录缓存刷新：完成（{0}，{1}s）".format(
            res.get("count") if res.get("count") is not None else "条数未报", res.get("seconds")))

    # ② 逐 TSIN 抓竞品
    tracked = failed = no_quote = 0
    not_run: list = []
    no_quote_examples: list = []
    picked_n = 0
    if args.limit > 0 or args.all:
        prods = all_catalog_rows(cli, store, cap=max(PAGE_SIZE, args.max_products))
        rows = [r for r in (prods.get("items") or [])]
        print("目录取数：{0} 行（翻 {1} 页{2}）".format(
            len(rows), prods.get("pagesFetched"),
            "；已到防呆上限 {0} 行，剩下的没取".format(args.max_products) if prods.get("truncatedByUs") else ""))
        if prods.get("hint"):
            problems.append("商品列表降级：{0}".format(str(prods.get("hint"))[:110]))
            print("  ⚠️ {0}".format(prods.get("hint")))

        if moving:
            moving_rows = [r for r in rows if _num((r.get("stock") or {}).get("totalSold30")) > 0]
            sold_sum = int(sum(_num((r.get("stock") or {}).get("totalSold30")) for r in moving_rows))
            print("动销筛选：30 天内有动销 {0} 行（销量合计 {1} 件）· 其余 {2} 行本轮不抓".format(
                len(moving_rows), sold_sum, len(rows) - len(moving_rows)))
            rows = moving_rows
            if not rows:
                problems.append("一条 30 天动销行都没有：该抓却没抓到任何东西"
                                "（先确认抓的是哪家店、Seller API 是不是降级）")
                print("  ⚠️ 一条 30 天动销行都没有 —— 本轮不抓")

        by_sku = {str(r.get("sku")): r for r in rows}
        targets = [str(r.get("tsin")) for r in rows if str(r.get("tsin") or "").startswith("TSIN")]
        cand = cli.call("GET", "/repricing/candidates", store_id=store) or {}
        seen = _load_seen(home_dir(cli))
        now = dt.datetime.now().timestamp()
        cooldown = max(0.0, args.recheck_days) * 86400
        in_scope = {str(r.get("sku")) for r in rows}
        missing: list = []
        skipped_cool = 0
        for i in (cand.get("items") or []):
            if i.get("lowestCompetitor") is not None:
                continue
            sku = str(i.get("sku"))
            if sku not in in_scope:          # 筛选之外的行不抢预算
                continue
            rec = seen.get(sku) or {}
            # 抓过、当时页面上就是没有别的卖家（competitorCount 0 / 登记不上）→ 冷却期内别再抓，
            # 既省流量也别老拍人家页面；过了冷却再复查一次（卖家可能新进来了）。
            if rec.get("competitors") == 0 and (now - float(rec.get("at") or 0)) < cooldown:
                skipped_cool += 1
                continue
            missing.append(sku)
        if skipped_cool:
            print("  （{0} 个 SKU 上次抓过就确认没有竞品，冷却 {1:g} 天内跳过）".format(skipped_cool, args.recheck_days))
        priority = [str(by_sku[s].get("tsin")) for s in missing
                    if s in by_sku and str(by_sku[s].get("tsin") or "").startswith("TSIN")]
        prio_set = set(priority)
        scope = priority + [t for t in targets if t not in prio_set]
        pick = scope if args.all else (priority or targets)[: args.limit]
        picked_n = len(pick)
        sku_of = {str(r.get("tsin")): str(r.get("sku")) for r in rows}
        last_err: list = []
        print("竞品抓取：本轮目标 {0} 个（在范围内 {1} 个，其中 {2} 个还没有竞品价；{3}）".format(
            len(pick), len(targets), len(missing),
            "--all：不设上限" if args.all else "上限 {0} 个/轮".format(args.limit)))
        deadline = started + max(30.0, args.max_seconds)
        for idx, tsin in enumerate(pick):
            if time.time() >= deadline:
                not_run = pick[idx:]
                print("  ⏱ 本轮时间预算（{0:.0f}s）用尽：还剩 {1} 个没抓，下轮接着抓（不是失败）".format(
                    args.max_seconds, len(not_run)))
                break
            # 两件事，顺序不能反（真机踩过：只调 /competitor/track 会 ok:false + source:none，
            # 因为它只是"登记"，**真抓取的入口是 /crawler/pull（按 PLID）**）：
            #   ① /crawler/pull  → 走出口代理抓公开页（拿竞品报价 / 评论增量）
            #   ② /competitor/track → 把这次快照登记成"在跟踪"，候选里才会有 lowestCompetitor
            plid = str((by_sku.get(sku_of.get(tsin)) or {}).get("plid") or "")
            fetch = cli.call("POST", "/crawler/pull", body={"target": plid or tsin, "force": bool(args.force)}) or {}
            got = bool(fetch.get("ok")) and bool(fetch.get("product"))
            if not got:
                failed += 1
                last_err.append("{0}: {1}".format(tsin, str(fetch.get("error") or fetch.get("mode") or "抓不到")[:70]))
                time.sleep(max(0.0, args.sleep))
                continue
            one = cli.call("POST", "/competitor/track", body={"tsin": tsin, "storeId": store}) or {}
            item = one.get("item") or {}
            comps = item.get("competitorCount")
            if comps is None:
                comps = item.get("offersCount")
            if one.get("ok") is False:
                # 「抓到了、但公开页上就是没有可比报价」**不是失败**：那是商品本身没有别的卖家
                # （独家/单报价），每轮都会出现（真店动销行里约 18%）。它单独计数，不进 PROBLEMS
                # —— 否则每轮都退回码 1，告警疲劳，真正的抓取失败反而被淹掉。
                no_quote += 1
                if len(no_quote_examples) < 3:
                    no_quote_examples.append(tsin)
                seen[sku_of.get(tsin, tsin)] = {"at": dt.datetime.now().timestamp(), "competitors": 0}
            else:
                tracked += 1
                seen[sku_of.get(tsin, tsin)] = {"at": dt.datetime.now().timestamp(), "competitors": comps}
            time.sleep(max(0.0, args.sleep))
        _save_seen(home_dir(cli), seen)
        print("竞品抓取：成功 {0} 个 · 抓不到 {1} 个 · 页面上没有可比报价 {2} 个 · 本轮没轮到 {3} 个".format(
            tracked, failed, no_quote, len(not_run)))
        if no_quote:
            print("  （没有可比报价 = 该商品公开页就一个报价，不是抓取故障；例：{0}）".format(
                "、".join(no_quote_examples)))
        if failed:
            problems.append("竞品抓取有 {0} 个没抓到：{1}".format(
                failed, "；".join(last_err[:3]) if last_err else "（原因未报）"))

    # ③ 回看：现在有多少条能跟价了（"闭环有没有接上"的证据）
    after = cli.call("GET", "/repricing/candidates", store_id=store) or {}
    items = after.get("items") or []
    withc = [i for i in items if i.get("lowestCompetitor") is not None]
    actionable = [i for i in withc if i.get("listed") and not i.get("buyboxHeld")]
    print("")
    print("SUMMARY: 本轮目标 {0} 个 · 成功 {1} · 抓不到 {2} · 没报价 {3} · 没轮到 {4} · 用时 {5:.0f}s".format(
        picked_n, tracked, failed, no_quote, len(not_run), time.time() - started))
    print("SUMMARY: 候选 {0} 条 · 有竞品价 {1} 条 · 其中该动作（丢盒/未占优）{2} 条".format(
        len(items), len(withc), len(actionable)))
    if not withc:
        print("  ⚠️ 一条竞品价都没有：跟价算不出目标价（不是脚本坏了，是竞品数据没抓到）")

    if problems:
        print("PROBLEMS:")
        for p in problems:
            print("  - " + p)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
