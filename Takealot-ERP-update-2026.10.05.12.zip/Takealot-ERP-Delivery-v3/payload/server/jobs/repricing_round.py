#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""24h 买盒盯盘 —— 一轮巡检的**唯一写价入口**（v3：走本机常驻服务，不再 import 插件内部模块）。

设计原则：**报告里的每个数字都必须来自本脚本的输出**。
agent 只许运行本脚本并原样转述；不许自己算价、不许自己写总结、不许凭接口响应声称成功。

用法：
    <ERP_HOME 的 venv python> repricing_round.py --store store-2
    <ERP_HOME 的 venv python> repricing_round.py                 # 用 state/repricing_watch.json 里的 storeIds
    <ERP_HOME 的 venv python> repricing_round.py --plan          # 只看"会动哪些"，一个价都不写
退出码：0 = 本轮无异常；1 = 有未验证/失败/越界项（需 agent 汇报）；2 = **没执行**（未授权/缺店铺等）。

每一步都留证据：
  1) 候选来自 GET /repricing/candidates（真端点）
  2) 写入走 POST /repricing/save（后端唯一写价路径：策略 + 立即写平台，逐条审计）
  3) 本脚本**再独立 GET /repricing/candidates 回读**一次（不信后端自述，也不信 agent 自述）
  4) 账本行 append 到 state/repricing_watch_log.md（UTF-8）；后端侧另有一份「调价日志」GET /repricing/log
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys

import _erpclient as C

WATCH = "repricing_watch.json"


def load_watch(home: str) -> dict:
    path = os.path.join(home, "state", WATCH)
    if not os.path.exists(path):
        C.die("ABORT: 未找到 {0} —— 没有授权就不许写价".format(path), 2)
    with open(path, encoding="utf-8") as fh:
        return json.load(fh) or {}


def readback(cli, skus: list[str], store: str) -> dict:
    """独立回读：**以后端调价日志里的实时回读值为准**（它写入时做的是真·平台读），
    候选缓存（currentPrice）只作次要信号 —— 缓存要等下一轮刷新才变，
    拿它当唯一依据会把**已经写成功的**报成"未验证"（真机踩过：R2598→R2596 已写入，账本却写"未验证!"）。
    """
    out = {}
    for sku in skus:
        out[sku] = {"price": None, "buyboxHeld": None, "live": None, "source": "none"}
        lg = cli.call("GET", "/repricing/log", query={"sku": sku, "limit": 3}) or {}
        rows = [r for r in (lg.get("rows") or []) if str(r.get("sku")) == sku and r.get("result") == "WROTE"]
        if rows:
            newest = rows[0]
            out[sku]["live"] = newest.get("readbackPrice")
            out[sku]["price"] = newest.get("readbackPrice")
            out[sku]["source"] = "审计日志（写入时实时回读，{0}）".format(newest.get("at"))
    data = cli.call("GET", "/repricing/candidates", store_id=store) or {}
    for it in data.get("items") or []:
        sku = str(it.get("sku"))
        if sku in out:
            out[sku]["cachePrice"] = it.get("currentPrice", it.get("price"))
            out[sku]["buyboxHeld"] = it.get("buyboxHeld")
            out[sku]["lowestCompetitor"] = it.get("lowestCompetitor")
            if out[sku]["price"] is None:
                out[sku]["price"] = out[sku]["cachePrice"]
                out[sku]["source"] = "候选缓存（会滞后一轮，仅供参考）"
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", default="")
    ap.add_argument("--skus", default="")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--plan", action="store_true", help="只看计划，不写平台")
    ap.add_argument("--stale-hours", type=float, default=4.0,
                    help="要动的行如果公开页卡比这个还旧，**先强制重抓**再决策（默认 4 小时；0=关）")
    ap.add_argument("--refresh-held", type=int, default=0,
                    help="每轮额外强制刷新几个「我们当前占优」的行（最旧优先），用来缩短丢盒发现延迟；0=不刷")
    args = ap.parse_args()

    try:
        cli = C.Client()
    except Exception as exc:
        C.die("读不到本机服务：{0}".format(exc), 2)
    home = cli.home

    if args.plan:
        # --plan 一个价都不写 → **不需要授权**。这样 agent 可以"先给人看会动哪些、再问要不要授权"，
        # 而不是没授权就什么都看不到（真机踩到：--plan 也被 ABORT 掉，没法给人看证据）。
        try:
            cfg = load_watch(home)
        except SystemExit:
            cfg = {}
    else:
        cfg = load_watch(home)
        if cfg.get("authorized") is not True:
            C.die("ABORT: {0} 里 authorized != true（还没授权），拒绝写入".format(WATCH), 2)
    stores = [args.store] if args.store else [str(s) for s in (cfg.get("storeIds") or [])]
    if not stores:
        stores = [cli.active_store()] if cli.active_store() else []
    if not stores:
        C.die("ABORT: 不知道给哪家店跟价（--store <店铺id>，或先授权）", 2)

    max_round = int(args.limit or cfg.get("maxChangesPerRun") or 10)
    floor = cfg.get("floorPrice")
    ceiling = cfg.get("ceilingPrice")
    undercut = float(cfg.get("minUndercut") or 1.0)
    stamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    ledger, problems = [], []
    total_write = total_skip = total_fail = 0

    for store in stores:
        cand = cli.call("GET", "/repricing/candidates", store_id=store) or {}
        items = cand.get("items") or []
        if cand.get("ok") is False or (not items and cand.get("error")):
            problems.append("{0}: 候选读不到（{1}）".format(store, str(cand.get("error"))[:90]))
            continue
        need = []
        for it in items:
            if args.skus and str(it.get("sku")) not in args.skus.split(","):
                continue
            if not it.get("listed") or it.get("buyboxHeld") or it.get("lowestCompetitor") is None:
                continue
            need.append(it)
        # —— 占优行轮转刷新（可选，缩短"丢盒发现"延迟）——
        # 我们**当前占优**的行最容易"以为自己还在手上"：按最旧的卡优先强制刷新，
        # 每轮刷 N 个 → 全店覆盖周期 = 行数/ N × 轮间隔。
        if args.refresh_held > 0 and not args.plan:
            held = sorted([i for i in items if i.get("buyboxHeld")],
                          key=lambda x: -(x.get("crawledAgeHours") or 0))[: args.refresh_held]
            refreshed = 0
            for i in held:
                tgt = i.get("plid") or i.get("tsin")
                if tgt:
                    cli.call("POST", "/crawler/pull", body={"target": tgt, "force": True})
                    refreshed += 1
            if refreshed:
                print("    轮转刷新 {0} 个占优行（最旧优先）".format(refreshed))

        need = need[:max_round]
        # —— 新鲜度闸门（真金白银那一步）——
        # 购物车归属与竞品价都来自公开页卡（TTL 5 天）。要动的行若卡太旧，**先重抓再决策**：
        # 否则会拿 5 天前的"我们还在买盒/竞品还是那个价"去压价 —— 压不及时或压错。
        if not args.plan and args.stale_hours > 0 and need:
            stale = [i for i in need if (i.get("crawledAgeHours") is None
                                         or float(i.get("crawledAgeHours") or 0) > args.stale_hours)]
            if stale:
                for i in stale:
                    tgt = i.get("plid") or i.get("tsin")
                    if tgt:
                        cli.call("POST", "/crawler/pull", body={"target": tgt, "force": True})
                print("    写价前刷新 {0} 行的公开页数据（卡龄 > {1:g}h）→ 用新鲜数据重算".format(
                    len(stale), args.stale_hours))
                fresh = cli.call("GET", "/repricing/candidates", query={"probe": 1}, store_id=store) or {}
                fmap = {str(x.get("sku")): x for x in (fresh.get("items") or [])}
                need = [fmap.get(str(i.get("sku")), i) for i in need]
                still = [i for i in need if i.get("listed") and not i.get("buyboxHeld")
                         and i.get("lowestCompetitor") is not None]
                if not still:
                    print("    → 刷新后确认这些行**在我们手上**（旧卡骗人了），本轮不动")
                    continue
                need = still
        if not need:
            print("[{0}] {1}: 本轮无需动作（候选 {2} 条：已有买盒 / 无竞品数据 / 未上架）".format(stamp, store, len(items)))
            continue
        skus = [str(i.get("sku")) for i in need]
        print("[{0}] {1}: 本轮提交 {2} 条 → {3}".format(stamp, store, len(skus), ",".join(skus)))
        for i in need:
            if i.get("action") and i.get("action") != "write":
                print("    注意 {0}：后端判定 {1}（{2}）".format(
                    i.get("sku"), i.get("action"), str(i.get("reason"))[:70]))
        if args.plan:
            for i in need:
                # 目标价/结论由**后端**算（candidates 行里就带着），脚本不自己重算 —— 免得两套口径。
                print("    - {0}｜现价 {1}｜竞品最低 {2}（{3} 家）｜后端目标价 {4}｜{5}{6}".format(
                    i.get("sku"), i.get("currentPrice"), i.get("lowestCompetitor"),
                    i.get("competitorCount"), i.get("targetPrice"), i.get("action") or "",
                    ("：" + str(i.get("reason"))[:70]) if i.get("reason") else ""))
            continue

        res = cli.call("POST", "/repricing/save", body={
            "storeId": store, "scope": "selection", "skus": skus,
            "floorPrice": floor, "undercutAmount": undercut, "ceilingPrice": ceiling,
            "maxChangesPerRun": max_round, "autoEnabled": bool(cfg.get("autoEnabled")),
        }) or {}
        if res.get("ok") is False:
            problems.append("{0}: 写价被后端拒绝（{1}）".format(store, str(res.get("reason") or res.get("error"))[:120]))
            continue
        rows = res.get("applied") or []
        after = readback(cli, skus, store)
        for row in rows:
            sku = str(row.get("sku"))
            result, newp = row.get("result"), row.get("newPrice")
            if result == "WROTE":
                got = (after.get(sku) or {}).get("price")
                held = (after.get(sku) or {}).get("buyboxHeld")
                ok = got is not None and newp is not None and abs(float(got) - float(newp)) < 0.01
                total_write += 1 if ok else 0
                if not ok:
                    total_fail += 1
                    problems.append("{0} 声称写入 {1} 但平台回读 {2}".format(sku, newp, got))
                ledger.append("{0} | {1} | {2} | {3} -> {4} | 平台回读 {5} | 买盒={6} | {7}".format(
                    stamp, sku, "WROTE(已验证)" if ok else "WROTE(未验证!)", row.get("oldPrice"), newp,
                    got, held, str(row.get("reason") or "")[:60]))
            elif result == "SKIPPED":
                total_skip += 1
                ledger.append("{0} | {1} | SKIPPED | {2} | {3}".format(
                    stamp, sku, row.get("oldPrice"), str(row.get("reason") or "")[:80]))
            else:
                total_fail += 1
                problems.append("{0} 结果 {1}: {2}".format(sku, result, str(row.get("reason") or "")[:80]))
                ledger.append("{0} | {1} | FAILED | {2}".format(stamp, sku, str(row.get("reason") or "")[:80]))

    state_dir = os.path.join(home, "state")
    os.makedirs(state_dir, exist_ok=True)
    ledger_path = os.path.join(state_dir, "repricing_watch_log.md")
    with open(ledger_path, "a", encoding="utf-8") as fh:
        for line in ledger:
            fh.write("- " + line + "\n")

    # 静默模式：本轮无事发生就一个字都不打印（看门狗模式：没有输出 = 不打扰用户），
    # 从结构上杜绝"没执行说执行了"。（--plan 除外：那本来就是给人看的。）
    if not ledger and not problems and not args.plan:
        return 0

    if ledger or problems:
        print("")
        print("SUMMARY: 写入 {0} 条 · 跳过 {1} 条 · 失败/未验证 {2} 条".format(total_write, total_skip, total_fail))
        print("LEDGER: {0}".format(ledger_path))
        if problems:
            print("PROBLEMS:")
            for p in problems:
                print("  - " + p)
            return 1
        if not ledger:
            print("NOTE: 本轮没有任何需要动作的 listing（不是失败）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
