# 前置：BrowserSkill（bsk）+ 交付自检

本技能的操作面依赖 **bsk（browser-skill）** —— 它让 agent 通过 Chrome 扩展直接读/写页面 DOM（无需截图猜坐标）。
客户机需要两件事，**都不需要管理员权限**：装 `bsk` CLI + 在 Chrome 里手动装扩展。

## 1. 客户端要做的（人工，一次）

1. 装 CLI：`curl -fsSL <官方安装脚本> | sh`（按官方文档为准）→ 确认 `bsk --version` 有输出。
2. Chrome 装上 browser-skill 扩展（Chrome 商店或官方给的 crx）。
3. 保持 Chrome 打开并登录卖家后台 `https://sellers.takealot.com`。
4. 跑自检：`python3 preflight.py` → 6/6 通过就能开工。

## 2. bsk 内置自检（出问题时先跑它）

```sh
bsk doctor      # 守护进程 / 扩展连接 / 协议兼容 逐项 ok|fail + 修复提示
bsk browsers    # 看哪个 Chrome 实例连上了（INSTANCE / EXT 版本 / 会话数）
bsk session list
```
实测输出形状：`ok daemon running` / `ok extension connected` / `ok browser protocol compatible`。

## 3. 会话约定（引擎已内置，客户不需要记）

- `bsk session start` 默认对着**唯一连上的浏览器**起会话；客户机通常不需要 instance id。
- 引擎把 SID 写进 `$BSK_SID_FILE`（默认 `/tmp/bsk_sid`），`bskhelp.py` 从那里读。
- 多浏览器时才需要 `--browser <INSTANCE>`；`bsk browsers` 拿。

## 4. 没有 bsk 时的降级路径（不推荐，但保留）

| 场景 | 降级方案 | 代价 |
|---|---|---|
| 装不上扩展 | Firefox + Peekaboo/cliclick 纯像素方案（见 SKILL.md「定位与验证实战」） | 慢一个数量级，需网格标定（`scripts/grid.py` 的原始版本见 SKILL.md） |
| 只想抽源数据 | 浏览器里 `extract_listing.py`（直连 curl 会 403） | 无 |
| 只想看类目字段 | 页面里手抄字段名 | 易错，别用 |

## 5. 打包口径（要不要把 BrowserSkill 一起封装？）

**结论：不要把 bsk/扩展塞进技能包，但要把"装它+自检它"写成技能里的可执行步骤。**
理由：
- 扩展必须由人在 Chrome 里手动安装/启用（受商店与浏览器权限约束），塞文件也装不上。
- bsk 是官方渠道维护、会升级的组件；抄一份进包里 = 客户机上是旧版 + 以后各修各的。
- 真正需要"打包"的是**本技能自己的脚本与流程**（已放 `scripts/`），以及一条客户能自己跑出 PASS 的自检命令（`preflight.py`）。
所以交付物 = 技能目录（含 `scripts/`、`references/`、`templates/`）+ 一份浏览器扩展安装指引（本文档）+ 自检命令。

## 6. 平台限制备忘（交付前要看）

- **macOS + Windows 已内置**（`tl_engine.py` 里按 `sys.platform` / `IS_WIN` 分支）：
  - 剪贴板：macOS `pbpaste/pbcopy`；Windows `tkinter`（隐藏 root **常驻**——Windows 上剪贴板归窗口所有，root 销毁内容就丢），无 tkinter 才退回 PowerShell `Set-Clipboard`（UTF-16LE 经 base64 传入）。
  - 真实按键：macOS System Events `keystroke … using command down`；Windows `user32!keybd_event`（**ctypes 直调**，不走 SendKeys/PowerShell：少一层语法与执行策略风险）。实测序列：Ctrl↓ → key↓ → key↑ → Ctrl↑（VK 17/65/67/86）。
  - 窗口前台化：macOS 走 System Events AXRaise（按 `bsk window resize` 定的特征宽度精确定位）；Windows 走 `EnumWindows` + `GetWindowTextW` 标题匹配 → `SW_RESTORE` + `BringWindowToTop` + `SetForegroundWindow`，外层包了 try（抬窗口失败不致命，os_paste 靠读回断言判定）。
- **Windows 路径尚未在真机实测**（本机是 Intel Mac；Mac 上的验证只能到“结构层”）：已在 Mac 上用**假 windll 验过 `_key` 的调用序列与 VK 码**、用**桁模块验过 `_win_clip` 的调用序列**；`ctypes.WINFUNCTYPE` 是 Windows 专有（Mac 上不存在，所以函数内有降级分支）。交付前请在客户桌面上跑这两条自证：
  1. `python3 preflight.py` → “OS 粘贴原语”一项会报出 `keybd_event 可解析` 和剪贴板走 `tkinter` 还是 `powershell`（不弹 GUI、不按键，远程也能跑）。
  2. `python3 tl_engine.py --selftest-paste` → 打印 `PASS` 才是真的可用。它会开记事本/TextEdit，粘一段标记文本 → 全选复制回读比对，完事自动关窗口并还原剪贴板。
  macOS 上已实测：`[selftest] platform=mac raised=TextEdit expect='TL-PASTE-OK-…' got='TL-PASTE-OK-…' -> PASS`（同时证明“原语本身没问题，portal 那次失败是 agent 窗口不可前台化”）。
- Windows 上跑务必注意：必须在**交互桌面会话**里跑（SSH/Session 0、计划任务、服务里提不起前台窗口，键也会空放）。
- `preflight.py` 共 7 项：python / bsk CLI / bsk doctor / 起会话 / 后台登录态+新建页（**自带硬重置自愈**）/ 本地图片服务 / **OS 粘贴原语**。
- 浏览器缩放必须锁 100%（改过缩放 = 视觉指纹变，像素方案失效）。
- Chrome 与卖家的登录态不能靠脚本代填；未登录时新建页会跳 `/login`（`preflight.py` 会报出来）。
- 富文本写入还需要「Agent Window 在最前且是活动标签」，多窗口同名时会失手 → 跑前把其它 Chrome 窗口关掉；实在不行引擎会存草稿 + 打印待粘贴文本，人工粘一下即可（见 `references/pitfalls.md` G3）。
