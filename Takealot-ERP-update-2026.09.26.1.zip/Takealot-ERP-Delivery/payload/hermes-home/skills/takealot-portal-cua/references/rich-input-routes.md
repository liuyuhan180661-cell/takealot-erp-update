# 富文本输入路对照（title / description 的 Draft.js 编辑器）

> **结论先行**：**默认走纯 bsk 逐字真实按键**（不依赖任何扩展）；CDP 桥是**可选加速件**；
> 其余路径一律不要用。判据永远是**「提交后回读服务端」**（`scripts/verify_persisted.py <submission_id>`）——
> 页面状态（Draft 的 `editorState`）和 DOM 都**不算**：它们可以被 JS 改得一切正常而服务端是空的。

## 1. 实测对照（Intel Mac + Chrome + bsk 0.3.1，2026-09-26）

| 路 | 怎么触发 | 编辑器状态 | 服务端持久 | 吞吐 | 额外依赖 |
|---|---|---|---|---|---|
| ✅ **bsk 逐字真实按键（默认）** | `bsk press <键> --selector '[data-fieldid="description"] .public-DraftEditor-content'` | ✅ 精确（实测 477/477；标点/大小写/换行/破折号全过） | ✅ 已提交 listing 回读 **544 字** | **152 ms/字**（477 字 ≈ 104s） | 无（只要 bsk 本身） |
| ⚙️ **CDP 真实按键（加速件）** | 扩展 `tl-cdp-bridge`：CDP `Input.dispatchKeyEvent` 带 `text` | ✅ 精确（103/103、117/117、477/477） | ✅ 同等（同为可信输入事件） | **8 ms/字**（≈4s / 475 字） | 需装 `tl-cdp-bridge` 扩展 |
| ❌ fiber 注入 `EditorState`+`onChange` | JS 直接改 React 状态 | 有的能改、有的不动 | ❌ **不持久** | — | 无 |
| ❌ `bsk fill` | CLI 一次填 | 对 title 常写不进 | ❌ 不持久 | — | 无 |
| ❌ `document.execCommand('insertText')` / 合成 `beforeinput`+`paste` | 页面内造事件 | 有时能改状态 | ❌ 不持久 | — | 无 |
| ❌ CDP `Input.insertText` | 桥的 insertText 动作 | 只改 DOM | ❌ 不持久 | — | 需扩展 |
| ❌ OS 级 ⌘V 粘贴 | pbcopy + 系统按键 | 本机 3/3 轮 **0 字符**（Chrome 吞掉） | ❌ | — | — |

**为什么只有"真实按键"持久**：只有浏览器自己产生的键盘输入事件才会走应用自己的 `onChange` → 才会发到服务端；
JS 造的事件和直接改状态都绕过了这一层。

## 2. 切桥还是留 bsk：确定性判据（**不许猜**）

1. 现场探测：`python3 scripts/probe_input_routes.py`
   - **桥可用 = 收到 `tl-cdp-done` 事件往返**（唯一可信信号）。DOM 属性 `data-tl-cdp-bridge="1"` 只是辅助。
   - bsk 可用 = 命令在、`bsk status --json` 有 session、能对目标 selector 按键。
2. 判据（写死）：
   - 探测到桥 **且** 明确需要提速（大批量、客户接受多一个扩展）→ `TL_RICH=bridge`
   - 其余**一律默认 bsk**：部件更少、失效面最小；客户机上没人替你排扩展兼容问题
   - 桥探测失败时引擎自己会退回 bsk 并在日志里写 `cdp-keys 不可用（no tl-cdp-done event）`——这是**正常降级**，不是错误
3. **绝不"看着像装了就用"**：探测结果要落进报告（`reports/input_routes_<时间戳>.json`），谁跑的、哪条路、什么依据，都留痕。

## 3. 两种路都要做的收尾（否则会得到"看起来对"的假结果）

打完字**不要立刻判成败**——Draft 的**最后一次输入事件总是落后一步**（实测：打完 543 读到 542）：

| 现象 | 正确动作 | 禁止动作 |
|---|---|---|
| 短 1~40 字 | 轮询等服务端状态落定（最多 30s）→ 仍缺则**逐字补尾**（追加实测有效） | 别立刻"再打一遍整段"（会变重复） |
| 多出 1~N 字 | **全选 + `bsk press Delete` 清空后重打**（最多 1 次） | ❌ `bsk press Backspace` **实测无效**（状态不变），拿它做减法只会空转 |
| 末尾 ±2 字差 | 引擎**如实打警告并接受**（不伪装精确），提交后必须跑 `verify_persisted.py` 复核 | 别为了 1 个字把整条 listing 卡死 |

## 4. 环境速查

| 客户机情况 | 用哪条 | 备注 |
|---|---|---|
| 只装了 bsk | **bsk** | 唯一依赖，交付默认 |
| 你亲手装好了 `tl-cdp-bridge` | 先探测再决定 | 扩展改代码必须在 `chrome://extensions` 点"重新加载"才生效 |
| 没窗口 / `bsk status` 里没有浏览器 | 先修环境 | 见 `pitfalls.md` G4/G5（残留 headless 实例会 handoff 掉 `open -a`） |
| 客户数据不能出机 | bsk（本地按键） | 两条路都不发数据出去；这条只影响你来不来装扩展 |
