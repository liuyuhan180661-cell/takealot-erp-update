#!/usr/bin/env python3
"""终判：在**已落库的草稿**里用真实按键写 description → 直接去预览页提交 → 读服务端。

为什么这样测：
  · 整条向导跑一次的属性步偶发失败、耗时也长；草稿里属性/图片/分区都齐了，最省时。
  · 草稿"保存"不落富文本（已两次实测）→ 所以要验的是**提交**这条路径：编辑器状态里的文本，
    提交时会不会被一起写进服务端。

用法：python3 probe_draft_submit.py [submission_id]
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tl_engine as E  # noqa: E402

DESC = ("Durability check with CDP real keys, paragraph one.\n"
        "Second paragraph: verifying that submit persists the description.")


def open_form(sid):
    E.goto(f"https://sellers.takealot.com/single-product/{sid}")
    time.sleep(5)
    if not E._js("document.querySelectorAll('[data-fieldid]').length"):
        E._js("""(()=>{const b=Array.from(document.querySelectorAll('button'))
            .find(x=>x.innerText.trim()==='Edit'); if(b)b.click(); return true;})()""")
        for _ in range(24):
            time.sleep(1.5)
            if E._js("document.querySelectorAll('[data-fieldid]').length"):
                break
    return E._js("document.querySelectorAll('[data-fieldid]').length") or 0


def main():
    sid = sys.argv[1] if len(sys.argv) > 1 else "5552612"
    E.start_session()
    n = open_form(sid)
    print(f"草稿 {sid} 表单字段数={n}")
    if not n:
        print("FAIL 表单没渲染")
        return 1

    print("=== ① 真实按键写 description ===")
    try:
        how = E.fill_rich("description", DESC)
    except Exception as e:
        print("  写入失败:", str(e)[:160])
        return 1
    got = (E._rich_truth("description") or {}).get("text") or ""
    print(f"  写法={how}  真身 {len(got)}/{len(DESC)}  {'✅ 精确' if got == DESC else '❌ 不一致'}")

    print("=== ② 预览 → 提交 ===")
    try:
        E.continue_to_preview()
        print("  已进预览页; Submit 状态:", E.submit_button_state())
    except Exception as e:
        print("  进预览失败:", str(e)[:140])
    E.set_submission_name("Cables cdp %s" % time.strftime("%d %b %H%M"))
    time.sleep(2)
    print("  Submit 状态:", E.submit_button_state())
    try:
        E.submit()
        print("  提交调用完成")
    except Exception as e:
        print("  提交异常:", str(e)[:180])

    print("=== ③ 读服务端 ===")
    time.sleep(5)
    E.goto(E.SUBMISSIONS_URL)
    time.sleep(4)
    ids = E._js_json("""(()=>{const o=[];document.querySelectorAll('a[href*="/single-product/"]').forEach(a=>{
        const m=(a.getAttribute('href')||'').match(/\\/single-product\\/(\\d+)/); if(m)o.push(m[1]);});return o.slice(0,5);})()""") or []
    print("  最近 submission:", ids)
    for cand in ids[:3]:
        nn = open_form(cand)
        got = (E._rich_truth("description") or {}).get("text") or ""
        print(f"  {cand} (字段 {nn}): description 服务端 len={len(got)} head={got[:44]!r}")
        if len(got) > 0:
            print("\n结论: ✅ 提交后服务端有 description —— 富文本可全自动（真实按键），"
                  "不依赖 OS 键盘/剪贴板 → 定时任务无人值守成立")
            return 0
    print("\n结论: ❌ 提交后服务端仍为空（编辑器里有、服务端没有）")
    return 1


if __name__ == "__main__":
    sys.exit(main())
