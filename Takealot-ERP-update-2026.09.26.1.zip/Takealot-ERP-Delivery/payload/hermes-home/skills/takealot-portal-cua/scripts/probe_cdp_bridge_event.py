#!/usr/bin/env python3
"""CDP 桥接验收（事件口径版）：验证「CDP Input.insertText」能不能**真的写进去并持久化**。

两个坑都踩过：
  · MV3 内容脚本跑在**隔离世界** → 它设的 `window.__TL_CDP_*` 主世界看不到。一律走
    **DOM 事件**（跨世界有效）：页面派发 `tl-cdp-insert`，监听 `tl-cdp-done` 收结果。
  · 页面读回（Draft 状态 / DOM）都不代表存进去了 → 判据只能是「存草稿 → 重开 → 读服务端」。

用法：python3 probe_cdp_bridge_event.py
"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tl_engine as E  # noqa: E402

CAT = ["Consumer Electronics", "Electronic Accessories", "Cellphone Cables"]
TITLE = "CDP Bridge Test 60W USB Type-C Fast Charging Cable 1m"
DESC = ("CDP bridge durable write check line one.\n"
        "Second paragraph to verify multi-line persistence.\n"
        "Third line for good measure.")

ARM = """(() => {
  window.__TL_DONE = null;
  if (!window.__TL_LISTENER) {
    document.addEventListener('tl-cdp-done', e => { window.__TL_DONE = e.detail; });
    window.__TL_LISTENER = true;
  }
  return true;
})()"""


def dom_text(fid):
    return E._js("""(()=>{const ed=document.querySelector('[data-fieldid="%s"] [contenteditable="true"]');
return ed?(ed.innerText||''):'';})()""" % fid) or ""


def bridge_insert(fid, text, timeout=12.0):
    E._js(ARM)
    E._js("""(() => {
      document.dispatchEvent(new CustomEvent('tl-cdp-insert', {detail: {
        id: %s, selector: '[data-fieldid="%s"]', text: %s
      }}));
      return true;
    })()""" % (json.dumps(fid + "-" + str(int(time.time()))), fid, json.dumps(text)))
    t0 = time.time()
    while time.time() - t0 < timeout:
        time.sleep(0.4)
        d = E._js_json("window.__TL_DONE || null")
        if d:
            return d
    return {"ok": False, "err": "no tl-cdp-done event（扩展没加载 / 内容脚本没注入）"}


def main():
    E.start_session()
    E.open_new_listing()
    E.pick_category(CAT)
    if not (E._js("document.querySelectorAll('[data-fieldid]').length") or 0):
        print("FAIL 字段没渲染出来")
        return 1

    print("=== ① 桥接写入（CDP Input.insertText，可信事件）===")
    for fid, val in (("title", TITLE), ("description", DESC)):
        r = bridge_insert(fid, val)
        time.sleep(1.0)
        d = len(dom_text(fid))
        print(f"  {fid}: 返回={r} DOM len={d} 期望={len(val)} -> {'✅ DOM 有真实内容' if d == len(val) else '❌'}")
        if not r.get("ok"):
            print("FAIL 桥接不可用，停止")
            return 2

    print("=== ② 存草稿 → 重开 → 核对服务端 ===")
    try:
        E.click_button(r"^Save and Close$", timeout=10)
    except Exception as e:
        print("  点保存失败:", str(e)[:100])
        return 1
    time.sleep(6)
    ids = E._js_json("""(()=>{const o=[];document.querySelectorAll('a[href*="/single-product/"]').forEach(a=>{
        const m=(a.getAttribute('href')||'').match(/\\/single-product\\/(\\d+)/); if(m)o.push(m[1]);});return o.slice(0,3);})()""") or []
    if not ids:
        print("FAIL 列表里没找到草稿")
        return 1
    sid = ids[0]
    E.goto(f"https://sellers.takealot.com/single-product/{sid}")
    time.sleep(4)
    if not E._js("document.querySelectorAll('[data-fieldid]').length"):
        E._js("""(()=>{const b=Array.from(document.querySelectorAll('button')).find(x=>x.innerText.trim()==='Edit');
            if(b)b.click(); return true;})()""")
        for _ in range(24):
            time.sleep(1.5)
            if E._js("document.querySelectorAll('[data-fieldid]').length"):
                break
    tp = E._rich_truth("title") or {}
    dp = E._rich_truth("description") or {}
    print(f"  草稿 {sid}")
    print(f"  title       期望 {len(TITLE):>3} → 服务端 {tp.get('len')}")
    print(f"  description 期望 {len(DESC):>3} → 服务端 {dp.get('len')}")
    ok = dp.get("len") == len(DESC)
    print("\n结论:", "✅ 持久化成功 —— 富文本可全自动、可无人值守（title 为 AutoBuild，服务端可为空）"
          if ok else "❌ 仍未持久化")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
