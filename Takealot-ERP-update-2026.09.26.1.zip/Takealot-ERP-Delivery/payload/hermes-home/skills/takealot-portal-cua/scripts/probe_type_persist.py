#!/usr/bin/env python3
"""逐字真实按键（CDP keyDown with text）→ 存草稿 → 重开 → 核对**服务端**。

为什么是这条路：
  · fiber 注入 / bsk fill / CDP Input.insertText → 只改页面，服务端为空 ✗
  · 页面内合成 paste/beforeinput → 同上 ✗
  · OS 真粘贴 → 能持久 ✓（但本机合成按键进不了 Chrome）
  · Draft 的逐字输入走 **keypress**，而 CDP `Input.dispatchKeyEvent` 带 `text` 是真实字符输入
    → 这是剩下唯一"真实且可自动化"的输入。

前置：扩展已加载，且 chrome://extensions 上点过「重新加载」（本版新增 typeText 动作）。

用法：python3 probe_type_persist.py [title|description|both]
"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tl_engine as E  # noqa: E402

CAT = ["Consumer Electronics", "Electronic Accessories", "Cellphone Cables"]
TITLE = "Typed Via Real Keys 60W USB Type-C Cable 1m"
DESC = ("Typed with real CDP key events, paragraph one.\n"
        "Second paragraph to verify multi-line persistence.")

ARM = """(() => {
  window.__TL_DONE = null;
  if (!window.__TL_LISTENER) {
    document.addEventListener('tl-cdp-done', e => { window.__TL_DONE = e.detail; });
    window.__TL_LISTENER = true;
  }
  return document.documentElement.getAttribute('data-tl-cdp-bridge');
})()"""


def state_len(fid):
    return (E._rich_truth(fid) or {}).get("len")


def dom_len(fid):
    return len(E._js("""(()=>{const ed=document.querySelector('[data-fieldid="%s"] [contenteditable="true"]');
        return ed?(ed.innerText||''):'';})()""" % fid) or "")


def bridge(fid, text, action="typeText", timeout=120.0):
    flag = E._js(ARM)
    if flag != "1":
        return {"ok": False, "err": "桥接未就绪（扩展没加载/没重新加载）"}
    E._js("""(() => {
      document.dispatchEvent(new CustomEvent('tl-cdp-insert', {detail: {
        id: %s, action: %s, selector: '[data-fieldid="%s"]', text: %s
      }}));
      return true;
    })()""" % (json.dumps(fid + "-" + str(int(time.time()))), json.dumps(action), fid, json.dumps(text)))
    t0 = time.time()
    while time.time() - t0 < timeout:
        time.sleep(0.5)
        d = E._js("""(() => { try { return JSON.stringify(window.__TL_DONE || null); }
            catch (e) { return 'null'; } })()""")
        try:
            d = json.loads(d) if isinstance(d, str) else d
        except Exception:
            d = None
        if d:
            return d
    return {"ok": False, "err": "no tl-cdp-done"}


def main():
    which = sys.argv[1] if len(sys.argv) > 1 else "both"
    E.start_session()
    E.open_new_listing()
    E.pick_category(CAT)
    if not (E._js("document.querySelectorAll('[data-fieldid]').length") or 0):
        print("FAIL 字段没渲染出来")
        return 1

    print("=== ① 逐字真实按键写入 ===")
    for fid, val in (("title", TITLE), ("description", DESC)):
        if which not in ("both", fid):
            continue
        r = bridge(fid, val)
        time.sleep(1.5)
        s, d = state_len(fid), dom_len(fid)
        ok = (s == len(val))
        print(f"  {fid}: {r}")
        print(f"     状态={s} DOM={d} 期望={len(val)} -> {'✅ 编辑器接受' if ok else '❌'}")

    print("=== ② 存草稿 → 重开 → 读服务端 ===")
    try:
        E.click_button(r"^Save and Close$", timeout=10)
    except Exception as e:
        print("  保存失败:", str(e)[:100])
        return 1
    time.sleep(6)
    ids = E._js_json("""(()=>{const o=[];document.querySelectorAll('a[href*="/single-product/"]').forEach(a=>{
        const m=(a.getAttribute('href')||'').match(/\\/single-product\\/(\\d+)/); if(m)o.push(m[1]);});return o.slice(0,3);})()""") or []
    if not ids:
        print("FAIL 列表里没找到草稿")
        return 1
    sid = ids[0]
    E.goto(f"https://sellers.takealot.com/single-product/{sid}")
    time.sleep(4)
    if not E._js("document.querySelectorAll('[data-fieldid]').length"):
        E._js("""(()=>{const b=Array.from(document.querySelectorAll('button')).find(x=>x.innerText.trim()==='Edit');
            if(b)b.click(); return true;})()""")
        for _ in range(24):
            time.sleep(1.5)
            if E._js("document.querySelectorAll('[data-fieldid]').length"):
                break
    tp, dp = E._rich_truth("title") or {}, E._rich_truth("description") or {}
    print(f"  草稿 {sid}")
    print(f"  title       期望 {len(TITLE)} → 服务端 {tp.get('len')}")
    print(f"  description 期望 {len(DESC)} → 服务端 {dp.get('len')}")
    ok = (dp.get("len") or 0) > 0
    print("\n结论:", "✅ 逐字真实按键可持久化 —— 富文本全自动成立（无人值守可用）" if ok
          else "❌ 仍不持久")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
