#!/usr/bin/env python3
"""用「已落库的草稿」测富文本持久化：写 description → 预览 → 提交 → 读服务端。

为什么走草稿：整条向导流程里属性步骤偶发失败（`merchant_packaged_dimensions.width` 读回空），
而草稿里属性已经齐了 → 直接接着写富文本并提交，最快回答"提交后服务端到底有没有"。

用法：python3 probe_submit_persist.py [submission_id] [description|title]
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tl_engine as E  # noqa: E402

DESC = ("Durability check via CDP real keys, paragraph one.\n"
        "Second paragraph, verifying submit-time persistence.")
TITLE = "CDP Keys Submit Check 60W USB Type-C Cable"


def main():
    sid = sys.argv[1] if len(sys.argv) > 1 else "5552612"
    fid = sys.argv[2] if len(sys.argv) > 2 else "description"
    val = DESC if fid == "description" else TITLE
    E.start_session()
    E.goto(f"https://sellers.takealot.com/single-product/{sid}")
    time.sleep(5)
    if not E._js("document.querySelectorAll('[data-fieldid]').length"):
        E._js("""(()=>{const b=Array.from(document.querySelectorAll('button')).find(x=>x.innerText.trim()==='Edit');
            if(b)b.click(); return true;})()""")
        for _ in range(24):
            time.sleep(1.5)
            if E._js("document.querySelectorAll('[data-fieldid]').length"):
                break
    n = E._js("document.querySelectorAll('[data-fieldid]').length")
    print(f"草稿 {sid} 表单字段数={n}  {fid} 真身={(E._rich_truth(fid) or {}).get('len')}")
    if not n:
        print("FAIL 表单没渲染")
        return 1

    print("=== ① 写入（CDP 真实按键）===")
    try:
        how = E.fill_rich(fid, val)
    except Exception as e:
        print("  写入失败:", str(e)[:160])
        return 1
    got = (E._rich_truth(fid) or {}).get("text") or ""
    print(f"  写法={how}  真身 {len(got)} / 期望 {len(val)}  {'✅ 精确' if got == val else '❌ 不一致'}")

    print("=== ② 存草稿 → 预览 → 提交 ===")
    E.click_button(r"^Save and Close$", timeout=10)
    time.sleep(6)
    E.goto(E.SUBMISSIONS_URL)
    time.sleep(3)
    opened = E._js("""(()=>{const tr=document.querySelector('table tbody tr');
        if(!tr) return 'no-row';const b=[...tr.querySelectorAll('button,a')].find(x=>/^(Edit|Continue|Resume|Open)$/i.test((x.textContent||'').trim()));
        if(!b) return 'no-open'; b.click(); return 'opened';})()""")
    print(f"  列表重开: {opened}")
    time.sleep(6)
    if E._js("""/Continue to Preview/i.test(document.body.innerText||'')"""):
        E.click_button(r"Continue to Preview", timeout=10)
        time.sleep(5)
    E.set_submission_name("Cables cdp %s" % time.strftime("%d %b %H%M"))
    time.sleep(2)
    print("  Submit 状态:", E.submit_button_state())
    try:
        E.submit()
    except Exception as e:
        print("  提交异常:", str(e)[:160])

    print("=== ③ 读服务端 ===")
    time.sleep(5)
    E.goto(E.SUBMISSIONS_URL)
    time.sleep(3)
    ids = E._js_json("""(()=>{const o=[];document.querySelectorAll('a[href*="/single-product/"]').forEach(a=>{
        const m=(a.getAttribute('href')||'').match(/\\/single-product\\/(\\d+)/); if(m)o.push(m[1]);});return o.slice(0,4);})()""") or []
    print("  最近 submission:", ids)
    for cand in ids[:2]:
        E.goto(f"https://sellers.takealot.com/single-product/{cand}")
        time.sleep(4)
        if not E._js("document.querySelectorAll('[data-fieldid]').length"):
            E._js("""(()=>{const b=Array.from(document.querySelectorAll('button')).find(x=>x.innerText.trim()==='Edit');
                if(b)b.click(); return true;})()""")
            for _ in range(20):
                time.sleep(1.5)
                if E._js("document.querySelectorAll('[data-fieldid]').length"):
                    break
        got = (E._rich_truth(fid) or {}).get("text") or ""
        print(f"  {cand}: {fid} 服务端 len={len(got)}  head={got[:46]!r}")
        if len(got) > 0:
            print("\n结论: ✅ 提交后服务端有富文本 —— 全自动（含定时任务）成立")
            return 0
    print("\n结论: ❌ 提交后服务端仍为空")
    return 1


if __name__ == "__main__":
    sys.exit(main())
