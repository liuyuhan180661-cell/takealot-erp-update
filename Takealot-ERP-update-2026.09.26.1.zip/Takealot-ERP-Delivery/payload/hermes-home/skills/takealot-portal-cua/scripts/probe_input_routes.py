#!/usr/bin/env python3
"""现场探测：这台机器上富文本输入的两条路（纯 bsk / CDP 桥）哪条**真的可用**，并落成报告。

为什么要这个脚本（交付纪律）：
  · 默认路永远是**纯 bsk**（不依赖任何扩展、失效面最小）；桥只是**可选加速件**。
  · "装没装桥"必须用**确定性信号**判断（`tl-cdp-done` 事件往返），**不许让模型猜**。
  · MV3 内容脚本跑在**隔离世界** → 它设的 window 变量主世界读不到，只能靠 DOM 事件往返。

用法：
  python3 probe_input_routes.py             # 探测（会打开卖家后台新建页做往返验证）
  python3 probe_input_routes.py --no-nav    # 不导航，只测当前页面上的桥能不能往返
退出码：0 = bsk 可用；2 = bsk 都不可用（先修环境）；桥可用与否不影响退出码（只是加速件）。
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tl_engine as E  # noqa: E402
import bskhelp as B  # noqa: E402

ARM = """(() => {
  window.__TL_DONE = null;
  if (!window.__TL_LISTENER) {
    document.addEventListener('tl-cdp-done', e => { window.__TL_DONE = e.detail; });
    window.__TL_LISTENER = true;
  }
  return true;
})()"""


def probe_bsk():
    """bsk 可用性：① 命令在不在 ② 扩展/浏览器有没有连上 ③ **能不能真的在页面上求值**（正判据）。

    踩过的坑（2026-09-26 实测）：把 `session_count == 0` 当成"不可用"是**假阴性** ——
    session 是引擎按需创建的（`tl_engine.start_session()`），Chrome 在、扩展连着就够用。
    真正的正判据是"能在页面上跑一次 `_js` 并拿到结果"。
    """
    r = {"exe": shutil.which("bsk")}
    if not r["exe"]:
        r["ok"] = False
        r["reason"] = "找不到 bsk 命令（确认 $HOME/.local/bin 在 PATH 里）"
        return r
    try:
        r["version"] = (subprocess.run([r["exe"], "--version"], capture_output=True, text=True,
                                       timeout=20).stdout or "").strip()
    except Exception as e:
        r["version"] = f"(取版本失败: {str(e)[:60]})"
    r["extension_connected"] = False
    try:
        s = subprocess.run([r["exe"], "status", "--json"], capture_output=True, text=True, timeout=30).stdout or ""
        d = json.loads(s) if s.strip().startswith("{") else {}
        r["browsers"] = len(d.get("browsers") or [])
        r["extension_connected"] = r["browsers"] > 0
        r["sessions"] = sum(int(b.get("session_count") or 0) for b in (d.get("browsers") or []))
        if not r["extension_connected"]:
            r["ok"] = False
            r["reason"] = ("扩展没连上：Chrome 没开 / 窗口全关导致扩展休眠 / 残留 headless 实例占位 → "
                           "见 references/pitfalls.md G4/G5")
            return r
    except Exception as e:
        r["ok"] = False
        r["reason"] = f"bsk status 解析失败: {str(e)[:80]}"
        return r
    # ③ 正判据：起会话（若没有就创建）→ 页面上真跑一次求值
    try:
        E.start_session()
        r["session"] = B.sid()
        r["eval"] = E._js("1+1")
        r["ok"] = (r["eval"] == 2)
        if not r["ok"]:
            r["reason"] = f"页面求值异常（拿到 {r['eval']!r}）—— 检查是否停在 chrome:// 或扩展页面"
    except Exception as e:
        r["ok"] = False
        r["reason"] = f"起会话/页面求值失败: {str(e)[:120]}"
    return r


def probe_bridge(timeout=12.0):
    """桥可用性：**唯一可信信号 = 收到 tl-cdp-done 事件往返**。

    探测动作刻意无害：对 `body` 发一次空 insertText —— 目的只是看扩展**答不答**，不写任何内容。
    """
    r = {"dom_attr": None, "roundtrip": None, "ok": False}
    try:
        r["dom_attr"] = E._js("""document.documentElement.getAttribute('data-tl-cdp-bridge')""")
        E._js(ARM)
        E._js("""(() => { document.dispatchEvent(new CustomEvent('tl-cdp-insert', {detail: {
            id: 'probe-%d', action: 'insertText', selector: 'body', text: '' }})); return true; })()"""
              % int(time.time()))
        t0 = time.time()
        while time.time() - t0 < timeout:
            time.sleep(0.4)
            d = E._js_json("window.__TL_DONE || null")
            if d:
                r["roundtrip"] = d
                r["ok"] = bool(d.get("ok"))
                if not r["ok"]:
                    r["reason"] = f"扩展答了但动作失败：{str(d.get('err'))[:100]}"
                return r
        r["reason"] = "no tl-cdp-done event（扩展没加载 / 没注入到本页 / 需要在 chrome://extensions 点重新加载）"
    except Exception as e:
        r["reason"] = f"探测异常: {str(e)[:100]}"
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-nav", action="store_true", help="不导航到新建页，只测当前页面")
    a = ap.parse_args()

    out = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "host": os.uname().nodename}
    out["bsk"] = probe_bsk()
    print("① bsk :", json.dumps(out["bsk"], ensure_ascii=False))

    if not out["bsk"].get("ok"):
        print("FAIL bsk 不可用 —— 先把环境修好（Chrome 有窗口 + 扩展连上），桥只是加速件，不是替代品")
        _save(out, route="none")
        return 2

    # 登录态检查（本技能永不碰凭据：被踢回登录页就交人）
    out["url"] = E._js("location.href")
    if "/login" in (out["url"] or ""):
        out["login_required"] = True
        print("⚠ 卖家后台登录已失效（被踢回 %s）" % out["url"])
        print("  → 请人工登录后重跑本探测；**这不是技能故障**，也不要用任何自动方式过登录（本技能不碰凭据）")
        _save(out, route="bsk")
        return 3
    if not a.no_nav:
        try:
            E.open_new_listing()
            out["url"] = E._js("location.href")
        except Exception as e:
            out["nav_error"] = str(e)[:140]
            print("⚠ 打不开新建页（%s）—— 探测继续，但请人工确认后台状态" % out["nav_error"])

    out["bridge"] = probe_bridge()
    print("② 桥  :", json.dumps(out["bridge"], ensure_ascii=False))

    route = "bridge" if out["bridge"].get("ok") else "bsk"
    out["recommended_rich_route"] = route
    out["rule"] = "默认 bsk；桥只在探测到 tl-cdp-done 往返且明确需要提速时用（TL_RICH=bridge）"
    print(f"\n推荐富文本输入路: **{route}**"
          + ("（引擎默认就是它，无需设置）" if route == "bsk" else "（设 TL_RICH=bridge 生效）"))
    if route == "bsk" and out["bridge"].get("dom_attr") == "1":
        print("⚠ 注意：DOM 属性说桥在，但事件往返没答 → **按不可用处理**（DOM 属性不可信）")
    _save(out, route=route)
    return 0


def _save(out, route):
    d = os.path.join(E.WORKDIR, "reports")
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, f"input_routes_{time.strftime('%Y%m%d_%H%M%S')}.json")
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print("报告:", p)


if __name__ == "__main__":
    sys.exit(main())
