# TL CDP Bridge（Chrome 扩展，MV3）

给本地脚本用的**最小桥接**：让页面能通过 `chrome.debugger` 发 CDP `Input.insertText`。

## 为什么要它

Takealot 新建/编辑 listing 的 **title / description 是 Draft.js 富文本**。实测（2026-09-26）：

| 写入方式 | 页面读回 | **存进服务器** |
|---|---|---|
| React fiber 注入（`EditorState.createWithContent` + `onChange`） | ✅ 正常 | ❌ **存不进** |
| `bsk fill`（扩展的 fill） | ✅ 正常 | ❌ **存不进** |
| JS 合成 `beforeinput`/`paste` 事件 | ❌ 无效 | — |
| 逐字 CDP 按键（`bsk press`） | ❌ 无效 | — |
| OS 级真实粘贴（⌘V） | 视环境 | ✅ 存得进（已提交的 listing 就是它写的） |

⇒ 只有**浏览器自己派发的可信输入事件**才会走应用的 onChange → 才会持久化。
CDP `Input.insertText` 就是可信的，且不依赖 OS 键盘/剪贴板 → **可无人值守**。

## 安装（一次性，人工）

1. Chrome 打开 `chrome://extensions`
2. 右上角打开「开发者模式」
3. 点「加载已解压的扩展程序」，选择本目录（`tl-cdp-bridge`）
4. 加载后访问 sellers.takealot.com，控制台里 `window.__TL_CDP_BRIDGE` 应为 `true`

> 调试时会显示「TL CDP Bridge 正在调试此浏览器」提示条，属正常（用完即 detach）。

## 用法（脚本侧，无需直接接触扩展）

```js
document.dispatchEvent(new CustomEvent('tl-cdp-insert', {
  detail: { id: 'x', selector: '[data-fieldid="title"]', text: '要写入的文本' }
}));
// 结果异步写入 window.__TL_CDP_RESULT = {id, ok, err, len}
```

内容脚本负责先 focus + 选中目标元素（`Input.insertText` 插到「当前聚焦元素」的插入点），
background 负责 attach → `Input.insertText` → detach。

验收：`python3 probe_cdp_bridge.py`（写入 → 存草稿 → 重开 → 核对**服务端**值）。
