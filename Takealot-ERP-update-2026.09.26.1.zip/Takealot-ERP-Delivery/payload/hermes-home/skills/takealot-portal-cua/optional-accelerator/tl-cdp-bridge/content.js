// TL CDP Bridge — content script（只在 sellers.takealot.com 注入）
//
// 协议（引擎侧用 bsk evaluate 走这条路）：
//   document.dispatchEvent(new CustomEvent('tl-cdp-insert', {detail:{id, selector, text}}))
//   → 本脚本 focus/选中目标元素 → 让 background 发 CDP Input.insertText
//   → 结果写到 window.__TL_CDP_RESULT = {id, ok, err, len}
//
// 为什么要在页面里 focus：Input.insertText 插到「该标签页当前聚焦元素」的插入点，
// 所以必须先把目标元素的 DOM 焦点和选区设好（JS focus/selection 是有效的，只有合成
// 的输入事件不可信）。

function targetEl(selector) {
  if (!selector) return document.activeElement;
  const box = document.querySelector(selector);
  if (!box) return null;
  if (box.matches('[contenteditable="true"], input, textarea')) return box;
  return box.querySelector('[contenteditable="true"], input, textarea') || box;
}

function focusAndSelect(el, atEnd) {
  el.scrollIntoView({ block: "center", inline: "nearest" });
  el.focus();
  try {
    const sel = document.getSelection();
    sel.removeAllRanges();
    const range = document.createRange();
    const isField = el.matches("input, textarea");
    if (isField) {
      const n = (el.value || "").length;
      if (atEnd) el.setSelectionRange(n, n);
      else el.setSelectionRange(0, n);
    } else {
      range.selectNodeContents(el);
      if (atEnd) range.collapse(false); // 光标放末尾：用于"只补丢失的尾字符"
      sel.addRange(range);
    }
  } catch (e) {
    // 选区设不上不致命：insertText 会插到焦点处
  }
  return document.activeElement === el;
}

async function handleInsert(detail) {
  const out = { id: detail && detail.id, ok: false, err: null, len: 0 };
  try {
    const el = targetEl(detail && detail.selector);
    if (!el) {
      out.err = "target not found: " + (detail && detail.selector);
    } else {
      const focused = focusAndSelect(el, !!(detail && detail.atEnd));
      if (!focused) out.focused = false;
      const res = await chrome.runtime.sendMessage({
        type: "tl-cdp",
        action: (detail && detail.action) || "insertText",
        text: detail && detail.text,
        delayMs: (detail && detail.delayMs) || 8,
      });
      out.ok = !!(res && res.ok);
      out.err = (res && res.err) || null;
      out.len = (res && res.len) || 0;
    }
  } catch (e) {
    out.err = String((e && e.message) || e).slice(0, 200);
  }
  window.__TL_CDP_RESULT = out;
  document.dispatchEvent(new CustomEvent("tl-cdp-done", { detail: out }));
  return out;
}

document.addEventListener("tl-cdp-insert", (e) => {
  handleInsert(e && e.detail);
});

// 探活：确认桥装好了（引擎 preflight 用）
// 主世界可见的标记（内容脚本跑在隔离世界，window 变量主世界读不到 → 用 DOM 属性）
document.documentElement.setAttribute("data-tl-cdp-bridge", "1");
