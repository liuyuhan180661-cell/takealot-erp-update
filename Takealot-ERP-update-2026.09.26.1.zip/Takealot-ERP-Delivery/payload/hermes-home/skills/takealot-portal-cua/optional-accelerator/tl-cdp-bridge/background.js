// TL CDP Bridge — background service worker
// 收到内容脚本的请求后，用 chrome.debugger 发 CDP Input.insertText（可信事件）。
//
// 为什么需要这个：macOS/Chrome 会把 OS 级合成按键吞掉（⌘V 到不了页面），
// 而 JS 合成的 beforeinput/paste 是**不可信事件**，Draft.js 拒收。
// CDP 的 Input.insertText 由浏览器自己派发（isTrusted=true），Draft 认。

const CDP_VERSION = "1.3";

async function attach(tabId) {
  try {
    await chrome.debugger.attach({ tabId }, CDP_VERSION);
    return true;
  } catch (e) {
    const m = String((e && e.message) || e);
    // 已经附着（可能是别的调试器/自己上次没 detach 干净）→ 直接复用
    if (/already attached/i.test(m)) return true;
    throw e;
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== "tl-cdp") return; // 不是给我们的
  const tabId = sender && sender.tab && sender.tab.id;
  if (tabId == null) {
    sendResponse({ ok: false, err: "no sender tab" });
    return;
  }
  (async () => {
    let attached = false;
    try {
      attached = await attach(tabId);
      if (msg.action === "insertText") {
        await chrome.debugger.sendCommand({ tabId }, "Input.insertText", {
          text: String(msg.text == null ? "" : msg.text),
        });
        sendResponse({ ok: true, action: "insertText", len: String(msg.text || "").length });
      } else if (msg.action === "typeText") {
        // **逐字真实按键**：Puppeteer 同款做法 —— keyDown 带 text（Chrome 会当成真实字符输入，
        // 走 Draft 的 keypress 路径）。实测 `Input.insertText` 只改 DOM、Draft 状态不动。
        const text = String(msg.text == null ? "" : msg.text);
        let sent = 0;
        for (const ch of text) {
          if (ch === "\n") {
            await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
              type: "keyDown", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13, text: "\r",
            });
            await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
              type: "keyUp", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13,
            });
          } else {
            await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
              type: "keyDown", text: ch, unmodifiedText: ch, key: ch,
            });
            await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
              type: "keyUp", key: ch,
            });
          }
          sent++;
          await new Promise((r) => setTimeout(r, msg.delayMs || 8));
        }
        sendResponse({ ok: true, action: "typeText", sent: sent });
      } else if (msg.action === "key") {
        // 可信按键（如 Delete / Backspace）——用于"多打了字符"时把尾巴删干净
        const key = msg.key || "Delete";
        const codeMap = {
          Delete: { key: "Delete", code: "Delete", windowsVirtualKeyCode: 46 },
          Backspace: { key: "Backspace", code: "Backspace", windowsVirtualKeyCode: 8 },
        };
        const k = codeMap[key] || codeMap.Delete;
        const n = Math.max(1, Math.min(200, msg.count || 1));
        for (let i = 0; i < n; i++) {
          await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
            type: "rawKeyDown",
            key: k.key,
            code: k.code,
            windowsVirtualKeyCode: k.windowsVirtualKeyCode,
          });
          await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
            type: "keyUp",
            key: k.key,
            code: k.code,
            windowsVirtualKeyCode: k.windowsVirtualKeyCode,
          });
        }
        sendResponse({ ok: true, action: "key", key, count: n });
      } else {
        sendResponse({ ok: false, err: "unknown action: " + msg.action });
      }
    } catch (e) {
      sendResponse({ ok: false, err: String((e && e.message) || e).slice(0, 300) });
    } finally {
      // 保持附着会一直显示 "正在调试此浏览器" 提示条；打完就 detach。
      if (attached) {
        try {
          await chrome.debugger.detach({ tabId });
        } catch (e) {
          /* 忽略：可能已被别的调试器接手 */
        }
      }
    }
  })();
  return true; // 异步 sendResponse
});
