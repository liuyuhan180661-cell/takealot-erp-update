#!/usr/bin/env python3
"""1688 货源配对核心（CONTRACT v5）。

设计约束（**不要违反**）
--------------------------------------------------------------------------------
1. **模型渠道不在代码里**。只从 `state/supplier.json` 读，三种模式：
     "openai" → POST `{base_url}/chat/completions`（任何 OpenAI 兼容端点；
                测试期指向本机代理就是免费通道，**这是配置、不是代码**）
     "hermes" → 调用本机 `hermes chat -q … --oneshot`（用客户自己配置的模型套餐）
     ""       → **不判定**：只取候选并标 `needs_review`
   → 客户机上没有任何免费通道也**照常可用**：取到候选入库、等模型或人工来判。
2. **1688 那条调用是唯一稀缺资源**（15~25s + 风控）。所以：
   - 候选取到就**落库缓存**，换规则/换模型**只重判不重搜**；
   - 搜索限速写进代码：间隔 ≥`min_gap_s`、单会话 ≤`max_per_session`，跨重启用状态文件计数。
3. 本模块**不被 plugin_api 导入**（避免循环）；它按需 `import plugin_api` 复用其状态读写。
"""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36")
APPKEY = "12574478"
MTOP_API = "mtop.1688.pc.plugin.imageSearch.plugin.search"
UPLOAD_URL = "https://search.1688.com/service/uploadErpImgSearch"
DETAIL_URL = "https://detail.1688.com/offer/{0}.html"

CONFIG_FILE = "supplier.json"
RUN_STATE_FILE = "supplier_match_state.json"

DEFAULT_CONFIG: Dict[str, Any] = {
    # 判定规则版本 —— 结果里会写死这个值，升级规则时可据此筛出旧结果重判。
    # v2 = 经 N=386 实测的严格规则（precision 84.4%）：规格/件数差异**不**否决，
    #      但品牌 / 结构 / 品类 / 材质档位不同 = 不同款。
    "rule": "v2",
    "model": {
        "mode": "",              # "openai" | "hermes" | ""（不判定）
        "base_url": "",          # 例: https://api.deepseek.com 或 http://127.0.0.1:8645/v1
        "model": "",             # 例: deepseek-flash / stepfun/step-5-preview:free
        # 备用模型链：主模型抖动/限流时**立刻切下一个**（"打热就切"），切换记进
        # state/supplier_switch.jsonl。客户机上换成客户自己的套餐即可，与代码无关。
        "fallback_models": [],
        "key_env": "",           # 从环境变量取 key（推荐）
        "api_key": "",           # 直填 key（不推荐，优先 key_env）
        "timeout_s": 180,
        "temperature": 0,
    },
    "search": {
        "enabled": True,
        "pages": 3,              # 每页 20 条
        # 串行闸（concurrency<=1 时生效）：两次搜索的最小真实间隔。这条是**浏览器通道**的实测
        # 安全线（16.5s）；纯 HTTP 图搜通道实测 6 并发持续 25 分钟 0 拦截 → 默认走并行，见下。
        "min_gap_s": 20,
        "max_per_session": 25,   # 单会话上限（实测 22 次连发 0 拦截）——并行模式下按一次运行计
        "timeout_s": 45,
        "jar": "/tmp/erp-1688-imgsearch.jar",
        "candidates_keep": 15,   # 送去判定的候选条数（按 1688 相似度降序取前 N）
        "max_wait_s": 120,       # 批量任务为等限速窗口最多睡多久（防配置写错后无限等）
        # ---- 并行模式（默认开）：把「串行 20s 闸」换成「全局令牌桶 + 连续失败退避」。
        # 为什么能并行：图搜是纯 HTTP（upload + mtop 分页），无浏览器/无登录/无 cookie，
        # 实测 6 并发、约 1 次请求/秒持续 25 分钟 0 滑块 0 登录墙；串行的 20s 间隔是给
        # 浏览器通道留的余量，用在纯 HTTP 上白等 20s/条（386 条多等 2 小时）。
        "concurrency": 6,        # 并行 worker 数；<=1 回退到旧的串行 20s 闸
        "rate_per_s": 2.0,       # 全局起搜速率（令牌桶，所有 worker 共享）
        "fail_cooldown_s": 180,  # 连续失败 N 次 → 全局冷却多久（疑似风控/滑块）
        "max_consecutive_fail": 3,  # 连续失败多少次触发冷却；累计翻倍则整轮收工
    },
    # 件重尺（1688 包装尺寸/重量）：只影响履约费（DC 费）核算，不影响配对本身。
    #   "defer"（默认）= 配对完立刻返回，件重尺进后台队列慢慢补 → 配对不被它拖住；
    #   "inline"       = 老行为（匹配成功当场抓，最坏 25s 匿名超时 + 90s headless Chrome）。
    # 实测教训：抓不到时它会把每条配对拖慢 25~60s，而成功率只有约 1/5。
    # engine：
    #   "auto"（默认）= 本机有 bsk（BrowserSkill）+ 连着的 **Chrome** 就用它（实测 4s/条），否则回落
    #                  headless 一次性渲染（实测 80s/条）。客户不装扩展也能用，装了的人快 20 倍。
    #   "bsk"        = 只用浏览器会话（拿不到就如实报，不降级）
    #   "headless"   = 只用 headless 一次性渲染
    # bsk_browser  : 要求浏览器名包含这个子串（默认 "chrome"）。**别用 Edge** —— 多环境下
    #                Edge 的 CDP/扩展行为更差（导航慢、get-html 截断、窗口复用怪），同一套动作在
    #                Chrome 上才稳定。客户机默认浏览器是什么不重要，我们只认 Chrome 实例。
    "pack": {"mode": "defer", "engine": "auto", "bsk_browser": "chrome"},
    # 判定段并发（阶段②）：判定不碰 1688（只打模型），可以与图搜并发解耦。
    # 为什么单列一个数：混在一个池里时判定只能吃到图搜的并发（6），而判定 p50 15.4s/条比图搜还贵。
    "judge": {"concurrency": 8, "batch": 2},
    "batch": {"max_items": 25},
}

# ---------------------------------------------------------------- 状态与配置


def _api() -> Any:
    """拿到已加载的 plugin_api 模块。

    **不能写 ``import plugin_api``**：部署形态下核心文件在 ``server/core/``，那个目录不一定在
    sys.path 上（实测装出来的服务上会 ModuleNotFoundError）。所以：
    ① 先按名字找已加载的那份；② 再按“谁有 STATE_DIR + supplier_pair_put”找；③ 最后按路径加载。
    """
    mod = sys.modules.get("plugin_api")
    if mod is not None and hasattr(mod, "STATE_DIR"):
        return mod
    for cand in list(sys.modules.values()):
        if cand is not None and hasattr(cand, "STATE_DIR") and hasattr(cand, "supplier_pair_put"):
            return cand
    import importlib.util
    path = Path(__file__).resolve().parent / "plugin_api.py"
    spec = importlib.util.spec_from_file_location("plugin_api", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("拿不到 plugin_api 模块（找不到 %s）" % path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules.setdefault("plugin_api", mod)
    spec.loader.exec_module(mod)
    return mod


def state_dir() -> Path:
    try:
        return Path(_api().STATE_DIR)
    except Exception:
        return Path(os.path.expanduser("~/.takealot-erp/state"))


def _json_read(path: Path, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def _json_write(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def _num(mapping: Dict[str, Any], key: str, default: Any) -> Any:
    """取数值配置：**显式 0 必须生效**。

    坑：`cfg.get(k) or default` 会让「配 0 想关掉」静默回落默认值
    （实测：min_gap_s=0 想关闭限速，结果仍按 20s 拦）。这里只用 None 判缺失。
    """
    v = (mapping or {}).get(key)
    if v is None or v == "":
        return default
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _int(mapping: Dict[str, Any], key: str, default: int) -> int:
    return int(_num(mapping, key, default))


def _deep_merge(base: Dict[str, Any], over: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def config() -> Dict[str, Any]:
    """配置 = 默认值 ⊕ state/supplier.json（客户可只写差异部分）。"""
    raw = _json_read(state_dir() / CONFIG_FILE, {})
    return _deep_merge(DEFAULT_CONFIG, raw if isinstance(raw, dict) else {})


def run_state() -> Dict[str, Any]:
    st = _json_read(state_dir() / RUN_STATE_FILE, {})
    return st if isinstance(st, dict) else {}


def _save_run_state(st: Dict[str, Any]) -> None:
    _json_write(state_dir() / RUN_STATE_FILE, st)


# ---------------------------------------------------------------- 并发闸（并行模式）

class _Pacer:
    """全局起搜闸：令牌桶 + 连续失败退避。串行路径不用它（走 _rate_gate）。

    为什么需要「全局」：风控看的是**整个会话的请求速率**，不是单个线程。N 个 worker
    各自 sleep 等于把速率乘 N —— 必须集中节流，否则并行只是把 IP 打进风控。
    """

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.starts: List[float] = []
        self.consec_fail = 0
        self.total_fail = 0
        self.cooldown_until = 0.0
        self.searches = 0
        self.cooldowns = 0

    def acquire(self, rate_per_s: float, max_wait_s: float) -> None:
        """等到允许起下一次搜索。冷却期超过 max_wait_s 直接抛（整轮该收工）。"""
        waited = 0.0
        while True:
            with self.lock:
                now = time.time()
                if now < self.cooldown_until:
                    nap = self.cooldown_until - now
                else:
                    self.starts = [t for t in self.starts if now - t < 1.0]
                    cap = max(1, int(rate_per_s))
                    if len(self.starts) < cap:
                        self.starts.append(now)
                        self.searches += 1
                        return
                    nap = 1.0 - (now - min(self.starts))
            if waited + max(0.0, nap) > max_wait_s:
                raise RuntimeError("图搜全局冷却中（还需 %.0fs，疑似风控）" % nap)
            time.sleep(max(0.02, min(nap, 1.0)))
            waited += max(0.02, min(nap, 1.0))

    def ok(self) -> None:
        with self.lock:
            self.consec_fail = 0

    def fail(self, cooldown_s: float, threshold: int) -> float:
        """记一次失败；连续失败到阈值就开全局冷却。返回冷却秒数（0=没冷却）。"""
        with self.lock:
            self.consec_fail += 1
            self.total_fail += 1
            if self.consec_fail >= max(1, threshold):
                self.cooldown_until = time.time() + cooldown_s
                self.consec_fail = 0
                self.cooldowns += 1
                return cooldown_s
            return 0.0

    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {"searches": self.searches, "fails": self.total_fail,
                    "cooldowns": self.cooldowns,
                    "coolingFor": round(max(0.0, self.cooldown_until - time.time()), 1)}


_PACER = _Pacer()
_PHASE: Dict[str, Any] = {}          # 上一轮两阶段的耗时（诊断用，随 run() 返回）

# 件重尺后台队列（defer 模式）：配对不被 1688 详情页拖住。
# 用一个 daemon 线程串行消化 —— 详情页抓取本来就慢（25s 超时 / 90s headless），并行只会
# 同时撞登录墙、弹出多个登录窗。
_PACK_LAST: Dict[str, Any] = {}      # 上一轮件重尺的统计（通道/成功/失败/单条耗时，诊断用）
_PACK_QUEUE: List[tuple] = []
_PACK_MU = threading.Lock()
_PACK_RUNNING = [False]


def _pack_worker() -> None:
    """件重尺后台队列：串行消化（浏览器 profile 单实例，并行只会互抢）。

    通道选择（`pack.engine`）：
      - auto（默认）：本机有 bsk + 连着 **Chrome** → 走浏览器会话（实测 2~8s/条）；否则 headless（~80s/条）。
      - bsk / headless：只用指定通道。
    浏览器通道连续失败 3 次 → 当场停掉会话、回落 headless（慢但稳），并把原因写进日志，
    免得「一直在跑但什么都没拿到」。
    """
    api = _api()
    pc = (config().get("pack") or {})
    engine = str(pc.get("engine") or "auto")
    bsk = _bsk_bin() if engine in ("auto", "bsk") else None
    browser = _bsk_pick_browser(bsk, str(pc.get("bsk_browser") or "chrome")) if bsk else None
    sess = _bsk_session_start(bsk, browser) if (bsk and browser) else None
    if engine == "bsk" and not sess:
        log.warning("takealot-erp: pack.engine=bsk 但没有可用的 Chrome 会话"
                    "（bsk 未安装/未连接/只连了非 Chrome）→ 本轮件重尺跳过")
        with _PACK_MU:
            _PACK_QUEUE.clear()
            _PACK_RUNNING[0] = False
        return
    use_bsk = bool(sess)
    bsk_fail = 0
    _PACK_LAST.clear()
    _PACK_LAST.update(engine=engine, via=("bsk" if use_bsk else "headless"), ok=0, miss=0, err=0)
    try:
        while True:
            with _PACK_MU:
                if not _PACK_QUEUE:
                    _PACK_RUNNING[0] = False
                    return
                plid, offer_id = _PACK_QUEUE.pop(0)
            st = pack_state()
            try:
                last = float(st.get("loginRequiredAt") or 0)
            except (TypeError, ValueError):
                last = 0.0
            # 登录墙 6h 冷却期内直接清空队列：继续试只会重复弹窗、重复等超时。
            if last and time.time() - last < 6 * 3600:
                with _PACK_MU:
                    _PACK_QUEUE.clear()
                    _PACK_RUNNING[0] = False
                log.info("takealot-erp: 件重尺暂停（1688 登录墙冷却中）")
                return
            pack: Dict[str, Any] = {}
            if use_bsk:
                t0 = time.time()
                try:
                    pack = fetch_offer_pack_bsk(offer_id, bsk, sess)
                    _PACK_LAST["lastSec"] = round(time.time() - t0, 1)
                    bsk_fail = 0
                except Exception as exc:
                    bsk_fail += 1
                    _PACK_LAST["err"] = _PACK_LAST.get("err", 0) + 1
                    log.warning("takealot-erp: 浏览器取件重尺失败(%d/3) %s: %s",
                                bsk_fail, offer_id, str(exc)[:120])
                    if bsk_fail >= 3:
                        use_bsk = False
                        _bsk_session_stop(bsk, sess)
                        sess = None
                        _PACK_LAST["via"] = "headless"
                        log.warning("takealot-erp: 浏览器通道连续失败 → 回落 headless（约 80s/条）")
            if not use_bsk:
                try:
                    pack = fetch_offer_pack(offer_id)
                except Exception:
                    continue
            if not pack:
                _PACK_LAST["miss"] = _PACK_LAST.get("miss", 0) + 1
                continue
            _PACK_LAST["ok"] = _PACK_LAST.get("ok", 0) + 1
            try:
                rec = api.supplier_pair_get(plid)
                if isinstance(rec, dict) and str(rec.get("offerId") or "") == str(offer_id):
                    api.supplier_pair_put(plid, {"pack": pack})
                    api.collection_sync_supplier_pack(plid, pack)
            except Exception as exc:
                log.warning("takealot-erp: 件重尺回填失败 %s: %s", plid, exc)
    finally:
        if sess:
            _bsk_session_stop(bsk, sess)


def pack_stats() -> Dict[str, Any]:
    """件重尺通道的上一轮统计（界面/agent 用来说清「为什么没有尺寸」）。"""
    with _PACK_MU:
        queued = len(_PACK_QUEUE)
        running = bool(_PACK_RUNNING[0])
    return dict(_PACK_LAST, queued=queued, running=running)


def _pack_enqueue(items: List[tuple]) -> None:
    if not items:
        return
    with _PACK_MU:
        _PACK_QUEUE.extend(items)
        if _PACK_RUNNING[0]:
            return
        _PACK_RUNNING[0] = True
    threading.Thread(target=_pack_worker, name="tk-pack", daemon=True).start()
_WORKER_JAR = threading.local()   # 每个 worker 一个 cookie jar（共享 jar 会互相串味）


# ---------------------------------------------------------------- 1688 图搜


def _curl(args: List[str], timeout: int = 60) -> str:
    # --noproxy: 本机 Clash TUN 会把回环请求也当代理拦掉（实测 502），
    # 所以访问 127.0.0.1/本地端点（如本机模型代理）必须显式绕过。
    cmd = ["curl", "-sS", "--max-time", str(timeout), "-A", UA,
           "--noproxy", "127.0.0.1,localhost"] + args
    p = subprocess.run(cmd, capture_output=True, text=True)
    return p.stdout


PACK_ROW_RE = re.compile(r'"pieceWeightScaleInfo"\s*:\s*\[\s*(\{[^{}]*\})')
PACK_UNIT_RE = re.compile(r'"unitWeight"\s*:\s*([\d.]+)')


CHROME_BINS = ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
               "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
               r"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe")


def pack_profile_dir() -> Path:
    """1688 抓取专用浏览器 profile（人工登录一次，cookie 长期复用）。"""
    return state_dir().parent / "browser-1688"


def fetch_offer_html_browser(offer_id: str, timeout: int = 90) -> str:
    """用本机 Chrome（独立 profile）渲染 1688 详情页，返回 DOM。

    为什么要这条通道：1688 详情页对匿名请求大多返回 4.8KB 登录墙，
    「商品件重尺」(productPackInfo) 只有登录后才渲染。人工在那个 profile 登录一次后，
    这里用 headless 复用 cookie。

    实现要点：`chrome --headless --dump-dom` **dump 完不会自己退出**（实测进程一直挂着），
    所以不能等 subprocess.run 结束 —— 要边写边看输出文件，出现 productPackInfo 或体积稳定就收工。
    """
    chrome = next((b for b in CHROME_BINS if os.path.exists(b)), "")
    if not chrome:
        return ""
    # 没登录过就没有 cookie：直接放弃，不要每条都启一次 headless 白等 90s
    cookie = pack_profile_dir() / "Default" / "Cookies"
    try:
        if not cookie.exists() or cookie.stat().st_size < 1024:
            return ""
    except OSError:
        return ""
    profile = pack_profile_dir()
    try:
        profile.mkdir(parents=True, exist_ok=True)
    except OSError:
        return ""
    lock = profile / "SingletonLock"
    if lock.exists():
        # 锁里是 hostname-pid：进程活着才是真占用，残留锁直接清掉
        try:
            pid = int(os.readlink(str(lock)).rsplit("-", 1)[-1])
            alive = subprocess.run(["ps", "-p", str(pid)], capture_output=True).returncode == 0
            if not alive:
                lock.unlink()
        except (OSError, ValueError):
            try:
                lock.unlink()
            except OSError:
                pass
    if lock.exists():
        return ""

    cmd = [chrome, "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
           "--user-data-dir={0}".format(profile), "--virtual-time-budget=15000",
           "--window-size=1440,900", "--dump-dom", DETAIL_URL.format(offer_id)]
    tmp_name = str(state_dir() / "supplier_work" / ("pack_{0}.html".format(offer_id)))
    try:
        Path(tmp_name).parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        tmp_name = "/tmp/pack_{0}.html".format(offer_id)
    html = ""
    try:
        with open(tmp_name, "w", encoding="utf-8") as fh:
            proc = subprocess.Popen(cmd, stdout=fh, stderr=subprocess.DEVNULL)
        deadline = time.time() + max(20, timeout)
        last_size = 0
        stable = 0
        while time.time() < deadline:
            time.sleep(2)
            try:
                size = os.path.getsize(tmp_name)
            except OSError:
                size = 0
            stable = stable + 1 if size == last_size and size > 0 else 0
            last_size = size
            if size > 200000 and stable >= 2:
                break            # 体积稳定两轮 = 渲染完了
            if size > 200000 and proc.poll() is not None:
                break
        try:
            proc.kill()
        except OSError:
            pass
        with open(tmp_name, encoding="utf-8", errors="replace") as fh:
            html = fh.read()
    except OSError:
        return ""
    try:
        os.unlink(tmp_name)
    except OSError:
        pass
    return html


def parse_offer_pack(html: str, offer_id: str) -> Dict[str, Any]:
    """从 1688 详情页 DOM/HTML 里解析「商品件重尺」；取不到返回 {}。"""
    if not html:
        return {}
    out: Dict[str, Any] = {"offerId": str(offer_id), "source": "1688-pack", "weightKg": None,
                           "lengthCm": None, "widthCm": None, "heightCm": None,
                           "volumeCm3": None, "raw": None}

    def _f(value: Any) -> float:
        try:
            return float(value or 0)
        except (TypeError, ValueError):
            return 0.0

    row: Dict[str, Any] = {}
    match = PACK_ROW_RE.search(html)
    if match:
        try:
            row = json.loads(match.group(1))
        except ValueError:
            row = {}
        length, width, height = _f(row.get("length")), _f(row.get("width")), _f(row.get("height"))
        weight_g, volume = _f(row.get("weight")), _f(row.get("volume"))
        # 单位坑：1688 有的卖家填 cm、有的填 mm（实测空气炸锅 520/324/630 其实是 mm）。
        # 判据：任一维 > 200 → 按 mm 处理，换算成 cm / cm³。
        if max(length, width, height) > 200:
            length, width, height = length / 10.0, width / 10.0, height / 10.0
            volume = volume / 1000.0
        # 常识校验：卖家常填错单位/填 0.25 这种明显无效值 —— 不可信就当没有（不猜）
        sane = all(1.0 <= v <= 200.0 for v in (length, width, height))
        # 第二个坑（2026-10-20 实测）：卖家把「件重尺」填成 100×100×100cm 的整数立方体（1 m³/1kg），
        # 越界校验放得过，但体积算出来是 100 万 cm³ → DC 费会翻几倍，比没有更糟。
        # 判据：体积 > 30 万 cm³ 且重量 < 3kg（比值荒谬）→ 只保留重量，尺寸当没有。
        if sane:
            vol = (volume or length * width * height)
            if vol > 300000 and (not weight_g or weight_g < 3000):
                sane = False
        if length and width and height and sane:
            out.update(lengthCm=round(length, 2), widthCm=round(width, 2), heightCm=round(height, 2),
                       volumeCm3=round(volume or length * width * height, 1))
        if weight_g and 1 <= weight_g <= 100000:      # 1g~100kg 之外视为填错
            out["weightKg"] = round(weight_g / 1000.0, 3)
        if row:
            out["raw"] = json.dumps(row, ensure_ascii=False)[:200]
    if out["weightKg"] is None:
        unit = PACK_UNIT_RE.search(html)
        if unit:
            try:
                out["weightKg"] = round(float(unit.group(1)), 3)
            except ValueError:
                pass
    if not (out["weightKg"] or out["lengthCm"]):
        return {}
    return out


PACK_CACHE_FILE = "supplier_pack_cache.json"
PACK_STATE_FILE = "supplier_pack_state.json"
LOGIN_URL = "https://login.1688.com/member/signin.htm"
#: 登录失效时自动弹窗的冷却时间：1688 会话本来就短（真人也会频繁失效），
#: 但绝不因为一次失败就反复弹窗骚扰客户。
LOGIN_POPUP_COOLDOWN_S = 6 * 3600


def pack_state() -> Dict[str, Any]:
    try:
        data = json.loads((state_dir() / PACK_STATE_FILE).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_pack_state(**kw: Any) -> None:
    """写件重尺状态。**显式传 None = 清除该键**（`loginRequiredAt=None` 就是「登录已恢复」）。

    坑（实测 2026-10-20）：早期实现用 `if v is not None` 过滤，把「清除」也一起丢了 →
    `loginRequiredAt` 一旦写上就**永远清不掉**：界面一直显示「1688 登录失效」，后台队列也
    一直跳过件重尺，用户重新扫码后毫无恢复迹象（状态是粘性的）。
    """
    data = pack_state()
    for k, v in kw.items():
        if v is None:
            data.pop(k, None)
        else:
            data[k] = v
    try:
        path = state_dir() / PACK_STATE_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def looks_like_login_wall(html: str) -> bool:
    """判断拿回来的是不是 1688 登录墙（而不是商品页）。

    判据：正常详情页 2.8MB 且含 productPackInfo；登录墙约 4.8KB，正文出现登录相关字样。
    """
    if not html:
        return False
    if len(html) > 200000:
        return False
    text = html.lower()
    return len(html) < 12000 or "login.1688.com" in text or "passport" in text or "扫码登录" in html or "登录后" in html


def open_login_window(force: bool = False) -> bool:
    """弹出 1688 登录窗口（人工扫码一次）。

    只在**真的需要**时弹：登录墙 + 冷却期外 + 当前没有已开着的登录窗口。
    返回 True = 本次弹出去了。
    """
    profile = pack_profile_dir()
    lock = profile / "SingletonLock"
    if lock.exists():
        try:
            pid = int(os.readlink(str(lock)).rsplit("-", 1)[-1])
            alive = subprocess.run(["ps", "-p", str(pid)], capture_output=True).returncode == 0
        except (OSError, ValueError):
            alive = False
        if alive:
            return False          # 已经有一个窗口开着，别开第二个
    now = time.time()
    last = float(pack_state().get("loginPopupAt") or 0)
    if not force and now - last < LOGIN_POPUP_COOLDOWN_S:
        return False
    chrome = next((b for b in CHROME_BINS if os.path.exists(b)), "")
    if not chrome:
        return False
    try:
        profile.mkdir(parents=True, exist_ok=True)
        subprocess.Popen([chrome, "--user-data-dir={0}".format(profile), "--no-first-run",
                          "--no-default-browser-check", "--new-window", LOGIN_URL],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError:
        return False
    _save_pack_state(loginPopupAt=now, loginRequiredAt=now)
    return True
PACK_TTL_OK_S = 30 * 24 * 3600      # 抓到了：缓存 30 天
PACK_TTL_MISS_S = 7 * 24 * 3600     # 没抓到：7 天内不再试（防重复等 90s）


def _pack_cache() -> Dict[str, Any]:
    try:
        data = json.loads((state_dir() / PACK_CACHE_FILE).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _pack_cache_put(offer_id: str, payload: Dict[str, Any], ttl: Optional[int] = None) -> None:
    try:
        data = _pack_cache()
        data[str(offer_id)] = {"at": time.time(), "pack": payload or {},
                               "ttl": int(ttl) if ttl else None}
        if len(data) > 2000:
            for key in sorted(data, key=lambda k: data[k].get("at") or 0)[:500]:
                data.pop(key, None)
        path = state_dir() / PACK_CACHE_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def _bsk_bin() -> Optional[str]:
    """找 bsk（BrowserSkill CLI）。本机/客户机装了就有，没有就回落 headless。"""
    for cand in (os.environ.get("BSK_BIN") or "", "bsk",
                 os.path.expanduser("~/.local/bin/bsk"), "/opt/homebrew/bin/bsk", "/usr/local/bin/bsk"):
        if not cand:
            continue
        p = cand if os.path.isabs(cand) and os.path.exists(cand) else shutil.which(cand)
        if p:
            return p
    return None


def _bsk_pick_browser(bsk: str, want: str = "chrome", timeout: int = 15) -> Optional[str]:
    """挑一个「活的、且是 Chrome」的浏览器实例。

    **为什么钉 Chrome**：同一套 bsk 动作（navigate + get-html）在 Edge 上多环境表现明显更差
    （导航慢、HTML 截断、窗口复用异常）。客户机默认浏览器是不是 Chrome 与我们无关 ——
    我们只认 `browser_name` 含 "chrome" 的实例，没有就诚实回落，不去猜别的浏览器。
    """
    try:
        out = subprocess.run([bsk, "browsers", "--json"], capture_output=True, text=True,
                             timeout=timeout).stdout
        rows = json.loads(out or "[]")
    except Exception:
        return None
    want = (want or "chrome").strip().lower()
    for row in rows if isinstance(rows, list) else []:
        name = str(row.get("browser_name") or "").lower()
        if row.get("unresponsive") or not row.get("instance_id"):
            continue
        if want and want not in name:
            continue
        return str(row["instance_id"])
    return None


def _bsk_session_start(bsk: str, browser_id: str, timeout: int = 30) -> Optional[str]:
    try:
        out = subprocess.run([bsk, "session", "start", "--browser", browser_id, "--json"],
                             capture_output=True, text=True, timeout=timeout).stdout
        return str((json.loads(out or "{}") or {}).get("session_id") or "") or None
    except Exception:
        return None


def _bsk_session_stop(bsk: str, sess: str, timeout: int = 20) -> None:
    try:
        subprocess.run([bsk, "session", "stop", "--session", sess, "--quiet"],
                       capture_output=True, text=True, timeout=timeout)
    except Exception:
        pass


def fetch_offer_pack_bsk(offer_id: str, bsk: str, sess: str, timeout: int = 45) -> Dict[str, Any]:
    """用**已登录的浏览器会话**读商详拿件重尺（实测 2~8s/条，headless 要 80s）。

    走的是同一个 `parse_offer_pack`：bsk 拿回来的 HTML 里 `pieceWeightScaleInfo` 结构与 curl 版一致。
    """
    offer_id = str(offer_id or "").strip()
    if not offer_id or not bsk or not sess:
        return {}
    cached = _pack_cache().get(offer_id) or {}
    if isinstance(cached, dict) and cached.get("at"):
        age = time.time() - float(cached["at"])
        pack_cached = cached.get("pack") or {}
        if pack_cached and age < PACK_TTL_OK_S:
            return pack_cached
        miss_ttl = float(cached.get("ttl") or PACK_TTL_MISS_S)
        if not pack_cached and age < miss_ttl:
            return {}
    out_dir = state_dir() / "pack_dom"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / ("%s.html" % offer_id)
    url = DETAIL_URL.format(offer_id)
    p = subprocess.run([bsk, "navigate", url, "--session", sess,
                        "--wait-until", "domcontentloaded", "--quiet"],
                       capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError("bsk navigate 失败：%s" % ((p.stderr or p.stdout or "")[:140]))
    p = subprocess.run([bsk, "get-html", "--session", sess, "--out", str(path),
                        "--max-bytes", "4000000", "--quiet"],
                       capture_output=True, text=True, timeout=timeout)
    html = path.read_text(encoding="utf-8", errors="ignore") if path.exists() else ""
    try:
        path.unlink()
    except OSError:
        pass
    pack = parse_offer_pack(html, offer_id)
    if pack:
        pack["via"] = "bsk"
        _pack_cache_put(offer_id, pack)
        _save_pack_state(lastOkAt=time.time(), loginRequiredAt=None)
        return pack
    if looks_like_login_wall(html):
        _save_pack_state(loginRequiredAt=time.time())
        popped = open_login_window()
        _pack_cache_put(offer_id, {}, ttl=1800)
        log.warning("takealot-erp: 1688 登录墙（浏览器会话）%s，件重尺暂不可用%s",
                    offer_id, "，已弹出登录窗口" if popped else "")
        return {}
    _pack_cache_put(offer_id, {})       # 页面正常但卖家没填件重尺
    return {}


def fetch_offer_pack(offer_id: str, timeout: int = 25) -> Dict[str, Any]:
    """抓 1688「商品件重尺」：先匿名 curl，失败/被登录墙挡就走本机 Chrome 已登录 profile。

    为什么值得抓：Takealot 的长宽高/重量不是必填，公开页常常没有；但官方履约费
    （DC 费）= 包装体积档 × 重量档，缺输入就算不出到手。1688 货源页的
    productPackInfo 是**卖家自己填的包装尺寸**，正好补这个缺口。取不到返回 {}，不猜。
    """
    offer_id = str(offer_id or "").strip()
    if not offer_id:
        return {}
    cached = _pack_cache().get(offer_id) or {}
    if isinstance(cached, dict) and cached.get("at"):
        age = time.time() - float(cached["at"])
        pack_cached = cached.get("pack") or {}
        if pack_cached and age < PACK_TTL_OK_S:
            return pack_cached
        miss_ttl = float(cached.get("ttl") or PACK_TTL_MISS_S)
        if not pack_cached and age < miss_ttl:
            return {}
    html = _curl(["-L", DETAIL_URL.format(offer_id)], timeout=timeout)
    pack = parse_offer_pack(html, offer_id)
    if pack:
        pack["via"] = "curl"
        _pack_cache_put(offer_id, pack)
        return pack
    # 匿名被挡（实测 4/5 是 4.8KB 登录墙）→ 用已登录的浏览器 profile 渲染一次
    dom = fetch_offer_html_browser(offer_id)
    pack = parse_offer_pack(dom, offer_id)
    if pack:
        pack["via"] = "browser"
        _pack_cache_put(offer_id, pack)
        _save_pack_state(lastOkAt=time.time(), loginRequiredAt=None)
        return pack
    # 拿不到 —— 分辨是「登录失效」还是「页面本来没件重尺」
    # ⚠️ 只能看**浏览器 DOM**：匿名 curl 对约 4/5 的商品本来就返回登录墙（这是常态，不是故障），
    # 拿它判「登录失效」会把一个抓取完全正常的会话反复判成失效 → 反复弹登录窗 + 状态粘住。
    # 实测（2026-10-20）：offer 862907730183 的 DOM 3.26MB、无任何登录字样、`productPackInfo.fields`
    # 只有 `unitWeight: 0`（卖家根本没填件重尺），却因为匿名 html 是登录墙而被判成「登录失效」。
    if not dom:
        # 渲染失败（profile 单实例锁/chrome 起不来）→ 只做短负缓存，不对登录下结论、不弹窗
        _pack_cache_put(offer_id, {}, ttl=1800)
        log.info("takealot-erp: 件重尺渲染失败（非登录问题），%s 30 分钟内不再试", offer_id)
        return {}
    if looks_like_login_wall(dom):
        _save_pack_state(loginRequiredAt=time.time())
        popped = open_login_window()
        # 登录墙期间只缓存 30 分钟：用户扫码后很快就能重试成功
        _pack_cache_put(offer_id, {}, ttl=1800)
        log.warning("takealot-erp: 1688 登录已失效%s，件重尺暂不可用（配对/成本不受影响）",
                    "，已弹出登录窗口" if popped else "（%s 内不再重复弹窗）" % "6h")
        return {}
    _pack_cache_put(offer_id, {})          # 负缓存：7 天内不再试
    return pack


def _read_token(jar: Path) -> Optional[str]:
    if not os.path.exists(jar):
        return None
    for line in open(jar, encoding="utf-8", errors="replace"):
        if "\t_m_h5_tk\t" in line:
            parts = line.strip().split("\t")
            if len(parts) > 6:
                return parts[6]
    return None


def _upload(image_bytes: bytes, jar: Path, timeout: int) -> str:
    b64 = base64.b64encode(image_bytes).decode()
    body = json.dumps({"imgBase64": b64, "searchType": "imageSearch",
                       "appName": "pcErpImage", "urlType": "main"})
    out = _curl(["-X", "POST", "-H", "Content-Type: application/json",
                 "-H", "Origin: https://s.1688.com", "-H", "Referer: https://s.1688.com/",
                 "-c", str(jar), "-b", str(jar), "-d", body, UPLOAD_URL], timeout)
    try:
        j = json.loads(out)
    except ValueError:
        raise RuntimeError("图搜上传返回非 JSON：%s" % out[:160])
    if j.get("code") != 0:
        raise RuntimeError("图搜上传失败：%s" % j.get("errMsg"))
    return j["data"]["imageId"]


def _search_page(image_id: str, page: int, jar: Path, timeout: int, page_size: int = 20) -> Dict[str, Any]:
    params = json.dumps({
        "searchScene": "imageEx", "serviceGroupName": "service.group.pc.image",
        "interfaceName": "imageExtraSearchService",
        "serviceParam.extendParam[subChannel]": "pc_image_plugin",
        "serviceParam.extendParam[imageId]": image_id,
        "serviceParam.extendParam[appName]": "imageExtra",
        "abRequest.level3Biz": "main", "abRequest.level2Biz": "image",
        "abRequest.level1Biz": "search",
        "serviceParam.extendParam[pageSize]": page_size,
        "serviceParam.extendParam[beginPage]": page,
    }, separators=(",", ":"))
    data = json.dumps({"params": params}, separators=(",", ":"))

    def call(sign: Optional[str] = None, t: Optional[str] = None) -> str:
        q = {"jsv": "2.7.4", "appKey": APPKEY, "t": t or str(int(time.time() * 1000)),
             "api": MTOP_API, "v": "1.1", "type": "json", "dataType": "json", "data": data}
        if sign:
            q["sign"] = sign
        url = "https://h5api.m.1688.com/h5/%s/1.1/?%s" % (MTOP_API, urllib.parse.urlencode(q))
        return _curl(["-c", str(jar), "-b", str(jar),
                      "-H", "Referer: https://search.1688.com/", url], timeout)

    tok = _read_token(jar)
    if not tok:
        r = json.loads(call())
        if "TOKEN_EMPTY" in (r.get("ret") or [""])[0]:
            tok = _read_token(jar)
    if not tok:
        raise RuntimeError("1688 未下发 _m_h5_tk（可能被风控）")
    token = tok.split("_")[0]
    t = str(int(time.time() * 1000))
    sign = hashlib.md5(("%s&%s&%s&%s" % (token, t, APPKEY, data)).encode()).hexdigest()
    r = json.loads(call(sign=sign, t=t))
    if "SUCCESS" not in (r.get("ret") or [""])[0]:
        raise RuntimeError("1688 mtop 失败：%s" % r.get("ret"))
    view = ((r.get("data") or {}).get("responseInfo") or {}).get("imageSearchOfferResultViewService")
    v = json.loads(view) if isinstance(view, str) else (view or {})
    d = v.get("data") or {}
    offers = []
    for o in d.get("offerList") or []:
        info = o.get("information") or {}
        tp = (o.get("tradePrice") or {}).get("offerPrice") or {}
        comp = o.get("company") or {}
        tq = o.get("tradeQuantity") or {}
        offers.append({
            "offerId": str(o.get("id") or ""),
            "title": info.get("subject") or info.get("simpleSubject") or "",
            "price": tp.get("valueString") or "",
            "img": (o.get("image") or {}).get("imgUrl") or "",
            "url": info.get("detailUrl") or DETAIL_URL.format(o.get("id")),
            "simScore": info.get("normalizationScore"),
            "company": comp.get("name") or "",
            "city": comp.get("city") or "",
            "isFactory": comp.get("isFactory"),
        })
    return {"total": d.get("totalCount"), "page": page, "offers": offers}


def search_candidates(image_url: str, cfg: Dict[str, Any], workdir: Path,
                      jar_path: Optional[Path] = None) -> Dict[str, Any]:
    """用图片 URL 去 1688 以图搜款 → {imageId, total, offers:[…]}。"""
    sc = cfg["search"]
    tmo = _int(sc, "timeout_s", 45)
    workdir.mkdir(parents=True, exist_ok=True)
    # 文件名带线程名 + 微秒：并行时两个 worker 的毫秒时间戳会撞车，撞了就是一个 worker
    # 读到另一个的图（图搜会「对着别人的图」出结果 —— 静默错配，比报错难查得多）。
    img_path = workdir / ("search-%s-%d.jpg" % (
        threading.current_thread().name.replace("/", "_"), int(time.time() * 1e6) % 10 ** 12))
    _curl(["-o", str(img_path), image_url], tmo)
    if not img_path.exists() or img_path.stat().st_size < 1000:
        raise RuntimeError("主图下载失败（%s）" % image_url[:80])
    # jar 优先级：显式入参 > 本线程的并行 jar（`_WORKER_JAR`）> 配置里的共享 jar。
    # 保留「jar 不进签名」是有意的：`search_candidates(url, cfg, workdir)` 这个三参数契约
    # 被脚本与回归测试当接口用（`verify_supplier_resilience.py` 用 fake_search 替身）。
    jar = Path(jar_path) if jar_path else Path(
        getattr(_WORKER_JAR, "path", None) or sc.get("jar") or DEFAULT_CONFIG["search"]["jar"])
    if os.path.exists(jar):
        os.remove(jar)                      # 每次新会话都换 jar，避免旧令牌串味
    image_id = _upload(img_path.read_bytes(), jar, tmo)
    offers: List[Dict[str, Any]] = []
    total = None
    for page in range(1, _int(sc, "pages", 3) + 1):
        r = _search_page(image_id, page, jar, tmo)
        total = r["total"]
        offers.extend(r["offers"])
    seen, uniq = set(), []
    for o in offers:
        if not o["offerId"] or o["offerId"] in seen:
            continue
        seen.add(o["offerId"])
        uniq.append(o)
    uniq.sort(key=lambda x: -(x.get("simScore") or 0))
    try:
        img_path.unlink()
    except OSError:
        pass
    return {"imageId": image_id, "total": total, "offers": uniq}


# ---------------------------------------------------------------- 模型判定

JUDGE_RULES = """你是跨境电商采购员。下面是【待采购商品】(境外电商，英文标题) 与 1688【候选货源】
(用我方商品主图以图搜得到，已按 1688 相似度降序，sim 越高越像)。

判定目标：候选**是不是同一个货源链接**（1688 一个链接内部通常有多个 SKU 规格）。

✅ 算同款：结构与用途一致（贴牌、换色、不同包装都算同款）。
   **规格差异不算不同款**：尺寸/容量/件数/色数不同仍算同款 —— 我方 listing 的规格很可能
   只是该链接里的某一个 SKU → confidence 给 low 即可。**候选"没写规格"绝不构成不同款。**
❌ 算不同款：**品牌/型号不同**（我方"得力Deli"vs 候选"蒙玛特"）；**结构/品类冲突**
   （方帐篷 vs 六角凉亭帐篷、两轮车 vs 三轮车、正版 vs 兼容仿品、专用件车型不匹配、
   电压/市场制式不同、材质档位不同如 9K金 vs 合金）。
   图搜常返回**同类目邻居**，这类一律判不同款。"""

JUDGE_OUT = ('只输出 JSON：{"ids":["商品ID",…最多3个;不同款给[]],"confidence":"high|low|none",'
             '"reason":"一句中文依据"}\n不要 markdown、不要解释。'
             '**只允许使用候选里出现过的商品ID，禁止编造。**')


def _judge_prompt(listing: str, candidates: List[Dict[str, Any]]) -> str:
    lines = [JUDGE_RULES, "", "【候选货源】"]
    for c in candidates:
        lines.append("%s | %s | ¥%s | sim=%s" % (
            c.get("offerId"), (c.get("title") or "")[:95], c.get("price") or "-",
            round(c.get("simScore") or 0, 3)))
    lines += ["", "【待采购商品】", listing, "", JUDGE_OUT]
    return "\n".join(lines)


# 「明确否决」措辞：模型在理由里断言这不是同款，却仍返回了候选 ID 时用它做护栏。
# ⚠️ 只能列**明确否定**，别把 `不同款`/`品类冲突` 单独放进来 —— 实测用宽松词扫 37 条
# 会误报 6 条，全是「规格差异不算不同款」「无品牌或品类冲突」这种**含否定词但语义相反**的反向表达。
_REJECT_RE = re.compile(
    r"不能(?:作为|算是|算|视为|当作)同款|不(?:是|属于)同款|并非同款|非同款|无同款货源|不存在同款"
)


def _parse_judgement(text: str) -> Dict[str, Any]:
    import re
    m = re.search(r"\{.*\}", text or "", re.S)
    if not m:
        return {}
    try:
        d = json.loads(m.group(0))
    except ValueError:
        return {}
    ids = d.get("ids")
    return {"ids": [str(x) for x in ids] if isinstance(ids, list) else [],
            "confidence": str(d.get("confidence") or "none"),
            "reason": str(d.get("reason") or "")[:300]}


def _model_chain(mc: Dict[str, Any]) -> List[str]:
    """判定模型链：主模型 + ``fallback_models``（去重、去空）。

    为什么要链：免费/自建通道会抖（实测 `upstream connection failed: Server disconnected`）。
    一次抖动**不能**让整批判定失败 —— 换下一个模型立刻继续（"打热就切"）。
    """
    out: List[str] = []
    for m in [mc.get("model")] + list(mc.get("fallback_models") or []):
        m = str(m or "").strip()
        if m and m not in out:
            out.append(m)
    return out


def _log_model_switch(model: str, exc: Any) -> None:
    """把「打热→切换」记进 state，作为可自证的证据（不静默降级）。"""
    try:
        path = state_dir() / "supplier_switch.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                                 "model": model, "error": str(exc)[:200]},
                                ensure_ascii=False) + "\n")
    except Exception:
        pass


def _judge_openai(prompt: str, mc: Dict[str, Any], model_id: Optional[str] = None) -> str:
    base = str(mc.get("base_url") or "").rstrip("/")
    key = str(mc.get("api_key") or "")
    if not key and mc.get("key_env"):
        key = os.environ.get(str(mc["key_env"]), "")
    body = json.dumps({"model": model_id or mc.get("model"), "temperature": mc.get("temperature", 0),
                       "messages": [{"role": "user", "content": prompt}]})
    out = _curl(["-X", "POST", "-H", "Content-Type: application/json",
                 "-H", "Authorization: Bearer " + key, "-d", body,
                 "%s/chat/completions" % base], _int(mc, "timeout_s", 180))
    try:
        r = json.loads(out)
        return (r["choices"][0]["message"].get("content") or "")
    except (ValueError, KeyError, IndexError):
        err = ""
        try:
            err = str((json.loads(out).get("error") or {}).get("message") or "")[:120]
        except Exception:
            err = out[:120]
        raise RuntimeError("模型返回异常：%s" % (err or "空响应"))


def _hermes_bin() -> str:
    """找到 hermes CLI 的真实路径。

    服务端由桌面入口 / launchd 拉起时 PATH 很短（常常没有 ~/.local/bin），
    直接 `subprocess.run(["hermes", ...])` 会 FileNotFoundError ——
    历史上这就表现为「配对全部待复核 · 模型链全部失败」，看着像模型问题，其实是找不到命令。
    """
    for cand in (os.environ.get("HERMES_BIN"),
                 shutil.which("hermes") if hasattr(shutil, "which") else None,
                 str(Path.home() / ".local/bin/hermes"),
                 "/usr/local/bin/hermes",
                 "/opt/homebrew/bin/hermes"):
        if cand and Path(cand).is_file() and os.access(cand, os.X_OK):
            return cand
    return "hermes"


def _judge_hermes(prompt: str, mc: Dict[str, Any], model_id: Optional[str] = None) -> str:
    """走本机 hermes CLI —— 用客户自己配置的模型套餐（渠道由客户运维决定）。"""
    cmd = [_hermes_bin(), "chat", "-q", prompt, "--oneshot", "--quiet"]
    mid = str(model_id or mc.get("model") or "")
    if mid:
        cmd += ["-m", mid]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=_int(mc, "timeout_s", 300))
    except FileNotFoundError:
        raise RuntimeError("找不到 hermes CLI（PATH 里没有，也找不到 ~/.local/bin/hermes）")
    if p.returncode != 0 and not (p.stdout or "").strip():
        raise RuntimeError("hermes CLI 退出码 {0}：{1}".format(p.returncode, (p.stderr or "").strip()[:160]))
    return p.stdout or ""


def judge(listing: str, candidates: List[Dict[str, Any]], cfg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """返回 {ids, confidence, reason}；未配置模型时返回 None（→ needs_review）。

    模型链逐级降级：主模型抖动/限流 → 换 ``fallback_models`` 里的下一个（"打热就切"），
    切换会记进 ``state/supplier_switch.jsonl``。全链都失败才抛异常（由调用方兜成 needs_review，
    **候选已缓存，下次只重判不重搜**）。
    """
    if not candidates:
        return {"ids": [], "confidence": "none", "reason": "1688 无候选"}
    mc = cfg.get("model") or {}
    mode = str(mc.get("mode") or "").strip().lower()
    if mode not in ("openai", "hermes"):
        return None
    prompt = _judge_prompt(listing, candidates)
    chain = _model_chain(mc) or [""]
    last: Optional[Exception] = None
    for idx, mid in enumerate(chain):
        try:
            text = (_judge_openai(prompt, mc, mid) if mode == "openai"
                    else _judge_hermes(prompt, mc, mid))
            return _parse_judgement(text)
        except Exception as exc:
            last = exc
            if idx < len(chain) - 1:
                _log_model_switch(mid or "(默认)", exc)     # 留证：切换过
            continue
    raise RuntimeError("模型链全部失败（%d 个）：%s" % (len(chain), str(last)[:160]))



def _judge_prompt_batch(items: List[tuple]) -> str:
    """把 N 条（listing, candidates）塞进一次调用。固定开销约 25s、多一条只多几秒，所以合并划算。"""
    lines = [JUDGE_RULES, "",
             "【批处理】下面是 %d 个待采购商品，各自带候选。**逐个独立判定**，"
             "禁止跨商品使用候选 ID（每条只能用自己那一节的 ID）。" % len(items), ""]
    for idx, (listing, candidates) in enumerate(items, 1):
        lines.append("=== 商品 %d ===" % idx)
        lines.append("【待采购商品】" + (listing or ""))
        lines.append("【候选货源】")
        for c in candidates:
            lines.append("%s | %s | ¥%s | sim=%s" % (
                c.get("offerId"), (c.get("title") or "")[:95], c.get("price") or "-",
                round(c.get("simScore") or 0, 3)))
        lines.append("")
    lines.append('只输出 JSON：{"results":[{"idx":1,"ids":["…"],"confidence":"high|low|none",'
                 '"reason":"一句中文依据"},{"idx":2,…}]}')
    lines.append("要求：results 条数与商品数一致、idx 从 1 开始；不同款给空 ids；"
                 "只允许使用该商品自己候选里出现过的 ID，禁止编造；不要 markdown、不要解释。")
    return "\n".join(lines)


def _parse_judgement_batch(text: str, n: int) -> List[Optional[Dict[str, Any]]]:
    """解析批处理结果；条数对不上/解析失败返回 [None]*n（调用方退回逐条判，不猜）。"""
    import re as _re
    m = _re.search(r"\{.*\}", text or "", _re.S)
    if not m:
        return [None] * n
    try:
        d = json.loads(m.group(0))
    except ValueError:
        return [None] * n
    rows = d.get("results") if isinstance(d, dict) else None
    if not isinstance(rows, list) or len(rows) != n:
        return [None] * n
    out: List[Optional[Dict[str, Any]]] = []
    for i, row in enumerate(rows):
        if not isinstance(row, dict):
            out.append(None)
            continue
        ids = row.get("ids")
        out.append({"ids": [str(x) for x in ids] if isinstance(ids, list) else [],
                    "confidence": str(row.get("confidence") or "none"),
                    "reason": str(row.get("reason") or "")[:300]})
    return out


def judge_batch(items: List[tuple], cfg: Dict[str, Any]) -> List[Optional[Dict[str, Any]]]:
    """一次调用判 N 条。任何异常/解析不一致 → 该批退回逐条判（**正确性优先于速度**）。"""
    if not items:
        return []
    if len(items) == 1:
        return [judge(items[0][0], items[0][1], cfg)]
    mc = cfg.get("model") or {}
    mode = str(mc.get("mode") or "").strip().lower()
    if mode not in ("openai", "hermes"):
        return [None] * len(items)
    prompt = _judge_prompt_batch(items)
    chain = _model_chain(mc) or [""]
    last: Optional[Exception] = None
    for idx, mid in enumerate(chain):
        try:
            text = (_judge_openai(prompt, mc, mid) if mode == "openai"
                    else _judge_hermes(prompt, mc, mid))
            parsed = _parse_judgement_batch(text, len(items))
            if any(p is None for p in parsed):
                break          # 形状不对 → 交给下面的逐条兜底
            return parsed
        except Exception as exc:
            last = exc
            if idx < len(chain) - 1:
                _log_model_switch(mid or "(默认)", exc)
            continue
    # 兜底：逐条判（慢但可靠；候选已缓存，重判不重搜）
    out: List[Optional[Dict[str, Any]]] = []
    for listing, cands in items:
        try:
            out.append(judge(listing, cands, cfg))
        except Exception:
            out.append(None)
    return out

# ---------------------------------------------------------------- 单条配对


def _rate_gate(cfg: Dict[str, Any], st: Dict[str, Any]) -> tuple:
    """搜索限速。返回 ``(reason, wait_s)``：

    - ``reason is None`` → 可以立刻搜；
    - ``wait_s > 0`` → **等这么多秒就能继续**（批量任务应当 sleep 后重试同一条，
      而不是把它标成 pending 跳过 —— 否则 ``--limit 20`` 一次只会配 1 条，
      实测踩过：任务 25 秒退出、19 条全标「限速中」）；
    - ``wait_s == 0`` 且 ``reason`` 非空 → 本会话到此为止（配额用尽，等下一轮）。
    """
    sc = cfg["search"]
    now = time.time()
    gap = _num(sc, "min_gap_s", 20)
    last = _num(st, "lastSearchAt", 0)
    if last and now - last < gap:
        return ("距上次 1688 搜索仅 %.0fs（<%.0fs）" % (now - last, gap), gap - (now - last))
    cap = _int(sc, "max_per_session", 25)
    if int(st.get("sessionCount") or 0) >= cap:
        return ("本会话已搜 %d 次（上限 %d）" % (int(st["sessionCount"]), cap), 0)
    return (None, 0)


def _stage_search(plid: str, image_url: str, cfg: Dict[str, Any], workdir: Path,
                  jar: Optional[Path] = None) -> tuple:
    """配对阶段①：取候选并落库（**唯一碰 1688 的环节**）。

    返回 ``(rec, candidates)``：
      - ``candidates is None`` → ``rec`` 就是终态（人工指定 / 搜索关闭 / 限速 / 图搜失败），调用方直接收下；
      - 否则候选就绪，交给 ``_stage_judge`` 出结论。

    为什么拆两段：图搜受 1688 速率约束（并发 6），模型判定完全不碰 1688（并发可以 10+）。
    混在一个池子里跑时，判定只能拿到图搜那 6 个并发 —— 这是 41 分钟里最大的一块浪费
    （判定 p50 15.4s/条，比图搜 10.4s 还贵）。
    """
    api = _api()
    sc = cfg["search"]
    old = api.supplier_pair_get(plid)
    # 人工指定优先：worker 绝不改写界面上手工填的货源。
    if isinstance(old, dict) and old.get("manual"):
        return old, None
    # 有缓存就不重搜 —— 换规则/换模型只重判不重搜（1688 配额是最贵的东西）
    cached = old.get("candidates") if isinstance(old.get("candidates"), list) else []
    if cached:
        return {"rule": cfg.get("rule") or "v2", "status": "matching"}, cached

    rec: Dict[str, Any] = {"rule": cfg.get("rule") or "v2", "status": "matching"}
    if not sc.get("enabled", True):
        rec.update({"status": "needs_review", "reason": "1688 搜索已被配置关闭"})
        return api.supplier_pair_put(plid, rec), None
    if jar is not None:
        # 并行路径：全局令牌桶节流（风控看整会话速率，不在单线程里 sleep）
        _PACER.acquire(_num(sc, "rate_per_s", 2.0), _num(sc, "max_wait_s", 120))
    else:
        st = run_state()
        blocked, wait_s = _rate_gate(cfg, st)
        if blocked:
            rec.update({"status": "pending", "reason": "限速中：" + blocked, "waitS": round(wait_s, 1)})
            return api.supplier_pair_put(plid, rec), None
    _t_search = time.time()
    got = None
    last_exc: Optional[Exception] = None
    # 并行下偶发失败（对端返回空/挑战页/限速 → 非 JSON）实测 1/12：退避重试一次，
    # 别把整行留成 pending（下一轮重跑要重花一次图搜配额）。
    for _try in range(1 + (1 if jar is not None and _int(sc, "retry", 1) else 0)):
        try:
            if _try:
                time.sleep(2.5 * _try)
                if jar is not None:
                    _PACER.acquire(_num(sc, "rate_per_s", 2.0), _num(sc, "max_wait_s", 120))
            if jar is not None:
                _WORKER_JAR.path = Path(jar)      # 线程局部：让 search_candidates 用本 worker 的 jar
            got = search_candidates(image_url, cfg, workdir)
            last_exc = None
            break
        except Exception as exc:
            last_exc = exc
    if got is None and last_exc is not None:
        exc = last_exc
        if jar is not None:
            cool = _PACER.fail(_num(sc, "fail_cooldown_s", 180),
                               _int(sc, "max_consecutive_fail", 3))
            rec.update({"status": "pending",
                        "reason": "图搜失败%s：%s" % ("（已全局冷却 %.0fs）" % cool if cool else "",
                                                    str(exc)[:150])})
            return api.supplier_pair_put(plid, rec), None
        st["lastSearchAt"] = time.time()
        st["sessionCount"] = int(st.get("sessionCount") or 0) + 1
        st["lastError"] = "%s: %s" % (type(exc).__name__, str(exc)[:200])
        _save_run_state(st)
        rec.update({"status": "pending", "reason": "图搜失败：" + str(exc)[:160]})
        return api.supplier_pair_put(plid, rec), None
    if jar is not None:
        _PACER.ok()
    else:
        st["lastSearchAt"] = time.time()
        st["sessionCount"] = int(st.get("sessionCount") or 0) + 1
        st["lastOkAt"] = st["lastSearchAt"]
        st["lastError"] = ""
        _save_run_state(st)
    candidates = got["offers"]
    rec["candidates"] = candidates
    rec["candidatesFetchedAt"] = api._iso_now()
    rec["candidateTotal"] = got.get("total")
    rec["tSearchMs"] = int((time.time() - _t_search) * 1000)   # 图搜真实耗时（含网络）
    # 候选立刻落库：判定失败时下次只重判不重搜（这一步不能省）
    api.supplier_pair_put(plid, rec)
    return rec, candidates


def _apply_verdict(plid: str, verdict: Optional[Dict[str, Any]],
                   candidates: List[Dict[str, Any]], cfg: Dict[str, Any]) -> Dict[str, Any]:
    """拿到模型结论后的全部处理：护栏 → 选货 → 落库 → 成本回填 → 件重尺排队。

    与「怎么问模型」解耦（单条判定 / 批量判定共用这一份），否则两条路径的护栏会漂。
    """
    api = _api()
    sc = cfg["search"]
    rec: Dict[str, Any] = {"rule": cfg.get("rule") or "v2"}
    picked = candidates[: _int(sc, "candidates_keep", 15)]
    if verdict is None:
        rec.update({"status": "needs_review",
                    "reason": "未配置判定模型（state/supplier.json → model.mode）"})
        return api.supplier_pair_put(plid, rec)
    ids = [i for i in verdict["ids"] if any(str(c["offerId"]) == i for c in picked)]
    if verdict["ids"] and not ids:
        rec.update({"status": "no_match", "reason": "模型给出的候选ID不在候选集内（已丢弃）"})
        return api.supplier_pair_put(plid, rec)
    if not ids:
        rec.update({"status": "no_match", "confidence": "none",
                    "reason": verdict.get("reason") or "无同款", "matchedAt": api._iso_now()})
        return api.supplier_pair_put(plid, rec)
    # ③ 自相矛盾护栏：模型**给了候选 ID，理由却明说"不是同款"** → 两个信号互相否定，谁都不采信。
    # 实测踩过（采集箱 1/37）：工具包这条 status=matched，理由却是「存在品类冲突，不能作为同款」。
    # 为什么必须护栏：假"已配对"是**危险方向** —— 会让人照着错链接去采购。
    if _REJECT_RE.search(str(verdict.get("reason") or "")):
        rec.update({"status": "needs_review", "contradiction": True,
                    "reason": "模型自相矛盾（给了链接但理由说不是同款），待人工确认："
                              + str(verdict.get("reason"))[:120],
                    "matchedAt": api._iso_now()})
        return api.supplier_pair_put(plid, rec)
    pick = next(c for c in picked if str(c["offerId"]) == ids[0])
    rec.update({
        "status": "matched", "offerId": str(pick["offerId"]), "url": pick.get("url") or DETAIL_URL.format(pick["offerId"]),
        "title": pick.get("title") or "", "price": pick.get("price") or "",
        "imageUrl": pick.get("img") or "", "sim": pick.get("simScore"),
        "confidence": verdict.get("confidence") or "low",
        "reason": verdict.get("reason") or "", "matchedAt": api._iso_now(),
        "altIds": ids[1:3],
    })
    # 1688 货源的「件重尺」：Takealot 侧长宽高/重量不是必填，抓不到就用 1688 的包装信息补，
    # 补上之后履约费（DC 费）才算得出来。取不到就跳过，不影响配对结果。
    # ⚠️ 默认 **defer**：它是慢操作（匿名 25s 超时，登录墙时还要 headless Chrome 30~90s，
    #    成功率仅约 1/5），同步做等于让「出链接」等一个可有可无的字段。改成配对返回后再补。
    pack: Dict[str, Any] = {}
    if str((cfg.get("pack") or {}).get("mode") or "defer") == "inline":
        try:
            pack = fetch_offer_pack(rec.get("offerId") or "")
        except Exception:
            pack = {}
    if pack:
        rec["pack"] = pack
    saved = api.supplier_pair_put(plid, rec)
    # 配对成功 → 立刻把 1688 ¥ 价回填进采集箱行的核算（否则配了也不进成本，
    # 界面上「采购成本」永远是空的、到手算不出）。人工填过的成本不覆盖。
    try:
        api.collection_sync_supplier_cost(plid, rec.get("price"), offer_id=rec.get("offerId") or "",
                                          url=rec.get("url") or "", source_title=rec.get("title") or "")
        if pack:
            api.collection_sync_supplier_pack(plid, pack)
    except Exception as exc:      # 回填失败不能把配对结果弄丢
        api.supplier_pair_put(plid, dict(saved, costSyncError=str(exc)[:120]))
    if not pack and str((cfg.get("pack") or {}).get("mode") or "defer") == "defer":
        _pack_enqueue([(plid, str(rec.get("offerId") or ""))])
    return saved


def _stage_judge(plid: str, listing: str, candidates: List[Dict[str, Any]],
                 cfg: Dict[str, Any]) -> Dict[str, Any]:
    """配对阶段②：单条模型判定（不碰 1688，可高并发）。返回落库后的记录。"""
    api = _api()
    picked = candidates[: _int(cfg["search"], "candidates_keep", 15)]
    _t_judge = time.time()
    try:
        verdict = judge(listing, picked, cfg)
    except Exception as exc:
        # 模型抖动/全链失败**不能**杀死这一批：候选已缓存，标 needs_review 下次只重判不重搜。
        return api.supplier_pair_put(plid, {
            "rule": cfg.get("rule") or "v2", "status": "needs_review",
            "reason": "判定模型失败（候选已缓存，下次只重判不重搜）：" + str(exc)[:150]})
    rec = _apply_verdict(plid, verdict, candidates, cfg)
    try:
        api.supplier_pair_put(plid, {"tJudgeMs": int((time.time() - _t_judge) * 1000)})
    except Exception:
        pass
    return rec


def match_one(plid: str, listing: str, image_url: str, cfg: Dict[str, Any],
              workdir: Path, jar: Optional[Path] = None) -> Dict[str, Any]:
    """一条 listing 走完整两段（串行/单点配对用；批量走 run() 的两阶段池子）。"""
    rec, candidates = _stage_search(plid, image_url, cfg, workdir, jar=jar)
    if candidates is None:
        return rec
    return _stage_judge(plid, listing, candidates, cfg)


def _pick_image(row: Dict[str, Any]) -> str:
    """优先用采集时存下的最大主图 —— 实测 280×280 缩略图会拖累图搜质量。"""
    images = row.get("images")
    if isinstance(images, list):
        fallback = ""
        for u in images:
            if not (isinstance(u, str) and u.startswith("http")):
                continue
            if "280x280" not in u:          # 非缩略图优先命中
                return u
            fallback = fallback or u
        if fallback:
            return fallback
    return str(row.get("imageUrl") or "")


def run(limit: Optional[int] = None, dry: bool = False,
        plids: Optional[List[str]] = None) -> Dict[str, Any]:
    """跑一轮配对：从采集箱取待配对行 → 逐条配对（受 1688 限速）。

    ``plids``：只做这几行（界面上「单点配对 / 单条链接配对」走这里）。
    指定行时**不看队列**——已配对的行也允许重跑（有候选缓存 → 只重判不重搜，不碰 1688）。
    人工指定的行仍受保护（``match_one`` 里不会改写）。
    """
    api = _api()
    cfg = config()
    st = run_state()
    # 「单会话 ≤25 次」= **一次运行**的预算，不是累计。
    # 缺陷记录：以前 sessionCount 从不重置 → 累计搜满 25 次后 worker 永久停摆（产品级隐患）。
    st["sessionStartedAt"] = api._iso_now()
    st["sessionCount"] = 0
    _save_run_state(st)

    queue = api.supplier_queue()["plids"]
    if plids:
        wanted = [api._plid_of(str(p)) for p in plids]
        todo = [p for p in wanted if p]
    else:
        if limit is None:
            limit = _int(cfg.get("batch") or {}, "max_items", 25)
        todo = queue[:max(0, int(limit))]
    workdir = state_dir() / "supplier_work"

    items_by_plid = {}
    for item in api._collection():
        # 行 → 键的映射必须和队列/配对表同一套（PLID 优先），否则队列里的 PLID
        # 在 items_by_plid 里查不到，会被误判成「该行不在采集箱里」。
        pid = api._row_plid(item)
        if pid and pid not in items_by_plid:
            items_by_plid[pid] = item
        for alias in api._row_pair_keys(item):
            items_by_plid.setdefault(alias, item)

    # ---- 并行度：批量才并行；单点配对（plids 指定）保持串行（界面等一条，排那么多没意义）
    sc = cfg.get("search") or {}
    workers = 1
    # 采集箱「入库即配对」会传 1 条 plids —— 排队没意义，保持串行（界面等一条，40s 可预期）。
    # 一次点检多条（≥3）才值得开池子。
    if plids is None or len(plids) >= 3:
        workers = int(_num(sc, "concurrency", 1) or 1)
        workers = max(1, min(workers, 12))
    judge_workers = max(2, min(_int(cfg.get("judge") or {}, "concurrency", 8), 16))
    base_jar = Path(sc.get("jar") or DEFAULT_CONFIG["search"]["jar"])
    _JAR_SEQ = [0]
    _JAR_LOCK = threading.Lock()
    _STOP = [""]

    def thread_jar() -> Path:
        """每个 worker 一个 cookie jar：共享 jar 会互相覆盖 `_m_h5_tk`（签名对不上 → 非法请求）。"""
        p = getattr(_WORKER_JAR, "path", None)
        if p is None:
            with _JAR_LOCK:
                _JAR_SEQ[0] += 1
                p = Path("%s.w%d" % (base_jar, _JAR_SEQ[0]))
            _WORKER_JAR.path = p
        return p

    def prepare(plid: str) -> dict:
        """行准备（纯本地）：返回 {plid,listing,image_url,jar} 或 {entry:…终态…}。"""
        item = items_by_plid.get(plid) or {}
        if not item:
            # 指定行（界面上单点配对）时可能出现：该 PLID 已经不在采集箱里了。
            # 照实说清楚 —— 别含糊成「无主图」，那会让人往图片问题上找。
            api.supplier_pair_put(plid, {"status": "needs_review", "rule": cfg.get("rule"),
                                         "reason": "该行不在采集箱里（可能已被删除或换了店铺作用域）"})
            return {"entry": {"plid": plid, "status": "needs_review", "reason": "不在采集箱"}}
        row = api._collection_row(item)
        listing = str(item.get("title") or row.get("title") or "")
        image_url = _pick_image(row or item)
        if dry:
            return {"entry": {"plid": plid, "status": "dry", "image": bool(image_url),
                              "listing": listing[:60]}}
        if not image_url:
            api.supplier_pair_put(plid, {"status": "needs_review", "rule": cfg.get("rule"),
                                         "reason": "该行没有可用的主图"})
            return {"entry": {"plid": plid, "status": "needs_review", "reason": "无主图"}}
        return {"plid": plid, "listing": listing, "image_url": image_url,
                "jar": thread_jar() if workers > 1 else None}

    def entry_of(plid: str, rec: Dict[str, Any], listing: str) -> Dict[str, Any]:
        e = {"plid": plid, "status": rec.get("status"), "offerId": rec.get("offerId"),
             "confidence": rec.get("confidence"), "reason": (rec.get("reason") or "")[:80]}
        if not e["offerId"] and rec.get("candidates"):
            e["candidates"] = len(rec["candidates"])     # 只剩「判不了」时也能看出候选有几个
        return e

    done: List[Dict[str, Any]] = []
    stopped_at = ""
    t_run = time.time()

    # ============================================================ 串行（单点配对 / concurrency<=1）
    if workers <= 1:
        for plid in todo:
            prep = prepare(plid)
            if "entry" in prep:
                done.append(prep["entry"])
                continue
            rec: Dict[str, Any] = {}
            stopped = ""
            # 串行路径的限速是**排队**、不是"这条跳过"（等待免费）
            for _attempt in range(6):
                try:
                    rec = match_one(plid, prep["listing"], prep["image_url"], cfg, workdir)
                except Exception as exc:
                    rec = {"status": "needs_review", "reason": "内部错误：%s" % str(exc)[:150]}
                    break
                if rec.get("status") != "pending" or "限速" not in str(rec.get("reason") or ""):
                    break
                wait_s = float(rec.get("waitS") or 0)
                if wait_s <= 0:
                    stopped = str(rec.get("reason") or "")
                    break
                time.sleep(min(wait_s + 1.0, float(_num(sc, "max_wait_s", 120))))
            done.append(entry_of(plid, rec, prep["listing"]))
            if stopped:
                stopped_at = stopped
                break

    # ============================================================ 并行（两阶段）
    else:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        prepared: Dict[str, dict] = {}
        for plid in todo:
            prep = prepare(plid)
            if "entry" in prep:
                done.append(prep["entry"])
            else:
                prepared[plid] = prep

        cands: Dict[str, List[Dict[str, Any]]] = {}
        t_phase1 = time.time()
        # ---- 阶段① 图搜（并发 = search.concurrency；受全局令牌桶节流）
        needs = [p for p in prepared
                 if not (api.supplier_pair_get(p).get("candidates") or [])]
        for plid in list(prepared):
            if plid not in needs:
                cands[plid] = api.supplier_pair_get(plid)["candidates"]   # 走缓存，不碰 1688

        def run_search(plid: str) -> tuple:
            if _STOP[0]:
                return plid, {"status": "pending", "reason": "本轮已停止：" + _STOP[0][:60]}, None
            try:
                rec, got = _stage_search(plid, prepared[plid]["image_url"], cfg, workdir,
                                         jar=prepared[plid]["jar"])
            except Exception as exc:
                return plid, {"status": "needs_review",
                              "reason": "内部错误：%s" % str(exc)[:140]}, None
            if got is None:
                return plid, rec, None
            return plid, None, got

        if needs:
            with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="sup-search") as pool:
                futs = [pool.submit(run_search, p) for p in needs]
                for fut in as_completed(futs):
                    try:
                        plid, rec, got = fut.result()
                    except Exception as exc:
                        plid, rec, got = "?", {"status": "needs_review",
                                               "reason": "worker 内部错误：%s" % str(exc)[:120]}, None
                    if got:
                        cands[plid] = got
                    elif rec is not None:
                        done.append(entry_of(plid, rec, ""))
                        if rec.get("status") == "pending" and "冷却" in str(rec.get("reason") or ""):
                            _STOP[0] = _STOP[0] or str(rec.get("reason") or "")
        stopped_at = _STOP[0]
        _PHASE["searchSec"] = round(time.time() - t_phase1, 1)
        _PHASE["searched"] = len(needs)
        # 图搜被风控停下时，**仍然把已经拿到候选的行判完**（判定不碰 1688，白扔可惜）

        # ---- 阶段② 判定（并发 = judge.concurrency；完全不碰 1688）
        todo_judge = [p for p in prepared if p in cands]
        _STOP[0] = ""

        # 判定可以**一次判多条**：模型调用是「固定开销 25s + 每条几秒」，合并后单条成本大降。
        # 批内任何解析异常都退回逐条判（judge_batch 内部兜底），所以不会因为合并丢结论。
        batch_n = max(1, min(_int(cfg.get("judge") or {}, "batch", 2), 4))
        keep_n = _int(sc, "candidates_keep", 15)
        chunks = [todo_judge[i:i + batch_n] for i in range(0, len(todo_judge), batch_n)]

        def run_judge_chunk(chunk: List[str]) -> List[Dict[str, Any]]:
            items = [(prepared[p]["listing"], cands[p][:keep_n]) for p in chunk]
            try:
                verdicts = judge_batch(items, cfg) if len(items) > 1 else [judge(*items[0], cfg)]
            except Exception as exc:
                verdicts = [None] * len(items)
                err = str(exc)[:140]
            else:
                err = ""
            out: List[Dict[str, Any]] = []
            for p, (listing, _cs), v in zip(chunk, items, verdicts):
                if v is None:
                    rec = api.supplier_pair_put(p, {
                        "rule": cfg.get("rule") or "v2", "status": "needs_review",
                        "reason": "判定模型失败（候选已缓存，下次只重判不重搜）：" + (err or "空响应")})
                else:
                    try:
                        rec = _apply_verdict(p, v, cands[p], cfg)
                    except Exception as exc:
                        rec = {"status": "needs_review", "reason": "落库失败：%s" % str(exc)[:120]}
                out.append(entry_of(p, rec, listing))
            return out

        if chunks:
            with ThreadPoolExecutor(max_workers=judge_workers, thread_name_prefix="sup-judge") as pool:
                for fut in as_completed([pool.submit(run_judge_chunk, c) for c in chunks]):
                    try:
                        done.extend(fut.result())
                    except Exception as exc:
                        done.append({"plid": "?", "status": "needs_review",
                                     "reason": "judge worker 崩了：%s" % str(exc)[:120]})
        _PHASE["judgeSec"] = round(time.time() - t_phase1 - _PHASE["searchSec"], 1)
        _PHASE["judged"] = len(todo_judge)
        order = {p: i for i, p in enumerate(todo)}
        done.sort(key=lambda d: order.get(d.get("plid"), 10 ** 9))

    wall = round(time.time() - t_run, 1)
    out = {"queue": len(queue), "processed": len(done), "results": done,
           "rule": cfg.get("rule"), "modelMode": (cfg.get("model") or {}).get("mode") or "(未配置)",
           "stopped": stopped_at, "workers": workers, "wallSec": wall}
    if workers > 1:
        out["pacer"] = _PACER.snapshot()
        out["judgeWorkers"] = judge_workers
        out["phase"] = dict(_PHASE)
        out["perItemSec"] = round(wall / len(done), 2) if done else None
    for f in base_jar.parent.glob(base_jar.name + ".w*"):
        try:
            f.unlink()                    # 并行 jar 用完即删（不含令牌残留）
        except OSError:
            pass
    return out


if __name__ == "__main__":
    import sys
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    lim = int(args[0]) if args and args[0].isdigit() else 3
    sel = [sys.argv[i + 1] for i, a in enumerate(sys.argv) if a == "--plid" and i + 1 < len(sys.argv)]
    print(json.dumps(run(limit=lim, dry=("--dry" in sys.argv), plids=sel or None),
                     ensure_ascii=False, indent=2))
