#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Takealot ERP 的 MCP server（stdio）—— 通用 agent 接口层（形态 v3 · P3）。

一份实现，给所有宿主用：Hermes / Codex / Cursor / 任何支持 MCP 的 agent。
    python3 server/mcp_server.py            # stdio，宿主自己 spawn
    erp mcp config --host codex             # 打印该宿主该写什么配置

设计纪律（改之前先读）：

* **只读 + 一个启动入口**。写平台（改价/改库存/上架/发 loadsheet）永远只在工作台界面里做，
  这里不注册任何写工具 —— 这是产品红线，不是技术限制。
* **取数走本机服务端**（`runtime.json` 里的端口 + token），服务没起就**静默起一个**（不开窗口）：
  用户问一句"今天几单"不该先被要求去点图标。
* **零模拟数据**：核心层返回 `ok:false` + 真实原因时，原样透出去，不编数字。
* 不实现协议里用不到的部分（resources / prompts / sampling），但被问到要老实回答空列表，
  不认识的方法回 -32601，绝不假装成功。
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


def force_utf8_stdio() -> None:
    """stdio 上跑的是 MCP 协议（JSON-RPC），**必须** UTF-8。

    Windows 中文版的 locale 是 cp936：不显式改，宿主读到的 JSON 会带编码错误
    （或我们自己 print 中文时直接 UnicodeEncodeError）。
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass


force_utf8_stdio()

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import app as srv  # noqa: E402  同目录的服务端模块
import cli as erp_cli  # noqa: E402  复用「启动/自检/路由」那唯一一份实现

SERVER_NAME = "takealot-erp"


def audit(event: str, **fields) -> None:
    """把「哪个宿主 spawn 了我们、握手说了什么、调了哪些工具」记到 ERP_HOME/logs/mcp-sessions.log。

    为什么要这个：能证明**宿主真的连上了**（不靠模型、不靠自述），也是产品要的审计面
    （自然语言→动作的链路必须可回查）。日志写不进去不该影响服务，所以全程吞异常。
    """
    try:
        home = _home()
        home.logs.mkdir(parents=True, exist_ok=True)
        rec = {"at": time.strftime("%Y-%m-%dT%H:%M:%S"), "pid": os.getpid(), "ppid": os.getppid(),
               "argv": sys.argv[1:], "event": event}
        rec.update(fields)
        with open(home.logs / "mcp-sessions.log", "a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass
SERVER_VERSION = getattr(srv, "VERSION", "3.0.0")
PROTOCOL_FALLBACK = "2024-11-05"

READ_ONLY_HINT = {"readOnlyHint": True}


# ---------------------------------------------------------------------------
# 与服务端对话（没起就静默起）
# ---------------------------------------------------------------------------

def _home() -> "srv.ErpHome":
    return srv.ErpHome(srv.default_erp_home())


def ensure_running(home=None) -> dict:
    """拿到在跑的实例；没起就起一个（不开窗口）。返回实例信息。"""
    home = home or _home()
    info = erp_cli.running(home)
    if info.get("running"):
        return info
    port = erp_cli.srv.pick_port(erp_cli.srv.DEFAULT_PORT)
    erp_cli.spawn_server(home, port)
    health = erp_cli.wait_health(port)
    if not health:
        raise RuntimeError("服务端起不来（{0} 秒内没有 /healthz）：看 {1}".format(40, home.logs / "server.out"))
    return {**home.read_runtime(), **health, "running": True}


def api(path: str, home=None, query: str = "") -> dict:
    """带 token 打核心 API。失败时把**真实原因**交给调用方（不吞、不编）。"""
    home = home or _home()
    info = ensure_running(home)
    rt = home.read_runtime()
    url = "http://127.0.0.1:{0}{1}{2}{3}".format(info.get("port"), srv.API_PREFIX, path, query)
    req = urllib.request.Request(url)
    req.add_header("X-ERP-Token", str(rt.get("token") or ""))
    try:
        # 回环不走系统代理（客户机一挂代理，走代理的 127.0.0.1 会被拦成 502）
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=90) as resp:
            return json.loads(resp.read().decode("utf-8") or "null")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")[:400]
        raise RuntimeError("核心 API {0} 返回 HTTP {1}：{2}".format(path, exc.code, body))
    except Exception as exc:
        raise RuntimeError("核心 API {0} 调用失败：{1}".format(path, exc))


# ---------------------------------------------------------------------------
# 工具表：只读 + 一个启动入口
# ---------------------------------------------------------------------------

def tool_defs() -> list[dict]:
    S = dict  # 简写对齐

    def t(name, title, desc, props=None, required=None, annotations=None):
        return {
            "name": name,
            "title": title,
            "description": desc,
            "inputSchema": {"type": "object", "properties": props or {}, "required": required or [],
                            "additionalProperties": False},
            "annotations": annotations or READ_ONLY_HINT,
        }

    store = {"storeId": {"type": "string", "description": "店铺 id（可选；不给就用界面里当前选中的店）"}}
    return [
        t("erp_workbench_open", "打开 Takealot 工作台",
          "启动 ERP 工作台：服务没起就起，然后打开窗口（无地址栏的应用窗口，装不了就回落默认浏览器）。"
          "用户说「打开工作台 / 打开中台 / 启动 ERP」时用这个。写完把端口和 URL 报给用户。",
          {"openWindow": {"type": "boolean", "description": "是否同时打开窗口，默认 true；只想要服务在跑就传 false"}},
          annotations={"readOnlyHint": False, "openWorldHint": False}),
        t("erp_status", "工作台运行状态",
          "工作台（常驻服务端）在不在跑：端口、PID、版本、数据目录、密钥库。用户问「工作台在吗/端口多少」时用。"),
        t("erp_doctor", "工作台自检",
          "13 项端到端自检：服务在跑、鉴权、核心文件哈希、前端资产、密钥库、数据目录、桌面入口、Hermes/Codex 入口、浏览器。"
          "用户说「自检 / 哪里不通 / 体检」时用。失败项会带真实原因。"),
        t("erp_route", "中文意图路由（确定性）",
          "把中文说法映射到确定的落点（读工具 / 界面写入 / 界面只读 / 运维 / 专项脚本 五类），返回硬指令。"
          "写入类（改价/改库存/上架/发 loadsheet）会被指到工作台界面（红线：不在对话里写）。命中不了就说没命中，不要猜。",
          {"text": {"type": "string", "description": "用户原话，例如「把工作台打开」"}}, ["text"]),
        t("erp_overview", "经营总览", "营收/净利/待发货/BuyBox/对账差异等 KPI 与风险提示。" + 说明, store),
        t("erp_orders", "订单与净利",
          "订单列表与逐单净利。" + 说明,
          {**store, "limit": {"type": "integer", "description": "最多返回几条（默认 20，最多 200）"}}),
        t("erp_products", "商品与库存",
          "店铺商品目录（含库存/价格）+ 销量推算。" + 说明,
          {**store, "limit": {"type": "integer", "description": "最多返回几条（默认 50）"}}),
        t("erp_finance", "财务与对账", "平台计费、结算与对账差异。" + 说明, store),
        t("erp_collection", "采集箱（跟卖池）",
          "采集箱里待跟卖/待上架的行与核算输入。" + 说明
          + "注意：跟卖只能改价格与库存，改完要在界面里提交。"),
        t("erp_diagnostics", "环境自检明细",
          "核心层的事实采集：出口通道、Seller API、密钥加密状态、公开爬取通道（含实测证据）。" + 说明),
    ]


说明 = ("只读。写平台的动作（改价/改库存/上架/发 loadsheet）只在工作台界面里做，"
       "不要试图通过工具改平台数据；需要写就把用户引到界面。取不到数时会返回 ok:false 与真实原因，"
       "照原样解释，不要编造数字。")


def _limit(args: dict, default: int, cap: int = 200) -> int:
    try:
        n = int(args.get("limit") or default)
    except (TypeError, ValueError):
        n = default
    return max(1, min(cap, n))


def _query(args: dict, limit_key: str = "", default_limit: int = 0) -> str:
    parts = []
    sid = str(args.get("storeId") or "").strip()
    if sid:
        parts.append("storeId=" + urllib.parse.quote(sid))
    if limit_key:
        parts.append("{0}={1}".format(limit_key, _limit(args, default_limit)))
    return ("?" + "&".join(parts)) if parts else ""


def call_tool(name: str, args: dict) -> str:
    """执行工具，返回给人/模型看的文本。异常向上抛，由协议层包成 isError。"""
    args = args or {}
    home = _home()

    if name == "erp_workbench_open":
        info, started = erp_cli.ensure_server(home, srv.DEFAULT_PORT)
        url = "http://127.0.0.1:{0}/".format(info.get("port"))
        win = None
        if args.get("openWindow", True) is not False:
            win = erp_cli.open_window(url, "app")
        return _text({
            "ok": True, "started": started, "url": url, "port": info.get("port"), "pid": info.get("pid"),
            "version": info.get("version"), "window": win,
            "note": "服务端已常驻；窗口只是看板，关掉窗口服务不会停。",
        })

    if name == "erp_status":
        info = erp_cli.running(home)
        rt = home.read_runtime()
        return _text({"ok": bool(info.get("running")), "running": bool(info.get("running")),
                      "port": info.get("port"), "pid": info.get("pid"), "version": info.get("version"),
                      "erpHome": str(home.root), "atRestBackend": info.get("atRestBackend"),
                      "detail": "在跑" if info.get("running") else "没在跑（任何取数工具都会自动把它起来）"})

    if name == "erp_doctor":
        rows = erp_cli.doctor_rows(home)
        fails = [{"name": n, "detail": d} for lv, n, d in rows if lv == "fail"]
        warns = [{"name": n, "detail": d} for lv, n, d in rows if lv == "warn"]
        return _text({"ok": not fails, "passed": len(rows) - len(fails) - len(warns), "total": len(rows),
                      "failed": fails, "warned": warns,
                      "checks": [{"level": lv, "name": n, "detail": d} for lv, n, d in rows]})

    if name == "erp_route":
        return _text(erp_cli.route(str(args.get("text") or ""), home))

    if name == "erp_overview":
        return _text(api("/overview", home, _query(args)))
    if name == "erp_orders":
        return _text(api("/orders", home, _query(args, "limit", 20)))
    if name == "erp_products":
        return _text(api("/products", home, _query(args, "limit", 50)))
    if name == "erp_finance":
        return _text(api("/financial", home, _query(args)))
    if name == "erp_collection":
        return _text(api("/collection", home, _query(args)))
    if name == "erp_diagnostics":
        return _text(api("/diagnostics", home, _query(args)))

    raise ValueError("未知工具：{0}".format(name))


#: MCP prompts —— 支持 `prompts/list` 的宿主（Claude Code 等）会把它变成斜杠命令入口。
#: 这是"没有侧栏可嵌"的宿主里最省事的入口形态：纯协议层，不依赖任何 UI 能力。
PROMPTS = [
    {
        "name": "open-workbench",
        "title": "打开 Takealot 工作台",
        "description": "启动并打开本地 ERP 工作台（独立窗口），报出端口、版本与自检结果。",
        "arguments": [],
    },
    {
        "name": "daily-brief",
        "title": "今天的经营快报",
        "description": "取经营总览 + 今日订单，汇总成一段话。取不到就如实说原因，不编数字。",
        "arguments": [{"name": "storeId", "description": "店铺 id（可选，默认界面里当前选中的店）", "required": False}],
    },
]


def prompt_messages(name: str, args: dict) -> dict:
    """把 prompt 渲染成宿主能直接喂给模型的消息。"""
    args = args or {}
    if name == "open-workbench":
        return {
            "description": "打开 Takealot ERP 工作台",
            "messages": [{"role": "user", "content": {"type": "text", "text":
                "用 takealot-erp 的 MCP 工具 erp_workbench_open（openWindow=true）把工作台打开，"
                "然后用 erp_status 报出端口与版本、用 erp_doctor 报出自检结果。不要自己拼 URL。"}}],
        }
    if name == "daily-brief":
        sid = str(args.get("storeId") or "").strip()
        extra = "，storeId 用 {0}".format(sid) if sid else "（不传 storeId，用界面里当前店铺）"
        return {
            "description": "今天的经营快报",
            "messages": [{"role": "user", "content": {"type": "text", "text":
                "用 takealot-erp 的工具 erp_overview 与 erp_orders{0} 汇总今天的营收、订单数、净利与风险提示；"
                "取不到数据就如实说明原因（例如没绑 Seller Key），**不要编数字**。".format(extra)}}],
        }
    raise ValueError("未知 prompt：{0}".format(name))


def _text(payload) -> str:
    if isinstance(payload, str):
        return payload
    return json.dumps(payload, ensure_ascii=False, indent=2, default=str)


# ---------------------------------------------------------------------------
# JSON-RPC / MCP 协议层（stdio，逐行）
# ---------------------------------------------------------------------------

def _reply(id_, result=None, error=None) -> None:
    msg = {"jsonrpc": "2.0", "id": id_}
    if error is not None:
        msg["error"] = error
    else:
        msg["result"] = result if result is not None else {}
    sys.stdout.write(json.dumps(msg, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def handle(msg: dict) -> None:
    method = msg.get("method")
    id_ = msg.get("id")
    params = msg.get("params") or {}

    if method == "initialize":
        ci = (params.get("clientInfo") or {})
        audit("initialize", client=ci.get("name"), clientVersion=ci.get("version"),
              protocolVersion=params.get("protocolVersion"))
        _reply(id_, {
            "protocolVersion": params.get("protocolVersion") or PROTOCOL_FALLBACK,
            "capabilities": {"tools": {"listChanged": False}, "prompts": {"listChanged": False}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION,
                           "title": "Takealot ERP（只读 + 启动入口）"},
            "instructions": ("Takealot 跨境 ERP。取数用下面的工具（只读）；改价/改库存/上架只在工作台界面里做。"
                             "取不到数据时工具会返回 ok:false 与真实原因，照实解释，不要编数字。"),
        })
        return

    if method in ("notifications/initialized", "initialized"):
        return  # 通知，无响应

    if method == "ping":
        _reply(id_, {})
        return

    if method == "tools/list":
        defs = tool_defs()
        audit("tools/list", count=len(defs))
        _reply(id_, {"tools": defs})
        return

    if method == "tools/call":
        name = params.get("name")
        audit("tools/call", tool=str(name))
        try:
            text = call_tool(str(name), params.get("arguments") or {})
            _reply(id_, {"content": [{"type": "text", "text": text}], "isError": False})
        except Exception as exc:
            _reply(id_, {"content": [{"type": "text", "text": "{0}: {1}".format(type(exc).__name__, exc)}],
                         "isError": True})
        return

    if method == "resources/list":
        _reply(id_, {"resources": []})
        return
    if method == "prompts/list":
        audit("prompts/list", count=len(PROMPTS))
        _reply(id_, {"prompts": PROMPTS})
        return

    if method == "prompts/get":
        pname = str(params.get("name") or "")
        audit("prompts/get", prompt=pname)
        try:
            _reply(id_, prompt_messages(pname, params.get("arguments") or {}))
        except Exception as exc:
            _reply(id_, error={"code": -32602, "message": "{0}: {1}".format(type(exc).__name__, exc)})
        return

    if id_ is not None:
        _reply(id_, error={"code": -32601, "message": "Method not found: {0}".format(method)})


def main() -> int:
    parent = "?"
    try:
        ppid = os.getppid()
        out = subprocess.run(["ps", "-p", str(ppid), "-o", "comm="], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip()
        parent = out or "?"
    except Exception:
        pass
    audit("spawn", parent_comm=parent, erp_home=str(_home().root))
    for raw in sys.stdin:
        line = raw.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            continue  # 脏行不该把整个连接带崩
        if isinstance(msg, list):  # 批量请求
            for m in msg:
                if isinstance(m, dict):
                    handle(m)
            continue
        if isinstance(msg, dict):
            try:
                handle(msg)
            except Exception as exc:  # 协议层不许静默死掉
                if msg.get("id") is not None:
                    _reply(msg.get("id"), error={"code": -32603, "message": str(exc)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
