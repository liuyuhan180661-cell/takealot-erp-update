# Takealot ERP（工作台）—— 给 Codex 等宿主的项目指令片段

> 用法：把本文件内容**追加**到 `~/.codex/AGENTS.md`（全局）或项目根 `AGENTS.md`。
> 生成的命令：`erp mcp config --host codex --write`（只追加，不覆盖你已有内容）。

## 这是什么

本机有一个常驻的 Takealot ERP 工作台（本地服务 + 界面），通过 **MCP** 暴露一组 `erp_*` 工具。
**它不是网页 SaaS**：服务只监听 127.0.0.1，数据都在本机（`ERP_HOME`，默认 `~/.takealot-erp`）。

## 两条铁律

1. **读在对话，写在界面。** `erp_*` 工具全是只读；改价、改库存、上架、发 loadsheet 一律只在
   工作台界面里做 —— 工具表里没有这类工具，别试图绕。
2. **拿不到就说拿不到。** 工具返回 `ok:false` + 真实原因时照实转述，**不要编数字**、不要用
   「大概/通常」补值。

## 工具与用法

| 用户说 | 调用 |
|---|---|
| 打开工作台 / 打开中台 / 起 ERP | `erp_workbench_open`（服务没起就起，再开窗口；回话报端口与 URL） |
| 工作台在吗 / 端口多少 | `erp_status` |
| 自检 / 哪里不通 | `erp_doctor`（13 项，失败项带真实原因） |
| 今天几单 / 净利多少 | `erp_overview`、`erp_orders` |
| 库存 / 商品 / 缺货 | `erp_products` |
| 结算 / 对账 / 平台费 | `erp_finance` |
| 采集箱 / 跟卖池 | `erp_collection` |
| 出口通不通 / Key 对不对 | `erp_diagnostics` |
| 不确定用户指什么 | `erp_route`（传原话；命中给硬指令，没命中就说没命中，**不要猜**） |

参数：`storeId`（可选，默认用界面里当前店铺）、`limit`（订单/商品条数）。

## 命令行等价物（没有 MCP 时）

```bash
erp open            # 起服务 + 开窗口
erp open --no-window
erp status          # 退出码 0=在跑、3=没跑
erp doctor          # 13 项自检
erp route "把工作台打开"
erp stop
```

## 排障

1. 先 `erp doctor`，修它报 FAIL 的那一项
2. 服务没起：`erp open --no-window`，再看 `~/.takealot-erp/logs/server.out` 尾部
3. `ok:true` 但没数据 = 真的没数据（没绑店铺/没订单），不是坏了
