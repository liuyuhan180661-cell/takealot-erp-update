#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""定时抓取 / 启动爬虫（只读，不改平台数据）—— 把公开页/目录缓存刷一遍。

做什么：调本机服务的目录刷新，把商品公开数据（类目/属性/竞品快照）拉到最新，
后续的开 listing / 竞品监控 / 合规检测都用这份缓存，不临场抓。
用法：  <venv python> crawl_pull.py [--target <PLID|TSIN|url>] [--limit N]
退出码：0 = 刷新成功；1 = 刷新了但有失败项；>=2 = 起不来/接口报错。
"""
from __future__ import annotations

import argparse
import datetime as dt
import sys

import _erpclient as C


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", default="")
    ap.add_argument("--limit", type=int, default=200)
    args = ap.parse_args()

    try:
        cli = C.Client()
    except Exception as exc:
        C.die("读不到本机服务：{0}".format(exc))

    print("定时抓取 · {0}".format(dt.datetime.now().strftime("%Y-%m-%d %H:%M")))
    if args.target:
        res = cli.call("POST", "/crawler/pull", body={"target": args.target, "force": True})
        what = "单目标抓取 {0}".format(args.target)
    else:
        res = cli.call("POST", "/catalog/refresh", body={"limit": args.limit})
        what = "目录缓存刷新"
        if not res or res.get("ok") is False:
            # 目录刷新不可用就退回批量抓取（同样是公开页，不改平台数据）
            res = cli.call("POST", "/crawler/batch", body={"limit": args.limit})
            what += "（目录刷新不可用，已改走批量抓取）"

    if not res:
        C.die("{0}：接口没有返回（服务没起？）".format(what))
    if res.get("ok") is False:
        print("{0} 失败：{1}".format(what, res.get("error") or res))
        return 2

    ok_n = res.get("ok_count") or res.get("succeeded") or res.get("count") or res.get("total")
    bad_n = res.get("failed") or res.get("failedCount") or res.get("errors")
    print("{0}：{1}".format(what, "完成" if not bad_n else "完成但有失败项"))
    for k in ("updated", "refreshed", "ok_count", "total", "count", "cached", "failed", "elapsedMs"):
        if res.get(k) is not None:
            print("    {0} = {1}".format(k, res.get(k)))
    if ok_n is None and bad_n is None:
        print("    （接口没给条数，这里就照实不编：{0}）".format(
            ", ".join(sorted(list(res.keys()))[:8])))
    return 1 if bad_n else 0


if __name__ == "__main__":
    sys.exit(main())
