---
name: takealot-erp-operator
description: "Takealot ERP 工作台：启动/状态/自检、中文意图路由，只读取数（总览/订单/商品/财务/采集箱/诊断）。写平台只在界面做。"
version: 2.0.0
author: Takealot ERP
license: MIT
platforms: [macos, windows, linux]
metadata:
  hermes:
    tags: [takealot, erp, ecommerce, south-africa, marketplace, mcp]
    category: productivity
    related_skills: [openclaw-erp]
---

# Takealot ERP 操作（形态 v3：常驻服务端 + 工作台）

南非 Takealot 跨境卖家的本地 ERP。**它不嵌在任何一个 agent 里**：本体是一个常驻服务端
（127.0.0.1，自带前端资产），任何一个 agent（Hermes / Codex / Cursor / …）都只是它的入口。

两种用法，都能用：

| 方式 | 什么时候用 |
|---|---|
| **MCP 工具**（`erp_*`） | 宿主支持 MCP（Hermes / Codex / Cursor）—— 取数、启动、自检都在工具里 |
| **命令行 `erp`** | 没有 MCP、或只要一次性动作 —— `erp open/status/doctor/route/stop` |

## 两条铁律（先记住再往下读）

1. **读在对话，写在界面。** 取数（总览/订单/商品/财务/采集箱/诊断）走工具；**改价、改库存、上架、
   发 loadsheet 一律不在对话里做**，把用户引到工作台界面。工具表里**没有**任何写平台的工具，这是故意设计的。
2. **拿不到就说拿不到。** 全链路零模拟数据：取不到时返回 `ok:false` + 真实原因，
   **永远不编样例数字**，也不许用「大概/通常」补一个值。

## 一、启动与状态（最常见的诉求）

| 用户说 | 做什么 |
|---|---|
| 打开工作台 / 打开中台 / 启动 ERP / 起工作台 | `erp_workbench_open`（或 `erp open`）。服务没起就起，然后开窗口。回话时报端口与 URL |
| 工作台在吗 / 端口多少 / 服务在跑吗 | `erp_status`（或 `erp status`）—— 端口、PID、版本、数据目录、密钥库 |
| 自检 / 哪里不通 / 体检 | `erp_doctor`（或 `erp doctor`）—— 13 项，失败项带真实原因 |
| 停掉工作台 / 关掉它 | `erp stop`（**注意**：停了以后界面就用不了了，先跟用户确认） |

要点：**服务是常驻的，窗口只是看板**。关掉窗口服务不会停；任何人问数据时工具会**自动把服务起起来**
（不开窗口），所以用户问「今天几单」不需要先去点图标。

## 二、取数工具（全部只读）

| 工具 | 内容 | 落到哪个端点 |
|---|---|---|
| `erp_overview` | 营收/净利/待发货/BuyBox/对账差异 KPI + 风险提示 | `GET /overview` |
| `erp_orders` | 订单列表与逐单净利（`limit` 默认 20） | `GET /orders` |
| `erp_products` | 店铺商品目录（库存/价格）+ 销量推算 | `GET /products` |
| `erp_finance` | 平台计费、结算与对账差异 | `GET /financial` |
| `erp_collection` | 采集箱（跟卖池）里的行与核算输入 | `GET /collection` |
| `erp_diagnostics` | 环境事实：出口通道、Seller API、密钥加密、公开爬取通道（带实测证据） | `GET /diagnostics` |
| `erp_route` | 中文说法 → 确定性落点（读工具 / 界面 / 运维 / 专项脚本 五类）。**命中不了就说没命中，不要猜** | 本机词表 |

可选参数：`storeId`（不给就用界面里当前选中的店）、`limit`。

## 三、用户说法 → 做法（词表，确定性 · 五类落点）

词表把中文说法**确定性地**落到五类落点上（`erp_route` 给硬指令，各宿主行为一致）。**顺序有意义**：
写入类排在最前，所以「把库存改成 5」不会落到读工具上。

| 用户说 | 落点 |
|---|---|
| 打开/启动/进去/起工作台、打开中台 | `erp_workbench_open`（或 `erp open`） |
| 工作台在吗、端口多少、服务在跑吗 | `erp_status` |
| 自检、哪里不通、体检 | `erp_doctor`（13 项） |
| 停掉/关闭工作台 | 先确认，再 `erp stop` |
| **改价、改库存、上架、发 loadsheet** | **不在对话里做**（红线）→ `erp open` 把人引到界面，说清「在工作台里做，每笔都留审计」 |
| 今天营收多少、今天几单、赚了多少、经营总览 | `erp_overview` |
| 看下订单、最近订单、净利多少、待发货 | `erp_orders` |
| 库存还剩多少、零库存、在售多少、缺主图 | `erp_products` |
| 对账、平台扣了多少、结算、账单 | `erp_finance` |
| 采集箱、跟卖池、选品 | `erp_collection` |
| 读不到、拿不到、连不通、为什么没有数据 | `erp_diagnostics`（逐项带证据，不要猜原因） |
| 物流巡查、送仓单、有没有退货 | 加载 `takealot-erp-logistics-patrol`，跑它自带的脚本（**只读**） |
| 盯盘、买盒、24 小时盯着价格 | 加载 `takealot-erp-buybox-watch`：**先做一次授权**，写入只由它的脚本执行 |
| 竞品监控、合规检测 | `erp open` 指到工作台对应模块（抓不到就说抓不到，不用估算值顶替） |

不确定用户指什么时**跑 `erp_route`**（把原话传给它）：命中就给硬指令，没命中就照实说词表没命中，
并按三分法兜底 —— ① 问数据 → 对应只读工具；② 要写入 → 红线，界面里做；③ 运维 → `erp open/status/stop/doctor`。

**定时任务（物流巡查 / 买盒日报 / 订单巡检 / PO 跟踪 / 定时抓取 / 自动跟价）跑在客户机自己的服务里**
（调度器 `server/scheduler.py`，脚本 `ERP_HOME/server/jobs/`，排期 `ERP_HOME/jobs/jobs.json`）——
脚本直跑不经过模型，所以不会幻觉；**不依赖 Hermes、不依赖任何外部机器**。
自然语言入口（agent 必须全会，面板只是给不熟提示词的用户兜底）：

| 用户说 | 落点 |
|---|---|
| 有什么定时任务 / 任务都在跑吗 | `erp_jobs`（或 `erp job list`）：排期、上次结果、下次时间、心跳 |
| 现在就跑一次巡检 / 跑一下订单巡检 | `erp job run <id>`（id 从 list 取，不要猜） |
| 关掉巡检 / 启用自动跟价 | `erp job disable\|enable <id>`；**写价任务命令行开不了**，必须先去工作台授权 |
| 检查更新 / 升级到最新版 | `erp update --check` → `erp update`（校验 sha256，不过拒装） |
| 启动爬虫 / 定时抓取 | `erp job run crawl-pull` |
| PO 单跟踪 | `erp job run po-tracking` |

**不要**把「没有消息」当成「一切正常」：每轮都有证据文件；离线/失败会明确出声（连续离线升级告警）。
退出码：`0`=没事、`1`=有要处理的事、`>=2`=真失败。

## 四、领域要点（回答业务问题时要用的口径）

- **计费口径**：成功费按「含 VAT 售价 × 类目费率 × 1.15」（官方费率表）；履约/配送/跨仓等按官方价目表
  ×1.15 入账；平台**不设最低成功费**（真店账单已验证）。VAT 不单独从卖家到手扣，只嵌在平台收费里。
- **采集箱 ≠ 新建草稿箱**：采集箱是**跟卖池**（平台上已存在的商品），跟卖**只能改价格与库存**
  （平台 CreateOffer 只接受条码/SKU + 售价 + 库存）；新建走独立草稿箱，两者不共享行。
- **BuyBox 跟价**：只处理「有货 + 有价格 + 在跟卖池或目录里」的行；跟价信号异常时先看
  `erp_diagnostics` 的出口与 Seller API 两项，别先怀疑算法。
- **口径统一**：日期按南非时间（SAST, UTC+2）看订单；净利 = 售价 − 成功费 − 履约费 − 采购成本
  （跨境 VAT 由平台代收代缴，卖家侧不出现缴纳动作）。

## 五、宿主怎么挂（给安装/排障用）

**Hermes**（已实测：`hermes mcp test` → Connected，10 tools）：

```bash
erp mcp config --host hermes --write    # 内部就是 hermes mcp add，写入 ~/.hermes/config.yaml
hermes mcp list && hermes mcp test takealot-erp
```

**Codex**（`~/.codex/config.toml`）：

```bash
erp mcp config --host codex --write     # 追加 [mcp_servers.takealot-erp]
codex mcp list
```

**其它宿主**：只要支持 MCP stdio，命令就是 `python <ERP>/server/mcp_server.py`（带 `ERP_HOME` 环境变量）。
技能文本（本文件）放进该宿主的技能目录；Codex 用 `AGENTS.md` 片段（见交付包 `AGENTS.md`）。

## 六、排障顺序（照这个顺序，别跳）

1. `erp doctor` —— 13 项里哪一项 FAIL，就修那一项（每项都带真实原因）
2. 服务没起 → `erp open --no-window`，再看 `ERP_HOME/logs/server.out` 尾部
3. 端口被占 → `erp status` 会指出「端口被别的进程占着」；换 `--port` 或找出占用者
4. 取数为空但 ok:true → 那是**真的没数据**（没绑店铺/没订单），不是坏了：看 `erp_diagnostics` 的 `mode` 字段
5. 界面打不开但服务在跑 → 浏览器问题：`erp open`（默认浏览器）而不是 `--app`
