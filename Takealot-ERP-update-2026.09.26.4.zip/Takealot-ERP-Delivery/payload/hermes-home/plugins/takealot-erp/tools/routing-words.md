# Takealot ERP · 中文意图路由与词表（人读版）

> 配套实现：`plugins/takealot-erp/tools.py`（`INTENT_RULES` / `classify_intent` / `build_directive`）
> 注册入口：`plugins/takealot-erp/__init__.py` → `register(ctx)`
> 审计落盘：`plugins/takealot-erp/state/agent_intent_audit.jsonl`
> **本文件与代码同源**：词表以 `tools.py` 为准，两边一起改；改完必须重跑
> `自然语言验收-20句.py`（A 20 句 / B 同义词矩阵 / C 否定上下文，共 42 条断言）。

## 为什么要有这一层

用户用中文说一句话（“帮我找一下我的订单”“扒一下这个链接”“帮我把价格改成 199”），
如果让模型自由判断该调哪个工具，同一个问法两次可能走两条路，而且**错了也不留痕**。
这里把判断变成一张**有序词表**：命中就向本轮上下文注入一条硬指令（点名必须调用的工具），
命中不了就不注入。于是：

* 判定是确定性的 —— 同一句话永远同一个意图，可回归测试；
* 判定是**可审计**的 —— 原话、命中规则、命中词、期望工具、实际调用的工具都进 jsonl；
* 判定是**保守**的 —— 拿不准就不注入（`classify_intent` 返回 `None`），把自由留给模型，
  而不是硬塞一个错工具。

## 工具 ↔ 意图对照表

| 意图 | 工具 | 说明 |
|---|---|---|
| `read_overview` | `takealot_erp_overview` | KPI/告警/最近订单/BuyBox 候选/平台费 |
| `read_orders` | `takealot_erp_orders` | 走 `orders_live`，行键 `items[]` |
| `read_products` | `takealot_erp_products` | 本店目录，必须看 `total/mapped/hasMore` |
| `read_finance` | `takealot_erp_finance` | 行键是 `months[]` / `ledgerRows[]`，**不是** `rows` |
| `read_fulfilment` | `takealot_erp_fulfilment` | 行在 `stages.inbound/outbound.pos` |
| `read_collection` | `takealot_erp_collection` | 采集箱；空 = 真实状态 |
| `read_listings` | `takealot_erp_listings` | 草稿；按店过滤为空会自动再读全量并解释归属 |
| `read_selfcheck` | `takealot_erp_selfcheck` | 环境自检 + 公开通道 transport |
| `crawl_single` | `takealot_crawl_product` | 链接/PLID/TSIN → 商品事实 + 四窗口销量 + 竞品 |
| `market_search` | `takealot_market_search` | 关键词搜市场行情，不落库 |
| `collection_add_single` | `takealot_collection_add` | 写**本地** `state/collection.json` |
| `collection_params` | `takealot_collection_update` | 改采集箱行的**本地核算参数**（成本/币种/汇率/汇损/头程/重量/尺寸）——费率条件的输入 |
| `route_verdict` | `takealot_route_verdict` | 跟卖 vs 建档（只读判定） |
| `write_refused` | （无工具） | 改价/改库存/发 Offer/上架 → 回绝 + 引到界面 |

**没有写平台的工具**：改价、改库存、发/改 Offer、上架、发布一律不暴露给 agent。
`write_refused` 意图只注入“回绝 + 指路界面”的指令，不调用任何工具。
**本地账本可以写**：采集箱行（加行 `collection_add` / 改核算参数 `collection_params`）都是本机 state，
平台看不到、也不产生平台写请求 —— 这两类才有工具。

## 判定顺序 = 优先级

```
1  write          改价/改库存/上架/发布（强表达无条件；弱表达遇到问句就不算写）
2  route          跟卖还是建档 / 要不要上架 / 该不该建档 / 这个能不能跟卖
3  collection_add 采集箱 + 存/加/放/收（且有采集箱这个词）
4  params         成本/汇率/汇损/头程/重量/尺寸 + 改成/填成/设成…（设费率条件；只有名词不算）
5  market         市场 / 行情 / 竞品 / 热销 / 关键词 / 排行 / 榜单 / 市场价 / 卖多少钱
6  crawl          句子里有**外部对象**（链接/URL/PLID/TSIN/这个商品/这款/同款/这货…）
7  read           按名词：履约 → 财务 → 草稿 → 采集箱 → 自检 → 订单 → 商品 → 总览
8  crawl(兜底)    只有裸抓取动词（抓一下/扒一下/爬取/取数/撸一下/弄下来…）
9  None           都没命中 → 不注入
```

> `params` 在 `collection_add` **之后**：一句话里既有「存进采集箱」又有「成本 30」时，先按采集处理
> （`takealot_collection_add` 本身就收这些参数，一次写完）；没有采集动词时才走 `collection_params`。

### 四个派生标志（“找/搜”歧义的解法）

| 标志 | 含义 | 命中词举例 |
|---|---|---|
| `external_object` | 句子里有**外部对象** | 链接、网址、url、`PLID12345678`、`TSIN…`、7–10 位数字、这个商品、这款、同款、**这货**、商品页 |
| `external_force` | 天生属于“外面”的词 | 市场、**市场价**、行情、竞品、热销、热搜、关键词、排行、榜单、**卖多少钱**、多少钱、价位、报价 |
| `own_data` | 有自有数据名词，且**没有**上面两类 | 我的订单、我的商品、本店、店里、采集箱、订单、销量、余额、结算、待发货… |
| `negated` | 句子在**否定**抓取动词 | 不要抓取、别采集、先别扒、不用取数、暂时不要搜 |

规则：**外部对象优先抓取、自有数据优先查询、否定一律不抓**。

* `own_data` 无外部对象 → 只可能是“查我自己的帐”，走 read；
* 有外部对象 + 没点名「市场/行情/竞品/关键词/排行/榜单/类目/行业」→ 走 crawl
  （“搜同款，看看别人卖多少钱”抓这一个商品，比搜关键词准）；
* 有外部对象 + 点名了市场词 → 走 market（“看看这个链接的市场行情”）；
* 命中否定词 → crawl / market / collection_add 三条规则整体跳过，落回只读或干脆不注入。

## 抓取动词词表（用户实际会说的整套同义词）

`抓` / `抓一下` / `抓取` / `抓数据` · `爬` / `爬取` / `爬一下` / `爬一份` ·
**`扒` / `扒一下` / `扒一份`** · **`撸` / `撸一下`** · **`取数` / `取一下数`** ·
**`弄下来` / `弄一份`** · `采一下` / `采集` · `看一下这个` / `看看这个` / `查一下这个` ·
`分析这个` / `评估这个` / `值不值得` / `能不能跟卖` / **`搜同款` / `找同款`**

> 「这个能不能跟卖」按**判定**处理（→ `takealot_route_verdict`），不是抓取：它问的是结论，
> 判定工具会先抓公开页再给 route/Reason，比让模型看一堆抓取字段自己下结论更准。

## 反例（最容易误判的，逐一回归）

| 原话 | 判定 | 为什么 |
|---|---|---|
| 帮我找一下我的订单 | `read_orders` | 有 `own_data`（我的订单），无 `external_object` |
| 搜一下最近 30 天销量 | `read_orders` | 有 `own_data`（销量），无外部对象 |
| 帮我把价格改成 199 | `write_refused` | 强表达：`把…价格…改` 同现，问句语气也压不住 |
| 把这款商品的库存改成 50 | `write_refused` | 强表达：`把` + 目标 + 库存 + 改 |
| 帮我上架这个商品 | `write_refused` | 弱表达 `上架`，且句中没有问句词 |
| 这个商品要不要上架？ | `route_verdict` | `要不要` 是问句词 → 不是写；`要不要上架` 命中路由 |
| **不要抓取这个链接** | 不注入（或落回只读） | `negated` 命中 → crawl 规则跳过 |
| **别采集这个商品了** | 不注入 | 同上 |
| **先别扒这个商品 / 不用取数了** | 不注入 | 同上 |
| **这个不要存进采集箱** | 不注入 | 否定词 + 采集动词 → 写采集箱也跳过 |
| **这个类别抓取一下** | `crawl_single` | 「类别」的“别”是假否定，负向断言挡住 |
| 看看这个链接的同款价格 | `crawl_single` | 外部对象优先 |
| 帮我把这个商品加到采集箱 | `collection_add_single` | 采集箱 + 加动词 |
| **把这条的成本改成 30 元** | `collection_params` | 核算字段（成本）+ 设置动词（改成） |
| **汇率填成 0.25** | `collection_params` | 核算字段（汇率）+ 设置动词（填成） |
| **重量设成 0.18 公斤，长宽高补上** | `collection_params` | 尺寸/重量 + 设置动词 |
| **这个商品的成本是多少？** | 不注入（或 read） | 只有字段名、没有设置动词 → 不是设条件 |
| **先别改汇率** | 不注入 | `negated` 命中 → params 跳过 |
| **帮我把价格改成 199** | `write_refused` | 价格是平台字段，不是本地核算参数 |
| **帮我把这个商品上架** | `write_refused` | 上架 = 平台写 |
| 采集箱里现在有什么？ | `read_collection` | 采集箱 + 只读词 → 不是写 |
| 帮我查一下竞品都在卖多少钱 | `market_search` | `external_force`（竞品/多少钱） |
| 这货多少钱 | `crawl_single` | 「这货」是外部对象；没点名市场词 → 抓单个 |
| 你好 / 谢谢 | 不注入 | 一句都不命中 → 返回 `None` |

## 硬指令长什么样（注入到本轮 user 消息，不动 system prompt）

```
【Takealot ERP · 本轮意图路由（确定性词表命中，不是模型猜测）】
意图 = read_orders
命中规则 = read.orders｜命中词 = 订单
本轮必须调用工具 = takealot_erp_orders
硬性要求：
  1. 本轮的取数动作只允许用 `takealot_erp_orders`；不要拿别的工具或记忆里的数字替代。
  2. 只转述工具返回的字段。总数/空值一律以工具回的 `total`/`empty`/`why_empty` 为准；
     `empty:true, total:0` 是真的没有，不许补一行「示例」或「大概」。
  3. 工具报 `blocked`/`error`/`transport` 时照实说明通道与原因（proxy→direct→blocked），
     禁止编造抓取结果。
  4. 平台写操作（改价/改库存/发 Offer/上架）没有对应工具：用户提就回绝并引到界面。
```

`write_refused` 的注入不同：不点名工具，明确“没有写平台的能力”，把用户引到
**BuyBox 跟价 / 商品管理 / 上架编排**，并禁止声称“已经帮你改好了”。

## 审计 jsonl

每行一条 JSON，两段式，靠 `session` + `turn` 串起来：

```json
{"at":"2026-09-20T14:12:33+0800","stage":"route","session":"s1","turn":"t7",
 "say":"帮我找一下我的订单","rule":"read.orders","intent":"read_orders",
 "matched":["订单"],"expectTool":"takealot_erp_orders","injected":true,
 "why":"订单与净利只读。"}
{"at":"2026-09-20T14:12:34+0800","stage":"tool_call","session":"s1","turn":"t7",
 "tool":"takealot_erp_orders","args":"{\"storeId\": \"store-2\"}",
 "forIntent":"read_orders","rule":"read.orders","expected":"takealot_erp_orders",
 "matched_expected":true}
```

* `stage=route` 由 **`pre_llm_call`** 写：原话 → 命中规则 → 命中词 → 判定意图 → 期望工具。
* `stage=tool_call` 由 **`pre_tool_call`** 写：实际调用的 `takealot_*` 工具与参数，
  并给出 `matched_expected`（实际 == 期望？）。只记账，从不拦截。
* 只有 `takealot_*` 的工具会记账；写平台的动作用户在界面做，不经过本插件。
* 两个钩子都**不会因为审计失败而影响本轮**（写盘异常被吞掉）。

查最近的路由决策：

```powershell
Get-Content "$env:LOCALAPPDATA\hermes\plugins\takealot-erp\state\agent_intent_audit.jsonl" -Tail 20
```

## 怎么扩展词表

1. 打开 `tools.py`，找到 `INTENT_RULES`（有序元组）。**新规则插在 `read` 组之前**才会优先命中；
   只有新 read 名词才往后加。
2. 一个读词组只需一行：

   ```python
   {"id": "read.promotions", "kind": "read", "intent": "read_promotions",
    "tool": "takealot_erp_promotions",
    "phrases": ("促销", "活动", "折扣"), "why": "促销只读。"},
   ```

   `kind` 决定匹配方式：`write` / `route` / `collection_add` / `market` / `crawl` / `read`。
3. **同时**在 `TOOLS` 里加 `(name, SCHEMA, _handle_x, emoji)`，并在 `_handle_x` 里**写死实测行键**
   （注释里注明证据）。工具名一旦对外公布就不要再改。
4. 词表改了必须重跑验收：`python 自然语言验收-20句.py`，三个块都要满（A 20/20、B 16/16、C 6/6，
   共 `RESULT 42/42`）；再加一句你自己的反例进 `CASES`。
5. 五条铁律：
   * 加抓取词时先问“这句话里有外部对象吗？”——没有就别进 `crawl`；
   * 加写动词时先问“这可能是问句吗？”——问句词（该不该/要不要/能不能/怎么/吗/？）要能把它压回只读；
   * 加否定词时把**单字「别」**配上 `(?<![类特分别个])` 负向断言，否则「类别/特别/分别」会被误判成否定；
   * 加市场词（多少钱/价位/报价）要记得 crawl 规则里那条“有外部对象且没点名市场词 → 抓单个”的优先级；
   * 别把本地箱子（采集箱/跟卖池/草稿箱）当成外部对象。

## 已知边界（如实记录，不装全能）

* `market_search` 必须有**关键词**。用户只说“看看竞品价”没给关键词时，工具会返回
  “query 必填，先问用户”，不会自己编一个关键词去搜。
* 抓取受这台机器的出口限制：`transport=blocked` 表示 Cloudflare 挡了本机出口，
  不是“商品不存在”。工具会带 `ladder` 说明，要求如实报告，不许编造抓取结果。
* 「这个能不能跟卖」归 `route_verdict`（判定），不是 `crawl_single`（抓数据）——
  判定工具内部会先读公开页 + 自有 Offer，再给结论。
* 否定判别是**邻近**匹配（否定词后 4 字内出现抓取/搜索/写箱动词）；
  跨小句的否定（“不要这个了，去抓那个”）不保证，这种情况会正常触发抓取。
* `collection_add` 写的是本地 `state/collection.json`；验收脚本会在调用后**逐字节还原**该文件，
  交付环境不留测试残留。
* 路由只决定“**调哪个工具**”，不决定参数。参数（storeId、时间窗、关键词）仍由模型按用户原话给。
