---
name: takealot-erp-operator
description: "Takealot ERP 操作：触发词路由、抓取降级、利润核算、BuyBox 跟价、合规与对账。"
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [takealot, erp, ecommerce, south-africa, marketplace, crawler, cdp]
    category: productivity
    related_skills: [openclaw-erp]
---

# Takealot ERP 操作 Skill（完整版）

南非 Takealot 跨境卖家的本地 ERP（Hermes 桌面插件，插件 id `takealot-erp`）：费用/利润核算、
BuyBox 跟价、采集箱与上架编排、竞品监控与销量推算、合规检测、结算单对账、履约闭环、环境自检。
引擎就在本机，**不联网也能算**（只有取实时数据、抓公开页、生成 AI 文案才需要出网）。

本技能的两条铁律，先记住再往下读：

1. **读的能力走工具，写的能力只走界面。** 对话里能读订单/库存/财务/履约/采集箱/草稿、能抓公开数据、
   能判该跟卖还是建档；**改价、改库存、上架一律不在对话里做**，只把用户引到界面。
2. **拿不到就说拿不到。** 后端全链路零模拟数据（CONTRACT v7）：取不到时返回 `ok:false` /
   `mode:"blocked"` + 真实原因，**永远不返回编造的样例数字**。Skill 层不许用"大概/通常"补一个值。

---

本交付是**三半**，缺一不可：

| 半边 | 文件 | 说明 |
|---|---|---|
| 界面 | `desktop-plugins\takealot-erp\plugin.js` | 15 个模块、主题、`.tkl` |
| 后端 | `plugins\takealot-erp\dashboard\plugin_api.py` | 全 `def` 端点、零模拟数据 |
| **agent 工具面** | `plugins\takealot-erp\tools.py` | **12 个原生工具（toolset=`takealot_erp`）+ 两个钩子 `pre_llm_call` / `pre_tool_call`** |

改任何一半都要**三半一起验**（界面改完跑渲染 harness；后端改完扫端点；工具/词表改完跑词表断言 + 20 句自然语言验收）。

---

## 1. 触发词与意图路由表（核心）

### 1.1 只读工具（8 个）

| 工具名 | 意图 | 落到哪个端点 |
|---|---|---|
| `takealot_erp_overview` | 经营总览、KPI、走势、风险提示 | `GET /overview` |
| `takealot_erp_orders` | 订单列表/明细、待发货、逐单净利 | `GET /orders`、`GET /orders/{order_id}`、`GET /orders/live` |
| `takealot_erp_products` | 本店商品目录、库存、缺货、单 SKU 详情 | `GET /products`、`GET /products/stats`、`GET /products/{sku}` |
| `takealot_erp_finance` | 财务、对账、结算单、余额、流水、履约费差异 | `GET /financial`、`GET /financial/live` |
| `takealot_erp_fulfilment` | 履约闭环、送仓单、入库、待收货 | `GET /fulfilment` |
| `takealot_erp_collection` | 采集箱（跟卖池）只读、查重 | `GET /collection` |
| `takealot_erp_listings` | 上架编排：草稿、装载表、必填属性、类目、变体主题 | `GET /listings/drafts`、`GET /meta/categories`、`GET /meta/attributes`、`GET /meta/variant-themes` |
| `takealot_erp_selfcheck` | 环境自检、通不通、Key 对不对、抓取通道状态 | `GET /health`、`GET /diagnostics`、`GET /crawler/status` |

### 1.2 抓取与本地写工具（5 个）

| 工具名 | 意图 | 落到哪个端点 |
|---|---|---|
| `takealot_crawl_product` | **有 URL / PLID / TSIN** 时抓一个商品的公开数据 | `GET /crawler/pull`、`POST /crawler/pull`、`GET /crawler/cache` |
| `takealot_market_search` | **只有关键词**时搜市场行情（不落库） | `GET /meta/catalog`（公开目录检索；关键词态不写 state） |
| `takealot_collection_add` | 把抓到的商品加进采集箱/跟卖池 | `POST /collection/add` |
| `takealot_collection_update` | 改采集箱行的**本地核算参数**（成本/币种/汇率/汇损/头程/重量/尺寸） | `POST /collection/update`（只写本地 state；平台侧字段会被拒） |
| `takealot_route_verdict` | 判定"该跟卖还是走装载表建档" | `GET /listings/prefill`（返回 `route`/`exists`/`routeSource`） |

### 1.3 中文同义词 → 意图 → 工具（对照表）

> 词表与代码同源（`plugins/takealot-erp/tools.py` 的动词表）；每句判定都写进
> `state/agent_intent_audit.jsonl`（原话 → 命中规则 → 意图 → 实际工具），可回溯、可自证。
> **缺词会漏判**：交付前用《自然语言触发对照表》逐词核一遍。

| 用户这么说（含同义词） | 意图 | 工具 |
|---|---|---|
| 今天怎么样 / 经营总览 / 大盘 / 这个月流水多少 / 有哪些风险 / 数据是哪来的 | 总览 | `takealot_erp_overview` |
| 我的订单 / 帮我找一下我的订单 / 找一下我今天的订单 / 最近30天有多少单 / 待发货的有哪些 / 这单赚了多少 / 订单详情 | 订单只读 | `takealot_erp_orders` |
| 我的商品 / 在卖的东西 / 哪些缺货 / 库存还有多少 / 商品列表 / 这个 SKU 现在卖多少 | 商品只读 | `takealot_erp_products` |
| 财务 / 对账 / 结算单 / 平台有没有多收钱 / 履约费对不上 / 余额 / 交易流水 / 月报 / 导出对账表 | 财务与对账 | `takealot_erp_finance` |
| 履约 / 送仓单 / 发货到 DC / 入库了没 / 待收货 / 履约费多少 | 履约闭环 | `takealot_erp_fulfilment` |
| 采集箱 / 跟卖池 / 采集了什么 / 采集箱里有重复吗 / 这条采集到哪一步了 | 采集箱只读 | `takealot_erp_collection` |
| 草稿箱 / 上架编排 / 装载表 / 必填属性 / 这个类目要填什么 / 变体主题 / 帮我写个标题和描述 | 上架编排只读 | `takealot_erp_listings` |
| 自检 / 环境检查 / 为什么读不到 / 抓取通道通不通 / Key 是不是失效了 / 桥在不在跑 | 环境自检 | `takealot_erp_selfcheck` |
| 帮我抓取 / **爬取** / **扒一下** / 抓一下这个 PLID… / 抓数据 / 取数 / 撸一下这个 / 把这份数据弄下来 / 找同款 / 搜同款 / 看看这个链接的数据 / 这货多少钱（**带链接 / PLID… / TSIN… / 条码时**） | 抓单个商品 | `takealot_crawl_product` |
| 搜一下 wireless earbuds 卖多少钱 / 市场行情 / 这个品类价格区间 / 帮我查查行情 | 市场行情搜索 | `takealot_market_search` |
| 采集这个 / 存进采集箱 / 加入跟卖池 / 这个也采一下 | 加入采集箱 | `takealot_collection_add`（**没指名店铺且绑了多家店时会回 `needsStoreChoice`，必须先问用户分派给哪家店**） |
| 把成本改成 30 / 汇率填成 0.25 / 重量设成 0.18kg / 长宽高补上 / 汇损系数改成 0.25 / 头程改成 25（**改的是采集箱行的本地核算参数**） | 设核算参数（费率条件的输入） | `takealot_collection_update`（只写本地 `state/collection.json`；**改价格/库存/listing 内容仍回绝并引到界面**） |
| 这个能不能跟卖 / 我是不是已经在卖这个 / 该跟卖还是建档 / 走装载表还是跟卖 | 跟卖/建档判定 | `takealot_route_verdict` |

**否定上下文（必须不触发）**：出现「不要 / 别 / 先别 / 暂时不用」+ 抓取类动词时，**不触发抓取**，
按字面执行（例如「先别采集这个」= 不动）。同理「找订单」里的"找"是查询语义，不是抓取。

### 1.4 反例（最容易幻觉的地方，逐条背下来）

- **「帮我找一下我的订单」= 查询，不是抓取。** 走 `takealot_erp_orders`。
- **「搜一下最近30天销量」= 查询/推算，不是抓取工具。** 有链接才 `takealot_crawl_product`；纯关键词走
  `takealot_market_search`。**没有 URL/PLID/TSIN，绝不调用 `takealot_crawl_product`。**
- **「帮我把价格改成 199」「把这个 SKU 上架」「库存改成 50」「帮我改标题」= 写操作 → 不在对话里做。**
  回复口径：写操作刻意留在界面里确认（商品管理改价/改库存、上架编排建草稿与装载表、BuyBox 跟价试算后应用），
  对话里不碰真店数据，然后把用户引到对应界面的具体位置。**不假装已改，也不去调写接口。**
  指路要指到**控件**：单个 listing 改价 =「BuyBox 跟价」模块 → 搜索框输入 SKU/PLID/标题定位那一行 →
  「目标价」列填数 → 「按此价调价」（手填价覆盖规则价，仍过底价熔断，偏差超 50% 会被拦下）；
  想按竞品自动算就走「按规则调价」，多条就勾选后「对选中跟价」。
- **「搜一下耳机」（无链接）→ `takealot_market_search`**，不要当抓取。
- **「把采集箱里那个改个价」→ 引到界面**（采集箱/商品管理），对话只读 `takealot_erp_collection`。
- **采集箱是「全店共用的一个池子」，分派店铺只是行上的标签 —— 未分派 ≠ 没采集到。**
  采集行会一直显示在采集箱里（店铺视图也会把未分派行一并带出来，返回里的 `unassignedIncluded`
  就是未分派条数）。因此报数必须分开讲：「本店 N 行 / 未分派 M 行」；**不许把某个店铺作用域里的
  空读成「采集箱是空的」**，也不许说「没入库」——先去读 `takealot_erp_collection`，按它的
  `total` / `empty` / `unassignedIncluded` 说话。
- **采集要归属哪家店：指名了就用，没指名且绑了多家店就先问，绝不猜。** 用户说「采集这个」而账号绑了
  两家店时，`takealot_collection_add` 会返回 `needsStoreChoice:true` 并列出可选店铺：照它的问题原样
  问用户（「这条要分派给哪家店？」），**本轮不要宣称已入库**（那时什么都没写）。用户答店名 → 再调一次
  并带上 `storeId`；用户答「不指定」→ 传 `storeId="不指定"`，行进未分派池，界面里随时可分派。
  猜店铺比未分派更危险：跟价与上架会用那家店的 Key，猜错等于把 A 店的数据挂到 B 店名下。
- **别把 demo/样例数字当业绩。** 返回里 `mode` 不是 `live` 时，明确说这是样例或空值。

### 1.5 路由纪律

- **一次只做一个动作**；意图命中多个时优先级：用户给了目标标识（URL/PLID/TSIN）→ 抓取类；
  否则读类；只要出现"改/设/上架/下架/发布"→ 拒绝并引到界面。
- **不靠猜**：命中动词表后按本表硬路由，路由结果要留痕（`state/agent_intent_audit.jsonl`），
  演示时用《自然语言验收-20句.md》的原话念一遍给客户看命中率。
- **金额一律 `R 1,234.00`，中文作答，不使用 Emoji。**

---

## 2. 抓取流程与降级阶梯（CDP → DOM → 公开 API → blocked）

抓取是本技能的核心能力，**必须按阶梯降级，每一层失败都如实回报，不许上一层编一个值给下一层**。

### 2.1 四层阶梯

| 层 | 走法 | 适用场景 | 落地到 ERP 的路径 |
|---|---|---|---|
| **L1 CDP / 页面会话** | 浏览器扩展在**客户已登录的 Chrome/Edge** 里带会话取数（`debugger` 是**可选权限**，需点一次「启用 CDP 抓取」授权）；Cloudflare 挑战在真人浏览器里自然通过 | 需要登录态的页面（卖家后台、被挑战的买家页）、官方模板 `GET https://seller-api.takealot.com/v1/loadsheets/templates` | 经本地桥 `127.0.0.1:18790` → `state/attributes_templates.json` 等；后端表现为 `transport: ingest` |
| **L2 DOM 兜底** | 页面已渲染时按 DOM 选择器读标题/价格/图片/面包屑 | L1 不可用但页面在手 | 同 L1；选择器被官方改了就**报空 + `priceKnown:false`**，绝不填 199 / 4.5 这类假默认值 |
| **L3 公开 API** | 后端 `dashboard/crawler.py` 直接打 `https://api.takealot.com/rest/v-1-12-0`（`product-details/{plid}` + 评论分页），无登录态 | 商品公开数据、评论时间线→销量推算 | 写 `state/velocity_cache.json`；`transport` = `proxy` 或 `direct` |
| **L4 blocked** | 以上都不通 | 出口被拦、PLID 下架、超时 | `ok:false` + `mode:"blocked"` + `transport:"blocked"` + `error` + `hint`；**不 500、不编数据** |

补充两条**离线投喂**通道（当机器根本不能出网时）：

- `POST /crawler/ingest`：把抓到的原始 JSON 推进来，走**完全相同的解析路径**，零网络 → `transport: ingest`。
- 投放目录 `state/ingest/*.json`：在能出网的机器上跑 `scripts/crawl_takealot_ingest.py` 产出，投进去；
  `GET /crawler/status` 与 `GET /crawler/pull` 会**先收割这个目录**再走阶梯。

### 2.2 返回里的 `transport` 字段怎么读

| `transport` | 含义 | 能对客户说什么 |
|---|---|---|
| `proxy` | 走了配置的出口代理取回（成功） | 抓取通道正常（走出口） |
| `direct` | 本机直连取回（成功） | 抓取通道正常（直连） |
| `blocked` | 代理与直连**都失败** | 抓取不可用，原因是出口/目标；Seller API 侧不受影响 |
| `ingest` | 数据来自手工投放（`/crawler/ingest` 或 `state/ingest/*.json`） | 数据是从能出网的机器投进来的 |
| `cache` | 命中本地缓存（评论速度缓存 `state/velocity_cache.json`，TTL **5 天**；AI 分析缓存 `state/ai_analysis.json`，TTL **24 小时**） | 这是 N 天前的缓存，不是刚抓的 |

`transport` 之外还要看：`mode`（`live`/`blocked`/`local`/`empty`）、`cached` / `fresh` / `ageDays`、
`fetchedAt`、`error`、`hint`。**`ok:false` 时永远先报 `error`，不要用上一次的缓存值当本次结果。**

### 2.3 403 必须区分两种（口径完全相反）

| 现象 | 说明什么 | 怎么对客户说 |
|---|---|---|
| 403 返回 **HTML**（Cloudflare 挑战页，常见 `Just a moment`） | **出口 IP 问题**（与 Key、请求量无关） | "换回原节点/稍等重试即可；Seller API 不受影响，订单财务照常"（换节点会偶发 403，属正常） |
| 403 返回 **JSON**（如 `Security not found`） | **Seller Key 问题**（不是出口） | "Key 无效或已换发，请重新签发并录入"（在「多店铺设置」里粘新 Key） |

代码侧证据：`crawler.py` 把 403 归一成 `HTTP 403 Forbidden (Cloudflare blocked this egress)`；
Seller API 的报错形如 `Takealot API 403: <原始 JSON 前 200 字符>`（Key 已打码）。
`GET /diagnostics` 的 `proxy` 与 `public` 两项就是按这个口径分流的。

### 2.4 出口代理怎么配（客户最常卡在这）

- 填**本机端口**形式（客户自己的 VPN/代理的本地混合端口，如 `http://127.0.0.1:7890`），
  不是远端地址；二选一：
  - 环境变量 `TAKEALOT_API_PROXY`（后端由 App 拉起，改完**重启后端**生效）；
  - 或写进 `state\stores.json` 的 `crawler.proxy`。
- Seller API **也**走这个出口（同一个 Cloudflare 面），所以代理配错时"爬虫看着正常、订单却读不到"
  是同一根因，别当成两个 bug。
- 换节点会出现**偶发 403**，属正常现象，不是配置坏。

---

## 3. 九个模块 ↔ 后端端点

插件 id `takealot-erp`，两半同 id：

- **界面半边**：`%LOCALAPPDATA%\hermes\desktop-plugins\takealot-erp\plugin.js` → 侧边栏「Takealot 运营」。
- **后端半边**：`%LOCALAPPDATA%\hermes\plugins\takealot-erp\dashboard\`（`plugin_api.py` + `crawler.py`），
  挂在 `/api/plugins/takealot-erp/`，**70 个路由**（`@router.` 计数，含 `GET`/`POST`/`PATCH`/`DELETE`）。

| 模块 | 端点 |
|---|---|
| 经营总览 | `GET /overview`（KPI、14 天走势、风险提示、费用构成） |
| 订单与净利 | `GET /orders?status=&q=`、`GET /orders/{order_id}`（逐单费用阶梯）、`GET /orders/live` |
| 财务与对账 | `GET /financial?q=`（月度、结算单、履约费差异）、`GET /financial/live`、`POST /financial/reconcile/export` |
| 采集箱 | `GET /collection`、`POST /collection/add`、`POST /collection/update`、`DELETE /collection/{item_id}`、`POST /collection/promote`、`POST /collection/assign`、`POST /collection/publish-all`、`POST /collection/reanalyze`、`POST /collection/refresh` |
| 上架编排 | `GET /listings/drafts`、`POST /listings/draft`、`POST /listings/drafts/delete`、`DELETE /listings/drafts/{draft_id}`、`GET /listings/prefill`、`POST /listings/validate`、`POST /listings/duplicates`、`POST /listings/loadsheet`、`POST /ai/listing-copy`、`POST /ai/listing-copy-from-spec`、`GET /meta/categories`、`GET /meta/variant-themes`、`GET /meta/attributes`、`POST /meta/attributes/ingest`、`POST /meta/categories/translate` |
| BuyBox 跟价 | `GET /buybox`、`GET /buybox/strategy`、`POST /buybox/strategy`、`POST /buybox/run`、`GET /buybox/log`、`POST /buybox/rules`、`POST /buybox/apply` |
| 竞品监控 | `GET /competitor`、`POST /competitor/track`、`DELETE /competitor/{tsin}`、`POST /ai/listing-analysis`、`GET /ai/listing-analysis`（只读缓存态） |
| 合规检测 | `GET /compliance/rules`、`POST /compliance/check` |
| 多店铺设置 | `GET /settings`、`POST /settings/store`、`DELETE /settings/store/{store_id}`、`POST /settings/test`、`POST /settings/active` |

补充页签（与上面 9 个共用同一后端，Agent 问到时别答"没这个模块"）：
`GET /products`、`GET /products/stats`、`GET /products/{sku}`、`PATCH /products/{sku}`、
`POST /products/batch-write`、`POST /products/{sku}/offer`、`POST /products/content-run`、
`POST /products/enrich`、`POST /analytics/draft`、`GET /fulfilment`、`GET /state`、
`GET /health`、`GET /diagnostics`、`GET /crawler/status`、`GET /crawler/pull`、`POST /crawler/pull`、
`POST /crawler/batch`、`POST /crawler/ingest`、`GET /crawler/cache`、`GET /meta/fees`、`GET /meta/catalog`。

### 3.1 今天新增/重点接口（字段名以 `plugin_api.py` 为准）

**① `GET /meta/attributes` —— 必填属性按叶子类目给**
参数：`category`（类目名/路径，可空）、`loadsheet`（装载表 id，可空）、`taxonomyId`（叶子类目 id）。
- **必须传 `taxonomyId` 才能列必填**：只给装载表会返回 `needsTaxonomy:true` + 中文 `note`，
  因为官方把 `requirements` 挂在**叶子类目**上（`loadsheets[id].categories[taxonomyId].requirements`）。
- 只给类目名/路径时，后端会用官方 nodes 自动反查 `taxonomyId`，并在 `taxonomyResolvedFrom`
  标明来源（`path:…`）——这是**真实映射不是猜**。
- 返回关键字段：`covered`、`required[]`、`recommended[]`（官方 `recommendeds`，单列并带 `recommended:true`）、
  `optional[]`、`fields[]`（= required+recommended+optional，向后兼容旧 UI）、`imageRequired[]`、
  **`minimumImages`**、**`requiresColour`**、`titleTemplateId`、`taxonomyPath`、
  `counts{required,recommended,optional,undefinedRequired}`、`source`（`bundled` = 内置 7 张表 /
  `ingested` = 扩展抓来的）、`basis`（说明必填来自官方 requirements 而非装载表级 `isRequired`）。
- **未收录显式说明、绝不兜底**：`covered:false` + `note`；类目不在该表清单里也返回 `covered:false`
  并提示可能选错类目。`undefinedRequired > 0` 时 `note` 要求界面如实标注，不给假控件。

**② `GET /meta/variant-themes` —— 变体主题下拉**
参数：`loadsheetId`、`taxonomyId`（任一即可，`taxonomyId` 会自动反查装载表）。
返回 `themes[]`：每项 `key/label/axes[]/needsCustomName/axisCount`，每个轴带官方列名、候选值、
是否必填、`resolved`（是否解析到官方数据）。装载表不在内置 7 张表里时**明确 warning + 轴字段给空**，不猜。

**③ `POST /ai/listing-copy-from-spec` —— 大输入框（粘规格）生成文案**
入参：用户粘贴的参数描述。返回 `title / subtitle / description / whatsInTheBox / bullets[] /
filled[] / missing[] / specEcho{dimensions,power,capacity,colour,material,numericFacts[]} /
guardDropped[] / basis[] / llm`。
铁律：**只用 spec 里真实出现过的规格**；抽不到的字段返回空值并列入 `missing`；
违规/夸大表述被拦下的列入 `guardDropped`。**不许拿"常见规格"补齐。**

**④ `GET /meta/categories?...&zh=1` —— 类目检索 + 中文装饰 + 缓存行为**
参数：`q`、`limit`（1–500，默认 20）、`department`、`loadsheet`、`zh`（0/1）。
- `q` **只匹配 Takealot 类目名**：商品词（`earbuds`）查不到是**正常的**，返回**空**而不是无关结果
  （`total` 为命中数，`items` 为截断后的页）。
- `zh=1` 时额外返回顶层 `zh` 块：`{cached, missing, translating, reason, provider, batchMax}`，
  行内加 `nameZh` / `pathZh` / `zhMissing[]`。
  行为：**命中缓存直接贴中文；没命中就回 `null` + 摘要，丢后台线程补翻，本次请求不被翻译阻塞**；
  没配 LLM Key 时**明确不翻也不编**（`reason` 说明），路径里没翻到的段**保持英文原样**。
- 翻译结果落本地缓存，二次请求即命中（`reason` 会变成"全部命中缓存，未触发翻译"）。

**⑤ `POST /meta/attributes/ingest` —— 扩展抓到的官方模板入库**
入参 `{source?, loadsheets:{ "<loadsheetId>": {fields:{...}, categories:{...}} }}`（或直接就是 loadsheets 映射）。
- 校验：节点必须有 `fields` 字典，否则点名拒绝；没有任何可用节点 → `ok:false` + `accepted:0`。
- 行为：读现有 → 合并（以装载表 id 为键）→ **原子写** `state/attributes_templates.json` →
  **立刻打掉 `taxonomyId→装载表` 反查索引**（`_ATTR_INDEX["sig"]=None`），
  并返回 `accepted`、`totalLoadsheets`、`added[]`、`loadsheetIds[]`、`stateFile`。
- 因此**扩展抓完模板后，ERP 读盘即生效，无需重启后端**：`source` 会从 `bundled` 变成 `ingested`，
  覆盖范围从内置 **7/36 张装载表**补齐。
- 原始响应留档走桥的 `/takealot/api/attributes/raw` → `state/attributes_templates_raw.json`
  （**只存响应体**，出现 `authorization/headers/cookie/jwt/token` 之类键直接拒收；上限 2MB，
  超出截断并标 `truncated:true`）。

### 3.2 界面读的契约字段名（改后端别改这些）

`orderRow` / `bbRow` / `logRow` / `colItem` / `draft` / `statementRow` / `compRow` / `storeRow`。
改完删掉包的 `state\` 让样例重新播种。

---

## 4. 费用与利润的权威算法（照这个算，别用记忆里的数字）

权威来源是 **`dashboard/data/takealot_fees_official.json`**（由官方两份 PDF 生成：
`2025_Success_Fee_Pricing.pdf`、`Takealot_Pricing_Schedule.pdf`；生成脚本
`source/scripts/build_fee_data.py`）。**不要手改 JSON，也不要凭记忆报费率。**

**成功费（Success Fee）**：官方口径 = 售价（**含 VAT**）× 类目费率，
费率表按「主类目 → 子类目」共 68 个主类目 / 418 条规则（例：Headphones & Headsets 12%、
Cosmetics 14%、Graphics Card 7%、Tablets & E-readers 7.5%、Automotive Parts & Accessories 10%）。
平台实扣 = 费率 × 售价 × **1.15**（官方价目表金额不含 VAT，平台按含 VAT 入账）。
界面上的「我方核算」与平台实扣一致到分；类目未匹配官方子类目时**不给数字**（`rate: null`），
绝不拿默认费率冒充。归类依据会回显在 `rateSource`（`subcategory-name` / `synonym:xxx` /
`main-category-modal` / `legacy-alias` / `unmatched`）。

**履约费（DC）**：官方按「包装体积 cm³ 档 × 重量档 × 类目分组」定价（不含 VAT）：
Standard ≤35 000 cm³ 分四组 R22 / R33 / R45 / R60；Large ≤130 000 → R60；Oversize ≤200 000 → R107；
Bulky ≤545 000 → R107；Extra Bulky → R270（重量档 Light/Heavy/Heavy Plus/Very Heavy 取值不同）。
实扣 = 官方金额 × 1.15。**官方没有仓库附加系数**，所以不再乘任何仓库系数。
类目分组未匹配时按官方「All other categories」档；完全缺尺寸/重量时不给数字。

**仓储费**：官方按包装体积 cm³ 定档（R4/12/25/45/150/250/450），**35 天以内动销 R0**（超龄才收）。

**净利 / 保本 / 目标价**：
`净利 = 售价 −（成功费 + 履约费[+ 跨仓费]）−（商品成本 + 汇损 + 头程物流 + 入仓运费）`；
`净利率 = 净利 / 售价`；`保本价 =（固定资产成本）/(1 − 费率×1.15)`；
`20% 目标价 = 固定资产成本 /(1 − 费率×1.15 − 0.20)`。
**VAT 不作为独立扣项**：平台把买家支付的含税全额记给卖家（真店流水
`payment-customer-order` = 标价全额，`vat_multiplier` 0.00），VAT 只嵌在平台收费里。
汇损系数默认 0.20（客户可在 `state/profit_config.json` 覆盖）；RMB 成本必须配汇率，
没填汇率就不给到手金额（不猜）。

### 4.1 直接调用引擎（**兜底**：只有工具没覆盖时才用）

> **第一入口永远是 12 个原生工具**（见「工具面与中文意图路由」一节）：工具已压好摘要、带实测行键与口径说明。
> 只有当某个端点工具没覆盖、或你要拿完整原始字段时，才用下面的直调。

后端不启 HTTP 也能当纯计算引擎用——这是本机最省事的权威算法入口，已实测：

```powershell
$py = 'C:\Users\Fly\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe'
& $py -c "import sys; sys.path.insert(0, r'C:\Users\Fly\AppData\Local\hermes\plugins\takealot-erp\dashboard'); import plugin_api as e; import json; print(json.dumps(e.calculate_order_profit({'sellingPrice':399,'category':'Audio & Headphones','cogsCost':110,'inboundFreight':25,'weightKg':0.18,'lengthCm':12,'widthCm':8,'heightCm':4,'warehouse':'JHB'}), ensure_ascii=False))"
```

复杂输入请把脚本写到临时 `.py` 文件再执行（`-c` 里的中文/引号经 ssh 容易被吞）。
可调用函数：`calculate_success_fee(售价, 类目)`、`calculate_dc_fulfillment_fee({weightKg,...})`、
`calculate_order_profit({...})`、`compliance_check(文本, 类目?)`、`reconcile_statement(csv文本)`。

**实测基准**（售价 R399、成本 R110、头程 R25、0.18kg、JHB、类目 "Audio & Headphones"）：
成功率 12%（官方子类目 Headphones & Headsets，命中词 `headphone`）→ 成功费 R55.06（= 399×12%×1.15，含 VAT）；
履约费 R69.00（官方 Standard / 数码家电组 R60 × 1.15）；平台费合计 R124.06；
净利 R139.94、净利率 35.1%、保本价 R236.66、20% 目标价 R308.16。
（口径：官方价目表金额不含 VAT，平台按含 VAT 入账，所以每个费用都 ×1.15；VAT 不作为独立扣项。）

**注意字段名差异**：引擎原始返回用 `dcFulfillmentFee` / `totalSupplyCost` / `profitMarginPercent`，
而界面契约（`GET /orders` 的行）用 `dcFee` / `supplyCost` / `marginPercent`，两套别混用。

---

## 5. 硬规则与陷阱

### 5.1 硬规则（越界即错）

1. **拿不到就说拿不到。** 后端零模拟数据；`ok:false` / `mode:"blocked"` / `empty:true` 时如实转述
   `error` 与 `hint`，**不许编造订单、价格、评分、评论数、销量、竞品价**。
2. **写操作只走界面。** 改价 / 改库存 / 上架 / 下架 / 改标题图片，对话里一律拒绝并引到界面
   （商品管理、上架编排、BuyBox 跟价、采集箱）。对话只能读。
3. **跟卖只能改价格与库存。** 采集箱/跟卖池的行是平台上**已存在**的商品，标题/图片/描述/品牌/类目
   **只读**（平台 `CreateOfferRequest` 是 `additionalProperties:false`，只接受条码/SKU + 售价 + 库存）。
   要改内容只能「转入新建草稿」，走装载表由人工上传。凡是"改跟卖行标题"的请求，直接说做不到。
4. **必填是按叶子类目给的。** 必须 `taxonomyId`；**不能用装载表级 `isRequired`**（我们数据里全为 false，
   不可用）。前端拿不到 `taxonomyId` 就先让用户在「上架编排」里选叶子类目。
5. **未收录类目不许拿别的类目属性顶替。** `covered:false` 就报未收录，并给出补齐路径
   （在卖家后台页面点扩展的「同步官方类目属性模板」→ 抓一次即补齐，ERP 读盘即生效）。
6. **出口代理要填本机端口**（如 `127.0.0.1:7890`），不是远端地址；`TAKEALOT_API_PROXY` 或
   `state\stores.json` 的 `crawler.proxy` 二选一，改完重启后端。**换节点出现偶发 403 属正常。**
7. **Seller API Key 只存后端**（`state\stores.json`，`dpapi:` 密文，接口一律回打码值）。
   永远不把 Key 写进聊天/文件/命令，也不替用户索要明文；加 Key 是用户在「多店铺设置」里的动作。
   不要提前要 Key——一签发旧 Key 立即失效，顺序必须是「先装好 → 再让客户签发 → 录入」。
8. **不承诺"训练/微调"，也不承诺 100% 命中意图。** 能力来自基础模型 + 本 skill + 工具；
   命中率靠动词表 + 硬路由 + 审计留痕，并用 20 句验收原话实测给客户看。
9. **不发明模块与字段**：模块/端点只认本文件第 3 节列出的那些（写进 SKILL 的每个端点都做过存在性断言）。

### 5.2 陷阱（踩过的坑）

- **订单状态两套写法**：界面过滤芯片发 `awaiting_shipment`（snake_case），行里存 `Awaiting Shipment`。
  后端已做双向归一；自己写查询时要归一，否则过滤恒为空。
- **`GET /meta/categories?q=` 只匹配 Takealot 类目名**：商品词（`earbuds`）查不到是正常的，
  返回空而不是无关结果。
- **PowerShell 5.1 的 `Invoke-WebRequest` 按 Latin-1 解 `application/json`**，中文会变乱码（假 bug）；
  取原始 JSON 用 `curl.exe -o`。终端里中文乱码同理是控制台代码页，不是数据坏。
- **后端 Python 只在 `hermes serve` 启动时导入**，且 `config.yaml` 的 `plugins.enabled` 必须含
  `takealot-erp`；改了 Python 要重启后端（kill 掉 serve 进程即可，App 约 3 秒自动重生）。
  **例外**：抓来的属性模板（`state/attributes_templates.json`）读盘即生效，不需要重启。
- **`/crawler/status` 的 `probe=1` 才真发请求**；不带参数只看最近一次结果与缓存，别把
  "上次是 proxy" 当成"现在通"。
- **`/crawler/cache` 与 `transport:"cache"` 是缓存态**：评论速度缓存 TTL 5 天、AI 分析 24 小时。
  报数据时要说清是缓存（`ageDays`/`fetchedAt`），不能当刚抓的。
- **Cloudflare 403 与 Key 403 别混**（见 2.3）：一个说出口，一个说 Key。
- **交付前清掉包里的 `__pycache__` 与 `state\`**（测试残留会让客户第一次打开看到脏数据）。
- **Windows 上截图/看 DOM 都不行**：打包版 Electron 没有 CDP 端口，ssh 里 `CopyFromScreen` 失败。
  验证界面用渲染 harness（见 `openclaw-erp` skill 的 `scripts/ui-render-harness/`），
  验证后端用 `scripts/verify-plugin-backend.ps1`（HTTP 端点全量扫描）。
- **行键不是 `rows`（写错就"能调但返回空"）**：`financial` → `ledgerRows[]`；`fulfilment` →
  `stages.inbound` / `stages.outbound.pos`；`orders_live` → `items[]`；`products` → `items[]` + `total`/`mapped`/`hasMore`；
  `overview` **没有 `rows`**（用 `alerts`/`recentOrders`/`buybox`）。
- **订单必须走 `orders_live`**：`orders("store-2")` 会把店号当 `status` 传进去 → **返回 0 行**（不是没订单）。
- **`listings` 按店过滤为空**会自动再读全量并标注归属；要拿全量就传 `storeId=''`。
- **`blocked` ≠ 商品不存在**：`transport=blocked` 说的是抓取通道被挡（出口/权限），不是 PLID 无效，别下"这个商品没有"的结论。
- **写操作没有任何工具**：改价/改库存/发 Offer/上架下架一律**引到界面**（BuyBox 跟价 / 商品管理 / 上架编排），
  不要尝试绕道调用，也不要给"已改好"的回执。
- **CDP 抓取提示未授权**：`debugger` 是**可选权限**，点一次「启用 CDP 抓取」授权即可；
  今天来不及点就明确说"当前用 DOM/公开接口抓取，CDP 作为增强项下一步启用"，**不要假装 CDP 已经在跑**。

---

## 5.5 工具面与中文意图路由（原生工具，第一入口）

**13 个工具**（toolset = `takealot_erp`，装好即出现在对话里）：

| 类别 | 工具 |
|---|---|
| 只读（8） | `takealot_erp_overview` / `_orders` / `_products` / `_finance` / `_fulfilment` / `_collection` / `_listings` / `_selfcheck` |
| 抓取与本地写（5） | `takealot_crawl_product` / `takealot_market_search` / `takealot_collection_add` / `takealot_collection_update` / `takealot_route_verdict` |

> `takealot_collection_update` 只改**本地核算参数**（成本/币种/汇率/汇损/头程/重量/长宽高）——
> 这些是费率条件的输入（履约费按体积 cm³ 档 × 重量档 × 类目分组定价），平台看不到，也不产生平台写请求。
> 价格/库存/listing 内容仍不在对话里改。

**意图路由是确定性的（词表命中，不是模型猜）**：

- `pre_llm_call` 用**有序中文词表**命中意图 → 注入"本轮必须调用 X 工具"的硬指令；命中不了**不注入**（返回 `None`）。
- `pre_tool_call` 把**实际调用的工具**接进同一份审计，用来核对"路由期望"与"实际动作"是否一致。
- **词表与代码同源**：`plugins\takealot-erp\tools\routing-words.md`（改词表只改这一处 + `tools.py`）。
- **审计（客户可自证）**：`state\agent_intent_audit.jsonl`，每轮写 `route`（原话/命中规则/意图/期望工具/是否注入）
  与 `tool_call`（实际工具）两类记录。客户可以直接打开看"它为什么这么理解"。

**改完词表必须重跑两样**：① 词表断言 `RESULT 42/42`；② 20 句自然语言验收（含同义词与反例）。
**必中清单**（用户原话里出现过的说法都要命中）：抓取 / **爬取** / 爬一份 / **扒** / 撸一下 / 取数 / 抓数据 /
找同款 / 搜同款 / 看看这个链接 / 这货多少钱 —— 后接链接、`PLID…`、`TSIN…` 或条码。

---

## 5.6 模型通道：跟随 Hermes 配置的 provider（客户可能用阿里千问）

> **⛔ 硬规矩：模型配置归用户所有，agent 一律不许改。**
> `config.yaml` 的 `model:` / `providers:` 段、`.env` 里的 key、`base_url`、默认模型 —— 全部是用户手工配的，
> **任何情况下都不许动**（包含更新、排障、"帮你配好"这类善意动机）：
> - **不许**执行 `hermes config set model.*` / `hermes model` 去改选、改 provider、改 base_url、换 key；
> - **不许**运行 `setup_llm_provider.py`（那是**首次装机**、且**用户明确要求**时才用，装完不再碰）；
> - 更新操作与模型配置**完全无关**：更新只换插件文件，模型报错就**把现象原文报给用户**，由用户自己改；
> - 用户要改模型时**用户自己改**；只有用户明确说「帮我配模型」才动，且动之前先备份 `config.yaml`。
>
> 本节下面的表**只用于读懂与排障（读，不写）**，不是让你照着执行的动作清单。

ERP 的 AI 功能（**AI 文案 / 类目中译 / 价值分析**）**不锁定厂商**：读
`<HERMES_HOME>/config.yaml` 的 `model:` 段（`provider` / `base_url` / `default`），
再按 provider 找对应的 key 环境变量；解析不到才回落到旧的 Agnes/DeepSeek 环境变量。
**所以客户换模型只改 Hermes 配置，ERP 不用动。**

| provider | key 环境变量（写在 `<HERMES_HOME>\.env`） | base_url |
|---|---|---|
| `alibaba`（阿里云百炼·国际站） | `DASHSCOPE_API_KEY` | `https://dashscope-intl.aliyuncs.com/compatible-mode/v1` |
| `alibaba-cn`（国内站） | `DASHSCOPE_API_KEY` | `https://dashscope.aliyuncs.com/compatible-mode/v1` |
| `alibaba-coding-plan` | `ALIBABA_CODING_PLAN_API_KEY` | `https://coding-intl.dashscope.aliyuncs.com/v1` |
| `alibaba-coding-plan-cn` | `ALIBABA_CODING_PLAN_CN_API_KEY` → `ALIBABA_CODING_PLAN_API_KEY` → `DASHSCOPE_API_KEY` | `https://coding.dashscope.aliyuncs.com/v1` |
| `alibaba-token-plan`（Token 套餐·国际） | `ALIBABA_TOKEN_PLAN_API_KEY` | `https://token-plan.ap-southeast-1.maas.aliyuncs.com/compatible-mode/v1` |
| `alibaba-token-plan-cn`（**Token 套餐·中国，本客户用的**） | `ALIBABA_TOKEN_PLAN_CN_API_KEY` → `ALIBABA_TOKEN_PLAN_API_KEY` | `https://token-plan.cn-beijing.maas.aliyuncs.com/compatible-mode/v1` |
| `deepseek` | `DEEPSEEK_API_KEY` | `https://api.deepseek.com/v1` |
| `custom:<名字>` | 由 `providers.<名字>.key_env` 指定 | `providers.<名字>.api` |

客户机设置（PowerShell，Key 由客户自己填）：

```powershell
echo DASHSCOPE_API_KEY=sk-xxxx >> "%LOCALAPPDATA%\hermes\.env"
hermes config set model.provider alibaba
hermes model                     # 列出这把 key 真能调的模型，选一个
hermes config set model.default qwen3.8-max
hermes doctor                    # 验证连通
```

**Token Plan 放行的模型**（`hermes model` 会列出来）：`qwen3.8-max-preview` / `qwen3.7-max` /
`qwen3.7-plus` / `qwen3.6-plus` / `qwen3.6-flash` / `deepseek-v4-pro` / `kimi-k2.7-code` / `glm-5.2` …
（Token Plan 的 key 形如 `sk-sp-…`；Coding Plan 与普通百炼 key 是**不同端点**，贴错会报"无可用通道"，别当成网络问题。）

**怎么验证 ERP 跟上了**：AI 文案返回里的 `llm` / `llmProvider` / `llmModel` 应显示
`alibaba` + 千问模型名；显示 `template` / `none` 就是没解析到 key（先查 `.env` 键名与
`config.yaml` 的 `model.provider` 是否对得上）。改完 Python 要重启后端。

---

## 6. 落地位置：三半必须一致（界面 + 后端 + agent 工具面）

**agent 工具面（新）**：`plugins\takealot-erp\tools.py` + `tools\routing-words.md`，
与 `__init__.py` 的 `register(ctx)` 一起生效（`register` 里注册 13 个工具与两个钩子）；
装完**必须重启 App**（工具在进程启动时注册），重启后 `hermes tools list` 应显示 `✓ enabled  takealot_erp`。

**生效位置**（Hermes 真正加载的只有这一份）：

```
%LOCALAPPDATA%\hermes\skills\takealot-erp-operator\SKILL.md
即 C:\Users\<用户>\AppData\Local\hermes\skills\takealot-erp-operator\SKILL.md
```

**副本位置**（插件包内，方便随包分发）：

```
<插件包>\skills\takealot-erp-operator\SKILL.md
```

**`plugin.yaml` 包里的 `skills/` 目录不会被 Hermes 自动加载**，所以副本只用于随包交付，
安装脚本必须把它复制到上面的生效位置。两份不一致时以生效位置为准，但**交付时必须一致**。

一致性检查（安装后跑一次，两条 md5 应完全相同）：

```powershell
Get-FileHash "$env:LOCALAPPDATA\hermes\skills\takealot-erp-operator\SKILL.md" -Algorithm MD5
Get-FileHash "<插件包>\skills\takealot-erp-operator\SKILL.md" -Algorithm MD5
```

改动流程：先改包内副本 → 复制到生效位置 → 重启（或新开会话）让 Agent 重新加载 skill。
**不要动 `~/.hermes/skills/software-development/openclaw-erp/`，那是另一套运维 skill，与本技能无关。**

---

## 7. 验证

1. **后端在跑**：`%LOCALAPPDATA%\hermes\logs\gui.log` 里有
   `Mounted plugin API routes: /api/plugins/takealot-erp/`。
2. **环境自检**：`takealot_erp_selfcheck`（`GET /diagnostics`）逐项看 ——
   `backend` / `openpyxl` / `state_dir` / `proxy` / `seller` / `public` / `key_at_rest`；
   `public` 一项里会打印实测 `transport`（`proxy`/`direct`/`blocked`）。这就是"哪里不通"的一次性答案。
3. **引擎可用**：`calculate_order_profit` 一行命令能打印出净利（R139.94）即为正常；
   想核对费率口径本身，跑**随包发的** `<Hermes home>\plugins\takealot-erp\delivery\verify\verify_fee_engine.py`
   （用店铺自己的 /sales 已计费行逐笔对账，差异 0 项才算通过）。
   交付方仓库里同一份在 `source/scripts/verify_fee_engine.py`。
   **给客户/发布说明只许印客户机上真实存在的路径** —— 印仓库路径会让客户机上的 agent
   找不到文件（真机踩过：发布说明让跑 `%USERPROFILE%\verify_fee_engine.py`，客户机上没有）。
3b. **口径核对**：`source/scripts/validate_against_portal_export.py <Orders_Detailed_*.csv>`
   用商家后台「Orders Detailed」导出逐笔校验 —— 它同时验三件事：Seller Earnings 的算术恒等、
   成功费、履约费的类目分组。**成功费没有最低费下限**（导出里 R39 的订单实收 5.38）。
3c. **一键上架可用**：`source/scripts/verify_publish_all.py`（dryRun 版，会临时改/还原
   `state/collection.json`）：必须看到「已上架 → 跳过」与「缺售价 → 跳过」，且 `writesSent=0`。
3d. **费率条件的输入齐不齐**：`source/scripts/verify_condition_inputs.py`（dryRun 版，会临时改/还原
   `state/collection.json`）：验证「公开页属性 → 条码/包装尺寸」、采集箱能写核算参数、
   缺汇率/尺寸时**不给到手数字只提示补什么**、补齐后到手出数。
   口径记住三条：
   - 履约费按「体积 cm³ 档 × 重量档 × 类目分组」定价 → 缺尺寸/重量就没数字（公开页只有少数商品写了
     `Assembled Dimensions`，实测 20 条缓存里 3 条有；条码则有 14 条）。
   - 采集箱可改 = 平台侧（价格/库存）+ **本地核算输入**（成本/币种/汇率/汇损/头程/重量/尺寸）；
     listing 内容（标题/图片/描述/类目/条码）仍然拒绝，要改就走「转入新建草稿」。
   - 结汇率口径：`exchangeRateZarPerRmb` = **1 ZAR 值多少 RMB**（实见 0.25），成本换算用
     `成本_ZAR = 成本_RMB ÷ 该值`。绝不预置、绝不猜；没填就只提示去填。
3e. **核算参数工具与列表健壮性**（改过 `tools.py` 的 `collection_params` 或采集箱 stats 就必跑）：
   - `source/scripts/verify_collection_update_tool.py` —— 工具边界：只写本地账本、拒平台字段
     （价格/库存/标题/条码）、缺目标行先问、`TOOLS` 里确实注册了它。
   - `source/scripts/verify_collection_stats_none.py` —— **回归**：缺尺寸/汇率的行算不出毛利率时，
     采集箱列表**不许 500**，且要报 `stats.marginRows`。改回旧写法会复现同一条 `TypeError`。
   - `source/scripts/verify_collection_accounting_inputs.py` —— 尺寸解析、核算参数写入、
     拒绝 listing 字段、补齐后费率条件算得出。
   - `source/scripts/verify_platform_partial_apply.py` —— 平台只接受部分字段（如创建成功但库存没落上）
     必须报 `partial` + 请求值/回读值，不许当成全绿。
   - `source/scripts/verify_update_routing.py` —— **回归**：ERP 自更新/回滚的句子（尤其带通道地址
     GitHub / gh-proxy / jsDelivr）不许被判成商品抓取；真商品链接必须照旧抓取。
   - 客户机上另有真机版 `verify_collection_update_tool_live.py`（打真后端，不写平台）。
   - **误命中报表**（客户机随包发）：`<Hermes home>\plugins\takealot-erp\delivery\verify\route_misfire_report.py`
     读 `state\route_misfire.jsonl`，列出被逃生条款忽略的误命中与命中文 → 据此收紧词表/加守卫。
     词表是**随使用演化**的，别指望一次写全。
4. **界面可用**：App 里侧边栏「Takealot 运营」各模块都有内容（不是空白/加载失败）。
5. **端点真实性**：本文件提到的每个插件端点，都用脚本对 `plugin_api.py` 的 `@router.` 表做过存在性断言
   （脚本：`verify_skill_endpoints.py`，输出 `PASS n/n`）。
6. **自然语言演示**：用《自然语言触发对照表.md》里的 6 句必演话术走一遍
   （抓取带链接 → 抓取工具；"帮我找一下我今天的订单" → 订单只读，**不许被当成抓取**；
   "帮我把价格改成 199" → 拒绝并引到界面；"采集箱里有重复吗" → 采集箱只读）。
