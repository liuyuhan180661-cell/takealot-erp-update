# ERP 更新操作规范（UPDATE-SPEC）

> **这份是规范正文，唯一真源。** 客户机上两处挂载同一份：
> `%LOCALAPPDATA%\hermes\plugins\takealot-erp\delivery\UPDATE-SPEC.md`（插件目录内，随版本更新）
> 和 `%LOCALAPPDATA%\hermes\skills\erp-self-update\UPDATE-SPEC.md`（技能目录旁）。
> `SKILL.md` 是执行清单，本文件是完整规范（含报告模板与日志格式）。

---

## 0. 三条铁律（任何时候都不许破）

1. **只报实际输出。** 不许说"应该没问题 / 大概可以了"。有 FAIL 就贴 FAIL 原文。
2. **不替用户做决定。** 先 dry-run，把「版本从哪到哪、包多大、改了什么、会动哪些文件」念清楚，**等用户确认**再 `--apply`。
3. **绝不碰 `state\`。** 那是客户数据（Seller Key 密文、店铺、采集箱、缓存、误命中记录、更新记录）。更新器已用白名单限制，**不要绕过它手工覆盖文件**。

另外三条失败处理：整包指纹或逐文件 md5 不符 → **中止**（不要重试到成功、不要拿别处的包顶替）；
用户不满意或装坏了 → `--rollback`（文件与版本记录一起回退，`state\` 不参与）；
相同版本想重装 → `--force`（仍做全部校验），**不要为此改版本号**。

---

## 1. 什么时候触发

用户说：`检查更新` · `有没有新版本` · `更新 ERP` · `升级一下` · `回滚` · `退回上一版` · `更新失败怎么办`。

> 注意：**更新 ERP 不是抓取商品**。这类句子里常带通道地址（GitHub / gh-proxy / jsDelivr），
> 新版词表已加守卫不会误注入抓取工具；若仍被注入（老版本插件），按工具指令里的**逃生条款**处理：
> 忽略注入、按用户原意做，并把这一行记进 `state\route_misfire.jsonl`。

---

## 2. 标准流程（七步，别跳）

| # | 做什么 | 判据 |
| --- | --- | --- |
| 1 | 找更新器（插件 `delivery\selfupdate.py` → 技能目录旁 → 交付包内；都没有就从公开通道下载它） | 文件存在 |
| 2 | **先看这台机器有几个 profile**（见 §3） | 列出来给用户 |
| 3 | `--status`：报当前版本 | 打印 `state\installed.json` 里的版本 |
| 4 | **dry-run**（不带 `--apply`）：念版本变化 / 包大小 / 变更说明 / 会改哪些文件 | 不改任何文件 |
| 5 | 等用户确认 | 用户明确说装 |
| 6 | `--apply`：下载 → 整包 sha256+md5 → 包内逐文件 md5 → **自动备份** → 白名单落盘 → 写版本记录 + 审计 | 校验全过 |
| 7 | **验证（这一步才是"完成"）**：重启 Hermes → 自检 → 跑自证脚本 → 按 §4 报告 | 见下 |

第 7 步的细节：
- **后端半边**（`plugin_api.py` / `tools.py`）是被**运行中的进程加载**的：文件覆盖成功 ≠ 生效。
  必须让用户**完全退出并重开 Hermes**，否则行为还是旧的（客户会直接说"更新了没用"）。
- **界面半边**（`plugin.js`）由桌面 App 热加载，不用重启。
- 自检：在对话里说「自检」，或跑交付包里的 `selfcheck.ps1` → 期望 **`RESULT 9/9 PASS`**。
- 自证脚本（随包发，不用开界面）：
  ```powershell
  $py = "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts\python.exe"
  $v  = "$env:LOCALAPPDATA\hermes\plugins\takealot-erp\delivery\verify"
  & $py "$v\verify_fee_engine.py"      # 用店铺自己的 /sales 逐笔核对费率 → 期望「差异 0 项」
  & $py "$v\route_misfire_report.py"   # 误命中报表（判断有没有被误判过）
  ```

---

## 3. 多 profile：**这是最容易漏的一步**

Hermes 的**一个 profile = 一个独立的 Hermes home**（边界是 `HERMES_HOME`）：默认 profile 的根是
`%LOCALAPPDATA%\hermes`，其它在 `%LOCALAPPDATA%\hermes\profiles\<名字>`。插件、`skills\`、
`config.yaml`、`.env`、`state\` **各 profile 各一套**。

- 动手前先列：`Get-ChildItem "$env:LOCALAPPDATA\hermes\profiles" -Directory`
- **更新只作用于"跑更新器的那个 profile"**。其它 profile 要在它自己的 `HERMES_HOME` 下再跑一遍：
  ```powershell
  $env:HERMES_HOME="$env:LOCALAPPDATA\hermes\profiles\<名字>"
  Get-ChildItem "$env:HERMES_HOME\plugins\takealot-erp" -Name     # 先确认那个 profile 里有没有插件
  & "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts\python.exe" `
    "$env:HERMES_HOME\plugins\takealot-erp\delivery\selfupdate.py" --repo <owner/repo> --apply
  Remove-Item Env:\HERMES_HOME
  ```
- 那个 profile 里**没有** `plugins\takealot-erp` → 它本来就没装，**别硬更**，告诉用户"这个 profile 需要先安装"，等他定。
- **报告必须写清：哪个 profile 更新了、哪个还是旧版**（否则用户以为全机都更新了）。有其它 profile 时要问用户"要不要一起更新"，但**别自己决定**。

---

## 4. 报告格式（每次更新都要写全，缺一项不算完成）

```
【更新】<插件名>：<旧版本> → <新版本>
【范围】已更新 profile：default（<旧版本> → <新版本>）
        未更新 profile：buzz（还是 <版本>，需不需要一起？请回一句）
【改了什么】① … ② … ③ …（按发布说明，用客户能懂的话）
【需要你做的】① 完全退出并重开 Hermes（后端与工具面在启动时注册）
              ② 扩展：<无变化 / 需要在 chrome://extensions 点一次「重新加载」>
              ③ 其它（换代理、录 Key 等，没有就写"无"）
【验证】selfcheck：<RESULT n/n PASS/FAIL 原文>
        费率对账：<差异 N 项>；误命中报表：<N 条 / 无>
【回滚】不满意可以退回：<... --rollback>（你的数据不会被碰）
```

**扩展那一项的写法**：不要在扩展没变时让用户去重载。判据是**真比对**：更新包里的
`payload/extension/<扩展名>/` 与客户机上 `<Root>\<扩展名>\` 是否逐文件一致 —— 一致就写"无变化，不用处理"。

---

## 5. 每次更新都要留痕（"更新了什么"落盘）

应用成功后，**追加一行**到 `state\UPDATE-LOG.md`（这个文件在 `state\` 里，更新器不会碰，能长期积累）：

```markdown
## 2026.09.24.1 · 2026-09-24 21:55 · profile=default
- 改了什么：更新类句子不再被判成抓取商品；自检脚本随包发
- 需要用户做：重启 Hermes（扩展无变化）
- 结果：selfcheck 9/9 PASS；费率对账差异 0 项
```

更细的机器可读记录已经在 `state\update_audit.jsonl`（谁、何时、从哪个版本到哪个版本、结果）——
`UPDATE-LOG.md` 是给人看的摘要，两个都要写。

---

## 6. 发布侧（我们出包/发版时）的对应规矩

发版=发布说明（`update.json` 的 notes）+ 包体。说明**必须**三段式，且**只引用客户机上真实存在的路径**
（曾经在说明里让客户跑 `%USERPROFILE%\verify_fee_engine.py`，而那个文件只在我们的测试机上 → 客户机
agent 老实去跑、报"不存在"。任何自检脚本都要**随包发**到 `plugins\<id>\delivery\verify\`）：

1. **改了什么**（客户能懂的话，一条一个"原来怎样 → 现在怎样"）
2. **需要用户做什么**（重启 / 扩展要不要重载 / 要不要换代理；没有就写"无"）
3. **怎么自证**（跑哪条命令、期望什么输出）

发之前跑仓库里的门禁（它会替你把这三个坑挡住）：

```bash
python3 scripts/precheck_release.py --notes <说明文件>
```

它一并验：通道包与本地包**逐字节一致** + 更新清单**逐文件 md5** + **说明里引用的文件名真在包里**
（`state\` 下的运行期文件自动跳过——那是客户数据，本就不该在包里）。这一关不过就别推。

## 7. 更新不许碰的东西（硬规矩）

更新**只换插件文件**，以下一律不许改、不许"顺手优化"：

1. **模型与供应商配置**：`config.yaml` 的 `model:` / `providers:`、`.env` 里的 key、`base_url`、默认模型
   —— 那是用户自己手工配的，agent 改了就是覆盖用户的工作。
   **不许**执行 `hermes config set model.*`、**不许**跑 `setup_llm_provider.py`（那是首次装机、用户明确要求时才用）。
   更新完模型报错 → 把原始报错报给用户，由用户决定，agent 不自行改配置。
2. `state\` 下的业务数据与密钥（Seller Key、stores.json、采集箱账本、费率/汇率配置）。
3. 用户已装的其它插件 / 技能 / 记忆。
4. 宿主 `.env` 里已有的 `TAKEALOT_API_PROXY` 等既有值（不覆盖为占位值）。
