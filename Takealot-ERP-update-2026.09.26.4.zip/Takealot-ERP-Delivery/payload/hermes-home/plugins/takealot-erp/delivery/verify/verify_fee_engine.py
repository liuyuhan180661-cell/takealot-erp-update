"""真店自证：用店铺自己的 /sales（平台已计费行）核对本工具的费率引擎。

在客户机上一条命令就能跑（不需要界面、不需要手工比对）：

    & "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts\python.exe" verify_fee_engine.py

判定标准（逐笔）：
    我方核算成功费 == /sales success_fee   （容差 0.01，平台四舍五入）
    我方核算履约费 == /sales fulfillment_fee + courier_collection_fee
退出码 0 = 全部对上；1 = 有差异（会打印每一笔的差额与原因）。
"""
import importlib.util
import os
import sys

try:  # Windows 控制台默认 GBK，先切成 UTF-8，否则中文/特殊字符会先把脚本打挂
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
_UP = os.path.dirname(HERE)
CANDIDATES = [
    os.environ.get("TAKEALOT_PLUGIN_DIR", ""),
    # 随包发出去的位置：<Hermes home>\plugins\takealot-erp\delivery\verify\ 的上两级就是插件目录
    os.path.join(os.path.dirname(os.path.dirname(HERE)), "dashboard"),
    # 多 profile 机器：HERMES_HOME 指到哪个 profile 根，就核对哪个 profile 的插件
    os.path.join(os.environ.get("HERMES_HOME", ""), "plugins", "takealot-erp", "dashboard"),
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "hermes", "plugins", "takealot-erp", "dashboard"),
    os.path.join(_UP, "plugin", "dashboard"),          # 交付方仓库：source/scripts + source/plugin
]
API_PATH = None
for base in CANDIDATES:
    if base and os.path.isfile(os.path.join(base, "plugin_api.py")):
        API_PATH = os.path.join(base, "plugin_api.py")
        break
if not API_PATH:
    print("找不到 plugin_api.py，用 TAKEALOT_PLUGIN_DIR 指定插件 dashboard 目录")
    sys.exit(2)

if "fastapi" not in sys.modules:
    try:
        import fastapi  # noqa: F401
    except ImportError:  # 没有宿主环境时也能跑（只用到纯函数）
        import types
        stub = types.ModuleType("fastapi")

        class _Router:
            def __init__(self, *a, **k):
                pass

            def __getattr__(self, _name):
                return lambda *a, **k: (lambda fn: fn)

        stub.APIRouter = _Router
        stub.Body = lambda *a, **k: None
        sys.modules["fastapi"] = stub

spec = importlib.util.spec_from_file_location("tkapi", API_PATH)
m = importlib.util.module_from_spec(spec)
sys.modules["tkapi"] = m
spec.loader.exec_module(m)
print("引擎:", API_PATH)
print("费率表:", m.FEE_DATA_FILE, "| 成功费基数:", m.fee_reference_meta().get("successFeeBase"))

TOL = 0.01
failures = []
checked = 0
for store in m._stores() or []:
    sid = str((store or {}).get("id") or "")
    name = (store or {}).get("name") or ""
    if not sid or not m._key_configured(sid):
        continue
    rows, err, truncated = m._fetch_live_sales(sid)
    billed = [r for r in rows if (r.get("total_fees") or 0)]
    print()
    print("=" * 104)
    print("店铺 {0}（{1}）: /sales {2} 行，其中已计费 {3} 行".format(sid, name, len(rows), len(billed)))
    print("=" * 104)
    if err:
        print("  取数失败:", err)
        continue
    if not billed:
        print("  该店没有已计费订单：费率对账需要平台已计费的行（费用滞后于结算）")
        continue
    offers = m._fetch_all_offers(sid)
    offer_rows = offers.get("items") or offers.get("rows") or []
    if not offer_rows and isinstance(offers, list):
        offer_rows = offers
    by_sku = {str(o.get("sku") or ""): o for o in offer_rows}
    catalog = m._catalog_items(store_id=sid)
    by_sku_item = {str(i.get("sku") or ""): i for i in (catalog.get("items") or [])}

    print("{0:<20} {1:>8} {2:>22} {3:>22}".format("SKU", "售价", "成功费 我方/平台", "履约费 我方/平台"))
    for sale in billed:
        sku = str(sale.get("sku") or "")
        offer = by_sku.get(sku) or {}
        item = by_sku_item.get(sku) or {}
        enrichment = item.get("enrichment") or {}
        price = float(sale.get("selling_price") or 0)
        title = str(offer.get("title") or item.get("title") or "")
        path = str(enrichment.get("categoryPath") or "")
        fee = m.calculate_success_fee(price, path or None, price=price, title=title)
        dc = m.calculate_dc_fulfillment_fee({
            "weightKg": float(offer.get("weight_grams") or 0) / 1000.0 or None,
            "lengthCm": offer.get("length_cm"), "widthCm": offer.get("width_cm"),
            "heightCm": offer.get("height_cm"),
            "category": path, "categoryPath": path, "title": title,
        })
        real_success = float(sale.get("success_fee") or 0)
        real_dc = float(sale.get("fulfillment_fee") or 0) + float(sale.get("courier_collection_fee") or 0)
        got_success = fee.get("feeAmount")
        got_dc = dc.get("fulfillmentFeeZAR")
        ok_s = got_success is not None and abs(got_success - real_success) <= TOL
        ok_d = (real_dc == 0 and got_dc is None) or (got_dc is not None and abs(got_dc - real_dc) <= TOL)
        checked += 2
        if not ok_s:
            failures.append((sid, sku, "成功费", real_success, got_success, fee.get("note")))
        if not ok_d:
            failures.append((sid, sku, "履约费", real_dc, got_dc, dc.get("note")))
        print("{0:<20} {1:>8} {2:>22} {3:>22}".format(
            sku, "{0:g}".format(price),
            "{0} / {1} {2}".format("None" if got_success is None else "{0:.2f}".format(got_success),
                                   "{0:.2f}".format(real_success), "OK" if ok_s else "XX"),
            "{0} / {1} {2}".format("None" if got_dc is None else "{0:.2f}".format(got_dc),
                                   "{0:.2f}".format(real_dc), "OK" if ok_d else "XX")))
        print("       成交成功费率 {0} [{1}]  履约档 {2} {3}".format(
            fee.get("ratePercent") or "未匹配", fee.get("rateSource") or "-",
            dc.get("tier") or "未定", "体积 {0} cm3".format(dc.get("volumeCm3")) if dc.get("volumeCm3") else ""))

print()
print("=" * 104)
print("逐笔对账：{0} 项，差异 {1} 项".format(checked, len(failures)))
for row in failures:
    print("  DIFF", row)
print("证据来源：店铺自己的 Seller API /sales + /offers（平台已计费金额），非估算")
sys.exit(1 if failures else 0)
