#!/usr/bin/env python3
"""误命中报表：读 state/route_misfire.jsonl，看哪些规则在真实使用里被忽略，据此调词表。

设计立场：**不把规则写死**。词表随客户使用演化 —— 误命中时 agent 只记一行（代价趋零），
积累到一定量再改词表 / 加否定，而不是靠猜或提前写一堆域名白名单。

用法:
    python3 route_misfire_report.py <插件目录>        # 默认取 %LOCALAPPDATA%\\hermes\\plugins 下的第一个
    python3 route_misfire_report.py --tail 20
"""
from __future__ import annotations

import argparse
import collections
import json
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


HERE = os.path.dirname(os.path.abspath(__file__))


def default_plugin_dir() -> str:
    # 脚本自己就躺在插件目录里（<插件>\delivery\verify\）→ 优先用自己所在的这个插件，
    # 免得机器上装了多个插件时读错别人的 state。
    here_plugin = os.path.dirname(os.path.dirname(HERE))
    if os.path.isdir(os.path.join(here_plugin, "dashboard")):
        return here_plugin
    # 退路：HERMES_HOME 优先（多 profile 机器 / 装在别的盘），否则默认位置下的第一个插件
    home = (os.environ.get("HERMES_HOME") or "").strip().strip('"').strip("'").rstrip("\\/")
    if not home:
        home = (os.path.join(os.environ.get("LOCALAPPDATA", ""), "hermes") if os.name == "nt"
                else os.path.expanduser("~/.hermes"))
    base = os.path.join(home, "plugins")
    if os.path.isdir(base):
        for name in sorted(os.listdir(base)):
            if os.path.isdir(os.path.join(base, name)):
                return os.path.join(base, name)
    return base


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("plugin_dir", nargs="?", default=default_plugin_dir())
    ap.add_argument("--tail", type=int, default=10, help="打印最近 N 条")
    args = ap.parse_args()

    path = os.path.join(args.plugin_dir, "state", "route_misfire.jsonl")
    if not os.path.exists(path):
        print("没有误命中记录：%s" % path)
        print("（这是好事：要么没触发过，要么 agent 没按逃生条款记账。")
        print("  装了新版插件后，被忽略的误命中会自动写进这个文件。）")
        return 0

    rows = []
    for line in open(path, encoding="utf-8", errors="replace"):
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except Exception:
            continue

    print("=== 误命中统计 ===")
    print("总计 %d 条，文件 %s" % (len(rows), path))
    by_rule = collections.Counter(str(r.get("rule", "?")) for r in rows)
    for rule, n in by_rule.most_common():
        print("  %-26s %d 次" % (rule, n))
    words = collections.Counter()
    for r in rows:
        for w in str(r.get("matched", "")).replace("、", ",").split(","):
            if w.strip():
                words[w.strip()] += 1
    if words:
        print()
        print("=== 触发它的命中文（按次数）——这些词是该收紧的候选 ===")
        for w, n in words.most_common(15):
            print("  %-20s %d" % (w, n))

    print()
    print("=== 最近 %d 条 ===" % min(args.tail, len(rows)))
    for r in rows[-args.tail:]:
        print("  [%s] rule=%s matched=%s text=%s" % (str(r.get("at", ""))[:19], r.get("rule"),
                                                     r.get("matched"), str(r.get("text", ""))[:60]))

    print()
    print("怎么用：命中次数多、又确实与产品无关的命中文，就")
    print("  ① 从该规则的 phrases 里去掉，或 ② 加进否定判断，或 ③ 给规则加语境守卫（guard_phrases）。")
    print("改完跑一次 scripts/patches/verify_router_setup.py 做回归。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
