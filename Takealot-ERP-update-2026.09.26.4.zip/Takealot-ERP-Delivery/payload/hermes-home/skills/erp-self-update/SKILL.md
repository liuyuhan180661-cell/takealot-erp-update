---
name: erp-self-update
description: Use when checking or applying an ERP update.
---

# ERP 自更新（检查更新 / 更新 / 回滚）

> **完整规范（流程判据、报告模板、更新日志格式、多 profile 处理）见同目录 `UPDATE-SPEC.md`。**
> 本文件是**执行清单**：照它做，遇到没写到的细节去翻 `UPDATE-SPEC.md`（插件目录里也有同一份：
> `<Hermes home>\plugins\takealot-erp\delivery\UPDATE-SPEC.md`）。

## 触发词

`检查更新` · `有没有新版本` · `更新 ERP` · `升级一下` · `回滚` · `退回上一版` · `更新失败怎么办`

## 流程（照做，别跳）

1. **找更新器**：按顺序找哪个存在用哪个
   - `%LOCALAPPDATA%\hermes\plugins\<插件 id>\delivery\selfupdate.py`
   - 本技能目录旁 `selfupdate.py`
   - 交付包解压目录里的同名文件

   **都没有 → 从公开通道下载它（这一步就是"给个地址让它自己拉"）**：
   ```
   https://cdn.jsdelivr.net/gh/<owner>/<repo>@main/selfupdate.py
   https://raw.githubusercontent.com/<owner>/<repo>/main/selfupdate.py      （jsDelivr 不通时用）
   ```
   下载后放到 `%LOCALAPPDATA%\hermes\plugins\<插件 id>\delivery\selfupdate.py` 即可（单文件即可运行；
   不需要其它依赖）。之后它就自给自足了 —— 更新包会把最新版更新器一起带过来。

2. **先检查（不动文件）**
   ```
   <Hermes venv python> selfupdate.py --repo <公开通道仓库 owner/repo>
   ```
   它会按 `GitHub API → raw.githubusercontent → gh-proxy → jsDelivr` 自动降级（API 无 CDN 缓存，发布后立刻可见）；成功会打印：远端版本 / 本机版本 / 包大小 / 变更说明 / 会改哪些文件。

3. **把结果念给用户**（版本从哪到哪、包多大、变了什么），**等用户确认**。

4. **用户确认后应用**
   ```
   ... --apply
   ```
   内部顺序：下载 → 整包 sha256+md5 校验 → 包内 MANIFEST 逐文件 md5 校验 → **自动备份** → 按白名单落盘 → 写版本记录 + 审计。

5. **应用后必须验证**（这是完成的唯一判据）
   - 跑 `selfcheck.ps1` → 期望 **9/9 PASS**；把实际结果告诉用户
   - 若这次更新动了浏览器扩展 → 让用户在 `chrome://extensions` 点一次「重新加载」
   - **界面半边**（`plugin.js`）由桌面 App 热加载，无需重启 ✓
   - **后端半边**（`plugin_api.py` / `tools.py` 等）是被**运行中的进程加载**的：文件覆盖成功 ≠ 生效，
     必须让用户**完全退出并重开 Hermes**（否则行为还是旧的，客户会说"更新了没用"）。
     更新完的标准动作：重启 App → 跑 `selfcheck.ps1` → 期望 9/9 PASS → 再让客户试一次原功能。

6. **按模板写报告 + 留痕**（缺一项不算完成）
   - 报告六段（模板见 `UPDATE-SPEC.md` §4）：`【更新】旧版本 → 新版本` · `【范围】哪个 profile 更新了、
     哪个还没` · `【改了什么】` · `【需要你做的】` · `【验证】` · `【回滚】`
   - 往 `state\UPDATE-LOG.md` 追加一行摘要（人看的，格式见 `UPDATE-SPEC.md` §5）；
     机器可读的 `state\update_audit.jsonl` 由更新器自己写。

7. **失败或客户不满意** → `... --rollback`（文件与版本记录一起回退；`state/` 从不参与）

## 浏览器扩展是例外的（重要）

更新器**不会**改浏览器扩展（它在 Chrome 里是「加载已解压」装的，脚本改它无效）。
`--apply` 之后如果打印「浏览器扩展有更新（按约定不自动更新，需手动处理）」：
1. 把更新包里的 `payload/extension/<扩展名>/` 覆盖到 `%LOCALAPPDATA%\hermes\<扩展名>\`
2. 让用户在 `chrome://extensions` 点一次「重新加载」

把这两步**明确告诉用户**，不要只说「更新完了」。

## 多 profile 的机器（**别漏**）

Hermes 的 **一个 profile = 一个独立的 Hermes home**（边界就是 `HERMES_HOME`；默认 profile 的根是
`%LOCALAPPDATA%\hermes`，其它 profile 在 `%LOCALAPPDATA%\hermes\profiles\<名字>`）。插件、`skills\`、
`config.yaml`、`.env`、`state\` **各 profile 各一套** —— 所以更新只作用于**你跑更新器时所在的那个 profile**。

- 动手前先看有没有别的 profile：`Get-ChildItem "$env:LOCALAPPDATA\hermes\profiles" -Directory`
- 有，就**问用户要不要一起更新**（别自己决定，也别默认忽略）：
  ```powershell
  $env:HERMES_HOME="$env:LOCALAPPDATA\hermes\profiles\<名字>"
  & "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts\python.exe" `
    "$env:HERMES_HOME\plugins\takealot-erp\delivery\selfupdate.py" --repo <owner/repo> --apply
  ```
  （更新器认 `HERMES_HOME`，会落到那个 profile 的插件目录；`state\` 同样不碰。）
- 报告必须写清**哪个 profile 更新了、哪个还是旧版** —— 否则用户会以为全机器都更新了。

## 本轮是「更新 ERP」而不是抓商品（别被误判）

更新说明里常带**通道地址**（GitHub / gh-proxy / jsDelivr）。词表已加守卫：更新/回滚类的句子
不会被注入抓取工具。若仍被注入（老版本），按工具指令里的**逃生条款**处理：忽略注入、按用户原意做，
并把这一行记进 `state/route_misfire.jsonl`；之后用随包发的
`delivery\verify\route_misfire_report.py` 看是哪个词触发的。

## 铁律

- **先 dry-run 再 apply**，不要替客户决定装不装
- **绝不碰 `state/`**（Seller Key 与业务数据）——更新器已用白名单限制，别绕过它手工覆盖文件
- 校验失败（整包指纹或逐文件 md5 不符）**一律中止**，不要"重试到成功"，也不要拿别处的包顶替
- 更新完只报 `selfcheck` 的**实际输出**，不许说"应该没问题"
- **每次更新都要写明"改了什么"**：报告按 `UPDATE-SPEC.md` §4 的六段写全 + 往 `state\UPDATE-LOG.md` 留一行
- 扩展那一项要**真比对**再写：更新包里的扩展与客户机上的 `<Root>\<扩展名>\` 逐文件一致 → 写"无变化，
  不用处理"（别让用户白点一次「重新加载」，也别在真变了时说"没变"）
- 三通道全不通就如实说网络不通，并在下一条回复里告诉用户可选项（换代理 / 走 gh-proxy / 稍后重试）
- 相同版本想重装用 `--force`（仍会做全部校验），不要为此改版本号

## 版本信息

- 当前版本查 `--status`（读 `state/installed.json`）
- 审计记录：`state/update_audit.jsonl`（谁、什么时候、从哪个版本到哪个版本、结果）
