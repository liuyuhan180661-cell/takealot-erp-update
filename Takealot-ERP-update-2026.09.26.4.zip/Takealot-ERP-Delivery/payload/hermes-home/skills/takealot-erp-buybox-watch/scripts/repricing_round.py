#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""24h 买盒盯盘 —— 一轮巡检的确定性执行器（唯一允许的写入入口）。

设计原则：**报告里的每个数字都必须来自本脚本的输出**。
agent 只许运行本脚本并原样转述；不许自己算价、不许自己写总结、不许凭接口响应声称成功。

用法（客户机）：
    <hermes venv python> repricing_round.py --store store-2
    <hermes venv python> repricing_round.py            # 用 state/repricing_watch.json 里的 storeIds
退出码：0 = 本轮无异常；1 = 有未验证/失败/越界项（需 agent 汇报）。

每一步都留证据：
  1) 候选来自 POST/GET 真实端点
  2) 写入走后端唯一写价路径（PATCH + 后端自身回读）
  3) 本脚本再独立 GET 回读一次（不信后端自述，也不信 agent 自述）
  4) 账本行 append 到 state/repricing_watch_log.md（UTF-8）
"""
import argparse
import datetime as dt
import json
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERMES = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "hermes")
PLUGIN = os.path.join(HERMES, "plugins", "takealot-erp")
sys.path.insert(0, PLUGIN)
sys.path.insert(0, os.path.join(PLUGIN, "dashboard"))

import plugin_api as A  # noqa: E402

STATE = getattr(A, "_state_dir", None) or os.path.join(PLUGIN, "state")


def state_path(name):
    return os.path.join(STATE, name)


def load_watch():
    p = state_path("repricing_watch.json")
    if not os.path.exists(p):
        print("ABORT: 未找到 %s —— 没有授权就不许写价" % p)
        sys.exit(2)
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def api(method, path, body, store_id):
    return A._api_request(method, path, None, body, store_id=store_id)


def readback_price(sku, store_id):
    d, _ = A._api_request("GET", "/offers/by_sku/{0}".format(sku), None, None, store_id=store_id)
    o = (d or {}).get("offer") or d or {}
    try:
        return float(o.get("selling_price"))
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", default="")
    ap.add_argument("--skus", default="")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    cfg = load_watch()
    if cfg.get("authorized") is not True:
        print("ABORT: repricing_watch.json 里 authorized != true，拒绝写入")
        sys.exit(2)
    stores = [args.store] if args.store else list(cfg.get("storeIds") or [])
    if not stores:
        print("ABORT: 没有 storeIds")
        sys.exit(2)
    max_round = int(args.limit or cfg.get("maxChangesPerRun") or 10)
    floor = cfg.get("floorPrice")
    ceiling = cfg.get("ceilingPrice")
    undercut = float(cfg.get("minUndercut") or 1.0)

    stamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    ledger = []
    problems = []
    total_write = total_skip = total_fail = 0

    for store in stores:
        cand = A.repricing_candidates(storeId=store) or {}
        items = cand.get("items") or []
        need = []
        for it in items:
            if args.skus and str(it.get("sku")) not in args.skus.split(","):
                continue
            if not it.get("listed"):
                continue
            if it.get("buyboxHeld"):
                continue
            if it.get("lowestCompetitor") is None:
                continue
            need.append(it)
        need = need[:max_round]
        if not need:
            print("[%s] %s: 本轮无需动作（候选 %d 条，已有买盒或无竞品数据）" % (stamp, store, len(items)))
            continue
        skus = [str(i.get("sku")) for i in need]
        print("[%s] %s: 本轮提交 %d 条 -> %s" % (stamp, store, len(skus), ",".join(skus)))
        res = A.repricing_save({"storeId": store, "scope": "selection", "skus": skus,
                                "floorPrice": floor, "undercutAmount": undercut,
                                "ceilingPrice": ceiling, "autoEnabled": bool(cfg.get("autoEnabled"))})
        for row in (res.get("applied") or []):
            sku = str(row.get("sku"))
            result = row.get("result")
            newp = row.get("newPrice")
            got = readback_price(sku, store)
            if result == "WROTE":
                ok = got is not None and newp is not None and abs(float(got) - float(newp)) < 0.01
                total_write += 1 if ok else 0
                if not ok:
                    total_fail += 1
                    problems.append("%s 声称写入 %s 但平台回读 %s" % (sku, newp, got))
                line = "%s | %s | %s | %s -> %s | 平台回读 %s | %s" % (
                    stamp, sku, "WROTE(已验证)" if ok else "WROTE(未验证!)",
                    row.get("oldPrice"), newp, got, str(row.get("reason") or "")[:60])
            elif result == "SKIPPED":
                total_skip += 1
                line = "%s | %s | SKIPPED | %s | %s" % (stamp, sku, row.get("oldPrice"), str(row.get("reason") or "")[:80])
            else:
                total_fail += 1
                problems.append("%s 结果 %s: %s" % (sku, result, str(row.get("reason") or "")[:80]))
                line = "%s | %s | FAILED | %s" % (stamp, sku, str(row.get("reason") or "")[:80])
            ledger.append(line)

    with open(state_path("repricing_watch_log.md"), "a", encoding="utf-8") as fh:
        for line in ledger:
            fh.write("- " + line + "\n")

    # 静默模式：本轮无事发生就一个字都不打印 —— 配合 cron no_agent=true，
    # 没有输出 = 不会给用户发消息（看门狗模式），从结构上杜绝"没执行说执行了"。
    if not ledger and not problems:
        sys.exit(0)

    print("")
    print("SUMMARY: 写入 %d 条 · 跳过 %d 条 · 失败/未验证 %d 条" % (total_write, total_skip, total_fail))
    print("LEDGER: %s" % state_path("repricing_watch_log.md"))
    if problems:
        print("PROBLEMS:")
        for p in problems:
            print("  - " + p)
        sys.exit(1)
    if not ledger:
        print("NOTE: 本轮没有任何需要动作的 listing（不是失败）")
    sys.exit(0)


if __name__ == "__main__":
    main()
