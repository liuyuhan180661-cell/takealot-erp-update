---
name: takealot-erp-buybox-watch
description: Use when 客户要 24 小时盯盘 / 买盒守护 / 自动跟价巡检（Takealot ERP）。授权一次后按固定间隔自动巡检并写价，异常才叫醒用户。
---

# 24 小时买盒盯盘（Takealot ERP）

> 搭配跟价重构后的新逻辑用（`docs/REPRICING-SPEC.md`）：**勾选即自动、点即写入、没有试算**。
> 本 skill 让 agent 从「用户点一下」升级为「不间断定时巡检」，但**只问一次权限**。

## 何时用
- 用户说「24 小时盯着 / 帮我守买盒 / 自动跟价 / 别让对手抢走购物车」。
- 前提：客户机已装本插件、卖家 Key 已配、跟价页能用（能读到候选）。

## 第 0 步：一次授权（只问这一次，之后不再问）
一次问清三件事，缺一个都不要开始：
1. **多久巡一次**（默认 2 小时；最小 30 分钟，别更密）
2. **调价范围**：下探 `R__` ~ 最多 `R__`（例：R1 ~ R50）—— 下探 = 比最低竞品低多少；最多 = 单次不许砸穿多少
3. **允许直接写平台价吗**（本插件默认允许；明确告知"写入立即生效、没有试算"）

授权落盘 `state\repricing_watch.json`：
```json
{"authorized": true, "authorizedAt": "<ISO>", "intervalHours": 2,
 "minUndercut": 1, "maxUndercut": 50, "storeIds": ["store-2"], "quiet": true}
```
然后建定时任务 —— **用 no_agent=true 直接跑脚本**（常规巡检完全不经过模型，结构上不可能幻觉；
脚本无事发生时不打印任何内容 → 不会给用户发消息；有写入/失败才把脚本输出原样发给用户）：
```
cronjob_manage(action="create", name="Takealot 买盒盯盘",
               schedule="every 2h",
               script="%LOCALAPPDATA%\\hermes\\skills\\takealot-erp-buybox-watch\\scripts\\repricing_round.py",
               no_agent=true, deliver="origin")
```
（机器开着才跑：Hermes 网关运行时调度器才跳；关机期间不跑、开机后继续，不补跑。
任务会出现在桌面端左侧「定时任务」面板里，客户可自行暂停/恢复/立即触发/删除 —— 收回授权不必找 agent。）
建完把任务 id 记进 `repricing_watch.json` 的 `cronId`，并告诉用户「已开始，授权范围 R1~R50，每 2 小时一次；说『停』我就停」。

## 每轮巡检（确定性步骤，不猜、不发挥）
1. 读 `state\repricing_watch.json`：`authorized` 非 true → 立刻停（不写任何价）。
2. 对每个 `storeIds`：`GET /repricing/candidates?storeId=<店>`（一次拿全，不要逐条轮询）。
3. 逐条判定：
   - `listed=false`（已下架）→ 跳过，不写。
   - `buyboxHeld=true` → 跳过（已处优势地位）。
   - `lowestCompetitor` 为空 → 记「未抓取」，调 `POST /buybox/enrich` 补一次，本轮不写。
   - 其余 = 需要跟价。
4. 目标价（与后端同一公式，写死）：
   `target = 最低竞品价 − 下探值`（下探值默认 `minUndercut`，即 R1）；
   再被 `floorPrice`（用户保本底价）与 `ceilingPrice`（天花板价）夹取；
   并按本轮授权再收一道：`target ≥ 现价 − maxUndercut`（单次不许砸穿）；
   夹取后仍 ≥ 现价、或落在边界外 → **不写**（交给后端记 `SKIPPED` + 原因）。
5. 写入：`POST /repricing/run {"storeId": <店>, "skus": [...]}`（只放本轮算得出且该写的 SKU）。
   单轮条数 ≤ `maxChangesPerRun`（默认 10），多出的**留到下一轮** —— 不许为了"一次做完"绕过限速。
6. 复核（必做，不许省）：对每条写过的 SKU `GET /offers/by_sku/{sku}`，回读价 == 目标价才算成功；
   不等 → 记 `FAILED` + 平台原文，下一轮重试一次；仍失败 → 叫醒用户。
7. 留痕：`GET /repricing/log?storeId=…&limit=50` 取本轮新增行，追加进 `state\repricing_watch_log.md`：
   `时间 · SKU · 旧价→新价 · 结果(WROTE/SKIPPED/FAILED) · 平台回读 · 原因`，一行一条。

## 证据铁律（防「没执行说执行了」）
**唯一允许的写入入口 = 本 skill 自带的脚本**：
`<hermes venv python> "%LOCALAPPDATA%\hermes\skills\takealot-erp-buybox-watch\scripts\repricing_round.py" --store <店>`

- agent 只许**运行它并原样转述它的输出**（`SUMMARY` / `PROBLEMS` 行）。不许自己算价、不许自己写总结、不许在脚本报错时美化措辞。
- 脚本内部的链路：读授权 → 拉候选 → 提交写入 → **再独立 GET 回读一次**（不信后端自述、也不信 agent 自述）→ 账本行 append 到 `state\repricing_watch_log.md`。
- **判定成功的唯一标准**：脚本打印 `WROTE(已验证)` 且 `SUMMARY` 里「失败/未验证」为 0（退出码 0）。
  出现 `WROTE(未验证!)`、`FAILED`、或退出码 1 → 必须如实说"未生效"，并附 `PROBLEMS` 原文。
- 任何「我已调价 / 已同步」的说法，必须**同时**给出三样：脚本输出、账本尾行、`state\offer_writes.json` 里该 SKU 的 `readbackPrice`。缺一即视为没执行。
- 脚本在无授权 / 无 storeIds 时会打印 `ABORT:` 并以退出码 2 结束 —— **这就是"没执行"，不许说成"已巡检"**。
- 平台侧证据以 `GET /offers/by_sku/{sku}` 的回读价为准；「接口返回 200」不算证据。

## 汇报纪律（默认静默，别刷屏）
- 正常轮次**不打扰用户**，只往日志文件累积。
- 只在下列情况主动发一条消息（附证据，不写长篇）：
  ① 出现 `FAILED`，或平台 4xx/5xx；② 连续 2 轮买盒仍未夺回；③ 竞品价跌破保本底价导致无法跟；
  ④ 单轮触顶/触底 ≥ 3 条；⑤ 候选数骤降（数据通道疑似断，先查通道再动手）。
- 日报（用户要才发）：`今日调价 N 条：写入 M、跳过 K（原因 top2）、失败 J`。

## 暂停 / 改范围
- 用户说「停」：删对应 cron 任务 + 把 `authorized` 置 false（已调出去的价格不再自动变，要还原就按第 4 步的手工 PATCH）。
- 用户改范围/改间隔：只改 `state\repricing_watch.json`（和 cron 的 schedule），不重建流程。

## 硬规矩
- **写价即时生效、没有试算、没有二次确认**：每轮动的都是真钱，授权前把范围讲清、写进文件。
- 不碰模型/供应商配置、不碰 `.env`、不碰用户其它插件与技能；只读写 `state\` 与调价相关端点。
- 未选定店铺的汇总视图**禁止写入**。
- 单轮上限与冷却（跟降/抬价冷却）是平台风控，不许绕过。
- 手工试写/还原规程照 `docs/REPRICING-SPEC.md` 第九节：只拿「目标价与现价差 ≤ R1」的 listing 或测试店试；
  还原用 `_api_request("PATCH", "/offers/by_sku/{sku}", None, {"selling_price": int(原价)}, store_id=...)`
  —— 注意签名是 `(method, path, query, body, ...)`，body 传错位置会被平台 400 拒且**误以为已还原**；还原后必须 GET 回读确认。

## 收工汇报（给用户的自证四件）
- `state\repricing_watch.json`（授权范围 + 间隔）
- `state\repricing_watch_log.md` 尾 10 行
- `state\offer_writes.json` 里本轮 `WROTE` 行的 `readbackPrice`
- 一句话：这轮写了哪些 SKU、各几块钱、平台回读价是多少
