#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""头程运费计算器（Takealot ERP 辅助技能）。

规则（默认）：
  体积重 kg = 长 cm × 宽 cm × 高 cm ÷ divisor
  计费重 kg = max(实重 kg, 体积重 kg)
  运费 = 计费重 × 单价

两种计费方式：
  * 默认整票合并：max(总实重, 总体积重) × 单价
  * --per-parcel：每个包裹分别 max(实重, 体积重) × 单价，再乘件数

不编造物流商报价。未知物流商或缺单价/体积系数时，返回 ok=false + 需要问用户的问题。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
PROVIDERS_FILE = HERE.parents[1] / "references" / "providers.json"


def _r(value, ndigits=2):
    if value is None:
        return None
    return round(float(value), ndigits)


def _questions_for(provider_name: str, have_rate: bool, have_divisor: bool) -> list:
    q = []
    if not have_rate:
        q.append("这家物流商的单价是多少？请注明币种（例如 ¥95/kg、R120/kg）")
    if not have_divisor:
        q.append("体积重系数是多少？长×宽×高÷?（常见 6000，但不要替用户假设）")
    q.append("按整票合并计费，还是每个包裹/单件分别计费？")
    q.append("报价是否含燃油/偏远/附加费？从哪天生效？")
    return q


def load_providers() -> dict:
    try:
        return json.loads(PROVIDERS_FILE.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SystemExit("[FATAL] 读不到 references/providers.json：%s" % exc)


def find_provider(data: dict, needle: str):
    target = str(needle or "").strip().lower()
    if not target:
        return None
    for pid, row in (data.get("providers") or {}).items():
        names = [pid, row.get("name") or ""] + list(row.get("aliases") or [])
        if any(str(n).strip().lower() == target for n in names if n):
            return pid, row
    return None


def print_provider_list(data: dict) -> None:
    print("物流商               单价            体积系数   状态")
    print("────────────────────────────────────────────────────────")
    for pid, row in (data.get("providers") or {}).items():
        rate = row.get("rate_cny_per_kg")
        divisor = row.get("divisor")
        status = "已核对" if row.get("verified") else "待补充"
        rate_text = ("¥%s/kg" % rate) if rate is not None else "未配置"
        div_text = str(divisor) if divisor is not None else "未配置"
        print("%-20s %-14s %-10s %s" % (row.get("name") or pid, rate_text, div_text, status))
        if row.get("note"):
            print("  └ %s" % row["note"])


def main() -> int:
    ap = argparse.ArgumentParser(description="头程运费计算（实重/体积重取大）")
    ap.add_argument("--list", action="store_true", help="列出已知物流商与报价")
    ap.add_argument("--provider", default="", help="物流商（炫思/ITS/xuansi/水牛/custom/任意名称）")
    ap.add_argument("--weight-kg", type=float, default=None, help="单件实重 kg")
    ap.add_argument("--length-cm", type=float, default=None)
    ap.add_argument("--width-cm", type=float, default=None)
    ap.add_argument("--height-cm", type=float, default=None)
    ap.add_argument("--qty", type=int, default=1, help="件数（默认 1）")
    ap.add_argument("--rate-per-kg", "--rate-cny-per-kg", dest="rate_cny_per_kg", type=float, default=None,
                    help="单价覆盖（不是 CNY 时用 --rate-currency 说明；另给 fx 才能折 ZAR）")
    ap.add_argument("--rate-currency", default="CNY", help="单价币种（默认 CNY）")
    ap.add_argument("--divisor", type=float, default=None, help="体积系数，如 6000")
    ap.add_argument("--fx-zar-per-cny", type=float, default=None,
                    help="ZAR / 单价币种 汇率（例如 2.5）；不给则只算原币")
    ap.add_argument("--per-parcel", action="store_true",
                    help="按每个包裹分别计费（默认整票合并计费）")
    ap.add_argument("--json", action="store_true", help="只输出 JSON")
    args = ap.parse_args()

    data = load_providers()
    if args.list:
        print_provider_list(data)
        return 0

    if not args.provider:
        msg = {"ok": False, "error": "missing_provider",
               "questions": ["要算哪家物流商？已知：炫思 (ITS)、水牛（单价/系数待补充）"]}
        print(json.dumps(msg, ensure_ascii=False, indent=2))
        return 2

    hit = find_provider(data, args.provider)
    if hit:
        pid, row = hit
    else:
        pid, row = "custom", {"name": args.provider, "rate_cny_per_kg": None, "divisor": None,
                              "verified": False, "note": "用户自定义物流商"}

    rate = args.rate_cny_per_kg if args.rate_cny_per_kg is not None else row.get("rate_cny_per_kg")
    divisor = args.divisor if args.divisor is not None else row.get("divisor")
    missing_rate = rate in (None, "")
    missing_divisor = divisor in (None, "")
    if missing_rate or missing_divisor:
        msg = {
            "ok": False,
            "error": "provider_incomplete",
            "provider": {"id": pid, "name": row.get("name") or args.provider,
                         "verified": bool(row.get("verified")),
                         "note": row.get("note") or ""},
            "have_rate": not missing_rate,
            "have_divisor": not missing_divisor,
            "questions": _questions_for(row.get("name") or args.provider, not missing_rate, not missing_divisor),
            "hint": "不要替用户猜单价或体积系数。拿到答案后带 --rate-cny-per-kg 与 --divisor 再算；"
                    "如果按单件分别计费，再加 --per-parcel。"
        }
        print(json.dumps(msg, ensure_ascii=False, indent=2))
        return 2

    required = {"weight_kg": args.weight_kg, "length_cm": args.length_cm,
                "width_cm": args.width_cm, "height_cm": args.height_cm}
    missing = [k for k, v in required.items() if v is None]
    if missing:
        msg = {"ok": False, "error": "missing_inputs", "missing": missing,
               "questions": ["请补：单件实重 kg、长 cm、宽 cm、高 cm（按包装后尺寸）"]}
        print(json.dumps(msg, ensure_ascii=False, indent=2))
        return 2

    weight = float(args.weight_kg)
    length = float(args.length_cm)
    width = float(args.width_cm)
    height = float(args.height_cm)
    qty = int(args.qty or 1)
    if weight < 0 or length <= 0 or width <= 0 or height <= 0 or qty < 1 or float(divisor) <= 0 or float(rate) <= 0:
        msg = {"ok": False, "error": "invalid_input",
               "hint": "实重 ≥0；长宽高 >0；件数 ≥1；单价与体积系数 >0"}
        print(json.dumps(msg, ensure_ascii=False, indent=2))
        return 2

    divisor = float(divisor)
    rate = float(rate)
    volume_per_unit = (length * width * height) / divisor
    chargeable_per_unit = max(weight, volume_per_unit)
    shipment_actual = weight * qty
    shipment_volume = (length * width * height * qty) / divisor
    shipment_chargeable = max(shipment_actual, shipment_volume)

    if args.per_parcel:
        fee = chargeable_per_unit * rate * qty
        mode = "per-parcel"
        chargeable_used = chargeable_per_unit * qty
    else:
        fee = shipment_chargeable * rate
        mode = "consolidated"
        chargeable_used = shipment_chargeable

    fx = args.fx_zar_per_cny
    fee_zar = fee * fx if fx and fx > 0 else None
    fee_per_unit = fee / qty
    fee_per_unit_zar = (fee_zar / qty) if fee_zar is not None else None
    currency = str(args.rate_currency or "CNY").upper()

    out = {
        "ok": True,
        "provider": {"id": pid, "name": row.get("name") or args.provider,
                     "verified": bool(row.get("verified")),
                     "note": row.get("note") or "",
                     "effective_from": row.get("effective_from") or ""},
        "input": {"weight_kg": weight, "length_cm": length, "width_cm": width,
                  "height_cm": height, "qty": qty, "divisor": divisor,
                  "rate": rate, "rate_currency": currency, "mode": mode,
                  "fx_zar_per_rate_currency": fx},
        "calc": {
            "volume_weight_per_unit_kg": _r(volume_per_unit, 3),
            "chargeable_per_unit_kg": _r(chargeable_per_unit, 3),
            "shipment_actual_kg": _r(shipment_actual, 3),
            "shipment_volume_weight_kg": _r(shipment_volume, 3),
            "shipment_chargeable_kg": _r(shipment_chargeable, 3),
            "chargeable_used_kg": _r(chargeable_used, 3),
            "fee": _r(fee, 2),
            "fee_currency": currency,
            "fee_per_unit": _r(fee_per_unit, 2),
            "fee_zar": _r(fee_zar, 2) if fee_zar is not None else None,
            "fee_per_unit_zar": _r(fee_per_unit_zar, 2) if fee_per_unit_zar is not None else None,
        },
        "formula": "体积重 = 长×宽×高÷%s；计费重 = max(实重, 体积重)；运费 = 计费重×%s %s/kg" % (
            _trim(divisor), _trim(rate), currency),
        "note": ("整票合并计费：max(总实重, 总体积重)×单价" if mode == "consolidated"
                 else "按每个包裹分别 max(实重, 体积重)×单价，再乘件数"),
    }
    if fee_zar is None:
        out["hint"] = "没有给 ZAR 汇率：只输出原币。要折 ZAR，请补 --fx-zar-per-cny（ZAR/单价币种）。"

    if args.json:
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0

    c = out["calc"]
    print("物流商：%s%s" % (out["provider"]["name"], "" if out["provider"]["verified"] else "（未核对）"))
    print("输入：实重 %.3f kg · 尺寸 %.2f×%.2f×%.2f cm · %d 件 · 系数 %s · 单价 %s %.2f/kg" % (
        weight, length, width, height, qty, _trim(divisor), currency, rate))
    print("单件：体积重 %.3f kg · 计费重 %.3f kg" % (c["volume_weight_per_unit_kg"], c["chargeable_per_unit_kg"]))
    print("整票：实重 %.3f kg · 体积重 %.3f kg · 计费重 %.3f kg" % (
        c["shipment_actual_kg"], c["shipment_volume_weight_kg"], c["shipment_chargeable_kg"]))
    print("运费：%s %.2f（单件 %s %.2f）" % (currency, c["fee"], currency, c["fee_per_unit"]))
    if c["fee_zar"] is not None:
        print("折 ZAR：R %.2f（单件 R %.2f）" % (c["fee_zar"], c["fee_per_unit_zar"]))
    print("口径：%s" % out["note"])
    if out.get("hint"):
        print("提示：%s" % out["hint"])
    return 0


def _trim(value: float) -> str:
    text = ("%.6f" % float(value)).rstrip("0").rstrip(".")
    return text or "0"


if __name__ == "__main__":
    sys.exit(main())
