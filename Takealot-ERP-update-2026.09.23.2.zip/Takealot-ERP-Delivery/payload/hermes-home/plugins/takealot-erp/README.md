# Takealot 跨境中台（Hermes 桌面插件）

私人部署的 Takealot 卖家 ERP：费用/利润核算、BuyBox 跟价、采集箱与上架编排、竞品与销量分析、
合规检测、结算单对账。Agent 与界面都在本机，**除取数与 AI 文案外不出网**。

## 三块拼图（同一插件 id：`takealot-erp`）

| 半边 | 位置 | 说明 |
|---|---|---|
| 界面 | `%LOCALAPPDATA%\hermes\desktop-plugins\takealot-erp\plugin.js` | Hermes 桌面端侧边栏「Takealot 运营」，10 个模块；存盘即热重载 |
| 后端 | `%LOCALAPPDATA%\hermes\plugins\takealot-erp\dashboard\plugin_api.py` | 挂在 `/api/plugins/takealot-erp/`；需 `config.yaml` 的 `plugins.enabled` 含 `takealot-erp` |
| 技能 | `%LOCALAPPDATA%\hermes\skills\takealot-erp-operator\SKILL.md` | 让本机 Agent 会算这笔账、会调这些接口 |

## 数据来源（界面右上/左上角会标出来）

1. **官方 Seller API v1**（`marketplace-api.takealot.com`，`X-API-Key`）——订单、Offer、库存、
   余额、结算、退货、发货单。这是唯一需要 Key 的来源，**Key 只存服务端**（`state\stores.json`，
   接口一律只回打码值）。
2. **公开目录/评论接口**（`api.takealot.com`）——竞品报价与跟卖人数、评论时间线→销量推算。
   不需要 Key，但**需要机器能出网到 Takealot**（见下）。
3. **内置样例数据**——两种来源都不可用时兜底，界面会明确标注「样例数据」，不会假装真实。

## 出网要求（部署前必读）

Takealot 前端有 Cloudflare，**它按出口 IP/ASN 拦，和 Key、和请求量都无关**：本机直连时
`marketplace-api` 与 `api.takealot.com` 一律返回 403 挑战页，一天几十条和几万条一样被拦。
量小不需要静态 IP 中继，**只需要一个 Takealot 能接受的出口**：

- 客户现有的 VPN / 代理订阅（把它的本地混合端口填进来即可），或
- 一台能出网的机器跑抓取脚本、把文件投进投放目录（下条），或
- 海外小 VPS 既当出口又跑抓取。

配置方式二选一：

```powershell
# ① 进程环境变量（后端由 App 拉起，改完重启后端生效）
setx TAKEALOT_API_PROXY "http://<proxy-host>:8899"
# ② 或写进插件状态：state\stores.json 的 crawler.proxy
```

诊断顺序：`GET /crawler/status` 会返回 `transport`（proxy / direct / blocked）、`lastError`、
`hint`，界面顶栏也会显示「抓取通道未通」并给出中继提示。

## 抓取数据的投放目录（当机器不能直连时）

在能出网的机器上跑 `crawl_takealot_ingest.py`（本仓库 `scripts/`，仅标准库）：

```bash
python3 crawl_takealot_ingest.py PLID96730174 "https://www.takealot.com/..." --out ./ingest
scp ./ingest/*.json win:C:/Users/Fly/AppData/Local/hermes/plugins/takealot-erp/state/ingest/
```

后端每次 `/crawler/status`、`/crawler/pull` 都会扫 `state\ingest\*.json` 并入库，坏文件进
`state\ingest\failed\`。文件里带原始 `productDetails` + 逐页 `reviewPages`，解析口径与直连一致。

## 销量口径（与 OpenListing 唯一真相源一致）

`月销 = round(近 30 天新增评论数 ÷ 类目留评率)`，7 天用 `月销×7/30` 平滑，90/180 天同法换算。
留评率三档：电子/音频 4.5%、美妆/母婴/个护 2.5%、其余 2%（最保守）。近 30 天无新增评论时
月销就是 0（慢动销或新 listing），界面会提示改看 90/180 天窗口。跟卖人数取
`other_offers.conditions[].count` 最大值，为 0 即独家。

## 自检

```powershell
# 后端在跑、插件已挂载
Select-String -Path "$env:LOCALAPPDATA\hermes\logs\gui.log" -Pattern "Mounted plugin API routes"
# 端到端（会在临时 HERMES_HOME 起一个探针后端，不打扰正在用的 App）
powershell -File verify_plugin_backend.ps1 18777
# 引擎可以用（不启 HTTP）
& "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts\python.exe" -c "import sys; sys.path.insert(0,r'C:\Users\Fly\AppData\Local\hermes\plugins\takealot-erp\dashboard'); import plugin_api as e; print(e.calculate_order_profit({'sellingPrice':399,'category':'Audio & Headphones','cogsCost':110,'inboundFreight':25,'weightKg':0.18,'lengthCm':12,'widthCm':8,'heightCm':4,'warehouse':'JHB'})['netProfit'])"
```

## Key 使用规则（交付红线）

- 界面只显示打码 Key（如 `TKL••••4f21`），明文只在 `state\stores.json`（服务端）。
- 抓取侧（公开接口）**永不接触 Seller Key**，两类凭据不混用。
- Takealot 一个卖家只有一把有效 Key，**签发新 Key 会立即吊销旧 Key**；换 Key 只能走
  「多店铺设置」重新绑定并即时校验。
- 不要把 Key 贴进聊天、工单、日志或代码；要共享就重新签发。
