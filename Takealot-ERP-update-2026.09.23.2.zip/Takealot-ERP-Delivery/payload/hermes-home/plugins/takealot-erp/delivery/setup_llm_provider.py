#!/usr/bin/env python3
"""按套餐自动配置 Hermes 的模型通道（阿里百炼 Token Plan / Coding Plan / DashScope）。

设计要点：
  · **先用客户自己的 key 探 `/models`**，拿到的就是"这个套餐真实可用"的清单（不靠猜、不写过时模型）
  · 默认 **dry-run**：只打印将要执行的 `hermes config set` 命令；加 `--apply` 才真写
  · **绝不打印 key**（只显示掩码长度）；key 从环境变量 / <hermes home>/.env / --key-file 读取
  · 写配置一律走 `hermes config set`（官方推荐路径，不手改 config.yaml）

用法（在客户机，用 Hermes 自带的 venv python 跑）:
  python setup_llm_provider.py --preset token-plan-cn                 # 探测 + 打印命令（不写）
  python setup_llm_provider.py --preset token-plan-cn --apply         # 真的写进去
  python setup_llm_provider.py --preset token-plan-cn --apply --default-model qwen3.8-flash
  python setup_llm_provider.py --preset token-plan-cn --probe-only     # 只看清单
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# ── 套餐预设（base_url 与 key 变量，两两不同：贴错会报"无可用通道"，不是网络问题）──
PRESETS = {
    "token-plan-cn": ("阿里云百炼 Token Plan（中国，仅华北2）",
                      "https://token-plan.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
                      "ALIBABA_TOKEN_PLAN_CN_API_KEY"),
    "token-plan": ("阿里云百炼 Token Plan（国际）",
                   "https://token-plan.ap-southeast-1.maas.aliyuncs.com/compatible-mode/v1",
                   "ALIBABA_TOKEN_PLAN_API_KEY"),
    "coding-plan-cn": ("阿里云百炼 Coding Plan（中国）",
                       "https://coding.dashscope.aliyuncs.com/v1",
                       "ALIBABA_CODING_PLAN_CN_API_KEY"),
    "coding-plan": ("阿里云百炼 Coding Plan（国际）",
                    "https://coding-intl.dashscope.aliyuncs.com/v1",
                    "ALIBABA_CODING_PLAN_API_KEY"),
    "dashscope-cn": ("百炼国内站（按量付费）",
                     "https://dashscope.aliyuncs.com/compatible-mode/v1",
                     "DASHSCOPE_API_KEY"),
    "dashscope-intl": ("百炼国际站（按量付费）",
                       "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
                       "DASHSCOPE_API_KEY"),
}

# 探测失败时的兜底清单（来自阿里云官方文档，2026-09；以探测结果为准）
FALLBACK = ["qwen3.8-flash", "qwen3.7-max", "qwen3.7-plus", "qwen3.6-flash",
            "deepseek-v4.1-flash", "deepseek-v4-pro", "deepseek-v4-pro-0813",
            "deepseek-v4-flash-0731", "glm-5.3", "glm-5.2"]

# 非文本/推理的模型（ERP 用不上，从清单里剔除）
NON_TEXT = ("image", "audio", "tts", "asr", "realtime", "video", "wan2", "wanx", "happyhorse",
            "embed", "rerank", "ocr", "speech", "music", "i2v", "t2v", "r2v", "vl-", "-vl")


def hermes_home() -> str:
    v = os.environ.get("HERMES_HOME")
    if v and os.path.isdir(v):
        return v
    if os.name == "nt":
        p = os.path.join(os.environ.get("LOCALAPPDATA", ""), "hermes")
        if os.path.isdir(p):
            return p
    p = os.path.expanduser("~/.hermes")
    return p if os.path.isdir(p) else os.path.expanduser("~/.hermes")


def read_key(key_env: str, key_file: str | None) -> tuple[str, str]:
    """返回 (key, 来源说明)；任何情况下都不打印 key 本身。"""
    if key_file and os.path.exists(key_file):
        return open(key_file, encoding="utf-8").read().strip(), "文件 %s" % key_file
    v = (os.environ.get(key_env) or "").strip()
    if v:
        return v, "环境变量 %s" % key_env
    envp = os.path.join(hermes_home(), ".env")
    if os.path.exists(envp):
        for line in open(envp, encoding="utf-8", errors="replace"):
            t = line.strip()
            if t.startswith("#") or "=" not in t:
                continue
            k, _, val = t.partition("=")
            if k.strip() == key_env:
                return val.strip().strip('"').strip("'"), "%s 里的 %s" % (envp, key_env)
    return "", "未找到"


def probe(base_url: str, key: str, timeout: int = 25) -> tuple[list[str], str]:
    url = base_url.rstrip("/") + "/models"
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + key,
                                               "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        return [], "HTTP %d %s" % (e.code, (e.read()[:120].decode("utf-8", "replace") if hasattr(e, "read") else ""))
    except Exception as e:
        return [], "%s: %s" % (type(e).__name__, e)
    items = data.get("data") if isinstance(data, dict) else None
    ids = []
    if isinstance(items, list):
        for it in items:
            mid = it.get("id") if isinstance(it, dict) else (it if isinstance(it, str) else None)
            if mid:
                ids.append(str(mid))
    elif isinstance(data, dict) and isinstance(data.get("models"), list):
        ids = [str(m.get("id") if isinstance(m, dict) else m) for m in data["models"]]
    return ids, "OK (%d 条)" % len(ids)


def keep_text(ids: list[str]) -> list[str]:
    out = [i for i in ids if not any(bad in i.lower() for bad in NON_TEXT)]
    # 去重且保序
    seen, uniq = set(), []
    for i in out:
        if i not in seen:
            seen.add(i)
            uniq.append(i)
    return uniq


def hermes_cmd() -> list[str]:
    """找到 hermes CLI：PATH 上的 hermes → 否则用当前解释器跑 hermes_cli.main。"""
    from shutil import which
    exe = which("hermes")
    if exe:
        return [exe]
    return [sys.executable, "-m", "hermes_cli.main"]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", default="token-plan-cn", choices=sorted(PRESETS))
    ap.add_argument("--provider", default="qwen-tokenplan", help="自定义 provider 名（id 会是 custom:<名>）")
    ap.add_argument("--key-env", default="", help="key 变量名（默认取套餐预设）")
    ap.add_argument("--key-file", default="", help="从文件读 key（避免命令行留痕）")
    ap.add_argument("--base-url", default="", help="覆盖端点（默认取套餐预设）")
    ap.add_argument("--default-model", default="", help="设为默认的模型（默认取清单第一个）")
    ap.add_argument("--probe-only", action="store_true")
    ap.add_argument("--apply", action="store_true", help="真正写配置（默认只打印）")
    ap.add_argument("--no-probe", action="store_true", help="跳过探测，直接用官方兜底清单")
    args = ap.parse_args()

    label, base_url, key_env = PRESETS[args.preset]
    key_env = args.key_env or key_env
    base_url = args.base_url or base_url

    print("=" * 68)
    print("套餐: %s" % label)
    print("端点: %s" % base_url)
    print("key 变量: %s" % key_env)
    print("provider 名: %s  (Hermes 里的 id = custom:%s)" % (args.provider, args.provider))
    print("=" * 68)

    models: list[str] = []
    if args.no_probe:
        models, note = FALLBACK, "按官方文档清单（未探测）"
    else:
        key, src = read_key(key_env, args.key_file or None)
        if not key:
            print("! 没找到 key（%s）。" % src)
            print("  在客户机上：Hermes 界面 → 设置/提供方 里填好 key，或把 key 写进 %s"
                  % os.path.join(hermes_home(), ".env"))
            print("  也可以：--key-file <文件> 或先 export %s=..." % key_env)
            models, note = FALLBACK, "按官方文档清单（无 key，未探测）"
        else:
            print("key: 已从 %s 读到（长度 %d，不回显）" % (src, len(key)))
            ids, status = probe(base_url, key)
            if ids:
                models, note = keep_text(ids), "探测 /models 得到"
                print("探测结果: %s，其中文本/推理 %d 个：%s" % (status, len(models), ", ".join(models)))
            else:
                models, note = FALLBACK, "探测失败，回退官方文档清单"
                print("探测失败: %s" % status)
                print("  → 常见原因：key 与套餐档位不匹配（三档端点/变量各不相同）、区域不对、网络不通")
                print("  → 先按官方清单继续；模型调用若报'无可用通道'，说明该模型不在这个套餐里")

    print()
    print("模型清单（%s）: %s" % (note, ", ".join(models)))
    if args.probe_only:
        return 0

    default_model = args.default_model or (models[0] if models else "qwen3.7-plus")
    if default_model not in models:
        print("! 指定的默认模型 %s 不在清单里（仍会写入，但可能报错）" % default_model)

    cmds = [
        ["config", "set", "providers.%s.api" % args.provider, base_url],
        ["config", "set", "providers.%s.key_env" % args.provider, key_env],
        ["config", "set", "providers.%s.discover_models" % args.provider, "false"],
        ["config", "set", "providers.%s.models" % args.provider, json.dumps(models)],
        ["config", "set", "model.provider", "custom:%s" % args.provider],
        ["config", "set", "model.default", default_model],
    ]
    base = hermes_cmd()
    print()
    print("将要执行（默认 dry-run，加 --apply 才真写）:")
    for c in cmds:
        print("  %s" % " ".join("'%s'" % x if " " in x else x for x in (base + c)))

    if not args.apply:
        print()
        print("确认无误后重跑并加 --apply")
        return 0

    print()
    for c in cmds:
        rc = subprocess.call(base + c)
        print("  [%s] %s" % ("ok" if rc == 0 else "FAIL %d" % rc, " ".join(c[:3])))
        if rc != 0:
            print("! 中止：上面这条失败，配置未写完")
            return rc

    print()
    print("回读验证:")
    subprocess.call(base + ["config", "get", "model"])
    print()
    print("完成。若 ERP 正在运行：它的 AI 功能会自动跟随（下次调用即生效）。")
    print("建议再确认一次：hermes doctor  （连通性）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
