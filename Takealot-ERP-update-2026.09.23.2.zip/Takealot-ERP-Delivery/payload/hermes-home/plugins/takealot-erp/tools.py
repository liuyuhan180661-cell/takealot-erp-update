"""Takealot ERP — agent-side tool surface (12 tools) + deterministic Chinese intent router.

Two halves live here:

1. **The tool surface.** Every tool calls the SAME backend functions the desktop UI's REST
   endpoints call (``dashboard/plugin_api.py``, loaded by file location so ``STATE_DIR``
   resolves to this package no matter which door imported us). No HTTP, no session token,
   no duplicated business logic, no second copy of the money math.

2. **The intent router.** A Chinese verb/phrase table turns a natural-language sentence into
   ONE intent, and the ``pre_llm_call`` hook injects a hard directive naming the tool that
   must be called (or, for a write request, that the action is refused and the user is pointed
   at the UI). Every decision is appended to ``state/agent_intent_audit.jsonl`` together with
   the tool actually invoked, so the routing is auditable rather than plausible.

Read-only + crawl only. There is deliberately **no** write-to-platform tool: changing price or
stock, creating an offer, publishing a loadsheet — all of that stays in the UI where the
customer can see the confirmation and the audit trail. ``takealot_crawl_product``,
``takealot_market_search`` and ``takealot_route_verdict`` never write anything at all;
``takealot_collection_add`` writes the LOCAL collection box (``state/collection.json``), which is
the customer's own workspace, never Takealot.

------------------------------------------------------------------------------
REAL ROW KEYS — measured live on the delivery box against the real store, 2026-09-20.
Every handler below reads the key named in its comment; none of them guesses
(``rows or items or drafts`` is exactly the bug that ships a tool that "calls fine but
returns nothing").
------------------------------------------------------------------------------
  overview(storeId)        -> alerts[]/trend[]/recentOrders[]/buybox[]/feeBreakdown[]/stores[]
                              kpis{}, basis, mode, storeName. There is NO `rows` key.
  orders_live(storeId,q,status,limit) -> items[] (87 rows), total, count, summary, mode
  orders(status,q,storeId) -> items[] too, BUT the params are positional
                              (status, q, storeId): ``orders("store-2")`` passes the store as
                              `status` and returns 0 rows. Use orders_live; that trap is why.
  products(q,status,sort,content,stock,limit,offset,storeId)
                           -> items[] (page of `limit`), total, mapped, count, limit, offset,
                              hasMore, pages, stats, mode
  financial(q,storeId)     -> months[] (1 row), ledgerRows[] (11 rows), summary{},
                              balances{}, reconcile{}, statements[], anomalies[]
  fulfilment(storeId,limit,withStock)
                           -> stages{inbound:{summary,pos},outbound:{summary,pos}},
                              linkage{}, errors{}, partial{}, portal
  collection(storeId)      -> items[] (genuinely empty on a fresh store: empty:true is CORRECT),
                              stats, note, scopeNote
  listings_drafts(storeId) -> items[] SCOPED BY storeId; 5 real drafts on the box belong to
                              store-apex-direct, so storeId=store-2 correctly returns 0 — read
                              `filtered`/`unassignedIncluded` and re-probe unscoped before
                              reporting "empty" (see _handle_listings)
  diagnostics(storeId,perfHeavy) -> checks[], summary{total,passed,warned,failed}, stores[],
                              public{}, proxy, apiBase
  CRAWLER.pull(target)     -> product{}, windows{}, sales{}, rate, rateNote, transport, mode, cached
  CRAWLER.http_json(search url) -> sections.products.results[].product_views{core,buybox_summary,...}
  _route_verdict(product, crawl, target, storeId) -> route, exists, routeSource, routeReason, nextStep
"""

from __future__ import annotations

import importlib.util
import json
import re
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# ``tool_result``/``tool_error`` are the framework's JSON encoders. Imported defensively so this
# module can also be loaded standalone (probe / offline check) without the whole agent on path.
try:  # pragma: no cover - exercised on the box
    from tools.registry import tool_error, tool_result
except Exception:  # pragma: no cover - standalone probe path
    def tool_result(data: Any = None, **kwargs: Any) -> str:
        return json.dumps(data if data is not None else kwargs, ensure_ascii=False)

    def tool_error(message: Any, **extra: Any) -> str:
        return json.dumps({"error": str(message), **extra}, ensure_ascii=False)

__all__ = [
    "register_tools", "register_hooks", "TOOLS", "INTENT_RULES", "classify_intent",
    "build_directive", "backend", "AUDIT_PATH",
]

PACKAGE_DIR = Path(__file__).resolve().parent
DASHBOARD_DIR = PACKAGE_DIR / "dashboard"
API_PATH = DASHBOARD_DIR / "plugin_api.py"
STATE_DIR = PACKAGE_DIR / "state"
AUDIT_PATH = STATE_DIR / "agent_intent_audit.jsonl"

#: The dashboard mount loads the backend under this name; reusing it means one module instance
#: (one crawler, one warm thread, one offers cache) whether the agent or the UI asked first.
BACKEND_MODULE_NAME = "hermes_dashboard_plugin_takealot-erp"

DEFAULT_ROWS = 10
MAX_ROWS = 50
MAX_CHARS = 12000

TOOLSET = "takealot_erp"

# ---------------------------------------------------------------------------
# Backend loading
# ---------------------------------------------------------------------------

_BACKEND: Dict[str, Any] = {"mod": None, "error": None}
_BACKEND_LOCK = threading.Lock()


def backend() -> Tuple[Optional[Any], Optional[str]]:
    """Return ``(plugin_api_module, None)`` or ``(None, reason)``. Loaded once, lazily.

    Lazy on purpose: importing ``plugin_api`` spawns its catalogue-warm thread, which must not
    happen merely because the plugin package was discovered.
    """
    mod = _BACKEND["mod"]
    if mod is not None:
        return mod, None
    if _BACKEND["error"]:
        return None, _BACKEND["error"]
    with _BACKEND_LOCK:
        if _BACKEND["mod"] is not None:
            return _BACKEND["mod"], None
        existing = sys.modules.get(BACKEND_MODULE_NAME)
        if existing is not None and hasattr(existing, "overview"):
            _BACKEND["mod"] = existing
            return existing, None
        try:
            if not API_PATH.is_file():
                raise FileNotFoundError("dashboard/plugin_api.py not found at {0}".format(API_PATH))
            spec = importlib.util.spec_from_file_location(BACKEND_MODULE_NAME, str(API_PATH))
            if spec is None or spec.loader is None:
                raise ImportError("could not build an import spec for {0}".format(API_PATH))
            module = importlib.util.module_from_spec(spec)
            sys.modules[BACKEND_MODULE_NAME] = module
            spec.loader.exec_module(module)
            _BACKEND["mod"] = module
            return module, None
        except Exception as exc:  # pragma: no cover - reported to the model verbatim
            _BACKEND["error"] = "backend import failed: {0}: {1}".format(type(exc).__name__, exc)
            return None, _BACKEND["error"]


def crawler() -> Tuple[Optional[Any], Optional[str]]:
    """The public-API crawler module (``dashboard/crawler.py``), as the backend holds it."""
    mod, err = backend()
    if mod is None:
        return None, err
    c = getattr(mod, "CRAWLER", None)
    if c is None:
        return None, "crawler module unavailable: {0}".format(getattr(mod, "CRAWLER_ERROR", "unknown"))
    return c, None


# ---------------------------------------------------------------------------
# Small helpers shared by the handlers
# ---------------------------------------------------------------------------


def _int(value: Any, default: int, low: int, high: int) -> int:
    try:
        out = int(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, out))


def _flag(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        cleaned = value.strip().lower()
        if cleaned in ("1", "true", "yes", "on", "是"):
            return True
        if cleaned in ("0", "false", "no", "off", "否"):
            return False
    return default


def _blank(value: Any) -> str:
    return str(value if value is not None else "").strip()


def _project(row: Any, fields: Tuple[str, ...]) -> Dict[str, Any]:
    """Fixed-field projection of one backend row (never ``**row`` — 30-field rows twice over
    would blow the context budget, and this is the difference between a usable summary and a
    187 KB response)."""
    if not isinstance(row, dict):
        return {"value": row}
    out: Dict[str, Any] = {}
    for key in fields:
        value = row.get(key)
        if isinstance(value, str) and len(value) > 160:
            value = value[:160] + "…"
        if value not in (None, "", [], {}):
            out[key] = value
    return out


def _trim(text: Any, limit: int = 240) -> str:
    value = _blank(text)
    return value if len(value) <= limit else value[:limit] + "…"


#: 后端每行自带的库存块（`stock`，实测键位：regions[]/sellerAvailable/dcAvailable/totalAvailable/
#: totalReceiving/totalOnWay/totalSold30/totalCoverDays/warehouseCount/regionCount）。
#: 原样回传每行约 450 字符，20 行就能把摘要顶到 13 KB —— 只留总量与一行式分仓。
_STOCK_KEYS = ("sellerAvailable", "dcAvailable", "totalAvailable", "totalReceiving", "totalOnWay",
               "totalSold30", "totalCoverDays", "warehouseCount", "regionCount")


def _stock_brief(stock: Any) -> Any:
    if not isinstance(stock, dict):
        return stock
    brief: Dict[str, Any] = {k: stock[k] for k in _STOCK_KEYS if k in stock}
    regions = stock.get("regions")
    if isinstance(regions, list) and regions:
        brief["regions"] = [
            "{0}{1}:{2}".format(r.get("warehouse") or "?",
                                ("-" + str(r.get("region"))) if r.get("region") else "",
                                r.get("available"))
            for r in regions if isinstance(r, dict)
        ][:12]
    return brief or stock


#: 行内「本店自建 vs 跟卖」推断块（`origin`，实测键位：code/label/likely/confidence/exclusive/
#: buyboxHeld/offerCount/competitorCount/competitors[]/signals[]/reason(长)/source/note）。
#: 原样回传 470–660 字符/行，是摘要超预算的主因；只留判据与结论，reason 截到 160 字。
def _origin_brief(origin: Any) -> Any:
    if not isinstance(origin, dict):
        return origin
    brief: Dict[str, Any] = {k: origin.get(k) for k in
                             ("code", "label", "likely", "confidence", "exclusive", "buyboxHeld",
                              "offerCount", "competitorCount", "cardCached", "source")
                             if origin.get(k) not in (None, "")}
    signals = origin.get("signals")
    if isinstance(signals, list) and signals:
        brief["signals"] = [s.get("source") for s in signals if isinstance(s, dict)][:5]
    competitors = origin.get("competitors")
    if isinstance(competitors, list):
        brief["competitorRows"] = len(competitors)
    reason = _blank(origin.get("reason"))
    if reason:
        brief["reason"] = _trim(reason, 160)
    return brief or origin


def _clip(payload: Dict[str, Any]) -> str:
    """Encode; on overflow drop the bulkiest blocks but NEVER the scalar header.

    Measured need: ``products`` with a 20-row page + the store-wide ``stats`` block blew past
    the budget, and the naive "head/tail" truncation lost ``total`` — i.e. the summary could no
    longer say how many products the store has, which is exactly the number the tool exists for.
    So: keep every scalar/indicator key, drop ``rows`` first, then the largest remaining
    blocks, and name what was dropped.
    """
    blob = json.dumps(payload, ensure_ascii=False, default=str)
    if len(blob) <= MAX_CHARS:
        return blob
    protect = ("ok", "mode", "empty", "storeId", "storeName", "total", "mapped", "count", "limit",
               "offset", "hasMore", "pages", "returned", "basis", "hint", "note", "why_empty",
               "transport", "blocked", "error", "errors", "source", "ladder", "wroteAnything",
               "query", "numFoundText", "totalNumFound", "rateSource", "rateNote", "route",
               "routeSource", "evidenceTier", "rule", "intent")
    slim = dict(payload)
    omitted: List[str] = []
    # 1) rows 不是一刀切丢掉：先按预算留尽可能多行（至少 3 行），并说明留了几行。
    rows = slim.get("rows")
    if isinstance(rows, list) and rows:
        header = json.dumps({k: v for k, v in slim.items() if k != "rows"}, ensure_ascii=False,
                            default=str)
        budget = MAX_CHARS - len(header) - 500
        keep: List[Any] = []
        used = 0
        for row in rows:
            size = len(json.dumps(row, ensure_ascii=False, default=str)) + 1
            if used + size > budget and len(keep) >= 3:
                break
            keep.append(row)
            used += size
        if len(keep) < len(rows):
            omitted.append("rows[{0}/{1}]".format(len(keep), len(rows)))
            slim["rows"] = keep
    # 2) 还超预算就按体积砍块，但永不砍标量指标键。
    for key in sorted((k for k in list(slim) if k not in protect and k != "rows"),
                      key=lambda k: -len(json.dumps(slim.get(k), ensure_ascii=False, default=str))):
        if len(json.dumps(slim, ensure_ascii=False, default=str)) <= MAX_CHARS - 400:
            break
        slim.pop(key, None)
        omitted.append(key)
    slim["rowsNote"] = ("摘要过大：为保住 total/口径等指标，已省略 {0}；"
                        "要看得更细请用 limit/offset 收窄，或到桌面界面看完整列表。").format(
        "、".join(omitted) or "部分字段")
    return json.dumps(slim, ensure_ascii=False, default=str)


def _err(message: Any, **extra: Any) -> str:
    return tool_error(message, **extra)


def _store_arg(args: Dict[str, Any]) -> str:
    """``storeId`` as given; empty string means "the active store" (the backend resolves it)."""
    return _blank(args.get("storeId"))


def _reason(payload: Any, *keys: str) -> str:
    """First non-empty human reason found in a backend payload."""
    if not isinstance(payload, dict):
        return ""
    for key in keys:
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return _trim(value)
        if isinstance(value, dict):
            inner = "; ".join("{0}: {1}".format(k, _trim(v, 80)) for k, v in value.items() if v)
            if inner:
                return _trim(inner)
    return ""


# ---------------------------------------------------------------------------
# Prose in the tool descriptions (these ARE the contract; the router relies on them too)
# ---------------------------------------------------------------------------

_READ_NOTE = "只读：直接调用后端函数，不产生任何平台写请求。"
_CRAWL_NOTE = "只读抓取：走公开 API（proxy→direct→blocked 通道梯），绝不用 Seller Key、绝不写平台。"
_WRITE_REFUSAL = ("没有写平台的工具（改价/改库存/发 Offer/上架 一律不暴露给 agent）。"
                  "请把用户引到桌面界面操作。")


# ===========================================================================
# TOOLS — 1..8 read-only
# ===========================================================================


def _handle_overview(args: Dict[str, Any], **kw: Any) -> str:
    """经营总览。真机键位：kpis/alerts/trend/recentOrders/buybox/feeBreakdown（无 rows）。"""
    api, err = backend()
    if api is None:
        return _err(err, tool="takealot_erp_overview")
    store_id = _store_arg(args)
    limit = _int(args.get("rows"), 5, 1, MAX_ROWS)
    try:
        data = api.overview(store_id)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_erp_overview")
    if not isinstance(data, dict):
        return _err("overview returned {0}".format(type(data).__name__), tool="takealot_erp_overview")

    alerts = data.get("alerts") or []
    orders = data.get("recentOrders") or []          # verified key
    buybox = data.get("buybox") or []
    summary = {
        "ok": bool(data.get("ok")),
        "mode": data.get("mode"),
        "empty": data.get("empty"),
        "storeId": data.get("storeId"),
        "storeName": data.get("storeName"),
        "kpis": data.get("kpis") or {},
        "alerts": {
            "total": len(alerts),
            "rows": [_project(a, ("level", "title", "detail")) for a in alerts[:limit]],
        },
        "trend": (data.get("trend") or [])[-7:],
        "recentOrders": {
            "total": len(orders),
            "rows": [_project(r, ("orderId", "sku", "tsin", "title", "quantity", "sellingPrice",
                                  "platformDeductions", "netProfit", "status", "saleStatus",
                                  "orderDate", "isLoss")) for r in orders[:limit]],
        },
        "buybox": {
            "total": len(buybox),
            "rows": [_project(b, ("sku", "tsin", "title", "myPrice", "competitorPrice",
                                  "competitorSeller", "hasBuybox", "buyboxKnown", "gap",
                                  "action", "priceSource", "lastChecked")) for b in buybox[:limit]],
        },
        "feeBreakdown": data.get("feeBreakdown") or [],
        "source": data.get("source"),
        "basis": _trim(data.get("basis")),
        "errors": data.get("errors"),
        "hint": _trim(data.get("hint")),
    }
    if not data.get("kpis"):
        summary["why_empty"] = _reason(data, "error", "hint", "requires") or \
            "后端返回空 kpis；先看 diagnostics 确认 Seller Key 与出口代理。"
    return _clip(summary)


def _handle_orders(args: Dict[str, Any], **kw: Any) -> str:
    """订单与净利。

    用 ``orders_live(storeId, q, status, limit)`` —— 实测返回 ``items[]`` 87 行 / total 87。
    ``orders(status, q, storeId)`` 参数是位置式的：``orders("store-2")`` 会把店号当 status 传进去
    并返回 0 行（交付前的排查坑），所以这里走 orders_live。
    """
    api, err = backend()
    if api is None:
        return _err(err, tool="takealot_erp_orders")
    store_id = _store_arg(args)
    limit = _int(args.get("limit"), 20, 1, MAX_ROWS * 4)
    try:
        data = api.orders_live(store_id, _blank(args.get("q")), _blank(args.get("status")), 500)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_erp_orders")
    if not isinstance(data, dict):
        return _err("orders_live returned {0}".format(type(data).__name__), tool="takealot_erp_orders")
    items = data.get("items") or []                  # verified key
    summary = {
        "ok": bool(data.get("ok")),
        "mode": data.get("mode"),
        "empty": not items,
        "storeId": data.get("storeId"),
        "storeName": data.get("storeName"),
        "total": data.get("total"),
        "count": data.get("count"),
        "returned": min(len(items), limit),
        "summary": data.get("summary") or {},
        "source": data.get("source") or "/sales",
        "rows": [_project(r, ("orderId", "orderItemId", "sku", "tsin", "title", "quantity",
                              "sellingPrice", "platformFees", "expectedSuccessFee", "net",
                              "saleStatus", "orderDate", "salesRegion", "stockSourceRegion"))
                 for r in items[:limit]],
        "hint": _trim(data.get("hint")),
    }
    if not items:
        summary["why_empty"] = (_reason(data, "error") or
                                "本店 /sales 当次返回 0 行（真实接口结果）——不是参数错误："
                                "orders_live 已成功调用，total={0}。".format(data.get("total")))
    return _clip(summary)


def _handle_products(args: Dict[str, Any], **kw: Any) -> str:
    """商品管理。实测：必须显式传 limit/offset，行在 ``items[]``；total/mapped/hasMore 同回。"""
    api, err = backend()
    if api is None:
        return _err(err, tool="takealot_erp_products")
    store_id = _store_arg(args)
    limit = _int(args.get("limit") or args.get("rows"), 20, 1, 200)
    offset = _int(args.get("offset"), 0, 0, 100000)
    try:
        data = api.products(_blank(args.get("q")), _blank(args.get("status")),
                            _blank(args.get("sort")), _blank(args.get("content")),
                            _blank(args.get("stock")), limit, offset, store_id)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_erp_products")
    if not isinstance(data, dict):
        return _err("products returned {0}".format(type(data).__name__), tool="takealot_erp_products")
    items = data.get("items") or []                  # verified key
    total = data.get("total")
    stats_raw = data.get("stats") or {}
    # 真店 stats 有 20+ 个键（含 byStatus/byOrigin/byOriginSignal 三张子表），全塞进来会顶爆摘要预算，
    # 只留做决策用得上的指标（实测键位：total/sellable/inStock/zeroStock/availableUnits/sold30…）。
    stats = {k: stats_raw.get(k) for k in
             ("total", "sellable", "notSellable", "disabled", "zeroStock", "inStock",
              "availableUnits", "sold30", "missingImage", "missingBarcode", "missingCategory",
              "missingText", "enriched", "byStatus") if k in stats_raw}
    summary = {
        "ok": bool(data.get("ok")),
        "mode": data.get("mode"),
        "empty": not items,
        "storeId": data.get("storeId"),
        "storeName": data.get("storeName"),
        "total": total,
        "mapped": data.get("mapped"),
        "count": data.get("count"),
        "limit": data.get("limit"),
        "offset": data.get("offset"),
        "hasMore": data.get("hasMore"),
        "pages": data.get("pages"),
        "returned": len(items),
        "stats": stats,
        "rows": [_project(r, ("sku", "tsin", "plid", "barcode", "title", "price", "rrp",
                              "status", "statusLabel", "sellable", "listingQuality",
                              "origin", "leadtimeDays", "imageUrl")) for r in items[:limit]],
    }
    for row_out, row_raw in zip(summary["rows"], items[:limit]):
        row_out["stock"] = _stock_brief(row_raw.get("stock"))
        if "origin" in row_out:
            row_out["origin"] = _origin_brief(row_raw.get("origin"))
    if not items:
        summary["why_empty"] = (
            "offset={0} 超出 total={1}（参数问题），把 offset 调小。".format(offset, total)
            if isinstance(total, int) and total and offset >= total else
            (_reason(data, "error", "note") or "本店目录当前为空（真实结果，不是参数错）。"))
    return _clip(summary)


def _handle_finance(args: Dict[str, Any], **kw: Any) -> str:
    """财务与对账。实用行键：``months[]`` / ``ledgerRows[]``（**不是 rows**）+ summary/balances。"""
    api, err = backend()
    if api is None:
        return _err(err, tool="takealot_erp_finance")
    store_id = _store_arg(args)
    limit = _int(args.get("limit") or args.get("rows"), 10, 1, MAX_ROWS)
    try:
        data = api.financial(_blank(args.get("q")), store_id)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_erp_finance")
    if not isinstance(data, dict):
        return _err("financial returned {0}".format(type(data).__name__), tool="takealot_erp_finance")
    months = data.get("months") or []                # verified key
    ledger = data.get("ledgerRows") or []            # verified key
    reconcile = data.get("reconcile") or {}
    summary = {
        "ok": bool(data.get("ok")),
        "mode": data.get("mode"),
        "empty": data.get("empty"),
        "storeId": data.get("storeId"),
        "storeName": data.get("storeName"),
        "summary": data.get("summary") or {},
        "balances": data.get("balances") or {},
        "months": {"total": len(months), "rows": months[:limit]},
        "ledgerRows": {
            "total": len(ledger),
            "rows": [_project(r, ("transaction_id", "transaction_type", "amount_incl_vat",
                                  "created_at")) for r in ledger[:limit]],
        },
        "reconcile": {
            "available": reconcile.get("available"),
            "totalOverchargedZAR": reconcile.get("totalOverchargedZAR"),
            "note": _trim(reconcile.get("note")),
        },
        "anomalies": (data.get("anomalies") or [])[:limit],
        "varianceRows": (data.get("varianceRows") or [])[:limit],
        "basis": _trim(data.get("basis")),
        "hint": _trim(data.get("hint")),
        "errors": data.get("errors"),
    }
    if not months and not ledger:
        summary["why_empty"] = (_reason(data, "error", "hint") or
                                "本店 /balances + /transactions 当次无数据（真实结果）。")
    return _clip(summary)


def _handle_fulfilment(args: Dict[str, Any], **kw: Any) -> str:
    """履约闭环。实测：**没有列表行**，数据在 ``stages.inbound/outbound.{summary,pos}`` + linkage。"""
    api, err = backend()
    if api is None:
        return _err(err, tool="takealot_erp_fulfilment")
    store_id = _store_arg(args)
    limit = _int(args.get("limit") or args.get("rows"), 5, 1, MAX_ROWS)
    with_stock = _flag(args.get("withStock"), False)
    try:
        data = api.fulfilment(store_id, 200, with_stock)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_erp_fulfilment")
    if not isinstance(data, dict):
        return _err("fulfilment returned {0}".format(type(data).__name__), tool="takealot_erp_fulfilment")
    stages = data.get("stages") or {}
    inbound = (stages.get("inbound") or {})
    outbound = (stages.get("outbound") or {})

    def _stage(block: Dict[str, Any]) -> Dict[str, Any]:
        pos = block.get("pos") or []
        return {
            "summary": block.get("summary") or {},
            "outstanding": sum(1 for p in pos if isinstance(p, dict) and p.get("dueDate")),
            "total": len(pos),
            "rows": [_project(p, ("shipmentId", "po", "reference", "typeLabel", "stateLabel",
                                  "region", "dueDate", "daysToDue", "actionable", "branch"))
                     for p in pos[:limit]],
        }

    summary = {
        "ok": bool(data.get("ok")),
        "mode": data.get("mode"),
        "storeId": data.get("storeId"),
        "storeName": data.get("storeName"),
        "stageKeys": sorted(stages.keys()),
        "inbound": _stage(inbound),
        "outbound": _stage(outbound),
        "partial": data.get("partial") or {},
        "linkage": {
            "basis": (data.get("linkage") or {}).get("basis"),
            "matchedKeys": (data.get("linkage") or {}).get("matchedKeys"),
            "unmatchedKeys": (data.get("linkage") or {}).get("unmatchedKeys"),
            "matched": ((data.get("linkage") or {}).get("matched") or [])[:limit],
        },
        "portal": data.get("portal"),
        "errors": data.get("errors"),
        "hint": _trim(data.get("hint")),
        "rowsNote": "履约没有平铺行列表：行在 stages.inbound/outbound.pos（键位已实测）。",
    }
    if not stages:
        summary["why_empty"] = _reason(data, "error", "hint") or "无送仓单/出库批次（真实结果）。"
    if (data.get("partial") or {}).get("stockSkipped"):
        summary["stockNote"] = ("库存未计算（partial.stockSkipped）：本店商品缓存冷、拉全量 /offers 约 30 秒。"
                                "需要库存就传 withStock=true 再调一次。")
    return _clip(summary)


def _handle_collection(args: Dict[str, Any], **kw: Any) -> str:
    """采集箱。实测：行在 ``items[]``；真店当前为空 → empty:true 是**正确**结果，不是失败。"""
    api, err = backend()
    if api is None:
        return _err(err, tool="takealot_erp_collection")
    store_id = _store_arg(args)
    limit = _int(args.get("limit") or args.get("rows"), 20, 1, MAX_ROWS * 4)
    try:
        data = api.collection(store_id)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_erp_collection")
    if not isinstance(data, dict):
        return _err("collection returned {0}".format(type(data).__name__), tool="takealot_erp_collection")
    items = data.get("items") or []                  # verified key
    unassigned_included = int(data.get("unassignedIncluded") or 0)
    unassigned_rows = [r for r in items if not (r.get("assignedStoreId") or r.get("storeId"))]
    summary = {
        "ok": bool(data.get("ok")),
        "mode": data.get("mode"),
        "empty": not items,
        "storeId": data.get("storeId"),
        "storeName": data.get("storeName"),
        "total": len(items),
        # 采集箱是全店共用的一个池子；未分派只是这行还没打店铺标签，不等于不在箱里。
        # 报数必须分开讲，否则「某个店铺作用域里为空」会被讲成「采集箱是空的」。
        "unassignedIncluded": unassigned_included,
        "unassignedRows": [_project(r, ("id", "title", "tsin", "barcode"))
                           for r in unassigned_rows[:limit]],
        "stats": data.get("stats") or {},
        "note": _trim(data.get("note")),
        "scopeNote": _trim(data.get("scopeNote")),
        "conflicts": (data.get("conflicts") or [])[:limit],
        "rows": [_project(r, ("id", "title", "tsin", "barcode", "category", "price", "cost",
                              "estSalePrice", "storeId", "status", "missing", "sourceUrl"))
                 for r in items[:limit]],
    }
    if unassigned_included:
        summary["unassignedNote"] = (
            "其中 {0} 行未分派店铺：采集箱全店共用，未分派 ≠ 不属于你。跟价 / 上架前先分派到店铺"
            "（界面采集箱里可勾选后批量分派），或告诉我店名我就带 storeId 重写一次。".format(unassigned_included))
    if not items:
        summary["why_empty"] = ("采集箱为空是本地真实状态（不是参数错、不是后端故障）："
                                "行只会由「采集」/takealot_collection_add 写入。"
                                "（本店行与未分派行都为空才报空——未分派行现在也会显示。）"
                                + (" 后端说明：" + _trim(data.get("note")) if data.get("note") else ""))
    return _clip(summary)


def _handle_listings(args: Dict[str, Any], **kw: Any) -> str:
    """上架草稿。

    实测坑：``listings_drafts(storeId)`` **按店过滤**，真店 state/drafts.json 里 5 条草稿全部属于
    ``store-apex-direct``；用 ``storeId=store-2`` 直调会得到 empty:true —— 那不是"没有草稿"，是
    "这家店没有"。所以这里：先在请求的店范围内读，如果为空再读一次全量（storeId=''），
    把归属说清楚，绝不让"筛选空了"读成"没有草稿"。
    """
    api, err = backend()
    if api is None:
        return _err(err, tool="takealot_erp_listings")
    store_id = _store_arg(args)
    limit = _int(args.get("limit") or args.get("rows"), 20, 1, MAX_ROWS * 4)
    try:
        scoped = api.listings_drafts(store_id)
        overall = scoped if not store_id else api.listings_drafts("")
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_erp_listings")
    if not isinstance(scoped, dict):
        return _err("listings_drafts returned {0}".format(type(scoped).__name__),
                    tool="takealot_erp_listings")
    items = scoped.get("items") or []                # verified key (SCORED by storeId)
    other = overall.get("items") or [] if isinstance(overall, dict) else []
    owners: Dict[str, int] = {}
    for row in (other or []):
        if isinstance(row, dict):
            key = _blank(row.get("storeId")) or "(未标注)"
            owners[key] = owners.get(key, 0) + 1

    summary = {
        "ok": True,
        "mode": scoped.get("mode"),
        "empty": not items,
        "storeId": scoped.get("storeId"),
        "storeName": scoped.get("storeName"),
        "filtered": scoped.get("filtered"),
        "unassignedIncluded": scoped.get("unassignedIncluded"),
        "total": len(items),
        "summary": scoped.get("summary") or {},
        "note": _trim(scoped.get("note")),
        "rows": [_project(r, ("id", "title", "tsin", "sku", "storeId", "storeName", "status",
                              "price", "qty", "brand", "mainCategory", "updatedAt"), )
                 for r in items[:limit]],
    }
    # readiness is nested; surface it without dumping the whole draft
    ready_rows = []
    for r in items[:limit]:
        if isinstance(r, dict):
            ready = r.get("readiness") or {}
            ready_rows.append({"id": r.get("id"), "ok": ready.get("ok"),
                               "blockers": (ready.get("blockers") or ready.get("missing") or [])[:6]})
    summary["readiness"] = ready_rows
    if not items:
        if other:
            summary["why_empty"] = ("当前店铺范围内 0 条草稿 —— 这是筛选结果，不是「没有草稿」："
                                    "全量 {0} 条，归属 {1}。要看这些草稿，传 storeId='' 或对应的 storeId。"
                                    ).format(len(other), json.dumps(owners, ensure_ascii=False))
        else:
            summary["why_empty"] = (_trim(scoped.get("note")) or
                                    "草稿箱确实为空（本地真实状态；草稿只会由采集箱转草稿或界面新建）。")
    return _clip(summary)


def _handle_selfcheck(args: Dict[str, Any], **kw: Any) -> str:
    """环境自检。实测键位：``checks[]`` / ``summary{total,passed,warned,failed}`` / public / stores。"""
    api, err = backend()
    if api is None:
        return _err(err, tool="takealot_erp_selfcheck")
    store_id = _store_arg(args)
    heavy = _flag(args.get("heavy"), False)
    try:
        data = api.diagnostics(store_id, heavy)
        crawl, crawl_err = crawler()
        crawl_status = crawl.status_payload(False) if crawl is not None else {"error": crawl_err}
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_erp_selfcheck")
    if not isinstance(data, dict):
        return _err("diagnostics returned {0}".format(type(data).__name__), tool="takealot_erp_selfcheck")
    checks = data.get("checks") or []                # verified key
    problems = [c for c in checks if isinstance(c, dict) and not c.get("ok")]
    summary = {
        "ok": bool(data.get("ok")),
        "storeId": data.get("storeId"),
        "version": data.get("version"),
        "apiBase": data.get("apiBase"),
        "proxy": data.get("proxy"),
        "summary": data.get("summary") or {},
        "checks": {"total": len(checks),
                   "rows": [_project(c, ("id", "label", "ok", "level", "detail", "hint"))
                            for c in checks[:MAX_ROWS]]},
        "problems": [_project(c, ("id", "label", "level", "detail", "hint")) for c in problems[:10]],
        "stores": data.get("stores") or [],
        "public": data.get("public") or {},
        "crawler": {
            "transport": (crawl_status or {}).get("transport"),
            "proxyConfigured": (crawl_status or {}).get("proxyConfigured"),
            "cacheEntries": (crawl_status or {}).get("cacheEntries"),
            "lastError": _trim((crawl_status or {}).get("lastError")),
            "ingestDir": (crawl_status or {}).get("ingestDir"),
            "error": (crawl_status or {}).get("error"),
        },
        "hint": "selfcheck 的 ok:true 表示后端与取数通道可用；warn/fail 项看 problems[]。",
    }
    return _clip(summary)


# ===========================================================================
# TOOLS — 9..12 crawl / route (read-only, idempotent, never write the platform)
# ===========================================================================

_PRODUCT_FIELDS = ("plid", "tsin", "title", "subtitle", "brand", "price", "prettyPrice",
                   "pretty_price", "rating", "reviews", "reviewCount", "sellerCount",
                   "isExclusive", "lowestCompetitorPrice", "competitorCount", "competitorGap",
                   "categoryPath", "categoryL1", "categoryL2", "categoryL3", "department",
                   "imageUrl", "url", "offerCount", "stock")
_SALES_FIELDS = ("sales_7d", "sales_30d", "sales_90d", "sales_180d", "estimated_monthly_sales",
                 "estimated_daily_sales", "estimated_monthly_revenue")
_WINDOW_FIELDS = ("total", "reviews_7d", "reviews_30d", "reviews_90d", "reviews_180d",
                  "pagesFetched", "truncated")

_BLOCKED_LADDER = ("公开 API 通道梯：proxy（出口代理）→ direct（直连）→ blocked（被 Cloudflare 挡）。"
                   "blocked 不是「没有这个商品」，是这台机器出不去；不要编造抓取结果，"
                   "如实报告 transport 与原因为准。")


def _crawl_digest(payload: Dict[str, Any], limit: int) -> Dict[str, Any]:
    product = payload.get("product") or {}
    out: Dict[str, Any] = {
        "ok": bool(payload.get("ok")),
        "mode": payload.get("mode"),
        "transport": payload.get("transport"),
        "cached": payload.get("cached"),
        "plid": payload.get("plid"),
        "target": payload.get("target"),
        "fetchedAt": payload.get("fetchedAt"),
    }
    if isinstance(product, dict) and product:
        out["product"] = _project(product, _PRODUCT_FIELDS)
        if "stock" in out["product"]:
            out["product"]["stock"] = _stock_brief(product.get("stock"))
        offers = product.get("topOffers") or product.get("offers") or []
        if isinstance(offers, list):
            out["offers"] = {
                "total": len(offers),
                "rows": [_project(o, ("price", "pretty_price", "seller", "is_takealot",
                                      "condition")) for o in offers[:limit] if isinstance(o, dict)],
            }
    sales = payload.get("sales") or {}
    if isinstance(sales, dict) and sales:
        out["sales"] = {k: sales.get(k) for k in _SALES_FIELDS if k in sales}
        out["sales"]["review_rate"] = sales.get("review_rate")
        out["sales"]["rateSource"] = sales.get("rateSource")
        out["sales"]["rateNote"] = _trim(sales.get("rateNote"))
    windows = payload.get("windows") or {}
    if isinstance(windows, dict) and windows:
        out["windows"] = {k: windows.get(k) for k in _WINDOW_FIELDS if k in windows}
    if payload.get("rate") is not None:
        out["rate"] = payload.get("rate")
        out["rateSource"] = payload.get("rateSource")
        out["rateNote"] = _trim(payload.get("rateNote"))
    out["hint"] = _trim(payload.get("hint"))
    if str(payload.get("transport") or "") == "blocked" or payload.get("error"):
        out["blocked"] = True
        out["error"] = _trim(payload.get("error"))
        out["ladder"] = _BLOCKED_LADDER
    return out


def _handle_crawl_product(args: Dict[str, Any], **kw: Any) -> str:
    """单个商品抓取（链接 / PLID / TSIN）+ 跟卖-or-建档判定。只读、幂等、不落库。"""
    crawl, err = crawler()
    if crawl is None:
        return _err(err, tool="takealot_crawl_product")
    api, api_err = backend()
    target = _blank(args.get("target") or args.get("url") or args.get("tsin"))
    if not target:
        return _err("target 必填：传商品链接、PLID12345678 或 TSIN12345678", tool="takealot_crawl_product")
    limit = _int(args.get("limit") or args.get("rows"), 8, 1, 30)
    force = _flag(args.get("force"), False)
    try:
        payload = crawl.pull(target, force=force, cached_only=False)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_crawl_product")
    if not isinstance(payload, dict):
        return _err("crawler.pull returned {0}".format(type(payload).__name__),
                    tool="takealot_crawl_product")
    digest = _crawl_digest(payload, limit)
    digest["wroteAnything"] = False
    digest["note"] = ("抓取只读且幂等，不写平台、也不自动进采集箱"
                      "（要入库请另调 takealot_collection_add）。")
    if api is not None and _flag(args.get("withRoute"), True):
        product = payload.get("product")
        if isinstance(product, dict) and product:
            try:
                digest["route"] = api._route_verdict(product, payload, target, _store_arg(args))
            except Exception as exc:
                digest["routeError"] = "{0}: {1}".format(type(exc).__name__, exc)
    return _clip(digest)


def _handle_market_search(args: Dict[str, Any], **kw: Any) -> str:
    """关键词搜市场行情（公开搜索接口，不落库、不写 state）。"""
    crawl, err = crawler()
    if crawl is None:
        return _err(err, tool="takealot_market_search")
    query = _blank(args.get("query") or args.get("q"))
    if not query:
        return _err("query 必填（关键词，例如 usb charger）。没有关键词就先问用户，不要编造。",
                    tool="takealot_market_search")
    limit = _int(args.get("limit") or args.get("rows"), 10, 1, 36)
    url = ("https://api.takealot.com/rest/v-1-12-0/searches/products?qsearch={0}"
           "&rows=36&context=search&sort=Relevance").format(_quote(query))
    try:
        data, error, transport = crawl.http_json(url, 15.0)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_market_search")
    section = (((data or {}).get("sections") or {}).get("products") or {}) if isinstance(data, dict) else {}
    results = section.get("results") or []
    out: Dict[str, Any] = {
        "ok": bool(results),
        "query": query,
        "transport": transport,
        "endpoint": "/searches/products?qsearch=…&context=search&sort=Relevance",
        "wroteAnything": False,
        "note": "市场行情只在内存里算，不落库、不写 state，也不会动采集箱。",
    }
    if not results:
        out["blocked"] = transport == "blocked" or bool(error)
        out["error"] = _trim(error)
        out["ladder"] = _BLOCKED_LADDER
        out["why_empty"] = ("公开搜索接口没返回结果：要么通道被挡（transport/error 见上），"
                            "要么关键词确实 0 命中 —— 不要编造行情数据。")
        return _clip(out)
    paging = section.get("paging") or {}
    out["numFoundText"] = paging.get("num_found_text")
    out["totalNumFound"] = paging.get("total_num_found")
    out["isApproximate"] = paging.get("is_approximate")
    out["returned"] = min(len(results), limit)
    rows: List[Dict[str, Any]] = []
    for entry in results[:limit]:
        pv = (entry or {}).get("product_views") or {}
        core = pv.get("core") or {}
        bb = pv.get("buybox_summary") or {}
        rs = pv.get("review_summary") or {}
        rows.append({
            "plid": core.get("id"),
            "title": _trim(core.get("title"), 120),
            "brand": core.get("brand"),
            "price": bb.get("pretty_price") or bb.get("app_pretty_price"),
            "prices": bb.get("prices"),
            "saving": bb.get("saving"),
            "rating": core.get("star_rating"),
            "reviews": core.get("reviews") or rs.get("review_count"),
            "tsin": bb.get("tsin"),
            "productId": bb.get("product_id"),
        })
    out["rows"] = rows
    out["basis"] = ("公开搜索接口返回（results[].product_views）逐条取值："
                    "价格是 listing 价，评论/星级是平台原值；销量不是平台给的，"
                    "要估算请对单个 PLID 调 takealot_crawl_product（留评率→销量）。")
    return _clip(out)


def _quote(text: str) -> str:
    from urllib.parse import quote_plus
    return quote_plus(text)


#: 用户在对话里回答「不指定」时的写法 —— 明确表达「先进未分派池」。
_UNASSIGNED_WORDS = ("不指定", "未分派", "不分配", "先不分派", "不分派", "none", "unassigned", "skip", "no", "-")


def _bound_stores(api: Any) -> List[Dict[str, str]]:
    """已绑定店铺（读后端自己的列表，不自己猜）。"""
    try:
        rows = api._public_store_list()
    except Exception:
        return []
    out: List[Dict[str, str]] = []
    for row in rows or []:
        if isinstance(row, dict) and _blank(row.get("id")):
            out.append({"id": _blank(row.get("id")),
                        "name": _blank(row.get("name")) or _blank(row.get("id"))})
    return out


def _resolve_collection_store(api: Any, args: Dict[str, Any]) -> Tuple[str, Optional[Dict[str, Any]]]:
    """采集行进箱时归属哪家店 → ``(storeId, None)`` 可以写；``("", {…})`` 先别写、回问用户。

    单店 = 唯一答案（后端 ``_sole_store_id()`` 就是这语义）；**多店必须问，绝不默认活跃店**：
    猜错等于把 A 店的数据挂到 B 店名下，比「未分派」严重得多。
    """
    raw = _blank(args.get("storeId"))
    if raw:
        return ("", None) if raw.lower() in _UNASSIGNED_WORDS else (raw, None)
    stores = _bound_stores(api)
    try:
        sole = _blank(api._sole_store_id())
    except Exception:
        sole = ""
    if sole:
        return sole, None
    if len(stores) <= 1:
        return (stores[0]["id"] if stores else ""), None
    names = "、".join("{0}（{1}）".format(s["name"], s["id"]) for s in stores)
    return "", {
        "ok": False,
        "needsStoreChoice": True,
        "wroteAnything": "没有写任何东西 —— 等你确认店铺之后再写",
        "question": "这条采集要分派给哪家店？（账号绑定了 {0} 家店，我不替你猜）".format(len(stores)),
        "stores": stores,
        "howToAnswer": "直接说店名或店 id，我立刻写入并归属该店；如果先不指定，就说「不指定」——"
                       "行会进采集箱的未分派池，界面里随时可以分派。当前绑定：{0}".format(names),
        "why": "采集箱是全店共用的池子，但一行只能归属一家店：跟价与上架会用那家店的 key，"
               "猜错等于把别的店的数据挂到这家店名下。",
        "tool": "takealot_collection_add",
    }


def _handle_collection_add(args: Dict[str, Any], **kw: Any) -> str:
    """把商品存进**本地**采集箱（写 state/collection.json），绝无平台写请求。"""
    api, err = backend()
    if api is None:
        return _err(err, tool="takealot_collection_add")
    target = _blank(args.get("url") or args.get("target") or args.get("tsin"))
    if not target:
        return _err("target 必填：传商品链接 / PLID… / TSIN…", tool="takealot_collection_add")
    store_arg, store_gate = _resolve_collection_store(api, args)
    if store_gate is not None:
        return _clip(store_gate)          # 多店且没指名 → 先问用户，本轮什么都不写
    body: Dict[str, Any] = {"url": target}
    if _blank(args.get("tsin")):
        body["tsin"] = _blank(args.get("tsin"))
    for key in ("title", "brand", "category", "barcode", "note"):
        if _blank(args.get(key)):
            body[key] = _blank(args.get(key))
    for key in ("price", "cost", "costCurrency", "costRmb", "exchangeRateZarPerRmb",
                "exchangeLossCoeff", "headLogisticsZar",
                "weightKg", "lengthCm", "widthCm", "heightCm"):
        if args.get(key) not in (None, ""):
            body[key] = args.get(key)
    if store_arg:
        body["storeId"] = store_arg
    try:
        data = api.collection_add(body)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_collection_add")
    if not isinstance(data, dict):
        return _err("collection_add returned {0}".format(type(data).__name__),
                    tool="takealot_collection_add")
    item = data.get("item") or {}
    crawl = data.get("crawl") or {}
    out = {
        "ok": bool(data.get("ok")),
        "mode": data.get("mode"),
        "wroteAnything": "本地 state/collection.json（客户自己的采集箱，不是平台）",
        "item": _project(item, ("id", "title", "tsin", "barcode", "category", "price", "cost",
                                "estSalePrice", "storeId", "status", "sourceUrl")),
        "missing": (item.get("missing") or [])[:10],
        "assignedStoreId": item.get("assignedStoreId"),
        "assignedStoreName": item.get("assignedStoreName"),
        "unassigned": not item.get("assignedStoreId"),
        "crawl": _crawl_digest(crawl, 5) if isinstance(crawl, dict) and crawl else None,
        "crawlError": _trim(data.get("crawlError")),
        "conflicts": (data.get("conflicts") or [])[:5],
        "note": ("这一行只进本地采集箱；抓取失败也不会丢行（缺的字段在 missing[] 里，"
                 "由界面提示补录）。"),
    }
    if not data.get("ok"):
        out["why_failed"] = "collection_add 返回 ok:false，检查 state 目录可写与入参。"
    if not item.get("assignedStoreId"):
        out["unassignedNote"] = (
            "这行进的是**未分派池**：采集箱全店共用，未分派 ≠ 没采集到，界面里也看得见"
            "（采集箱会显示「未分派 N 行」）。跟价 / 上架前把它分派到店铺，或告诉我店名我重写一次。"
        )
    return _clip(out)


def _handle_route_verdict(args: Dict[str, Any], **kw: Any) -> str:
    """这个商品该跟卖还是建档。证据分级：自有 Offer > 公开页确认 > 本地记录（仅提示，不改路由）。"""
    crawl, err = crawler()
    if crawl is None:
        return _err(err, tool="takealot_route_verdict")
    api, api_err = backend()
    if api is None:
        return _err(api_err, tool="takealot_route_verdict")
    target = _blank(args.get("target") or args.get("url") or args.get("tsin"))
    if not target:
        return _err("target 必填：传商品链接 / PLID… / TSIN…", tool="takealot_route_verdict")
    store_id = _store_arg(args)
    try:
        payload = crawl.pull(target, force=_flag(args.get("force"), False), cached_only=False)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_route_verdict")
    product = (payload or {}).get("product") if isinstance(payload, dict) else None
    out: Dict[str, Any] = {
        "target": target,
        "transport": (payload or {}).get("transport"),
        "mode": (payload or {}).get("mode"),
        "wroteAnything": False,
    }
    if not isinstance(product, dict) or not product:
        out["ok"] = False
        out["route"] = None
        out["blocked"] = True
        out["error"] = _trim((payload or {}).get("error"))
        out["ladder"] = _BLOCKED_LADDER
        out["why_empty"] = ("抓不到公开页就无法判定跟卖/建档（判定依据必须是公开页确认或自有 Offer，"
                            "不能靠本地记录猜）；如实报告 transport 与原因。")
        return _clip(out)
    try:
        verdict = api._route_verdict(product, payload, target, store_id)
    except Exception as exc:
        return _err("{0}: {1}".format(type(exc).__name__, exc), tool="takealot_route_verdict")
    out.update({
        "ok": True,
        "route": verdict.get("route"),
        "routeLabel": {"offer": "跟卖（已存在）", "loadsheet": "建档（新品）",
                       "review": "先人工复核"}.get(str(verdict.get("route")), verdict.get("route")),
        "exists": verdict.get("exists"),
        "routeSource": verdict.get("routeSource"),
        "matchKey": verdict.get("matchKey"),
        "routeReason": _trim(verdict.get("routeReason"), 400),
        "nextStep": _trim(verdict.get("nextStep"), 300),
        "sellerOffer": verdict.get("sellerOffer"),
        "evidenceTier": {"seller-offers": "T1 自有 Offer（可改变路由）",
                         "public-catalog": "T2 公开页已确认（可改变路由）",
                         "erp-records": "T3 仅本地记录（只提示，不改路由）",
                         }.get(str(verdict.get("routeSource")), str(verdict.get("routeSource"))),
        "product": _project(product, ("plid", "tsin", "title", "price", "sellerCount",
                                      "isExclusive", "lowestCompetitorPrice", "categoryPath")),
        "note": "判定只读；真正的改价/发 Offer 请在界面执行（agent 没有写平台的工具）。",
    })
    return _clip(out)


# ===========================================================================
# Schemas
# ===========================================================================

_S_STR = {"type": "string"}
_S_INT = {"type": "integer"}
_S_BOOL = {"type": "boolean"}


def _schema(name: str, description: str, properties: Dict[str, Any],
            required: Tuple[str, ...] = ()) -> Dict[str, Any]:
    return {"name": name, "description": description,
            "parameters": {"type": "object", "properties": properties,
                           "required": list(required), "additionalProperties": False}}


_STORE = {"type": "string", "description": "店铺 id（storeId）。省略 = 当前店铺；多店汇总类端点会明确拒绝跨店。"}
_ROWS = {"type": "integer", "description": "返回给模型的行数上限（默认 10，最大 50；总数另回 total）。"}

OVERVIEW_SCHEMA = _schema(
    "takealot_erp_overview",
    "经营总览（只读）：KPI、近 14 天趋势、告警、最近订单、BuyBox 候选、平台费拆分。"
    "行键：alerts/trend/recentOrders/buybox/feeBreakdown。" + _READ_NOTE,
    {"storeId": _STORE, "rows": _ROWS})

ORDERS_SCHEMA = _schema(
    "takealot_erp_orders",
    "订单与净利（只读）：走 Seller API /sales 的实时订单（items[]，含每单净利口径）。"
    "status 过滤平台状态原文（如 Awaiting Shipment），q 为关键词。" + _READ_NOTE,
    {"storeId": _STORE, "status": {"type": "string", "description": "平台状态过滤，如 Awaiting Shipment"},
     "q": {"type": "string", "description": "订单号/标题/SKU 关键词"},
     "limit": {"type": "integer", "description": "返回行数（默认 20，最大 200）"}})

PRODUCTS_SCHEMA = _schema(
    "takealot_erp_products",
    "本店商品目录（只读）：Seller API /offers + 分仓库存 + 抓取补全，分页返回。"
    "一定要看 total/mapped/hasMore：一行不等于全部。" + _READ_NOTE,
    {"storeId": _STORE, "q": {"type": "string", "description": "SKU/标题/条码/TSIN 关键词"},
     "status": {"type": "string", "description": "状态过滤，如 buyable / not_buyable / disabled"},
     "sort": {"type": "string", "description": "排序键（后端定义，如 price / stock / title）"},
     "content": {"type": "string", "description": "内容完整度过滤（后端定义）"},
     "stock": {"type": "string", "description": "库存过滤（后端定义）"},
     "limit": {"type": "integer", "description": "每页行数（默认 20，最大 200）"},
     "offset": {"type": "integer", "description": "起始偏移（默认 0）"}})

FINANCE_SCHEMA = _schema(
    "takealot_erp_finance",
    "财务与对账（只读）：月份汇总 months[]、/transactions 流水 ledgerRows[]、余额 balances、"
    "对账差异 reconcile、异常 anomalies。注意行键是 ledgerRows 不是 rows。" + _READ_NOTE,
    {"storeId": _STORE, "q": {"type": "string", "description": "关键词（后端定义）"}, "rows": _ROWS})

FULFILMENT_SCHEMA = _schema(
    "takealot_erp_fulfilment",
    "履约闭环（只读）：入仓送仓单/出库批次（/shipments）→ 分仓库存 → 关联订单。"
    "没有平铺行列表，行在 stages.inbound/outbound.pos。" + _READ_NOTE,
    {"storeId": _STORE, "limit": {"type": "integer", "description": "每个阶段返回的批次行数（默认 5）"},
     "withStock": {"type": "boolean",
                   "description": "true 才去拉全量 /offers 算库存（真店约 30 秒）；默认 false 用缓存"}})

COLLECTION_SCHEMA = _schema(
    "takealot_erp_collection",
    "采集箱/跟卖池（只读）：本地 state 里已经采集、等待处理的行（items[]）。"
    "为空是真实状态，不是错误。" + _READ_NOTE,
    {"storeId": _STORE, "rows": _ROWS})

LISTINGS_SCHEMA = _schema(
    "takealot_erp_listings",
    "上架草稿箱（只读）：按店铺过滤的草稿 items[] + 就绪度 readiness。"
    "如果按店过滤为空，工具会自动再读一次全量并把草稿归属说清楚。" + _READ_NOTE,
    {"storeId": _STORE, "rows": _ROWS})

SELFCHECK_SCHEMA = _schema(
    "takealot_erp_selfcheck",
    "环境自检（只读）：后端挂载、Seller API、出口代理/公开通道、state 目录、各店 Key 状态；"
    "附公开抓取通道当前 transport。" + _READ_NOTE,
    {"storeId": _STORE, "heavy": {"type": "boolean", "description": "true 跑重项自检（更慢）"}})

CRAWL_PRODUCT_SCHEMA = _schema(
    "takealot_crawl_product",
    "按链接/PLID/TSIN 抓单个商品（公开页只读抓取）：商品事实、四个销量窗口（留评率→销量）、"
    "跟卖人数、竞品价，并附跟卖-or-建档判定。不写平台、不自动入库。" + _CRAWL_NOTE,
    {"target": {"type": "string", "description": "商品链接、PLID12345678 或 TSIN12345678"},
     "force": {"type": "boolean", "description": "true 跳过 5 天缓存重新抓"},
     "withRoute": {"type": "boolean", "description": "是否附跟卖/建档判定（默认 true）"},
     "limit": {"type": "integer", "description": "附带的竞品 Offer 行数（默认 8）"},
     "storeId": _STORE},
    ("target",))

MARKET_SEARCH_SCHEMA = _schema(
    "takealot_market_search",
    "关键词搜 Takealot 市场行情（公开搜索接口，只读、不落库）：命中数、前 N 个商品的标题/价格/"
    "评分/评论数/TSIN。要估算销量请对单个 PLID 用 takealot_crawl_product。" + _CRAWL_NOTE,
    {"query": {"type": "string", "description": "搜索关键词（英文命中率更高，例如 usb charger）"},
     "rows": {"type": "integer", "description": "返回商品条数（默认 10，最大 36）"}},
    ("query",))

COLLECTION_ADD_SCHEMA = _schema(
    "takealot_collection_add",
    "把一个商品存进本地采集箱（写 state/collection.json，客户自己的 workspace）："
    "抓取成功则带上真实标题/价格/条码，抓不到也照样入库并标出缺什么。"
    "绝不产生平台写请求（没有写平台的工具）。"
    "**分派店铺**：用户这句话指名了店铺就传 storeId；没指名而账号绑了多家店时本工具**不会自己猜**，"
    "会返回 needsStoreChoice:true 并把可选店铺列出来——照它的 question/stores 原样问用户，"
    "等用户回答后再调一次并带上 storeId（用户答「不指定」就传 storeId=\"不指定\"，行进未分派池）。"
    "工具回 needsStoreChoice 时，本轮不得宣称已经入库。",
    {"url": {"type": "string", "description": "商品链接（首选）"},
     "tsin": {"type": "string", "description": "商品 TSIN/PLID"},
     "title": {"type": "string", "description": "备注标题（不传就用抓取到的）"},
     "price": {"type": "number", "description": "售价（不传就用抓取到的）"},
     "cost": {"type": "number", "description": "采购成本（客户自己的记录）"},
     "costCurrency": {"type": "string", "enum": ["ZAR", "RMB"],
                      "description": "成本币种，默认 ZAR"},
     "costRmb": {"type": "number", "description": "按 RMB 记的成本（用 exchangeRateZarPerRmb 折算）"},
     "exchangeRateZarPerRmb": {"type": "number",
                               "description": "客户自己的 XT 结汇率：**1 ZAR = 此值 RMB**（实见 0.25 / 0.232 / 0.27，"
                                              "不同客户与时间点不同，绝不预置、绝不猜）。成本按 RMB 记录时"
                                              "按「成本_ZAR = 成本_RMB ÷ 此汇率」折算；没填就不给到手金额，"
                                              "只提示去填。别把它反过来当「1 RMB = ? ZAR」。"},
     "exchangeLossCoeff": {"type": "number",
                           "description": "汇损系数（估计值，预置 0.20，合理范围 0.2–0.3；"
                                          "不要谎称是平台公布的固定值）"},
     "headLogisticsZar": {"type": "number", "description": "头程物流费（ZAR）"},
     "weightKg": {"type": "number", "description": "包装重量 kg —— 履约费档位条件之一"},
     "lengthCm": {"type": "number", "description": "包装长 cm —— 与宽/高一起定体积 cm³ 档"},
     "widthCm": {"type": "number", "description": "包装宽 cm"},
     "heightCm": {"type": "number", "description": "包装高 cm"},
     "storeId": {"type": "string",
                 "description": "要分派到的店铺 id。留空=用户没指定：单店自动归属，多店会回 "
                                "needsStoreChoice 让你先问用户。传「不指定」= 明确进未分派池。"}},
    ())

ROUTE_VERDICT_SCHEMA = _schema(
    "takealot_route_verdict",
    "判定这个商品该跟卖还是建档（只读）：依据自有 Offer > 公开页确认 > 本地记录，"
    "回 route/routeReason/nextStep。抓不到公开页就明说不可判定，不猜。" + _CRAWL_NOTE,
    {"target": {"type": "string", "description": "商品链接、PLID12345678 或 TSIN12345678"},
     "force": {"type": "boolean", "description": "true 跳过缓存重新抓"},
     "storeId": _STORE},
    ("target",))

#: ``(name, schema, handler, emoji)`` — the single source the plugin registers from.
TOOLS: Tuple[Tuple[str, Dict[str, Any], Callable[..., str], str], ...] = (
    ("takealot_erp_overview", OVERVIEW_SCHEMA, _handle_overview, "📊"),
    ("takealot_erp_orders", ORDERS_SCHEMA, _handle_orders, "🧾"),
    ("takealot_erp_products", PRODUCTS_SCHEMA, _handle_products, "📦"),
    ("takealot_erp_finance", FINANCE_SCHEMA, _handle_finance, "💰"),
    ("takealot_erp_fulfilment", FULFILMENT_SCHEMA, _handle_fulfilment, "🚚"),
    ("takealot_erp_collection", COLLECTION_SCHEMA, _handle_collection, "🗃️"),
    ("takealot_erp_listings", LISTINGS_SCHEMA, _handle_listings, "🧱"),
    ("takealot_erp_selfcheck", SELFCHECK_SCHEMA, _handle_selfcheck, "🩺"),
    ("takealot_crawl_product", CRAWL_PRODUCT_SCHEMA, _handle_crawl_product, "🔍"),
    ("takealot_market_search", MARKET_SEARCH_SCHEMA, _handle_market_search, "🛒"),
    ("takealot_collection_add", COLLECTION_ADD_SCHEMA, _handle_collection_add, "➕"),
    ("takealot_route_verdict", ROUTE_VERDICT_SCHEMA, _handle_route_verdict, "🧭"),
)


def register_tools(ctx: Any) -> List[str]:
    """Register all 12 tools on ``ctx`` and return the names in registration order."""
    names: List[str] = []
    for name, schema, handler, emoji in TOOLS:
        ctx.register_tool(name=name, toolset=TOOLSET, schema=schema, handler=handler, emoji=emoji)
        names.append(name)
    return names


# ===========================================================================
# 中文自然语言 → 确定性意图路由（词表 + 反例守卫 + 审计）
#
# 设计原则：**不靠模型猜**。句子先过一张有序的规则表，命中就注入一条硬指令，
# 点名本轮必须调用的工具；命中不了就不注入（模型自由发挥，不留痕迹地干扰）。
#
# 顺序 = 优先级。歧义最大的「找/搜」两字靠三个派生标志解决：
#   external_object —— 句子里出现了外部对象（链接/PLID/TSIN/这个商品/同款…）
#   external_force  —— 句子里出现了天生外部的词（市场/竞品/热销/关键词/排行…）
#   own_data        —— 有自有数据名词，且没有上面两类 → 只可能是"查我自己的帐"
# 反例「帮我找一下我的订单」「搜一下最近30天销量」因此永远走查询，绝不触发抓取。
# ===========================================================================

AUDIT_MAX_ARGS = 400


def _message_text(user_message: Any) -> str:
    """Flatten a user message (str, or a multimodal content list) into plain text."""
    if isinstance(user_message, str):
        return user_message
    if isinstance(user_message, (list, tuple)):
        parts: List[str] = []
        for block in user_message:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                for key in ("text", "content", "input_text"):
                    value = block.get(key)
                    if isinstance(value, str):
                        parts.append(value)
                        break
        return " ".join(parts)
    return "" if user_message is None else str(user_message)


# --------------------------------------------------------------------------
# 派生标志
# --------------------------------------------------------------------------

_LINK_RE = re.compile(r"https?://|www\.|takealot\.com|/p/\d", re.I)
_PLID_RE = re.compile(r"\b(?:plid|tsin)[\s\-_]?\d{4,}\b|\b\d{7,10}\b", re.I)

_EXTERNAL_OBJECT = (
    "这个链接", "这条链接", "该链接", "链接", "网址", "url", "商品页", "产品页",
    "这个商品", "这个产品", "这款", "这一款", "这个sku的竞品", "同款", "类似款",
    "竞品链接", "对手的", "别人的商品", "这货", "这货多少钱",
)
_EXTERNAL_FORCE = (
    "市场", "市场价", "行情", "竞品", "热销", "热搜", "畅销", "关键词", "排行", "榜单",
    "同类商品", "市场上", "整个平台", "类目行情", "卖多少钱", "多少钱", "价多少", "报价",
    "价位",
)
#: 只读查询类名词（负例守卫用：有这些词说明在问自己的帐，不是在抓外面）
_OWN_DATA = (
    "我的订单", "我的店", "我的商品", "我的库存", "我的销量", "我的财务", "我的余额",
    "我们店", "本店", "我店", "店里", "店铺", "我的采集箱", "我的草稿",
    "订单", "销量", "销售额", "营收", "营业额", "净利", "余额", "结算", "对账",
    "账单", "流水", "手续费", "平台费", "打款", "待发货", "已发货", "库存",
    "采集箱", "跟卖池", "草稿", "总览", "概览", "经营", "整体情况", "财务",
    "履约", "入仓", "出库", "送仓", "自检", "体检", "诊断", "上架草稿",
)

#: 抓取动词（用户实际会说的一整套同义词；抓/爬/扒/撸/取数/弄下来…）
_CRAWL_VERBS = (
    "抓", "抓取", "抓一下", "抓数据", "爬", "爬取", "爬一下", "爬一份", "扒", "扒一下",
    "扒一份", "撸一下", "撸", "取数", "取一下数", "弄下来", "弄一份", "采一下", "采集",
    "看一下这个", "看看这个", "查一下这个", "分析这个", "评估这个", "值不值得",
    "能不能跟卖", "搜同款", "找同款",
)

# 写操作的"强"表达：动词 + 目标 + 值 同现，问句语气也压不住（"帮我把价格改成199 行吗" 也是写）
_WRITE_STRONG = (
    re.compile(r"(把|将|给)\s*[^\s，。？！]{0,10}?(价格|售价|价钱|price|库存|stock)\s*(改|设|调|定|变)"),
    re.compile(r"(价格|售价|价钱|库存)\s*(改|设|调)\s*(成|为|到)\s*[\dR$r]"),
    re.compile(r"(改|设|调|修改|调整)\s*(一下)?\s*(价格|售价|库存|价钱)\s*(成|为|到)\s*[\dR$r]"),
)
# 写操作的"弱"表达：像命令，但可能是问句（"要不要上架一下" 不是写）
_WRITE_WEAK = (
    "上架", "下架", "发布", "发offer", "发个offer", "创建offer", "提交offer", "新建offer",
    "改标题", "改图片", "改描述", "改类目", "改价", "调价", "提价", "降价", "改库存", "加库存",
)
_QUESTION = ("该不该", "要不要", "能不能", "可不可以", "是不是", "应不应该", "为什么", "为啥",
             "怎么", "如何", "需要吗", "吗", "呢", "？", "?")

_COLLECTION_ADD_VERBS = ("存进", "存入", "存到", "加进", "加入", "加到", "放进", "放到", "收进",
                         "扔进", "丢进", "添进", "添到", "添加", "入库", "进采集箱", "进跟卖池",
                         "收藏")
_COLLECTION_READ_WORDS = ("有什么", "有哪些", "多少", "几条", "列表", "看看", "查看", "查一下",
                          "有没有", "清单", "几个")

_ROUTE_PHRASES = (
    "跟卖还是建档", "建档还是跟卖", "该跟卖", "该建档", "要不要建档", "需要建档", "要建档吗",
    "能不能跟卖", "该不该跟卖", "走跟卖还是", "该走哪条", "哪条路", "上架方式", "怎么上架",
    "该不该上架", "要不要上架", "能不能上架", "需要上架吗", "跟卖判定", "建档判定", "路由判定",
    "该不该新建", "要不要新建", "需要新建", "要不要发offer", "要不要建offer",
)


def _hit(text: str, phrases: Tuple[str, ...]) -> List[str]:
    """Phrases present in *text*, longest first (so the audit names the most specific hit)."""
    found = [p for p in phrases if p and p in text]
    return sorted(found, key=len, reverse=True)


def _has(text: str, phrases: Tuple[str, ...]) -> bool:
    return any(p in text for p in phrases)


#: 否定上下文：「不要抓取 / 别采集 / 先别扒 / 不用取数」不是抓取请求。
#: 负向断言只挂在单字「别」上（挡掉「类别 / 特别 / 分别 / 个别」这类假否定）；多字否定词
#: （不要/先别/不用…）不需要断言，否则「这个不要存进采集箱」会被「个+别？」误伤。
_NEGATION_RE = re.compile(
    r"(?:不要|不需要|暂不|暂时不|先不|无需|不许|先别|不用"
    r"|(?<![类特分别个])别)"
    r"\s*[^\s，。！？,]{0,4}?(抓|爬|扒|撸|采集|取数|弄下来|搜|查|存进|加进|放进|下载)")


def _negated(text: str) -> bool:
    """True when the sentence negates a fetch/search verb (so it must NOT trigger crawl)."""
    return bool(_NEGATION_RE.search(text))


def _external_object(text: str) -> bool:
    return bool(_LINK_RE.search(text) or _PLID_RE.search(text) or _hit(text, _EXTERNAL_OBJECT))


def _external_force(text: str) -> bool:
    return bool(_hit(text, _EXTERNAL_FORCE))


def _is_write(text: str) -> Tuple[bool, List[str]]:
    """(is_write, evidence). 强表达无条件成立；弱表达在问句里不算写。"""
    for pattern in _WRITE_STRONG:
        m = pattern.search(text)
        if m:
            return True, [m.group(0)]
    weak = _hit(text, _WRITE_WEAK)
    if weak and not _hit(text, _QUESTION):
        return True, weak
    return False, []


#: 有序规则表。``intent`` → ``tool``（None = 不调用任何工具，只回绝/说明）。
#: ``kind`` 决定匹配方式：``write`` / ``route`` / ``collection_add`` / ``market`` /
#: ``crawl`` / ``read`` / ``none``。
INTENT_RULES: Tuple[Dict[str, Any], ...] = (
    {"id": "setup.llm_channel", "kind": "setup_llm", "intent": "setup_llm", "tool": None,
     "phrases": ("配模型", "配置模型", "模型配置", "换模型", "切换模型", "换一个模型", "模型通道",
                 "模型列表", "模型选不到", "选不到模型", "模型只有", "默认模型", "设置模型",
                 "模型不对", "模型太少", "模型好少", "千问", "百炼",
                 "token plan", "Token Plan", "coding plan", "Coding Plan", "dashscope", "DashScope"),
     "why": "配置/切换模型通道 = 走 qwen-token-plan-setup 技能（先探测套餐真实可用清单，再写配置）。"},
    {"id": "write.price_or_stock", "kind": "write", "intent": "write_refused", "tool": None,
     "why": "改价/改库存/上架/发布 = 平台写操作，agent 没有写平台工具，只回绝并引到界面。"},
    {"id": "route.offer_or_loadsheet", "kind": "route", "intent": "route_verdict",
     "tool": "takealot_route_verdict",
     "phrases": _ROUTE_PHRASES,
     "why": "跟卖还是建档 = 只读判定，走路由判定工具。"},
    {"id": "collection.add", "kind": "collection_add", "intent": "collection_add_single",
     "tool": "takealot_collection_add",
     "phrases": _COLLECTION_ADD_VERBS,
     "guard_phrases": ("采集箱", "跟卖池", "采集"),
     "why": "把商品存进本地采集箱 = 写本地 state，允许；不是平台写。"},
    {"id": "market.keyword_search", "kind": "market", "intent": "market_search",
     "tool": "takealot_market_search",
     "phrases": _EXTERNAL_FORCE,
     "why": "关键词/市场/竞品 = 公开市场行情搜索，不落库。"},
    {"id": "crawl.single_product", "kind": "crawl", "intent": "crawl_single",
     "tool": "takealot_crawl_product",
     "phrases": _CRAWL_VERBS,
     "why": "带外部对象（链接/PLID/TSIN/这个商品/同款）的抓取请求。"},
    {"id": "read.fulfilment", "kind": "read", "intent": "read_fulfilment",
     "tool": "takealot_erp_fulfilment",
     "phrases": ("履约", "入仓", "出库", "送仓", "集货", "补货", "仓库", "分仓", "po单",
                 "送仓单", "发货批次", "上架到仓库", "收货", "在途"), "why": "履约/入仓/出库类。"},
    {"id": "read.finance", "kind": "read", "intent": "read_finance",
     "tool": "takealot_erp_finance",
     "phrases": ("财务", "结算", "余额", "对账", "流水", "账单", "手续费", "平台费", "打款",
                 "扣了多少钱", "到账", "transaction", "月结"), "why": "钱相关的只读。"},
    {"id": "read.listings", "kind": "read", "intent": "read_listings",
     "tool": "takealot_erp_listings",
     "phrases": ("草稿", "上架草稿", "待上架", "建档", "loadsheet", "载入表", "listing草稿"),
     "why": "上架草稿箱只读。"},
    {"id": "read.collection", "kind": "read", "intent": "read_collection",
     "tool": "takealot_erp_collection",
     "phrases": ("采集箱", "跟卖池"), "why": "采集箱/跟卖池只读。"},
    {"id": "read.selfcheck", "kind": "read", "intent": "read_selfcheck",
     "tool": "takealot_erp_selfcheck",
     "phrases": ("自检", "体检", "诊断", "环境检查", "连通性", "接口通不通", "key 有没有",
                 "代理配置", "报错原因"), "why": "环境自检只读。"},
    {"id": "read.orders", "kind": "read", "intent": "read_orders",
     "tool": "takealot_erp_orders",
     "phrases": ("订单", "销量", "卖了", "卖了多少", "销售额", "营收", "营业额", "净利",
                 "待发货", "已发货", "发货", "客户买", "多少单", "出单", "最近30天", "近30天",
                 "最近三十天"), "why": "订单与净利只读。"},
    {"id": "read.products", "kind": "read", "intent": "read_products",
     "tool": "takealot_erp_products",
     "phrases": ("商品", "产品", "库存", "在售", "sku", "listing", "上架的商品", "目录",
                 "有几款", "有多少款", "哪些款", "货"), "why": "本店商品目录只读。"},
    {"id": "read.overview", "kind": "read", "intent": "read_overview",
     "tool": "takealot_erp_overview",
     "phrases": ("总览", "概览", "经营情况", "经营状况", "整体情况", "整体怎么样", "今天怎么样",
                 "最近怎么样", "kpi", "店铺情况", "生意", "报表"), "why": "经营总览只读。"},
)


def classify_intent(text: str) -> Optional[Dict[str, Any]]:
    """Sentence → one decision, or ``None`` when nothing matches (no injection, no audit noise).

    Deterministic: the rule order IS the priority order. ``matched`` carries the literal
    phrases that fired so the audit trail can be re-checked by hand.
    """
    raw = _blank(text)
    if not raw:
        return None
    lowered = raw.lower()
    external_object = _external_object(raw)
    external_force = _external_force(raw)
    own_data = _hit(raw, _OWN_DATA) and not external_object and not external_force
    negated = _negated(raw)

    for rule in INTENT_RULES:
        kind = rule["kind"]
        if kind == "write":
            is_write, evidence = _is_write(raw)
            if is_write:
                return _decision(rule, evidence)
            continue
        if kind == "setup_llm":
            # 配置类（模型通道）：命中词表即决定；否定句（"先别换模型"）不注入
            if negated or _NEG_SETUP_RE.search(raw):
                continue
            hits = _hit(raw, rule["phrases"])
            if hits:
                return _decision(rule, hits)
            continue
        if kind == "route":
            hits = _hit(raw, rule["phrases"])
            if hits:
                return _decision(rule, hits)
            continue
        if kind == "collection_add":
            if negated:
                continue  # 「别存进采集箱」不是采集请求
            hits = _hit(raw, rule.get("phrases", ()))
            if hits and _has(raw, rule.get("guard_phrases", ())):
                # 采集箱 + "存/加/放" = 写入本地；采集箱 + "有什么/看看" = 只读，放给 read 规则
                if _has(raw, _COLLECTION_READ_WORDS) and not _has(raw, ("存", "加进", "放进", "收进", "存进")):
                    continue
                return _decision(rule, hits)
            continue
        if kind == "market":
            if negated:
                continue
            hits = _hit(raw, rule["phrases"])
            if not hits:
                continue
            # 自有数据 + 没有天生外部的词 → 是「查我自己的帐」，交给 read 规则
            if own_data and not external_force:
                continue
            # 句子里已经点名了一个外部对象（链接/PLID/这款/同款/这货），而且没说"市场/行情/竞品"，
            # 那是"给我这一个商品的行情"——抓单个商品比搜关键词更准，交给 crawl 规则。
            if external_object and not _has(raw, ("市场", "行情", "竞品", "关键词", "排行",
                                                  "榜单", "类目", "行业")):
                continue
            verbs = _hit(lowered, ("搜", "查", "看", "找", "行情", "多少钱", "有哪些"))
            return _decision(rule, hits + verbs)
        if kind == "crawl":
            if negated:
                continue  # 「不要抓取这个链接」不是抓取请求
            if not external_object:
                continue
            # 「采集箱/跟卖池 + 有没有/哪些」是在问本地箱子，不是在抓外站链接
            # （注意用「采一下/采集一下」而不是裸「采集」：后者是「采集箱」的子串）
            if _has(raw, ("采集箱", "跟卖池")) and _has(raw, _COLLECTION_READ_WORDS) \
                    and not _has(raw, ("抓", "爬", "采一下", "采集一下", "抓取")):
                continue
            verbs = _hit(raw, rule["phrases"]) or _hit(lowered, ("搜", "找", "查", "看", "抓", "爬"))
            # 外部对象 + 抓取动词（或干脆只有外部对象）→ 抓取
            return _decision(rule, (verbs or ["外部对象"]) + _hit(raw, _EXTERNAL_OBJECT))
        if kind == "read":
            hits = _hit(raw, rule["phrases"])
            if not hits:
                continue
            # 反例守卫：查询类只在"自有数据语境"或无外部对象时成立。
            # 例外：句子里点名了本地箱子（采集箱/跟卖池/草稿箱）——那是自己的 workspace，
            # 不是外站对象，照读不误。
            if external_object and not own_data and \
                    not _has(raw, ("采集箱", "跟卖池", "草稿箱", "上架草稿")):
                continue
            return _decision(rule, hits)
        raise AssertionError("unknown rule kind: {0}".format(kind))

    # 没有任何名词命中的兜底：只有裸抓取动词时也算抓取意图（但绝不含自有数据词、也不含否定）
    if not own_data and not negated:
        verbs = _hit(raw, ("抓一下", "抓取", "抓数据", "爬一下", "爬取", "爬一份", "扒一下", "扒一份",
                           "撸一下", "取数", "弄下来", "采集一下", "采一下"))
        if verbs:
            crawl_rule = {"id": "crawl.verb_only", "kind": "crawl", "intent": "crawl_single",
                          "tool": "takealot_crawl_product",
                          "why": "只有抓取动词、没有别的名词：按单商品抓取处理（缺目标就问用户）。"}
            return _decision(crawl_rule, verbs)
    return None


def _decision(rule: Dict[str, Any], matched: List[str]) -> Dict[str, Any]:
    return {"intent": rule["intent"], "tool": rule.get("tool"), "rule": rule["id"],
            "why": rule.get("why", ""), "matched": [m for m in matched if m][:6]}


# --------------------------------------------------------------------------
# 硬指令注入
# --------------------------------------------------------------------------

_WRITE_MODULE_HINT = ("BuyBox 跟价（改价/跟价策略）、商品管理（库存/上下架字段）、"
                      "上架编排（建档/loadsheet 导出）。")
_NEG_SETUP_RE = re.compile(
    r"(?:不要|不需要|暂不|暂时不|先不|无需|不许|先别|不用|别|勿)"
    r"\s*[^\s，。！？,]{0,4}?(配|换|切换|改|动|设置|选|用)"
    r"\s*[^\s，。！？,]{0,4}?(模型|千问|百炼|token\s*plan|coding\s*plan|dashscope)")

_SETUP_DIRECTIVE = (
    "【Takealot ERP · 本轮意图路由（确定性词表命中，不是模型猜测）】\n"
    "意图 = setup_llm\n"
    "命中规则 = {rule}｜命中词 = {matched}\n"
    "本轮不要调用 ERP 取数工具（这是配置类请求，不是查订单/查商品/抓取）。\n"
    "硬性要求：\n"
    "  1. 走技能 qwen-token-plan-setup 的流程；先问清用户买的是哪一档\n"
    "     （Token Plan 中国 / 国际、Coding Plan、DashScope 按量付费；三档端点与 key 变量各不相同，\n"
    "      选错会报「无可用通道 / 无权限」——那不是网络问题，别去调代理）。\n"
    "  2. 先跑 setup_llm_provider.py 的 dry-run，把将要执行的命令给用户看，确认后才加 --apply。\n"
    "  3. 绝不让用户把 key 贴进对话；脚本自己从 <hermes home>\\.env 读，只显示长度、不回显。\n"
    "  4. 完成的判据 = hermes config get model 回读正确 + 用户在 ERP 里成功生成一次 AI 文案。\n"
)



_ESCAPE_CLAUSE = (
    "【逃生条款 · 优先于下面所有条款】上面的工具要求只在「本轮确实是本产品语境」时成立。\n"
    "  若用户在问别的东西（别的网站链接 / 别的平台文档 / 一般性技术问题 / 配置类请求），\n"
    "  **忽略**上面的工具要求，按用户原意回答；并在 state/route_misfire.jsonl 追加一行：\n"
    "  {{\"at\":\"<ISO 时间>\",\"rule\":\"{rule}\",\"matched\":\"{matched}\",\"tool\":\"{tool}\",\"text\":\"<用户原话>\"}}\n"
    "  （只记账、不改回答；这行用于事后调词表，让规则随使用演化。）\n"
)

_TOOL_DIRECTIVE = _ESCAPE_CLAUSE + (
    "【Takealot ERP · 本轮意图路由（确定性词表命中，不是模型猜测）】\n"
    "意图 = {intent}\n"
    "命中规则 = {rule}｜命中词 = {matched}\n"
    "本轮必须调用工具 = {tool}\n"
    "硬性要求：\n"
    "  1. 本轮的取数动作只允许用 `{tool}`；不要拿别的工具或记忆里的数字替代。\n"
    "  2. 只转述工具返回的字段。总数/空值一律以工具回的 `total`/`empty`/`why_empty` 为准；\n"
    "     `empty:true, total:0` 是真的没有，不许补一行「示例」或「大概」。\n"
    "  3. 工具报 `blocked`/`error`/`transport` 时照实说明通道与原因（proxy→direct→blocked），\n"
    "     禁止编造抓取结果。\n"
    "  4. 平台写操作（改价/改库存/发 Offer/上架）没有对应工具：用户提就回绝并引到界面。\n"
)

_WRITE_DIRECTIVE = (
    "【Takealot ERP · 本轮意图路由（确定性词表命中，不是模型猜测）】\n"
    "意图 = write_refused\n"
    "命中规则 = {rule}｜命中词 = {matched}\n"
    "本轮必须调用工具 = （无 —— 本轮不要调用任何工具去执行这个请求）\n"
    "硬性要求：\n"
    "  1. 这是**平台写操作**（改价/改库存/发 Offer/上架/发布）。系统没有、也不打算给 agent\n"
    "     任何写平台的工具：这类动作必须在桌面界面里由用户确认后执行。\n"
    "  2. 明确回绝，并指路界面：{modules}\n"
    "  3. 禁止声称「已经帮你改好了/已经上架了」；禁止伪造成功回执或价格。\n"
    "  4. 用户如果只是想问「该不该改/该跟卖还是建档」，那是只读判定，让他再说一次，或直接\n"
    "     调 takealot_route_verdict 帮他把依据查出来（只读）。\n"
)


_COLLECTION_ADD_DIRECTIVE = _ESCAPE_CLAUSE + (
    "【Takealot ERP · 本轮意图路由（确定性词表命中，不是模型猜测）】\n"
    "意图 = {intent}\n"
    "命中规则 = {rule}｜命中词 = {matched}\n"
    "本轮必须调用工具 = {tool}\n"
    "硬性要求：\n"
    "  1. 「采集 / 存进采集箱 / 加入跟卖池」= 只写**本地**采集箱（state/collection.json），\n"
    "     不是平台动作，也不等于新建 listing。\n"
    "  2. **分派店铺先看用户这句话有没有指名**：\n"
    "     · 指名了（例如「存到 Apex 店」）→ 把 storeId 传给 {tool}。\n"
    "     · 没指名且账号绑定了多家店 → **先问用户要分派给哪家店**，不要猜、不要默认用活跃店；\n"
    "       用户回答后再调一次 {tool} 并带上 storeId。用户说「不指定」就传 storeId=\"不指定\"，\n"
    "       行会进「未分派池」——采集箱全店共用，未分派不是没采集到。\n"
    "     · 工具返回 needsStoreChoice:true 时，照它给的 question/stores 原样问用户；\n"
    "       **本轮不得宣称已经入库**（那时确实什么都没写）。\n"
    "  3. 只转述工具返回的字段。`ok:false`、needsStoreChoice、missing[] 照实说，不许讲成成功。\n"
    "  4. 报采集箱行数时把「本店 N 行 / 未分派 M 行」分开讲；工具回的 unassignedIncluded 就是未分派数。\n"
    "     不许把某个店铺作用域里的空读成「采集箱是空的」。\n"
    "  5. 改价/改库存/发 Offer/上架这类平台写操作仍然只在界面里做。\n"
)


def build_directive(decision: Dict[str, Any], text: str = "") -> str:
    """The exact string the hook injects into this turn's user message."""
    matched = "、".join(str(m) for m in decision.get("matched") or []) or "—"
    if decision.get("intent") == "write_refused":
        return _WRITE_DIRECTIVE.format(rule=decision["rule"], matched=matched,
                                       modules=_WRITE_MODULE_HINT)
    if decision.get("intent") == "setup_llm":
        return _SETUP_DIRECTIVE.format(rule=decision["rule"], matched=matched)
    if decision.get("intent") == "collection_add_single":
        return _COLLECTION_ADD_DIRECTIVE.format(intent=decision.get("intent"), rule=decision["rule"],
                                                matched=matched, tool=decision.get("tool") or "（无）")
    return _TOOL_DIRECTIVE.format(intent=decision.get("intent"), rule=decision["rule"],
                                  matched=matched, tool=decision.get("tool") or "（无）")


# --------------------------------------------------------------------------
# 审计 jsonl
# --------------------------------------------------------------------------

_AUDIT_LOCK = threading.Lock()
_LAST_DECISION: Dict[str, Dict[str, Any]] = {}


def _iso_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def audit(entry: Dict[str, Any]) -> None:
    """Append one audit line. Never raises: auditing must not break a turn."""
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        record = dict(entry)
        record.setdefault("at", _iso_now())
        line = json.dumps(record, ensure_ascii=False, default=str)
        with _AUDIT_LOCK:
            with AUDIT_PATH.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
    except Exception:
        pass


def _remember(decision: Dict[str, Any], session_id: str, text: str) -> None:
    if not session_id:
        session_id = "default"
    _LAST_DECISION[session_id] = dict(decision, say=text)
    if len(_LAST_DECISION) > 32:  # bounded; this is a linkage cache, not a store
        for key in list(_LAST_DECISION)[:-16]:
            _LAST_DECISION.pop(key, None)


# --------------------------------------------------------------------------
# 钩子
# --------------------------------------------------------------------------


def on_pre_llm_call(user_message: Any = "", session_id: str = "", turn_id: str = "",
                    is_first_turn: bool = False, **kwargs: Any) -> Optional[Dict[str, str]]:
    """``pre_llm_call``: 命中词表 → 注入硬指令；命中不了 → 返回 None（不注入）。"""
    text = _message_text(user_message)
    decision = classify_intent(text)
    if decision is None:
        return None
    _remember(decision, session_id, text)
    audit({"stage": "route", "session": session_id, "turn": turn_id,
           "say": _trim(text, 400), "rule": decision["rule"], "intent": decision["intent"],
           "matched": decision["matched"], "expectTool": decision["tool"],
           "injected": True, "why": decision.get("why")})
    return {"context": build_directive(decision, text)}


def on_pre_tool_call(tool_name: str = "", args: Optional[Dict[str, Any]] = None,
                     session_id: str = "", turn_id: str = "", **kwargs: Any) -> None:
    """``pre_tool_call``：把"实际调用的工具"接到本轮路由判定上，写进同一份审计。

    只记账、不拦截（返回 None）。必须快：钩子有超时预算。
    """
    if not str(tool_name or "").startswith("takealot_"):
        return None
    last = _LAST_DECISION.get(session_id or "default") or {}
    try:
        dumped = json.dumps(args or {}, ensure_ascii=False, default=str)
    except Exception:
        dumped = "{}"
    audit({"stage": "tool_call", "session": session_id, "turn": turn_id,
           "tool": tool_name, "args": _trim(dumped, AUDIT_MAX_ARGS),
           "forIntent": last.get("intent"), "rule": last.get("rule"),
           "expected": last.get("tool"),
           "matched_expected": (last.get("tool") == tool_name) if last.get("tool") else None})
    return None


def register_hooks(ctx: Any) -> List[str]:
    """Register the two hooks on ``ctx`` and return their names."""
    ctx.register_hook("pre_llm_call", on_pre_llm_call)
    ctx.register_hook("pre_tool_call", on_pre_tool_call)
    return ["pre_llm_call", "pre_tool_call"]
