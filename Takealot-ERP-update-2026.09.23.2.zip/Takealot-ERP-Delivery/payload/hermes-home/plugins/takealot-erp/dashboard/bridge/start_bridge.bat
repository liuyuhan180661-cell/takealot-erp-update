@echo off
REM Takealot ERP local bridge - start script (ASCII only on purpose)
REM Serves the Chrome/Edge extension on http://127.0.0.1:18790
setlocal
set HERE=%~dp0
set VENV=%LOCALAPPDATA%\hermes\hermes-agent\venv\Scripts\python.exe
echo Starting Takealot ERP bridge on port 18790 ...
echo State dir: %LOCALAPPDATA%\hermes\plugins\takealot-erp\state
if exist "%VENV%" (
  "%VENV%" "%HERE%erp_bridge.py" --port 18790
) else (
  python "%HERE%erp_bridge.py" --port 18790
)
echo.
echo Bridge stopped. If it exited immediately, check that port 18790 is free:
echo   netstat -ano ^| findstr :18790
pause
