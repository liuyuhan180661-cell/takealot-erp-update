#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Takealot ERP 本地桥 (hermes-erp-bridge)
=======================================

把 Hermes 桌面插件（Windows 上的 takealot-erp）的**本地 state** 以固定 HTTP 接口暴露给
Chrome/Edge 扩展。它替换掉已经停掉的 OpenClaw 网关（127.0.0.1:18789）。

设计约束（必须遵守，改动前读一遍）
----------------------------------
1. 只监听 127.0.0.1，绝不对外网开放；不调用 Takealot 任何 API（跟卖/上架的写动作由
   ERP 后端负责，本桥只读写本地 state 文件）。
2. 采集箱 collection.json = **跟卖池**：行是平台上已存在的商品（有 TSIN/PLID/条码）。
   跟卖只能改价格与库存 —— 平台 CreateOfferRequest 是 additionalProperties:false，
   只接受 barcode/sku + selling_price + 仓库库存，改不了标题/图片/描述/类目。
   所以本桥的采集箱写接口**只接受 price/stock**，别的字段一律明确拒绝。
3. 新建草稿箱 drafts.json = **独立容器**，承载未编辑完的新建 listing（官方装载表列）。
   支持随时保存继续（断点续存）。与采集箱不共享行：只能"从采集箱转入"（promote）或
   "从零新建"。
4. 零模拟数据：取不到的数据给 null（或显式空数组）+ reason，绝不返回编造值。
5. 写文件必须原子（临时文件 + os.replace）+ 线程锁；不触碰行里其它字段。
6. 官方类目属性模板（`/v1/loadsheets/templates`）只能由**扩展在商家后台页面带会话**抓，
   抓完 POST 到本桥的 `/takealot/api/attributes/ingest`，桥写 state/attributes_templates.json
   （与插件 `plugin_api.py` 的 ATTR_INGEST_FILE 同名同目录，插件读的就是它）。
   **不转发**插件的 `/meta/attributes/ingest`：那条路要插件后端的会话 token，桥没有。

用法
----
    python erp_bridge.py                       # 127.0.0.1:18790，state 用插件默认目录
    python erp_bridge.py --port 18790
    python erp_bridge.py --state "C:\\Users\\Fly\\bridge-test-state"

依赖：纯 stdlib（http.server / json / urllib.parse / threading / os / time / uuid）。
"""

from __future__ import annotations

import argparse
import json
import os
import random
import sys
import threading
import time
import traceback
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

SOURCE = "hermes-erp-bridge"
VERSION = "1.0.0"
DEFAULT_PORT = 18790
DEFAULT_HOST = "127.0.0.1"  # 固定回环，不提供覆盖

# takealot-erp 插件 state 目录的默认位置：%LOCALAPPDATA%\hermes\plugins\takealot-erp\state
_PLUGIN_REL = os.path.join("hermes", "plugins", "takealot-erp", "state")


def default_state_dir() -> str:
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
    if base:
        return os.path.join(base, _PLUGIN_REL)
    if os.name == "nt":
        home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
        return os.path.join(home, "AppData", "Local", _PLUGIN_REL)
    # 非 Windows：仅用于开发/自测，实际部署在 Windows 上
    return os.path.join(os.path.expanduser("~"), ".hermes", _PLUGIN_REL)


# ---------------------------------------------------------------------------
# CORS：扩展在 seller.takealot.com / www.takealot.com 的页面里 fetch 本桥，
# chrome-extension://<id> 页面也要能读。只回显白名单内的 Origin。
# ---------------------------------------------------------------------------
ALLOWED_ORIGIN_EXACT = {
    "https://seller.takealot.com",
    "https://sellers.takealot.com",
    "https://www.takealot.com",
    "https://takealot.com",
}
ALLOWED_ORIGIN_PREFIX = (
    "chrome-extension://",
    "http://127.0.0.1:",
    "http://localhost:",
)

# ---------------------------------------------------------------------------
# 官方装载表（41 列）里"必填"的那几列 —— completeness 用它算。
# header 文本与插件 pkg/dashboard/plugin_api.py 的 LOADSHEET_COLUMNS 对齐；
# 图片列在装载表里叫 "Product Image 1 (Cover)"，这里按扩展口径写作 "Main Image"。
# Barcode 不是装载表的 required，但 CreateOfferRequest（跟卖）必填，所以也列入。
# ---------------------------------------------------------------------------
REQUIRED_COLUMNS: List[Tuple[str, str]] = [
    ("mainCategory", "Main Category"),
    ("lowestCategory", "Lowest Category"),
    ("title", "Title"),
    ("features", "Key Selling Features"),
    ("barcode", "Barcode"),
    ("mainImage", "Main Image"),
    ("warrantyType", "Warranty Type"),
    ("warrantyPeriod", "Warranty Period"),
]

# 写草稿时允许出现在 fields 里的键（其余键照收，但会记进 audit 的 keys 里）
DRAFT_FIELD_KEYS = (
    "title", "subtitle", "features", "whatsInTheBox", "brand", "model",
    "price", "rrp", "leadtime", "barcode", "images", "attributes",
    "sku", "tsin", "category", "categoryPath", "mainCategory", "lowestCategory",
    "videoUrl", "warrantyType", "warrantyPeriod", "productType", "variantGroup",
    "qty", "stock",
)

# 这些键在草稿行上做"扁平镜像"，插件（上架编排）按扁平结构读 drafts.json
FLAT_MIRROR_KEYS = (
    "title", "subtitle", "features", "whatsInTheBox", "brand", "model",
    "price", "rrp", "leadtime", "barcode", "images", "attributes",
    "sku", "tsin", "category", "categoryPath", "mainCategory", "lowestCategory",
    "videoUrl", "warrantyType", "warrantyPeriod",
    "qty", "stock",
)

COLLECTION_WRITE_WHITELIST = ("id", "price", "stock")

MAX_BODY_BYTES = 4 * 1024 * 1024  # 单次请求体上限 4MB（表单/图片 base64 之类别走这里）

# ---------------------------------------------------------------------------
# 官方类目属性模板（扩展在商家后台页面带会话抓，经本桥落盘）
#
#   文件与插件 plugin_api.py 的 ATTR_INGEST_FILE 同名、同 state 目录：
#   %LOCALAPPDATA%\hermes\plugins\takealot-erp\state\attributes_templates.json
#   形状（插件侧 _read_state 直接吃这个形状）：
#     {_meta:{source, updatedAt, loadsheetsCovered, note}, loadsheets:{<id>:{fields,variant_fields,template_defaults,categories}}}
#
# 为什么桥自己写而不转发插件后端 /meta/attributes/ingest：桥没有插件后端的会话
# token（那条路要 ERP 会话），转发必然 401。所以选「桥直接读-合并-原子替换」，
# 插件后续自己再 ingest 一次会覆盖同名条目，语义一致（都以 loadsheet id 为键）。
# ---------------------------------------------------------------------------
ATTR_TEMPLATES_FILE = "attributes_templates.json"
ATTR_TEMPLATES_NOTE = "由商家后台页面会话抓取（seller-api /v1/loadsheets/templates），非编造"
ATTR_TEMPLATES_SOURCE_DEFAULT = "extension:seller-sidepanel"
# 官方原始响应原样留档：用户只会在真机上点这一次，归一化遇到没见过形状时必须能离线修。
# 只存响应体（rawText），**绝不存任何请求头 / Authorization / JWT / cookie**。
ATTR_RAW_FILE = "attributes_templates_raw.json"
ATTR_RAW_LIMIT_BYTES = 2 * 1024 * 1024          # rawText 上限 2MB，超限截断并标 truncated:true
ATTR_RAW_KEEP_KEYS = ("fetchedAt", "via", "url", "status", "contentType", "bytes", "rawText")
# 这些键名一旦出现就明确拒绝（单独报出来，便于发现调用方在错误地传凭证）
ATTR_RAW_FORBIDDEN_KEYS = ("authorization", "headers", "cookie", "cookies", "jwt", "token",
                           "apikey", "api_key", "x-api-key", "bearer", "set-cookie")
# 36 个装载表的字段/选项明细是几十 MB 量级（现有 7 个装载表的数据包就有 3.1MB），
# 所以这个接口单独放宽上限；其它接口仍是 MAX_BODY_BYTES。
MAX_ATTR_BODY_BYTES = 64 * 1024 * 1024


# ---------------------------------------------------------------------------
# state 读写
# ---------------------------------------------------------------------------
class StateStore(object):
    """直接读写 ERP 插件的 state 目录。

    - 读：文件不存在 → 显式空 + reason（绝不编数据）
    - 写：threading.Lock + 原子替换（临时文件 → os.replace）
    - 审计：写操作 append 到 state/bridge_audit.jsonl
    """

    def __init__(self, state_dir: str) -> None:
        self.state_dir = state_dir
        self.lock = threading.RLock()
        self.writable = False
        self.writable_reason = ""
        self.audit_disabled_reason: Optional[str] = None
        self._probe()

    # -- 启动自检 ----------------------------------------------------------
    def _probe(self) -> None:
        if not os.path.isdir(self.state_dir):
            self.writable = False
            self.writable_reason = "state 目录不存在：{0}".format(self.state_dir)
            return
        probe = os.path.join(
            self.state_dir, ".bridge_write_probe-{0}".format(os.getpid())
        )
        try:
            with open(probe, "w", encoding="utf-8") as fh:
                fh.write("probe")
            os.remove(probe)
            self.writable = True
            self.writable_reason = "ok"
        except Exception as exc:  # noqa: BLE001 - 任何 IO 错误都降级为只读
            self.writable = False
            self.writable_reason = "{0}: {1}".format(type(exc).__name__, exc)

    def path(self, name: str) -> str:
        return os.path.join(self.state_dir, name)

    # -- 读 ----------------------------------------------------------------
    def read_json(self, name: str, default: Any) -> Tuple[Any, Optional[str]]:
        """返回 (data, reason)。reason 非空表示"没读到"，data 是显式空值。"""
        p = self.path(name)
        if not os.path.isfile(p):
            return default, "{0} 不存在（{1}）".format(name, p)
        try:
            with open(p, "r", encoding="utf-8") as fh:
                raw = fh.read()
        except Exception as exc:  # noqa: BLE001
            return default, "读 {0} 失败：{1}: {2}".format(name, type(exc).__name__, exc)
        if not raw.strip():
            return default, "{0} 是空文件".format(name)
        try:
            return json.loads(raw), None
        except Exception as exc:  # noqa: BLE001
            return default, "{0} 不是合法 JSON：{1}".format(name, exc)

    def read_rows(self, name: str) -> Tuple[List[Dict[str, Any]], Optional[str]]:
        data, reason = self.read_json(name, [])
        if isinstance(data, dict):
            for key in ("items", "rows", "data"):
                inner = data.get(key)
                if isinstance(inner, list):
                    return [r for r in inner if isinstance(r, dict)], reason
            return [], reason or "{0} 是对象而不是数组".format(name)
        if not isinstance(data, list):
            return [], reason or "{0} 顶层不是数组（{1}）".format(name, type(data).__name__)
        return [r for r in data if isinstance(r, dict)], reason

    # -- 写 ----------------------------------------------------------------
    def write_rows(self, name: str, rows: List[Dict[str, Any]]) -> str:
        """原子写：同目录临时文件 → fsync → os.replace。返回临时文件名（排错用）。"""
        p = self.path(name)
        tmp = "{0}.tmp-{1}-{2}".format(p, os.getpid(), uuid4_hex())
        payload = json.dumps(rows, ensure_ascii=False, indent=2)
        with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, p)
        return tmp

    # 事务：读-改-写必须在同一把锁里，否则并发 add 会互相覆盖
    def mutate_rows(self, name: str, fn) -> Any:
        with self.lock:
            rows, reason = self.read_rows(name)
            if reason:
                # 文件不存在是正常的（空箱）；文件损坏则拒绝写，避免把坏数据覆盖成"空箱"
                if os.path.isfile(self.path(name)) and "不是合法 JSON" in reason:
                    raise StateError("拒绝写入：{0}".format(reason))
            out = fn(rows)
            self.write_rows(name, rows)
            return out

    # -- 对象型 state 文件（attributes_templates.json 等）------------------
    def write_json(self, name: str, data: Any) -> str:
        """原子写任意 JSON（同目录临时文件 → fsync → os.replace）。返回临时文件名。"""
        p = self.path(name)
        tmp = "{0}.tmp-{1}-{2}".format(p, os.getpid(), uuid4_hex())
        payload = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=False)
        with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, p)
        return tmp

    def mutate_json(self, name: str, fn) -> Any:
        """对象型文件的事务读-改-写：同一把锁内 读 → fn(data) → 原子替换。

        文件损坏（存在但不是合法 JSON）时拒绝写，避免把别人写坏的内容覆盖成"空"。
        """
        with self.lock:
            data, reason = self.read_json(name, {})
            if reason:
                exists = os.path.isfile(self.path(name))
                if exists and ("不是合法 JSON" in reason or "是空文件" in reason):
                    raise StateError("拒绝写入：{0}".format(reason))
                if not isinstance(data, dict):
                    data = {}
            if not isinstance(data, dict):
                raise StateError("拒绝写入：{0} 顶层不是对象（{1}）".format(name, type(data).__name__))
            out = fn(data)
            self.write_json(name, data)
            return out

    def append_audit(self, action: str, entry_id: Any, changed: Any, source: str) -> None:
        rec = {
            "ts": now_str(),
            "action": action,
            "id": entry_id,
            "changed": changed,
            "source": source,
        }
        line = json.dumps(rec, ensure_ascii=False) + "\n"
        with self.lock:
            try:
                with open(self.path("bridge_audit.jsonl"), "a", encoding="utf-8", newline="\n") as fh:
                    fh.write(line)
                    fh.flush()
            except Exception as exc:  # noqa: BLE001 - 审计失败不影响主流程，只报一次
                if self.audit_disabled_reason is None:
                    self.audit_disabled_reason = "{0}: {1}".format(type(exc).__name__, exc)
                    log("WARN bridge_audit.jsonl 不可写，审计已关闭：{0}".format(
                        self.audit_disabled_reason))

    # -- 店铺（只取 id/name，绝不输出密文）--------------------------------
    def active_store(self) -> Tuple[Optional[str], Optional[str], List[str]]:
        """返回 (storeId, storeName, notes)。读不到 → (None, None, [原因])。"""
        notes: List[str] = []
        data, reason = self.read_json("stores.json", None)
        if reason:
            return None, None, [reason]
        if not isinstance(data, dict):
            return None, None, ["stores.json 顶层不是对象"]
        stores = [s for s in (data.get("stores") or []) if isinstance(s, dict)]

        def from_obj(obj: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
            sid = obj.get("id") or obj.get("storeId")
            name = obj.get("name") or obj.get("storeName")
            if sid and not name:
                for s in stores:
                    if str(s.get("id") or s.get("storeId")) == str(sid):
                        name = s.get("name") or s.get("storeName")
                        break
            return (str(sid) if sid else None, str(name) if name else None)

        active = data.get("active")
        if isinstance(active, dict):
            sid, name = from_obj(active)
            if sid:
                return sid, name, notes
            notes.append("stores.json 的 active 对象里没有 id")
        elif isinstance(active, str) and active.strip():
            for s in stores:
                if str(s.get("id")) == active.strip():
                    sid, name = from_obj(s)
                    if sid:
                        return sid, name, notes
            sid, name = from_obj({"id": active.strip()})
            notes.append("active 指向的 storeId 在 stores 列表里找不到，已按 id 返回 name=null")
            return sid, None, notes
        else:
            notes.append("stores.json 里没有 `active` 字段")

        # 兼容插件实际写法：activeStoreId / activeStore
        for key in ("activeStoreId", "activeStore"):
            val = data.get(key)
            if isinstance(val, str) and val.strip():
                for s in stores:
                    if str(s.get("id") or s.get("storeId")) == val.strip():
                        sid, name = from_obj(s)
                        notes.append("active 缺失，回退到 stores.json 的 {0}".format(key))
                        return sid, name, notes
                notes.append("{0}={1} 在 stores 列表里找不到".format(key, val.strip()))
                return val.strip(), None, notes
        if len(stores) == 1:
            sid, name = from_obj(stores[0])
            notes.append("没有 active/activeStoreId，只有一家店，按唯一店铺返回")
            return sid, name, notes
        notes.append("stores.json 里没有 active/activeStoreId，且有 {0} 家店，无法判定".format(
            len(stores)))
        return None, None, notes

    def settings(self) -> Tuple[Dict[str, Any], bool, List[str]]:
        """settings 只读 state/settings.json（没有就全 false）。返回 (settings, fromFile, notes)。"""
        data, reason = self.read_json("settings.json", None)
        if reason or not isinstance(data, dict):
            return {"autoLockCategory": False, "autoPolishTitle": False}, False, [
                reason or "settings.json 顶层不是对象"
            ]
        return {
            "autoLockCategory": bool(data.get("autoLockCategory", False)),
            "autoPolishTitle": bool(data.get("autoPolishTitle", False)),
        }, True, []


class StateError(Exception):
    pass


def uuid4_hex() -> str:
    return "%08x" % random.getrandbits(32)


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log(msg: str) -> None:
    sys.stderr.write("[{0}] {1}\n".format(datetime.now().strftime("%H:%M:%S"), msg))
    sys.stderr.flush()


# ---------------------------------------------------------------------------
# 行/草稿字段工具
# ---------------------------------------------------------------------------
def as_text(val: Any) -> Optional[str]:
    if val is None:
        return None
    if isinstance(val, (int, float, bool)):
        return str(val)
    if isinstance(val, str):
        s = val.strip()
        return s or None
    return None


def as_num(val: Any) -> Optional[float]:
    if isinstance(val, bool) or val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        s = val.strip().replace("R", "").replace("r", "").replace(",", "")
        try:
            return float(s)
        except ValueError:
            return None
    return None


def normalize_images(val: Any) -> List[str]:
    out: List[str] = []
    if isinstance(val, str):
        val = [val]
    if isinstance(val, list):
        for x in val:
            s = as_text(x)
            if s:
                out.append(s)
    seen = set()
    uniq: List[str] = []
    for u in out:
        if u not in seen:
            seen.add(u)
            uniq.append(u)
    return uniq


def norm_key(val: Any) -> Optional[str]:
    """去重用的规范化键：大小写无关、去掉空白/分隔符。"""
    s = as_text(val)
    if not s:
        return None
    return "".join(ch for ch in s.lower() if ch.isalnum())


def collection_dedupe_keys(row: Dict[str, Any]) -> Dict[str, Optional[str]]:
    keys = {
        "tsin": norm_key(row.get("tsin")),
        "plid": norm_key(row.get("plid")),
        "barcode": norm_key(row.get("barcode")),
    }
    title = norm_key(row.get("title"))
    url = norm_key(row.get("sourceUrl"))
    if title:
        keys["text"] = "{0}|{1}".format(title, url or "")
    return {k: v for k, v in keys.items() if v}


def draft_fields(row: Dict[str, Any]) -> Dict[str, Any]:
    """把任意形状的草稿行归一成 fields 子字典（缺的给 None，不编）。"""
    raw = row.get("fields")
    fields: Dict[str, Any] = dict(raw) if isinstance(raw, dict) else {}
    attrs = row.get("attributes")
    if "attributes" not in fields and isinstance(attrs, dict):
        fields["attributes"] = dict(attrs)
    # 扁平镜像补回 fields
    for key in DRAFT_FIELD_KEYS:
        if key not in fields and key in row:
            fields[key] = row.get(key)
    # 旧行的同义字段映射（只做真实存在的键，不猜值）
    if fields.get("images") in (None, [], "") and row.get("images"):
        fields["images"] = row.get("images")
    if fields.get("lowestCategory") in (None, "") and row.get("lowestCategory"):
        fields["lowestCategory"] = row.get("lowestCategory")
    if fields.get("mainCategory") in (None, "") and row.get("mainCategory"):
        fields["mainCategory"] = row.get("mainCategory")
    if fields.get("warrantyPeriod") in (None, "") and row.get("warrantyPeriod") not in (None, ""):
        fields["warrantyPeriod"] = row.get("warrantyPeriod")
    if fields.get("warrantyType") in (None, "") and row.get("warrantyType"):
        fields["warrantyType"] = row.get("warrantyType")
    return fields


def completeness(fields: Dict[str, Any]) -> Dict[str, Any]:
    """按官方装载表的必填列算完整度：列出缺哪些列名。"""
    images = normalize_images(fields.get("images"))
    warranty_period = fields.get("warrantyPeriod")
    if warranty_period in (None, "", 0, "0"):
        warranty_period = fields.get("warrantyPeriodMonths")
    checks = {
        "mainCategory": as_text(fields.get("mainCategory")) or as_text(fields.get("category")),
        "lowestCategory": as_text(fields.get("lowestCategory")) or (
            as_text(fields.get("categoryPath")).split(">")[-1].strip()
            if as_text(fields.get("categoryPath")) else None
        ),
        "title": as_text(fields.get("title")),
        "features": as_text(fields.get("features")),
        "barcode": as_text(fields.get("barcode")),
        "mainImage": images[0] if images else None,
        "warrantyType": as_text(fields.get("warrantyType")),
        "warrantyPeriod": as_text(warranty_period),
    }
    present = [header for key, header in REQUIRED_COLUMNS if checks.get(key)]
    missing = [header for key, header in REQUIRED_COLUMNS if not checks.get(key)]
    total = len(REQUIRED_COLUMNS)
    return {
        "missing": missing,
        "present": present,
        "requiredCount": total,
        "presentCount": len(present),
        "percent": int(round(100.0 * len(present) / total)) if total else 100,
        "complete": not missing,
        "imageCount": len(images),
    }


def draft_view(row: Dict[str, Any]) -> Dict[str, Any]:
    """统一对外形状。缺字段 → null。"""
    fields = draft_fields(row)
    images = normalize_images(fields.get("images"))
    state = as_text(row.get("state")) or as_text(row.get("status")) or "drafting"
    if state == "draft":
        state = "drafting"
    comp = row.get("completeness") if isinstance(row.get("completeness"), dict) else None
    calc = completeness(fields)
    if comp and isinstance(comp.get("missing"), list):
        comp = dict(comp)
    else:
        comp = calc
    return {
        "id": as_text(row.get("id")),
        "title": as_text(fields.get("title")),
        "sku": as_text(fields.get("sku")),
        "barcode": as_text(fields.get("barcode")),
        "images": images,
        "completeness": comp,
        "state": state,
        "source": as_text(row.get("source")) or "state/drafts.json",
        "updatedAt": as_text(row.get("updatedAt")),
        "fields": {
            "title": as_text(fields.get("title")),
            "subtitle": as_text(fields.get("subtitle")),
            "features": as_text(fields.get("features")),
            "whatsInTheBox": as_text(fields.get("whatsInTheBox")),
            "brand": as_text(fields.get("brand")),
            "model": as_text(fields.get("model")),
            "price": as_num(fields.get("price")),
            "rrp": as_num(fields.get("rrp")),
            "leadtime": as_num(fields.get("leadtime")),
            "barcode": as_text(fields.get("barcode")),
            "images": images,
            "attributes": fields.get("attributes") if isinstance(fields.get("attributes"), dict) else {},
        },
    }


# ---------------------------------------------------------------------------
# 采集箱 / 草稿箱 业务
# ---------------------------------------------------------------------------
def collection_row_from_payload(body: Dict[str, Any]) -> Dict[str, Any]:
    images = normalize_images(body.get("images") or body.get("imageUrl") or body.get("image"))
    source_url = as_text(body.get("url")) or as_text(body.get("sourceUrl")) or as_text(
        body.get("productUrl"))
    price = as_num(body.get("price"))
    if price is None:
        price = as_num(body.get("selling_price"))
    est = as_num(body.get("estSalePrice"))
    if est is None:
        est = as_num(body.get("suggestedPrice"))
    stock = as_num(body.get("stock"))
    if stock is None:
        stock = as_num(body.get("qty"))
    row = {
        "id": "COL-{0}-{1}".format(int(time.time() * 1000), random.randint(1000, 9999)),
        "intent": "follow",
        "state": "pool",
        "source": "extension",
        "savedAt": now_str(),
        "title": as_text(body.get("title")),
        "sku": as_text(body.get("sku")),
        "tsin": as_text(body.get("tsin")),
        "plid": as_text(body.get("plid")),
        "barcode": as_text(body.get("barcode")),
        "imageUrl": images[0] if images else None,
        "images": images,
        "sourceUrl": source_url,
        "price": price,
        "stock": stock,
        "estSalePrice": est,
        "brand": as_text(body.get("brand")),
        "category": as_text(body.get("category")),
        "categoryPath": as_text(body.get("categoryPath") or body.get("suggestedCategory")),
        "attributes": body.get("attributes") if isinstance(body.get("attributes"), dict) else None,
    }
    # 其它原始键原样留档（不丢采集现场），但放在 raw 里，不和行字段混。
    known = set(row) | {"images", "url", "sourceUrl", "productUrl", "imageUrl", "image",
                        "selling_price", "qty", "suggestedPrice", "estSalePrice"}
    extra = {k: v for k, v in body.items() if k not in known}
    if extra:
        row["raw"] = extra
    return row


def collection_row_view(row: Dict[str, Any]) -> Dict[str, Any]:
    images = normalize_images(row.get("images"))
    return {
        "id": as_text(row.get("id")),
        "intent": as_text(row.get("intent")) or "follow",
        "state": as_text(row.get("state")),
        "title": as_text(row.get("title")),
        "sku": as_text(row.get("sku")),
        "tsin": as_text(row.get("tsin")),
        "plid": as_text(row.get("plid")),
        "barcode": as_text(row.get("barcode")),
        "imageUrl": as_text(row.get("imageUrl")) or (images[0] if images else None),
        "images": images,
        "sourceUrl": as_text(row.get("sourceUrl")),
        "price": as_num(row.get("price")),
        "stock": as_num(row.get("stock")),
        "estSalePrice": as_num(row.get("estSalePrice")),
        "source": as_text(row.get("source")),
        "savedAt": as_text(row.get("savedAt")),
        "brand": as_text(row.get("brand")),
        "category": as_text(row.get("category")),
        "categoryPath": as_text(row.get("categoryPath")),
        "draftId": as_text(row.get("draftId")),
    }


def draft_row_from_collection(col: Dict[str, Any], draft_id: str) -> Dict[str, Any]:
    """采集行 → 草稿行的初始映射。只搬真实存在的值，其余留 None。"""
    images = normalize_images(col.get("images"))
    category = as_text(col.get("category"))
    category_path = as_text(col.get("categoryPath"))
    attributes: Dict[str, Any] = {}
    if category_path:
        attributes["Takealot Category Path"] = category_path
    if isinstance(col.get("attributes"), dict):
        attributes.update(col["attributes"])
    fields: Dict[str, Any] = {
        "title": as_text(col.get("title")),
        "subtitle": None,
        "features": None,          # 文案由插件/人在草稿里生成，桥不编
        "whatsInTheBox": None,
        "brand": as_text(col.get("brand")),
        "model": None,
        "price": as_num(col.get("price")) if as_num(col.get("price")) is not None
                 else as_num(col.get("estSalePrice")),
        "rrp": None,
        "leadtime": None,
        "barcode": as_text(col.get("barcode")),
        "images": images,
        "attributes": attributes,
        "sku": as_text(col.get("sku")),
        "tsin": as_text(col.get("tsin")),
        "category": category,
        "categoryPath": category_path,
        "mainCategory": category,
        "lowestCategory": category_path.split(">")[-1].strip() if category_path else None,
    }
    if as_num(col.get("stock")) is not None:
        fields["qty"] = as_num(col.get("stock"))
    draft: Dict[str, Any] = {
        "id": draft_id,
        "source": "collection:{0}".format(as_text(col.get("id")) or "?"),
        "fromCollection": as_text(col.get("id")),
        "fields": fields,
        "completeness": completeness(fields),
        "state": "drafting",
        "updatedAt": now_str(),
    }
    for key in FLAT_MIRROR_KEYS:  # 插件按扁平结构读 drafts.json
        if key in fields and fields[key] is not None:
            draft[key] = fields[key]
    return draft


def merge_draft_fields(row: Dict[str, Any], incoming: Dict[str, Any]) -> Dict[str, Any]:
    """部分字段合并：只覆盖传来的键，其它键（含插件自有键）原样保留。"""
    fields = draft_fields(row)
    changed: List[str] = []
    for key, val in incoming.items():
        if isinstance(val, dict) and isinstance(fields.get(key), dict):
            merged = dict(fields[key])
            merged.update(val)
            fields[key] = merged
        else:
            fields[key] = val
        changed.append(key)
    row["fields"] = fields
    for key in FLAT_MIRROR_KEYS:
        if key in changed and key in fields:
            if fields[key] is None:
                row.pop(key, None)
            else:
                row[key] = fields[key]
    row["completeness"] = completeness(fields)
    return row


# ---------------------------------------------------------------------------
# 类目属性模板：入库前清洗（只接受认识的形状；不认识就报错，绝不编造）
#
# 输入 = 扩展归一后的 ingest 形状（扩展侧 shared/template_sync.js 已做官方原始形状 →
# 本形状的映射）。桥这一层再独立校验一次：宁可少收，也不把结构不对的条目写进 state
# 给插件当"官方模板"用。
# ---------------------------------------------------------------------------
def attr_field_node(raw: Any) -> Optional[Dict[str, Any]]:
    """单个字段定义。fields 里的值必须是对象，否则丢弃（返回 None）。"""
    if not isinstance(raw, dict):
        return None
    fid = as_text(raw.get("fieldId"))
    if not fid:
        return None
    node: Dict[str, Any] = {"fieldId": fid}
    for key in ("fieldType", "displayName", "description"):
        val = raw.get(key)
        node[key] = as_text(val) if val is not None else None
    node["isRequired"] = bool(raw.get("isRequired")) if raw.get("isRequired") is not None else False
    if isinstance(raw.get("options"), list):
        node["options"] = raw["options"]  # 官方 options 是 [[label, code, sort]…]，原样透传
    return node


def attr_field_map(raw: Any) -> Dict[str, Any]:
    """{fieldId:{...}}；键以字段自己的 fieldId 为准，缺失的条目丢弃。"""
    out: Dict[str, Any] = {}
    if not isinstance(raw, dict):
        return out
    for key, val in raw.items():
        node = attr_field_node(val)
        if node is None:
            continue
        out[node["fieldId"]] = node
    return out


def attr_categories(raw: Any) -> Dict[str, Any]:
    """{taxonomyId:{taxonomy_id, name, requirements:[fieldId]}}；结构不对的条目丢弃。"""
    out: Dict[str, Any] = {}
    if not isinstance(raw, dict):
        return out
    for key, val in raw.items():
        if not isinstance(val, dict):
            continue
        try:
            tax: Any = int(str(key).strip())
        except (TypeError, ValueError):
            tax = as_text(key)
        entry: Dict[str, Any] = {"taxonomy_id": tax, "name": as_text(val.get("name"))}
        reqs = [as_text(x) for x in (val.get("requirements") or []) if as_text(x)]
        entry["requirements"] = reqs
        out[str(key)] = entry
    return out


def attr_loadsheet_node(ls_id: str, raw: Any) -> Optional[Dict[str, Any]]:
    """单个装载表节点；没有 fields 的不算可用模板，返回 None（由调用方点名报出）。"""
    if not isinstance(raw, dict):
        return None
    fields = attr_field_map(raw.get("fields"))
    if not fields:
        return None
    return {
        "name": as_text(raw.get("name")) or "",
        "fields": fields,
        "variant_fields": attr_field_map(raw.get("variant_fields")),
        "template_defaults": raw.get("template_defaults") if isinstance(raw.get("template_defaults"), dict) else {},
        "categories": attr_categories(raw.get("categories")),
    }


def attr_clean_loadsheets(body: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str], List[str]]:
    """返回 (可用装载表, 被丢弃的 id, 丢弃原因)。只接受 {loadsheets:{id:node}}。"""
    incoming = body.get("loadsheets")
    if not isinstance(incoming, dict):
        # 注意：这条消息里有字面量大括号，不能走 str.format（会把 {loadsheets} 当占位符）
        raise BridgeError(400, "body 需要 {loadsheets:{<装载表id>:{fields:{<fieldId>:{…}}}}}；收到了 " +
                          json.dumps(sorted(body.keys())[:8], ensure_ascii=False) +
                          "（loadsheets 必须是对象，不是数组/字符串）")
    keep: Dict[str, Any] = {}
    skipped: List[str] = []
    reasons: List[str] = []
    for lid, node in incoming.items():
        sid = as_text(lid)
        if not sid:
            continue
        cleaned = attr_loadsheet_node(sid, node)
        if cleaned is None:
            skipped.append(sid)
            reasons.append("{0} 没有可用的 fields（该装载表未采集到字段定义）".format(sid))
            continue
        keep[sid] = cleaned
    return keep, skipped, reasons


def attr_catalog(body: Dict[str, Any]) -> Dict[str, Any]:
    """可选的装载表目录 {id:{name,dept}}，只用于算「N/总数」进度，不参与属性反查。"""
    raw = body.get("templates")
    out: Dict[str, Any] = {}
    if not isinstance(raw, dict):
        return out
    for key, val in raw.items():
        sid = as_text(key)
        if not sid:
            continue
        if isinstance(val, dict):
            out[sid] = {"name": as_text(val.get("name")) or "",
                        "dept": as_text(val.get("dept")) or ""}
        elif isinstance(val, str):
            out[sid] = {"name": val, "dept": ""}
    return out


def attr_raw_payload(body: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str], List[str]]:
    """原始响应留档：**只**保留白名单字段，凭证类键名一律拒绝并点名。

    返回 (要落盘的对象, 被拒的键名, 被忽略的键名)。
    rawText 上限 ATTR_RAW_LIMIT_BYTES（按 UTF-8 字节算），超限截断 + truncated:true；
    bytes = 官方实际返回的字节数，storedBytes = 实际落盘的字节数（截断时可区分）。
    """
    raw_text = body.get("rawText")
    if raw_text is None:
        raise BridgeError(400, "body 需要 rawText（官方响应体原文，字符串）")
    if isinstance(raw_text, (dict, list)):
        # 调用方已经把响应体 parse 过了：序列化回文本，如实标注来源，不丢信息
        raw_text = json.dumps(raw_text, ensure_ascii=False)
        text_from = "object"
    elif isinstance(raw_text, str):
        text_from = "string"
    else:
        raise BridgeError(400, "rawText 必须是字符串（官方响应体原文）")

    forbidden: List[str] = []
    ignored: List[str] = []
    for key in body.keys():
        low = str(key).strip().lower()
        if low in ATTR_RAW_FORBIDDEN_KEYS:
            forbidden.append(str(key))
        elif str(key) not in ATTR_RAW_KEEP_KEYS:
            ignored.append(str(key))
    if forbidden:
        raise BridgeError(400, "拒绝落盘：body 里出现了凭证/请求头类字段 "
                               "（" + "、".join(sorted(forbidden)) + "）。本接口只存响应体原文，"
                               "不存任何 Authorization/JWT/cookie/headers。",
                          {"rejectedKeys": sorted(forbidden)})

    encoded = raw_text.encode("utf-8")
    total = len(encoded)
    truncated = total > ATTR_RAW_LIMIT_BYTES
    if truncated:
        # 按字节切，再按 UTF-8 容错解码，保证不产生半个汉字
        raw_text = encoded[:ATTR_RAW_LIMIT_BYTES].decode("utf-8", errors="ignore")
        encoded = raw_text.encode("utf-8")
    try:
        declared = int(body.get("bytes")) if body.get("bytes") is not None else total
    except (TypeError, ValueError):
        declared = total
    payload: Dict[str, Any] = {
        "fetchedAt": as_text(body.get("fetchedAt")) or now_str(),
        "url": as_text(body.get("url")) or "",
        "via": as_text(body.get("via")) or "",
        "status": body.get("status") if isinstance(body.get("status"), int) else None,
        "contentType": as_text(body.get("contentType")) or "",
        "bytes": max(declared, total),
        "storedBytes": len(encoded),
        "truncated": truncated,
        "limitBytes": ATTR_RAW_LIMIT_BYTES,
        "textFrom": text_from,
        "rawText": raw_text,
        "note": ("官方 /v1/loadsheets/templates 原始响应留档：只含响应体，"
                 "不含任何请求头/凭证。归一化遇到不认识形状时用它离线修。"),
    }
    return payload, [], ignored


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------
class BridgeError(Exception):
    def __init__(self, status: int, message: str, extra: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.extra = extra or {}


class Handler(BaseHTTPRequestHandler):
    server_version = "hermes-erp-bridge/{0}".format(VERSION)
    protocol_version = "HTTP/1.1"

    # -- 基础设施 ----------------------------------------------------------
    @property
    def store(self) -> StateStore:
        return self.server.store  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: Any) -> None:  # noqa: A003
        log("{0} {1}".format(self.address_string(), fmt % args))

    def _cors_origin(self) -> Optional[str]:
        origin = self.headers.get("Origin")
        if not origin:
            return None
        if origin in ALLOWED_ORIGIN_EXACT or origin.startswith(ALLOWED_ORIGIN_PREFIX):
            return origin
        return None

    def _send(self, status: int, payload: Dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        origin = self._cors_origin()
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:  # noqa: BLE001 - 客户端断开
            pass

    def _read_body(self, max_bytes: Optional[int] = None) -> Dict[str, Any]:
        limit = MAX_BODY_BYTES if max_bytes is None else max_bytes
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise BridgeError(400, "Content-Length 不是数字")
        if length <= 0:
            return {}
        if length > limit:
            raise BridgeError(413, "请求体过大（>{0} 字节）".format(limit))
        raw = self.rfile.read(length)
        if not raw.strip():
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise BridgeError(400, "请求体不是合法 JSON：{0}".format(exc))
        if not isinstance(data, dict):
            raise BridgeError(400, "请求体必须是 JSON 对象")
        return data

    def _require_writable(self) -> None:
        if not self.store.writable:
            raise BridgeError(503, "桥以只读模式运行，写接口不可用：{0}".format(
                self.store.writable_reason))

    # -- 路由 --------------------------------------------------------------
    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(204)
        origin = self._cors_origin()
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        self._dispatch("GET")

    def do_POST(self) -> None:  # noqa: N802
        self._dispatch("POST")

    def _dispatch(self, method: str) -> None:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        query = parse_qs(parsed.query)
        try:
            if path == "/takealot/api/health" and method == "GET":
                return self._send(200, self.h_health())
            if path == "/takealot/api/takealot/init-data" and method == "GET":
                return self._send(200, self.h_init_data())
            if path == "/takealot/api/collection/pending" and method == "GET":
                return self._send(200, self.h_collection_pending(query))
            if path == "/takealot/api/collection/add" and method == "POST":
                return self._send(200, self.h_collection_add())
            if path == "/takealot/api/collection/update" and method == "POST":
                return self._send(200, self.h_collection_update())
            if path == "/takealot/api/collection/promote" and method == "POST":
                return self._send(200, self.h_collection_promote())
            if path == "/takealot/api/listing/drafts" and method == "GET":
                return self._send(200, self.h_listing_drafts())
            if path == "/takealot/api/listing/draft" and method == "POST":
                return self._send(200, self.h_listing_draft())
            if path == "/takealot/api/attributes/ingest" and method == "POST":
                return self._send(200, self.h_attributes_ingest())
            if path == "/takealot/api/attributes/raw" and method == "POST":
                return self._send(200, self.h_attributes_raw())
            if path == "/takealot/api/attributes/status" and method == "GET":
                return self._send(200, self.h_attributes_status())
            if path == "/":
                return self._send(200, {
                    "ok": True, "source": SOURCE, "version": VERSION,
                    "endpoints": [
                        "GET  /takealot/api/health",
                        "GET  /takealot/api/takealot/init-data",
                        "GET  /takealot/api/collection/pending",
                        "POST /takealot/api/collection/add",
                        "POST /takealot/api/collection/update",
                        "POST /takealot/api/collection/promote",
                        "GET  /takealot/api/listing/drafts",
                        "POST /takealot/api/listing/draft",
                        "POST /takealot/api/attributes/ingest",
                        "POST /takealot/api/attributes/raw",
                        "GET  /takealot/api/attributes/status",
                    ],
                })
            raise BridgeError(404, "没有这个接口：{0} {1}".format(method, path))
        except BridgeError as exc:
            payload: Dict[str, Any] = {"ok": False, "source": SOURCE, "error": exc.message}
            payload.update(exc.extra)
            self._send(exc.status, payload)
        except StateError as exc:
            self._send(409, {"ok": False, "source": SOURCE, "error": str(exc)})
        except Exception as exc:  # noqa: BLE001 - 不把堆栈里的敏感内容回给扩展
            log("ERROR {0} {1}: {2}\n{3}".format(method, path, exc, traceback.format_exc()))
            self._send(500, {"ok": False, "source": SOURCE,
                             "error": "{0}: {1}".format(type(exc).__name__, exc)})

    # -- 1. /health --------------------------------------------------------
    def h_health(self) -> Dict[str, Any]:
        st: StateStore = self.store
        return {
            "ok": True,
            "source": SOURCE,
            "version": VERSION,
            "uptimeSec": round(time.time() - self.server.started_at, 3),  # type: ignore[attr-defined]
            "statePath": st.state_dir,
            "writable": st.writable,
            "writableReason": st.writable_reason,
            "auditDisabledReason": st.audit_disabled_reason,
        }

    # -- 2. /init-data -----------------------------------------------------
    def h_init_data(self) -> Dict[str, Any]:
        st = self.store
        collection, col_reason = st.read_rows("collection.json")
        drafts, drf_reason = st.read_rows("drafts.json")
        store_id, store_name, store_notes = st.active_store()
        settings, from_file, settings_notes = st.settings()
        notes = [n for n in ([col_reason] if col_reason else []) +
                 ([drf_reason] if drf_reason else []) + store_notes + settings_notes if n]
        return {
            "ok": True,
            "source": SOURCE,
            "version": VERSION,
            "storeId": store_id,
            "storeName": store_name,
            "counts": {"collection": len(collection), "drafts": len(drafts)},
            "settings": settings,
            "settingsFromFile": from_file,
            "statePath": st.state_dir,
            "writable": st.writable,
            "notes": notes,
        }

    # -- 3. /collection/pending -------------------------------------------
    def h_collection_pending(self, query: Dict[str, List[str]]) -> Dict[str, Any]:
        rows, reason = self.store.read_rows("collection.json")
        include_promoted = str((query.get("all") or ["0"])[0]).lower() in ("1", "true", "yes")
        promoted = [r for r in rows if as_text(r.get("state")) == "promoted"]
        items = rows if include_promoted else [r for r in rows if as_text(r.get("state")) != "promoted"]
        payload: Dict[str, Any] = {
            "ok": reason is None,
            "source": SOURCE,
            "count": len(items),
            "items": [collection_row_view(r) for r in items],
            "total": len(rows),
            "excluded": {"promoted": len(promoted)},
            "includePromoted": include_promoted,
        }
        if reason:
            payload["error"] = reason
            payload["reason"] = reason
        elif promoted and not include_promoted:
            payload["note"] = ("已排除 {0} 条 state='promoted' 的行（已转草稿，不再跟卖）；"
                               "要看全部加 ?all=1".format(len(promoted)))
        return payload

    # -- 4. /collection/add ------------------------------------------------
    def h_collection_add(self) -> Dict[str, Any]:
        self._require_writable()
        body = self._read_body()
        if not body:
            raise BridgeError(400, "请求体为空；至少要给 title/tsin/plid/barcode/url 之一")
        candidate = collection_row_from_payload(body)
        if not any(candidate.get(k) for k in ("title", "tsin", "plid", "barcode", "sourceUrl")):
            raise BridgeError(400, "缺可识别字段：至少要有 title / tsin / plid / barcode / url 之一，"
                                   "否则无法采集也无法去重")
        new_keys = collection_dedupe_keys(candidate)

        def work(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
            for row in rows:
                existing = collection_dedupe_keys(row)
                hit = [k for k in new_keys if k in existing and new_keys[k] == existing[k]]
                if hit:
                    return {"deduped": True, "item": row, "matchedOn": hit}
            rows.append(candidate)
            return {"deduped": False, "item": candidate, "matchedOn": []}

        result = self.store.mutate_rows("collection.json", work)
        item = result["item"]
        self.store.append_audit(
            "collection.add",
            item.get("id"),
            {"deduped": result["deduped"], "matchedOn": result["matchedOn"],
             "keys": sorted(collection_dedupe_keys(candidate).keys())},
            "extension",
        )
        rows_after, _ = self.store.read_rows("collection.json")
        out: Dict[str, Any] = {
            "ok": True,
            "source": SOURCE,
            "deduped": bool(result["deduped"]),
            "id": item.get("id"),
            "item": collection_row_view(item),
            "count": len(rows_after),
        }
        if result["deduped"]:
            out["matchedOn"] = result["matchedOn"]
            out["note"] = "已存在同一商品（按 {0} 去重），返回已存在行".format(
                "/".join(result["matchedOn"]))
        return out

    # -- 5. /collection/update --------------------------------------------
    def h_collection_update(self) -> Dict[str, Any]:
        self._require_writable()
        body = self._read_body()
        entry_id = as_text(body.get("id"))
        if not entry_id:
            raise BridgeError(400, "缺 id：跟卖改价必须指定要改的采集行")
        rejected = sorted(k for k in body.keys() if k not in COLLECTION_WRITE_WHITELIST)
        if rejected:
            raise BridgeError(400,
                "跟卖只能改价格与库存（平台不允许修改 listing 内容）",
                {"error": "跟卖只能改价格与库存（平台不允许修改 listing 内容）",
                 "rejectedFields": rejected,
                 "allowedFields": list(COLLECTION_WRITE_WHITELIST),
                 "reason": ("采集箱 = 跟卖池：商品在平台上已存在（TSIN/条码），"
                            "Takealot CreateOfferRequest 不含标题/图片/描述/类目字段，"
                            "listing 内容只能在 Seller Portal 由平台侧维护。")})
        if "price" not in body and "stock" not in body:
            raise BridgeError(400, "没有要改的字段：至少给 price 或 stock 之一")
        changes: Dict[str, Any] = {}
        if "price" in body:
            price = as_num(body.get("price"))
            if price is None or price < 0:
                raise BridgeError(400, "price 必须是非负数字，收到：{0!r}".format(body.get("price")))
            changes["price"] = price
        if "stock" in body:
            stock = as_num(body.get("stock"))
            if stock is None or stock < 0 or float(stock) != int(stock):
                raise BridgeError(400, "stock 必须是非负整数，收到：{0!r}".format(body.get("stock")))
            changes["stock"] = int(stock)

        def work(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
            for row in rows:
                if as_text(row.get("id")) == entry_id:
                    for key, val in changes.items():
                        row[key] = val
                    row["updatedAt"] = now_str()
                    return {"found": True, "row": row}
            return {"found": False, "row": None}

        result = self.store.mutate_rows("collection.json", work)
        if not result["found"]:
            raise BridgeError(404, "采集箱里没有 id={0} 的行".format(entry_id))
        self.store.append_audit("collection.update", entry_id, changes, "extension")
        # 回读（不信内存里的对象）作为证据
        rows_after, _ = self.store.read_rows("collection.json")
        row = next((r for r in rows_after if as_text(r.get("id")) == entry_id), result["row"])
        return {"ok": True, "source": SOURCE, "changed": changes, "item": collection_row_view(row)}

    # -- 6. /collection/promote -------------------------------------------
    def h_collection_promote(self) -> Dict[str, Any]:
        self._require_writable()
        body = self._read_body()
        entry_id = as_text(body.get("id"))
        if not entry_id:
            raise BridgeError(400, "缺 id：promote 必须指定采集行")
        draft_id = as_text(body.get("draftId")) or "DRF-{0}-{1}".format(
            int(time.time() * 1000), random.randint(1000, 9999))
        with self.store.lock:
            col_rows, _ = self.store.read_rows("collection.json")
            col = next((r for r in col_rows if as_text(r.get("id")) == entry_id), None)
            if col is None:
                raise BridgeError(404, "采集箱里没有 id={0} 的行".format(entry_id))
            draft = draft_row_from_collection(col, draft_id)
            if col.get("state") == "promoted" and as_text(col.get("draftId")):
                raise BridgeError(409,
                    "这行已经转过草稿了（state='promoted', draftId={0}）；"
                    "采集箱与草稿箱不共享行，重复 promote 不允许".format(col.get("draftId")),
                    {"id": entry_id, "draftId": col.get("draftId")})
            self.store.mutate_rows("drafts.json", lambda rows: rows.append(draft))

            def mark(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
                for row in rows:
                    if as_text(row.get("id")) == entry_id:
                        row["state"] = "promoted"
                        row["draftId"] = draft_id
                        row["promotedAt"] = now_str()
                        return {"row": row}
                return {"row": None}

            marked = self.store.mutate_rows("collection.json", mark)
            self.store.append_audit("collection.promote", entry_id,
                                    {"draftId": draft_id, "from": "collection", "to": "drafts"},
                                    "extension")
        col_row = marked.get("row") or col
        return {
            "ok": True,
            "source": SOURCE,
            "draftId": draft_id,
            "item": collection_row_view(col_row),
            "draft": draft_view(draft),
        }

    # -- 7. /listing/drafts ------------------------------------------------
    def h_listing_drafts(self) -> Dict[str, Any]:
        rows, reason = self.store.read_rows("drafts.json")
        payload: Dict[str, Any] = {
            "ok": reason is None,
            "source": SOURCE,
            "count": len(rows),
            "drafts": [draft_view(r) for r in rows],
        }
        if reason:
            payload["error"] = reason
            payload["reason"] = reason
        return payload

    # -- 8. /listing/draft (upsert，断点续存) ------------------------------
    def h_listing_draft(self) -> Dict[str, Any]:
        self._require_writable()
        body = self._read_body()
        entry_id = as_text(body.get("id"))
        incoming = body.get("fields")
        if isinstance(incoming, dict):
            fields = dict(incoming)
        else:  # 扩展也可能直接把扁平 draft 对象丢进来
            fields = {k: v for k, v in body.items()
                      if k not in ("id", "state", "source", "completeness", "updatedAt")}
        if not fields:
            raise BridgeError(400, "没有可保存的字段：body 需要 {id?, fields:{...}}")

        created = False
        with self.store.lock:
            rows, _ = self.store.read_rows("drafts.json")
            if entry_id:
                row = next((r for r in rows if as_text(r.get("id")) == entry_id), None)
                if row is None:
                    created = True
            else:
                entry_id = "DRF-{0}-{1}".format(int(time.time() * 1000), random.randint(1000, 9999))
                row = None
                created = True

            def work(rws: List[Dict[str, Any]]) -> Dict[str, Any]:
                target = None
                if not created:
                    target = next((r for r in rws if as_text(r.get("id")) == entry_id), None)
                if target is None:
                    target = {"id": entry_id, "source": "extension", "state": "drafting",
                              "fields": {}, "createdAt": now_str()}
                    rws.append(target)
                merge_draft_fields(target, fields)
                if as_text(body.get("state")):
                    target["state"] = as_text(body.get("state"))
                target["updatedAt"] = now_str()
                return target

            saved = self.store.mutate_rows("drafts.json", work)
        self.store.append_audit("listing.draft.save", entry_id,
                                {"created": created, "keys": sorted(fields.keys())}, "extension")
        rows_after, _ = self.store.read_rows("drafts.json")
        row = next((r for r in rows_after if as_text(r.get("id")) == entry_id), saved)
        view = draft_view(row)
        return {
            "ok": True,
            "source": SOURCE,
            "created": created,
            "id": entry_id,
            "draft": view,
            "completeness": view["completeness"],
        }

    # -- 9. /attributes/ingest --------------------------------------------
    def h_attributes_ingest(self) -> Dict[str, Any]:
        """接收扩展在商家后台页面带会话抓到的官方类目属性模板，桥自己原子落盘。

        为什么不转发插件后端的 /meta/attributes/ingest：桥没有插件后端（ERP）的会话
        token，转发必然 401。这里直接写**同一个 state 文件**（插件 `plugin_api.py` 的
        ATTR_INGEST_FILE 同名同目录），语义与插件一致：以装载表 id 为键、读-合并-原子替换；
        插件之后自己再 ingest 同名条目也会覆盖，两边不会互相拆台。

        只收认识的形状（{loadsheets:{id:{fields:{…}}}}）；节点缺 fields 的点名丢弃并回报，
        不编造、不猜测。
        """
        self._require_writable()
        body = self._read_body(max_bytes=MAX_ATTR_BODY_BYTES)
        if not body:
            raise BridgeError(400, "请求体为空；需要 {source?, loadsheets:{<装载表id>:{fields:{…}}}}")
        keep, skipped, reasons = attr_clean_loadsheets(body)
        if not keep:
            raise BridgeError(400, "没有任何可用的装载表（loadsheets 里的节点都缺 fields）",
                              {"accepted": 0, "skipped": skipped[:20], "reasons": reasons[:5]})
        catalog = attr_catalog(body)
        source = as_text(body.get("source")) or ATTR_TEMPLATES_SOURCE_DEFAULT
        fetched_at = as_text(body.get("fetchedAt")) or now_str()
        added: List[str] = []
        covered_before = [0]

        def work(data: Dict[str, Any]) -> None:
            merged = data.get("loadsheets")
            merged = dict(merged) if isinstance(merged, dict) else {}
            covered_before[0] = len(merged)
            existing = set(merged.keys())
            merged.update(keep)
            added.extend(sorted(set(merged) - existing))
            old_catalog = data.get("templates")
            old_meta = data.get("_meta") if isinstance(data.get("_meta"), dict) else {}
            data.clear()
            data["_meta"] = {
                "source": source,
                "updatedAt": fetched_at,
                "ingestedAt": now_str(),
                "via": as_text(body.get("via")) or "",
                "loadsheetsCovered": len(merged),
                "note": ATTR_TEMPLATES_NOTE,
            }
            data["loadsheets"] = merged
            if catalog:
                data["templates"] = catalog
            elif isinstance(old_catalog, dict):
                data["templates"] = old_catalog
            if old_meta.get("shape"):
                data["_meta"]["shape"] = old_meta.get("shape")

        self.store.mutate_json(ATTR_TEMPLATES_FILE, work)
        self.store.append_audit("attributes.ingest", ",".join(sorted(keep.keys()))[:200],
                                {"accepted": len(keep), "skipped": skipped,
                                 "added": added, "via": as_text(body.get("via")) or ""},
                                "extension")

        # 读回文件再回报（不凭内存里的数字声称成功）
        data, reason = self.store.read_json(ATTR_TEMPLATES_FILE, {})
        data = data if isinstance(data, dict) else {}
        merged_now = data.get("loadsheets") if isinstance(data.get("loadsheets"), dict) else {}
        catalog_now = data.get("templates") if isinstance(data.get("templates"), dict) else {}
        bundled_catalog, bundled_covered = self._bundled_attributes()
        expected = sorted(set(catalog_now) | set(bundled_catalog))
        effective = set(merged_now) | set(bundled_covered)
        missing = [sid for sid in expected if sid not in effective]
        payload: Dict[str, Any] = {
            "ok": True,
            "source": SOURCE,
            "mode": "local",
            "accepted": len(keep),
            "added": added,
            "skipped": skipped,
            "skippedReasons": reasons[:5],
            "totalLoadsheets": len(merged_now),
            "coveredBefore": covered_before[0],
            "loadsheetIds": sorted(keep.keys())[:60],
            "stateFile": self.store.path(ATTR_TEMPLATES_FILE),
            "file": ATTR_TEMPLATES_FILE,
            "templatesExpected": len(expected) or None,
            "missingLoadsheets": missing[:60] if expected else [],
            "readBackReason": reason,
        }
        if skipped:
            payload["note"] = ("有 {0} 个装载表没有可用 fields，已跳过（不是成功）：{1}"
                               .format(len(skipped), "、".join(skipped[:5])))
        return payload

    # -- 9b. /attributes/raw ----------------------------------------------
    def h_attributes_raw(self) -> Dict[str, Any]:
        """把官方 /v1/loadsheets/templates 的**原始响应体**留档（离线排错用）。

        用户只会在真机上点这一次；万一归一化遇到没见过的形状，必须能拿原始响应离线修。
        只存响应体：请求头 / Authorization / JWT / cookie 一律不接收也不落盘（键名命中即 400）。
        rawText 上限 2MB，超限截断并标 truncated:true（同时给出原字节数与落盘字节数）。
        """
        self._require_writable()
        body = self._read_body(max_bytes=MAX_ATTR_BODY_BYTES)
        if not body:
            raise BridgeError(400, "请求体为空；需要 {rawText, fetchedAt?, url?, status?, contentType?}")
        payload, _rejected, ignored = attr_raw_payload(body)
        self.store.mutate_json(ATTR_RAW_FILE, lambda data: data.update(payload))
        self.store.append_audit("attributes.raw.save", ATTR_RAW_FILE,
                                {"bytes": payload["bytes"], "storedBytes": payload["storedBytes"],
                                 "truncated": payload["truncated"], "via": payload.get("via") or "",
                                 "url": payload.get("url") or ""},
                                "extension")
        data, reason = self.store.read_json(ATTR_RAW_FILE, {})
        data = data if isinstance(data, dict) else {}
        return {
            "ok": reason is None,
            "source": SOURCE,
            "file": ATTR_RAW_FILE,
            "stateFile": self.store.path(ATTR_RAW_FILE),
            "bytes": data.get("bytes"),
            "storedBytes": data.get("storedBytes"),
            "truncated": bool(data.get("truncated")),
            "limitBytes": data.get("limitBytes"),
            "fetchedAt": data.get("fetchedAt"),
            "status": data.get("status"),
            "contentType": data.get("contentType"),
            "url": data.get("url"),
            "via": data.get("via"),
            "ignoredKeys": ignored,
            "reason": reason,
            "note": ("原始响应已留档（只含响应体，不含任何请求头/凭证）。"
                     "归一化失败时可离线拿它修模板映射。"),
        }

    def _bundled_attributes(self) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """插件数据包里的 (装载表目录, 已带字段的装载表)，只读。

        目录 = <插件根>/dashboard/data/takealot-attributes.json 的 `templates`
        （装载表 id → {name, dept}），用来算「N/总数」；已带字段的 = 同文件的 `loadsheets`
        （数据包自带 7 个）。插件根 = state 目录的父目录（真实布局：
        %LOCALAPPDATA%\\hermes\\plugins\\takealot-erp\\{state,dashboard}）。
        读不到就都空，绝不编造。
        """
        root = os.path.dirname(self.store.state_dir)
        candidates = [
            os.path.join(root, "dashboard", "data", "takealot-attributes.json"),
            os.path.join(root, "data", "takealot-attributes.json"),
        ]
        data: Any = None
        for path in candidates:
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                break
            except Exception:  # noqa: BLE001 - 只影响进度显示，读不到就试下一个
                data = None
        if not isinstance(data, dict):
            return {}, {}
        catalog: Dict[str, Any] = {}
        tpl = data.get("templates")
        if isinstance(tpl, dict):
            for key in tpl:
                if as_text(key):
                    catalog[str(key)] = tpl[key]
        covered: Dict[str, Any] = {}
        bundled = data.get("loadsheets")
        if isinstance(bundled, dict):
            for lid, node in bundled.items():
                if not as_text(lid):
                    continue
                covered[str(lid)] = node
                catalog.setdefault(str(lid), {"name": (node or {}).get("name", "") if isinstance(node, dict) else ""})
        return catalog, covered

    # -- 10. /attributes/status -------------------------------------------
    def h_attributes_status(self) -> Dict[str, Any]:
        """属性模板覆盖情况：state 文件（ingested）+ 插件数据包（bundled）+ 缺哪些装载表 + 原始留档。"""
        data, reason = self.store.read_json(ATTR_TEMPLATES_FILE, {})
        data = data if isinstance(data, dict) else {}
        raw, raw_reason = self.store.read_json(ATTR_RAW_FILE, {})
        raw = raw if isinstance(raw, dict) else {}
        merged = data.get("loadsheets") if isinstance(data.get("loadsheets"), dict) else {}
        meta = data.get("_meta") if isinstance(data.get("_meta"), dict) else {}
        catalog_state = data.get("templates") if isinstance(data.get("templates"), dict) else {}
        bundled_catalog, bundled = self._bundled_attributes()
        effective = set(str(k) for k in merged.keys()) | set(str(k) for k in bundled.keys())
        expected = sorted(set(catalog_state) | set(bundled_catalog))
        missing = [sid for sid in expected if sid not in effective]
        fields_total = 0
        categories_total = 0
        for node in merged.values():
            if isinstance(node, dict):
                fields_total += len(node.get("fields") or {})
                categories_total += len(node.get("categories") or {})
        payload: Dict[str, Any] = {
            "ok": reason is None,
            "source": SOURCE,
            "file": ATTR_TEMPLATES_FILE,
            "stateFile": self.store.path(ATTR_TEMPLATES_FILE),
            "exists": os.path.isfile(self.store.path(ATTR_TEMPLATES_FILE)),
            "loadsheetsCovered": len(merged),
            "updatedAt": meta.get("updatedAt"),
            "ingestedAt": meta.get("ingestedAt"),
            "fileSource": meta.get("source"),
            "via": meta.get("via"),
            "bundledLoadsheets": len(bundled),
            "effectiveLoadsheets": len(effective),
            "templatesExpected": len(expected) or None,
            "missingLoadsheets": missing[:60],
            "fieldsTotal": fields_total,
            "categoriesTotal": categories_total,
            "loadsheetIds": sorted(str(k) for k in merged.keys())[:60],
            "rawFile": ATTR_RAW_FILE,
            "rawBytes": raw.get("bytes") if raw else None,
            "rawFetchedAt": raw.get("fetchedAt") if raw else None,
            "rawUrl": raw.get("url") if raw else None,
            "rawTruncated": bool(raw.get("truncated")) if raw else None,
            "rawStoredBytes": raw.get("storedBytes") if raw else None,
            "rawReason": raw_reason,
        }
        if reason:
            payload["reason"] = reason
            payload["note"] = ("state 里还没有属性模板（loadsheetsCovered=0）："
                               "在卖家后台页面点扩展抽屉「同步官方类目属性模板」后会写进来。")
        elif missing:
            payload["note"] = ("还有 {0} 个装载表没有模板（插件数据包 + 已 ingest 都算上）：{1}"
                               .format(len(missing), "、".join(missing[:8])))
        else:
            payload["note"] = "装载表模板已齐（插件数据包 + ingested 覆盖了全部 {0} 个）。".format(len(expected))
        return payload


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Takealot ERP 本地桥（扩展 ↔ 本地 state）")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT,
                        help="监听端口（默认 {0}）".format(DEFAULT_PORT))
    parser.add_argument("--state", default=default_state_dir(),
                        help="state 目录（默认插件目录：%%LOCALAPPDATA%%\\hermes\\plugins\\takealot-erp\\state）")
    args = parser.parse_args(argv)

    if args.port < 1 or args.port > 65535:
        log("端口非法：{0}".format(args.port))
        return 2

    store = StateStore(os.path.abspath(args.state))
    if store.writable:
        log("state OK（可写）：{0}".format(store.state_dir))
    else:
        log("只读模式启动：{0}".format(store.writable_reason))

    try:
        httpd = Server((DEFAULT_HOST, args.port), Handler)
    except OSError as exc:
        log("绑定 {0}:{1} 失败：{2}".format(DEFAULT_HOST, args.port, exc))
        log("端口被占用时：netstat -ano | findstr {0}  →  taskkill /PID <pid> /F".format(args.port))
        return 3
    httpd.store = store  # type: ignore[attr-defined]
    httpd.started_at = time.time()  # type: ignore[attr-defined]
    log("{0} v{1} 监听 http://{2}:{3}  state={4}  writable={5}".format(
        SOURCE, VERSION, DEFAULT_HOST, args.port, store.state_dir, store.writable))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        log("收到 Ctrl+C，退出")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
