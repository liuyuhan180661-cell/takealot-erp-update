# Takealot ERP 本地桥（erp_bridge.py）

把 Hermes 桌面插件（Windows 上的 `takealot-erp`）的**本地 state** 暴露给旧的 Chrome/Edge 扩展，
替换已经停掉的 OpenClaw 网关（`127.0.0.1:18789`）。扩展原本就按 `http://127.0.0.1:18789/takealot/api/...`
调用，所以桥的路径原样保留，只要把扩展里的 `gatewayUrl` 改成 `http://127.0.0.1:18790` 即可。

- 纯 stdlib（`http.server` / `json` / `threading` / `urllib.parse`），无第三方依赖，Windows + Python 3.8+ 都能跑。
- **只监听 `127.0.0.1`**，不做鉴权也不对外网开放。
- **不调用 Takealot 任何 API**：跟卖/上架的写动作由 ERP 后端负责，桥只读写本地 state 文件。
- 默认端口 **18790**，默认 state 目录 `%LOCALAPPDATA%\hermes\plugins\takealot-erp\state`。

---

## 1. 启动

```bat
rem 在 Windows 上（插件机器）
python erp_bridge.py
rem 或用插件自带的 venv：
"C:\Users\Fly\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe" erp_bridge.py
```

启动后应该看到：

```
[02:35:41] state OK（可写）：C:\Users\Fly\AppData\Local\hermes\plugins\takealot-erp\state
[02:35:41] hermes-erp-bridge v1.0.0 监听 http://127.0.0.1:18790  state=...  writable=True
```

自检：

```bat
python -c "import urllib.request;print(urllib.request.urlopen('http://127.0.0.1:18790/takealot/api/health').read().decode())"
```

后台常驻（不弹窗）：`powershell -Command "Start-Process python -ArgumentList 'C:\path\erp_bridge.py' -WindowStyle Hidden"`。

### 改端口 / 改 state 路径

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `--port` | `18790` | 监听端口 |
| `--state` | `%LOCALAPPDATA%\hermes\plugins\takealot-erp\state` | state 目录（读 `collection.json` / `drafts.json` / `stores.json` / `settings.json`，写 `collection.json` / `drafts.json` / `bridge_audit.jsonl`） |

```bat
python erp_bridge.py --port 18790 --state "C:\Users\Fly\AppData\Local\hermes\plugins\takealot-erp\state"
```

监听地址固定 `127.0.0.1`，**没有**覆盖开关（桥永远不对外网开）。

---

## 2. 接口清单

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/takealot/api/health` | `{ok, source, version, uptimeSec, statePath, writable, writableReason}` |
| GET | `/takealot/api/takealot/init-data` | `{ok, source, version, storeId, storeName, counts:{collection,drafts}, settings:{autoLockCategory, autoPolishTitle}, notes[]}` |
| GET | `/takealot/api/collection/pending` | 跟卖池待处理行；`{ok, count, items[], total, excluded:{promoted}}`。已 `promoted` 的行默认排除，`?all=1` 看全部 |
| POST | `/takealot/api/collection/add` | 前台采集到的商品对象入库；补 `id(COL-…)`/`intent:'follow'`/`state:'pool'`/`source:'extension'`/`savedAt`；按 `tsin/plid/barcode/text` 幂等去重（命中返回 `deduped:true` + 已存在行 id，`count` 不变） |
| POST | `/takealot/api/collection/update` | **只接受 `{id, price?, stock?}`**，其它字段一律 400 拒绝 |
| POST | `/takealot/api/collection/promote` | `{id}` → 在 drafts 建一条 `source:'collection:<COL id>'`；采集行置 `state:'promoted'` + `draftId`。**采集箱→草稿箱的唯一通道**，重复 promote 返回 409 |
| GET | `/takealot/api/listing/drafts` | `{ok, count, drafts:[{id,title,sku,barcode,images,completeness,state,source,updatedAt,fields{…}}]}` |
| POST | `/takealot/api/listing/draft` | `{id?, fields:{…}}`：有 id 就 upsert 部分合并，没 id 就新建 `DRF-…`；每次写更新 `updatedAt` 与 `completeness.missing`（按官方装载表必填列） |

采集行字段（缺的一律 `null`，不编）：`id, intent, state, title, sku, tsin, plid, barcode, imageUrl, images[], sourceUrl, price, stock, estSalePrice, source, savedAt, brand, category, categoryPath, draftId`。

`completeness.missing` 的列名：`Main Category / Lowest Category / Title / Key Selling Features / Barcode / Main Image / Warranty Type / Warranty Period`
（对齐插件 `plugin_api.py` 的 `LOADSHEET_COLUMNS`；图片列在装载表里叫 `Product Image 1 (Cover)`，这里按扩展口径写作 `Main Image`。`Barcode` 装载表非必填，但 `CreateOfferRequest` 必填，所以也计入必填。）

CORS：回显白名单里的 `Origin`（`https://seller.takealot.com`、`https://www.takealot.com`、`https://takealot.com`、`chrome-extension://*`、`http://127.0.0.1:*`、`http://localhost:*`），支持 `OPTIONS` 预检（`Access-Control-Allow-Headers: Content-Type`）。非白名单 Origin 不回 CORS 头。

state 文件写入：同目录临时文件 → `fsync` → `os.replace`（原子），全程 `threading.Lock` 保护读-改-写，只动目标字段，其它字段（含插件自有字段如 `compliance`、`storeId`）原样保留。写操作 append 到 `state/bridge_audit.jsonl`（每行 `{ts, action, id, changed, source}`）。日志只打「方法 路径 状态码」，**不打印请求体、不打印 `stores.json` 任何一行**。

---

## 3. 为什么采集箱写接口只接受 price/stock

采集箱 = **跟卖池**：里面的商品在 Takealot 上**已经存在**（有 TSIN/PLID/条码）。跟卖走的是官方
`CreateOfferRequest`，schema 是 `additionalProperties: false` —— 只接受 `barcode/sku` + `selling_price`
+ 仓库库存，**没有**标题/图片/描述/类目字段。也就是说 listing 内容在平台上根本改不了（只能在
Seller Portal 由平台侧维护），改了也不会生效。

所以：

- `collection/update` 收到 `title`/`images`/`description`… → 返回
  `{ok:false, error:'跟卖只能改价格与库存（平台不允许修改 listing 内容）', rejectedFields:[…]}`，**不写入**；
- 想改内容，只能在草稿箱里做（`listing/draft`），那是**新建 listing**的通道；
- 采集箱与草稿箱**不共享行**：只能 `promote` 转入（之后采集行 `state='promoted'`，不再出现在待跟卖列表里）
  或从零新建。

---

## 4. 排错

| 症状 | 原因 / 处理 |
| --- | --- |
| 启动打印 `绑定 127.0.0.1:18790 失败：[WinError 10048]` | 端口被占用：`netstat -ano \| findstr 18790` 拿 PID，`taskkill /PID <pid> /F`；或换端口 `--port 18791`（同时改扩展里的 `gatewayUrl`） |
| 启动打印 `只读模式启动：state 目录不存在：…` | 路径不对或插件还没建 state。桥**不会崩**：读接口给空 + `reason`，写接口返回 503。核对 `--state`，或用 `%LOCALAPPDATA%` 展开后的真实路径 |
| `writable=false`，`writableReason` 是 `PermissionError` | 当前用户对 state 目录没有写权限（例如用管理员/其他账号跑插件）。用插件同账号启动桥 |
| 扩展连不上（`checkConnection` 失败 / `Connection refused`） | 1) 桥没起 → 看 `/takealot/api/health`；2) 扩展里的 `gatewayUrl` 还是旧的 `18789` → 改成 `http://127.0.0.1:18790`；3) 端口被占或桥换过端口 |
| 浏览器里 fetch 报 CORS 错 | 页面 Origin 不在白名单（比如 `seller.takealot.com` 的某种子域）。把该 Origin 加进 `erp_bridge.py` 的 `ALLOWED_ORIGIN_EXACT/PREFIX` 再重启 |
| `collection/update` 一直 400 | 正常：body 里除了 `id/price/stock` 还有别的字段。看返回的 `rejectedFields`（见上一节） |
| 草稿保存后状态不见了 | 看 `GET /listing/drafts` 的 `count` 与 `state/drafts.json`；每次写都会更新 `updatedAt`，可按时间排序定位 |
| 想知道谁改了什么 | 看 `state/bridge_audit.jsonl`（每行一条 JSON，含时间/动作/id/变更字段/来源） |

---

## 5. 自证脚本

`probe_bridge.py`（路径 `/tmp/hermeswin/probe_bridge.py`，与 `pkg/dashboard/bridge/` 同一工作区）是参数化可复跑的验收脚本，
**只对临时 state 副本跑**，不碰真实 state：

```bat
python probe_bridge.py --base http://127.0.0.1:18790 --state "C:\Users\Fly\bridge-test-state" ^
                       --readonly-base http://127.0.0.1:18791 --legacy-base http://127.0.0.1:18792
```

覆盖：health/init-data、CORS 预检、add 幂等去重、update 只允许 price/stock、promote 转换、
draft upsert 部分合并 + `missing` 列、20 线程并发原子写（磁盘 JSON 完整、条数 == 成功次数）、
只读模式（state 不存在）、插件现网形状的旧 state（扁平 drafts + `activeStoreId`）。最近一次：**59 PASS / 0 FAIL**。
