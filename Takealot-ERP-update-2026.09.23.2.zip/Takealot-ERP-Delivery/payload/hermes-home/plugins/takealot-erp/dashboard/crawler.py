"""Takealot public-API crawler, sales estimation, and AI-valuation core.

Imported by ``dashboard/plugin_api.py`` (same package). Speaks the PUBLIC
Takealot REST API only — it never reads, sends or logs the Seller
``X-API-Key`` and never touches ``marketplace-api.takealot.com``.

Faithful port of the OpenListing reference implementation (唯一真相源):

* ``packages/shared/src/salesEstimate.ts``            — 留评率档位 + 销量换算
* ``apps/web/src/lib/takealotVelocity.ts``            — review paging + windows
* ``server/crawlers/takealot/api-lib.mjs``            — extractors
* ``supabase/migrations/027_takealot_velocity_cache.sql`` — cache TTL 5 days

Design rules (CONTRACT2.md):

* stdlib only, no module-level network calls, no lingering threads.
* Transport ladder ``proxy`` → ``direct`` → ``blocked`` (Cloudflare 403 is the
  normal outcome on a restricted network); an ingested payload is a fourth
  transport, ``ingest``, which uses the identical parsing path with zero
  network.  ``blocked`` never 500s and never invents data: it returns the
  sanitized error plus a ``hint``.
* Payloads can also arrive through a drop folder (``state/ingest/*.json``)
  written by a crawler that *can* reach Takealot; both ``/crawler/status``
  and ``/crawler/pull`` reap that folder before doing anything else.
"""

from __future__ import annotations

import concurrent.futures
import json
import logging
import math
import os
import re
import shutil
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("hermes.plugin.takealot_erp.crawler")

# --------------------------------------------------------------------------
# Constants — mirrors api-lib.mjs / takealotVelocity.ts
# --------------------------------------------------------------------------

API_BASE = "https://api.takealot.com/rest/v-1-12-0"
PROXY_ENV = "TAKEALOT_API_PROXY"
PAGE_SIZE = 10          # 接口固定每页 10 条
MAX_PAGES = 120         # 硬上限（1200 条评论 ≈ 覆盖 180 天）
CONCURRENCY = 6         # 每轮并发页数
PRODUCT_TIMEOUT = 8.0   # api-lib.mjs timeoutMs
REVIEW_TIMEOUT = 10.0   # takealotVelocity.ts AbortController
MAX_AGE_DAYS = 180      # 翻页停止阈值 / 180 天销量窗口
CACHE_TTL_DAYS = 5.0    # migration 027
AI_CACHE_TTL_HOURS = 24.0
DEEPSEEK_BASE = "https://api.deepseek.com/v1"
DEEPSEEK_MODEL = "deepseek-chat"
AI_TIMEOUT = 20.0

HEADERS = {
    "Accept": "application/json",
    "Accept-Language": "en-ZA,en;q=0.9",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
}

WAREHOUSE_CODES = ["CPT", "JHB", "DBN", "PTA", "BFN", "PLZ", "NEL", "PMB", "ELS", "KIM", "NLP", "MPB"]

#: 类目留评率档位 (salesEstimate.ts REVIEW_RATE_TIERS)
REVIEW_RATE_TIERS = {
    "electronics": 0.045,
    "beauty": 0.025,
    "default": 0.02,
}

ELECTRONICS_RE = re.compile(
    r"audio|video|\btv\b|television|headphone|earphone|speaker|computer|laptop|tablet|phone|"
    r"cellular|gaming|console|camera|electronic|gadget|charger|cable|monitor|drone|smart\s?watch|"
    r"электрон|наушник|телефон|смартфон|ноутбук|планшет|камер|телевизор|консол|гаджет|зарядн",
    re.I,
)
BEAUTY_RE = re.compile(
    r"beauty|cosmetic|makeup|skin\s?care|personal\s?care|health|hygiene|baby|toddler|infant|diaper|"
    r"fragrance|perfume|hair\s?care|космет|макияж|уход|красот|парфюм|гигиен|детск|подгузник|здоров",
    re.I,
)

RATE_NOTES = {
    "electronics": "留评率档位 4.5%（电子/音频/电脑/手机/游戏/相机类目实测最高，同评论增速换算的销量最保守）",
    "beauty": "留评率档位 2.5%（美妆/个护/健康/母婴类目实测中位）",
    "default": "留评率档位 2.0%（通用/预算款，未命中类目关键词时取最保守值）",
}

#: 跟卖风险等级阈值（sellerCount）
COMPETITION_BANDS = ((1, "低"), (5, "中"))
VERDICTS = ((75, "值得跟卖"), (58, "可以上新"), (42, "观望"), (-1, "不建议"))

DASHBOARD_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = DASHBOARD_DIR.parent
#: Overridable so the plugin (and tests) can point the crawler at the same
#: state directory the rest of the backend uses.
STATE_DIR = PACKAGE_DIR / "state"

_LOCK = threading.RLock()
_TRANSPORT: Dict[str, Any] = {
    "transport": None,
    "lastError": None,
    "lastErrorAt": None,
    "directReachable": None,
    "lastProbeAt": None,
}


def set_state_dir(path: Any) -> None:
    global STATE_DIR
    STATE_DIR = Path(path)


def state_dir() -> Path:
    return STATE_DIR


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------

_KEY_RE = re.compile(
    r"(?i)(x-api-key|api[_-]?key|authorization|bearer|token)\s*[:=]?\s*[A-Za-z0-9._\-]{6,}"
)


def sanitize(text: Any) -> str:
    """Strip anything key-shaped out of a message (no Seller key is reachable
    from this module, but crawler errors are echoed into API responses)."""
    out = str(text or "")
    out = re.sub(r"(?i)(sk-|Bearer\s+)[A-Za-z0-9._\-]{8,}", r"\1***", out)
    return _KEY_RE.sub(r"\1=***", out)


def js_round(value: float) -> int:
    """JS ``Math.round`` — half away from zero, unlike Python's banker's rounding."""
    try:
        num = float(value)
    except (TypeError, ValueError):
        return 0
    if num != num or num in (float("inf"), float("-inf")):
        return 0
    return int(math.floor(num + 0.5)) if num >= 0 else -int(math.floor(-num + 0.5))


def _dig(data: Any, *keys: Any, default: Any = None) -> Any:
    """Safe nested lookup: ``_dig(payload, "buybox", "items", 0, "price")``."""
    node = data
    for key in keys:
        if node is None:
            return default
        if isinstance(key, int):
            if isinstance(node, (list, tuple)) and -len(node) <= key < len(node):
                node = node[key]
            else:
                return default
        elif isinstance(node, dict):
            node = node.get(key)
        else:
            return default
    return default if node is None else node


def _iso(ts: Optional[float] = None) -> str:
    value = datetime.fromtimestamp(ts) if ts else datetime.now()
    return value.strftime("%Y-%m-%d %H:%M")


def _now_ms() -> float:
    return time.time() * 1000.0


def read_state(name: str, default: Any) -> Any:
    try:
        with open(state_dir() / name, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def write_state(name: str, data: Any) -> None:
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        path = state_dir() / name
        tmp = path.with_suffix(path.suffix + ".tmp")
        with _LOCK:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
    except OSError as exc:  # pragma: no cover - disk level failure
        log.warning("takealot-erp crawler: cannot write state %s: %s", name, exc)


def _clean_number(value: Any) -> Optional[float]:
    try:
        if value is None or isinstance(value, bool):
            return None
        num = float(value)
    except (TypeError, ValueError):
        return None
    if num != num or num in (float("inf"), float("-inf")):
        return None
    return num


# --------------------------------------------------------------------------
# B. Sales estimation — exact port of packages/shared/src/salesEstimate.ts
# --------------------------------------------------------------------------

def review_rate_for(*hints: Any) -> Tuple[float, str, str]:
    """Return ``(rate, rateSource, rateNote)``.

    ``hay = hints.filter(Boolean).join(' ')``; electronics wins over beauty;
    no match → default (most conservative).
    """
    hay = " ".join(str(h) for h in hints if h)
    if ELECTRONICS_RE.search(hay):
        source = "electronics"
    elif BEAUTY_RE.search(hay):
        source = "beauty"
    else:
        source = "default"
    return REVIEW_RATE_TIERS[source], source, RATE_NOTES[source]


def estimate_sales(windows: Optional[Dict[str, Any]], category_hint: Optional[str] = None,
                   price: Optional[float] = None) -> Dict[str, Any]:
    """Port of ``estimateSalesFromWindows(windows, {categoryHint, price})``."""
    source_windows = windows if isinstance(windows, dict) else {}
    w: Dict[str, Any] = {}
    for key in ("total", "reviews_7d", "reviews_30d", "reviews_90d", "reviews_180d", "pagesFetched"):
        w[key] = int(_clean_number(source_windows.get(key)) or 0)
    w["truncated"] = bool(source_windows.get("truncated"))
    rate, source, note = review_rate_for(category_hint)
    sales_30d = js_round(w["reviews_30d"] / rate)
    sales_90d = js_round(w["reviews_90d"] / rate)
    sales_180d = js_round(w["reviews_180d"] / rate)
    sales_7d = js_round((sales_30d * 7) / 30)
    price_num = _clean_number(price)
    has_price = price_num is not None and price_num > 0
    return {
        "sales_7d": sales_7d,
        "sales_30d": sales_30d,
        "sales_90d": sales_90d,
        "sales_180d": sales_180d,
        "estimated_monthly_sales": sales_30d,
        "estimated_daily_sales": js_round((sales_30d / 30) * 10) / 10,
        "estimated_monthly_revenue": js_round(sales_30d * price_num) if has_price else None,
        "review_rate": rate,
        "rateSource": source,
        "rateNote": note,
        "windows": w,
    }


# --------------------------------------------------------------------------
# Review parsing — `date` is "06 Jul 2026" (day month year), not ISO
# --------------------------------------------------------------------------

#: Supported review-date shapes, most specific first. ``%d %b %Y`` is the
#: Takealot public-API format the contract calls out.
DATE_FORMATS = (
    "%d %b %Y",     # 06 Jul 2026  ← Takealot public API
    "%d %B %Y",     # 06 July 2026
    "%d-%b-%Y",     # 06-Jul-2026
    "%d %b %y",     # 06 Jul 26
    "%b %d, %Y",    # Jul 06, 2026
    "%d/%m/%Y",     # 06/07/2026 (day first, ZA convention)
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d",     # ISO fallback
)

_WS_RE = re.compile(r"\s+")


def parse_review_date(value: Any) -> Tuple[Optional[datetime], Optional[str]]:
    """Parse a Takealot review date to a naive **local** datetime.

    ``Date.parse("06 Jul 2026")`` in V8 resolves to local midnight, and the
    reference computes ages against ``Date.now()``; parsing to local midnight
    keeps the window arithmetic numerically identical.
    """
    if value is None or isinstance(value, bool):
        return None, None
    if isinstance(value, (int, float)):
        num = float(value)
        # epoch seconds vs milliseconds
        secs = num / 1000.0 if num > 1e11 else num
        try:
            return datetime.fromtimestamp(secs), "epoch"
        except (OverflowError, OSError, ValueError):
            return None, None
    raw = str(value).strip()
    if not raw:
        return None, None
    if re.fullmatch(r"\d{9,13}", raw):
        return parse_review_date(float(raw))
    text = _WS_RE.sub(" ", raw)
    for candidate in (text, text.replace(",", " ")):
        for fmt in DATE_FORMATS:
            try:
                return datetime.strptime(candidate, fmt), fmt
            except ValueError:
                continue
    return None, None


def review_date_ms(value: Any) -> Tuple[Optional[float], Optional[str]]:
    stamp, fmt = parse_review_date(value)
    if stamp is None:
        return None, fmt
    try:
        return stamp.timestamp() * 1000.0, fmt
    except (OverflowError, OSError, ValueError):
        return None, fmt


def parse_reviews(payload: Any) -> List[Dict[str, Any]]:
    """Page JSON ``reviews[]`` → contract review rows."""
    out: List[Dict[str, Any]] = []
    for row in _dig(payload, "reviews", default=[]) or []:
        if not isinstance(row, dict):
            continue
        body = _dig(row, "text", "body")
        title = _dig(row, "text", "title")
        stamp, fmt = parse_review_date(row.get("date"))
        out.append(
            {
                "rating": _clean_number(row.get("rating")),
                "date": row.get("date"),
                "dateParsed": stamp.strftime("%Y-%m-%d") if stamp else None,
                "dateFormat": fmt,
                "text": body if isinstance(body, str) else "",
                "title": title if isinstance(title, str) else "",
                "num_upvotes": int(_clean_number(row.get("num_upvotes")) or 0),
                "customer_name": row.get("customer_name") or "",
                "tsin_id": row.get("tsin_id"),
                "variant_info": row.get("variant_info") or [],
                "tsin": row.get("tsin_id"),
            }
        )
    return out


def _page_dates(payload: Any) -> List[Any]:
    """``arr.map(r => r?.date).filter(d => typeof d === 'string')`` — order kept."""
    dates: List[Any] = []
    for row in _dig(payload, "reviews", default=[]) or []:
        if isinstance(row, dict) and isinstance(row.get("date"), str):
            dates.append(row["date"])
    return dates


def _tally(fetch_batch: Callable[[List[int]], List[Any]], now: float,
           max_pages: int = MAX_PAGES, concurrency: int = CONCURRENCY) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """The one and only window counter — shared by the live and ingest paths.

    Rounds of ``CONCURRENCY`` pages, ``pagesFetched`` counts the empty page too,
    an empty page ends the crawl, a parse failure is skipped (like ``Date.parse``
    returning NaN), and ``truncated`` reports the page cap.

    It deliberately does NOT stop on an "old" review (upstream
    ``fetchReviewWindows`` does, which is only sound for a chronological listing).
    This API's ordering is not chronological, so stopping early silently dropped
    recent reviews and under-counted the window: measured on a live product the
    early stop gave 30d=0 / 月销 0 where the full enumeration gives 30d=3 / 月销 150.
    """
    w = {
        "total": 0,
        "reviews_7d": 0,
        "reviews_30d": 0,
        "reviews_90d": 0,
        "reviews_180d": 0,
        "pagesFetched": 0,
        "truncated": False,
    }
    diag: Dict[str, Any] = {"parsed": 0, "failed": 0, "formats": {}, "unparsed": [], "samples": [], "pages": [],
                            "olderThan180d": 0}
    page = 1
    done = False
    stop_cause: Optional[str] = None
    while not done and page <= max_pages:
        size = min(concurrency, max_pages - page + 1)
        batch = list(range(page, page + size))
        bodies = fetch_batch(batch)
        for offset in range(len(batch)):
            body = bodies[offset] if offset < len(bodies) else None
            w["pagesFetched"] += 1
            dates = _page_dates(body)
            diag["pages"].append({"page": batch[offset], "reviews": len(dates), "oldest": dates[-1] if dates else None})
            if not dates:
                done = True
                stop_cause = stop_cause or "empty-page"
                break
            for raw in dates:
                ms, fmt = review_date_ms(raw)
                if ms is None:
                    diag["failed"] += 1
                    if len(diag["unparsed"]) < 10:
                        diag["unparsed"].append(raw)
                    continue
                diag["parsed"] += 1
                diag["formats"][fmt] = diag["formats"].get(fmt, 0) + 1
                if len(diag["samples"]) < 6:
                    diag["samples"].append(raw)
                age_days = (now - ms) / 86400000.0
                w["total"] += 1
                if age_days <= 7:
                    w["reviews_7d"] += 1
                if age_days <= 30:
                    w["reviews_30d"] += 1
                if age_days <= 90:
                    w["reviews_90d"] += 1
                if age_days <= MAX_AGE_DAYS:
                    w["reviews_180d"] += 1
                else:
                    # Diagnostic only — never a stop condition (page order is not
                    # chronological on this API, see reviews_url()).
                    diag["olderThan180d"] += 1
        page += len(batch)
    if page > max_pages and not done:
        w["truncated"] = True
    if w["truncated"]:
        diag["stopReason"] = "truncated"
    elif not done:
        diag["stopReason"] = "page-exhausted"
    else:
        diag["stopReason"] = stop_cause or "empty-page"
    diag["pagesWithReviews"] = [p["page"] for p in diag["pages"] if p["reviews"]]
    return w, diag


def count_windows(pages: Dict[int, Any], now_ms: Optional[float] = None,
                  max_pages: int = MAX_PAGES, concurrency: int = CONCURRENCY,
                  fetch_page: Optional[Callable[[int], Any]] = None) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Replay ``fetchReviewWindows`` over pages already in hand (ingest path)."""
    if fetch_page is None:
        def fetch_page(page: int) -> Any:  # noqa: E306
            return pages.get(page)

    def fetch_batch(batch: List[int]) -> List[Any]:
        return [_fetch_page_safe(fetch_page, p) for p in batch]

    now = float(now_ms) if now_ms else _now_ms()
    return _tally(fetch_batch, now, max_pages, concurrency)


def _fetch_page_safe(fetch_page: Callable[[int], Any], page: int) -> Any:
    try:
        return fetch_page(page)
    except Exception as exc:  # mirrors the TS `catch { return [] }`
        log.debug("takealot-erp crawler: review page %s failed: %s", page, exc)
        return None


# --------------------------------------------------------------------------
# Extractors — faithful port of server/crawlers/takealot/api-lib.mjs
# --------------------------------------------------------------------------

def extract_breadcrumbs(data: Dict[str, Any]) -> Dict[str, Any]:
    sources = [
        _dig(data, "breadcrumbs", "items"),
        data.get("breadcrumbs"),
        _dig(data, "navigation", "breadcrumbs"),
        _dig(data, "core", "breadcrumbs"),
        data.get("breadcrumb"),
        _dig(data, "page", "breadcrumbs"),
        _dig(data, "product", "breadcrumbs"),
    ]
    for crumbs in sources:
        if isinstance(crumbs, list) and crumbs:
            names = []
            for b in crumbs:
                if isinstance(b, str):
                    names.append(b)
                elif isinstance(b, dict):
                    value = b.get("name") or b.get("title") or b.get("label") or b.get("text") or ""
                    if value:
                        names.append(value)
            names = [n for n in names if n]
            if names:
                return {
                    "path": " > ".join(names),
                    "l1": names[0] or None,
                    "l2": names[1] if len(names) > 1 else None,
                    "l3": names[2] if len(names) > 2 else None,
                    "names": names,
                    "ids": [b.get("id") for b in crumbs if isinstance(b, dict) and b.get("id") is not None],
                }
    cat = data.get("category") or _dig(data, "core", "category") or data.get("classification")
    if isinstance(cat, dict):
        l1 = cat.get("level1") or cat.get("l1") or cat.get("category_level_1") or cat.get("primary") or cat.get("name")
        l2 = cat.get("level2") or cat.get("l2") or cat.get("category_level_2") or cat.get("subcategory")
        l3 = cat.get("level3") or cat.get("l3") or cat.get("category_level_3") or cat.get("subsubcategory")
        if l1:
            return {
                "path": " > ".join([x for x in (l1, l2, l3) if x]),
                "l1": l1,
                "l2": l2 or None,
                "l3": l3 or None,
                "names": [x for x in (l1, l2, l3) if x],
                "ids": [],
            }
    return {"path": None, "l1": None, "l2": None, "l3": None, "names": [], "ids": []}


def extract_price(data: Dict[str, Any]) -> float:
    bb = data.get("buybox") or {}
    if isinstance(bb, dict):
        num = _clean_number(bb.get("price"))
        if num and num > 0:
            return num
        pretty = bb.get("pretty_price")
        if pretty:
            digits = re.sub(r"[^0-9.]", "", str(pretty))
            try:
                value = float(digits) if digits not in ("", ".") else 0.0
            except ValueError:
                value = 0.0
            if value:
                return value
        items = bb.get("items")
        if isinstance(items, list) and items and isinstance(items[0], dict):
            item = items[0]
            for key in item.keys():
                if "price" in key.lower() and isinstance(item[key], (int, float)) and item[key] > 0:
                    return float(item[key])
            offer = item.get("offer_detail")
            if isinstance(offer, dict):
                for key in offer.keys():
                    if "price" in key.lower() and isinstance(offer[key], (int, float)) and offer[key] > 0:
                        return float(offer[key])
    for key in ("price", "selling_price", "sellingPrice", "buybox_price", "current_price", "list_price"):
        num = _clean_number(data.get(key))
        if num and num > 0:
            return num
    return 0.0


def pretty_price(data: Dict[str, Any]) -> Optional[str]:
    for candidate in (
        _dig(data, "buybox", "items", 0, "pretty_price"),
        _dig(data, "buybox", "pretty_price"),
        _dig(data, "core", "pretty_price"),
    ):
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()
    price = extract_price(data)
    return "R {0:,.0f}".format(price).replace(",", "") if price else None


def extract_image(data: Dict[str, Any]) -> Optional[str]:
    def pick_best(images: Any) -> Optional[str]:
        if not isinstance(images, list):
            return None
        for img in images:
            url = img if isinstance(img, str) else (img or {}).get("url") if isinstance(img, dict) else None
            if url and not re.search(r"logo|icon|brand|avatar|swatch|placeholder", url, re.I):
                return url
        if images:
            first = images[0]
            return first if isinstance(first, str) else (first or {}).get("url") if isinstance(first, dict) else None
        return None

    url = (
        pick_best(_dig(data, "gallery", "images"))
        or pick_best(data.get("images"))
        or pick_best(_dig(data, "core", "images"))
    )
    core_image = _dig(data, "core", "image")
    if isinstance(core_image, str) and not re.search(r"logo|icon|brand|avatar|swatch|placeholder", core_image, re.I):
        url = core_image
    if url and "{size}" in url:
        # Takealot CDN 已弃用数字尺寸，命名尺寸 xlpreview 才稳定可用
        url = url.replace("{size}", "xlpreview")
    return url


def extract_images(data: Dict[str, Any]) -> List[str]:
    """Every gallery image, ``{size}`` → ``xlpreview``."""
    out: List[str] = []
    for img in _dig(data, "gallery", "images", default=[]) or []:
        url = img if isinstance(img, str) else (img or {}).get("url") if isinstance(img, dict) else None
        if not url:
            continue
        out.append(url.replace("{size}", "xlpreview") if "{size}" in url else url)
    return out


def extract_rating(data: Dict[str, Any]) -> Dict[str, Any]:
    core = data.get("core") or {}
    reviews = data.get("reviews") or {}
    if not isinstance(core, dict):
        core = {}
    if not isinstance(reviews, dict):
        reviews = {}
    star = core.get("star_rating") or reviews.get("average_rating") or reviews.get("average_score") or 0
    count = reviews.get("count") or core.get("reviews") or reviews.get("total_reviews") or reviews.get("total") or 0
    distribution = reviews.get("distribution") if isinstance(reviews.get("distribution"), dict) else None
    return {
        "rating": _clean_number(star) or 0,
        "reviewCount": int(_clean_number(count) or 0),
        "starRating": _clean_number(star) or 0,
        "reviews": int(_clean_number(count) or 0),
        "brand": core.get("brand") or data.get("brand") or None,
        "title": data.get("title") or core.get("title") or "",
        "subtitle": core.get("subtitle") or "",
        "imageUrl": extract_image(data),
        "distribution": distribution,
    }


def extract_shipping(data: Dict[str, Any]) -> Dict[str, Any]:
    item = _dig(data, "buybox", "items", 0)
    if not isinstance(item, dict) or not isinstance(item.get("stock_availability"), dict):
        return {
            "status": None,
            "warehouses": [],
            "deliveryDays": None,
            "isInStock": None,
            "isLeadtime": None,
            "isImported": None,
        }
    sa = item["stock_availability"]
    status = sa.get("status") or None
    warehouses: List[str] = []
    dcs = sa.get("distribution_centres")
    if isinstance(dcs, list):
        for dc in dcs:
            code = (dc or {}).get("text") or (dc or {}).get("code") or (dc or {}).get("id") if isinstance(dc, dict) else None
            if code and code in WAREHOUSE_CODES and code not in warehouses:
                warehouses.append(code)
    delivery_days = None
    if status:
        match = re.search(r"Ships\s+in\s+(\d+)\s*[-\u2013\u2014to]+\s*(\d+)", status, re.I) or re.search(
            r"Ships\s+in\s+(\d+)", status, re.I
        )
        if match:
            delivery_days = "{0}-{1}".format(match.group(1), match.group(2)) if match.group(2) else match.group(1)
    return {
        "status": status,
        "warehouses": warehouses,
        "deliveryDays": delivery_days,
        "isInStock": bool(sa.get("is_in_stock")) if sa.get("is_in_stock") is not None else None,
        "isLeadtime": bool(sa.get("is_leadtime")) if sa.get("is_leadtime") is not None else None,
        "isImported": bool(sa.get("is_imported")) if sa.get("is_imported") is not None else None,
    }


def extract_seller(data: Dict[str, Any]) -> Dict[str, Any]:
    """跟卖人数 / 独家 / 最低竞品价 + 每个跟卖卖家明细（零额外请求）。"""
    seller_detail = data.get("seller_detail") if isinstance(data.get("seller_detail"), dict) else {}
    other_offers = data.get("other_offers") if isinstance(data.get("other_offers"), dict) else {}
    seller_name = seller_detail.get("display_name") or None
    seller_reviews = seller_detail.get("seller_reviews") if isinstance(seller_detail.get("seller_reviews"), dict) else {}

    competitor_count = 0
    lowest_competitor_price: Optional[float] = None
    offers: List[Dict[str, Any]] = []
    conditions: List[Dict[str, Any]] = []

    for cond in other_offers.get("conditions") or []:
        if not isinstance(cond, dict):
            continue
        count = _clean_number(cond.get("count"))
        if count is not None:
            competitor_count = max(competitor_count, int(count))
        from_price = _clean_number(cond.get("from_price"))
        if from_price is not None:
            lowest_competitor_price = from_price
        conditions.append(
            {
                "condition": cond.get("condition"),
                "count": int(count) if count is not None else None,
                "from_price": from_price,
                "items": len(cond.get("items") or []) if isinstance(cond.get("items"), list) else 0,
            }
        )
        for item in cond.get("items") or []:
            if not isinstance(item, dict):
                continue
            seller = item.get("seller") if isinstance(item.get("seller"), dict) else {}
            reviews = seller.get("seller_reviews") if isinstance(seller.get("seller_reviews"), dict) else {}
            dcs = _dig(item, "stock_availability", "distribution_centres")
            offers.append(
                {
                    "product_id": item.get("product_id"),
                    "price": _clean_number(item.get("price")),
                    "condition": cond.get("condition"),
                    "isTakealot": item.get("is_takealot") is True,
                    "is_takealot": item.get("is_takealot") is True,
                    "sellerId": seller.get("seller_id"),
                    "sellerName": seller.get("display_name") or None,
                    "sellerRating": _clean_number(reviews.get("average_star_rating")),
                    "sellerReviewCount": int(_clean_number(reviews.get("total_count_value")) or 0),
                    "warehouses": [d.get("text") for d in dcs if isinstance(d, dict) and d.get("text")] if isinstance(dcs, list) else [],
                    "inStock": _dig(item, "stock_availability", "is_in_stock"),
                    "stockStatus": _dig(item, "stock_availability", "status"),
                }
            )

    offers.sort(key=lambda o: (o["price"] is None, o["price"] if o["price"] is not None else 0.0))
    return {
        "sellerName": seller_name,
        "sellerId": seller_detail.get("seller_id"),
        "sellerRating": _clean_number(seller_reviews.get("average_star_rating")),
        "sellerReviewCount": int(_clean_number(seller_reviews.get("total_count_value")) or 0),
        "isBuyboxHolder": bool(seller_name),
        "competitorCount": competitor_count,
        "sellerCount": competitor_count,
        "isExclusive": competitor_count == 0,
        "lowestCompetitorPrice": lowest_competitor_price,
        "conditions": conditions,
        "offerCount": len(offers),
        "offers": offers,
    }


def extract_variants(data: Dict[str, Any]) -> Optional[List[Dict[str, Any]]]:
    selectors = _dig(data, "variants", "selectors")
    if not isinstance(selectors, list) or not selectors:
        return None
    variants = []
    for sel in selectors:
        if not isinstance(sel, dict):
            continue
        options = []
        for opt in sel.get("options") or []:
            if not isinstance(opt, dict):
                continue
            href = opt.get("href") or None
            variant_param = None
            if href:
                match = re.search(r"&(.+)$", href)
                if match:
                    variant_param = match.group(1)
            options.append(
                {
                    "label": opt.get("label") or opt.get("value") or "",
                    "variantParam": variant_param,
                    "enabled": opt.get("is_enabled") is not False,
                }
            )
        variants.append({"type": sel.get("selector_type") or sel.get("type") or "unknown", "title": sel.get("title") or "", "options": options})
    return variants


def _strip_html(text: Any) -> str:
    if not isinstance(text, str):
        return ""
    out = re.sub(r"<[^>]+>", " ", text)
    out = out.replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
    return _WS_RE.sub(" ", out).strip()


def extract_attributes(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    out = []
    for item in _dig(data, "product_information", "items", default=[]) or []:
        if not isinstance(item, dict):
            continue
        name = item.get("display_name") or item.get("name") or item.get("id")
        value = _strip_html(item.get("displayable_text") or item.get("value") or "")
        if name and value:
            out.append({"name": name, "value": value})
    return out


def extract_badges(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    out = []
    for item in _dig(data, "badges", "items", default=[]) or []:
        if not isinstance(item, dict):
            continue
        out.append({"id": item.get("id"), "type": item.get("type"), "value": item.get("value")})
    return out


def parse_product(data: Any, plid: Optional[str] = None, tsin: Optional[str] = None) -> Dict[str, Any]:
    """Raw product-details JSON → the rich product row the UI reads."""
    if not isinstance(data, dict):
        data = {}
    crumbs = extract_breadcrumbs(data)
    rating = extract_rating(data)
    seller = extract_seller(data)
    shipping = extract_shipping(data)
    price = extract_price(data)
    layer = data.get("data_layer") if isinstance(data.get("data_layer"), dict) else {}
    data_tsin = layer.get("tsin")
    # 平台自身的标识（用于校验"返回的确实是这个商品"，防止张冠李戴）
    api_ident = {
        "metaIdentifier": _dig(data, "meta", "identifier"),
        "coreId": _dig(data, "core", "id"),
        "tsin": data_tsin,
        "productLineSku": layer.get("productlineSku"),
    }
    product_line = layer.get("productlineSku")
    if not plid:
        plid = _dig(data, "meta", "identifier") or (str(product_line).split("-")[0] if product_line else None) or _dig(data, "core", "id")
        if plid is not None and not str(plid).upper().startswith("PLID"):
            digits = re.sub(r"\D", "", str(plid))
            plid = "PLID" + digits if digits else str(plid)
    if not tsin and isinstance(data_tsin, str):
        tsin = data_tsin
    if not tsin:
        tsin = _dig(data, "buybox", "items", 0, "sku")
        tsin = "TSIN{0}".format(tsin) if isinstance(tsin, (int, str)) and str(tsin).strip() else None

    department = layer.get("departmentname")
    category_names = layer.get("categoryname") if isinstance(layer.get("categoryname"), list) else None
    lowest = seller.get("lowestCompetitorPrice")
    return {
        "plid": plid,
        "tsin": tsin,
        "apiIdentity": api_ident,
        "title": rating["title"],
        "subtitle": rating["subtitle"],
        "brand": rating["brand"],
        "price": price,
        "prettyPrice": pretty_price(data),
        "pretty_price": pretty_price(data),
        "currency": "ZAR",
        "rating": rating["rating"],
        "reviews": rating["reviewCount"],
        "reviewCount": rating["reviewCount"],
        "starRating": rating["starRating"],
        "ratingDistribution": rating["distribution"],
        "category": {
            "path": crumbs["path"],
            "l1": crumbs["l1"],
            "l2": crumbs["l2"],
            "l3": crumbs["l3"],
            "names": crumbs["names"],
        },
        "categoryPath": crumbs["path"],
        "categoryL1": crumbs["l1"],
        "categoryL2": crumbs["l2"],
        "categoryL3": crumbs["l3"],
        "categoryName": " > ".join(category_names) if category_names else crumbs["path"],
        "department": department,
        "departmentname": department,
        "image": rating["imageUrl"],
        "imageUrl": rating["imageUrl"],
        "images": extract_images(data),
        "attributes": extract_attributes(data),
        "badges": extract_badges(data),
        "description": _strip_html(_dig(data, "description", "html"))[:4000],
        "url": "https://www.takealot.com/product/{0}".format(plid) if plid else None,
        "desktopHref": data.get("desktop_href"),
        "stock": {
            "status": shipping["status"],
            "statusText": shipping["status"],
            "inStock": shipping["isInStock"],
            "isInStock": shipping["isInStock"],
            "warehouses": shipping["warehouses"],
            "distributionCentres": shipping["warehouses"],
            "deliveryDays": shipping["deliveryDays"],
            "isLeadtime": shipping["isLeadtime"],
            "isImported": shipping["isImported"],
            "fulfillmentType": (
                "takealot_fulfillment"
                if shipping["warehouses"]
                else ("seller_fulfillment" if shipping["status"] and "ships in" in str(shipping["status"]).lower() else None)
            ),
        },
        "seller": {
            "name": seller["sellerName"],
            "id": seller["sellerId"],
            "rating": seller["sellerRating"],
            "reviewCount": seller["sellerReviewCount"],
            "isBuyboxHolder": seller["isBuyboxHolder"],
        },
        "sellerDetail": {
            "displayName": seller["sellerName"],
            "sellerId": seller["sellerId"],
            "averageStarRating": seller["sellerRating"],
            "totalCountValue": seller["sellerReviewCount"],
        },
        "sellerCount": seller["sellerCount"],
        "competitorCount": seller["competitorCount"],
        "isExclusive": seller["isExclusive"],
        "lowestCompetitorPrice": lowest,
        "competitorGap": None if lowest is None or not price else round(price - lowest, 2),
        "conditions": seller["conditions"],
        "offers": seller["offers"],
        "offerCount": seller["offerCount"],
        "topOffers": seller["offers"][:3],
        "variants": extract_variants(data),
        "dataLayer": {k: layer.get(k) for k in ("sku", "tsin", "totalPrice", "departmentname", "categoryname", "productlineSku")},
        "rateHint": _rate_hint(crumbs, department, category_names, rating["title"]),
    }


def _rate_hint(crumbs: Dict[str, Any], department: Any, category_names: Any, title: Any) -> str:
    """The exact string handed to ``reviewRateFor`` (category path + title)."""
    parts = [crumbs.get("path"), department, " > ".join(category_names) if category_names else None, title]
    return " ".join(str(p) for p in parts if p)


# --------------------------------------------------------------------------
# Transport ladder: proxy → direct → blocked (+ ingest)
# --------------------------------------------------------------------------

def proxy_url() -> Optional[str]:
    env = (os.environ.get(PROXY_ENV) or "").strip()
    if env:
        return env
    data = read_state("stores.json", {})
    if isinstance(data, dict):
        cfg = data.get("crawler")
        if isinstance(cfg, dict):
            value = str(cfg.get("proxy") or "").strip()
            if value:
                return value
    return None


def _raw_json(url: str, timeout: float, proxy: Optional[str]) -> Tuple[Optional[Any], Optional[str]]:
    handlers: List[Any] = []
    if proxy:
        handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
    opener = urllib.request.build_opener(*handlers)
    req = urllib.request.Request(url, headers=dict(HEADERS), method="GET")
    try:
        with opener.open(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", "replace")
        if not raw.strip():
            return {}, None
        return json.loads(raw), None
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", "replace")[:200]
        except Exception:
            detail = ""
        if exc.code == 403:
            return None, "HTTP 403 Forbidden (Cloudflare blocked this egress)"
        return None, sanitize("HTTP {0} {1} {2}".format(exc.code, exc.reason, detail))
    except Exception as exc:
        return None, sanitize("{0}: {1}".format(type(exc).__name__, exc))


def http_json(url: str, timeout: float) -> Tuple[Optional[Any], Optional[str], str]:
    """Try the ladder in order; returns ``(data, error, transport)``."""
    errors: List[str] = []
    proxy = proxy_url()
    if proxy:
        data, err = _raw_json(url, timeout, proxy)
        if err is None:
            _record(transport="proxy")
            return data, None, "proxy"
        errors.append("proxy({0}) {1}".format(proxy, err))
    data, err = _raw_json(url, timeout, None)
    if err is None:
        _record(transport="direct")
        return data, None, "direct"
    errors.append("direct {0}".format(err))
    message = " | ".join(errors)
    _record(transport="blocked", error=message)
    return None, message, "blocked"


def _record(transport: Optional[str] = None, error: Optional[str] = None) -> None:
    with _LOCK:
        if transport:
            _TRANSPORT["transport"] = transport
        if error:
            _TRANSPORT["lastError"] = error
            _TRANSPORT["lastErrorAt"] = _iso()


def product_url(plid: str) -> str:
    return "{0}/product-details/{1}".format(API_BASE, plid)


# 连通性探针用的**公开商品**（一件男式T恤：任何市场都能看到的公开目录项，与本店商品无关）。
# 探针只需要"能取回 200 + JSON"，所以：
#   1) 别换成客户自己的商品（那是客户业务数据）；
#   2) 别在匿名化/清理时把它改成映射值 —— 换成一个不存在的 PLID，会让客户机的自检
#      与 probe_direct 永远报"公开抓取通道不通"（实测映射值 PLID11563976 就是 404）。
PUBLIC_PROBE_PLID = "PLID96730174"


def reviews_url(plid: str, page: int) -> str:
    """Review page URL — deliberately WITHOUT a sort parameter.

    The endpoint exposes exactly two sorts (`SO_MOST_HELPFUL`, the default, and
    `SO_LATEST`), and **neither is chronological**: `SO_LATEST` is stale on this
    API (measured on a live product it hid every review from the last two months,
    e.g. a review dated 5 days ago was absent while the newest it returned was
    75 days old), and the default order interleaves years. So the review window
    cannot be derived from page order — it has to be a full enumeration with the
    dates counted client-side (see `_tally`). The default sort is the superset:
    enumerating it reproduced the union of both orders exactly.
    """
    return "{0}/product-reviews/plid/{1}?page={2}".format(API_BASE, plid_num(plid), page)


def plid_num(plid: Any) -> str:
    """``normalizePlid`` — bare numeric id for the review route."""
    return re.sub(r"^PLID", "", str(plid or "").strip(), flags=re.I).strip()


def normalize_target(target: Any) -> Dict[str, Any]:
    """URL / ``PLID123`` / bare digits / ``TSIN…`` → a resolvable target."""
    raw = str(target or "").strip()
    if not raw:
        return {"target": "", "kind": "empty", "plid": None, "tsin": None, "url": None}
    text = urllib.parse.unquote(raw)
    plid_match = re.search(r"(PLID)\s*(\d{5,})", text, re.I)
    tsin_match = re.search(r"(TSIN)\s*[-_ ]?(\d{4,})", text, re.I)
    if plid_match:
        plid = "PLID" + plid_match.group(2)
        return {"target": raw, "kind": "plid", "plid": plid, "tsin": None, "url": product_url(plid)}
    if tsin_match:
        tsin = "TSIN" + tsin_match.group(2)
        return {"target": raw, "kind": "tsin", "plid": None, "tsin": tsin, "url": product_url(tsin)}
    bare = re.search(r"\b(\d{5,10})\b", text)
    if bare:
        # a bare 8-digit number on a takealot URL is a PLID; a bare 8-digit TSIN
        # is indistinguishable, and the product route accepts both shapes.
        plid = "PLID" + bare.group(1)
        return {"target": raw, "kind": "plid", "plid": plid, "tsin": None, "url": product_url(plid)}
    return {"target": raw, "kind": "opaque", "plid": None, "tsin": None, "url": None}


def fetch_product(plid: str) -> Tuple[Optional[Any], Optional[str], str]:
    return http_json(product_url(plid), PRODUCT_TIMEOUT)


def fetch_review_windows(plid: str, now_ms: Optional[float] = None) -> Tuple[Dict[str, Any], Dict[str, Any], str, Optional[str]]:
    """Live paging with bounded concurrency — ``fetchReviewWindows`` port.

    Uses the very same counter as the ingest path (``_tally``), so a relayed
    payload and a live fetch can never drift apart.
    """
    errors: List[str] = []
    transport_box: Dict[str, Optional[str]] = {"value": None}

    def fetch_one(page: int) -> Any:
        data, err, transport = http_json(reviews_url(plid, page), REVIEW_TIMEOUT)
        transport_box["value"] = transport
        if err is not None:
            errors.append("page {0}: {1}".format(page, err))
            return None
        return data

    def fetch_batch(batch: List[int]) -> List[Any]:
        bodies: List[Any] = [None] * len(batch)
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=max(1, min(CONCURRENCY, len(batch))))
        try:
            futures = {executor.submit(fetch_one, p): idx for idx, p in enumerate(batch)}
            for future in concurrent.futures.as_completed(futures):
                idx = futures[future]
                try:
                    bodies[idx] = future.result()
                except Exception as exc:  # pragma: no cover - defensive
                    log.debug("takealot-erp crawler: review fetch failed: %s", exc)
                    bodies[idx] = None
        finally:
            executor.shutdown(wait=True)  # bounded: never leave threads running
        return bodies

    now = float(now_ms) if now_ms else _now_ms()
    w, diag = _tally(fetch_batch, now)
    error = errors[0] if errors else None
    return w, diag, (transport_box["value"] or "blocked"), error


def probe_direct(timeout: float = 5.0) -> bool:
    """Reach the public API without the proxy (``crawler/status?probe=1``)."""
    data, err = _raw_json(product_url(PUBLIC_PROBE_PLID), timeout, None)
    ok = err is None and isinstance(data, dict)
    with _LOCK:
        _TRANSPORT["directReachable"] = ok
        _TRANSPORT["lastProbeAt"] = _iso()
        if not ok:
            _TRANSPORT["lastError"] = sanitize(err)
            _TRANSPORT["lastErrorAt"] = _iso()
    return ok


HINT_BLOCKED = (
    "公网出口被 Cloudflare 拦截（403）。三种取数方式任选：1) 设置 TAKEALOT_API_PROXY（或 state/stores.json 的 "
    "crawler.proxy）指向 Takealot 接受的出口代理；2) 把抓到的原始 JSON 通过 POST /crawler/ingest 推入；"
    "3) 把文件放进后端 state/ingest/*.json 投放目录（可由能访问 Takealot 的机器 scp/共享写入），"
    "后端在 /crawler/status 与 /crawler/pull 时会自动吸收并写入 5 天速度缓存。"
)


def hint() -> str:
    proxy = proxy_url()
    if proxy:
        return "代理已配置（{0}）。若仍被拦截，请改用 /crawler/ingest 或 state/ingest 投放目录。".format(proxy)
    return HINT_BLOCKED


# --------------------------------------------------------------------------
# Velocity cache — state/velocity_cache.json, TTL 5 days (migration 027)
# --------------------------------------------------------------------------

def cache_filename() -> str:
    return "velocity_cache.json"


def cache_load() -> Dict[str, Any]:
    data = read_state(cache_filename(), {})
    if not isinstance(data, dict):
        return {}
    entries = data.get("entries")
    if isinstance(entries, dict):
        return entries
    # tolerate a flat {plid: entry} file
    return {k: v for k, v in data.items() if isinstance(v, dict)}


def cache_save(entries: Dict[str, Any]) -> None:
    write_state(cache_filename(), {"entries": entries, "updatedAt": _iso()})


def _age_days(fetched_at_ms: Any) -> float:
    num = _clean_number(fetched_at_ms)
    if not num:
        return 1e9
    return (_now_ms() - num) / 86400000.0


def cache_get(plid: str, ttl_days: float = CACHE_TTL_DAYS) -> Optional[Dict[str, Any]]:
    entry = cache_load().get(plid_num(plid)) if plid else None
    if not isinstance(entry, dict):
        return None
    if _age_days(entry.get("fetchedAtMs")) > ttl_days:
        return None
    return entry


def cache_get_any(plid: str) -> Optional[Dict[str, Any]]:
    entry = cache_load().get(plid_num(plid)) if plid else None
    return entry if isinstance(entry, dict) else None


def cache_put(plid: str, entry: Dict[str, Any]) -> Dict[str, Any]:
    entries = cache_load()
    key = plid_num(plid)
    entry = dict(entry)
    entry.setdefault("fetchedAtMs", _now_ms())
    entry["fetchedAt"] = entry.get("fetchedAt") or _iso(_clean_number(entry.get("fetchedAtMs")) / 1000.0 if entry.get("fetchedAtMs") else None)
    entry["plid"] = key
    entries[key] = entry
    # keep the file bounded: 400 most recent entries
    if len(entries) > 400:
        ordered = sorted(entries.items(), key=lambda kv: _clean_number(kv[1].get("fetchedAtMs")) or 0, reverse=True)
        entries = dict(ordered[:400])
    cache_save(entries)
    return entry


def cache_items(limit: int = 50) -> List[Dict[str, Any]]:
    entries = cache_load()
    rows = []
    for key, entry in entries.items():
        if not isinstance(entry, dict):
            continue
        product = entry.get("product") or {}
        sales = entry.get("sales") or {}
        rows.append(
            {
                "plid": key,
                "title": product.get("title") or "",
                "price": product.get("price"),
                "sales": sales.get("estimated_monthly_sales"),
                "monthlySales": sales.get("estimated_monthly_sales"),
                "rate": entry.get("rate"),
                "rateSource": sales.get("rateSource") or entry.get("rateSource"),
                "fetchedAt": entry.get("fetchedAt"),
                "transport": entry.get("transport"),
                "fresh": _age_days(entry.get("fetchedAtMs")) <= CACHE_TTL_DAYS,
                "windows": entry.get("windows"),
                "sellerCount": product.get("sellerCount"),
            }
        )
    rows.sort(key=lambda r: r.get("fetchedAt") or "", reverse=True)
    try:
        cut = int(limit)
    except (TypeError, ValueError):
        cut = 50
    return rows[: max(1, min(cut, 400))]


# --------------------------------------------------------------------------
# Drop-folder ingest — state/ingest/*.json (the practical live path)
# --------------------------------------------------------------------------

def ingest_dirs() -> Dict[str, Path]:
    base = state_dir() / "ingest"
    return {"root": base, "done": base / "done", "failed": base / "failed"}


def _ensure_ingest_dirs() -> Dict[str, Path]:
    dirs = ingest_dirs()
    for path in (dirs["root"], dirs["done"], dirs["failed"]):
        try:
            path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:  # pragma: no cover
            log.warning("takealot-erp crawler: cannot create %s: %s", path, exc)
    return dirs


def ingest_log() -> Dict[str, Any]:
    data = read_state("ingest_log.json", {})
    if not isinstance(data, dict):
        data = {}
    data.setdefault("ingested", 0)
    data.setdefault("failed", 0)
    data.setdefault("errors", [])
    return data


def _move_file(src: Path, dest_dir: Path) -> Optional[str]:
    try:
        dest_dir.mkdir(parents=True, exist_ok=True)
        target = dest_dir / src.name
        if target.exists():
            target = dest_dir / "{0}.{1}{2}".format(src.stem, int(time.time()), src.suffix)
        shutil.move(str(src), str(target))
        return str(target)
    except OSError as exc:  # pragma: no cover
        log.warning("takealot-erp crawler: cannot move %s: %s", src, exc)
        return None


def reap_drop_folder() -> Dict[str, Any]:
    """Absorb every ``state/ingest/*.json`` file; malformed → ``failed/``."""
    dirs = _ensure_ingest_dirs()
    log_data = ingest_log()
    report = {"ingested": 0, "failed": 0, "files": [], "errors": list(log_data.get("errors") or [])}
    try:
        candidates = sorted(p for p in dirs["root"].glob("*.json") if p.is_file())
    except OSError:  # pragma: no cover
        candidates = []
    for path in candidates:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                body = json.load(fh)
            if not isinstance(body, dict):
                raise ValueError("payload is not a JSON object")
            result = ingest_payload(body)
            if not result.get("ok"):
                raise ValueError(result.get("error") or "ingest rejected the payload")
            report["ingested"] += 1
            report["files"].append({"file": path.name, "plid": result.get("plid"), "sales": _dig(result, "sales", "estimated_monthly_sales")})
            log_data["ingested"] = int(log_data.get("ingested") or 0) + 1
            _move_file(path, dirs["done"])
        except Exception as exc:
            report["failed"] += 1
            entry = {"file": path.name, "error": sanitize(exc), "at": _iso()}
            log_data["failed"] = int(log_data.get("failed") or 0) + 1
            errors = list(log_data.get("errors") or [])
            errors.insert(0, entry)
            log_data["errors"] = errors[:50]
            report["errors"] = log_data["errors"]
            _move_file(path, dirs["failed"])
    log_data["lastRun"] = _iso()
    log_data["root"] = str(dirs["root"])
    write_state("ingest_log.json", log_data)
    report["totalIngested"] = log_data.get("ingested")
    report["totalFailed"] = log_data.get("failed")
    report["dir"] = str(dirs["root"])
    return report


# --------------------------------------------------------------------------
# Payload builders
# --------------------------------------------------------------------------

def _windows_from_body(body: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    # NOTE: an explicitly supplied EMPTY list is meaningful — it means the relay
    # crawled and page 1 was already empty — so presence is checked by key, not
    # by truthiness.
    if "reviewPages" in body:
        raw_pages = body.get("reviewPages")
    elif "pages" in body:
        raw_pages = body.get("pages")
    else:
        raw_pages = None
    supplied = raw_pages is not None
    pages: Dict[int, Any] = {}
    if isinstance(raw_pages, dict):
        for key, value in raw_pages.items():
            try:
                pages[int(key)] = value
            except (TypeError, ValueError):
                continue
    elif isinstance(raw_pages, list):
        for idx, value in enumerate(raw_pages, start=1):
            pages[idx] = value
    if supplied:
        # The caller handed us the pages a relay fetched. The page after the
        # last supplied one is what ended that crawl, so the shared counter sees
        # an empty page there — exactly what a live `fetchReviewWindows` sees.
        return count_windows(pages, now_ms=body.get("nowMs") or body.get("now"))
    provided = body.get("windows")
    if isinstance(provided, dict):
        w = {
            "total": int(_clean_number(provided.get("total")) or 0),
            "reviews_7d": int(_clean_number(provided.get("reviews_7d")) or 0),
            "reviews_30d": int(_clean_number(provided.get("reviews_30d")) or 0),
            "reviews_90d": int(_clean_number(provided.get("reviews_90d")) or 0),
            "reviews_180d": int(_clean_number(provided.get("reviews_180d")) or 0),
            "pagesFetched": int(_clean_number(provided.get("pagesFetched")) or 0),
            "truncated": bool(provided.get("truncated")),
        }
        return w, {"parsed": 0, "failed": 0, "formats": {}, "unparsed": [], "samples": [], "pages": [], "stopReason": "supplied"}
    return (
        {"total": 0, "reviews_7d": 0, "reviews_30d": 0, "reviews_90d": 0, "reviews_180d": 0, "pagesFetched": 0, "truncated": False},
        {"parsed": 0, "failed": 0, "formats": {}, "unparsed": [], "samples": [], "pages": [], "stopReason": "no-reviews-supplied"},
    )


def build_payload(plid: str, product: Dict[str, Any], windows: Dict[str, Any], transport: str,
                  diag: Optional[Dict[str, Any]] = None, fetched_at_ms: Optional[float] = None,
                  cached: bool = False, reviews: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    hint_text = product.get("rateHint") or " ".join(
        [str(product.get("categoryPath") or ""), str(product.get("title") or "")]
    )
    sales = estimate_sales(windows, hint_text, product.get("price"))
    entry = cache_put(
        plid,
        {
            "product": product,
            "windows": sales["windows"],
            "sales": sales,
            "rate": sales["review_rate"],
            "rateSource": sales["rateSource"],
            "rateNote": sales["rateNote"],
            "fetchedAt": _iso((fetched_at_ms or _now_ms()) / 1000.0),
            "fetchedAtMs": fetched_at_ms or _now_ms(),
            "transport": transport,
            "source": "public-api",
        },
    )
    return {
        "ok": True,
        "mode": "live",
        "transport": transport,
        "cached": cached,
        "plid": plid_num(plid),
        "target": plid,
        "product": product,
        "identity": {
            "requested": plid,
            "apiMetaIdentifier": (product.get("apiIdentity") or {}).get("metaIdentifier"),
            "apiCoreId": (product.get("apiIdentity") or {}).get("coreId"),
            "apiTsin": (product.get("apiIdentity") or {}).get("tsin"),
            "basis": "平台 product-details 响应自身的标识；与请求不一致时后端会拒绝采用",
        },
        "windows": sales["windows"],
        "rate": sales["review_rate"],
        "rateSource": sales["rateSource"],
        "rateNote": sales["rateNote"],
        "sales": sales,
        "reviews": (reviews or [])[:20],
        "dateParse": diag or {},
        "fetchedAt": entry.get("fetchedAt"),
    }


def payload_from_entry(entry: Dict[str, Any], plid: str, target: Any = None, cached: bool = True) -> Dict[str, Any]:
    sales = entry.get("sales") or estimate_sales(entry.get("windows"), _dig(entry, "product", "rateHint"), _dig(entry, "product", "price"))
    return {
        "ok": True,
        "mode": "live",
        "transport": entry.get("transport") or "ingest",
        "cached": cached,
        "plid": plid_num(plid),
        "target": target if target is not None else plid,
        "product": entry.get("product"),
        "windows": entry.get("windows") or sales.get("windows"),
        "rate": entry.get("rate") if entry.get("rate") is not None else sales.get("review_rate"),
        "rateSource": entry.get("rateSource") or sales.get("rateSource"),
        "rateNote": entry.get("rateNote") or sales.get("rateNote"),
        "sales": sales,
        "fetchedAt": entry.get("fetchedAt"),
        "stale": _age_days(entry.get("fetchedAtMs")) > CACHE_TTL_DAYS,
    }


def ingest_payload(body: Any) -> Dict[str, Any]:
    """``POST /crawler/ingest`` — parse a relayed payload, zero network."""
    if not isinstance(body, dict):
        return {"ok": False, "mode": "blocked", "error": "ingest body must be a JSON object", "hint": hint()}
    details = body.get("productDetails") if isinstance(body.get("productDetails"), dict) else None
    if details is None and isinstance(body.get("product"), dict):
        details = body["product"]
    raw_plid = body.get("plid") or body.get("target") or body.get("url")
    if not raw_plid and details is not None:
        raw_plid = (
            _dig(details, "meta", "identifier")
            or _dig(details, "data_layer", "prodid")
            or _dig(details, "data_layer", "productlineSku")
            or _dig(details, "core", "id")
        )
    resolved = normalize_target(raw_plid) if raw_plid else {"plid": None, "target": None}
    plid = resolved.get("plid")
    if details is not None and not plid:
        # product-details payloads that only carry a bare numeric id
        numeric = re.search(r"\b(\d{5,10})\b", str(raw_plid or ""))
        plid = "PLID" + numeric.group(1) if numeric else None
    if details is None and not plid:
        return {
            "ok": False,
            "mode": "blocked",
            "error": "ingest payload carries neither productDetails nor a resolvable plid",
            "hint": hint(),
        }
    if details is None and not (body.get("reviewPages") or body.get("pages") or isinstance(body.get("windows"), dict)):
        return {
            "ok": False,
            "mode": "blocked",
            "error": "ingest payload carries neither productDetails nor reviewPages/windows — nothing to compute",
            "hint": hint(),
        }
    product = parse_product(details, plid) if details else None
    if product is not None:
        plid = product.get("plid") or plid
    if not plid:
        return {"ok": False, "mode": "blocked", "error": "ingest payload has no usable PLID", "hint": hint()}
    if product is None:
        product = {
            "plid": plid,
            "tsin": body.get("tsin"),
            "title": body.get("title") or "",
            "brand": body.get("brand"),
            "price": _clean_number(body.get("price")) or 0.0,
            "prettyPrice": None,
            "categoryPath": body.get("category") or body.get("categoryPath"),
            "category": {"path": body.get("category") or body.get("categoryPath"), "l1": None, "l2": None, "l3": None, "names": []},
            "rateHint": " ".join(str(x) for x in (body.get("category"), body.get("title")) if x),
            "offers": [],
            "offerCount": 0,
            "sellerCount": None,
            "isExclusive": None,
            "stock": {"warehouses": []},
            "attributes": [],
            "badges": [],
        }
    product["transport"] = "ingest"
    windows, diag = _windows_from_body(body)
    fetched_at = body.get("fetchedAt")
    fetched_at_ms = _clean_number(body.get("fetchedAtMs"))
    if not fetched_at_ms and isinstance(fetched_at, str) and fetched_at.strip():
        stamp, _fmt = parse_review_date(fetched_at)
        if stamp is None:
            for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
                try:
                    stamp = datetime.strptime(fetched_at.strip(), fmt)
                    break
                except ValueError:
                    continue
        if stamp is not None:
            fetched_at_ms = stamp.timestamp() * 1000.0
    reviews: List[Dict[str, Any]] = []
    raw_pages = body.get("reviewPages") or body.get("pages") or []
    if isinstance(raw_pages, dict):
        raw_pages = [raw_pages[k] for k in sorted(raw_pages, key=lambda x: str(x))]
    if isinstance(raw_pages, list):
        for page in raw_pages:
            reviews.extend(parse_reviews(page))
    payload = build_payload(str(plid), product, windows, "ingest", diag, fetched_at_ms, cached=False, reviews=reviews)
    payload["reviewsParsed"] = len(reviews)
    payload["mode"] = "live"
    _record(transport="ingest")
    return payload


def blocked_payload(target: Any, error: Optional[str], mode: str = "blocked") -> Dict[str, Any]:
    resolved = normalize_target(target) if target else {"plid": None}
    stale = cache_get_any(resolved.get("plid") or "") if resolved.get("plid") else None
    payload = {
        "ok": False,
        "mode": mode,
        "transport": "blocked" if mode == "blocked" else mode,
        "cached": False,
        "plid": plid_num(resolved.get("plid") or "") or None,
        "target": target,
        "product": None,
        "windows": None,
        "rate": None,
        "sales": None,
        "fetchedAt": _iso(),
        "error": sanitize(error) if error else None,
        "hint": hint(),
        "ingestDir": str(ingest_dirs()["root"]),
    }
    if stale:
        payload["cachedFallback"] = {
            "product": stale.get("product"),
            "windows": stale.get("windows"),
            "sales": stale.get("sales"),
            "rate": stale.get("rate"),
            "fetchedAt": stale.get("fetchedAt"),
            "transport": stale.get("transport"),
            "ageDays": round(_age_days(stale.get("fetchedAtMs")), 2),
        }
    return payload


def empty_cached_payload(target: Any) -> Dict[str, Any]:
    """``GET /crawler/pull?cachedOnly=1`` miss — HTTP 200, never a network call."""
    resolved = normalize_target(target) if target else {"plid": None}
    return {
        "ok": False,
        "mode": "empty",
        "transport": "cache",
        "cached": False,
        "plid": plid_num(resolved.get("plid") or "") or None,
        "target": target,
        "product": None,
        "windows": None,
        "rate": None,
        "sales": None,
        "hint": "该 PLID 没有新鲜的速度缓存（TTL 5 天）。可用 POST /crawler/pull 抓取，或把原始 JSON 放进 state/ingest/ 投放目录后重试。",
    }


def pull(target: Any, force: bool = False, cached_only: bool = False,
         demo_factory: Optional[Callable[[Any], Dict[str, Any]]] = None,
         reap: bool = True) -> Dict[str, Any]:
    """``POST/GET /crawler/pull`` — cache first, then the transport ladder."""
    if reap:
        try:
            reap_drop_folder()
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("takealot-erp crawler: drop-folder reap failed: %s", exc)

    resolved = normalize_target(target)
    plid = resolved.get("plid")
    if cached_only:
        entry = cache_get(plid) if plid else None
        if entry:
            return payload_from_entry(entry, plid, target=resolved.get("target"), cached=True)
        return empty_cached_payload(resolved.get("target") or target)

    if plid and not force:
        entry = cache_get(plid)
        if entry:
            return payload_from_entry(entry, plid, target=resolved.get("target"), cached=True)

    if not plid:
        # nothing resolvable: deterministic demo row rather than an error
        demo = demo_factory(resolved.get("target")) if demo_factory else None
        if demo:
            windows = _windows_from_body({})[0]
            sales = estimate_sales(windows, demo.get("rateHint"), demo.get("price"))
            return {
                "ok": True,
                "mode": "blocked",
                "transport": "blocked",
                "cached": False,
                "plid": None,
                "target": resolved.get("target"),
                "product": demo,
                "windows": sales["windows"],
                "rate": sales["review_rate"],
                "rateSource": sales["rateSource"],
                "rateNote": sales["rateNote"],
                "sales": sales,
                "fetchedAt": _iso(),
                "hint": "目标无法解析为 PLID/TSIN，已返回确定性样例数据（mode: demo）。",
            }
        return blocked_payload(resolved.get("target") or target, "cannot resolve target to a PLID/TSIN", mode="blocked")

    data, error, transport = fetch_product(plid)
    if error is not None or not isinstance(data, dict) or not data:
        return blocked_payload(plid, error or "empty product-details response")
    product = parse_product(data, plid)
    # 身份校验：请求的是 PLID 时，平台自身标识若与请求不符 → 拒绝采用（宁缺勿错）
    ident = product.get("apiIdentity") or {}
    want_digits = plid_num(plid)
    api_ids = {str(ident.get("metaIdentifier") or ""), str(ident.get("coreId") or "")}
    api_ids = {i for i in api_ids if i}
    if want_digits and api_ids and not any(want_digits in i or i in want_digits for i in api_ids):
        return blocked_payload(
            plid,
            "public response identity mismatch: requested PLID{0} but the API answered with {1}".format(
                want_digits, ", ".join(sorted(api_ids))),
            hint="平台对该 PLID 返回的是另一个商品的数据，已拒绝采用，避免把别人的商品当成本商品。",
        )
    windows, diag, _transport, review_error = fetch_review_windows(plid)
    if not windows.get("total") and review_error:
        diag["reviewError"] = sanitize(review_error)
    payload = build_payload(plid, product, windows, transport, diag)
    payload["target"] = resolved.get("target")
    if review_error:
        payload["reviewsError"] = sanitize(review_error)
    return payload


def status_payload(probe: bool = False) -> Dict[str, Any]:
    """``GET /crawler/status`` — also reaps the drop folder first."""
    ingested = {"ingested": 0, "failed": 0, "errors": []}
    try:
        ingested = reap_drop_folder()
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("takealot-erp crawler: drop-folder reap failed: %s", exc)
    entries = cache_load()
    with _LOCK:
        snapshot = dict(_TRANSPORT)
    direct = snapshot.get("directReachable")
    if probe:
        direct = probe_direct()
        with _LOCK:
            snapshot = dict(_TRANSPORT)
    proxy = proxy_url()
    return {
        "ok": True,
        "proxyConfigured": bool(proxy),
        "proxy": proxy,
        "directReachable": direct,
        "directReachableProbedAt": snapshot.get("lastProbeAt"),
        "lastError": snapshot.get("lastError"),
        "lastErrorAt": snapshot.get("lastErrorAt"),
        "cacheEntries": len(entries),
        "transport": snapshot.get("transport"),
        "hint": hint(),
        "probe": probe,
        "apiBase": API_BASE,
        "ingested": ingested.get("totalIngested") if ingested.get("totalIngested") is not None else int(ingested.get("ingested") or 0),
        "ingestedThisRun": int(ingested.get("ingested") or 0),
        "failed": ingested.get("totalFailed") if ingested.get("totalFailed") is not None else int(ingested.get("failed") or 0),
        "ingestErrors": ingested.get("errors") or [],
        "ingestDir": str(ingest_dirs()["root"]),
        "ingestDoneDir": str(ingest_dirs()["done"]),
        "cachePath": str(state_dir() / cache_filename()),
        "cacheTtlDays": CACHE_TTL_DAYS,
        "pageSize": PAGE_SIZE,
        "maxPages": MAX_PAGES,
        "serverTime": _iso(),
    }


def batch_pull(targets: Any, limit: int = 10, force: bool = False,
               demo_factory: Optional[Callable[[Any], Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Sequential, bounded batch (≤10 per call)."""
    if isinstance(targets, str):
        targets = [targets]
    if not isinstance(targets, list):
        targets = []
    try:
        cap = int(limit)
    except (TypeError, ValueError):
        cap = 10
    cap = max(1, min(cap, 10))
    selected = [t for t in targets if str(t or "").strip()][:cap]
    results: List[Dict[str, Any]] = []
    blocked = 0
    failed = 0
    for target in selected:
        try:
            result = pull(target, force=force, demo_factory=demo_factory)
        except Exception as exc:  # pragma: no cover - defensive
            result = blocked_payload(target, sanitize(exc))
        if result.get("mode") == "blocked":
            blocked += 1
        if not result.get("ok"):
            failed += 1
        results.append(result)
    return {
        "ok": failed == 0,
        "mode": "live" if failed == 0 else ("blocked" if blocked else "partial"),
        "count": len(results),
        "blocked": blocked,
        "failed": failed,
        "results": results,
        "hint": hint() if blocked else None,
        "serverTime": _iso(),
    }


# --------------------------------------------------------------------------
# AI valuation — deterministic evidence first, LLM second
# --------------------------------------------------------------------------

def analysis_cache_get(plid: str, store_id: Any) -> Optional[Dict[str, Any]]:
    data = read_state("ai_analysis.json", {})
    if not isinstance(data, dict):
        return None
    entry = data.get(_analysis_key(plid, store_id))
    if not isinstance(entry, dict):
        return None
    age_hours = (_now_ms() - (_clean_number(entry.get("cachedAtMs")) or 0)) / 3600000.0
    if age_hours > AI_CACHE_TTL_HOURS:
        return None
    return entry


def analysis_cache_put(plid: str, store_id: Any, payload: Dict[str, Any]) -> Dict[str, Any]:
    data = read_state("ai_analysis.json", {})
    if not isinstance(data, dict):
        data = {}
    entry = dict(payload)
    entry["cachedAtMs"] = _now_ms()
    entry["cachedAt"] = _iso()
    data[_analysis_key(plid, store_id)] = entry
    if len(data) > 200:
        ordered = sorted(data.items(), key=lambda kv: _clean_number(kv[1].get("cachedAtMs")) or 0, reverse=True)
        data = dict(ordered[:200])
    write_state("ai_analysis.json", data)
    return entry


def _analysis_key(plid: Any, store_id: Any) -> str:
    return "{0}|{1}".format(plid_num(plid) or str(plid or ""), store_id or "unassigned")


def _competition_band(seller_count: int) -> Tuple[str, str]:
    if seller_count <= 1:
        return "低", "跟卖卖家 {0} 家，几乎没有同款竞争，可自主定价。".format(seller_count)
    if seller_count <= 5:
        return "中", "跟卖卖家 {0} 家，价格战压力中等，需守住保本价。".format(seller_count)
    return "高", "跟卖卖家 {0} 家，同款内卷严重，只能靠价差与时效取胜。".format(seller_count)


def deterministic_score(metrics: Dict[str, Any]) -> Tuple[int, str, str]:
    monthly = int(_clean_number(metrics.get("monthlySales")) or 0)
    seller_count = int(_clean_number(metrics.get("sellerCount")) or 0)
    margin = _clean_number(metrics.get("marginAtRecommended"))
    rating = _clean_number(metrics.get("rating"))
    reviews = int(_clean_number(metrics.get("reviews")) or 0)
    truncated = bool(_dig(metrics, "windows", "truncated"))
    reviews_30d = int(_clean_number(_dig(metrics, "windows", "reviews_30d")) or 0)

    score = 50
    if monthly >= 200:
        score += 22
    elif monthly >= 80:
        score += 15
    elif monthly >= 30:
        score += 8
    elif monthly >= 10:
        score += 3
    else:
        score -= 6
    if seller_count == 0:
        score += 12
    elif seller_count <= 2:
        score += 6
    elif seller_count <= 5:
        score += 0
    elif seller_count <= 10:
        score -= 8
    else:
        score -= 16
    if margin is None:
        score -= 4
    elif margin >= 25:
        score += 12
    elif margin >= 18:
        score += 7
    elif margin >= 10:
        score += 2
    elif margin >= 0:
        score -= 6
    else:
        score -= 16
    if rating is None:
        pass
    elif rating >= 4.5:
        score += 6
    elif rating >= 4.2:
        score += 4
    elif rating >= 3.8:
        score += 0
    elif rating >= 3.2:
        score -= 4
    else:
        score -= 8
    if reviews >= 500:
        score += 6
    elif reviews >= 100:
        score += 3
    if truncated:
        score -= 3
    if reviews_30d == 0:
        score -= 4
    score = max(0, min(100, score))
    verdict = "不建议"
    for threshold, label in VERDICTS:
        if score >= threshold:
            verdict = label
            break
    reasons = "月销约 {0} 件、跟卖 {1} 家、目标价毛利率 {2}%、评分 {3}".format(
        monthly, seller_count, "{0}%".format(round(margin, 1)) if margin is not None else "未知", rating if rating else "无"
    )
    return score, verdict, reasons


def deterministic_analysis(metrics: Dict[str, Any]) -> Dict[str, Any]:
    monthly = int(_clean_number(metrics.get("monthlySales")) or 0)
    seller_count = int(_clean_number(metrics.get("sellerCount")) or 0)
    margin = _clean_number(metrics.get("marginAtRecommended"))
    level, note = _competition_band(seller_count)
    score, verdict, reasons = deterministic_score(metrics)
    windows = metrics.get("windows") or {}
    risks: List[str] = []
    opportunities: List[str] = []
    actions: List[str] = []

    if seller_count >= 8:
        risks.append("跟卖卖家 {0} 家，同款价格战激烈，BuyBox 极易被抢。".format(seller_count))
    if not metrics.get("exclusive") and seller_count:
        lowest = _clean_number(metrics.get("lowestCompetitorPrice"))
        if lowest and metrics.get("recommended"):
            if lowest < float(metrics["recommended"]):
                risks.append("最低竞品价 R {0} 已低于建议售价 R {1}，跟价会吃掉目标毛利。".format(lowest, metrics["recommended"]))
    if margin is not None and margin < 15:
        risks.append("目标价毛利率仅 {0}%，物流与汇率小幅波动即可能亏损。".format(round(margin, 1)))
    if windows.get("truncated"):
        risks.append("评论翻页命中 {0} 页上限，180 天窗口可能少算，销量被低估。".format(MAX_PAGES))
    if int(_clean_number(windows.get("reviews_30d")) or 0) == 0:
        risks.append("近 30 天没有新增评价，动销信号弱，可能是滞销款。")
    if int(_clean_number(metrics.get("reviews")) or 0) < 30:
        risks.append("累计评价不足 30 条，留评率换算的销量噪声大，建议以广告数据复核。")

    if metrics.get("exclusive"):
        opportunities.append("当前没有跟卖卖家（独家 listing），可自主定价并锁定 BuyBox。")
    if monthly >= 100:
        opportunities.append("月销约 {0} 件，属于动销款，适合做首单小批量测款。".format(monthly))
    if metrics.get("dcWarehouses"):
        opportunities.append("商品在 {0} 有 DC 库存，可对齐官方仓发货，时效与转化更高。".format("、".join(metrics["dcWarehouses"][:3])))
    if monthly and monthly < 30:
        opportunities.append("月销较低但竞争少，适合低库存铺货卡位，占住类目关键词。")
    if not opportunities:
        opportunities.append("类目需求稳定，可用差异化套装（加配件/多规格）避开同款比价。")

    if monthly:
        daily = max(0.1, round(monthly / 30.0, 1))
        actions.append("备货：按日均 {0} 件备 30-45 天安全库存（约 {1}-{2} 件）。".format(daily, int(daily * 30), int(daily * 45)))
    if metrics.get("recommended"):
        actions.append("上架价不超过 R {0}（20% 目标毛利价），首期可用 R {1} 卡位。".format(metrics["recommended"], metrics["floor"]))
    if metrics.get("floor"):
        actions.append("设置底价熔断 R {0}（保本价），竞品低于此价立即停售或改规格。".format(metrics["floor"]))
    actions.append("上架 14 天后复抓评论速度，校准留评率档位（当前 {0}）。".format(metrics.get("rateSource") or "default"))
    if seller_count >= 5:
        actions.append("开启 BuyBox 监控规则，对手降价 R 1.00 时自动跟价但不破底价。")

    summary = (
        "{0}。近 30 天新增评论 {1} 条，按留评率档位 {2}% 换算月销约 {3} 件；跟卖 {4} 家（竞争{5}）；"
        "目标价 R {6} 时毛利率 {7}%。综合打分 {8} 分，结论：{9}。"
    ).format(
        metrics.get("title") or "该商品",
        int(_clean_number(windows.get("reviews_30d")) or 0),
        round((_clean_number(metrics.get("ratePercent")) or REVIEW_RATE_TIERS["default"] * 100), 1),
        monthly,
        seller_count,
        level,
        metrics.get("recommended"),
        round(margin, 1) if margin is not None else "未知",
        score,
        verdict,
    )
    return {
        "score": score,
        "verdict": verdict,
        "summary": summary,
        "reasons": reasons,
        "competition": {"level": level, "note": note, "sellerCount": seller_count},
        "risks": risks,
        "opportunities": opportunities,
        "actions": actions,
    }


AI_SCHEMA = (
    '{"score":0-100整数,"verdict":"值得跟卖|可以上新|观望|不建议","summary":"中文2-4句",'
    '"competitionNote":"中文一句","risks":["中文一句"],"opportunities":["中文一句"],"actions":["中文动作建议"]}'
)


def ai_overlay(evidence: Dict[str, Any], key: Optional[str], base: str = DEEPSEEK_BASE,
               model: str = DEEPSEEK_MODEL, timeout: float = AI_TIMEOUT) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Ask DeepSeek to refine the deterministic verdict. Any failure → (None, error)."""
    if not key:
        return None, "no DEEPSEEK_API_KEY configured"
    prompt = (
        "你是南非 Takealot 跨境电商选品分析师。基于下面这份确定性证据（已由后台算好，不要改动数字）"
        "给出结论。只回复 JSON：{0}。score 0-100，verdict 必须是四个中文枚举之一，"
        "summary 2-4 句中文，risks/opportunities 各 2-4 条中文短句，actions 3-5 条可执行中文动作。"
        "不要编造不存在的数据，不要出现绝对化用语与商标词。\n证据：{1}"
    ).format(AI_SCHEMA, json.dumps(evidence, ensure_ascii=False)[:6000])
    body = json.dumps(
        {
            "model": model,
            "messages": [
                {"role": "system", "content": "你是严谨的跨境电商选品分析师，只输出 JSON。"},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.3,
            "max_tokens": 1200,
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        base.rstrip("/") + "/chat/completions",
        data=body,
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json", "Accept": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", "replace")
        parsed = json.loads(raw)
        content = parsed["choices"][0]["message"]["content"]
        match = re.search(r"\{.*\}", content, re.S)
        data = json.loads(match.group(0) if match else content)
        if not isinstance(data, dict):
            return None, "AI reply was not a JSON object"
        return data, None
    except Exception as exc:
        return None, sanitize("{0}: {1}".format(type(exc).__name__, exc))


def _merge_ai(deterministic: Dict[str, Any], ai: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(deterministic)
    score = _clean_number(ai.get("score"))
    if score is not None:
        merged["score"] = max(0, min(100, int(round(score))))
    verdict = str(ai.get("verdict") or "").strip()
    if verdict in ("值得跟卖", "可以上新", "观望", "不建议"):
        merged["verdict"] = verdict
    if str(ai.get("summary") or "").strip():
        merged["summary"] = str(ai["summary"]).strip()
    note = str(ai.get("competitionNote") or "").strip()
    if note:
        merged["competition"] = dict(merged.get("competition") or {}, note=note)
    for key in ("risks", "opportunities", "actions"):
        values = ai.get(key)
        if isinstance(values, list):
            cleaned = [str(v).strip() for v in values if str(v or "").strip()][:6]
            if cleaned:
                merged[key] = cleaned
    return merged


def listing_analysis(plid: Any, store: Dict[str, Any], product: Optional[Dict[str, Any]],
                     windows: Optional[Dict[str, Any]], sales: Optional[Dict[str, Any]],
                     money: Dict[str, Any], key: Optional[str] = None, use_cache: bool = True,
                     force: bool = False, ai_enabled: bool = True) -> Dict[str, Any]:
    """Assemble the `/ai/listing-analysis` payload (deterministic + optional AI)."""
    product = product or {}
    windows = windows or {}
    sales = sales or estimate_sales(windows, product.get("rateHint"), product.get("price"))
    store_id = (store or {}).get("id") or "unassigned"
    target = product.get("plid") or plid
    if use_cache and not force:
        cached_entry = analysis_cache_get(plid or target, store_id)
        if cached_entry:
            out = dict(cached_entry)
            out["cached"] = True
            return out

    supply_cost = _clean_number(money.get("supplyCost")) or 0.0
    cost = _clean_number(money.get("cost")) or 0.0
    freight = _clean_number(money.get("freight")) or 0.0
    dc_fee = _clean_number(money.get("dcFee")) or 0.0
    rate = _clean_number(sales.get("review_rate")) or REVIEW_RATE_TIERS["default"]
    band = money.get("priceBand") if isinstance(money.get("priceBand"), dict) else {}
    price_band = {
        "floor": band.get("floor"),
        "recommended": band.get("recommended"),
        "current": band.get("current") if band.get("current") is not None else product.get("price"),
    }
    success_rate = _clean_number(money.get("successRate"))
    success_rate = success_rate if success_rate is not None else 0.12

    metrics: Dict[str, Any] = {
        "title": product.get("title") or "",
        "monthlySales": sales.get("estimated_monthly_sales"),
        "monthlyRevenue": sales.get("estimated_monthly_revenue"),
        "sales": sales,
        "windows": sales.get("windows") or windows,
        "sellerCount": product.get("sellerCount") if product.get("sellerCount") is not None else 0,
        "exclusive": bool(product.get("isExclusive")),
        "lowestCompetitorPrice": product.get("lowestCompetitorPrice"),
        "rating": product.get("rating"),
        "reviews": product.get("reviews"),
        "recommended": price_band.get("recommended"),
        "floor": price_band.get("floor"),
        "marginAtRecommended": money.get("marginAtRecommended"),
        "rateSource": sales.get("rateSource"),
        "rateLabel": sales.get("rateNote"),
        "ratePercent": (_clean_number(sales.get("review_rate")) or 0) * 100,
        "dcWarehouses": _dig(product, "stock", "warehouses") or [],
        "cost": cost,
        "freight": freight,
        "supplyCost": supply_cost,
        "dcFee": dc_fee,
        "dcTier": money.get("dcTier"),
    }
    deterministic = deterministic_analysis(metrics)
    payback_days = None
    net_unit = _clean_number(money.get("netPerUnitAtRecommended"))
    monthly = int(_clean_number(sales.get("estimated_monthly_sales")) or 0)
    if net_unit and supply_cost and monthly:
        units_month = max(1.0, monthly)
        payback_days = max(1, int(round(supply_cost * 30.0 / (net_unit * units_month))))
    payback_note = (
        "按目标价 R {0}、月销 {1} 件估算，单件净利 R {2}，约 {3} 天可回收 R {4} 的采购+头程成本。".format(
            price_band.get("recommended"), monthly, net_unit if net_unit is not None else 0, payback_days, supply_cost
        )
        if payback_days
        else "缺少采购/头程成本，无法估算回本周期；补齐 cost 与 freight 后可自动计算。"
    )

    ai_used = False
    ai_error = None
    model = None
    merged = deterministic
    if ai_enabled and key:
        evidence = {
            "target": target,
            "storeId": store_id,
            "title": product.get("title"),
            "brand": product.get("brand"),
            "category": product.get("categoryPath"),
            "price": price_band.get("current"),
            "windows": sales.get("windows"),
            "sales": {k: v for k, v in sales.items() if k != "windows"},
            "rateSource": sales.get("rateSource"),
            "sellerCount": metrics["sellerCount"],
            "isExclusive": metrics["exclusive"],
            "lowestCompetitorPrice": metrics["lowestCompetitorPrice"],
            "offers": (product.get("offers") or [])[:3],
            "rating": product.get("rating"),
            "reviews": product.get("reviews"),
            "stock": product.get("stock"),
            "cost": cost,
            "freight": freight,
            "priceBand": price_band,
            "marginAtRecommended": money.get("marginAtRecommended"),
            "feeBreakdown": money.get("feeBreakdown"),
            "deterministicScore": deterministic["score"],
            "deterministicVerdict": deterministic["verdict"],
        }
        ai, ai_error = ai_overlay(evidence, key)
        if ai:
            merged = _merge_ai(deterministic, ai)
            ai_used = True
            model = DEEPSEEK_MODEL

    payload: Dict[str, Any] = {
        "ok": True,
        "ai": ai_used,
        "model": model,
        "target": target,
        "plid": plid_num(target) if target else None,
        "storeId": store_id,
        "storeName": (store or {}).get("name") or "",
        "score": merged["score"],
        "verdict": merged["verdict"],
        "summary": merged["summary"],
        "reasons": merged.get("reasons"),
        "monthlySales": sales.get("estimated_monthly_sales"),
        "monthlyRevenue": sales.get("estimated_monthly_revenue"),
        "reviewRate": sales.get("review_rate"),
        "rateSource": sales.get("rateSource"),
        "rateNote": sales.get("rateNote"),
        "sellerCount": metrics["sellerCount"],
        "isExclusive": metrics["exclusive"],
        "competition": merged["competition"],
        "priceBand": price_band,
        "marginAtRecommended": money.get("marginAtRecommended"),
        "paybackNote": payback_note,
        "paybackDays": payback_days,
        "risks": merged["risks"],
        "opportunities": merged["opportunities"],
        "actions": merged["actions"],
        "evidence": {
            "windows": sales.get("windows"),
            "sales": sales,
            "product": {
                "plid": product.get("plid"),
                "tsin": product.get("tsin"),
                "title": product.get("title"),
                "brand": product.get("brand"),
                "categoryPath": product.get("categoryPath"),
                "price": product.get("price"),
                "prettyPrice": product.get("prettyPrice"),
                "image": product.get("image"),
                "rating": product.get("rating"),
                "reviews": product.get("reviews"),
                "stock": product.get("stock"),
                "badges": product.get("badges"),
                "attributes": (product.get("attributes") or [])[:12],
                "transport": product.get("transport"),
            },
            "offers": (product.get("offers") or [])[:3],
            "offerCount": product.get("offerCount") or 0,
            "conditions": product.get("conditions") or [],
            "feeBreakdown": money.get("feeBreakdown"),
            "cost": cost,
            "freight": freight,
            "supplyCost": supply_cost,
            "dcTier": money.get("dcTier"),
            "dcFee": dc_fee,
            "successRate": success_rate,
            "vatRate": money.get("vatRate"),
        },
    }
    if ai_error:
        payload["aiError"] = ai_error
    payload["cached"] = False
    return analysis_cache_put(target or plid, store_id, payload)


def cached_analysis(target: Any, store_id: Any) -> Dict[str, Any]:
    """``GET /ai/listing-analysis?cachedOnly=1`` — cache only, never an LLM call."""
    resolved = normalize_target(target) if target else {"plid": None, "target": target}
    plid = resolved.get("plid") or target
    entry = analysis_cache_get(plid, store_id) if plid else None
    if entry:
        out = dict(entry)
        out["cached"] = True
        return out
    return {
        "ok": False,
        "ai": None,
        "mode": "empty",
        "cached": False,
        "target": resolved.get("target") or target,
        "plid": plid_num(plid) if plid else None,
        "storeId": store_id or None,
        "hint": "该 PLID+店铺在 24 小时分析缓存中没有记录；先调用 POST /ai/listing-analysis 生成。",
    }
