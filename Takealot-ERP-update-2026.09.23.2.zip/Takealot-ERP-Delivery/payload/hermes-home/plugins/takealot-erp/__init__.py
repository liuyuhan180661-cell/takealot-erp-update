"""Takealot ERP — Hermes agent-side plugin shim: 12 tools + the Chinese intent router.

The capability of this package lives in four places:

* ``dashboard/plugin_api.py`` — the FastAPI backend mounted at
  ``/api/plugins/takealot-erp/`` (gated by ``plugins.enabled`` in ``config.yaml``).
* ``dashboard/crawler.py`` — the public-API crawler/valuation core used by that backend
  (transport ladder proxy→direct→blocked, 留评率→销量 estimation ported 1:1 from the
  OpenListing ``salesEstimate.ts``, 5-day velocity cache, ``state/ingest`` drop folder).
  It never reads or sends the Seller ``X-API-Key``.
* ``tools.py`` — **this half**: the agent-side tool surface (12 tools, read-only + crawl) and the
  deterministic 中文意图路由 hook. Every tool calls the SAME backend functions the UI's REST
  endpoints call, loaded by file location, so there is one implementation of the money math and
  one source of truth for the data.
* ``skills/takealot-erp-operator/SKILL.md`` — the domain skill for agent use. NOTE: a
  ``plugin.yaml`` package's ``skills/`` folder is NOT auto-loaded (only portable
  ``plugin.json`` Agent-Plugin packages are), so the live copy the agent actually sees is
  installed at ``<hermes home>\\skills\\takealot-erp-operator\\SKILL.md``. Keep both copies
  identical.
* ``<hermes home>\\desktop-plugins\\takealot-erp\\plugin.js`` — the desktop UI half. It lives
  in the desktop plugin door (auto-enabled, hot-reloading) rather than in this package's
  ``desktop/`` folder, because a unified package's desktop half ships opt-in and would need a
  Settings toggle.

No write-to-platform tool exists, on purpose: changing price/stock, creating an offer and
publishing a loadsheet all stay in the UI. The intent router also refuses such requests in
words and points at the界面 modules.
"""

from __future__ import annotations

import sys

__version__ = "1.2.0"


def _tools_module():
    """Load ``tools.py`` next to this file (relative import first, then by path)."""
    try:
        from . import tools as _tools  # type: ignore[import-not-found]
        return _tools
    except Exception:
        pass
    name = "hermes_takealot_erp_agent_tools"
    cached = sys.modules.get(name)
    if cached is not None:
        return cached
    import importlib.util
    from pathlib import Path

    path = Path(__file__).resolve().parent / "tools.py"
    spec = importlib.util.spec_from_file_location(name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError("takealot-erp: cannot create a spec for {0}".format(path))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def register(ctx) -> None:  # noqa: ANN001 - PluginContext
    """Register the 12 tools (toolset ``takealot_erp``) and the two routing hooks.

    Tools: 8 read-only (overview/orders/products/finance/fulfilment/collection/listings/selfcheck)
    and 4 crawl-side (crawl_product/market_search/collection_add/route_verdict). Hooks:
    ``pre_llm_call`` (词表命中 → 注入硬指令) and ``pre_tool_call`` (把实际调用的工具接进审计).
    """
    tools = _tools_module()
    tools.register_tools(ctx)
    tools.register_hooks(ctx)
