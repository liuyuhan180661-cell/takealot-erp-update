---
name: qwen-token-plan-setup
description: Use when configuring the model channel (千问/Token Plan/模型选不到).
---

# 一句话配好模型通道（阿里百炼 / Token Plan / Coding Plan / DashScope）

## 什么时候用（用户可能这么说）

- "帮我配一下千问" / "配好 Token Plan" / "换模型通道"
- "模型只有 qwen3.7-max，其它的选不到" / "模型列表里没有 deepseek"
- "AI 文案生成不了" / "帮我设默认模型" / "用哪个模型省钱"

## 三步，别跳

**1. 先问一句套餐档位**（三档的端点和 key 变量各不相同，选错会报"无可用通道"——**那不是网络问题**，别去调代理）：

| 用户说 | `--preset` |
|---|---|
| 百炼 Token Plan，中国买/中国机器 | `token-plan-cn` |
| Token Plan，国际站 | `token-plan` |
| Coding Plan（写代码套餐） | `coding-plan-cn` / `coding-plan` |
| 百炼按量付费（不是套餐） | `dashscope-cn` / `dashscope-intl` |

**2. 跑探测脚本（默认 dry-run：先把将执行的命令给用户看）**

```bash
"<Hermes venv python>" "<脚本路径>" --preset token-plan-cn
```

脚本路径按这个顺序找（哪个存在用哪个）：
1. 本技能目录旁：`skills/qwen-token-plan-setup/setup_llm_provider.py`
2. 交付包解压目录：`%USERPROFILE%\tkl\Takealot-ERP-Delivery\setup_llm_provider.py`
3. 插件目录：`%LOCALAPPDATA%\hermes\plugins\<插件 id>\delivery\setup_llm_provider.py`

都找不到 → 让用户重新解压交付包（或从仓库 `scripts/setup_llm_provider.py` 拷一份）。

脚本会：读 key（环境变量 → `<hermes home>\.env` → `--key-file`）→ 用**客户自己的 key** 探 `/models`
→ 得到该套餐**真实可用**的文本/推理模型清单 → 生成 `hermes config set` 命令。

**3. 用户确认后加 `--apply`**，然后验证：
```bash
hermes doctor                     # 连通性
hermes config get model           # provider = custom:qwen-tokenplan，default = 选定模型
```
最后让用户在 ERP 里**生成一次 AI 文案**，看返回的 `llmProvider` / `llmModel` 是否是刚配的 —— 这条才是端到端证据。

## 铁律

- **绝不让用户把 key 贴进对话**✗。key 只该待在 Hermes 界面或 `<hermes home>\.env` 里；脚本从那里读，全程只显示长度、不回显
- **不要手改 `config.yaml`**，一律走 `hermes config set`（官方路径，避免结构写坏）
- **不要删改别的 provider**；只在 `providers.<名>` 下新增，`model.provider` 才是切换点
- **探测得到的清单优先**（那是这个套餐真实可用的）；探测失败才用官方文档兜底清单，并告诉用户"清单来自文档，可能不全"
- 写入失败要**当场停**，不要把半套配置留在机器上
- 想省 Credits：日常 `qwen3.8-flash` / `deepseek-v4-flash-0731`，重活 `qwen3.7-plus` / `deepseek-v4-pro`；夜间 22:00–08:00 有 5 折模型
- 已下线模型别选（如 `qwen3.8-max-preview`）

