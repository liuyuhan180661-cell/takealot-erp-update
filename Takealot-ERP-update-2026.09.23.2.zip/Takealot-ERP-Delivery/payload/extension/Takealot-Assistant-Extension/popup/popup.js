/**
 * Takealot 运营助手 - Popup 逻辑
 * 检查本地桥健康状态、提供快捷入口、读写偏好与桥端口
 * 不包含任何模拟兜底：桥不通就如实显示错误原因。
 */

document.addEventListener('DOMContentLoaded', async () => {
  const dotEl = document.getElementById('status-dot');
  const textEl = document.getElementById('status-text');
  const metaEl = document.getElementById('status-meta');
  const detailEl = document.getElementById('status-detail');
  const portInput = document.getElementById('bridge-port');
  const portHint = document.getElementById('port-hint');
  const savePortBtn = document.getElementById('btn-save-port');

  function setStatus(state, text, meta, detail) {
    dotEl.className = `status-dot ${state}`;
    textEl.innerText = text;
    metaEl.innerText = meta || '';
    detailEl.innerText = detail || '';
  }

  async function currentBase() {
    const url = await OpenClawBridge.getGatewayUrl();
    return OpenClawBridge.normalizeGatewayUrl(url);
  }

  async function refreshHealth() {
    const base = await currentBase();
    if (portInput) {
      const m = base.match(/:(\d+)$/);
      portInput.value = m ? m[1] : OpenClawBridge.defaultPort;
    }
    setStatus('', '正在检查本地桥...', `本地桥（${base.replace(/^https?:\/\//, '')}）`, '');

    let health;
    try {
      health = await OpenClawBridge.health();
    } catch (e) {
      setStatus('offline', '本地桥连接失败', `本地桥（${base.replace(/^https?:\/\//, '')}）`, (e && e.message) || String(e));
      return;
    }

    if (!health.ok) {
      setStatus('offline', '未检测到本地桥', `本地桥（${base.replace(/^https?:\/\//, '')}）`, health.error || '未知错误');
      return;
    }

    const baseLabel = `本地桥（${base.replace(/^https?:\/\//, '')}）`;
    setStatus(
      'online',
      '本地桥已连接',
      `${baseLabel} · 来源: ${health.source || '未知'} · 可写: ${health.writable ? '是' : '否'}`,
      health.statePath ? `状态文件: ${health.statePath}` : ''
    );

    // 顺带取一次计数（失败不覆盖上面的成功状态，只在 detail 里补充说明）
    const init = await OpenClawBridge.getInitData();
    if (init.ok) {
      const counts = init.counts || {};
      detailEl.innerText = `店铺: ${init.storeName || init.storeId || '未设置'} · 跟卖池: ${counts.collection || 0} · 草稿箱: ${counts.drafts || 0}`;
    } else {
      detailEl.innerText = `init-data 读取失败: ${init.error}`;
    }
  }

  if (savePortBtn) {
    savePortBtn.addEventListener('click', () => {
      const raw = String(portInput.value || '').trim();
      const port = Number(raw);
      if (!Number.isInteger(port) || port < 1 || port > 65535) {
        portHint.innerText = `端口非法：${raw}（需 1-65535 的整数）`;
        return;
      }
      chrome.storage.local.set({ gatewayUrl: `http://127.0.0.1:${port}` }, () => {
        portHint.innerText = `已切换本地桥到 127.0.0.1:${port}`;
        refreshHealth();
      });
    });
  }

  // Bind Quick Navigation Buttons
  document.getElementById('btn-open-erp')?.addEventListener('click', async () => {
    const base = await currentBase();
    chrome.tabs.create({ url: `${base}/takealot/#overview` });
  });

  document.getElementById('btn-open-seller')?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://seller.takealot.com/' });
  });

  document.getElementById('btn-open-market')?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://www.takealot.com/' });
  });

  // CDP 抓取（可选 debugger 权限）：扩展页里点按钮 = 有用户手势，chrome.permissions.request 最稳。
  // 状态一律按真实结果展示；未授权/被拒就把原始错误写出来，不假装已开启。
  const cdpBtn = document.getElementById('btn-toggle-cdp');
  const cdpHint = document.getElementById('cdp-hint');
  const cdpDetail = document.getElementById('cdp-detail');

  function hasCdpApi() {
    return typeof chrome !== 'undefined' && !!chrome.permissions && !!chrome.permissions.request;
  }

  function renderCdp(granted, error) {
    if (cdpBtn) cdpBtn.innerText = granted ? '撤销 CDP 抓取权限' : '启用 CDP 抓取';
    if (cdpHint) {
      cdpHint.innerText = granted
        ? '已授权：买家商品页采集会优先用 CDP 抓原始 XHR JSON，并写入 ERP 的 state/ingest/。'
        : '未启用时采集走页面 DOM + 公开接口（CDP 是增强项，不启用不影响其它功能）。';
    }
    if (cdpDetail) cdpDetail.innerText = error ? `上次结果：${error}` : '';
  }

  async function refreshCdpStatus() {
    if (!hasCdpApi()) {
      renderCdp(false, '当前环境没有 chrome.permissions');
      return;
    }
    chrome.permissions.contains({ permissions: ['debugger'] }, (granted) => {
      const err = chrome.runtime && chrome.runtime.lastError;
      renderCdp(granted === true, err ? (err.message || String(err)) : '');
    });
  }

  if (cdpBtn) {
    cdpBtn.addEventListener('click', () => {
      if (!hasCdpApi()) { renderCdp(false, '当前环境没有 chrome.permissions'); return; }
      chrome.permissions.contains({ permissions: ['debugger'] }, (granted) => {
        const containsErr = chrome.runtime && chrome.runtime.lastError;
        if (granted === true) {
          chrome.permissions.remove({ permissions: ['debugger'] }, (removed) => {
            const err = chrome.runtime && chrome.runtime.lastError;
            if (removed === true) renderCdp(false, '已撤销 debugger 权限（采集退回 DOM/公开接口）');
            else renderCdp(false, '撤销失败：' + ((err && err.message) || '浏览器未说明原因'));
          });
          return;
        }
        chrome.permissions.request({ permissions: ['debugger'] }, (ok) => {
          const err = chrome.runtime && chrome.runtime.lastError;
          if (ok === true) {
            renderCdp(true, '已授权（弹窗里点的那一次就是授权动作）');
          } else {
            renderCdp(false, '未授权：' + (containsErr ? (containsErr.message || String(containsErr)) : ((err && err.message) || '用户取消或浏览器拒绝')));
          }
        });
      });
    });
  }

  // Preferences Storage
  const toggleAi = document.getElementById('toggle-ai-polish');
  const toggleCat = document.getElementById('toggle-cat-lock');

  chrome.storage.local.get(['autoPolishTitle', 'autoLockCategory'], (res) => {
    if (res.autoPolishTitle !== undefined && toggleAi) toggleAi.checked = res.autoPolishTitle;
    if (res.autoLockCategory !== undefined && toggleCat) toggleCat.checked = res.autoLockCategory;
  });

  toggleAi?.addEventListener('change', (e) => {
    chrome.storage.local.set({ autoPolishTitle: e.target.checked });
  });

  toggleCat?.addEventListener('change', (e) => {
    chrome.storage.local.set({ autoLockCategory: e.target.checked });
  });

  await refreshHealth();
  await refreshCdpStatus();
});
