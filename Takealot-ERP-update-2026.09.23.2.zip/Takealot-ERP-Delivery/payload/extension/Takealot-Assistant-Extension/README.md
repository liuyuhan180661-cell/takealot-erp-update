﻿# Takealot 运营助手 · 浏览器扩展（Manifest V3）

本地桥地址：`http://127.0.0.1:18790`

> 完整交付说明（安装步骤、桥启动、改端口、两个 tab 的使用边界、回填失败排查、内部标识未改名说明、实测范围）：见 **`INSTALL.md`**。

## 安装（Chrome / Edge）
1. 打开 Chrome 或 Edge。
2. 地址栏输入 `chrome://extensions` 或 `edge://extensions`。
3. 打开右上角「开发者模式 / Developer mode」。
4. 点左上角「加载已解压的扩展程序 / Load unpacked」。
5. 选择本文件夹（Windows 上一般是 `C:\Users\Fly\Desktop\Takealot-Assistant-Extension`，改名前目录名保持不变）。
6. 工具栏出现「Takealot 运营助手」图标即安装成功；点图标可看到本地桥连接状态与端口设置。

## 功能边界（重要）
- **跟卖池（原采集箱）**：商品在 Takealot 平台上已存在，跟卖**只能改价格与库存**；标题 / 图片 / 描述等内容只读，扩展不提供任何内容修改入口。
- **新建草稿箱（原草稿）**：承载未编辑完的新建 listing，全字段可编辑并随时「保存到草稿箱」；点「一键回填」把字段写入官方新建商品表单。
- 两个 tab 数据不混用；跟卖池 → 草稿箱的唯一通道是「转为新建草稿」按钮（`POST /takealot/api/collection/promote`）。
- 买家市场页浮动条：抓取商品 → 存入跟卖池；批量下载 1200px 高清图到 `takealot_assets/<tsin>/`。
- **官方类目属性模板**：在卖家后台页面点一次「同步官方类目属性模板」，把官方全量装载表的属性模板写进自有 ERP
  （原始响应同时留档一份便于排错）。这一步**只能**在登录着的卖家后台页面做（官方 Seller API 没有该接口）。
- **CDP 原始抓取（可选权限，增强项）**：点一次「启用 CDP 抓取」后，扩展用 Chrome 调试协议
  （`chrome.debugger` + `Network` 域）把商品页自己发出的**原始 XHR JSON**（商品详情 / 评论分页 /
  `other_offers` 报价）抓下来，经本地桥写进 ERP 的 `state/ingest/` 投放目录，后端 crawler 自动吸收。
  未授权时采集仍走页面 DOM + 公开接口：降级顺序 **CDP → DOM → 公开 API → 明确 blocked**。
  详见 `shared/CDP-README.md`。`debugger` 只在 `optional_permissions` 里（安装时不弹吓人提示）。

## 本地桥接口契约（11 个 + 1 个附加）
| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/takealot/api/takealot/init-data` | `{ok, source, counts:{collection,drafts}, storeId, storeName, settings}` |
| GET | `/takealot/api/health` | `{ok, source, statePath, writable}` |
| GET | `/takealot/api/collection/pending` | `{ok, count, items:[...]}` |
| POST | `/takealot/api/collection/add` | 前台抓取对象 → `{ok, id, deduped}` |
| POST | `/takealot/api/collection/update` | 仅 `{id, price?, stock?}` |
| POST | `/takealot/api/collection/promote` | `{id}` → `{ok, draftId, item, draft}` |
| GET | `/takealot/api/listing/drafts` | `{ok, count, drafts:[...]}` |
| POST | `/takealot/api/listing/draft` | `{id?, fields:{...}}` upsert |
| POST | `/takealot/api/attributes/ingest` | 官方类目属性模板入库 → `state/attributes_templates.json`（`{ok, accepted, totalLoadsheets, added[], skipped[]}`） |
| POST | `/takealot/api/attributes/raw` | 官方响应体原文留档 → `state/attributes_templates_raw.json`（**只存响应体**，不存任何请求头/JWT/cookie；上限 2MB，超出截断 + `truncated:true`） |
| GET | `/takealot/api/attributes/status` | `{ok, file, loadsheetsCovered, updatedAt, source, bundledLoadsheets, effectiveLoadsheets, templatesExpected, missingLoadsheets[], rawFile, rawBytes, rawFetchedAt}` |

**附加接口（不属于上面冻结的 11 条，CDP 抓取用）**

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/takealot/api/ingest/raw` | CDP 抓到的原始 XHR JSON → `state/ingest/cdp-<PLID>-<时间戳>-<4hex>.json`（`{ok, file, dir, stateFile, bytes, plid, kinds, reviewPages}`）；后端 `crawler.reap_drop_folder()` 吸收；坏件（无 `productDetails` 且无 `reviewPages`、推不出 PLID、带 `authorization` 等键）一律 400 且不落盘 |

### 官方类目属性模板（把 7/36 → 36/36）

官方模板只在商家后台接口 `GET https://seller-api.takealot.com/v1/loadsheets/templates`，需要**页面登录会话**，
所以只能在**卖家后台页面**点抽屉里的「**同步官方类目属性模板**」（seller.takealot.com / sellers.takealot.com 均可）。
点一次的顺序是：**① 原始响应留档**（`state/attributes_templates_raw.json`，先保住原始件，便于离线排错）→
**② 归一化成 ingest 形状** → **③ 经本地桥写 `state/attributes_templates.json`**（ERP 插件读的同一个文件）。
形状不认识时**不猜**：直接报错并回报官方返回的前 300 字符，同时原始响应已经留档。详见 `INSTALL.md` 第五节。

桥地址可在扩展弹窗里改端口（`chrome.storage.local.gatewayUrl`），默认 `http://127.0.0.1:18790`。

## 内部标识说明
用户可见文案已全部改为「Takealot 运营助手」；但 **内部 DOM id/class（`openclaw-*`）、CSS 文件名（`styles/openclaw_extension.css`）、JS 全局对象名（`OpenClawBridge` / `OpenClawSellerCopilot` / `OpenClawUtils`）有意保持不变**，以避免大面积重命名引入回归风险。看到 `openclaw-` 前缀属于内部标识，不代表品牌残留。
