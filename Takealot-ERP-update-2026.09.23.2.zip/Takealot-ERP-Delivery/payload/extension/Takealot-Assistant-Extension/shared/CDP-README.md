# CDP 原始抓取说明（shared/CDP-README.md）

> 这一层负责：**从浏览器本会话真实发出的 XHR 里拿原始 JSON**（后端 `crawler.py` 用的就是同一批
> 响应体），把它交给本地桥写进 ERP 的 `state/ingest/` 投放目录，由 crawler 正常吸收。
> 不猜字段、不用 DOM 结果冒充 CDP 结果、抓不到就说清原因。

---

## 1. 为什么用「可授权」的方式（而不是直接写进 permissions）

`debugger` 权限在安装时会弹出「**读取和更改您在所有网站上的所有数据**」级别的提示，这就是
「装扩展吓人」的常见来源，而 CDP 只是**增强项**：不授权时采集仍能走页面 DOM + 公开接口。

所以：

- `manifest.json` 里它是 `optional_permissions`，`permissions` 与 `host_permissions` 一个字没动；
- 用户主动点一次才生效；随时可以撤销（popup 里同一个按钮变成「撤销 CDP 抓取权限」）。

```json
"permissions": ["storage", "activeTab", "scripting", "downloads"],
"optional_permissions": ["debugger"],
"host_permissions": ["*://*.takealot.com/*", "http://127.0.0.1/*", "http://localhost/*"]
```

`chrome.debugger` 只在扩展的后台/扩展页可用（content script 里没有这个 API），所以真正的抓取
在 `background/service_worker.js` 里执行；浮动条 / 侧边抽屉通过 `chrome.runtime.sendMessage`
调用它。

**真机实测（本机 Chrome 150，headless 探针 `_verify/cdp_realchrome_probe.cjs`，输出
`_verify/cdp_realchrome_probe_out.txt`）**：

- `optional_permissions:["debugger"]` 被 Chrome **原样接受**（扩展正常加载，`getManifest()`
  返回 `["debugger"]`，加载日志里没有 manifest/权限报错），`permissions` 里也没有 debugger；
- 真 MV3 service worker 里 `importScripts('/shared/bridge.js','/shared/cdp_capture.js')` 成功
  （后台能正确回应 `CDP_CAPTURE_STATUS`）；
- **未授权时 `chrome.debugger` 整个不存在（`typeof === 'undefined'`），`chrome.permissions.contains`
  返回 `false`** —— 所以抓取入口会先报 `no-permission`（并告诉你点哪里开启），而不是含糊的
  「API 缺失」；这一条在真机上就是这样，不是我们的兜底。

---

## 2. 怎么开启（一次就够）

| 入口 | 操作 | 说明 |
|---|---|---|
| 扩展弹窗（**最稳**） | 工具栏点扩展图标 → 点「启用 CDP 抓取」 | 扩展页面里点击 = 有用户手势，`chrome.permissions.request` 一定被接受 |
| 买家商品页浮动条 | 点「启用 CDP 抓取（可选权限）」 | 从页面里代请求；浏览器若因缺少用户手势拒绝，会**如实**提示去弹窗点 |
| 卖家后台侧边抽屉 | 点「用 CDP 抓取当前商品」 | 未授权时会先自动请求一次，失败就给出同一句指引 |

撤销：弹出窗口里点「撤销 CDP 抓取权限」（`chrome.permissions.remove`），此后 CDP 抓取会明确报
`no-permission` 而不是静默降级。

---

## 3. 它到底抓什么

用 `chrome.debugger.attach({tabId}, '1.3')` + `Network.enable`，然后按 URL/响应体识别三类原始 JSON
（形态与 `pkg/dashboard/crawler.py` 一致）：

| 类别 | 判定 | 依据 |
|---|---|---|
| `product-details` | `/product-details/<PLID…>`（也认响应体自证：`meta.identifier` + `core/buybox/title…`） | `crawler.product_url()` crawler.py:981 |
| `product-reviews` | `/product-reviews/plid/<数字>?page=N`（评论路由**不带 PLID 前缀**） | `crawler.reviews_url()` crawler.py:996 + `plid_num()` crawler.py:999 |
| `other-offers` | 响应体里有 `other_offers.conditions[]/items[]`（不是独立端点，常与商品详情同体） | `crawler.py:663-672`、`market_scraper.js:111-119` |

规则：

- 只取 `XHR/Fetch` + `2xx` + JSON 的响应体；图片、404、非 JSON 一律记进 `bodyErrors` 不去猜。
- **认不出来的 JSON 不丢**：URL 命中但形状不像（例如官方改了协议）时，响应体原文进
  `body.cdp.otherResponses` 留档，离线照着修映射；但它**不会**被当数据塞进 ERP 工单。
- 归包顺序是确定性的：**商品详情 → offers → 评论（页码升序）**；同一份抓取无论响应到达顺序如何，
  结果一致（`_verify/cdp_pure_test.cjs` 断言）。
- 抓取会在**后台标签页**（`active:false`）里加载该商品页 —— 不打断你当前页面，而且必须有真实页面
  加载，那些 XHR 才会发出。抓完立即 `detach` 并关掉该标签页（`finally` 里保证执行）。
- 商品页的评论是**懒加载**：抓到商品详情后，引擎会用 `Runtime.evaluate` 滚动 4 次催评论分页
  （可用 `nudge:false` 关掉），静默 1.2s 即收工。
- 只回传响应体：**不读、不存、不打印**任何请求头 / `Authorization` / JWT / cookie；桥侧也会拒绝
  这类键名（返回 400 并点名）。

---

## 4. 落到 ERP 里的什么位置

```
扩展(CDP) --POST /takealot/api/ingest/raw--> 桥 --写文件--> ERP state/ingest/*.json
                                                            |
                              crawler.reap_drop_folder() 读它 → ingest_payload() → done/ 或 failed/
```

- 接口：`POST /takealot/api/ingest/raw`（桥的第 **12** 个、**附加**接口；冻结的 11 条路径与
  `shared/bridge.js` 的 `PATHS` 一个没动，老断言 42/42 仍通过）。
- 文件：`state/ingest/cdp-<PLID>-<YYYYmmdd-HHMMSS>-<4hex>.json`，内容形状对齐 `ingest_payload()` 认的键
  （`plid` / `productDetails` / `reviewPages` / `fetchedAt[Ms]`，外加 `transport=cdp` 与 `cdp` 诊断块），
  与真实投放样例 `ingest/ingest-PLID96730174.json` 同形。
- 吸收：后端 `/crawler/status`、`/crawler/pull` 会自动 reap；成功移 `done/`，失败移 `failed/` 并在
  `state/ingest_log.json` 里点名（`crawler.py:1232-1269`）。

---

## 5. 抓不到时看什么（每一条都给明确原因，绝不返回空成功）

| reason | 含义 | 怎么办 |
|---|---|---|
| `no-permission` | 没授权 `debugger`（或已被撤销） | 弹窗里点「启用 CDP 抓取」；今天不想点就用 DOM/公开接口 |
| `no-api` | 当前上下文没有 `chrome.debugger/chrome.permissions`，或**已授权但仍拿不到 API** | 确认是在扩展里跑（content script 不能抓）；已授权还缺失就到 `chrome://extensions` 重新加载扩展 |
| `bad-url` | 目标不是买家商品页 URL（缺 `PLID…`） | 用挑选中的行里有真实 `url` 的商品；只有 TSIN 时会按扩展既有口径推导 `/p/PLID…` |
| `no-tab` | 建后台标签页失败 | 看浏览器是否禁止新标签页；重试一次 |
| `attach-failed` | `chrome.debugger.attach` 失败（原文附在 detail 里） | 常见：该标签页已被 DevTools 或别的调试器占用；关掉 DevTools 再试 |
| `network-enable-failed` | 附加成功但 `Network.enable` 失败 | 页面/标签页已关闭；重试 |
| `detached` | 抓取中途会话被结束 | 抓取时不要打开该标签页的 DevTools、不要关它；重试 |
| `no-responses` | 附加成功但时限内页面**一个响应都没有** | 页面没加载出来（网络/被 Cloudflare 挡）；先手动确认该商品页能打开 |
| `no-payload` | 有响应，但没有商品详情/评论/offers 的 JSON XHR（detail 里列出见到的主机与次数） | 页面改版或商品页形态不同；把 detail 里的主机清单反馈，或改用公开 API/投放目录 |
| `no-plid` | 抓到了内容但推不出 PLID | 说明响应形状变了：看 `state/ingest/` 里已落盘的 `cdp.otherResponses` 原始件离线修 |
| `not-captured` | 抓取本身没成功（不入账） | 见上一条对应原因 |

其它观察点：

- **`state/ingest/failed/` 里出现文件** = 桥收下了，但 crawler 解析失败，`state/ingest_log.json` 的
  `errors[0].error` 就是原因。
- **`state/ingest/` 里堆着文件不动** = 后端还没跑 crawler（`/crawler/status` 或 `/crawler/pull` 会 reap）。
- 桥不在线时：CDP 抓取可能成功（`ok:true`）但 `ingest.ok:false`，文案写「原始 JSON 未入账」——
  这是真话，不是成功。

---

## 6. 降级顺序（写死在界面上）

```
CDP（原始 XHR，最完整） → 页面 DOM（h1/价格/图片元素） → 公开 API（api.takealot.com，可能被 Cloudflare 挡）
                                                            → 明确 blocked（后端返回原因 + hint，不编数据）
```

- **浮动条「存入跟卖池」**：先 CDP；成功 → 采集行 `transport=cdp`（商品名/报价来自原始 JSON）；
  失败 → 退回 DOM/公开接口，`transport=dom`，toast 里写清 CDP 失败原因。
- **侧边抽屉「用 CDP 抓取当前商品」**：CDP 专用入口（不做 DOM 冒充）；结果行永远标 `transport`。
- **后端 crawler** 本来就有 `proxy → direct → blocked` 的阶梯，再加 `ingest`/投放目录这条路；
  CDP 这条正好补上「出口 IP 被 Cloudflare 挡」时最缺的那条。

---

## 7. 离线可证明的 vs 必须真机点一次的

**离线已证（可复跑，输出见 `_verify/*_out.txt`）**

| 证据 | 命令 |
|---|---|
| 纯逻辑：URL 分类 / 归包顺序 / 入账体 / 失败归因（54 条断言） | `node _verify/cdp_pure_test.cjs` |
| 控制流（模拟 chrome）：attach→Network.enable→getResponseBody→**detach 在 finally**、未授权/attach 失败/没抓到/超时/中途 detach 各路径 | 同上（B 段） |
| 界面入口：抽屉卡片 + 两个 tab + 目标推导 + 未授权/授权两条点击路径；浮动条 CDP 优先、失败退 DOM 并标 transport（20 条） | `node _verify/cdp_ui_entry_test.cjs` |
| 端到端：扩展真实代码（bridge.js + cdp_capture.js）→ 真桥 → `state/ingest/` → **真 crawler.py 吸收成功**（投放件进 `done/`、缓存 `transport=ingest`、评论窗口重放、销量估算）（23 条） | `python3 _verify/cdp_bridge_ingest_test.py` |
| 真 Chrome（Chrome for Testing 150，headless）9 项断言全通过：manifest 可选权限被接受、真 SW 的 importScripts 与消息通道、真 `permissions.contains`、未授权时 `chrome.debugger` 不存在且抓取入口返回 `no-permission`、无加载报错；另 1 项点击观察项（headless 里发真实鼠标事件点「启用 CDP 抓取」，浏览器无弹窗可点 → `contains` 仍为 false，符合预期） | `node _verify/cdp_realchrome_probe.cjs` |
| 无回归：冻结的 11 条桥契约 42/42、归一化 37/37、抽屉接线 14/14 | `node _verify/bridge_url_test.js` 等 |
| 以上全部一键复跑 | `bash _verify/run_cdp_e2e.sh` |

**必须真机点一次（离线测不到）**

1. 授权弹窗本身：点「启用 CDP 抓取」→ 浏览器弹出的权限确认 → 状态变成「已授权」，且**不用重新加载扩展**
   就能抓（离线只能证明"授权前 chrome.debugger 不存在"；授权后的即时生效需要点这一次确认）。
2. 真页面抓到 XHR：在 `www.takealot.com/p/…` 上点采集 → 结果行/toast 出现 `transport=cdp`、
   评论页数与 `state/ingest/cdp-<PLID>-….json` 文件名。
3. 抓取时 Chrome 顶部那条「正在调试此浏览器」提示条（这是 `debugger` 权限的固有表现），
   以及抓完提示条消失、后台标签页自动关闭。
4. 商品页评论懒加载：滚动催评论是否真的把第 2、3… 页催出来（不同页面滚动容器可能不同）。
5. MV3 生命周期：一次抓取最长 25s（含后台标签页加载），真机上要看 service worker 会不会在抓取
   中途被回收（Chrome 对活动调试会话通常会续命，但需实测一次）；以及授权后扩展更新/重载是否仍保持授权。
6. 无 TSIN→PLID 的真实商品：侧边抽屉里选中一行只有 TSIN 时，推导出的 `/p/PLID…` 是否会被
   Takealot 正确重定向到商品页（本机出口被 Cloudflare 挡，离线验证不了）。
7. 未授权时的降级观感：弹窗不点授权，直接在商品页采集 → 应显示 `transport=dom` + CDP 未授权原因。

---

## 8. 代码地图

| 文件 | 作用 |
|---|---|
| `manifest.json` | `optional_permissions:["debugger"]`；把 `shared/cdp_capture.js` 注入两个 content_scripts |
| `shared/cdp_capture.js` | 纯逻辑（分类/归包/入账体/失败归因）+ chrome.debugger 抓取 + 桥入账 |
| `shared/bridge.js` | `CDP_INGEST_PATH` + `ingestCapturedRaw()`（冻结的 11 条 `PATHS` 未动） |
| `background/service_worker.js` | `importScripts` 两者；消息：`CDP_CAPTURE_STATUS` / `CDP_REQUEST_PERMISSION` / `CDP_CAPTURE_AND_INGEST` |
| `content/market_floating_bar.js` | 采集按钮 CDP 优先、失败退 DOM，结果标 `transport`；面板显示通道状态；「启用 CDP 抓取」 |
| `content/seller_sidepanel.js` | 「用 CDP 抓取当前商品」卡片（两个 tab 都有）+ 未授权自动请求 |
| `popup/popup.html` / `popup.js` | 权限开关（授权 / 撤销）+ 真实状态展示 |
| `pkg/dashboard/bridge/erp_bridge.py` | `POST /takealot/api/ingest/raw`（校验 + 落 `state/ingest/`，附审计） |
