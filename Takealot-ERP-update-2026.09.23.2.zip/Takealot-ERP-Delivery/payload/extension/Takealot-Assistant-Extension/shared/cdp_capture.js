/**
 * Takealot 运营助手 - CDP 原始 XHR 抓取 (shared/cdp_capture.js)
 *
 * 为什么要有这一层：买家商品页（www.takealot.com/p/…）上真正有用的数据是页面自己发的
 * 那几个 XHR —— 后端 dashboard/crawler.py 用的正是同一批原始 JSON：
 *   GET  {API}/product-details/{PLID}          → 商品详情（可能含 other_offers 报价块）
 *   GET  {API}/product-reviews/plid/{数字}?page=N → 评论分页
 * 走 DOM 解析会丢字段；走扩展自己的 fetch 又会被 Cloudflare 按出口 IP 挑战（crawler 的
 * 公开 API 路线就是这个问题）。CDP（chrome.debugger + Network 域）拿的是**浏览器本会话
 * 真实发出的响应体原文**，不猜字段、不改造，原样回传并交给本地桥落进 ERP 的 state/ingest/。
 *
 * 权限设计：debugger 是**可选权限**（manifest.optional_permissions）。直接写进 permissions 会在
 * 安装时弹出「读取和更改所有网站上的所有数据」级别的吓人提示，所以做成用户主动开启：
 *   popup「启用 CDP 抓取」按钮（扩展页面里点，有用户手势，chrome.permissions.request 最稳），
 *   侧边抽屉 / 浮动条在未授权时会先尝试代请求，失败就明确让你去 popup 点一次。
 *
 * 硬约束（与交付约定一致，测试会断言）：
 *   1) 抓不到就返回**明确原因**（no-permission / attach-failed / no-responses / no-payload /
 *      detached / timeout …），绝不用 DOM 结果冒名顶替 CDP 结果。
 *   2) detach 一律写在 finally 里；隐藏标签页用完即关。
 *   3) 只回传响应体原文；不读、不存、不打印任何请求头 / Authorization / JWT / cookie。
 *   4) 纯逻辑（URL 分类 / 归包 / 入账体构造 / 失败归因）不依赖 chrome，可在 node 里单测
 *      （见 /tmp/hermeswin/_verify/cdp_pure_test.cjs）。
 *
 * 运行位置：chrome.debugger 只在扩展的后台 service worker 里可用，所以真正抓取由
 * background/service_worker.js importScripts 本文件后执行；content script（浮动条 / 侧边抽屉）
 * 通过 chrome.runtime.sendMessage 调用。本文件同时被两个 content_scripts 加载，只用其纯逻辑
 * （URL 推导 / 文案），不会在页面里碰 chrome.debugger。
 */

const OpenClawCdpCapture = {
  VERSION: '1.0.0',
  DEBUGGER_PROTOCOL: '1.3',
  PERMISSION: 'debugger',

  // 抓取节奏（毫秒）
  DEFAULT_TIMEOUT_MS: 25000,   // 单次抓取总上限
  SETTLE_MS: 1200,             // 静默多久算「没新东西了」
  POLL_MS: 250,                // 主循环轮询间隔
  NUDGE_STEPS: 4,              // 商品页评论是懒加载：滚动催它发 XHR 的次数
  NUDGE_WAIT_MS: 700,
  MAX_PAYLOADS: 60,
  MAX_SEEN: 400,               // 见到的响应摘要上限（防无界内存）

  // URL 形态：与 pkg/dashboard/crawler.py 一致
  //   crawler.product_url()  = {API_BASE}/product-details/{plid}          (crawler.py:981)
  //   crawler.reviews_url()  = {API_BASE}/product-reviews/plid/{num}?page= (crawler.py:996)
  // 其中 plid_num() 去掉 PLID 前缀（crawler.py:999-1001）——
  // 所以评论 URL 里的数字**不带 PLID**，下面 plidFromUrl 会补回来。
  API_BASE: 'https://api.takealot.com/rest/v-1-12-0',
  PRODUCT_PATH_RE: /\/product-details\/([^/?#]+)/i,
  REVIEWS_PATH_RE: /\/product-reviews\/plid\/(\d+)/i,
  REVIEWS_PAGE_RE: /[?&]page=(\d+)/i,
  OFFERS_PATH_RE: /\/other[-_]?offers?\b/i,
  PLID_RE: /PLID\s*[-_ ]?(\d{5,})/i,
  BARE_ID_RE: /\b(\d{5,10})\b/,

  // 归包顺序（测试断言：商品详情 → offers → 评论，评论按页码升序）
  KIND_ORDER: ['product-details', 'other-offers', 'product-reviews'],

  // 「像不像那类响应」的最低要求：URL 命中还不够，避免把错误页/无关 JSON 塞进 ERP 工单。
  // 认不出来时**不丢数据**：原始体仍会放进 body.cdp.otherResponses 留档（离线照着修形状用）。
  PDP_KEYS: ['core', 'buybox', 'title', 'gallery', 'meta', 'data_layer', 'breadcrumbs',
    'product_information', 'description', 'variants', 'attributes', 'gallery_images'],
  REVIEWS_KEYS: ['reviews', 'page_info', 'results', 'pagination', 'review_count', 'total'],
  MAX_OTHER_RESPONSES: 5,
  MAX_OTHER_BYTES: 200000,

  // 失败原因 → 人话（UI 与测试都用这一份，避免各处自己编）
  REASONS: Object.freeze({
    'bad-url': '目标不是 Takealot 商品页 URL（需要 takealot.com 且含 PLID…）',
    'no-api': '当前上下文没有 chrome.debugger/chrome.permissions（CDP 抓取只能在扩展后台 service worker 里执行；已授权但仍缺失时重新加载扩展）',
    'no-permission': '未授权 debugger 可选权限（在扩展弹窗点一次「启用 CDP 抓取」）',
    'permission-error': '请求 debugger 权限时出错',
    'no-tab': '无法创建/定位要抓取的标签页',
    'attach-failed': 'chrome.debugger.attach 失败',
    'network-enable-failed': 'Network.enable 失败',
    'detached': '调试会话被结束（例如打开了 DevTools，或标签页被关掉）',
    'no-responses': '页面在时限内没有发出任何网络响应（多半页面没加载成功/被挡）',
    'no-payload': '页面有响应，但没有一个是商品详情/评论/offers 的 JSON XHR',
    'no-plid': '抓到的内容里没有可用的 PLID，未入账',
    'not-captured': '没有可入账的抓取结果',
    'timeout': '抓取超时'
  }),

  // ---------------------------------------------------------------- 小工具

  str(v) {
    return (v === undefined || v === null) ? '' : String(v).trim();
  },

  /** crawler.plid_num() 的对应实现：PLID96730174 → 96730174 */
  plidNum(plid) {
    return this.str(plid).replace(/^PLID\s*[-_]?\s*/i, '').trim();
  },

  /** 扩展到 PLID 的既有口径（与 market_scraper.toPlid 一致：TSIN-12345 → PLID12345） */
  plidFromTsin(tsin) {
    const num = this.str(tsin).replace(/^TSIN\s*[-_ ]?/i, '').trim();
    return /^\d{5,}$/.test(num) ? 'PLID' + num : '';
  },

  isTakealotUrl(url) {
    const u = this.str(url);
    if (!/^https?:\/\//i.test(u)) return false;
    try {
      const host = new URL(u).hostname.toLowerCase();
      return host === 'takealot.com' || host.endsWith('.takealot.com');
    } catch (e) {
      return false;
    }
  },

  /**
   * 从任意 URL 里认 PLID（严格说：只从 PLID 字面量或商品/评论路由认，不拿裸数字猜）。
   *   /p/some-slug/PLID96730174        → PLID96730174
   *   /rest/v-1-12-0/product-details/PLID96730174 → PLID96730174
   *   /rest/v-1-12-0/product-reviews/plid/96730174?page=2 → PLID96730174（评论路由不带前缀）
   */
  plidFromUrl(url) {
    const u = this.str(url);
    if (!u) return '';
    const m = u.match(this.PLID_RE);
    if (m) return 'PLID' + m[1];
    const rev = u.match(this.REVIEWS_PATH_RE);
    if (rev) return 'PLID' + rev[1];
    const prod = u.match(this.PRODUCT_PATH_RE);
    if (prod) {
      const token = decodeURIComponent(prod[1]);
      const numeric = token.match(this.BARE_ID_RE);
      if (numeric) return 'PLID' + numeric[1];
    }
    return '';
  },

  isProductUrl(url) {
    return this.isTakealotUrl(url) && !!this.plidFromUrl(url);
  },

  /**
   * 目标商品 URL。优先用真实 URL；只给了 PLID/TSIN 时才推导。
   * 注意：推导出来的 `/p/PLID…` 形式不带 slug，Takealot 会重定向到规范地址；
   * 这一点属于「需真机点一次」的验证项（见 shared/CDP-README.md）。
   */
  productUrlFor(input) {
    const raw = this.str(input);
    if (this.isProductUrl(raw)) return raw;
    const plid = this.plidFromUrl(raw) || (/^PLID/i.test(raw) ? this.plidFromUrl(raw) : '') || this.plidFromTsin(raw);
    if (!plid) return '';
    return 'https://www.takealot.com/p/' + plid;
  },

  // ------------------------------------------------- 分类（纯，URL + 响应体）
  // 依据 crawler.py：offers 不是独立端点，而是 product-details 响应里的 other_offers
  // （crawler.py:663-672 读 data["other_offers"]["conditions"]）；
  // 浮动条 market_scraper.js:111-119 也是同一处。所以 offers 按**响应体**认。

  urlKind(url) {
    const u = this.str(url);
    if (!u) return null;
    if (this.PRODUCT_PATH_RE.test(u)) return 'product-details';
    if (this.REVIEWS_PATH_RE.test(u)) return 'product-reviews';
    if (this.OFFERS_PATH_RE.test(u)) return 'other-offers';
    return null;
  },

  reviewPage(url) {
    const m = this.str(url).match(this.REVIEWS_PAGE_RE);
    if (!m) return 1;
    const n = parseInt(m[1], 10);
    return (isFinite(n) && n > 0) ? n : 1;
  },

  hasOtherOffers(json) {
    if (!json || typeof json !== 'object' || Array.isArray(json)) return false;
    const oo = json.other_offers;
    if (!oo || typeof oo !== 'object' || Array.isArray(oo)) return false;
    return Array.isArray(oo.conditions) || Array.isArray(oo.items);
  },

  /** 商品详情响应的自证特征（不依赖 URL，供 URL 变了时兜底救一次） */
  looksLikeProductDetails(json) {
    if (!json || typeof json !== 'object' || Array.isArray(json)) return false;
    const hasId = !!(this.plidFromJson(json));
    const hasBody = !!(json.core || json.buybox || json.title || json.gallery);
    return hasId && hasBody;
  },

  /** 评论页自证特征（真实形状见 crawl-samples/rv_96730174_p1.json：reviews/page_info） */
  looksLikeReviews(json) {
    if (!json || typeof json !== 'object' || Array.isArray(json)) return false;
    if (Array.isArray(json.reviews)) return true;
    return Array.isArray(json.results) && !!(json.page_info || json.pagination);
  },

  /** 非空对象（数组也算占用，但只有对象才当响应体用） */
  isNonEmptyObject(json) {
    return !!json && typeof json === 'object' && !Array.isArray(json) && Object.keys(json).length > 0;
  },

  hasAnyKey(json, keys) {
    if (!this.isNonEmptyObject(json)) return false;
    return keys.some(k => Object.prototype.hasOwnProperty.call(json, k));
  },

  /** 商品详情响应是否「像那么回事」（有已知顶层键，或有 PLID + 主体字段） */
  isPlausibleProductDetails(json) {
    if (!this.isNonEmptyObject(json)) return false;
    return this.looksLikeProductDetails(json) || this.hasAnyKey(json, this.PDP_KEYS);
  },

  /** 评论分页响应是否「像那么回事」 */
  isPlausibleReviews(json) {
    if (!this.isNonEmptyObject(json)) return false;
    return this.looksLikeReviews(json) || this.hasAnyKey(json, this.REVIEWS_KEYS);
  },

  topKeysOf(json, limit = 8) {
    if (!json || typeof json !== 'object') return String(typeof json);
    if (Array.isArray(json)) return '[数组 ' + json.length + ' 项]';
    return Object.keys(json).slice(0, limit).join(', ') || '（空对象）';
  },

  /** 从商品详情响应里取 PLID —— 与 crawler.ingest_payload 的优先级完全一致
   *  （crawler.py:1397-1402：meta.identifier → data_layer.prodid → data_layer.productlineSku → core.id） */
  plidFromJson(json) {
    const dig = (obj) => (obj && typeof obj === 'object' && !Array.isArray(obj)) ? obj : null;
    const meta = dig(json && json.meta);
    if (meta && this.str(meta.identifier)) {
      const direct = this.str(meta.identifier).match(this.PLID_RE);
      if (direct) return 'PLID' + direct[1];
    }
    const dl = dig(json && json.data_layer);
    if (dl && dl.prodid) return this.plidFromUrl('PLID' + this.str(dl.prodid).replace(/^PLID/i, ''));
    if (dl && dl.productlineSku && this.BARE_ID_RE.test(this.str(dl.productlineSku))) {
      const m = this.str(dl.productlineSku).match(this.BARE_ID_RE);
      if (m) return 'PLID' + m[1];
    }
    const core = dig(json && json.core);
    if (core && core.id && this.BARE_ID_RE.test(this.str(core.id))) {
      const m = this.str(core.id).match(this.BARE_ID_RE);
      if (m) return 'PLID' + m[1];
    }
    return '';
  },

  /**
   * 单个已拿到响应体的事件 → 分类结果。
   * @returns {{picked:boolean, kinds:string[], kind:string|null, page:number,
   *            reason?:string, archive?:boolean, json?:any}}
   *   archive=true 表示「认不出来但响应体还在」，调用方应把它放进 otherResponses 留档。
   */
  classify(event) {
    const url = this.str(event && event.url);
    const status = Number(event && event.status);
    const json = event ? event.json : null;
    const page = this.reviewPage(url);
    const plain = (reason) => ({ picked: false, kinds: [], kind: null, page: page, reason: reason, archive: false });
    const keep = (reason) => ({ picked: false, kinds: [], kind: null, page: page, reason: reason, archive: true, json: json });

    if (isFinite(status) && (status < 200 || status >= 300)) {
      return plain('HTTP ' + status + ' 非 2xx（错误页不当数据用）');
    }
    if (json === null || json === undefined) {
      return plain('响应体不是 JSON（或为空/binary）');
    }
    if (typeof json !== 'object' || Array.isArray(json) || Object.keys(json).length === 0) {
      return keep('响应体不是非空 JSON 对象（' + this.topKeysOf(json) + '）');
    }

    const urlKinds = [];
    const k = this.urlKind(url);
    if (k) urlKinds.push(k);

    // URL 命中的类别还要响应体「像那么回事」，否则只留档不当数据
    for (const name of urlKinds) {
      if (name === 'product-details' && !this.isPlausibleProductDetails(json)) {
        return keep('URL 像商品详情（' + url + '），但响应体不像：顶层键 ' + this.topKeysOf(json) +
          '（既不认 PLID，也没有 core/buybox/title… 任一已知键）');
      }
      if (name === 'product-reviews' && !this.isPlausibleReviews(json)) {
        return keep('URL 像评论分页（' + url + '），但响应体不像：顶层键 ' + this.topKeysOf(json) +
          '（没有 reviews/page_info/results…）');
      }
      if (name === 'other-offers' && !this.hasOtherOffers(json)) {
        return keep('URL 像 offers（' + url + '），但响应体里没有 other_offers.conditions/items：顶层键 ' +
          this.topKeysOf(json));
      }
    }

    const kinds = urlKinds.slice();
    if (this.hasOtherOffers(json) && kinds.indexOf('other-offers') < 0) kinds.push('other-offers');
    if (!kinds.length) {
      // URL 认不出来：只认响应体自证
      if (this.isPlausibleProductDetails(json) && this.looksLikeProductDetails(json)) kinds.push('product-details');
      else if (this.isPlausibleReviews(json)) kinds.push('product-reviews');
      else if (this.hasOtherOffers(json)) kinds.push('other-offers');
    }
    if (!kinds.length) {
      return keep('JSON 里没有可识别的商品/评论/offers 特征（顶层键 ' + this.topKeysOf(json) + '）');
    }
    // 主 kind：商品详情优先（offers 常与它同体），其次 offers，最后评论
    let primary = null;
    for (const name of this.KIND_ORDER) { if (kinds.indexOf(name) >= 0) { primary = name; break; } }
    return {
      picked: true, kinds: kinds, kind: primary, page: page,
      status: isFinite(status) ? status : null, json: json
    };
  },

  /** 值不值得去取响应体（status 2xx + JSON 类型 + XHR/fetch + takealot 主机/已知路径） */
  isCandidateResponse(entry) {
    const url = this.str(entry && entry.url);
    if (!url) return false;
    const status = Number(entry && entry.status);
    if (isFinite(status) && (status < 200 || status >= 300)) return false;
    const type = this.str(entry && entry.type).toLowerCase();
    if (type && type !== 'xhr' && type !== 'fetch') return false;
    const mime = this.str(entry && entry.mimeType).toLowerCase();
    if (mime && mime.indexOf('json') < 0) return false;
    if (this.urlKind(url)) return true;
    return this.isTakealotUrl(url) && url.indexOf('/rest/') >= 0;
  },

  sortPayloads(payloads) {
    const rank = (name) => {
      const i = this.KIND_ORDER.indexOf(name);
      return i < 0 ? this.KIND_ORDER.length : i;
    };
    return payloads.slice().sort((a, b) => {
      const ra = rank(a.kind), rb = rank(b.kind);
      if (ra !== rb) return ra - rb;
      if (a.kind === 'product-reviews' && b.kind === 'product-reviews' && a.page !== b.page) return a.page - b.page;
      return (a.seq || 0) - (b.seq || 0);
    });
  },

  /**
   * 归包：把「按到达顺序记录的响应体」整理成确定性结果。
   * 顺序保证：商品详情 → offers → 评论（页码升序），同 kind 同页按到达顺序。
   * 认不出来的响应体（archive=true）单独收进 otherResponses 留档，不当数据用、也不丢。
   * @param {Array} events  已经取到响应体的条目 {url, status, mimeType, type, json, seq?}
   */
  collectResponses(events, opts = {}) {
    const list = Array.isArray(events) ? events : [];
    const maxPayloads = Number(opts.maxPayloads) > 0 ? Number(opts.maxPayloads) : this.MAX_PAYLOADS;
    const maxOther = Number(opts.maxOther) > 0 ? Number(opts.maxOther) : this.MAX_OTHER_RESPONSES;
    const maxOtherBytes = Number(opts.maxOtherBytes) > 0 ? Number(opts.maxOtherBytes) : this.MAX_OTHER_BYTES;
    const picked = [];
    const skipped = [];
    const other = [];
    let otherBytes = 0;
    list.forEach((ev, i) => {
      const verdict = this.classify(ev);
      if (!verdict.picked) {
        skipped.push({ url: this.str(ev && ev.url), reason: verdict.reason || '不可识别' });
        if (verdict.archive && other.length < maxOther) {
          let size = 0;
          try { size = JSON.stringify(verdict.json || null).length; } catch (e) { size = 0; }
          if (otherBytes + size <= maxOtherBytes) {
            otherBytes += size;
            other.push({ url: this.str(ev && ev.url), status: verdict.status ? verdict.status : (Number(ev && ev.status) || null), bytes: size, json: verdict.json });
          }
        }
        return;
      }
      if (picked.length >= maxPayloads) {
        skipped.push({ url: this.str(ev && ev.url), reason: '超过上限 ' + maxPayloads + ' 条' });
        return;
      }
      picked.push({
        kind: verdict.kind,
        kinds: verdict.kinds,
        url: this.str(ev && ev.url),
        status: verdict.status,
        mimeType: this.str(ev && ev.mimeType),
        page: verdict.page,
        seq: (ev && ev.seq !== undefined && ev.seq !== null) ? ev.seq : i,
        json: verdict.json
      });
    });
    const ordered = this.sortPayloads(picked);
    const pd = ordered.find(p => p.kind === 'product-details') || null;
    const offers = ordered.find(p => p.kinds.indexOf('other-offers') >= 0) || null;
    const reviews = ordered.filter(p => p.kind === 'product-reviews');
    return {
      picked: ordered,
      urls: ordered.map(p => p.url),
      kinds: ordered.map(p => p.kind),
      productDetails: pd,
      offers: offers,
      reviewPayloads: reviews,
      reviewPages: reviews.map(p => p.page),
      pages: reviews.map(p => p.page),
      skipped: skipped,
      otherResponses: other,
      stats: {
        supplied: list.length,
        picked: ordered.length,
        skipped: skipped.length,
        archived: other.length,
        archivedBytes: otherBytes,
        productDetails: pd ? 1 : 0,
        offers: offers ? 1 : 0,
        reviews: reviews.length,
        maxPayloads: maxPayloads
      }
    };
  },

  /** 见到但没采用的响应 → 一句话摘要（真机排障时最有用的东西） */
  summarizeSeen(seen, limit = 5) {
    const list = Array.isArray(seen) ? seen : [];
    const byHost = {};
    list.forEach(e => {
      let host = '(相对)';
      try { host = new URL(this.str(e && e.url)).hostname; } catch (err) { /* 保持默认 */ }
      const key = host + ' ' + (Number(e && e.status) || 0);
      byHost[key] = (byHost[key] || 0) + 1;
    });
    const parts = Object.keys(byHost).sort((a, b) => byHost[b] - byHost[a]).slice(0, limit)
      .map(k => k + '×' + byHost[k]);
    return { total: list.length, top: parts, text: parts.length ? parts.join('、') : '（无）' };
  },

  /**
   * 结果归因（纯）：抓到了 → ok:true；没抓到 → 明确 reason。
   * 绝不在没抓到的时候返回 ok:true（也不拿 DOM 结果充当 CDP 结果）。
   */
  finalizeCapture(state) {
    const s = state || {};
    const picked = Array.isArray(s.picked) ? s.picked : [];
    const seen = Array.isArray(s.seen) ? s.seen : [];
    const seconds = Math.max(1, Math.round((Number(s.timeoutMs) || this.DEFAULT_TIMEOUT_MS) / 1000));
    if (picked.length > 0) {
      return { ok: true, reason: null, detail: '', stopReason: s.stopReason || 'idle' };
    }
    if (s.detachReason) {
      return {
        ok: false, reason: 'detached', stopReason: 'detached',
        detail: '调试会话被结束：' + this.str(s.detachReason) +
          '（在抓取过程中不要打开该标签页的 DevTools，也不要关闭它）'
      };
    }
    if (!seen.length) {
      return {
        ok: false, reason: 'no-responses', stopReason: s.stopReason || 'timeout',
        detail: '附加成功、Network 已开启，但 ' + seconds + 's 内页面没有发出任何网络响应（页面没加载成功或被挡）。'
      };
    }
    const seenInfo = this.summarizeSeen(seen);
    const bodyErr = (Array.isArray(s.bodyErrors) && s.bodyErrors.length)
      ? '；取到响应体但不可用 ' + s.bodyErrors.length + ' 个（首个：' + this.str(s.bodyErrors[0].error) + '）'
      : '';
    return {
      ok: false, reason: 'no-payload', stopReason: s.stopReason || 'timeout',
      detail: '页面共发出 ' + seenInfo.total + ' 个响应（' + seenInfo.text + '），' +
        '但没有商品详情/评论/offers 的 JSON XHR' + bodyErr + '。'
    };
  },

  /**
   * 抓取结果 → 本地桥 ingest 载荷（纯）。
   * 形状对齐 crawler.ingest_payload 认识的那几个键（crawler.py:1388-1473）：
   *   plid / productDetails / reviewPages / fetchedAt[Ms]
   * 与 /tmp/hermeswin/ingest/ingest-PLID96730174.json（真实投放样例）同形，另加诊断字段
   * （transport / cdp），crawler 只读它认识的键，多余的键会被忽略。
   */
  toIngestBody(capture, opts = {}) {
    if (!capture || !capture.ok) {
      return { ok: false, reason: 'not-captured', detail: '抓取没成功（capture.ok=false），不入账' };
    }
    const picked = capture.payloads || capture.picked || [];
    const pd = picked.find(p => p.kind === 'product-details') || null;
    const offers = picked.find(p => (p.kinds || []).indexOf('other-offers') >= 0) || null;
    const reviews = picked.filter(p => p.kind === 'product-reviews');
    const plid = this.str(capture.plid) ||
      (pd ? this.plidFromJson(pd.json) : '') ||
      this.plidFromUrl(capture.target || '') ||
      this.plidFromUrl((capture.urls || [])[0] || '');
    if (!plid) {
      return {
        ok: false, reason: 'no-plid',
        detail: '抓到的 ' + picked.length + ' 个响应里没有 PLID（product-details 的 meta.identifier / ' +
          'data_layer.prodid / core.id 都没有），不能开工单，未入账。'
      };
    }
    const now = opts.now ? new Date(opts.now) : new Date();
    const pad = (n) => (n < 10 ? '0' + n : String(n));
    // crawler._iso() 的口径：'%Y-%m-%d %H:%M'
    const fetchedAt = opts.fetchedAt || (now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate()) +
      ' ' + pad(now.getHours()) + ':' + pad(now.getMinutes()));
    const body = {
      plid: plid,
      target: capture.target || '',
      fetchedAt: fetchedAt,
      fetchedAtMs: now.getTime(),
      source: opts.source || 'extension:cdp-capture',
      transport: 'cdp'
    };
    if (pd) body.productDetails = pd.json;
    if (reviews.length) body.reviewPages = reviews.map(p => p.json);
    // offers：单独响应体就整份留档；与商品详情同体时留 raw 子节点（原样，不改写）
    if (offers && offers !== pd) body.otherOffers = offers.json;
    else if (pd && this.hasOtherOffers(pd.json)) body.otherOffers = pd.json.other_offers;
    body.cdp = {
      version: this.VERSION,
      protocol: this.DEBUGGER_PROTOCOL,
      target: capture.target || '',
      tabId: capture.tabId || null,
      ownTab: !!capture.ownTab,
      capturedAt: now.toISOString(),
      stopReason: capture.stopReason || '',
      elapsedMs: capture.elapsedMs || null,
      timeoutMs: capture.timeoutMs || null,
      urls: (capture.urls || []).slice(0, 40),
      kinds: capture.kinds || picked.map(p => p.kind),
      reviewPages: reviews.map(p => ({ page: p.page, url: p.url, status: p.status })),
      skipped: (capture.skipped || []).slice(0, 20),
      otherResponses: (capture.otherResponses || []).slice(0, this.MAX_OTHER_RESPONSES),
      bodyErrors: (capture.bodyErrors || []).slice(0, 10),
      seen: this.summarizeSeen(capture.seen || []).text,
      note: '扩展用 chrome.debugger + Network 域抓到的响应体原文（transport=cdp）；' +
        '只含响应体，不含任何请求头/Authorization/JWT/cookie。'
    };
    return { ok: true, body: body, plid: plid };
  },

  reasonText(reason, detail) {
    const base = this.REASONS[reason] || ('未知原因：' + this.str(reason));
    return detail ? base + '｜' + detail : base;
  },

  /** 给 UI 用的一句话（抓取 + 入账两段都说到） */
  describe(result) {
    if (!result) return '未执行 CDP 抓取。';
    if (!result.ok) {
      return 'CDP 抓取失败（transport=cdp）：' + this.reasonText(result.reason, result.detail);
    }
    const kinds = (result.kinds || []).slice();
    const reviews = (result.reviewPages || []).slice().sort((a, b) => a - b);
    const parts = [];
    parts.push('商品详情 ' + (kinds.indexOf('product-details') >= 0 ? '✓' : '✗'));
    parts.push('其他卖家报价 ' + (kinds.indexOf('other-offers') >= 0 ? '✓' : '（本次响应里没有 other_offers）'));
    parts.push('评论 ' + (reviews.length ? reviews.length + ' 页（第 ' + reviews.join('、') + ' 页）' : '0 页'));
    const head = 'CDP 抓取成功（transport=cdp）：' + parts.join('，') + '。';
    if (!result.ingest) return head;
    if (result.ingest.ok) {
      return head + '原始 JSON 已交给本地桥 → state/ingest/' + (result.ingest.file || '?') +
        '（PLID ' + (result.plid || '?') + '），后端 crawler 会自动吸收。';
    }
    return head + '⚠ 写入 ERP 失败：' + (result.ingest.error || '未知原因') + '（原始 JSON 仍在本次结果里，可重试）。';
  },

  // ------------------------------------------------------------- chrome 层

  /** 权限 API 是否可用（读/请求可选权限用；任何扩展上下文都有） */
  hasPermissionsApi() {
    return typeof chrome !== 'undefined' && !!chrome.permissions && !!chrome.permissions.contains;
  },

  /**
   * chrome.debugger 是否真的可用。
   * 真机实测（Chrome 150，见 _verify/cdp_realchrome_probe_out.txt）：**可选权限未授权时
   * chrome.debugger 整个不存在**（不是报错，而是 undefined）。所以绝不能把它当成
   * 「扩展装坏了」，必须先把「未授权」判出来（no-permission），再谈 API 缺失（no-api）。
   */
  hasDebuggerApi() {
    return typeof chrome !== 'undefined' && !!chrome.debugger && !!chrome.tabs;
  },

  /** 兼容旧名（等同 hasDebuggerApi） */
  hasChromeApi() {
    return this.hasDebuggerApi();
  },

  /** {granted, error, api} —— 只报真实状态，不猜 */
  async permissionState() {
    if (typeof chrome === 'undefined' || !chrome.permissions || !chrome.permissions.contains) {
      return { granted: false, api: false, error: '当前环境没有 chrome.permissions' };
    }
    return new Promise((resolve) => {
      try {
        chrome.permissions.contains({ permissions: [this.PERMISSION] }, (granted) => {
          const err = chrome.runtime && chrome.runtime.lastError;
          resolve({ granted: granted === true, api: true, error: err ? (err.message || String(err)) : '' });
        });
      } catch (e) {
        resolve({ granted: false, api: true, error: (e && e.message) || String(e) });
      }
    });
  },

  /**
   * 请求 debugger 可选权限。**必须在有用户手势的上下文里调用**
   * （popup 按钮最稳；从 content script 经 sendMessage 让 SW 代请求时 Chrome 可能因无手势拒绝，
   *  这时会如实把原始错误返回，由 UI 引导用户去 popup 点一次）。
   */
  async requestPermission() {
    if (typeof chrome === 'undefined' || !chrome.permissions || !chrome.permissions.request) {
      return { granted: false, error: '当前环境没有 chrome.permissions.request' };
    }
    return new Promise((resolve) => {
      try {
        chrome.permissions.request({ permissions: [this.PERMISSION] }, (granted) => {
          const err = chrome.runtime && chrome.runtime.lastError;
          resolve({
            granted: granted === true,
            error: granted === true ? '' : (err ? (err.message || String(err)) : '用户未授权（或当前上下文没有用户手势）')
          });
        });
      } catch (e) {
        resolve({ granted: false, error: (e && e.message) || String(e) });
      }
    });
  },

  /** 撤销授权（popup 用；撤销后 CDP 抓取会明确报 no-permission） */
  async removePermission() {
    if (typeof chrome === 'undefined' || !chrome.permissions || !chrome.permissions.remove) {
      return { removed: false, error: '当前环境没有 chrome.permissions.remove' };
    }
    return new Promise((resolve) => {
      try {
        chrome.permissions.remove({ permissions: [this.PERMISSION] }, (removed) => {
          const err = chrome.runtime && chrome.runtime.lastError;
          resolve({ removed: removed === true, error: err ? (err.message || String(err)) : '' });
        });
      } catch (e) {
        resolve({ removed: false, error: (e && e.message) || String(e) });
      }
    });
  },

  sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  },

  /** 催评论懒加载：CDP Runtime.evaluate 滚动一下（失败不影响主流程） */
  async _nudge(tabId, step) {
    try {
      await chrome.debugger.sendCommand({ tabId: tabId }, 'Runtime.evaluate', {
        expression: '(function(){var h=Math.max(document.body?document.body.scrollHeight:0,document.documentElement?document.documentElement.scrollHeight:0);' +
          'window.scrollTo(0, Math.round(h*' + (step / (this.NUDGE_STEPS + 1)).toFixed(3) + '));return h;})()',
        returnByValue: true
      });
      await this.sleep(this.NUDGE_WAIT_MS);
      return true;
    } catch (e) {
      return false;
    }
  },

  /**
   * 用 CDP 抓一个商品页的原始 XHR JSON。
   * @param {string} url 商品页 URL（www.takealot.com/p/…PLID…）
   * @param {{timeoutMs?:number, settleMs?:number, maxPayloads?:number, nudge?:boolean,
   *          tabId?:number, keepTab?:boolean}} opts
   *   - 不给 tabId 时**新建隐藏标签页**（active:false）加载目标页再抓，用完即关：
   *     不打扰用户当前页，且必须有真实页面加载才会发出那些 XHR。
   *   - 传 tabId 时附加到已有标签页（该页的 XHR 已被页面自己发过，多半抓不到；除非它随后还会再发）。
   * @returns {Promise<{ok:boolean, transport:'cdp', reason?:string, detail?:string,
   *   payloads:Array, urls:string[], kinds:string[], plid:string, reviewPages:number[],
   *   stopReason:string, elapsedMs:number, timeoutMs:number, seen:Array, bodyErrors:Array}>}
   */
  async captureProduct(url, opts = {}) {
    const startedAt = Date.now();
    const timeoutMs = Number(opts.timeoutMs) > 0 ? Number(opts.timeoutMs) : this.DEFAULT_TIMEOUT_MS;
    const settleMs = Number(opts.settleMs) > 0 ? Number(opts.settleMs) : this.SETTLE_MS;
    const maxPayloads = Number(opts.maxPayloads) > 0 ? Number(opts.maxPayloads) : this.MAX_PAYLOADS;
    const target = this.str(url);
    const seen = [];
    const bodies = [];
    const bodyErrors = [];
    let detachReason = null;
    let stopReason = 'timeout';
    let tabId = Number(opts.tabId) || 0;
    let ownTab = false;
    let attached = false;
    let networkEnabled = false;

    const finish = (verdict, extra) => {
      const picked = this.collectResponses(bodies, { maxPayloads: maxPayloads });
      const out = Object.assign({
        ok: verdict.ok,
        transport: 'cdp',
        reason: verdict.ok ? undefined : verdict.reason,
        detail: verdict.ok ? '' : (verdict.detail || ''),
        stopReason: verdict.stopReason || stopReason,
        target: target,
        plid: picked.productDetails ? (this.plidFromJson(picked.productDetails.json) || this.plidFromUrl(target)) : this.plidFromUrl(target),
        payloads: picked.picked,
        urls: picked.urls,
        kinds: picked.kinds,
        reviewPages: picked.reviewPages,
        skipped: picked.skipped,
        otherResponses: picked.otherResponses,
        stats: picked.stats,
        seen: seen.slice(),
        bodyErrors: bodyErrors.slice(),
        tabId: tabId || null,
        ownTab: ownTab,
        timeoutMs: timeoutMs,
        elapsedMs: Date.now() - startedAt
      }, extra || {});
      return out;
    };

    const fail = (reason, detail, extra) => finish({ ok: false, reason: reason, detail: detail, stopReason: stopReason }, extra);

    if (!this.isProductUrl(target)) {
      return fail('bad-url', '收到：' + (target || '(空)'));
    }
    if (!this.hasPermissionsApi()) {
      return fail('no-api', '当前上下文没有 chrome.permissions（CDP 抓取只能在扩展后台/扩展页里执行）');
    }
    // 顺序很重要：未授权时 chrome.debugger 根本不存在（真机实测），
    // 必须先如实报 no-permission（并告诉用户怎么开启），而不是含糊地说「API 缺失」。
    const perm = await this.permissionState();
    if (!perm.granted) {
      return fail('no-permission', perm.error || 'chrome.permissions.contains 返回未授权');
    }
    if (!this.hasDebuggerApi()) {
      return fail('no-api', '已授权 debugger，但 chrome.debugger/chrome.tabs 仍不可用：' +
        '到 chrome://extensions 点一次「重新加载」后再试（旧实例不会自动带上新权限）');
    }

    const h = { onEvent: null, onDetach: null };
    try {
      if (!tabId) {
        let tab = null;
        try {
          tab = await chrome.tabs.create({ url: target, active: false });
        } catch (e) {
          return fail('no-tab', 'chrome.tabs.create 失败：' + ((e && e.message) || e));
        }
        tabId = tab && tab.id;
        ownTab = true;
        if (!tabId) return fail('no-tab', 'chrome.tabs.create 没有返回 tab id');
      }

      // ---- 附加 + 开 Network ----
      try {
        await chrome.debugger.attach({ tabId: tabId }, this.DEBUGGER_PROTOCOL);
        attached = true;
      } catch (e) {
        return fail('attach-failed', ((e && e.message) || String(e)));
      }

      const queue = [];
      let pumping = false;
      const pump = async () => {
        if (pumping) return;
        pumping = true;
        try {
          while (queue.length) {
            const item = queue.shift();
            let body = null;
            try {
              body = await chrome.debugger.sendCommand({ tabId: tabId }, 'Network.getResponseBody', { requestId: item.requestId });
            } catch (e) {
              bodyErrors.push({ url: item.url, error: 'Network.getResponseBody 失败：' + ((e && e.message) || e) });
              continue;
            }
            if (!body || typeof body.body !== 'string' || !body.body.trim()) {
              bodyErrors.push({
                url: item.url,
                error: body && body.base64Encoded ? '响应体是 base64（非 JSON XHR）' : '响应体为空'
              });
              continue;
            }
            let json = null;
            try {
              json = JSON.parse(body.body);
            } catch (e) {
              bodyErrors.push({ url: item.url, error: '响应体不是 JSON：' + ((e && e.message) || e) });
              continue;
            }
            bodies.push({
              url: item.url, status: item.status, mimeType: item.mimeType, type: item.type,
              json: json, seq: bodies.length, rawBytes: body.body.length
            });
            lastActivity = Date.now();
          }
        } finally {
          pumping = false;
        }
      };

      let lastActivity = Date.now();
      h.onEvent = (source, method, params) => {
        if (!source || source.tabId !== tabId) return;
        if (method === 'Network.responseReceived') {
          const r = (params && params.response) || {};
          const entry = { url: r.url, status: r.status, mimeType: r.mimeType, type: params.type };
          seen.push(entry);
          if (seen.length > this.MAX_SEEN) seen.splice(0, seen.length - this.MAX_SEEN);
          lastActivity = Date.now();
          if (this.isCandidateResponse(entry)) {
            queue.push({ requestId: params.requestId, url: entry.url, status: entry.status, mimeType: entry.mimeType, type: entry.type });
            pump();
          }
        } else if (method === 'Page.loadEventFired') {
          lastActivity = Date.now();
        }
      };
      h.onDetach = (source, reason) => {
        if (source && source.tabId === tabId) detachReason = reason || 'unknown';
      };
      chrome.debugger.onEvent.addListener(h.onEvent);
      chrome.debugger.onDetach.addListener(h.onDetach);

      try {
        await chrome.debugger.sendCommand({ tabId: tabId }, 'Page.enable');
      } catch (e) {
        bodyErrors.push({ url: '(Page.enable)', error: ((e && e.message) || e) });
      }
      try {
        await chrome.debugger.sendCommand({ tabId: tabId }, 'Network.enable');
        networkEnabled = true;
      } catch (e) {
        return fail('network-enable-failed', ((e && e.message) || e));
      }

      // ---- 等待：先等商品详情，再滚动催评论，静默即收工 ----
      const deadline = Date.now() + timeoutMs;
      let nudged = 0;
      while (Date.now() < deadline) {
        await this.sleep(this.POLL_MS);
        if (detachReason) { stopReason = 'detached'; break; }
        const picked = this.collectResponses(bodies, { maxPayloads: maxPayloads });
        const hasProduct = !!picked.productDetails;
        if (!hasProduct) continue;
        const idle = Date.now() - lastActivity;
        if (idle < settleMs) continue;
        if (opts.nudge !== false && nudged < this.NUDGE_STEPS) {
          nudged += 1;
          const nudgedOk = await this._nudge(tabId, nudged);
          lastActivity = Date.now();
          if (!nudgedOk) nudged = this.NUDGE_STEPS;   // 页面不支持 evaluate 就不要再试
          continue;
        }
        stopReason = 'idle';
        break;
      }
      if (!detachReason && stopReason === 'timeout' && this.collectResponses(bodies, { maxPayloads: maxPayloads }).picked.length) {
        stopReason = 'timeout(有部分结果)';
      }

      const verdict = this.finalizeCapture({
        picked: this.collectResponses(bodies, { maxPayloads: maxPayloads }).picked,
        seen: seen, bodyErrors: bodyErrors, detachReason: detachReason,
        stopReason: stopReason, timeoutMs: timeoutMs
      });
      return finish(verdict, { networkEnabled: networkEnabled, attached: attached, nudges: nudged });
    } catch (e) {
      return fail('exception', '未预期的异常：' + ((e && e.message) || String(e)));
    } finally {
      // 硬要求：detach 一定在 finally 里
      if (h.onEvent) { try { chrome.debugger.onEvent.removeListener(h.onEvent); } catch (e) { /* noop */ } }
      if (h.onDetach) { try { chrome.debugger.onDetach.removeListener(h.onDetach); } catch (e) { /* noop */ } }
      if (attached && tabId) {
        try { await chrome.debugger.detach({ tabId: tabId }); } catch (e) { /* 已 detach / 标签页没了 */ }
      }
      if (ownTab && tabId && opts.keepTab !== true) {
        try { await chrome.tabs.remove(tabId); } catch (e) { /* 用户可能已关掉 */ }
      }
    }
  },

  /** 把抓取结果 POST 给本地桥（桥写 state/ingest/*.json，后端 crawler 自动吸收） */
  async ingestCapture(capture, opts = {}) {
    const bridge = (typeof OpenClawBridge !== 'undefined')
      ? OpenClawBridge
      : ((typeof globalThis !== 'undefined' && globalThis.OpenClawBridge) ? globalThis.OpenClawBridge : null);
    if (!bridge || typeof bridge.ingestCapturedRaw !== 'function') {
      return { ok: false, error: 'bridge.js 未加载（没有 ingestCapturedRaw），原始 JSON 未入账' };
    }
    const built = this.toIngestBody(capture, opts);
    if (!built.ok) {
      return { ok: false, reason: built.reason, error: built.detail };
    }
    const res = await bridge.ingestCapturedRaw(built.body);
    return {
      ok: res.ok === true,
      file: res.file || '',
      dir: res.dir || '',
      stateFile: res.stateFile || '',
      bytes: res.bytes,
      plid: res.plid || built.plid,
      kinds: res.kinds || [],
      error: res.ok === true ? '' : (res.error || '本地桥未给出原因'),
      reason: res.reason || ''
    };
  },

  /**
   * 一步到位：CDP 抓 → 桥入账。给 content script 用的主入口。
   * 返回的是**紧凑摘要**（含商品详情原文，供页面复用数据；不含全部评论体，体量太大）。
   */
  async captureAndIngest(url, opts = {}) {
    // 每个字段都显式给值：失败时也要让调用方看到真实原因，不做假成功
    const capture = await this.captureProduct(url, opts);
    const summary = this.summarize(capture, null, opts);
    if (!capture.ok) return summary;
    let ingest = null;
    if (opts.ingest !== false) {
      ingest = await this.ingestCapture(capture, {
        source: opts.source || 'extension:cdp-capture'
      });
    }
    return this.summarize(capture, ingest, opts);
  },

  /** 抓取结果 → 跨进程（sendMessage）可传的紧凑摘要 */
  summarize(capture, ingest, opts = {}) {
    const payloads = (capture && capture.payloads) || [];
    const pd = payloads.find(p => p.kind === 'product-details') || null;
    const reviews = payloads.filter(p => p.kind === 'product-reviews');
    const offers = payloads.find(p => (p.kinds || []).indexOf('other-offers') >= 0) || null;
    const result = {
      ok: !!(capture && capture.ok),
      transport: 'cdp',
      written: !!(capture && capture.ok && ingest && ingest.ok === true),
      reason: (capture && capture.reason) || null,
      detail: (capture && capture.detail) || '',
      plid: (capture && capture.plid) || (pd ? this.plidFromJson(pd.json) : '') || this.plidFromUrl((capture && capture.target) || ''),
      target: (capture && capture.target) || '',
      kinds: (capture && capture.kinds) || [],
      urls: (capture && capture.urls) || [],
      reviewPages: (capture && capture.reviewPages) || [],
      payloadCount: payloads.length,
      hasProductDetails: !!pd,
      hasOtherOffers: !!offers,
      productDetails: pd ? pd.json : null,       // 页面侧可直接复用（mapFromApi）
      stopReason: (capture && capture.stopReason) || '',
      elapsedMs: (capture && capture.elapsedMs) || 0,
      timeoutMs: (capture && capture.timeoutMs) || this.DEFAULT_TIMEOUT_MS,
      skipped: (capture && capture.skipped) || [],
      seenText: capture ? this.summarizeSeen(capture.seen || []).text : '',
      ingest: ingest ? {
        ok: ingest.ok === true,
        file: ingest.file || '',
        dir: ingest.dir || '',
        stateFile: ingest.stateFile || '',
        bytes: ingest.bytes,
        error: ingest.error || '',
        reason: ingest.reason || ''
      } : null
    };
    result.reviewsCaptured = reviews.length;
    result.text = this.describe(result);
    if (opts.verbose) result.payloads = payloads;
    return result;
  },

  /** content script 侧用的消息封装（失败如实返回，不吞错） */
  async ask(message) {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      return { ok: false, error: '当前页面没有 chrome.runtime，无法与扩展后台通信' };
    }
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (res) => {
          const err = chrome.runtime && chrome.runtime.lastError;
          if (err) {
            resolve({ ok: false, error: '后台无响应：' + (err.message || String(err)) });
            return;
          }
          resolve(res || { ok: false, error: '扩展后台返回空响应' });
        });
      } catch (e) {
        resolve({ ok: false, error: (e && e.message) || String(e) });
      }
    });
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = OpenClawCdpCapture;
}
if (typeof window !== 'undefined') {
  window.OpenClawCdpCapture = OpenClawCdpCapture;
}
if (typeof self !== 'undefined' && typeof window === 'undefined') {
  // service worker 全局（importScripts 之后 self.OpenClawCdpCapture 也能拿到）
  self.OpenClawCdpCapture = OpenClawCdpCapture;
}
