/**
 * Takealot 运营助手 - 共享工具函数（对象名 OpenClawUtils 为内部标识，保持不变）
 * Strictly No Emojis, Commercial Standard
 */

const OpenClawUtils = {
  // Extract clean TSIN or PLID from URL or text
  extractIdFromUrl(url) {
    if (!url) return null;
    const plidMatch = url.match(/PLID(\d+)/i);
    if (plidMatch) return 'PLID' + plidMatch[1];
    const tsinMatch = url.match(/tsin[=\/](\d+)/i);
    if (tsinMatch) return 'TSIN-' + tsinMatch[1];
    const pMatch = url.match(/\/p\/([^\/\?#]+)/);
    if (pMatch) return pMatch[1];
    return null;
  },

  // Clean Price String to Number (e.g. "R 1,299.00" -> 1299.00)
  parseZarPrice(str) {
    if (typeof str === 'number') return str;
    if (!str) return 0;
    const clean = str.replace(/[^0-9.]/g, '');
    const num = parseFloat(clean);
    return isNaN(num) ? 0 : num;
  },

  // Format Number as ZAR
  formatZar(num) {
    const val = Number(num) || 0;
    return 'R ' + val.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  },

  // Extract High-Res Image URL from Takealot CDN Image URLs
  // Often Takealot URLs have resize query params or thumbnail path segments
  getHighResImageUrl(url) {
    if (!url) return '';
    try {
      // Remove query parameters like ?w=... or ?h=...
      let cleanUrl = url.split('?')[0];
      // Replace thumb variants with original if applicable
      cleanUrl = cleanUrl.replace(/\/covers_thumbs\//, '/covers_images/');
      cleanUrl = cleanUrl.replace(/\/covers_small\//, '/covers_images/');
      return cleanUrl;
    } catch (e) {
      return url;
    }
  },

  // AI Title Cleaner for Takealot Guidelines
  formatTakealotTitle(rawTitle, brand, specs = {}) {
    if (!rawTitle) return '';
    let title = rawTitle.trim();

    // Strip common prohibited clickbait or spam words
    const banned = [
      /100%\s*original/gi,
      /best\s*seller/gi,
      /hot\s*sale/gi,
      /free\s*shipping/gi,
      /warranty/gi,
      /guarantee/gi,
      /top\s*quality/gi,
      /special\s*offer/gi
    ];
    banned.forEach(regex => {
      title = title.replace(regex, '');
    });

    // Remove double spaces and punctuation glitches
    title = title.replace(/\s{2,}/g, ' ').replace(/^[\s\-–—:,]+|[\s\-–—:,]+$/g, '').trim();

    // Ensure brand prefix if present and not already at start
    if (brand && brand !== 'Generic' && !title.toLowerCase().startsWith(brand.toLowerCase())) {
      title = `${brand} ${title}`;
    }

    // Capitalize first letter of each word (Title Case)
    title = title.replace(/\w\S*/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());

    // Truncate safely if exceeding Takealot typical 120 chars
    if (title.length > 120) {
      const truncated = title.substring(0, 117);
      title = truncated.substring(0, truncated.lastIndexOf(' ')) + '...';
    }

    return title;
  },

  // Generate Clean HTML Description for Takealot
  generateCleanDescription(title, bulletPoints = [], attributes = {}) {
    let html = `<div class="takealot-product-description" style="font-family: Arial, sans-serif; line-height: 1.6; color: #333333;">\n`;
    html += `  <h3 style="font-size: 16px; font-weight: bold; margin-bottom: 12px; color: #111827;">${title}</h3>\n`;

    if (bulletPoints && bulletPoints.length > 0) {
      html += `  <h4 style="font-size: 14px; font-weight: bold; margin-top: 14px; margin-bottom: 8px; color: #374151;">Key Features:</h4>\n`;
      html += `  <ul style="padding-left: 20px; margin-bottom: 16px;">\n`;
      bulletPoints.forEach(bp => {
        if (bp && bp.trim()) {
          html += `    <li style="margin-bottom: 6px;">${bp.trim()}</li>\n`;
        }
      });
      html += `  </ul>\n`;
    }

    if (attributes && Object.keys(attributes).length > 0) {
      html += `  <h4 style="font-size: 14px; font-weight: bold; margin-top: 14px; margin-bottom: 8px; color: #374151;">Product Specifications:</h4>\n`;
      html += `  <table style="width: 100%; max-width: 600px; border-collapse: collapse; font-size: 13px; margin-bottom: 16px;">\n`;
      Object.entries(attributes).forEach(([key, val]) => {
        if (val) {
          html += `    <tr style="border-bottom: 1px solid #E5E7EB;">\n`;
          html += `      <td style="padding: 6px 10px; font-weight: 600; color: #4B5563; width: 35%;">${key}</td>\n`;
          html += `      <td style="padding: 6px 10px; color: #1F2937;">${val}</td>\n`;
          html += `    </tr>\n`;
        }
      });
      html += `  </table>\n`;
    }

    html += `</div>`;
    return html;
  },

  // Safe DOM Event Dispatcher to simulate real user typing in React/Angular forms
  simulateInput(element, value) {
    if (!element) return;
    element.focus();
    element.value = value;
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = OpenClawUtils;
}
