/**
 * Takealot 运营助手 - 官方类目属性模板同步 (shared/template_sync.js)
 *
 * 为什么必须做在这里：官方装载表属性模板**只有**商家后台接口能给 ——
 *   GET https://seller-api.takealot.com/v1/loadsheets/templates
 * 它要 sellers/seller.takealot.com 页面会话的 Authorization: Bearer <JWT>（HttpOnly/页面内存里），
 * 官方 Seller API（api.takealot.com + X-API-Key）**没有**属性接口。所以只能让扩展在
 * 商家后台页面上带会话 fetch，再把结果交给本地桥落进 ERP 的 state。
 *
 * 链路：本文件 fetchTemplates() → normalizeTemplates() → OpenClawBridge.ingestAttributeTemplates()
 *       → 桥 POST /takealot/api/attributes/ingest → ERP 的 state/attributes_templates.json
 *
 * 硬约束（和交付约定一致）：
 *   1) 不猜形状：官方返回的形状不认识就**报错 + 原样回报前 300 字符**，绝不编造字段。
 *   2) 不落任何凭证：本文件不读、不存、不打印 JWT / X-API-Key；报错样本会打码 eyJ… 串。
 *   3) normalizeTemplates() 是纯函数（无 chrome/fetch 依赖），可直接在 node 里单测
 *      （见 _verify/normalize_test.js）。
 *
 * 官方可能给的形状（都支持；字段/类目内层键做了宽容映射，见 FIELD_* / CATEGORY_* 常量）：
 *   A. {loadsheets:{<装载表id>:{name?, fields:{fieldId:{…}}, variant_fields, template_defaults, categories}}}
 *   B. {templates:{<id>:{name,…}}, fields:{fieldId:{…}}}            ← 顶层共享字段字典
 *   C. {loadsheets:[{id|loadsheetId, fields:{…}}, …]} / 裸数组
 *   D. 上面任意一种外面再包一层 {data:{…}} / {result:{…}} / {body:{…}}
 */

const OpenClawTemplateSync = {
  SAME_ORIGIN_PATH: '/v1/loadsheets/templates',
  ABSOLUTE_URL: 'https://seller-api.takealot.com/v1/loadsheets/templates',
  INGEST_SOURCE: 'extension:seller-sidepanel',
  RAW_FILE: 'attributes_templates_raw.json',
  MAX_SAMPLE: 300,

  // 内层键的宽容映射（官方不同端点用过不同拼法，按优先级取第一个有值的）
  ID_KEYS: ['fieldId', 'field_id', 'id', 'key', 'code'],
  TYPE_KEYS: ['fieldType', 'field_type', 'type', 'dataType', 'data_type', 'inputType', 'control'],
  NAME_KEYS: ['displayName', 'display_name', 'label', 'title', 'name'],
  DESC_KEYS: ['description', 'help', 'helpText', 'hint', 'tooltip'],
  REQ_KEYS: ['isRequired', 'is_required', 'required', 'mandatory'],
  OPTION_KEYS: ['options', 'values', 'choices', 'items'],
  NODE_NAME_KEYS: ['name', 'displayName', 'label', 'title', 'loadsheetName', 'loadsheet_name'],
  LS_ID_KEYS: ['id', 'loadsheetId', 'loadsheet_id', 'templateId', 'template_id', 'code'],
  FIELD_ID_LIST_KEYS: ['fieldIds', 'field_ids', 'fields', 'attributes', 'fieldList'],
  TAX_ID_KEYS: ['taxonomy_id', 'taxonomyId', 'nodeId', 'node_id', 'id'],
  CAT_NAME_KEYS: ['name', 'label', 'displayName', 'title'],
  REQ_LIST_KEYS: ['requirements', 'required', 'requiredFields', 'required_fields',
    'requiredFieldIds', 'required_field_ids'],

  // ---------------------------------------------------------------- 小工具

  pick(obj, keys) {
    if (!obj || typeof obj !== 'object') return undefined;
    for (const k of keys) {
      const v = obj[k];
      if (v !== undefined && v !== null && v !== '') return v;
    }
    return undefined;
  },

  toBool(v) {
    if (v === true || v === false) return v;
    if (v === undefined || v === null || v === '') return false;
    const s = String(v).trim().toLowerCase();
    return s === '1' || s === 'true' || s === 'yes' || s === 'y' || s === 'required';
  },

  str(v) {
    if (v === undefined || v === null) return undefined;
    if (typeof v === 'object') return undefined;   // 对象/数组不当字符串用，避免 [object Object]
    const s = String(v).trim();
    return s === '' ? undefined : s;
  },

  /** 报错样本里把疑似 JWT 打码（我们从不主动读凭证，这里只做兜底） */
  redact(text) {
    return String(text == null ? '' : text)
      .replace(/eyJ[A-Za-z0-9_\-.]{10,}/g, '<redacted-jwt>')
      .replace(/(Bearer|X-API-Key|api[_-]?key)\s*[:=]?\s*[A-Za-z0-9_\-.]{8,}/gi, '$1 <redacted>');
  },

  sampleOf(raw) {
    let text;
    try {
      text = typeof raw === 'string' ? raw : JSON.stringify(raw);
    } catch (e) {
      text = String(raw);
    }
    return this.redact(String(text == null ? '' : text)).slice(0, this.MAX_SAMPLE);
  },

  topKeysOf(raw) {
    if (Array.isArray(raw)) return `[数组 ${raw.length} 项]`;
    if (raw && typeof raw === 'object') return Object.keys(raw).slice(0, 12).join(', ');
    return typeof raw;
  },

  // ------------------------------------------------- 内层映射（字段 / 类目）

  /** 单个字段定义 → ingest 形状；不是对象 / 没有 id 就返回 null（由调用方计数丢弃） */
  normalizeField(fallbackId, raw, stats) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
      if (stats) stats.droppedFields += 1;
      return null;
    }
    const fieldId = this.str(this.pick(raw, this.ID_KEYS)) || fallbackId;
    if (!fieldId) {
      if (stats) stats.droppedFields += 1;
      return null;
    }
    const node = {
      fieldId: fieldId,
      fieldType: this.str(this.pick(raw, this.TYPE_KEYS)) || null,
      displayName: this.str(this.pick(raw, this.NAME_KEYS)) || fieldId.split('.').pop(),
      description: this.str(this.pick(raw, this.DESC_KEYS)) || null,
      isRequired: this.toBool(this.pick(raw, this.REQ_KEYS)),
    };
    const options = this.pick(raw, this.OPTION_KEYS);
    if (Array.isArray(options)) {
      // 官方 options 是 [[label, code, sort], …]；原样透传（ERP 侧自己会归一）
      node.options = options;
    } else if (options !== undefined) {
      // 形状不认识：不猜、不改造，如实计数
      if (stats) stats.droppedOptionShapes += 1;
    }
    return node;
  },

  /** {fieldId:{…}} —— 键不是 id 时以值里的 id 为准 */
  normalizeFields(raw, stats) {
    const out = {};
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return out;
    Object.keys(raw).forEach(key => {
      const node = this.normalizeField(key, raw[key], stats);
      if (node) out[node.fieldId] = node;
    });
    return out;
  },

  /** categories: {taxonomyId:{…}} 或 [{…}] → {taxonomyId:{taxonomy_id,name,requirements}} */
  normalizeCategories(raw, stats) {
    const out = {};
    const push = (key, val) => {
      if (!val || typeof val !== 'object' || Array.isArray(val)) {
        if (stats) stats.droppedCategories += 1;
        return;
      }
      const taxRaw = this.pick(val, this.TAX_ID_KEYS);
      const taxKey = this.str(taxRaw) || this.str(key);
      if (!taxKey) {
        if (stats) stats.droppedCategories += 1;
        return;
      }
      const reqRaw = this.pick(val, this.REQ_LIST_KEYS);
      const requirements = [];
      if (Array.isArray(reqRaw)) {
        reqRaw.forEach(item => {
          const id = typeof item === 'object' && item !== null
            ? this.str(this.pick(item, this.ID_KEYS))
            : this.str(item);
          if (id) requirements.push(id);
        });
      } else if (reqRaw && typeof reqRaw === 'object') {
        requirements.push(...Object.keys(reqRaw));   // 偶见 {fieldId:true} 形式
      }
      const asInt = /^\d+$/.test(taxKey) ? parseInt(taxKey, 10) : taxKey;
      out[String(taxKey)] = {
        taxonomy_id: asInt,
        name: this.str(this.pick(val, this.CAT_NAME_KEYS)) || null,
        requirements: requirements,
      };
    };
    if (Array.isArray(raw)) {
      raw.forEach((item, i) => push(String(i), item));
    } else if (raw && typeof raw === 'object') {
      Object.keys(raw).forEach(key => push(key, raw[key]));
    }
    return out;
  },

  /**
   * 单个装载表节点 → ingest 形状。
   * sharedFields/sharedVariantFields = 顶层共享字段字典（形状 B 用）。
   * 返回 {ok:true,node} / {ok:false,reason}
   */
  normalizeLoadsheet(lsId, raw, sharedFields, sharedVariantFields, stats) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
      return { ok: false, reason: `${lsId} 不是对象` };
    }
    let fieldsRaw = raw.fields;
    if (fieldsRaw && typeof fieldsRaw === 'object' && !Array.isArray(fieldsRaw)) {
      // 每个装载表自带字段字典（形状 A）
    } else if (Array.isArray(fieldsRaw) || Array.isArray(raw.fieldIds) || Array.isArray(raw.field_ids)) {
      // 形状 B 变体：只给字段 id 列表，字段定义在顶层共享字典里
      const ids = (Array.isArray(fieldsRaw) ? fieldsRaw : (raw.fieldIds || raw.field_ids))
        .map(x => (typeof x === 'object' && x !== null ? this.str(this.pick(x, this.ID_KEYS)) : this.str(x)))
        .filter(Boolean);
      fieldsRaw = {};
      ids.forEach(id => {
        if (sharedFields && sharedFields[id]) fieldsRaw[id] = sharedFields[id];
      });
      if (stats) stats.fieldIdListRefs += ids.length;
    } else if (sharedFields && Object.keys(sharedFields).length) {
      fieldsRaw = sharedFields;      // 形状 B：顶层共享字段字典
      if (stats) stats.sharedFieldsUsed += 1;
    } else {
      fieldsRaw = null;
    }

    const fields = this.normalizeFields(fieldsRaw, stats);
    if (!Object.keys(fields).length) {
      return { ok: false, reason: `${lsId} 找不到字段定义（fields/顶层共享 fields 都没有）` };
    }
    let variantRaw = raw.variant_fields;
    if (!variantRaw || typeof variantRaw !== 'object' || Array.isArray(variantRaw)) {
      variantRaw = sharedVariantFields || {};
    }
    const defaults = (raw.template_defaults && typeof raw.template_defaults === 'object' &&
      !Array.isArray(raw.template_defaults)) ? raw.template_defaults : {};
    return {
      ok: true,
      node: {
        name: this.str(this.pick(raw, this.NODE_NAME_KEYS)) || '',
        fields: fields,
        variant_fields: this.normalizeFields(variantRaw, stats),
        template_defaults: defaults,
        categories: this.normalizeCategories(raw.categories, stats),
      },
    };
  },

  /** 装载表目录（可选）：{id:{name,dept}}，只用来算「N/总数」 */
  normalizeCatalog(raw, stats) {
    const out = {};
    if (Array.isArray(raw)) {
      raw.forEach(item => {
        if (!item || typeof item !== 'object') return;
        const id = this.str(this.pick(item, this.LS_ID_KEYS));
        if (!id) return;
        out[id] = { name: this.str(this.pick(item, this.NODE_NAME_KEYS)) || '', dept: this.str(item.dept) || '' };
      });
    } else if (raw && typeof raw === 'object') {
      Object.keys(raw).forEach(key => {
        const val = raw[key];
        if (val && typeof val === 'object') {
          out[String(key)] = {
            name: this.str(this.pick(val, this.NODE_NAME_KEYS)) || '',
            dept: this.str(val.dept) || '',
          };
        } else if (typeof val === 'string') {
          out[String(key)] = { name: val, dept: '' };
        }
      });
    }
    if (stats) stats.catalog = Object.keys(out).length;
    return out;
  },

  // ------------------------------------------------------------ 归一化主函数

  /**
   * 官方原始 JSON → ingest 形状（纯函数）。
   * @returns {{ok:true, shape:string, loadsheets:Object, templates:Object, stats:Object}}
   *        | {{ok:false, error:string, shape:string, sample:string}}
   */
  normalizeTemplates(raw) {
    const stats = {
      shapes: [], loadsheets: 0, fields: 0, variantFields: 0, categories: 0,
      catalog: 0, droppedFields: 0, droppedCategories: 0, droppedOptionShapes: 0,
      sharedFieldsUsed: 0, fieldIdListRefs: 0, skippedNodes: [], skippedReasons: [],
    };
    const fail = (error, shape) => ({
      ok: false, error: error, shape: shape || 'unknown', sample: this.sampleOf(raw),
      topKeys: this.topKeysOf(raw),
    });

    if (raw === undefined || raw === null) return fail('官方响应为空（null/undefined）');
    if (typeof raw === 'string') {
      const text = raw;
      let parsed;
      try {
        parsed = JSON.parse(text);
      } catch (e) {
        return fail(`官方响应不是 JSON（可能是登录页 HTML 或改了协议）：${String((e && e.message) || e)}`);
      }
      return this.normalizeTemplates(parsed);
    }

    let body = raw;
    let shapeName = '';

    // D. 信封：{data:{…}} / {result:{…}} / {body:{…}}（只在没有别的可识别键时剥一层）
    if (!Array.isArray(body) && typeof body === 'object') {
      for (const key of ['data', 'result', 'body']) {
        const inner = body[key];
        if (inner && typeof inner === 'object' &&
            body.loadsheets === undefined && body.templates === undefined && body.fields === undefined) {
          body = inner;
          shapeName = `envelope:${key}`;
          stats.shapes.push(shapeName);
          break;
        }
      }
    }

    let loadsheetSource = null;      // {id: rawNode}
    let sharedFields = {};
    let sharedVariantFields = {};
    let templatesRaw = undefined;

    if (Array.isArray(body)) {
      // C. 裸数组
      shapeName = shapeName || 'array';
      stats.shapes.push('array');
      loadsheetSource = {};
      body.forEach((item, i) => {
        const id = (item && typeof item === 'object')
          ? (this.str(this.pick(item, this.LS_ID_KEYS)) || String(i)) : String(i);
        loadsheetSource[id] = item;
      });
    } else if (body && typeof body === 'object') {
      const lsRaw = body.loadsheets !== undefined ? body.loadsheets : body.loadsheets_by_id;
      if (Array.isArray(lsRaw)) {
        shapeName = shapeName || 'loadsheets-array';
        stats.shapes.push('loadsheets-array');
        loadsheetSource = {};
        lsRaw.forEach((item, i) => {
          const id = (item && typeof item === 'object')
            ? (this.str(this.pick(item, this.LS_ID_KEYS)) || String(i)) : String(i);
          loadsheetSource[id] = item;
        });
      } else if (lsRaw && typeof lsRaw === 'object') {
        shapeName = shapeName || 'loadsheets';
        stats.shapes.push('loadsheets');
        loadsheetSource = lsRaw;
      }

      if (body.fields && typeof body.fields === 'object' && !Array.isArray(body.fields)) {
        sharedFields = body.fields;
      }
      if (body.variant_fields && typeof body.variant_fields === 'object' && !Array.isArray(body.variant_fields)) {
        sharedVariantFields = body.variant_fields;
      }
      if (body.templates && typeof body.templates === 'object') {
        templatesRaw = body.templates;
        stats.shapes.push('templates');
        if (!loadsheetSource) {
          // 形状 B：没有 loadsheets 时，templates 本身就是逐个装载表的节点
          shapeName = shapeName || 'templates+fields';
          if (Array.isArray(body.templates)) {
            loadsheetSource = {};
            body.templates.forEach((item, i) => {
              const id = (item && typeof item === 'object')
                ? (this.str(this.pick(item, this.LS_ID_KEYS)) || String(i)) : String(i);
              loadsheetSource[id] = item;
            });
          } else {
            loadsheetSource = body.templates;
          }
        }
      }
    } else {
      return fail(`无法识别的响应形状（顶层是 ${typeof body}）`);
    }

    if (!loadsheetSource) {
      return fail('无法识别的响应形状：既没有 loadsheets，也没有 templates/fields（不敢猜）',
        shapeName || 'unknown');
    }
    const shaped = shapeName || 'loadsheets';
    const loadsheets = {};
    Object.keys(loadsheetSource).forEach(id => {
      const res = this.normalizeLoadsheet(String(id), loadsheetSource[id],
        this.normalizeFields(sharedFields, null), this.normalizeFields(sharedVariantFields, null), stats);
      if (res.ok) {
        loadsheets[String(id)] = res.node;
        stats.loadsheets += 1;
        stats.fields += Object.keys(res.node.fields).length;
        stats.variantFields += Object.keys(res.node.variant_fields).length;
        stats.categories += Object.keys(res.node.categories).length;
      } else {
        stats.skippedNodes.push(String(id));
        stats.skippedReasons.push(res.reason);
      }
    });

    if (!Object.keys(loadsheets).length) {
      return fail(`响应形状认出来了（${shaped}），但没有一个装载表带字段定义` +
        (stats.skippedReasons.length ? `：${stats.skippedReasons.slice(0, 2).join('；')}` : ''),
        shaped);
    }

    return {
      ok: true,
      shape: shaped,
      loadsheets: loadsheets,
      templates: templatesRaw ? this.normalizeCatalog(templatesRaw, stats) : {},
      stats: stats,
    };
  },

  // ------------------------------------------------------------------ 抓取

  /**
   * 在商家后台页面（seller.takealot.com / sellers.takealot.com）带会话抓官方模板。
   * 同源先试 `/v1/loadsheets/templates`，失败再试绝对地址 seller-api.takealot.com。
   * 不读也不打印任何凭证（credentials:'include' 只让浏览器自己带 cookie）。
   */
  async fetchTemplates() {
    const attempts = [];
    const one = async (url, label) => {
      let res;
      try {
        res = await fetch(url, {
          method: 'GET',
          credentials: 'include',
          headers: { 'Accept': 'application/json' },
          cache: 'no-store',
        });
      } catch (e) {
        attempts.push({ via: label, url: url, error: String((e && e.message) || e) });
        return { ok: false, error: `请求失败：${(e && e.message) || e}` };
      }
      let text = '';
      try {
        text = await res.text();
      } catch (e) {
        attempts.push({ via: label, status: res.status, error: '读取响应体失败' });
        return { ok: false, status: res.status, error: `读取响应体失败：${(e && e.message) || e}` };
      }
      let contentType = '';
      try {
        contentType = (res.headers && res.headers.get && res.headers.get('content-type')) || '';
      } catch (e) { /* 某些环境拿不到 headers，不影响主流程 */ }
      const bytes = (typeof TextEncoder !== 'undefined')
        ? new TextEncoder().encode(text).length : text.length;
      attempts.push({ via: label, status: res.status, bytes: bytes });
      if (!res.ok) {
        return {
          ok: false, status: res.status,
          error: `HTTP ${res.status}${res.status === 401 || res.status === 403
            ? '（多半是没登录/会话过期，先在页面正常登录一次）' : ''}`,
          bodySample: this.redact(text).slice(0, this.MAX_SAMPLE),
        };
      }
      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        return {
          ok: false, status: res.status,
          error: `HTTP ${res.status} 但返回的不是 JSON（可能是登录页 HTML 或接口已变）`,
          bodySample: this.redact(text).slice(0, this.MAX_SAMPLE),
        };
      }
      return {
        ok: true, status: res.status, data: data,
        rawText: text, contentType: contentType, bytes: bytes, url: url,
      };
    };

    let out = await one(this.SAME_ORIGIN_PATH, 'same-origin');
    let via = 'same-origin';
    if (!out.ok) {
      const second = await one(this.ABSOLUTE_URL, 'seller-api');
      if (second.ok) {
        out = second;
        via = 'seller-api';
      } else {
        return {
          ok: false, via: 'both-failed', attempts: attempts,
          error: `两处都没拿到模板：同源 ${out.error}；seller-api ${second.error}`,
          bodySample: out.bodySample || second.bodySample || '',
        };
      }
    }
    return {
      ok: true, via: via, status: out.status, raw: out.data, attempts: attempts,
      rawText: out.rawText,               // 原始响应体原文（留档用）
      contentType: out.contentType, bytes: out.bytes, url: out.url,
    };
  },

  /**
   * 把官方响应的**原始文本**交给桥留档（state/attributes_templates_raw.json）。
   * 只发响应体：不带任何请求头 / Authorization / JWT / cookie（桥也会再拒一次）。
   */
  async saveRawResponse(fetched) {
    if (typeof OpenClawBridge === 'undefined' || !OpenClawBridge.saveAttributeTemplatesRaw) {
      return { ok: false, error: 'bridge.js 未加载（无 saveAttributeTemplatesRaw）' };
    }
    if (!fetched || typeof fetched.rawText !== 'string') {
      return { ok: false, error: '没有原始响应文本可留档' };
    }
    return OpenClawBridge.saveAttributeTemplatesRaw({
      fetchedAt: new Date().toISOString(),
      url: fetched.url || '',
      via: fetched.via || '',
      status: fetched.status,
      contentType: fetched.contentType || '',
      rawText: fetched.rawText,
    });
  },

  /**
   * 一键链路：抓取 → **先留档原始响应** → 归一 → 交给本地桥落盘 → 读回桥的状态。
   * 留档在前是有意的：用户只会在真机上点这一次，归一化失败时原始响应必须已经落盘。
   * 任何一步失败都返回 {ok:false, stage, error}，绝不假装成功。
   */
  async syncAttributeTemplates() {
    if (typeof OpenClawBridge === 'undefined' || !OpenClawBridge.ingestAttributeTemplates) {
      return { ok: false, stage: 'bridge', error: 'bridge.js 未加载（请到 chrome://extensions 重新加载扩展）' };
    }
    const fetched = await this.fetchTemplates();
    if (!fetched.ok) {
      return { ok: false, stage: 'fetch', error: fetched.error, attempts: fetched.attempts || [],
        bodySample: fetched.bodySample || '' };
    }

    // 1) 先留档原始响应（只含响应体，不含凭证）
    const rawSaved = await this.saveRawResponse(fetched);

    // 2) 归一化
    const normalized = this.normalizeTemplates(fetched.raw);
    if (!normalized.ok) {
      return {
        ok: false, stage: 'normalize', error: normalized.error,
        shape: normalized.shape, sample: normalized.sample, topKeys: normalized.topKeys,
        via: fetched.via, rawSaved: rawSaved.ok === true,
        rawFile: rawSaved.file || this.RAW_FILE,
        rawBytes: rawSaved.bytes != null ? rawSaved.bytes : (fetched.bytes || null),
        rawTruncated: rawSaved.truncated === true,
        rawError: rawSaved.ok ? '' : (rawSaved.error || '未知原因'),
      };
    }

    // 3) 归一化件入库
    const payload = {
      source: this.INGEST_SOURCE,
      via: fetched.via,
      fetchedAt: new Date().toISOString(),
      loadsheets: normalized.loadsheets,
    };
    if (Object.keys(normalized.templates || {}).length) payload.templates = normalized.templates;

    const res = await OpenClawBridge.ingestAttributeTemplates(payload);
    if (!res.ok) {
      return { ok: false, stage: 'bridge', error: res.error, url: res.url, via: fetched.via,
        shape: normalized.shape, stats: normalized.stats,
        rawSaved: rawSaved.ok === true, rawFile: rawSaved.file || this.RAW_FILE,
        rawError: rawSaved.ok ? '' : (rawSaved.error || '未知原因') };
    }
    let status = null;
    if (OpenClawBridge.getAttributeTemplatesStatus) {
      const st = await OpenClawBridge.getAttributeTemplatesStatus();
      status = st.ok ? st : Object.assign({}, st, { ok: false });
    }
    return {
      ok: true, stage: 'done', via: fetched.via, shape: normalized.shape,
      stats: normalized.stats, accepted: res.accepted, total: res.totalLoadsheets,
      added: res.added || [], skipped: res.skipped || [], stateFile: res.stateFile,
      templatesExpected: res.templatesExpected, missing: res.missingLoadsheets || [],
      status: status,
      rawSaved: rawSaved.ok === true, rawFile: rawSaved.file || this.RAW_FILE,
      rawBytes: rawSaved.bytes != null ? rawSaved.bytes : (fetched.bytes || null),
      rawTruncated: rawSaved.truncated === true,
      rawError: rawSaved.ok ? '' : (rawSaved.error || '未知原因'),
    };
  },

  /** 给 UI 用的一行人话（失败也给出原因，不兜底） */
  describe(result) {
    if (!result) return '还没同步过。';
    if (!result.ok) {
      const stage = { fetch: '抓取官方接口', normalize: '归一化响应', bridge: '写入本地桥' }[result.stage] || result.stage;
      let text = `同步失败（${stage}）：${result.error}`;
      if (result.sample) text += ` ｜ 官方返回前 300 字符：${result.sample}`;
      if (result.bodySample) text += ` ｜ 响应体：${result.bodySample}`;
      if (result.stage === 'normalize') {
        text += result.rawSaved
          ? ` ｜ 原始响应已存 state/${result.rawFile}（${result.rawBytes} 字节${result.rawTruncated ? '，已截断' : ''}），可离线照着修归一化后再重发。`
          : ` ｜ ⚠ 原始响应留档失败：${result.rawError}（先让本地桥可写，再点一次，别丢这次的原始响应）。`;
      }
      return text;
    }
    const st = result.status || {};
    const parts = [
      `已同步 ${result.accepted} 个装载表`,
      `（桥里共 ${result.total} 个` +
      (result.templatesExpected ? `，本数据包含 ${result.templatesExpected} 个装载表` : '') + '）',
    ];
    if (result.missing && result.missing.length) parts.push(`还缺 ${result.missing.length} 个`);
    else if (result.templatesExpected) parts.push('已齐');
    if (result.skipped && result.skipped.length) {
      parts.push(`跳过 ${result.skipped.length} 个（无字段定义：${result.skipped.slice(0, 3).join('、')}）`);
    }
    if (st.effectiveLoadsheets) parts.push(`ERP 侧可用 ${st.effectiveLoadsheets}/${st.templatesExpected || '?'}`);
    if (result.rawSaved) parts.push(`原始响应已留档 state/${result.rawFile}`);
    else if (result.rawError) parts.push(`⚠ 原始响应未留档：${result.rawError}`);
    return parts.join('，') + '。';
  },
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = OpenClawTemplateSync;
}
if (typeof window !== 'undefined') {
  window.OpenClawTemplateSync = OpenClawTemplateSync;
}
