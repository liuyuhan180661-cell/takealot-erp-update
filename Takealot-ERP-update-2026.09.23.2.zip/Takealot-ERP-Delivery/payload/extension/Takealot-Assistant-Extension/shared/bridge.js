/**
 * Takealot 运营助手 - 本地桥客户端 (shared/bridge.js)
 * 默认桥地址: http://127.0.0.1:18790 （可用 chrome.storage.local.gatewayUrl 覆盖）
 *
 * 契约（11 个接口，路径冻结）:
 *   GET  /takealot/api/takealot/init-data        -> {ok, source, counts:{collection,drafts}, storeId, storeName, settings}
 *   GET  /takealot/api/health                    -> {ok, source, statePath, writable}
 *   GET  /takealot/api/collection/pending        -> {ok, count, items:[...]}
 *   POST /takealot/api/collection/add            -> {ok, id, deduped}
 *   POST /takealot/api/collection/update         -> {ok} / {ok:false, rejectedFields:[...]}
 *   POST /takealot/api/collection/promote        -> {ok, draftId, item, draft}
 *   GET  /takealot/api/listing/drafts            -> {ok, count, drafts:[...]}
 *   POST /takealot/api/listing/draft             -> upsert 后的草稿
 *   POST /takealot/api/attributes/ingest         -> {ok, accepted, totalLoadsheets, added[], skipped[]}
 *        （官方类目属性模板：扩展在商家后台页面带会话抓 → 归一 → 这里落 ERP 的
 *          state/attributes_templates.json；见 shared/template_sync.js）
 *   POST /takealot/api/attributes/raw            -> {ok, file, bytes, storedBytes, truncated}
 *        （官方响应体**原文**留档 state/attributes_templates_raw.json；只存响应体，
 *          不带任何请求头/JWT/cookie；rawText 上限 2MB，超限截断 + truncated:true）
 *   GET  /takealot/api/attributes/status         -> {ok, file, loadsheetsCovered, updatedAt, source,
 *                                                    bundledLoadsheets, templatesExpected, missingLoadsheets[],
 *                                                    rawFile, rawBytes, rawFetchedAt}
 *
 * CDP 抓取附加接口（**不属于上面冻结的 11 条**，见 shared/CDP-README.md）：
 *   POST /takealot/api/ingest/raw                -> {ok, file, dir, stateFile, bytes, plid, kinds}
 *        （扩展用 chrome.debugger 抓到的商品页原始 XHR JSON，落 ERP 的 state/ingest/*.json
 *          投放目录；后端 dashboard/crawler.py 的 reap_drop_folder() 会自动吸收并走
 *          与公开 API 完全相同的解析路径。路径常量见 CDP_INGEST_PATH。）
 *
 * 原则: 请求失败一律返回 {ok:false, error:<真实原因>}。
 *       本文件内不存在任何"失败即假装成功"的兜底，也不存在内置模拟数据。
 *
 * 注意: 全局对象名 OpenClawBridge 属于内部标识，按交付约定保留原名，
 *       避免牵连 3 个调用方（popup / market_floating_bar / seller_sidepanel）。
 */

const OpenClawBridge = {
  defaultGatewayUrl: 'http://127.0.0.1:18790',
  defaultPort: 18790,

  // 契约路径（冻结，禁止随意改动；测试会断言这 11 条）
  PATHS: Object.freeze({
    initData: '/takealot/api/takealot/init-data',
    health: '/takealot/api/health',
    collectionPending: '/takealot/api/collection/pending',
    collectionAdd: '/takealot/api/collection/add',
    collectionUpdate: '/takealot/api/collection/update',
    collectionPromote: '/takealot/api/collection/promote',
    listingDrafts: '/takealot/api/listing/drafts',
    listingDraft: '/takealot/api/listing/draft',
    attributesIngest: '/takealot/api/attributes/ingest',
    attributesRaw: '/takealot/api/attributes/raw',
    attributesStatus: '/takealot/api/attributes/status'
  }),

  // CDP 抓取入账路径（**第 12 个、附加接口**，故意不进上面的 PATHS：
  // PATHS 是冻结的 11 条契约，_verify/bridge_url_test.js 断言它恰好 11 个键）。
  CDP_INGEST_PATH: '/takealot/api/ingest/raw',

  // 归一化 base url：补协议、去尾斜杠；非法输入回落到默认桥
  normalizeGatewayUrl(raw) {
    let url = String(raw == null ? '' : raw).trim();
    if (!url) return this.defaultGatewayUrl;
    if (!/^https?:\/\//i.test(url)) url = 'http://' + url;
    url = url.replace(/\/+$/, '');
    try {
      const parsed = new URL(url);
      if (!parsed.host) return this.defaultGatewayUrl;
    } catch (e) {
      return this.defaultGatewayUrl;
    }
    return url;
  },

  // 纯函数式子 url 拼接（测试可直接调用，无需 chrome 环境）
  buildUrl(baseUrl, path) {
    const base = this.normalizeGatewayUrl(baseUrl);
    const p = String(path || '');
    return base + (p.startsWith('/') ? p : '/' + p);
  },

  async getGatewayUrl() {
    return new Promise((resolve) => {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local && chrome.storage.local.get) {
        try {
          chrome.storage.local.get(['gatewayUrl'], (res) => {
            resolve(this.normalizeGatewayUrl(res && res.gatewayUrl));
          });
        } catch (e) {
          resolve(this.defaultGatewayUrl);
        }
      } else {
        resolve(this.defaultGatewayUrl);
      }
    });
  },

  /**
   * 统一请求层。任何异常/非 2xx/非 JSON/ok:false 都返回 {ok:false, error, url}。
   * 绝不吞掉错误、绝不伪造成功。
   */
  async request(path, options = {}) {
    const base = await this.getGatewayUrl();
    const url = this.buildUrl(base, path);
    const method = (options.method || 'GET').toUpperCase();
    const init = {
      method,
      headers: { 'Accept': 'application/json' }
    };
    if (options.body !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(options.body);
    }

    let res;
    try {
      res = await fetch(url, init);
    } catch (e) {
      return {
        ok: false,
        offline: true,
        url,
        error: `无法连接本地桥 ${base}（${(e && e.message) || e}）。请确认本地桥已启动。`
      };
    }

    let text = '';
    try {
      text = await res.text();
    } catch (e) {
      return { ok: false, url, status: res.status, error: `读取本地桥响应失败：${(e && e.message) || e}` };
    }

    let data = null;
    if (text && text.trim()) {
      try {
        data = JSON.parse(text);
      } catch (e) {
        return {
          ok: false,
          url,
          status: res.status,
          error: `本地桥返回非 JSON 内容（HTTP ${res.status}）`,
          raw: text.slice(0, 300)
        };
      }
    }

    if (!res.ok) {
      return {
        ok: false,
        url,
        status: res.status,
        error: (data && (data.error || data.message)) || `本地桥 HTTP ${res.status}`,
        rejectedFields: data && data.rejectedFields,
        rejectedKeys: data && data.rejectedKeys
      };
    }

    if (!data || typeof data !== 'object') {
      return { ok: false, url, status: res.status, error: '本地桥返回空响应体' };
    }

    if (data.ok === false) {
      return {
        ok: false,
        url,
        status: res.status,
        error: data.error || data.message || '本地桥返回 ok:false（未给出原因）',
        rejectedFields: data.rejectedFields
      };
    }

    return Object.assign({}, data, { ok: true, url });
  },

  // ---- 健康检查 / 初始化数据 ----

  async health() {
    return this.request(this.PATHS.health);
  },

  async getInitData() {
    return this.request(this.PATHS.initData);
  },

  // 兼容旧调用方签名（popup）：返回结构化连接状态
  async checkConnection() {
    const res = await this.health();
    if (!res.ok) return { connected: false, error: res.error };
    return {
      connected: true,
      source: res.source,
      statePath: res.statePath,
      writable: res.writable
    };
  },

  // ---- 跟卖池（采集箱）----

  async getPendingCollection() {
    const res = await this.request(this.PATHS.collectionPending);
    if (!res.ok) return { ok: false, error: res.error, items: [], count: 0 };
    const items = Array.isArray(res.items) ? res.items : [];
    return { ok: true, items, count: typeof res.count === 'number' ? res.count : items.length };
  },

  async sendToCollection(product) {
    if (!product || typeof product !== 'object') {
      return { ok: false, error: '采集数据为空，未发送到本地桥' };
    }
    const images = Array.isArray(product.images) ? product.images.filter(Boolean) : [];
    const payload = {
      title: product.title || '',
      price: Number(product.price || product.buyboxPrice || 0) || 0,
      images: images,
      url: product.url || product.sourceUrl || '',
      tsin: product.tsin || '',
      plid: product.plid || '',
      barcode: product.barcode || '',
      brand: product.brand || '',
      category: product.category || ''
    };
    return this.request(this.PATHS.collectionAdd, { method: 'POST', body: payload });
  },

  /**
   * 跟卖池唯一可写操作：只允许价格与库存。
   * 其它字段不进入 body，后端若仍拒绝会返回 rejectedFields。
   */
  async updateCollection(id, patch = {}) {
    if (!id) return { ok: false, error: '缺少采集行 id，无法更新' };
    const body = { id };

    if (patch.price !== undefined && patch.price !== null && patch.price !== '') {
      const price = Number(patch.price);
      if (!Number.isFinite(price) || price < 0) return { ok: false, error: `价格不是有效数字：${patch.price}` };
      body.price = price;
    }
    if (patch.stock !== undefined && patch.stock !== null && patch.stock !== '') {
      const stock = Number(patch.stock);
      if (!Number.isFinite(stock) || stock < 0) return { ok: false, error: `库存不是有效数字：${patch.stock}` };
      body.stock = stock;
    }
    if (Object.keys(body).length === 1) {
      return { ok: false, error: '没有需要更新的字段（跟卖只允许修改价格与库存）' };
    }
    return this.request(this.PATHS.collectionUpdate, { method: 'POST', body });
  },

  // 跟卖池 -> 新建草稿 的唯一转换通道
  async promoteToDraft(id) {
    if (!id) return { ok: false, error: '缺少采集行 id，无法转为新建草稿' };
    return this.request(this.PATHS.collectionPromote, { method: 'POST', body: { id } });
  },

  // ---- 新建草稿箱 ----

  async getDrafts() {
    const res = await this.request(this.PATHS.listingDrafts);
    if (!res.ok) return { ok: false, error: res.error, drafts: [], count: 0 };
    const drafts = Array.isArray(res.drafts) ? res.drafts : [];
    return { ok: true, drafts, count: typeof res.count === 'number' ? res.count : drafts.length };
  },

  /**
   * upsert 草稿。
   *   saveDraft('', fields)        新建
   *   saveDraft('DRAFT-1', fields) 更新
   *   saveDraft(fieldsWithId)      兼容写法（fields.id 作为 id）
   */
  async saveDraft(idOrFields, maybeFields) {
    let id = '';
    let fields = null;

    if (maybeFields !== undefined) {
      id = typeof idOrFields === 'string' ? idOrFields : '';
      fields = maybeFields;
    } else if (idOrFields && typeof idOrFields === 'object' && !Array.isArray(idOrFields)) {
      fields = Object.assign({}, idOrFields);
      if (typeof fields.id === 'string') {
        id = fields.id;
        delete fields.id;
      }
    }

    if (!fields || typeof fields !== 'object' || Array.isArray(fields)) {
      return { ok: false, error: '草稿字段为空或格式非法' };
    }

    const body = { fields };
    if (id) body.id = id;
    return this.request(this.PATHS.listingDraft, { method: 'POST', body });
  },

  // ---- 官方类目属性模板（扩展在商家后台页面带会话抓到 → 交给桥落盘）----

  /**
   * 把归一后的官方装载表属性模板交给本地桥写入 ERP 的 state/attributes_templates.json。
   * body 形状（由 shared/template_sync.js 产出）：
   *   {source, via, fetchedAt, loadsheets:{<装载表id>:{name,fields,variant_fields,template_defaults,categories}},
   *    templates?:{<id>:{name,dept}}}   ← 可选目录，用于算「N/总数」
   * 桥只接受认识的形状；不认识的条目会被点名跳过（返回 skipped），不会静默丢弃。
   */
  async ingestAttributeTemplates(payload) {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return { ok: false, error: '属性模板载荷为空或格式非法' };
    }
    const loadsheets = payload.loadsheets;
    if (!loadsheets || typeof loadsheets !== 'object' || Array.isArray(loadsheets) ||
        Object.keys(loadsheets).length === 0) {
      return { ok: false, error: '属性模板载荷里没有 loadsheets{<装载表id>:{fields:{…}}}，未发送到本地桥' };
    }
    return this.request(this.PATHS.attributesIngest, { method: 'POST', body: payload });
  },

  /** 查已收录情况：{ok, file, loadsheetsCovered, updatedAt, source, bundledLoadsheets, templatesExpected, missingLoadsheets[], rawFile, rawBytes, rawFetchedAt} */
  async getAttributeTemplatesStatus() {
    const res = await this.request(this.PATHS.attributesStatus);
    if (!res.ok) {
      return { ok: false, error: res.error, loadsheetsCovered: 0, file: res.file || '' };
    }
    return res;
  },

  /**
   * 把官方响应的原始文本留档（state/attributes_templates_raw.json），供离线排错。
   * 只发响应体：**不带**任何请求头 / Authorization / JWT / cookie（桥侧也会拒绝这类字段）。
   * rawText 上限由桥控制（2MB，超限截断并标 truncated:true）。
   */
  async saveAttributeTemplatesRaw(payload) {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return { ok: false, error: '原始响应留档载荷为空或格式非法' };
    }
    if (typeof payload.rawText !== 'string') {
      return { ok: false, error: '原始响应留档需要 rawText（响应体原文，字符串）' };
    }
    return this.request(this.PATHS.attributesRaw, { method: 'POST', body: payload });
  },

  // ---- CDP 抓取结果入账（写 ERP 的 state/ingest/ 投放目录，crawler 自动吸收）----

  /**
   * 把 CDP 抓到的**原始 XHR JSON** 交给本地桥落进 ERP 的 state/ingest/*.json。
   *
   * 为什么是「投放目录」而不是新协议：后端 dashboard/crawler.py 早就有这个机制 ——
   *   crawler.ingest_dirs()  = state/ingest/{root,done,failed}          (crawler.py:1194-1196)
   *   crawler.reap_drop_folder() 读 state/ingest/*.json → ingest_payload(body) → 好的进 done/，
   *   坏的进 failed/ 并在 state/ingest_log.json 里点名（crawler.py:1232-1269）
   * 载荷形状对齐 ingest_payload 认识的键：plid / productDetails / reviewPages / fetchedAt[Ms]
   * （crawler.py:1388-1473），与真实投放样例 /tmp/hermeswin/ingest/ingest-PLID96730174.json 同形。
   *
   * body 由 shared/cdp_capture.js 的 toIngestBody() 产出，只含响应体原文：
   * **不带**任何请求头 / Authorization / JWT / cookie（桥侧也会拒绝这类键）。
   */
  async ingestCapturedRaw(body) {
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
      return { ok: false, error: 'CDP 抓取载荷为空或格式非法，未发送到本地桥' };
    }
    const hasProduct = !!(body.productDetails && typeof body.productDetails === 'object');
    const pages = body.reviewPages || body.pages;
    const hasPages = Array.isArray(pages) ? pages.length > 0 : (!!pages && typeof pages === 'object' && Object.keys(pages).length > 0);
    if (!hasProduct && !hasPages) {
      return { ok: false, error: 'CDP 抓取载荷里既没有 productDetails 也没有 reviewPages，未发送到本地桥' };
    }
    return this.request(this.CDP_INGEST_PATH, { method: 'POST', body: body });
  },

  // ---- 图片批量下载（交给 background service worker）----

  downloadImages(tsin, imageUrls) {
    if (!Array.isArray(imageUrls) || imageUrls.length === 0) {
      return { ok: false, error: '没有可下载的图片 URL' };
    }
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      return { ok: false, error: '当前环境没有 chrome.runtime，无法派发下载任务' };
    }
    chrome.runtime.sendMessage({
      type: 'DOWNLOAD_IMAGES',
      tsin: tsin || 'takealot_item',
      urls: imageUrls
    });
    return { ok: true, count: imageUrls.length };
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = OpenClawBridge;
}
if (typeof window !== 'undefined') {
  window.OpenClawBridge = OpenClawBridge;
}
