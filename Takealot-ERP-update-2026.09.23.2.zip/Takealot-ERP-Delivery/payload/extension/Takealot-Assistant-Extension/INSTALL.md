# 交付说明 · Takealot 运营助手（Chrome/Edge MV3 扩展）

改造范围：`openclaw_ext/**`（就地改造，未部署、未重启任何后端、未改动其它目录）。
扩展现在只认**我们自己的本地桥**，默认 `http://127.0.0.1:18790`。

---

## 一、安装（Chrome / Edge，加载已解压扩展）

1. 确认本机已经拿到改造后的文件夹（Windows 上建议仍放在原目录 `C:\Users\Fly\Desktop\Takealot-Assistant-Extension`，**目录名未要求改**）。
2. 打开 Chrome 或 Edge，地址栏输入 `chrome://extensions` / `edge://extensions`。
3. 打开右上角 **开发者模式 / Developer mode**。
4. 点左上角 **加载已解压的扩展程序 / Load unpacked**，选中该文件夹。
5. 工具栏出现蓝色向上箭头图标「**Takealot 运营助手**」即安装成功。
6. 点图标打开弹窗：状态区应显示「本地桥已连接」；若显示「未检测到本地桥」，先做第二步。

> 改完代码后必须回 `chrome://extensions` 点该扩展的「重新加载 ↻」，content script 才会更新；已打开的 takealot 页面建议刷新一次。
> 目录里原有的 `Takealot_OpenClaw_Extension.zip` 和 `Takealot 跨境中台 (ERP).lnk` 是旧产物，**不是**被加载的扩展内容，可忽略（本次未随新目录交付）。

---

## 二、先启动本地桥（否则扩展只会显示未连接）

扩展本身不含任何模拟数据，桥没起来就是真的没数据。

```bash
# 1) 启动本地桥（命令以「本地桥」自己的交付说明为准；形如）
python3 <bridge目录>/bridge.py --port 18790

# 2) 自检（必须返回 JSON，且 ok=true）
curl -s http://127.0.0.1:18790/takealot/api/health
#   {"ok":true,"source":"hermes-erp-bridge","statePath":"...","writable":true}
```

扩展依赖的 11 个接口（契约冻结）：

| 方法 | 路径 | 用途 |
| --- | --- | --- |
| GET | `/takealot/api/takealot/init-data` | 弹窗计数 / 店铺信息 |
| GET | `/takealot/api/health` | 弹窗连接状态 |
| GET | `/takealot/api/collection/pending` | 跟卖池列表 |
| POST | `/takealot/api/collection/add` | 市场页抓到的商品入池 |
| POST | `/takealot/api/collection/update` | **仅** `{id, price?, stock?}` |
| POST | `/takealot/api/collection/promote` | 采集行 → 新建草稿（唯一转换通道） |
| GET | `/takealot/api/listing/drafts` | 草稿箱列表 |
| POST | `/takealot/api/listing/draft` | 草稿 upsert |
| POST | `/takealot/api/attributes/ingest` | 官方类目属性模板入库（见第五节） |
| POST | `/takealot/api/attributes/raw` | 官方响应体原文留档（只存响应体，不存凭证；上限 2MB） |
| GET | `/takealot/api/attributes/status` | 覆盖进度 + 原始留档信息（`loadsheetsCovered` / `missingLoadsheets` / `rawFile`…） |

**附加接口（不属于上面冻结的 11 条，可选的 CDP 抓取用；见 `shared/CDP-README.md`）**

| 方法 | 路径 | 用途 |
| --- | --- | --- |
| POST | `/takealot/api/ingest/raw` | CDP 抓到的商品页**原始 XHR JSON** 投放进 ERP 的 `state/ingest/`，后端 `crawler.reap_drop_folder()` 自动吸收；只收 `plid` / `productDetails` / `reviewPages` / `fetchedAt[Ms]` 这些 crawler 认识的键，带 `authorization` 之类字段直接 400 |

---

## 三、改桥端口

- 点扩展图标 → 状态卡里「**桥端口**」输入框填端口（1–65535）→ 点「**保存并重连**」。
- 该值写入 `chrome.storage.local.gatewayUrl`（形如 `http://127.0.0.1:<端口>`），弹窗与所有页面脚本读同一处。
- 不填则用默认 `18790`；填 `127.0.0.1:18790` 这类裸地址也会自动补 `http://`。
- 换端口后建议刷新一次卖家后台页面，让抽屉重新拉数据。

---

## 四、两个 tab 的边界（必须按此使用）

### 跟卖池（原“采集箱”）
- 商品在平台上**已存在**，跟卖**只能改「价格 / 库存」**。
- 标题 / SKU / TSIN / PLID / 条码 / 图片 / 采集时间 / 原页链接都是**只读展示**，界面上没有任何改内容或换图的入口。
- 保存按钮文案为「**保存价格与库存（跟卖）**」，只向后端提交 `id / price / stock`；后端若拒绝其它字段，会在 toast 里列出 `rejectedFields`。
- 想自己重新刊登（不是跟卖）：点「**转为新建草稿（跟卖池 → 草稿箱）**」，会跳到草稿箱继续编辑。这是两个 tab 之间**唯一**的数据通道，两边数据不会互相混用。

### 新建草稿箱（原“草稿”）
- 承载没编辑完的新建 listing，字段覆盖官方装载表：标题 / 副标题 / 卖点 / 包装清单 / 品牌 / 型号 / 条码 / 售价 / RRP / Leadtime / 主类目 / 图片 URL / 动态类目属性。
- 「**保存到草稿箱**」写草稿箱；保存后卡片上会显示**完整度百分比 + 缺项列表**，以及**最近一次保存时间**。
- 「**一键回填到官方新建 Listing 表单**」把字段写进官方页面控件。

---

## 五、同步官方类目属性模板（把 7/36 → 36/36 补上）

**为什么必须在卖家后台页面上点一次**：官方「装载表属性模板」只有商家后台接口能给 ——
`GET https://seller-api.takealot.com/v1/loadsheets/templates`，它要**页面登录会话**（`Authorization: Bearer <JWT>`，
JWT 在页面会话里，扩展之外拿不到）。官方 Seller API（`api.takealot.com` + `X-API-Key`）**没有**这个接口，
所以离线跑、后台跑都拿不到：只能在你**正登录着的卖家后台页面**点一次。

**在哪点**：任意 `seller.takealot.com` / `sellers.takealot.com` 页面 → 右侧抽屉 → 「**新建草稿箱**」tab →
「**官方类目属性模板**」卡片 → 点「**同步官方类目属性模板**」。

**点完发生了什么**（3 步，全部在本机完成）：
1. 扩展用本页会话请求 `/v1/loadsheets/templates`（同源不可用会自动改用绝对地址
   `https://seller-api.takealot.com/v1/loadsheets/templates`，仍带会话）；
2. **先把官方响应原文留档**到 `state/attributes_templates_raw.json`：形状
   `{fetchedAt, url, status, contentType, bytes, rawText}`，`rawText` 上限 **2MB**（超限截断并标
   `truncated:true`，同时给出原字节数 `bytes` 与落盘字节数 `storedBytes`）。
   **只存响应体，不存任何请求头 / Authorization / JWT / cookie**（桥会把这类字段直接拒掉）；
3. 再把归一化后的模板 POST 给本地桥 `/takealot/api/attributes/ingest`，桥原子写入
   `state/attributes_templates.json` —— 这是 ERP 插件 `plugin_api.py` **读的同一个文件**，
   ingested 覆盖数据包自带的 bundled。

留档放在归一化**之前**是有意的：万一官方换了返回形状，这一次点击的原始响应不会白丢。

**ERP 里能看到什么**：
- 抽屉结果行：「已同步 N 个装载表（桥里共 M 个，本数据包含 K 个装载表），还缺 X 个 …，原始响应已留档 …」；
- ERP「上架编排 → 类目属性」：同步前只有 7 个装载表能给出必填属性，同步后其余装载表/叶子类目也能给出
  （必填 = `loadsheets[id].categories[taxonomyId].requirements`；未收录类目仍**不做跨类目兜底**，会如实说未收录）；
- 命令行随时自查（桥在跑就行）：

  ```bash
  curl -s http://127.0.0.1:18790/takealot/api/attributes/status
  # loadsheetsCovered / effectiveLoadsheets / templatesExpected / missingLoadsheets[] / rawFile / rawBytes / rawFetchedAt
  ```

**失败怎么办**（结果行会写明「哪一步 + 真实原因 + 下一步」）：

| 结果行现象 | 原因 | 怎么办 |
| --- | --- | --- |
| `同步失败（抓取官方接口）：HTTP 401/403（多半是没登录/会话过期…）` | 页面会话过期/没登录 | 在卖家后台正常登录一次 → 刷新页面 → 再点一次 |
| `HTTP 200 但返回的不是 JSON（可能是登录页 HTML…）` | 被重定向到登录页，或接口协议变了 | 先确认页面已登录；仍如此就把结果行里的样例反馈 |
| `同步失败（归一化响应）：无法识别的响应形状…｜官方返回前 300 字符：…` | 官方换了返回形状 | **不用再让你点第二次**：原始响应已存在 `state/attributes_templates_raw.json`，拿它离线修 `shared/template_sync.js` 的映射后重发 |
| `⚠ 原始响应留档失败：…` | 本地桥没起来 / state 不可写 | 先让桥可写（第二节）再点一次——这一次的原始响应**不会**被保存 |
| `同步失败（写入本地桥）：…` | 桥没起来、端口不对、被拒 | `curl http://127.0.0.1:18790/takealot/api/health` 看健康；端口改过就按第三节重连 |
| `template_sync.js 未加载（请到 chrome://extensions 重新加载扩展）` | 扩展没重新加载 | `chrome://extensions` 点「重新加载 ↻」→ 刷新页面 |

网络中断 / 代理拦截也算抓取失败，报错里会带真实 HTTP 状态或异常文本。本功能**任何一步失败都不会假装成功**，
也**不会**把 JWT/Key 写进 state、日志或界面。

---

## 六、CDP 精确抓取（**可选权限**，不装也能用）

买家商品页上最完整的数据是页面自己发出的那几个 XHR（`api.takealot.com/rest/.../product-details`、
`.../product-reviews/plid/<数字>?page=N`，以及响应体里的 `other_offers` 报价块）。扩展可以用
Chrome 的调试协议（`chrome.debugger` + `Network` 域）把**响应体原文**抓下来，经本地桥写进 ERP 的
`state/ingest/` 投放目录，后端 crawler 会自动吸收（走与公开 API 相同的解析路径）。

**为什么做成可选**：`debugger` 权限在安装时会弹「读取和更改您在所有网站上的所有数据」级别的提示。
它只是**增强项** —— 不授权时采集仍走页面 DOM + 公开接口（出口 IP 被 Cloudflare 挡时才最需要它）。

怎么开（点一次即可）：

1. **推荐**：点扩展图标 →「**CDP 精确抓取（可选权限）**」区块 → 点「启用 CDP 抓取」（扩展页面里点击
   一定带用户手势，浏览器会弹一次确认）。同一个按钮之后会变成「撤销 CDP 抓取权限」。
2. 买家商品页浮动条 →「启用 CDP 抓取（可选权限）」；卖家后台抽屉 →「用 CDP 抓取当前商品」时也会
   自动请求一次（浏览器若因缺少用户手势拒绝，会如实提示你去弹窗点）。

用哪儿：

- **浮动条「存入跟卖池」**：优先 CDP（成功则采集行标记 `transport=cdp`，商品名/报价来自原始 JSON），
  失败退回 DOM/公开接口并标 `transport=dom`，toast 里写清 CDP 失败原因。
- **卖家后台抽屉「用 CDP 抓取当前商品」**：CDP 专用入口（不做 DOM 冒充），抓完直接把原始 JSON 交给桥。

抓取行为与排错清单（`no-permission` / `attach-failed` / `no-responses` / `no-payload` / `detached` /
`no-plid` 各怎么办）全部写在 **`shared/CDP-README.md`**，包含降级顺序
**CDP → DOM → 公开 API → 明确 blocked** 与"必须真机点一次"的清单。

---

## 七、回填失败怎么办

回填只写官方页面上的真实控件，**不会**再“静默复制剪贴板然后说成功”。两种结果：

1. **命中若干字段** → toast 会逐个报出命中的字段名，例如
   `回填完成，命中 7 个字段：标题 title、副标题 subtitle、品牌 brand、型号 model、售价 selling price、备货期 leadtime、描述 description。`
2. **一个都没命中** → 明确报
   `当前页面不是新建 Listing 表单 / 页面结构可能变了（未探测到任何表单字段）。请在官方「Add a Product」页面打开本抽屉，或用下方「手动复制标题」。`

排查顺序：
1. 确认当前页面是官方**新建/添加商品（Add a Product）**表单页，而不是商品列表或编辑页；
2. 页面刚跳转时表单可能还没渲染完 → 等 1–2 秒再点一次；
3. 仍失败说明官方改了 DOM 选择器 → 用抽屉里的「**手动复制标题**」按钮，把标题/图片 URL 手工粘过去（图片可点「复制全部 URL」）；
4. 反馈时请把 toast 里的**命中字段名列表**一起给出，便于定位是哪个选择器失效。

---

## 八、内部标识未改名的说明（有意为之）

用户可见文案已全部换成「Takealot 运营助手」（含 manifest `name`/`description`/`default_title`、弹窗标题与按钮、抽屉标题与全部提示、toast、README）。

但以下**内部标识保持原名**，因为大面积重命名会牵连 4 个文件的调用方、带来无谓回归风险：

- DOM id / class 前缀：`openclaw-*`（如 `openclaw-seller-copilot-drawer`、`openclaw-field-price`）
- CSS 文件名：`styles/openclaw_extension.css`
- JS 全局对象名：`OpenClawBridge`、`OpenClawSellerCopilot`、`OpenClawUtils`、`TakealotMarketScraper`

看到 `openclaw-` 属于内部标识，**不代表品牌文案残留**；真要改名应作为独立重构任务，一起改 manifest 注入顺序与全部调用点。

---

## 九、本次实测过的 / 需要真机点一次的

### 已在本机真实跑通（有命令与输出，见交付报告）
- 10 个 `.js` 全部 `node --check` 通过；`manifest.json` 通过 `python3 -m json.tool`。
- 4 个图标 PNG 头部实测为 16×16 / 32×32 / 48×48 / 128×128（`python3` 读 PNG IHDR）。
- `shared/bridge.js` 对**本地最小桩桥**（`_verify/stub_bridge.py`，实现同 11 个接口）跑通 **42 条断言**：11 条路径字符串、URL 拼接、每个接口的方法/路径/body、`collection/update` body 只含 `id/price/stock`、`attributes/raw` body 只含白名单字段（无 headers/JWT/cookie）、失败场景（HTTP 500、`rejectedFields`/`rejectedKeys`、非 JSON、端口不通）**一律返回 `{ok:false,error}`，无 `simulated`/假成功**。
- 官方类目属性模板链路（新增，全部真跑，见 `_verify/`）：
  - `_verify/normalize_test.js`：归一化函数单测 **37 PASS / 0 FAIL**（形状 A `{loadsheets:{…}}`、形状 B `{templates:{…},fields:{…}}`、数组/裸数组/信封；**不认识的形状必须报错 + 回报前 300 字符**；JWT 打码；全链路 stub 下「先留档原始件 → 再 ingest」的顺序与载荷白名单；401/桥拒收/桥没起来/write 失败各失败路径）。
  - `_verify/attr_bridge_ingest_test.py`：真起桥（临时 state 副本，端口 18796）**79 PASS / 0 FAIL**：干净 state 如实报 `covered:0` + reason、自造装载表 `999` 落盘、`status` 读回、同 body 重发幂等、合并（1→2）、缺 fields 点名 skipped、畸形形状 400、CORS 白名单、审计 jsonl 无凭证、**raw 留档**（畸形响应一字不差、>2MB 截断 `truncated:true`、带 `headers` 直接 400 且不落盘、ingest 失败后 raw 仍在）、按数据包目录 37 个装载表全量 ingest 后 `missingLoadsheets:[]`。
  - `_verify/attr_erp_read_test.py`：拿**插件的 `plugin_api.py` 副本**读同一份 state，**20 PASS / 0 FAIL**：`_attribute_ingested()`/`_attribute_loadsheets_all()` 里能看到桥写的装载表（7 → 39）、taxonomy 反查、`meta_attributes` 给出必填、同名装载表以 ingested 为准、数据包 bundled 路径未被破坏、未收录类目仍不兜底。
  - `_verify/sidepanel_attrsync_test.js`：抽屉接线（假 DOM）**14 PASS / 0 FAIL**：按钮渲染/禁用、成功与失败结果行（含「原始响应已存 state/attributes_templates_raw.json，可离线修」）、点击确实调用同步、toast 判成败、template_sync.js 未加载时的明确报错。
  - 一键复跑：`bash _verify/run_attr_e2e.sh`（全部输出落在 `_verify/*_out.txt`）。

- CDP 原始抓取链路（新增，全部真跑，见 `_verify/`）：
  - `_verify/cdp_pure_test.cjs`：**54 PASS / 0 FAIL**。A 段纯逻辑（用真实抓取样本
    `crawl-samples/pd_PLID100888308.json`（含 `other_offers`）、`rv_*_p1..p3.json`）：URL 分类、
    归包顺序（**商品详情 → offers → 评论按页码升序，与到达顺序无关**）、响应体原样回传、
    `toIngestBody` 与真实投放样例同形的键、失败归因（`no-responses` / `no-payload` / `detached` /
    `not-captured` / `no-plid`）；B 段用**模拟 chrome API**验证控制流：调用序列
    `permissions.contains → tabs.create → attach('1.3') → Page.enable → Network.enable →
    Network.getResponseBody`、**detach 与关闭隐藏标签页都在 finally**、未授权不发 attach、
    attach/Network.enable 失败带原始错误、只有图片响应 → `no-payload`（不假装成功）、
    一个响应都没有 → `no-responses`（等满时限）、中途 detach → `detached`、桥不通时
    `ok=true` 但 `written=false` 且带桥的真实错误。
  - `_verify/cdp_ui_entry_test.cjs`：**20 PASS / 0 FAIL**（假 DOM + 桩 chrome）。抽屉
    「用 CDP 抓取当前商品」卡片在两个 tab 都渲染、目标推导（真实 url 优先 / 只有 TSIN 按扩展口径
    推导 / 没有选中行明确报错）、未授权时先请求权限且被拒**不发抓取消息**并指向弹窗、授权后发
    `CDP_CAPTURE_AND_INGEST`；浮动条采集按钮**优先 CDP**（采集行 `transport=cdp`，标题/报价来自原始
    JSON）、CDP 失败**退回 DOM**（`transport=dom` + toast 写明原因）、面板「抓取通道」状态行如实显示。
  - `_verify/cdp_bridge_ingest_test.py`：**23 PASS / 0 FAIL**，端到端。扩展**真实代码**
    （`shared/bridge.js` + `shared/cdp_capture.js`，只用 `chrome.storage` 桩指端口）→ 真桥
    （临时 state，端口 18795）→ `state/ingest/cdp-<PLID>-….json` → **真 `crawler.py`
    `reap_drop_folder()` 吸收成功**：投放件移进 `done/`、`ingest_log.json` 记 `ingested:1`、
    缓存 `transport=ingest`、真实评论页被重放成评论窗口（`reviews_30d:30`）、算出销量估计 1200；
    坏件（空件 / 带 `authorization` / 推不出 PLID / 非 JSON / GET）一律 400 且**不落盘**。
  - `_verify/cdp_realchrome_probe.cjs`：**真 Chrome 探针（本机 Chrome for Testing 150，headless）
    9 项断言全通过 + 1 项点击观察项符合预期**。证明三件事：① `optional_permissions:["debugger"]` 被 Chrome **原样接受**
    （扩展正常加载、`getManifest()` 返回 `["debugger"]`、`permissions` 里没有 debugger、加载日志无
    manifest/权限报错）；② 真 MV3 **service worker 里 `importScripts` 成功**（后台能正确回应
    `CDP_CAPTURE_STATUS`）；③ **未授权时 `chrome.debugger` 根本不存在、`permissions.contains=false`**，
    抓取入口如实返回 `reason:no-permission`（并指引「点一次启用」），不是含糊的 API 缺失、更不是假成功。
  - 无回归：`_verify/bridge_url_test.js` **42/42**（冻结的 11 条桥契约原样）、`normalize_test.js`
    **37/37**、`sidepanel_attrsync_test.js` **14/14** 在本次改动后重跑仍全通过。
  - 一键复跑：`bash _verify/run_cdp_e2e.sh`（语法检查 + 真 Chrome 探针 + 上面 3 个 CDP 测试 + 3 个回归，
    输出落在 `_verify/cdp_*_out.txt`、`_verify/regress_*_out.txt`）。

- 无头 Chrome 真机渲染（同一个桩桥）：
  - 抽屉两个 tab 渲染正确、默认进草稿箱；跟卖池 tab **只有价格/库存两个输入框**，标题/品牌/图片输入框均不存在（DOM 断言为 true），只读行齐全；
  - 点「保存价格与库存（跟卖）」→ 桩桥收到 `{"id":"COL-1001","price":455.5,"stock":9}`，toast 为「已保存价格与库存（跟卖），listing 内容未改动。」；
  - 「转为新建草稿」→ 桩桥收到 `{"id":"COL-1001"}`，自动切到草稿箱 tab；
  - 草稿箱 tab 12 个字段 + 4 个动态类目属性渲染正常，完整度 82% / 缺项提示 / 最近保存时间正常；
  - 点回填 → 命中 7 个字段（逐个字段名列出），且真的写进了页面控件（标题/品牌/售价/描述已取到值）；
  - 在**没有表单**的页面上点回填 → 明确报「当前页面不是新建 Listing 表单 / 页面结构可能变了」，并保留「手动复制标题」按钮；
  - 页面内 `placeholder.com` 图片数 = 0（占位图已删除，加载失败走本地条纹占位块）。
  - 真实 `popup.html` + `popup.js` 渲染：状态区为「本地桥已连接 / 本地桥（127.0.0.1:18790）· 来源: hermes-erp-bridge · 可写: 是」，端口输入框值 18790，三个快捷入口与两个开关齐全。

### 必须到真机浏览器点一次才算数（离线无法证明）
- **CDP 抓取（本次最重要的人工项，逐条见 `shared/CDP-README.md` 第 7 节）**：
  离线已证的部分（manifest 被接受、真 SW 的 importScripts、未授权时 `no-permission`）见上面的真 Chrome 探针；
  仍需人工点一次的只剩：**授权弹窗那一次确认**（授权后是否立即生效不用重载）、真商品页抓到 XHR
  （结果应出现 `transport=cdp` 与 `state/ingest/cdp-<PLID>-….json`）、Chrome 顶部「正在调试此浏览器」
  提示条出现/消失、评论懒加载滚动是否催出第 2/3 页、只有 TSIN 时推导出的 `/p/PLID…` 是否被正确重定向、
  未授权时的降级观感（`transport=dom`）、25s 抓取期间 service worker 会不会被回收。
  **今天来不及点的话**：明确说「当前用 DOM + 公开接口抓取，CDP 作为增强项下一步启用」即可 —— 代码里
  未授权路径会如实报 `no-permission`，不会假成功。
0. **官方类目属性模板的真实抓取**：真机 JWT 只在你机器上，本机**拿不到真实模板**——`state/attributes_templates.json`
   在真机上点一次「同步官方类目属性模板」之前是空的（数据包里只有 7 个装载表）。点一次后请把抽屉结果行
   截图/文本，以及 `curl -s http://127.0.0.1:18790/takealot/api/attributes/status` 的输出一起反馈
   （有 `missingLoadsheets[]` 就说明还缺哪些）。**仿真链路已用自造装载表 `999` 与数据包目录全量 37 个装载表证明**，
   但"官方真实返回的形状"只能真机见；不认识的话原始响应会留在 `state/attributes_templates_raw.json`，离线可修。
1. **回填命中率**：官方 seller.takealot.com「Add a Product」真实 DOM 与我的桩页面不同，选择器需要真机验证一次；命中的字段名会逐个报出来，据此微调选择器。
2. **图片 URL 输入框**：官方是否真有可写 URL 的图片输入（`input#imageUrl` 之类）需真机确认；没有就只能靠「复制全部 URL」手工贴。
3. **长描述富文本**（`div.ql-editor` / contenteditable）：桩页面用的是 `textarea`，官方若是 Quill，需要真机确认写入后编辑器状态正常。
4. **图片批量下载**：`chrome.downloads` 只能在真实扩展环境验证，落盘路径应为 `takealot_assets/<tsin>/<tsin>_image_N.jpg`（本次只做了代码与消息通道检查，未在扩展内实际触发下载）。
5. **`chrome.storage` 端口覆盖**：桩环境用的是垫片，真机上改端口 → 保存 → 重连需点一次确认。
6. **真实本地桥**（另一子代理产出）联调：字段名/去重/`rejectedFields` 行为以真桥为准；若真桥返回体与契约不同，`bridge.js` 会把真实错误原样显示在 toast 里，不会假装成功。

---

## 十、验证脚本位置（不属于扩展，不会被 Chrome 加载）

- `/tmp/hermeswin/_verify/stub_bridge.py` —— 11 接口桩桥（18790 正常 / 18792 恒 500 / 18793 恒非 JSON），附带 UI 冒烟页 `/autotest`、`/autotest-blank`、`/shot`、`/popup-verify`
- `/tmp/hermeswin/_verify/bridge_url_test.js` —— node 契约断言（42 条，含 3 条属性模板接口）
- `/tmp/hermeswin/_verify/normalize_test.js` —— 归一化 + 同步链路单测（37 条）
- `/tmp/hermeswin/_verify/sidepanel_attrsync_test.js` —— 抽屉同步卡片接线测试（14 条，假 DOM）
- `/tmp/hermeswin/_verify/attr_bridge_ingest_test.py` —— 桥端到端（79 条，真起桥 + 临时 state 副本）
- `/tmp/hermeswin/_verify/attr_erp_read_test.py` —— ERP 插件读回（20 条，plugin_api.py 副本）
- `/tmp/hermeswin/_verify/run_attr_e2e.sh` —— 上面 4 个脚本的一键复跑 + 语法检查

CDP 抓取（本次新增）：

- `/tmp/hermeswin/_verify/cdp_pure_test.cjs` —— 纯逻辑 + 模拟 chrome 控制流（**54 条**：分类/归包顺序/入账体/失败归因/detach 在 finally）
- `/tmp/hermeswin/_verify/cdp_ui_entry_test.cjs` —— 两个界面入口（**20 条**，假 DOM：抽屉卡片 + 浮动条 CDP 优先/退 DOM）
- `/tmp/hermeswin/_verify/cdp_bridge_client_node.cjs` —— 用扩展真实代码（bridge.js + cdp_capture.js）打真桥的 node 客户端
- `/tmp/hermeswin/_verify/cdp_bridge_ingest_test.py` —— 端到端（**23 条**：扩展真代码 → 真桥 → `state/ingest/` → 真 `crawler.py` 吸收）
- `/tmp/hermeswin/_verify/cdp_realchrome_probe.cjs` —— **真 Chrome 探针**（9 项：manifest 可选权限 / 真 SW importScripts / 真 permissions / 未授权路径）
- `/tmp/hermeswin/_verify/run_cdp_e2e.sh` —— CDP 链路一键复跑（语法 + 真 Chrome + 3 个 CDP 测试 + 3 个回归）
- `/tmp/hermeswin/openclaw_ext/shared/CDP-README.md` —— 使用/排错/降级顺序/真机清单
- `/tmp/hermeswin/_verify/run_ui_autotest.sh` / `run_ui_screenshots.sh` / `run_popup_verify.sh`
- 证据输出：`_verify/node_test_output.txt`、`_verify/autotest_result.jsonl`、`_verify/requests.jsonl`、`_verify/shot_*.png`、`_verify/popup_dom.html`
