/**
 * Takealot 运营助手 - Background Service Worker (Manifest V3)
 * 职责: 本地桥默认地址初始化 + 采集图片批量下载 + CDP 原始 XHR 抓取（可选权限）
 * 说明: 不包含任何模拟兜底；下载/抓取失败只回真实错误与明确原因。
 *
 * 为什么 CDP 抓取必须在这一层：chrome.debugger 只在扩展的后台/扩展页可用，
 * content script 拿不到。所以 floating bar / sidepanel 都走 runtime.sendMessage 到这里。
 */

const DEFAULT_GATEWAY_URL = 'http://127.0.0.1:18790';
const ASSET_ROOT = 'takealot_assets';

// shared/bridge.js（入账通道）+ shared/cdp_capture.js（CDP 抓取）。
// 经典 service worker 用 importScripts；两者都是无副作用定义对象的脚本。
// 用 try 包住：任一个加载失败要在日志里看到真实原因，而不是静默少功能。
try {
  importScripts('/shared/bridge.js', '/shared/cdp_capture.js');
} catch (e) {
  console.error('[Takealot 运营助手] importScripts 失败（桥/CDP 能力将不可用）:', (e && e.message) || e);
}

// Initialize default settings on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['gatewayUrl'], (res) => {
    const patch = {
      autoLockCategory: res.autoLockCategory !== undefined ? res.autoLockCategory : true,
      autoPolishTitle: res.autoPolishTitle !== undefined ? res.autoPolishTitle : true,
      installedAt: new Date().toISOString()
    };
    // 仅在用户未自定义过桥地址时写入默认值，避免覆盖用户改过的端口
    if (!res.gatewayUrl) patch.gatewayUrl = DEFAULT_GATEWAY_URL;
    chrome.storage.local.set(patch);
  });
  console.log('[Takealot 运营助手] Installed successfully with Manifest V3');
});

// Message Routing
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'DOWNLOAD_IMAGES') {
    handleBatchDownload(message.tsin, message.urls)
      .then(res => sendResponse({ ok: res.failed === 0, count: res.downloaded, failed: res.failed, errors: res.errors }))
      .catch(err => sendResponse({ ok: false, error: (err && err.message) || String(err) }));
    return true; // Keep message channel open for async response
  }

  if (message && message.type === 'PING') {
    sendResponse({ ok: true, pong: true, timestamp: Date.now() });
    return false;
  }

  // ---- CDP 抓取（可选 debugger 权限）----

  if (message && message.type === 'CDP_CAPTURE_STATUS') {
    handleCdpStatus()
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, granted: false, error: (err && err.message) || String(err) }));
    return true;
  }

  if (message && message.type === 'CDP_REQUEST_PERMISSION') {
    handleCdpPermissionRequest()
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, granted: false, error: (err && err.message) || String(err) }));
    return true;
  }

  if (message && message.type === 'CDP_CAPTURE_AND_INGEST') {
    handleCdpCapture(message)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({
        ok: false, transport: 'cdp', reason: 'exception',
        detail: (err && err.message) || String(err),
        text: 'CDP 抓取失败（未预期异常）：' + ((err && err.message) || String(err))
      }));
    return true; // 抓取是长任务（最多 timeoutMs），通道必须保持
  }
});

// ------------------------------------------------------------------ CDP 抓取

function cdp() {
  // 直接用全局对象，不做任何"没有就用假的"兜底
  if (typeof OpenClawCdpCapture === 'undefined') {
    return null;
  }
  return OpenClawCdpCapture;
}

async function handleCdpStatus() {
  const mod = cdp();
  if (!mod) return { ok: false, granted: false, error: 'shared/cdp_capture.js 未加载（重新加载扩展后重试）' };
  const perm = await mod.permissionState();
  return {
    ok: true,
    granted: perm.granted === true,
    api: perm.api === true,
    hasDebugger: mod.hasChromeApi(),
    error: perm.error || ''
  };
}

async function handleCdpPermissionRequest() {
  const mod = cdp();
  if (!mod) return { ok: false, granted: false, error: 'shared/cdp_capture.js 未加载（重新加载扩展后重试）' };
  const res = await mod.requestPermission();
  return { ok: res.granted === true, granted: res.granted === true, error: res.error || '' };
}

/**
 * 抓一个商品页的原始 XHR JSON 并交给本地桥落 state/ingest/。
 * params: {url, timeoutMs?, nudge?, ingest?}
 * 返回紧凑摘要（含商品详情原文 + 入账结果），失败带明确 reason/detail。
 */
async function handleCdpCapture(params) {
  const mod = cdp();
  const url = (params && params.url) || '';
  if (!mod) {
    return {
      ok: false, transport: 'cdp', reason: 'no-api',
      detail: 'shared/cdp_capture.js 未加载', target: url,
      text: 'CDP 抓取失败：shared/cdp_capture.js 未加载（到 chrome://extensions 重新加载扩展后再试）'
    };
  }
  const options = {
    timeoutMs: Number(params && params.timeoutMs) > 0 ? Number(params.timeoutMs) : undefined,
    nudge: params && params.nudge !== undefined ? params.nudge : true,
    ingest: params && params.ingest !== undefined ? params.ingest : true,
    source: 'extension:cdp-capture'
  };
  return mod.captureAndIngest(url, options);
}

/**
 * 批量下载图片到 takealot_assets/<tsin>/
 * 返回真实成功数与失败原因，不做静默吞错。
 */
async function handleBatchDownload(tsin, urls) {
  if (!Array.isArray(urls) || urls.length === 0) {
    return { downloaded: 0, failed: 0, errors: ['没有可下载的 URL'] };
  }
  const cleanTsin = String(tsin || 'takealot_item').replace(/[^a-zA-Z0-9_\-]/g, '_');
  let downloaded = 0;
  const errors = [];

  for (let i = 0; i < urls.length; i++) {
    const url = urls[i];
    if (!url) {
      errors.push(`第 ${i + 1} 张: URL 为空`);
      continue;
    }
    let ext = 'jpg';
    try {
      const pathPart = String(url).split('?')[0].split('#')[0];
      const raw = pathPart.split('.').pop().toLowerCase();
      if (/^(jpg|jpeg|png|webp|gif|avif|bmp)$/.test(raw)) ext = raw === 'jpeg' ? 'jpg' : raw;
    } catch (e) {
      ext = 'jpg';
    }
    const filename = `${ASSET_ROOT}/${cleanTsin}/${cleanTsin}_image_${i + 1}.${ext}`;

    try {
      await chrome.downloads.download({
        url: url,
        filename: filename,
        saveAs: false,
        conflictAction: 'overwrite'
      });
      downloaded++;
    } catch (e) {
      const reason = (e && e.message) || String(e);
      errors.push(`第 ${i + 1} 张失败: ${reason}`);
      console.warn(`[Takealot 运营助手] 图片下载失败 ${filename}:`, reason);
    }
  }

  return { downloaded, failed: urls.length - downloaded, errors };
}
