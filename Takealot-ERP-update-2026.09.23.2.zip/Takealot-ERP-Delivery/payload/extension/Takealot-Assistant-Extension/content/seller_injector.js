/**
 * Takealot 运营助手 - 卖家后台注入器
 * Observes navigation and URL changes on seller.takealot.com to mount the copilot drawer
 * Strictly No Emojis, Commercial Standard
 */

(function () {
  function checkAndMount() {
    // Mount if on seller portal
    if (window.location.hostname.includes('seller.takealot.com') || window.location.hostname.includes('127.0.0.1')) {
      OpenClawSellerCopilot.init();
    }
  }

  // Check on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', checkAndMount);
  } else {
    checkAndMount();
  }

  // Also observe SPA route changes in Takealot Seller Portal
  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      setTimeout(checkAndMount, 1000);
    }
  }).observe(document, { subtree: true, childList: true });
})();
