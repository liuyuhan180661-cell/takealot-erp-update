/**
 * Takealot 运营助手 - 买家市场页浮动条 (content/market_floating_bar.js)
 * 注入 takealot.com 商品详情页：抓取商品 -> 存入本地桥的跟卖池；批量下载高清图。
 * 不包含任何模拟兜底：本地桥失败会如实报错（含真实原因）。
 */

(function () {
  // Only execute on product pages
  if (!window.location.pathname.includes('/p/') && !window.location.pathname.includes('/PLID')) {
    return;
  }

  // Prevent multiple injections
  if (document.getElementById('openclaw-market-floating-bar')) return;

  async function initFloatingBar() {
    const product = await TakealotMarketScraper.scrapeProduct();
    // 抓取通道状态（CDP 可选权限）：拿不到就如实写「未知」，不装作已授权
    let cdpStatus = { ok: false, granted: false, error: '尚未检查' };
    if (typeof OpenClawCdpCapture !== 'undefined') {
      try {
        const st = await OpenClawCdpCapture.ask({ type: 'CDP_CAPTURE_STATUS' });
        cdpStatus = st || cdpStatus;
      } catch (e) {
        cdpStatus = { ok: false, granted: false, error: (e && e.message) || String(e) };
      }
    } else {
      cdpStatus = { ok: false, granted: false, error: 'shared/cdp_capture.js 未加载' };
    }

    const bar = document.createElement('div');
    bar.id = 'openclaw-market-floating-bar';
    bar.className = 'openclaw-floating-panel';

    const priceText = product.priceKnown ? `R ${Number(product.buyboxPrice).toFixed(2)}` : '未获取到';
    const offerText = product.competitorCount > 0 ? `${product.competitorCount} 家店铺` : '未获取到';

    bar.innerHTML = `
      <div class="openclaw-bar-header">
        <div class="openclaw-brand-tag">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="4"/><path d="M7 15l3.2-3.2 2.3 2.3L17 9.5"/><path d="M13.5 9.5H17v3.5"/></svg>
          <span>Takealot 运营助手</span>
        </div>
        <button class="openclaw-btn-minimize" id="openclaw-bar-toggle" title="收起/展开">-</button>
      </div>

      <div class="openclaw-bar-body" id="openclaw-bar-body">
        <div class="openclaw-product-summary">
          <div class="openclaw-summary-row">
            <span class="openclaw-label">TSIN / PLID:</span>
            <span class="openclaw-val mono">${escapeText(product.tsin || product.plid || '未识别')}</span>
          </div>
          <div class="openclaw-summary-row">
            <span class="openclaw-label">BuyBox 价格:</span>
            <span class="openclaw-val highlight">${escapeText(priceText)}</span>
          </div>
          <div class="openclaw-summary-row">
            <span class="openclaw-label">提取高清图片:</span>
            <span class="openclaw-val">${product.images.length} 张</span>
          </div>
          <div class="openclaw-summary-row">
            <span class="openclaw-label">在售跟卖数:</span>
            <span class="openclaw-val">${escapeText(offerText)}</span>
          </div>
          <div class="openclaw-summary-row">
            <span class="openclaw-label">抓取通道:</span>
            <span class="openclaw-val" id="openclaw-cdp-state">${escapeText(cdpStatusText())}</span>
          </div>
        </div>

        <div class="openclaw-action-group">
          <!-- Action 1: 存入跟卖池（CDP 优先，失败退页面 DOM/公开接口） -->
          <button class="openclaw-btn openclaw-btn-primary" id="openclaw-btn-collect">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            <span>存入跟卖池</span>
          </button>

          <!-- Action 2: Batch Download High-Res Images -->
          <button class="openclaw-btn openclaw-btn-secondary" id="openclaw-btn-download-images">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <span>打包下载高清图 (${product.images.length})</span>
          </button>

          <!-- Action 3: View Competitors Breakdown -->
          <button class="openclaw-btn openclaw-btn-subtle" id="openclaw-btn-show-competitors">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
            <span>跟卖价格参考</span>
          </button>

          <!-- Action 4: 启用 CDP 抓取（可选权限；最稳的是扩展弹窗里点） -->
          <button class="openclaw-btn openclaw-btn-text" id="openclaw-btn-enable-cdp">
            <span>${cdpStatus.granted ? 'CDP 抓取已授权' : '启用 CDP 抓取（可选权限）'}</span>
          </button>
        </div>

        <div class="openclaw-status-toast" id="openclaw-status-toast" style="display: none;"></div>
      </div>
    `;

    document.body.appendChild(bar);

    function escapeText(v) {
      return String(v === undefined || v === null ? '' : v)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
    }

    function cdpStatusText() {
      if (cdpStatus.granted === true) return 'CDP 已授权（优先抓原始 XHR）';
      return 'DOM / 公开接口（CDP 未授权：' + (cdpStatus.error || '未知原因') + '）';
    }

    // Event Bindings
    const toggleBtn = document.getElementById('openclaw-bar-toggle');
    const bodyEl = document.getElementById('openclaw-bar-body');
    toggleBtn.addEventListener('click', () => {
      const isCollapsed = bodyEl.style.display === 'none';
      bodyEl.style.display = isCollapsed ? 'block' : 'none';
      toggleBtn.innerText = isCollapsed ? '-' : '+';
    });

    const toastEl = document.getElementById('openclaw-status-toast');
    const cdpStateEl = document.getElementById('openclaw-cdp-state');
    function showToast(msg, isSuccess = true) {
      toastEl.innerText = msg;
      toastEl.className = `openclaw-status-toast ${isSuccess ? 'success' : 'warn'}`;
      toastEl.style.display = 'block';
      clearTimeout(showToast._t);
      showToast._t = setTimeout(() => { toastEl.style.display = 'none'; }, 6000);
    }

    // 存入跟卖池：**CDP 优先**（拿浏览器真实发出的原始 XHR JSON，并把它交给桥落进
    // ERP 的 state/ingest/），CDP 不可用/失败时退回页面 DOM + 公开接口，结果里标 transport。
    document.getElementById('openclaw-btn-collect').addEventListener('click', async () => {
      const btn = document.getElementById('openclaw-btn-collect');
      const originalHtml = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = `<span>CDP 抓取中（最多 25s）...</span>`;

      let transport = 'dom';
      let cdpNote = '';
      let cdpRes = null;
      let row = product;
      try {
        if (typeof OpenClawCdpCapture !== 'undefined') {
          cdpRes = await OpenClawCdpCapture.ask({
            type: 'CDP_CAPTURE_AND_INGEST',
            url: window.location.href,
            timeoutMs: 25000
          });
        } else {
          cdpRes = { ok: false, reason: 'no-api', detail: 'shared/cdp_capture.js 未加载' };
        }
      } catch (e) {
        cdpRes = { ok: false, reason: 'exception', detail: (e && e.message) || String(e) };
      }

      if (cdpRes && cdpRes.ok) {
        transport = 'cdp';
        // 用 CDP 抓到的 product-details 原文重建商品行（页面自己的公开 API 被 Cloudflare 挡时也能用）
        if (cdpRes.hasProductDetails && cdpRes.productDetails && typeof TakealotMarketScraper !== 'undefined') {
          try {
            row = TakealotMarketScraper.mapFromApi(cdpRes.productDetails, TakealotMarketScraper.extractPlid(window.location.href), window.location.href);
          } catch (e) {
            cdpNote = `（CDP 原文映射失败，改用页面数据：${(e && e.message) || e}）`;
          }
        }
        cdpNote = `CDP：商品详情${cdpRes.hasProductDetails ? '✓' : '✗'}、报价${cdpRes.hasOtherOffers ? '✓' : '（无 other_offers）'}、评论 ${cdpRes.reviewsCaptured || 0} 页` +
          (cdpRes.ingest && cdpRes.ingest.ok ? `；原始 JSON 已写入 ERP state/ingest/${cdpRes.ingest.file}` : '') + cdpNote;
        if (cdpRes.ingest && !cdpRes.ingest.ok) {
          cdpNote += `；⚠ 原始 JSON 未入账：${cdpRes.ingest.error || '未知原因'}`;
        }
      } else {
        cdpNote = 'CDP 不可用（' + (typeof OpenClawCdpCapture !== 'undefined'
          ? OpenClawCdpCapture.reasonText(cdpRes && cdpRes.reason, cdpRes && cdpRes.detail)
          : ((cdpRes && cdpRes.detail) || '未加载')) + '），已退回页面 DOM/公开接口';
      }
      if (cdpStateEl) cdpStateEl.innerText = 'transport=' + transport + (transport === 'cdp' ? '（CDP 已授权）' : '（CDP 未生效）');

      row = Object.assign({}, row, { transport: transport });
      try {
        const res = await OpenClawBridge.sendToCollection(row);
        if (res.ok) {
          showToast(`已存入跟卖池（transport=${transport}）：${res.id || '已记录'}${res.deduped ? '（重复商品，已去重合并）' : ''} ｜ ${cdpNote}`, true);
        } else {
          showToast(`存入失败（transport=${transport}）：${res.error} ｜ ${cdpNote}`, false);
        }
      } catch (e) {
        showToast(`存入失败（transport=${transport}）：${(e && e.message) || e} ｜ ${cdpNote}`, false);
      } finally {
        btn.disabled = false;
        btn.innerHTML = originalHtml;
      }
    });

    // 启用 CDP 抓取（可选 debugger 权限）。
    // 从页面里请求权限（chrome.permissions.request 需要用户手势）：能成就成，不成如实说明并指向弹窗。
    document.getElementById('openclaw-btn-enable-cdp').addEventListener('click', async () => {
      const btn = document.getElementById('openclaw-btn-enable-cdp');
      btn.disabled = true;
      try {
        const res = typeof OpenClawCdpCapture !== 'undefined'
          ? await OpenClawCdpCapture.ask({ type: 'CDP_REQUEST_PERMISSION' })
          : { ok: false, granted: false, error: 'shared/cdp_capture.js 未加载' };
        if (res && res.granted === true) {
          cdpStatus = { ok: true, granted: true, error: '' };
          btn.innerHTML = '<span>CDP 抓取已授权</span>';
          if (cdpStateEl) cdpStateEl.innerText = cdpStatusText();
          showToast('CDP 抓取已授权：采集时会优先抓原始 XHR JSON 并写入 ERP 的 state/ingest/。', true);
        } else {
          cdpStatus = { ok: false, granted: false, error: (res && res.error) || '未授权' };
          if (cdpStateEl) cdpStateEl.innerText = cdpStatusText();
          showToast(`未能在此处完成授权：${(res && res.error) || '未知原因'}。请在浏览器工具栏点扩展图标 →「启用 CDP 抓取」再点一次。`, false);
        }
      } catch (e) {
        showToast(`启用 CDP 失败：${(e && e.message) || e}`, false);
      } finally {
        btn.disabled = false;
      }
    });

    // Batch Download High-Res Images
    document.getElementById('openclaw-btn-download-images').addEventListener('click', () => {
      if (!product.images || product.images.length === 0) {
        showToast('未检测到有效的高清图片资源', false);
        return;
      }
      const res = OpenClawBridge.downloadImages(product.tsin || product.plid, product.images);
      if (res && res.ok) {
        showToast(`已向后台派发 ${res.count} 张图片下载任务（保存到 takealot_assets/${product.tsin || 'takealot_item'}/）`, true);
      } else {
        showToast(`派发下载失败：${(res && res.error) || '未知原因'}`, false);
      }
    });

    // Competitor reference（只使用页面上真实抓到的数据，缺失即说明缺失）
    document.getElementById('openclaw-btn-show-competitors').addEventListener('click', () => {
      const lines = [];
      lines.push('TSIN: ' + (product.tsin || '未识别'));
      lines.push(product.priceKnown
        ? '当前 BuyBox 价格: R ' + product.buyboxPrice.toFixed(2)
        : '当前 BuyBox 价格: 页面未提供（请不要用猜测值定价）');
      lines.push('在售跟卖数: ' + (product.competitorCount > 0 ? product.competitorCount + ' 家' : '页面未提供'));
      if (Array.isArray(product.competitors) && product.competitors.length > 0) {
        lines.push('');
        lines.push('其他卖家报价:');
        product.competitors.slice(0, 8).forEach(c => {
          lines.push(`- ${c.sellerName}: R ${Number(c.price).toFixed(2)}（${c.fulfillment || '未知' }）`);
        });
      }
      lines.push('');
      lines.push('提示: 跟卖只能调整价格与库存，listing 内容由原商品决定。');
      alert('[跟卖参考] ' + '\n\n' + lines.join('\n'));
    });
  }

  // Delay slightly to ensure Takealot dynamic React components render
  setTimeout(initFloatingBar, 1500);
})();
