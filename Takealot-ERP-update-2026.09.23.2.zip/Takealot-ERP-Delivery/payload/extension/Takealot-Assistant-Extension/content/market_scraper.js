/**
 * Takealot 运营助手 - 买家市场页抓取器 (REST API + DOM 混合)
 * 抓取商品标题 / BuyBox 价格 / 1200px 高清图 / 面包屑类目。
 * 原则: 抓不到就返回空值 + priceKnown=false，绝不填伪造的默认值（旧版的 199 / 4.5 / 样例卖点已删除）。
 */

const TakealotMarketScraper = {
  API_BASE: 'https://api.takealot.com/rest/v-1-12-0',
  IMG_ZOOM_SIZE: 'zoom', // 1200x1200 high-res token

  isProductPage() {
    return window.location.pathname.includes('/p/') ||
           window.location.pathname.includes('/PLID') ||
           document.querySelector('h1') !== null;
  },

  extractPlid(url = window.location.href) {
    const parts = url.split('/');
    for (const part of parts) {
      if (part.startsWith('PLID')) return part;
    }
    const match = url.match(/PLID(\d+)/i);
    return match ? 'PLID' + match[1] : null;
  },

  normalizeImageUrl(url) {
    if (!url || typeof url !== 'string') return url;
    if (url.includes('{size}')) return url.replace('{size}', this.IMG_ZOOM_SIZE);
    return url.replace(/(covers_images\/[a-f0-9]+\/s-)([^./]+)(\.\w+)/i,
      (_m, pre, size, ext) => `${pre}${/^\d+x\d+$/i.test(size) ? this.IMG_ZOOM_SIZE : size}${ext}`);
  },

  toPlid(tsin) {
    if (!tsin) return '';
    return String(tsin).replace(/^TSIN-?/i, 'PLID');
  },

  async scrapeProduct() {
    const url = window.location.href;
    const plid = this.extractPlid(url);

    // Try high-accuracy internal REST API first
    if (plid) {
      try {
        const res = await fetch(`${this.API_BASE}/product-details/${plid}`, {
          headers: {
            'Accept': 'application/json',
            'Accept-Language': 'en-ZA,en;q=0.9'
          }
        });
        if (res.ok) {
          const data = await res.json();
          return this.mapFromApi(data, plid, url);
        }
        console.warn('[Takealot 运营助手] product-details API 返回 HTTP', res.status, '，改用 DOM 抓取');
      } catch (err) {
        console.warn('[Takealot 运营助手] product-details API 不可用，改用 DOM 抓取:', err);
      }
    }

    // DOM Fallback
    return this.scrapeFromDom(url, plid);
  },

  mapFromApi(data, plid, url) {
    const core = data.core || {};
    const buybox = data.buybox || {};
    const title = data.title || core.title || document.title.replace(' | Takealot.com', '').trim();
    const brand = core.brand || data.brand || '';

    // Price（缺失即 0 + priceKnown=false，不假设 199）
    let price = buybox.price;
    if (price === undefined || price === null) {
      if (buybox.pretty_price) {
        price = OpenClawUtils.parseZarPrice(buybox.pretty_price);
      }
    }
    const priceKnown = Number.isFinite(Number(price)) && Number(price) > 0;
    if (!priceKnown) price = 0;

    // High-Res Images (1200x1200px zoom)
    const images = [];
    const rawImages = data.gallery?.images || core.images || data.images || [];
    rawImages.forEach(img => {
      const src = typeof img === 'string' ? img : (img.url || img.uri || img.src);
      if (src && !/logo|icon|avatar|placeholder/i.test(src)) {
        const zoomUrl = this.normalizeImageUrl(src);
        if (!images.includes(zoomUrl)) images.push(zoomUrl);
      }
    });

    if (images.length === 0 && core.image) {
      images.push(this.normalizeImageUrl(core.image));
    }

    // Competitors & Other Offers
    const competitors = [];
    if (Array.isArray(buybox.items)) {
      buybox.items.forEach(item => {
        const sName = item.seller?.name || item.seller_name || '未知卖家';
        const sPrice = item.price || item.offer_detail?.price;
        if (sPrice) {
          competitors.push({
            sellerName: sName,
            price: sPrice,
            fulfillment: item.warehouse ? 'Takealot DC' : 'Leadtime'
          });
        }
      });
    }
    if (data.other_offers?.conditions) {
      data.other_offers.conditions.forEach(cond => {
        if (Array.isArray(cond.items)) {
          cond.items.forEach(it => {
            if (it.price) competitors.push({ sellerName: it.seller?.name || '其他卖家', price: it.price, fulfillment: 'Takealot DC' });
          });
        }
      });
    }

    // Category / Breadcrumbs（无面包屑则留空，不伪造 'General Merchandise'）
    let department = '';
    let category = '';
    if (Array.isArray(data.breadcrumbs) && data.breadcrumbs.length > 0) {
      department = data.breadcrumbs[0].name || '';
      category = data.breadcrumbs.map(b => b.name).filter(Boolean).join(' > ');
    }

    // Reviews & Rating（缺失即 null）
    const rating = data.reviews?.rating ?? core.star_rating ?? null;
    const reviewCount = data.reviews?.total ?? core.review_count ?? null;

    const tsin = data.tsin || (plid ? plid.replace('PLID', 'TSIN-') : '');

    return {
      tsin: tsin,
      plid: plid,
      url: url,
      title: title,
      cleanTitle: OpenClawUtils.formatTakealotTitle(title, brand),
      brand: brand,
      department: department,
      category: category,
      buyboxPrice: price,
      priceKnown: priceKnown,
      images: images,
      competitors: competitors,
      competitorCount: competitors.length,
      rating: rating,
      reviewCount: reviewCount,
      attributes: data.attributes || data.core?.attributes || {},
      bulletPoints: Array.isArray(data.bullet_points) ? data.bullet_points : (Array.isArray(core.bullet_points) ? core.bullet_points : []),
      collectedAt: new Date().toISOString()
    };
  },

  scrapeFromDom(url, plid) {
    const id = plid || null;
    const titleEl = document.querySelector('h1') || document.querySelector('.product-title');
    const rawTitle = titleEl ? titleEl.innerText.trim() : document.title.replace(' | Takealot.com', '').trim();
    const brand = document.querySelector('a[href*="/brand/"]')?.innerText.trim() || '';

    let price = 0;
    const priceEl = document.querySelector('.currency.plus, .pdp-price, .price');
    if (priceEl) price = OpenClawUtils.parseZarPrice(priceEl.innerText);
    const priceKnown = price > 0;

    const images = [];
    document.querySelectorAll('.gallery-thumb img, .image-gallery img').forEach(img => {
      const src = img.getAttribute('data-src') || img.src;
      if (src && !src.includes('data:image')) {
        const norm = this.normalizeImageUrl(src);
        if (!images.includes(norm)) images.push(norm);
      }
    });

    // 面包屑类目（DOM 兜底）
    const crumbs = [];
    document.querySelectorAll('nav[aria-label*="readcrumb" i] a, .breadcrumbs a, ol.breadcrumb a').forEach(a => {
      const t = a.innerText.trim();
      if (t && !crumbs.includes(t)) crumbs.push(t);
    });

    return {
      tsin: id ? id.replace('PLID', 'TSIN-') : '',
      plid: id || '',
      url: url,
      title: rawTitle,
      cleanTitle: OpenClawUtils.formatTakealotTitle(rawTitle, brand),
      brand: brand,
      department: crumbs[0] || '',
      category: crumbs.join(' > '),
      buyboxPrice: price,
      priceKnown: priceKnown,
      images: images,
      competitors: [],
      competitorCount: 0,
      rating: null,
      reviewCount: null,
      attributes: {},
      bulletPoints: [],
      collectedAt: new Date().toISOString()
    };
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = TakealotMarketScraper;
}
if (typeof window !== 'undefined') {
  window.TakealotMarketScraper = TakealotMarketScraper;
}
