/**
 * Takealot 运营助手 - 卖家后台 Listing 副驾驶抽屉 (content/seller_sidepanel.js)
 * 注入 seller.takealot.com，数据来自本地桥 http://127.0.0.1:18790
 *
 * 领域边界（硬约束，UI 必须体现）:
 *   1) 跟卖池 tab（原采集箱）: 商品在平台上已存在 —— 只允许改「价格 / 库存」，
 *      标题 / 图片 / 条码等 listing 内容只读展示，不提供任何内容修改入口。
 *   2) 新建草稿箱 tab（原草稿）: 承载未编辑完的新建 listing，全字段可编辑，
 *      「保存到草稿箱」写草稿箱，「一键回填」写入官方新建商品表单。
 *   3) 两个 tab 数据不混用。唯一转换通道 = POST /collection/promote。
 *
 * 内部 DOM id/class 沿用 openclaw-*（按交付约定不改名，避免大面积回归）。
 */

const OpenClawSellerCopilot = {
  currentTab: 'drafts', // 'drafts' | 'collection'
  drafts: [],
  collectionItems: [],
  selected: { drafts: null, collection: null },
  isCollapsed: false,
  bridgeState: { ok: null, error: '' },
  lastSavedAt: null,
  lastAutofill: null,
  saveInFlight: false,
  isBlankDraft: false,
  attrSync: { running: false, at: '', result: null },   // 官方类目属性模板同步结果
  cdp: { running: false, at: '', granted: false, result: null },  // CDP 原始抓取（可选 debugger 权限）

  draftFieldKeys: [
    'title', 'subtitle', 'features', 'whatsInTheBox', 'brand', 'model',
    'barcode', 'sellingPrice', 'rrp', 'leadTimeDays', 'images', 'category', 'attributes'
  ],

  async init() {
    if (document.getElementById('openclaw-seller-copilot-drawer')) return;
    await this.reloadData();

    if (this.drafts.length > 0 || this.collectionItems.length === 0) {
      this.currentTab = 'drafts';
    } else {
      this.currentTab = 'collection';
    }
    this.selected.drafts = this.drafts[0] || null;
    this.selected.collection = this.collectionItems[0] || null;

    this.renderDrawer();
    this.bindEvents();
  },

  async reloadData() {
    const [colRes, draftRes] = await Promise.all([
      typeof OpenClawBridge !== 'undefined'
        ? OpenClawBridge.getPendingCollection()
        : Promise.resolve({ ok: false, error: 'bridge.js 未加载', items: [], count: 0 }),
      typeof OpenClawBridge !== 'undefined'
        ? OpenClawBridge.getDrafts()
        : Promise.resolve({ ok: false, error: 'bridge.js 未加载', drafts: [], count: 0 })
    ]);

    this.collectionItems = colRes.items || [];
    this.drafts = draftRes.drafts || [];

    const errors = [];
    if (!colRes.ok) errors.push(`跟卖池: ${colRes.error}`);
    if (!draftRes.ok) errors.push(`草稿箱: ${draftRes.error}`);
    this.bridgeState = {
      ok: colRes.ok && draftRes.ok,
      error: errors.join(' ｜ ')
    };
  },

  currentItem() {
    return this.selected[this.currentTab] || null;
  },

  // ------------------------------------------------------------------ render

  renderDrawer() {
    const existing = document.getElementById('openclaw-seller-copilot-drawer');
    if (existing) existing.remove();

    const drawer = document.createElement('div');
    drawer.id = 'openclaw-seller-copilot-drawer';
    drawer.className = 'openclaw-seller-drawer';

    const body = this.currentTab === 'drafts'
      ? this.renderDraftTab()
      : this.renderCollectionTab();

    drawer.innerHTML = `
      <div class="openclaw-drawer-header">
        <div class="openclaw-brand-title">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#1D4ED8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="4"/><path d="M7 15l3.2-3.2 2.3 2.3L17 9.5"/><path d="M13.5 9.5H17v3.5"/></svg>
          <span>Takealot 运营助手 · Listing 副驾驶</span>
        </div>
        <div style="display:flex; align-items:center; gap:6px;">
          <button class="openclaw-btn-icon" id="openclaw-btn-refresh-erp" title="重新拉取本地桥数据">↻</button>
          <button class="openclaw-btn-icon" id="openclaw-drawer-toggle" title="折叠 / 展开">_</button>
        </div>
      </div>

      <div class="openclaw-drawer-body" id="openclaw-drawer-body">
        <div style="display:flex; border-bottom:1px solid #E5E7EB; margin-bottom:12px;">
          <button class="openclaw-tab-btn ${this.currentTab === 'collection' ? 'active' : ''}" id="openclaw-tab-collection"
            style="flex:1; padding:6px 0; background:none; border:none; border-bottom:${this.currentTab === 'collection' ? '2px solid #1D4ED8' : '2px solid transparent'}; font-size:12px; font-weight:${this.currentTab === 'collection' ? '700' : '400'}; color:${this.currentTab === 'collection' ? '#1D4ED8' : '#6B7280'}; cursor:pointer;">
            跟卖池 (${this.collectionItems.length})
          </button>
          <button class="openclaw-tab-btn ${this.currentTab === 'drafts' ? 'active' : ''}" id="openclaw-tab-drafts"
            style="flex:1; padding:6px 0; background:none; border:none; border-bottom:${this.currentTab === 'drafts' ? '2px solid #1D4ED8' : '2px solid transparent'}; font-size:12px; font-weight:${this.currentTab === 'drafts' ? '700' : '400'}; color:${this.currentTab === 'drafts' ? '#1D4ED8' : '#6B7280'}; cursor:pointer;">
            新建草稿箱 (${this.drafts.length})
          </button>
        </div>

        ${this.renderBridgeBanner()}
        ${body}

        <div class="openclaw-status-toast" id="openclaw-seller-toast" style="display: none; margin-top:10px; padding:8px 12px; border-radius:6px; font-size:12px;"></div>
      </div>
    `;

    document.body.appendChild(drawer);
  },

  renderBridgeBanner() {
    if (this.bridgeState.ok) {
      return `<div class="openclaw-note ok">本地桥已连接（127.0.0.1:18790）</div>`;
    }
    return `<div class="openclaw-note error">
      <div>本地桥未就绪，数据可能为空。</div>
      <div style="margin-top:3px; word-break:break-all;">${this.escapeHtml(this.bridgeState.error || '未知错误')}</div>
      <div style="margin-top:3px;">请先启动本地桥，再点右上角 ↻ 重试。</div>
    </div>`;
  },

  // ---- Tab A: 跟卖池（只读内容 + 价格/库存）----

  renderCollectionTab() {
    const items = this.collectionItems;
    const item = this.currentItem() || {};

    if (items.length === 0) {
      return `<div class="openclaw-note">跟卖池为空。请到 Takealot 买家市场页抓取商品后，回到这里刷新。</div>`;
    }

    const images = Array.isArray(item.images) ? item.images.filter(Boolean) : (item.imageUrl ? [item.imageUrl] : []);

    return `
      <div class="openclaw-card-box">
        <div class="openclaw-card-title">
          <span>选定跟卖商品</span>
          <span class="openclaw-badge-ro" style="margin-left:auto;">内容只读</span>
        </div>
        <select class="openclaw-select" id="openclaw-item-select">
          ${items.map(p => `
            <option value="${this.escapeHtml(p.id || '')}" ${item.id === p.id ? 'selected' : ''}>
              [${this.escapeHtml(p.tsin || p.sku || p.id || '')}] ${this.escapeHtml(String(p.title || '未命名').slice(0, 40))}
            </option>
          `).join('')}
        </select>
      </div>

      <div class="openclaw-note">
        该商品在平台上已存在，跟卖只能修改 <b>价格</b> 与 <b>库存</b>。
        标题 / 图片 / 描述等内容由原 listing 决定，本工具不提供任何内容修改入口。
      </div>

      <div class="openclaw-card-box">
        <div class="openclaw-card-title">Listing 内容（只读）</div>
        ${this.roRow('标题', item.title)}
        ${this.roRow('SKU', item.sku, true)}
        ${this.roRow('TSIN', item.tsin, true)}
        ${this.roRow('PLID', item.plid, true)}
        ${this.roRow('条码 Barcode', item.barcode, true)}
        ${this.roRow('来源', item.source, true)}
        ${this.roRow('采集时间', item.savedAt, true)}
        ${item.sourceUrl ? `<div class="openclaw-ro-row"><span class="openclaw-ro-label">原页链接</span>
          <a href="${this.escapeHtml(item.sourceUrl)}" target="_blank" rel="noopener" class="openclaw-ro-value" style="color:#1D4ED8;">打开</a></div>` : ''}
        ${this.renderImageTray(images, true)}
      </div>

      <div class="openclaw-card-box">
        <div class="openclaw-card-title">可修改字段（跟卖）</div>
        <div class="openclaw-form-grid-2">
          <div class="openclaw-form-section">
            <label class="openclaw-section-label">价格 Selling Price (ZAR):</label>
            <input type="number" step="0.01" min="0" class="openclaw-input" id="openclaw-field-price"
              value="${this.escapeHtml(item.price !== undefined && item.price !== null ? item.price : '')}" />
          </div>
          <div class="openclaw-form-section">
            <label class="openclaw-section-label">库存 Stock:</label>
            <input type="number" step="1" min="0" class="openclaw-input" id="openclaw-field-stock"
              value="${this.escapeHtml(item.stock !== undefined && item.stock !== null ? item.stock : '')}" />
          </div>
        </div>
        <button class="openclaw-btn openclaw-btn-primary full-width" id="openclaw-btn-save-collection">
          保存价格与库存（跟卖）
        </button>
        <div class="openclaw-hint">只会向本地桥提交 id / price / stock 三个字段；若后端拒绝其它字段会在这里列出。</div>
      </div>

      <div class="openclaw-card-box">
        <div class="openclaw-card-title">转为新建草稿</div>
        <div class="openclaw-hint" style="margin-bottom:8px;">
          想自己重新刊登（而非跟卖）时，用这个把该采集行转成新建草稿，之后到「新建草稿箱」继续编辑。
        </div>
        <button class="openclaw-btn openclaw-btn-secondary full-width" id="openclaw-btn-promote">
          转为新建草稿（跟卖池 → 草稿箱）
        </button>
      </div>

      ${this.renderCdpCard()}
    `;
  },

  // ---- Tab B: 新建草稿箱（全字段）----

  renderDraftTab() {
    const drafts = this.drafts;
    const d = this.currentItem();
    const item = d || { fields: {} };
    const f = this.draftFields(item);
    const images = Array.isArray(f.images) ? f.images.filter(Boolean) : [];
    const completeness = this.draftCompleteness(item, f);
    const matchedCat = typeof TakealotCategoryRules !== 'undefined' ? TakealotCategoryRules.matchCategory(f.title) : null;
    const attrDefs = matchedCat ? (matchedCat.mandatoryAttributes || []).map(a => typeof a === 'string' ? { name: a, you: true } : a) : [];
    const attrs = f.attributes && typeof f.attributes === 'object' ? f.attributes : {};

    return `
      <div class="openclaw-card-box">
        <div class="openclaw-card-title">
          <span>选定草稿</span>
          <button class="openclaw-btn-text" id="openclaw-btn-new-draft" style="margin-left:auto; font-size:10.5px;">＋ 新建空白草稿</button>
        </div>
        <select class="openclaw-select" id="openclaw-item-select">
          ${drafts.length === 0 ? '<option value="">（草稿箱为空）</option>' : drafts.map(p => `
            <option value="${this.escapeHtml(p.id || '')}" ${item.id === p.id ? 'selected' : ''}>
              ${this.escapeHtml(p.id || '')} · ${this.escapeHtml(String((this.draftFields(p).title) || '未命名').slice(0, 32))} · ${this.draftScoreLabel(p)}
            </option>
          `).join('')}
        </select>
        ${this.lastSavedAt ? `<div class="openclaw-hint">最近一次保存：${this.escapeHtml(this.lastSavedAt)}</div>` : ''}
      </div>

      <div class="openclaw-card-box">
        <div class="openclaw-card-title">
          <span>完整度 ${completeness.score}%</span>
          <span class="openclaw-badge-ro" style="margin-left:auto;">${item.id ? this.escapeHtml(item.id) : '未保存的新草稿'}</span>
        </div>
        ${completeness.missing.length === 0
          ? `<div class="openclaw-hint ok">必填项已齐。</div>`
          : `<div class="openclaw-hint warn"><b>缺项 ${completeness.missing.length} 个：</b>${this.escapeHtml(completeness.missing.join('、'))}</div>`}
      </div>

      <div class="openclaw-form-section">
        <label class="openclaw-section-label">标题 Title (${(f.title || '').length}/75)：</label>
        <input type="text" class="openclaw-input" id="openclaw-field-title" value="${this.escapeHtml(f.title || '')}" />
      </div>

      <div class="openclaw-form-section">
        <label class="openclaw-section-label">副标题 Subtitle (${(f.subtitle || '').length}/110)：</label>
        <input type="text" class="openclaw-input" id="openclaw-field-subtitle" value="${this.escapeHtml(f.subtitle || '')}" />
      </div>

      <div class="openclaw-form-section">
        <label class="openclaw-section-label">卖点 Key Selling Features（≥200 字符）：</label>
        <textarea class="openclaw-input" id="openclaw-field-features" rows="4" style="resize:vertical; font-size:11.5px; height:auto;">${this.escapeHtml(f.features || '')}</textarea>
      </div>

      <div class="openclaw-form-section">
        <label class="openclaw-section-label">包装清单 What's in the Box：</label>
        <textarea class="openclaw-input" id="openclaw-field-box" rows="2" style="resize:vertical; font-size:11.5px; height:auto;">${this.escapeHtml(f.whatsInTheBox || '')}</textarea>
      </div>

      <div class="openclaw-form-grid-2">
        <div class="openclaw-form-section">
          <label class="openclaw-section-label">品牌 Brand：</label>
          <input type="text" class="openclaw-input" id="openclaw-field-brand" value="${this.escapeHtml(f.brand || '')}" />
        </div>
        <div class="openclaw-form-section">
          <label class="openclaw-section-label">型号 Model / MPN：</label>
          <input type="text" class="openclaw-input" id="openclaw-field-model" value="${this.escapeHtml(f.model || '')}" />
        </div>
      </div>

      <div class="openclaw-form-grid-2">
        <div class="openclaw-form-section">
          <label class="openclaw-section-label">售价 Selling Price (ZAR)：</label>
          <input type="number" step="0.01" min="0" class="openclaw-input" id="openclaw-field-price" value="${this.escapeHtml(f.sellingPrice !== undefined && f.sellingPrice !== null ? f.sellingPrice : '')}" />
        </div>
        <div class="openclaw-form-section">
          <label class="openclaw-section-label">建议原价 RRP (ZAR)：</label>
          <input type="number" step="0.01" min="0" class="openclaw-input" id="openclaw-field-rrp" value="${this.escapeHtml(f.rrp !== undefined && f.rrp !== null ? f.rrp : '')}" />
        </div>
      </div>

      <div class="openclaw-form-grid-2">
        <div class="openclaw-form-section">
          <label class="openclaw-section-label">条码 Barcode（选填）：</label>
          <input type="text" class="openclaw-input mono" id="openclaw-field-barcode" placeholder="留空由 Takealot 生成" value="${this.escapeHtml(f.barcode || '')}" />
        </div>
        <div class="openclaw-form-section">
          <label class="openclaw-section-label">备货期 Lead Time：</label>
          <select class="openclaw-select" id="openclaw-field-leadtime">
            ${[2, 3, 5, 7, 10].map(v => `<option value="${v}" ${String(f.leadTimeDays) === String(v) ? 'selected' : ''}>${v} Days</option>`).join('')}
          </select>
        </div>
      </div>

      <div class="openclaw-form-section">
        <label class="openclaw-section-label">主类目 Category（本地桥字段，用于属性匹配）：</label>
        <input type="text" class="openclaw-input" id="openclaw-field-category" value="${this.escapeHtml(f.category || (matchedCat ? matchedCat.category : ''))}" />
      </div>

      <div class="openclaw-card-box">
        <div class="openclaw-card-title">
          <span>类目属性（${matchedCat ? this.escapeHtml(matchedCat.category) : '通用'}）</span>
        </div>
        ${attrDefs.length === 0 ? `<div class="openclaw-hint">先填写标题，系统会匹配类目必填属性。</div>` : attrDefs.map(attr => {
          const name = attr.name;
          const val = attrs[name] !== undefined && attrs[name] !== null ? attrs[name] : '';
          const key = this.attrKey(name);
          const label = `${name}${attr.you ? ' *' : ''}`;
          if (attr.type === 'select' && Array.isArray(attr.options)) {
            return `<div class="openclaw-form-section">
              <label class="openclaw-section-label">${this.escapeHtml(label)}：</label>
              <select class="openclaw-select openclaw-attr-input" data-attr="${this.escapeHtml(name)}" id="openclaw-attr-${key}">
                <option value="">（未选）</option>
                ${attr.options.map(o => `<option value="${this.escapeHtml(o)}" ${String(val) === String(o) ? 'selected' : ''}>${this.escapeHtml(o)}</option>`).join('')}
              </select>
            </div>`;
          }
          return `<div class="openclaw-form-section">
            <label class="openclaw-section-label">${this.escapeHtml(label)}：</label>
            <input type="text" class="openclaw-input openclaw-attr-input" data-attr="${this.escapeHtml(name)}" id="openclaw-attr-${key}" value="${this.escapeHtml(val)}" />
          </div>`;
        }).join('')}
      </div>

      ${this.renderAttrSyncCard()}

      ${this.renderCdpCard()}

      <div class="openclaw-card-box">
        <div class="openclaw-card-title">
          <div style="display:flex; align-items:center; gap:6px;"><span>图片 URL (${images.length})</span></div>
          <button class="openclaw-btn-text" id="openclaw-btn-copy-all-imgs" style="margin-left:auto; font-size:10.5px;">复制全部 URL</button>
        </div>
        ${this.renderImageTray(images, true)}
        <div class="openclaw-form-section" style="margin-top:8px;">
          <textarea class="openclaw-input" id="openclaw-field-images" rows="3" style="resize:vertical; font-size:11px; height:auto;" placeholder="每行一个图片 URL">${this.escapeHtml(images.join('\n'))}</textarea>
        </div>
      </div>

      <div style="margin-top: 14px;">
        <button class="openclaw-btn openclaw-btn-primary full-width" id="openclaw-btn-save-draft">
          保存到草稿箱
        </button>
      </div>

      <div style="margin-top: 8px;">
        <button class="openclaw-btn full-width" id="openclaw-btn-autofill"
          style="background:#1D4ED8; border-color:#1D4ED8; color:#FFF; font-weight:700;">
          一键回填到官方新建 Listing 表单
        </button>
        <button class="openclaw-btn-text" id="openclaw-btn-copy-title" style="width:100%; margin-top:8px; text-align:center; padding:6px 0;">
          手动复制标题（回填失败时用）
        </button>
        <div class="openclaw-hint">
          回填只写官方页面上的表单控件。若当前不在新建 Listing 表单页，或页面结构已变，会明确报错并列出命中的字段名。
        </div>
      </div>
    `;
  },

  /**
   * 官方类目属性模板同步卡片（草稿 tab 内的小区域）。
   * 为什么必须在这里点：官方属性模板只在 seller-api 的 /v1/loadsheets/templates，
   * 要**本页面的登录会话**（JWT 在页面里，扩展之外拿不到；官方 Seller API 没有这个接口）。
   */
  renderAttrSyncCard() {
    const s = this.attrSync || {};
    const result = s.result;
    const okc = result && result.ok === true;
    const line = result
      ? `<div class="openclaw-hint ${okc ? 'ok' : 'warn'}" id="openclaw-attr-sync-result">${
          this.escapeHtml(this.attrSyncText(result))}</div>`
      : `<div class="openclaw-hint" id="openclaw-attr-sync-result">未同步。点一次会把官方全量装载表的属性模板写进 ERP（state/attributes_templates.json），并原样留档一份原始响应（state/attributes_templates_raw.json）。</div>`;
    return `
      <div class="openclaw-card-box">
        <div class="openclaw-card-title">
          <span>官方类目属性模板</span>
          <span class="openclaw-badge-ro" style="margin-left:auto;">${
            s.running ? '同步中…' : (s.at ? this.escapeHtml(s.at) : '未同步')}</span>
        </div>
        <button class="openclaw-btn full-width" id="openclaw-btn-sync-attr-templates" ${s.running ? 'disabled' : ''}>
          ${s.running ? '同步中…（抓官方 + 留档原始响应）' : '同步官方类目属性模板'}
        </button>
        ${line}
        <div class="openclaw-hint">
          必须在<b>已登录的卖家后台页面</b>（seller.takealot.com / sellers.takealot.com）点，扩展用本页会话
          <code>GET /v1/loadsheets/templates</code>。归一化失败时原始响应已留档，可离线照着修。
        </div>
      </div>
    `;
  },

  /** 结果行文案（接受几个装载表 / 总数 / 失败原因）——优先用 template_sync 的统一实现 */
  attrSyncText(result) {
    if (typeof OpenClawTemplateSync !== 'undefined' && OpenClawTemplateSync.describe) {
      return OpenClawTemplateSync.describe(result);
    }
    // 兜底：template_sync.js 没加载时也要说清「接受几个 / 总数 / 失败原因 + 原始件在不在」
    if (!result) return '未同步。';
    if (!result.ok) {
      const stage = { fetch: '抓取官方接口', normalize: '归一化响应', bridge: '写入本地桥' }[result.stage]
        || result.stage || '未知阶段';
      let text = `同步失败（${stage}）：${result.error || '未给出原因'}`;
      if (result.sample) text += ` ｜ 官方返回前 300 字符：${result.sample}`;
      if (result.stage === 'normalize') {
        text += result.rawSaved
          ? ` ｜ 原始响应已存 state/${result.rawFile || 'attributes_templates_raw.json'}（${result.rawBytes} 字节${result.rawTruncated ? '，已截断' : ''}），可离线照着修归一化后再重发。`
          : ` ｜ ⚠ 原始响应留档失败：${result.rawError || '未知原因'}（先让本地桥可写，再点一次）。`;
      }
      return text;
    }
    const st = result.status || {};
    const parts = [
      `已同步 ${result.accepted} 个装载表`,
      `（桥里共 ${result.total} 个` + (result.templatesExpected ? `，本数据包含 ${result.templatesExpected} 个装载表` : '') + '）',
    ];
    if (result.missing && result.missing.length) parts.push(`还缺 ${result.missing.length} 个`);
    else if (result.templatesExpected) parts.push('已齐');
    if (result.skipped && result.skipped.length) parts.push(`跳过 ${result.skipped.length} 个`);
    if (st.effectiveLoadsheets) parts.push(`ERP 侧可用 ${st.effectiveLoadsheets}/${st.templatesExpected || '?'}`);
    if (result.rawSaved) parts.push(`原始响应已留档 state/${result.rawFile || 'attributes_templates_raw.json'}`);
    else if (result.rawError) parts.push(`⚠ 原始响应未留档：${result.rawError}`);
    return parts.join('，') + '。';
  },

  async syncAttributeTemplates() {
    if (this.attrSync && this.attrSync.running) return;
    this.attrSync = Object.assign({}, this.attrSync, { running: true });
    this.repaint();

    let result;
    try {
      if (typeof OpenClawTemplateSync === 'undefined') {
        result = { ok: false, stage: 'bridge',
          error: 'template_sync.js 未加载（请到 chrome://extensions 重新加载扩展后再试）' };
      } else {
        result = await OpenClawTemplateSync.syncAttributeTemplates();
      }
    } catch (e) {
      result = { ok: false, stage: 'sync', error: (e && e.message) || String(e) };
    }

    this.attrSync = { running: false, at: new Date().toLocaleString(), result };
    this.repaint();
    this.showToast(this.attrSyncText(result), result.ok === true);
  },

  /**
   * CDP 抓取卡片（草稿 tab 内，紧邻属性模板卡）。
   * 为什么在这里：debugger 是**可选权限**，未授权时点一次会先请求权限；
   * 抓取本身必须由后台 service worker 执行（chrome.debugger 在 content script 里不存在）。
   * 目标商品 = 当前选中的跟卖池/草稿行（真实 url 优先，只有 TSIN 时按扩展既有口径推导 PLID）。
   */
  renderCdpCard() {
    const s = this.cdp || {};
    const result = s.result;
    const line = result
      ? `<div class="openclaw-hint ${result.ok ? 'ok' : 'warn'}" id="openclaw-cdp-result">${
          this.escapeHtml(this.cdpResultText(result))}</div>`
      : `<div class="openclaw-hint" id="openclaw-cdp-result">未抓取。CDP 抓的是页面自己发出的**原始 XHR JSON**（商品详情 / 评论分页 / other_offers），抓到就原样交给本地桥写进 ERP 的 state/ingest/，后端 crawler 会自动吸收。</div>`;
    return `
      <div class="openclaw-card-box">
        <div class="openclaw-card-title">
          <span>CDP 原始抓取（可授权）</span>
          <span class="openclaw-badge-ro" style="margin-left:auto;">${
            s.running ? '抓取中…' : (s.at ? this.escapeHtml(s.at) : (s.granted ? '已授权' : '未授权'))}</span>
        </div>
        <button class="openclaw-btn full-width" id="openclaw-btn-cdp-capture" ${s.running ? 'disabled' : ''}>
          ${s.running ? '抓取中…（原始 XHR → ERP state/ingest/）' : '用 CDP 抓取当前商品'}
        </button>
        ${line}
        <div class="openclaw-hint">
          <b>降级顺序：CDP → DOM → 公开 API → 明确 blocked</b>（CDP 不装/不授权不阻塞其它两种方式）。
          抓取会在后台标签页里加载该商品页（不打扰当前页）；未授权时先在这里请求一次，若浏览器因缺少
          用户手势拒绝，请到浏览器工具栏点扩展图标 →「启用 CDP 抓取」。
        </div>
      </div>
    `;
  },

  /** CDP 结果文案：优先用 cdp_capture 的统一实现 */
  cdpResultText(result) {
    if (typeof OpenClawCdpCapture !== 'undefined' && OpenClawCdpCapture.describe) {
      return OpenClawCdpCapture.describe(result);
    }
    if (!result) return '未抓取。';
    if (!result.ok) return `CDP 抓取失败：${result.reason || '未给出原因'}（${result.detail || ''}）`;
    return `CDP 抓取成功：${(result.urls || []).length} 个原始响应` +
      (result.ingest && result.ingest.ok ? `，已写 state/ingest/${result.ingest.file}` : '') + '。';
  },

  /** 当前选中行 → 可抓取的商品 URL（拿不到就返回 error，交给 UI 如实显示） */
  cdpTargetUrl() {
    const item = this.currentItem();
    if (!item) return { error: '当前没有选中的商品（先在左侧选一个跟卖池行或草稿）' };
    const raw = item.url || item.sourceUrl || '';
    if (typeof OpenClawCdpCapture !== 'undefined') {
      const direct = OpenClawCdpCapture.isProductUrl(raw) ? raw : '';
      if (direct) return { url: direct, from: 'row.url' };
      const derived = OpenClawCdpCapture.productUrlFor(raw) || OpenClawCdpCapture.plidFromTsin(item.tsin);
      const candidate = OpenClawCdpCapture.isProductUrl(derived)
        ? derived
        : (OpenClawCdpCapture.plidFromTsin(item.tsin) ? 'https://www.takealot.com/p/' + OpenClawCdpCapture.plidFromTsin(item.tsin) : '');
      if (candidate) return { url: candidate, from: 'row.tsin→PLID' };
      return { error: `该行既没有商品 URL 也没有可用 TSIN（tsin=${item.tsin || '空'}），无法定位商品页` };
    }
    return { error: 'shared/cdp_capture.js 未加载（重新加载扩展后再试）' };
  },

  async captureCurrentWithCdp() {
    if (this.cdp && this.cdp.running) return;
    const target = this.cdpTargetUrl();
    this.cdp = Object.assign({}, this.cdp, { running: true, granted: (this.cdp && this.cdp.granted) || false });
    this.repaint();

    let result;
    try {
      if (target.error) {
        result = { ok: false, transport: 'cdp', reason: 'bad-url', detail: target.error, urls: [], kinds: [], reviewPages: [] };
      } else if (typeof OpenClawCdpCapture === 'undefined') {
        result = { ok: false, transport: 'cdp', reason: 'no-api', detail: 'shared/cdp_capture.js 未加载', urls: [], kinds: [], reviewPages: [] };
      } else {
        // 先看权限：未授权就先请求一次（扩展页/手势缺失时如实回错误，再由 UI 引导去 popup）
        const st = await OpenClawCdpCapture.ask({ type: 'CDP_CAPTURE_STATUS' });
        let granted = !!(st && st.granted === true);
        if (!granted) {
          const req = await OpenClawCdpCapture.ask({ type: 'CDP_REQUEST_PERMISSION' });
          granted = !!(req && req.granted === true);
          if (!granted) {
            result = {
              ok: false, transport: 'cdp', reason: 'no-permission',
              detail: ((req && req.error) || (st && st.error) || '未授权') + '（可到扩展弹窗点「启用 CDP 抓取」，或改用页面 DOM/公开接口采集）',
              urls: [], kinds: [], reviewPages: []
            };
          }
        }
        this.cdp = Object.assign({}, this.cdp, { granted: granted });
        if (!result) {
          result = await OpenClawCdpCapture.ask({
            type: 'CDP_CAPTURE_AND_INGEST',
            url: target.url,
            timeoutMs: 25000
          });
          result = Object.assign({ transport: 'cdp', urls: [], kinds: [], reviewPages: [] }, result || { ok: false, reason: 'exception', detail: '后台返回空响应' });
          if (target.from) result.targetFrom = target.from;
        }
      }
    } catch (e) {
      result = { ok: false, transport: 'cdp', reason: 'exception', detail: (e && e.message) || String(e), urls: [], kinds: [], reviewPages: [] };
    }

    this.cdp = {
      running: false,
      at: new Date().toLocaleString(),
      granted: !!(this.cdp && this.cdp.granted),
      result: result
    };
    this.repaint();
    this.showToast(this.cdpResultText(result), result.ok === true);
  },

  renderImageTray(images, readonly) {
    if (!images || images.length === 0) {
      return `<div class="openclaw-hint">无图片（抓取或粘贴图片 URL 后会显示预览）。</div>`;
    }
    return `
      <div class="openclaw-image-tray" style="margin-top:6px;">
        ${images.map((img, i) => `
          <div class="openclaw-img-item ${readonly ? 'readonly' : ''}" title="${this.escapeHtml(img)}">
            <img src="${this.escapeHtml(img)}" alt="">
            <span class="openclaw-img-idx">#${i + 1}</span>
            <div class="openclaw-img-fallback">图片加载失败</div>
          </div>
        `).join('')}
      </div>
    `;
  },

  roRow(label, value, mono) {
    const v = (value === undefined || value === null || value === '') ? '—' : value;
    return `<div class="openclaw-ro-row">
      <span class="openclaw-ro-label">${this.escapeHtml(label)}</span>
      <span class="openclaw-ro-value ${mono ? 'mono' : ''}">${this.escapeHtml(String(v))}</span>
    </div>`;
  },

  attrKey(name) {
    return String(name || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') || 'attr';
  },

  draftFields(draft) {
    const f = (draft && draft.fields) ? draft.fields : {};
    const out = {};
    this.draftFieldKeys.forEach(k => {
      if (f[k] !== undefined) out[k] = f[k];
    });
    // 后端若直接平铺字段而非放在 fields 下，这里兜一层
    if (Object.keys(out).length === 0 && draft) {
      this.draftFieldKeys.forEach(k => {
        if (draft[k] !== undefined) out[k] = draft[k];
      });
    }
    if (!Array.isArray(out.images)) {
      if (typeof out.images === 'string') out.images = out.images.split('\n').map(s => s.trim()).filter(Boolean);
      else out.images = [];
    }
    if (!out.attributes || typeof out.attributes !== 'object') out.attributes = {};
    return out;
  },

  draftCompleteness(draft, fields) {
    if (draft && draft.completeness && typeof draft.completeness.score === 'number') {
      return {
        score: Math.round(draft.completeness.score),
        missing: Array.isArray(draft.completeness.missing) ? draft.completeness.missing : []
      };
    }
    const f = fields || this.draftFields(draft);
    const missing = [];
    if (!f.title) missing.push('标题');
    if (!f.brand) missing.push('品牌');
    if (!f.sellingPrice && f.sellingPrice !== 0) missing.push('售价');
    if (!f.features) missing.push('卖点');
    if (!f.whatsInTheBox) missing.push('包装清单');
    if (!Array.isArray(f.images) || f.images.length === 0) missing.push('图片');
    if (typeof TakealotCategoryRules !== 'undefined') {
      try {
        const v = TakealotCategoryRules.validateListing({
          title: f.title, sellingPrice: f.sellingPrice, images: f.images,
          subtitle: f.subtitle, features: f.features, attributes: f.attributes
        });
        (v.missingFields || []).forEach(m => { if (!missing.includes(m)) missing.push(m); });
      } catch (e) { /* 规则引擎异常不影响保存 */ }
    }
    const total = 8;
    const score = Math.max(0, Math.round(((total - Math.min(missing.length, total)) / total) * 100));
    return { score, missing };
  },

  draftScoreLabel(draft) {
    const c = this.draftCompleteness(draft, this.draftFields(draft));
    return `${c.score}%${c.missing.length ? ' · 缺 ' + c.missing.length : ''}`;
  },

  // ------------------------------------------------------------------ events

  bindEvents() {
    const drawer = document.getElementById('openclaw-seller-copilot-drawer');
    if (!drawer) return;

    // 图片加载失败 -> 本地占位块（不使用任何外部占位图服务）
    drawer.querySelectorAll('.openclaw-img-item img').forEach(img => {
      img.addEventListener('error', () => {
        img.style.display = 'none';
        const fb = img.parentElement ? img.parentElement.querySelector('.openclaw-img-fallback') : null;
        if (fb) fb.style.display = 'flex';
      });
    });

    const toggleBtn = document.getElementById('openclaw-drawer-toggle');
    const bodyEl = document.getElementById('openclaw-drawer-body');
    if (toggleBtn && bodyEl) {
      toggleBtn.addEventListener('click', () => {
        this.isCollapsed = !this.isCollapsed;
        bodyEl.style.display = this.isCollapsed ? 'none' : 'block';
        toggleBtn.innerText = this.isCollapsed ? '+' : '_';
      });
    }

    const refreshBtn = document.getElementById('openclaw-btn-refresh-erp');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', async () => {
        refreshBtn.innerText = '...';
        const keepDraftId = this.selected.drafts ? this.selected.drafts.id : '';
        const keepColId = this.selected.collection ? this.selected.collection.id : '';
        await this.reloadData();
        this.selected.drafts = this.drafts.find(d => d.id === keepDraftId) || this.drafts[0] || null;
        this.selected.collection = this.collectionItems.find(c => c.id === keepColId) || this.collectionItems[0] || null;
        this.isBlankDraft = false;
        this.repaint();
        if (this.bridgeState.ok) this.showToast('已从本地桥重新拉取跟卖池与草稿箱', true);
        else this.showToast(`本地桥刷新失败：${this.bridgeState.error}`, false);
      });
    }

    const tabCollection = document.getElementById('openclaw-tab-collection');
    if (tabCollection) {
      tabCollection.addEventListener('click', () => {
        this.currentTab = 'collection';
        this.repaint();
      });
    }

    const tabDrafts = document.getElementById('openclaw-tab-drafts');
    if (tabDrafts) {
      tabDrafts.addEventListener('click', () => {
        this.currentTab = 'drafts';
        this.repaint();
      });
    }

    const itemSelect = document.getElementById('openclaw-item-select');
    if (itemSelect) {
      itemSelect.addEventListener('change', (e) => {
        const list = this.currentTab === 'drafts' ? this.drafts : this.collectionItems;
        const found = list.find(p => p.id === e.target.value);
        this.isBlankDraft = false;
        this.selected[this.currentTab] = found || null;
        this.repaint();
      });
    }

    const newDraftBtn = document.getElementById('openclaw-btn-new-draft');
    if (newDraftBtn) {
      newDraftBtn.addEventListener('click', () => {
        this.isBlankDraft = true;
        this.selected.drafts = { id: '', fields: {}, completeness: { score: 0, missing: [] } };
        this.repaint();
        this.showToast('已新建空白草稿，填好后点「保存到草稿箱」', true);
      });
    }

    // 跟卖池保存（只提交 price / stock）
    const saveColBtn = document.getElementById('openclaw-btn-save-collection');
    if (saveColBtn) {
      saveColBtn.addEventListener('click', () => this.saveCollection());
    }

    const promoteBtn = document.getElementById('openclaw-btn-promote');
    if (promoteBtn) {
      promoteBtn.addEventListener('click', () => this.promoteSelected());
    }

    // 草稿保存
    const saveDraftBtn = document.getElementById('openclaw-btn-save-draft');
    if (saveDraftBtn) {
      saveDraftBtn.addEventListener('click', () => this.saveCurrentDraft());
    }

    const copyTitleBtn = document.getElementById('openclaw-btn-copy-title');
    if (copyTitleBtn) {
      copyTitleBtn.addEventListener('click', () => {
        const val = (document.getElementById('openclaw-field-title') || {}).value || '';
        if (!val) { this.showToast('标题为空，无可复制内容', false); return; }
        this.copyText(val, '标题已复制到剪贴板');
      });
    }

    const copyImgsBtn = document.getElementById('openclaw-btn-copy-all-imgs');
    if (copyImgsBtn) {
      copyImgsBtn.addEventListener('click', () => {
        const f = this.draftFields(this.currentItem() || {});
        const urls = (f.images || []).join('\n');
        if (!urls) { this.showToast('没有图片 URL 可复制', false); return; }
        this.copyText(urls, `已复制 ${(f.images || []).length} 条图片 URL`);
      });
    }

    const autofillBtn = document.getElementById('openclaw-btn-autofill');
    if (autofillBtn) {
      autofillBtn.addEventListener('click', () => this.executeAutofill());
    }

    // 官方类目属性模板同步（必须在卖家后台页面点，才有会话）
    const attrSyncBtn = document.getElementById('openclaw-btn-sync-attr-templates');
    if (attrSyncBtn) {
      attrSyncBtn.addEventListener('click', () => this.syncAttributeTemplates());
    }

    // CDP 原始抓取（可选 debugger 权限；未授权时先请求一次）
    const cdpBtn = document.getElementById('openclaw-btn-cdp-capture');
    if (cdpBtn) {
      cdpBtn.addEventListener('click', () => this.captureCurrentWithCdp());
    }
  },

  repaint() {
    this.renderDrawer();
    this.bindEvents();
  },

  // ------------------------------------------------------------------ 写入动作

  async saveCollection() {
    const item = this.currentItem();
    if (!item || !item.id) { this.showToast('未选择跟卖商品', false); return; }
    if (this.saveInFlight) return;
    this.saveInFlight = true;
    const priceEl = document.getElementById('openclaw-field-price');
    const stockEl = document.getElementById('openclaw-field-stock');
    const btn = document.getElementById('openclaw-btn-save-collection');
    if (btn) { btn.disabled = true; btn.innerText = '保存中...'; }

    try {
      const res = await OpenClawBridge.updateCollection(item.id, {
        price: priceEl ? priceEl.value : undefined,
        stock: stockEl ? stockEl.value : undefined
      });
      if (res.ok) {
        if (priceEl) item.price = Number(priceEl.value);
        if (stockEl) item.stock = Number(stockEl.value);
        this.showToast('已保存价格与库存（跟卖），listing 内容未改动。', true);
      } else {
        const extra = Array.isArray(res.rejectedFields) && res.rejectedFields.length
          ? ` 后端拒绝字段：${res.rejectedFields.join('、')}` : '';
        this.showToast(`保存失败：${res.error}${extra}`, false);
      }
    } catch (e) {
      this.showToast(`保存失败：${(e && e.message) || e}`, false);
    } finally {
      this.saveInFlight = false;
      if (btn) { btn.disabled = false; btn.innerText = '保存价格与库存（跟卖）'; }
    }
  },

  async promoteSelected() {
    const item = this.currentItem();
    if (!item || !item.id) { this.showToast('未选择跟卖商品', false); return; }
    const btn = document.getElementById('openclaw-btn-promote');
    if (btn) { btn.disabled = true; btn.innerText = '转换中...'; }
    try {
      const res = await OpenClawBridge.promoteToDraft(item.id);
      if (res.ok) {
        const draftsRes = await OpenClawBridge.getDrafts();
        if (draftsRes.ok) this.drafts = draftsRes.drafts;
        const created = draftsRes.ok ? this.drafts.find(d => d.id === res.draftId) : null;
        this.currentTab = 'drafts';
        this.isBlankDraft = false;
        this.selected.drafts = created || res.draft || this.drafts[0] || null;
        this.repaint();
        this.showToast(`已转为新建草稿（${res.draftId || '已创建'}），可在「新建草稿箱」完善后回填。`, true);
      } else {
        this.showToast(`转换失败：${res.error}`, false);
        if (btn) { btn.disabled = false; btn.innerText = '转为新建草稿（跟卖池 → 草稿箱）'; }
      }
    } catch (e) {
      this.showToast(`转换失败：${(e && e.message) || e}`, false);
      if (btn) { btn.disabled = false; btn.innerText = '转为新建草稿（跟卖池 → 草稿箱）'; }
    }
  },

  collectDraftFields() {
    const get = (id) => {
      const el = document.getElementById(id);
      return el ? el.value : '';
    };
    const attrs = {};
    document.querySelectorAll('.openclaw-attr-input').forEach(el => {
      const name = el.getAttribute('data-attr');
      if (name) attrs[name] = el.value;
    });
    const imgText = get('openclaw-field-images');
    const images = String(imgText || '').split('\n').map(s => s.trim()).filter(Boolean);

    return {
      title: get('openclaw-field-title').trim(),
      subtitle: get('openclaw-field-subtitle').trim(),
      features: get('openclaw-field-features'),
      whatsInTheBox: get('openclaw-field-box'),
      brand: get('openclaw-field-brand').trim(),
      model: get('openclaw-field-model').trim(),
      barcode: get('openclaw-field-barcode').trim(),
      sellingPrice: this.numOrNull(get('openclaw-field-price')),
      rrp: this.numOrNull(get('openclaw-field-rrp')),
      leadTimeDays: Number(get('openclaw-field-leadtime')) || 2,
      category: get('openclaw-field-category').trim(),
      images: images,
      attributes: attrs
    };
  },

  numOrNull(v) {
    if (v === '' || v === null || v === undefined) return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  },

  async saveCurrentDraft() {
    if (this.saveInFlight) return;
    const fields = this.collectDraftFields();
    if (!fields.title) { this.showToast('标题为空，无法保存草稿', false); return; }
    this.saveInFlight = true;
    const btn = document.getElementById('openclaw-btn-save-draft');
    if (btn) { btn.disabled = true; btn.innerText = '保存中...'; }

    const current = this.currentItem();
    const id = (current && current.id) ? current.id : '';

    try {
      const res = await OpenClawBridge.saveDraft(id, fields);
      if (res.ok) {
        const saved = res.draft || res;
        const savedId = (saved && saved.id) || res.id || id;
        const draftsRes = await OpenClawBridge.getDrafts();
        if (draftsRes.ok && draftsRes.drafts.length) {
          this.drafts = draftsRes.drafts;
        } else if (savedId) {
          const idx = this.drafts.findIndex(d => d.id === savedId);
          const record = { id: savedId, fields: fields, state: 'draft', source: 'extension' };
          if (idx >= 0) this.drafts[idx] = Object.assign({}, this.drafts[idx], record);
          else this.drafts.push(record);
        }
        this.selected.drafts = this.drafts.find(d => d.id === savedId) || this.drafts[0] || null;
        this.isBlankDraft = false;
        this.lastSavedAt = new Date().toLocaleString();
        const c = this.draftCompleteness(this.selected.drafts, fields);
        this.repaint();
        this.showToast(`已保存到草稿箱（${savedId || '新草稿'}）。完整度 ${c.score}%${c.missing.length ? '，缺：' + c.missing.join('、') : ''}`, true);
      } else {
        this.showToast(`草稿保存失败：${res.error}`, false);
        if (btn) { btn.disabled = false; btn.innerText = '保存到草稿箱'; }
      }
    } catch (e) {
      this.showToast(`草稿保存失败：${(e && e.message) || e}`, false);
      if (btn) { btn.disabled = false; btn.innerText = '保存到草稿箱'; }
    } finally {
      this.saveInFlight = false;
    }
  },

  // ------------------------------------------------------------------ 回填

  /**
   * 探测当前页面是否为官方新建 Listing 表单。
   * 命中信号少于 1 个即判定"不是新建表单 / 结构可能变了"。
   */
  detectFormSignals() {
    const signals = [];
    const probe = (label, selectors) => {
      for (const sel of selectors) {
        if (document.querySelector(sel)) { signals.push(label); return; }
      }
    };
    probe('title', ['input[name*="title" i]', 'input#title', 'input[placeholder*="Title" i]']);
    probe('brand', ['input[name*="brand" i]', 'input#brand', 'input[placeholder*="Brand" i]']);
    probe('price', ['input[name*="price" i]', 'input#selling_price', 'input[placeholder*="Price" i]']);
    probe('barcode', ['input[name*="barcode" i]', 'input#barcode', 'input[name*="gtin" i]']);
    probe('description', ['textarea[name*="description" i]', 'div.ql-editor', 'div[contenteditable="true"]']);
    return signals;
  },

  executeAutofill() {
    const item = this.currentItem() || {};
    const f = this.isBlankDraft && !item.id ? this.collectDraftFields() : this.draftFields(item);
    // 以当前输入框内容为准（用户可能刚改过还没保存）
    const live = this.collectDraftFields();
    if (live.title) Object.assign(f, live);

    const signals = this.detectFormSignals();
    if (signals.length === 0) {
      this.lastAutofill = { hit: [], signals: [] };
      this.showToast('当前页面不是新建 Listing 表单 / 页面结构可能变了（未探测到任何表单字段）。请在官方「Add a Product」页面打开本抽屉，或用下方「手动复制标题」。', false);
      return;
    }

    const filled = [];
    const missed = [];
    const set = (label, el, value) => {
      if (!el) return false;
      if (value === undefined || value === null || value === '') return false;
      OpenClawUtils.simulateInput(el, value);
      filled.push(label);
      return true;
    };

    const mappings = [
      { name: '标题 title', value: f.title, selectors: ['input[name*="title" i]', 'input#title', 'input[placeholder*="Title" i]'] },
      { name: '副标题 subtitle', value: f.subtitle, selectors: ['input[name*="subtitle" i]', 'input#subtitle', 'input[placeholder*="Subtitle" i]'] },
      { name: '卖点 features', value: f.features, selectors: ['textarea[name*="feature" i]', 'textarea#features'] },
      { name: '包装清单 what\'s in the box', value: f.whatsInTheBox, selectors: ['textarea[name*="box" i]', 'textarea#whats_in_the_box', 'textarea[name*="packaging" i]'] },
      { name: '品牌 brand', value: f.brand, selectors: ['input[name*="brand" i]', 'input#brand', 'input[placeholder*="Brand" i]'] },
      { name: '型号 model', value: f.model, selectors: ['input[name*="model" i]', 'input#model', 'input[name*="mpn" i]'] },
      { name: '条码 barcode', value: f.barcode, selectors: ['input[name*="barcode" i]', 'input#barcode', 'input[name*="gtin" i]', 'input[placeholder*="Barcode" i]'] },
      { name: '售价 selling price', value: f.sellingPrice, selectors: ['input[name*="selling_price" i]', 'input#selling_price', 'input[name*="price" i]', 'input[placeholder*="Price" i]'] },
      { name: '原价 rrp', value: f.rrp, selectors: ['input[name*="rrp" i]', 'input#rrp'] },
      { name: '备货期 leadtime', value: f.leadTimeDays, selectors: ['select[name*="leadtime" i]', 'select#leadtime', 'input[name*="leadtime" i]'] }
    ];

    mappings.forEach(m => {
      for (const sel of m.selectors) {
        const el = document.querySelector(sel);
        if (el) {
          if (set(m.name, el, m.value)) { /* hit */ } else { missed.push(m.name); }
          break;
        }
      }
    });

    // 动态类目属性
    const attrs = f.attributes || {};
    Object.keys(attrs).forEach(attrKey => {
      const attrVal = attrs[attrKey];
      if (attrVal === '' || attrVal === undefined || attrVal === null) return;
      const cleanKey = String(attrKey).toLowerCase().replace(/[^a-z0-9]/g, '');
      const attrSelectors = [
        `input[name*="${cleanKey}" i]`,
        `select[name*="${cleanKey}" i]`,
        `input[placeholder*="${attrKey}" i]`,
        `select[data-attribute*="${cleanKey}" i]`
      ];
      for (const sel of attrSelectors) {
        const el = document.querySelector(sel);
        if (el) {
          if (set(`属性 ${attrKey}`, el, attrVal)) { /* hit */ } else { missed.push(`属性 ${attrKey}`); }
          break;
        }
      }
    });

    // 长描述（富文本 / contenteditable）
    const descHtml = f.descriptionHtml || (typeof OpenClawUtils !== 'undefined'
      ? OpenClawUtils.generateCleanDescription(f.title, (f.bulletPoints || []), attrs)
      : '');
    if (descHtml) {
      const descSelectors = ['textarea[name*="description" i]', 'textarea#description', 'div.ql-editor', 'div[contenteditable="true"]'];
      for (const sel of descSelectors) {
        const descEl = document.querySelector(sel);
        if (descEl) {
          if (descEl.isContentEditable) {
            descEl.innerHTML = descHtml;
            descEl.dispatchEvent(new Event('input', { bubbles: true }));
          } else {
            OpenClawUtils.simulateInput(descEl, descHtml);
          }
          filled.push('描述 description');
          break;
        }
      }
    }

    // 图片 URL 输入框
    if (Array.isArray(f.images) && f.images.length > 0) {
      const imgInput = document.querySelector('input[placeholder*="http" i], input[name*="image_url" i], input#imageUrl');
      if (imgInput) set('图片 URL image', imgInput, f.images[0]);
    }

    this.lastAutofill = { hit: filled, signals: signals };

    if (filled.length > 0) {
      const missedNote = missed.length ? ` ｜ 有值但控件为空跳过：${missed.join('、')}` : '';
      this.showToast(`回填完成，命中 ${filled.length} 个字段：${filled.join('、')}。${missedNote}`, true);
    } else {
      this.showToast('回填失败：当前页面不是新建 Listing 表单 / 页面结构可能变了（未命中任何字段）。请确认已在官方「Add a Product」页面，或改用「手动复制标题」。', false);
    }
  },

  copyText(text, okMsg) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(
          () => this.showToast(okMsg, true),
          (e) => this.showToast(`复制失败：${(e && e.message) || e}`, false)
        );
      } else {
        const ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
        this.showToast(okMsg, true);
      }
    } catch (e) {
      this.showToast(`复制失败：${(e && e.message) || e}`, false);
    }
  },

  showToast(msg, isSuccess = true) {
    const toastEl = document.getElementById('openclaw-seller-toast');
    if (!toastEl) return;
    toastEl.innerText = msg;
    toastEl.style.display = 'block';
    toastEl.style.background = isSuccess ? '#ECFDF5' : '#FEF2F2';
    toastEl.style.color = isSuccess ? '#065F46' : '#991B1B';
    toastEl.style.border = `1px solid ${isSuccess ? '#A7F3D0' : '#FECACA'}`;
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => { toastEl.style.display = 'none'; }, 6000);
  },

  escapeHtml(str) {
    if (str === undefined || str === null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = OpenClawSellerCopilot;
}
if (typeof window !== 'undefined') {
  window.OpenClawSellerCopilot = OpenClawSellerCopilot;
}
