<#
  selfcheck.ps1 - post-install acceptance check for the Takealot ERP delivery.

  Prints one line per item, then a single final line:
      RESULT <passed>/<total> PASS      or      RESULT <passed>/<total> FAIL
  Paste that line back to us; the detail lines tell you what to fix.

  It only reads, plus one throwaway write-probe inside the state folder (created
  and deleted immediately, exactly like the plugin's own /diagnostics does).
  It NEVER prints a Seller Key or any other credential - only a mask.

  Usage:
      powershell -NoProfile -ExecutionPolicy Bypass -File selfcheck.ps1
      powershell -NoProfile -ExecutionPolicy Bypass -File selfcheck.ps1 -Root "C:\fake\hermes"
      powershell -NoProfile -ExecutionPolicy Bypass -File selfcheck.ps1 -Root "C:\fake\hermes" -Port 51926

  Params:
      -Root      Hermes home. Default: %LOCALAPPDATA%\hermes
      -ExtDir    Extension folder. Default: <Root>\Takealot-Assistant-Extension
      -Manifest  MANIFEST.md5 to compare against. Default: next to this script.
      -Port      Backend port. Default: read from <Root>\logs\desktop.log,
                 else scan the local listening ports.

  ASCII ONLY ON PURPOSE (PowerShell 5.1 reads .ps1 as ANSI/GBK).
#>
param(
    [string]$Root = "$env:LOCALAPPDATA\hermes",
    [string]$ExtDir = '',
    [string]$Manifest = '',
    [int]$Port = 0
)

$ErrorActionPreference = 'Continue'

# Chinese UI labels, composed from code points so THIS FILE stays pure ASCII.
# (PowerShell 5.1 reads a .ps1 as ANSI/GBK: a literal non-ASCII byte inside a
#  string would break the parser and report an error far from the real line.)
function CN { param([int[]]$CodePoint) -join ($CodePoint | ForEach-Object { [char]$_ }) }
$LBL_STORE_SETTINGS = CN 0x591A, 0x5E97, 0x94FA, 0x8BBE, 0x7F6E          # duo dian pu she zhi
$LBL_SET_ACTIVE     = CN 0x8BBE, 0x4E3A, 0x5F53, 0x524D                  # she wei dang qian
$LBL_ZH_TRANSLATE   = CN 0x4E2D, 0x8BD1                                  # zhong yi
$LBL_AI_COPY        = CN 0x4E0A, 0x67B6, 0x6587, 0x6848                  # shang jia wen an

if (-not $ExtDir) { $ExtDir = Join-Path $Root 'Takealot-Assistant-Extension' }
if (-not $Manifest) { $Manifest = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'MANIFEST.md5' }

$script:Items = @()
function Add-Item {
    param([string]$Label, [bool]$Ok, [string]$Detail, [string]$Advice = '')
    $script:Items += [pscustomobject]@{ Label = $Label; Ok = $Ok; Detail = $Detail; Advice = $Advice }
    if ($Ok) { Write-Host ('  [PASS] ' + $Label) } else { Write-Host ('  [FAIL] ' + $Label) }
    if ($Detail) { Write-Host ('         ' + $Detail) }
    if (-not $Ok -and $Advice) { Write-Host ('         -> ' + $Advice) }
}

function Get-HttpStatus {
    param([string]$Url, [int]$TimeoutMs = 5000)
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Method = 'GET'
        $req.Timeout = $TimeoutMs
        $req.AllowAutoRedirect = $false
        $req.Proxy = $null
        $resp = $req.GetResponse()
        $code = [int]$resp.StatusCode
        $resp.Close()
        return $code
    } catch [System.Net.WebException] {
        if ($_.Exception.Response) { return [int]$_.Exception.Response.StatusCode }
        return -1
    } catch {
        return -1
    }
}

function Test-Port {
    param([string]$Host_, [int]$Port_, [int]$TimeoutMs = 3000)
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $c.BeginConnect($Host_, $Port_, $null, $null)
        if (-not $iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) { return $false }
        $c.EndConnect($iar); return $true
    } catch { return $false } finally { try { $c.Close() } catch { } }
}

# ---------------------------------------------------------------- header
Write-Host ''
Write-Host '====================================================================='
Write-Host ' Takealot ERP - SELF CHECK'
Write-Host '====================================================================='
Write-Host (' Root (Hermes home) : {0}' -f $Root)
Write-Host (' Extension folder   : {0}' -f $ExtDir)
Write-Host (' Manifest           : {0}' -f $Manifest)
Write-Host (' Checked at         : {0}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'))

# ---------------------------------------------------------------- python probe
$stateDir = Join-Path $Root 'plugins\takealot-erp\state'
$venvPy = Join-Path $Root 'hermes-agent\venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $venvPy)) { $venvPy = '' }

# Load <Root>\.env into this process, so the child probes the SAME egress and
# sees the SAME AI key the Hermes backend would. Values are never printed.
$envFile = Join-Path $Root '.env'
$envLoaded = @()
if (Test-Path -LiteralPath $envFile) {
    foreach ($line in [System.IO.File]::ReadAllLines($envFile, [System.Text.Encoding]::UTF8)) {
        $t = $line.Trim()
        if ($t -eq '' -or $t.StartsWith('#')) { continue }
        if ($t -match '^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$') {
            $name = $Matches[1]
            $value = $Matches[2].Trim().Trim('"')
            Set-Item -Path ('Env:' + $name) -Value $value -ErrorAction SilentlyContinue
            $envLoaded += $name
        }
    }
}
Write-Host (' .env variables seen : {0}' -f (($envLoaded | Sort-Object -Unique) -join ', '))
Write-Host ''

$probePy = @'
import base64, json, os, sys, urllib.request

root = sys.argv[1]
out = {}

def state_file(name):
    return os.path.join(root, "plugins", "takealot-erp", "state", name)

# ---- 1. Seller Key: bound? encrypted at rest? masked (never plaintext) -----
stores = []
try:
    with open(state_file("stores.json"), "r", encoding="utf-8") as fh:
        raw = json.load(fh)
    for row in (raw.get("stores") or []):
        val = (row.get("_key") or "").strip()
        at_rest, mask, note = "none", "", ""
        if val:
            if val.startswith("dpapi:"):
                at_rest = "dpapi-ciphertext"
                try:
                    import win32crypt  # noqa
                    blob = base64.b64decode(val[len("dpapi:"):])
                    secret = win32crypt.CryptUnprotectData(blob, None, None, None, 0)[1].decode("utf-8", "replace")
                    mask = "TKL" + "\u2022" * 4 + (secret[-4:] if len(secret) >= 12 else "****")
                    del secret
                except Exception as exc:
                    mask = "(cannot decrypt with this Windows account)"
                    note = type(exc).__name__
            else:
                at_rest = "PLAINTEXT"
                mask = "TKL" + "\u2022" * 4 + (val[-4:] if len(val) >= 12 else "****")
                note = "stored as plaintext on disk"
        stores.append({"id": row.get("id"), "name": row.get("name"),
                       "bound": bool(val), "atRest": at_rest, "mask": mask, "note": note})
    out["activeStoreId"] = raw.get("activeStoreId")
except FileNotFoundError:
    out["storesError"] = "state/stores.json does not exist yet"
except Exception as exc:
    out["storesError"] = type(exc).__name__ + ": " + str(exc)[:200]
out["stores"] = stores

# ---- 2. egress transport ladder (proxy -> direct -> blocked) --------------
def proxy_url():
    env = (os.environ.get("TAKEALOT_API_PROXY") or "").strip()
    if env:
        return env, "env(.env)"
    try:
        with open(state_file("stores.json"), "r", encoding="utf-8") as fh:
            cfg = (json.load(fh).get("crawler") or {})
        val = str(cfg.get("proxy") or "").strip()
        if val:
            return val, "state/stores.json crawler.proxy"
    except Exception:
        pass
    return None, "none"

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126 Safari/537.36")
URL = "https://api.takealot.com/rest/v-1-12-0/product-details/PLID96730174"

def raw_json(url, timeout, proxy):
    handlers = []
    if proxy:
        handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
    opener = urllib.request.build_opener(*handlers)
    req = urllib.request.Request(url, headers={"Accept": "application/json",
                                               "Accept-Language": "en-ZA,en;q=0.9",
                                               "User-Agent": UA})
    try:
        with opener.open(req, timeout=timeout) as resp:
            body = resp.read()
        return json.loads(body.decode("utf-8", "replace")), None
    except Exception as exc:
        return None, type(exc).__name__ + ": " + str(exc)[:160]

proxy, proxy_source = proxy_url()
out["proxyConfigured"] = bool(proxy)
out["proxy"] = proxy or ""
out["proxySource"] = proxy_source
transport, errors = None, []
if proxy:
    data, err = raw_json(URL, 12, proxy)
    if err is None:
        transport = "proxy"
    else:
        errors.append("proxy(" + proxy + ") " + err)
if transport is None:
    data, err = raw_json(URL, 12, None)
    if err is None:
        transport = "direct"
    else:
        errors.append("direct " + err)
out["transport"] = transport or "blocked"
out["transportErrors"] = errors
out["transportUrl"] = URL

# ---- 3. AI / Chinese-translation channel key: present or not (bool only) --
KEY_ENVS = ["ALIBABA_TOKEN_PLAN_CN_API_KEY", "ALIBABA_TOKEN_PLAN_API_KEY",
            "DASHSCOPE_API_KEY", "ALIBABA_CODING_PLAN_CN_API_KEY", "ALIBABA_CODING_PLAN_API_KEY",
            "DEEPSEEK_API_KEY", "AGNES_NEW_KEY", "AGNES_API_KEY", "OPENAI_API_KEY",
            "ANTHROPIC_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY", "XAI_API_KEY",
            "MOONSHOT_API_KEY", "KIMI_API_KEY", "ZAI_API_KEY", "MINIMAX_API_KEY",
            "MINIMAX_CN_API_KEY", "OPENROUTER_API_KEY"]
PROVIDER_KEY_ENV = {
    "alibaba": "DASHSCOPE_API_KEY", "alibaba-cn": "DASHSCOPE_API_KEY",
    "dashscope": "DASHSCOPE_API_KEY", "aliyun": "DASHSCOPE_API_KEY",
    "alibaba-token-plan": "ALIBABA_TOKEN_PLAN_API_KEY",
    "alibaba-token-plan-cn": "ALIBABA_TOKEN_PLAN_CN_API_KEY",
    "alibaba-coding-plan": "ALIBABA_CODING_PLAN_API_KEY",
    "alibaba-coding-plan-cn": "ALIBABA_CODING_PLAN_CN_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY", "agnes": "AGNES_NEW_KEY", "agnes2": "AGNES_NEW_KEY",
}
dotenv = {}
try:
    with open(os.path.join(root, ".env"), "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            t = line.strip()
            if t and not t.startswith("#") and "=" in t:
                k, _, v = t.partition("=")
                dotenv[k.strip()] = v.strip().strip(chr(34)).strip(chr(39))
except Exception:
    pass
cfg_provider = ""
try:
    with open(os.path.join(root, "config.yaml"), "r", encoding="utf-8", errors="replace") as fh:
        in_model = False
        for line in fh:
            if line.startswith("model:"):
                in_model = True
                continue
            if in_model:
                if line.strip() and not line[0].isspace():
                    break
                if ":" in line:
                    k, _, v = line.partition(":")
                    if k.strip() == "provider":
                        cfg_provider = v.strip().strip(chr(34)).strip(chr(39))
                        break
except Exception:
    pass
found = []
for n in KEY_ENVS:
    if (os.environ.get(n) or "").strip() or (dotenv.get(n) or "").strip():
        found.append(n)
wanted = PROVIDER_KEY_ENV.get(cfg_provider.lower(), "")
out["aiKeyPresent"] = bool(found)
out["aiKeysFound"] = found
out["aiProvider"] = cfg_provider
out["aiProviderKeyEnv"] = wanted
out["aiProviderKeyFound"] = bool(wanted and wanted in found)
out["aiKeySource"] = "hermes-home/.env" if dotenv else "process env"
out["win32crypt"] = False
try:
    import win32crypt  # noqa
    out["win32crypt"] = True
except Exception:
    pass
out["python"] = sys.version.split()[0]
print(json.dumps(out, ensure_ascii=True))
'@

$probePath = Join-Path $env:TEMP 'takealot_erp_selfcheck_probe.py'
[System.IO.File]::WriteAllText($probePath, $probePy, (New-Object System.Text.UTF8Encoding($false)))

$probe = $null
$usedPython = ''
foreach ($py in @($venvPy, 'python', 'py')) {
    if ($py -eq '') { continue }
    try {
        $rawOut = (& $py $probePath $Root 2>&1 | Out-String)
        $jsonLine = ($rawOut -split "`r?`n" | Where-Object { $_.Trim().StartsWith('{') } | Select-Object -Last 1)
        if ($jsonLine) {
            $probe = $jsonLine | ConvertFrom-Json
            $usedPython = $py
            break
        }
    } catch { }
}
if ($probe) {
    Write-Host (' Probe interpreter  : {0} (Python {1})' -f $usedPython, $probe.python)
} else {
    Write-Host ' Probe interpreter  : NONE WORKED - the checks that need Python will be reported as failures'
}
Write-Host ''
Write-Host '--- checks -----------------------------------------------------------'

# ---------------------------------------------------------------- 1. backend mounted
$ports = @()
if ($Port -gt 0) { $ports += $Port }
$desktopLog = Join-Path $Root 'logs\desktop.log'
if (Test-Path -LiteralPath $desktopLog) {
    $m = [regex]::Matches(([System.IO.File]::ReadAllText($desktopLog, [System.Text.Encoding]::UTF8)), 'HERMES_BACKEND_READY port=(\d+)')
    if ($m.Count -gt 0) { $ports += [int]$m[$m.Count - 1].Groups[1].Value }
}
$ports = $ports | Select-Object -Unique

$healthPort = 0
$healthCode = -1
if ($ports.Count -eq 0) {
    # last resort: local listening ports owned by a python/hermes/electron process
    $pids = @()
    try {
        $pids = (Get-Process | Where-Object { $_.ProcessName -match 'python|hermes|Hermes|electron' } | Select-Object -ExpandProperty Id)
    } catch { }
    if ($pids.Count -gt 0) {
        $cand = @()
        foreach ($line in (netstat -ano | Select-String -Pattern 'LISTENING' | Select-String -Pattern '127\.0\.0\.1:')) {
            $parts = ($line.ToString() -split '\s+') | Where-Object { $_ }
            if ($parts.Count -ge 5) {
                $lp = $parts[1]
                $op = $parts[4]
                if ($lp -match '127\.0\.0\.1:(\d+)$') {
                    $pnum = [int]$Matches[1]
                    if ($pids -contains [int]$op) { $cand += $pnum }
                }
            }
        }
        $ports = $cand | Select-Object -Unique | Select-Object -First 12
    }
}
foreach ($p in $ports) {
    $code = Get-HttpStatus -Url ('http://127.0.0.1:{0}/api/plugins/takealot-erp/health' -f $p) -TimeoutMs 4000
    if ($code -eq 401 -or $code -eq 200) { $healthPort = $p; $healthCode = $code; break }
}
$mountLine = ''
$guiLog = Join-Path $Root 'logs\gui.log'
if (Test-Path -LiteralPath $guiLog) {
    $mm = [regex]::Matches(([System.IO.File]::ReadAllText($guiLog, [System.Text.Encoding]::UTF8)), '(?m)^(\d{4}-\d{2}-\d{2}[^\r\n]*?)\s.*Mounted plugin API routes: /api/plugins/takealot-erp/')
    if ($mm.Count -gt 0) { $mountLine = $mm[$mm.Count - 1].Value.Trim() }
}
$backendOk = ($healthPort -gt 0) -and ($mountLine -ne '')
$detail = ''
if ($healthPort -gt 0) {
    $detail = ('GET http://127.0.0.1:{0}/api/plugins/takealot-erp/health -> HTTP {1} (a bare 401/200 proves the backend process is up; the plugin name itself is never revealed without a session token)' -f $healthPort, $healthCode)
} else {
    $detail = 'no local backend answered on /api/plugins/takealot-erp/health (tried: ' + (($ports | ForEach-Object { ':' + $_ }) -join ' ') + ')'
}
if ($mountLine) { $detail += ' | gui.log: ' + $mountLine } else { $detail += ' | gui.log: no "Mounted plugin API routes: /api/plugins/takealot-erp/" line found' }
Add-Item 'Backend is mounted (/api/plugins/takealot-erp/health + gui.log mount line)' $backendOk $detail `
    'Start the Hermes desktop app, then check <Root>\logs\gui.log for "Mounted plugin API routes: /api/plugins/takealot-erp/". If it is missing, plugins.enabled in config.yaml does not list takealot-erp, or the backend needs a restart.'

# ---------------------------------------------------------------- 2. hashes
$hashOk = $true
$hashChecked = 0
$hashBad = @()
if (-not (Test-Path -LiteralPath $Manifest)) {
    $hashOk = $false
    $hashBad += ('manifest not found: ' + $Manifest)
} else {
    $extPrefix = 'extension/Takealot-Assistant-Extension/'
    foreach ($line in [System.IO.File]::ReadAllLines($Manifest, [System.Text.Encoding]::UTF8)) {
        if ($line.Trim() -eq '' -or $line.TrimStart().StartsWith('#')) { continue }
        if ($line -notmatch '^([0-9a-fA-F]{32})\s\s(.+)$') { continue }
        $want = $Matches[1].ToLower(); $rel = $Matches[2].Trim(); $target = $null
        if ($rel.StartsWith('hermes-home/')) { $target = Join-Path $Root ($rel.Substring(12) -replace '/', '\') }
        elseif ($rel.StartsWith($extPrefix)) { $target = Join-Path $ExtDir ($rel.Substring($extPrefix.Length) -replace '/', '\') }
        else { continue }
        if (-not (Test-Path -LiteralPath $target)) { $hashOk = $false; $hashBad += ('missing: ' + $rel); continue }
        $got = (Get-FileHash -LiteralPath $target -Algorithm MD5).Hash.ToLower()
        $hashChecked++
        if ($got -ne $want) { $hashOk = $false; $hashBad += ('changed: ' + $rel + ' (want ' + $want + ' got ' + $got + ')') }
    }
}
Add-Item ('Deployed files match MANIFEST.md5 ({0} files compared)' -f $hashChecked) $hashOk `
    ($(if ($hashOk) { 'every shipped file is byte-identical to the package' } else { ($hashBad | Select-Object -First 8) -join ' ; ' })) `
    'Re-run install.ps1 from the package folder. If a file keeps changing, something else is writing to that path.'

# ---------------------------------------------------------------- 3. state writable
$stateOk = $false
$stateDetail = ''
try {
    if (-not (Test-Path -LiteralPath $stateDir)) { New-Item -ItemType Directory -Force -Path $stateDir | Out-Null }
    $probeFile = Join-Path $stateDir '.selfcheck-probe'
    [System.IO.File]::WriteAllText($probeFile, 'ok', (New-Object System.Text.UTF8Encoding($false)))
    Remove-Item -LiteralPath $probeFile -Force
    $stateOk = $true
    $nState = @(Get-ChildItem -LiteralPath $stateDir -Force).Count
    $stateDetail = ('{0} (wrote and deleted a probe file; {1} entries present)' -f $stateDir, $nState)
} catch {
    $stateDetail = ('{0} -> {1}' -f $stateDir, $_.Exception.Message)
}
Add-Item 'state folder is writable' $stateOk $stateDetail `
    'Check folder permissions and free disk space. The backend must run as the SAME Windows user that owns this folder.'

# ---------------------------------------------------------------- 4. seller key
if (-not $probe) {
    Add-Item 'Seller Key is bound (masked - never printed in clear)' $false 'the Python probe did not run, so state/stores.json could not be read safely' 'Install/repair the bundled venv python (see precheck.ps1 check 5).'
} elseif ($probe.storesError) {
    Add-Item 'Seller Key is bound (masked - never printed in clear)' $false $probe.storesError `
        ('Open the Hermes app once so the backend creates its state folder, then enter the Seller Key in ' + $LBL_STORE_SETTINGS + '.')
} else {
    $rows = @($probe.stores)
    $bound = @($rows | Where-Object { $_.bound })
    $plain = @($rows | Where-Object { $_.atRest -eq 'PLAINTEXT' })
    $ok = ($bound.Count -gt 0) -and ($plain.Count -eq 0)
    $bits = @()
    foreach ($r in $rows) {
        $bits += ('{0} [{1}] {2} at-rest={3}{4}' -f ($r.name), ($r.id), ($(if ($r.bound) { $r.mask } else { '(not bound)' })), $r.atRest, $(if ($r.note) { ' - ' + $r.note } else { '' }))
    }
    if ($rows.Count -eq 0) { $bits += 'no store rows at all' }
    $d = ('active=' + $probe.activeStoreId + ' | ' + ($bits -join ' || '))
    $advice = ''
    if ($bound.Count -eq 0) { $advice = ('Enter the Seller X-API-Key in ' + $LBL_STORE_SETTINGS + ', then click ' + $LBL_SET_ACTIVE + ' on that row.') }
    elseif ($plain.Count -gt 0) { $advice = 'RED LINE: a Seller Key is sitting on disk in PLAINTEXT. Restart the backend once - it migrates the key to DPAPI automatically. If it stays plaintext, pywin32 is missing in the venv (see precheck.ps1 check 7).' }
    Add-Item 'Seller Key is bound (masked - never printed in clear)' $ok $d $advice
}

# ---------------------------------------------------------------- 5. egress transport
if (-not $probe) {
    Add-Item 'Egress transport (proxy / direct / blocked)' $false 'the Python probe did not run' 'Repair the bundled venv python first.'
} else {
    $t = [string]$probe.transport
    $ok = ($t -eq 'proxy') -or ($t -eq 'direct')
    $d = ('transport=' + $t + ' | proxy configured=' + $probe.proxyConfigured + ' (source: ' + $probe.proxySource + ')')
    if ($probe.proxyConfigured) { $d += ' value=' + $probe.proxy }
    if ($probe.transportErrors.Count -gt 0) { $d += ' | attempts: ' + ($probe.transportErrors -join ' ; ') }
    $advice = ''
    if ($t -eq 'blocked') { $advice = 'Takealot refused every attempt (usually a Cloudflare 403 on this egress IP). Set TAKEALOT_API_PROXY in <Root>\.env to a working egress proxy, then restart the Hermes app.' }
    elseif ($t -eq 'direct') { $advice = 'Works, but only DIRECT - no proxy is configured. Fine if this ISP egress is accepted, fragile if it is not.' }
    Add-Item 'Egress transport (proxy / direct / blocked)' $ok $d $advice
}

# ---------------------------------------------------------------- 6. bridge
$bridgeUp = Test-Port -Host_ '127.0.0.1' -Port_ 18790 -TimeoutMs 2500
$bridgeDetail = ''
if ($bridgeUp) {
    $code = Get-HttpStatus -Url 'http://127.0.0.1:18790/takealot/api/health' -TimeoutMs 4000
    $bridgeDetail = ('127.0.0.1:18790 is listening; GET /takealot/api/health -> HTTP {0}' -f $code)
    if ($code -eq 200) {
        $body = ''
        try {
            $r = Invoke-WebRequest -Uri 'http://127.0.0.1:18790/takealot/api/health' -TimeoutSec 5 -UseBasicParsing
            $body = ($r.Content -replace '\s+', ' ')
        } catch { }
        if ($body) { $bridgeDetail += ' ' + $body }
    }
} else {
    $bridgeDetail = 'nothing is listening on 127.0.0.1:18790'
}
Add-Item 'Local bridge is running on 18790 (extension data channel)' $bridgeUp $bridgeDetail `
    'Double-click <Root>\plugins\takealot-erp\dashboard\bridge\start_bridge.bat and leave that window open.'

# ---------------------------------------------------------------- 7. extension folder
$extManifest = Join-Path $ExtDir 'manifest.json'
$extOk = $false
$extDetail = ''
if (Test-Path -LiteralPath $extManifest) {
    try {
        $em = [System.IO.File]::ReadAllText($extManifest, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
        $need = @('background\service_worker.js', 'content\seller_sidepanel.js', 'content\seller_injector.js', 'content\market_scraper.js', 'popup\popup.html', 'shared\bridge.js')
        $missing = @()
        foreach ($n in $need) { if (-not (Test-Path -LiteralPath (Join-Path $ExtDir $n))) { $missing += $n } }
        $nFiles = @(Get-ChildItem -LiteralPath $ExtDir -Recurse -File).Count
        $extOk = ($missing.Count -eq 0)
        $extDetail = ('{0} files | manifest name="{1}" v{2} mv{3}' -f $nFiles, $em.name, $em.version, $em.manifest_version)
        if ($missing.Count -gt 0) { $extDetail += ' | MISSING: ' + ($missing -join ', ') }
        $gw = ''
        try { $gw = [string]$em.host_permissions } catch { }
        if ($gw) { $extDetail += ' | host_permissions=' + $gw }
    } catch {
        $extDetail = ('manifest.json could not be parsed: ' + $_.Exception.Message)
    }
} else {
    $extDetail = ('no manifest.json under ' + $ExtDir)
}
Add-Item 'Extension folder is in place' $extOk $extDetail `
    'Re-run install.ps1 (or copy the package''s payload\extension\Takealot-Assistant-Extension\ folder there), then reload it in chrome://extensions. NOTE: "in place" does not mean the browser has it loaded - check chrome://extensions yourself.'

# ---------------------------------------------------------------- 8. data jsons
$dataDir = Join-Path $Root 'plugins\takealot-erp\dashboard\data'
$want = @('takealot-attributes.json', 'takealot-brands.json', 'takealot-categories.json')
$found = @()
$missingData = @()
foreach ($f in $want) {
    $p = Join-Path $dataDir $f
    if (Test-Path -LiteralPath $p) { $found += ('{0} ({1:N0} bytes)' -f $f, (Get-Item -LiteralPath $p).Length) } else { $missingData += $f }
}
$dataOk = ($missingData.Count -eq 0)
Add-Item 'Catalogue data files are present (3 JSON)' $dataOk `
    ($(if ($dataOk) { $found -join ' | ' } else { 'MISSING: ' + ($missingData -join ', ') })) `
    'Re-run install.ps1 - the package carries these under payload\hermes-home\plugins\takealot-erp\dashboard\data\.'

# ---------------------------------------------------------------- 9. AI key
if (-not $probe) {
    Add-Item 'AI / Chinese-translation channel key present (presence only)' $false 'the Python probe did not run; presence was not determined' 'Repair the bundled venv python first.'
} else {
    $aiOk = [bool]$probe.aiKeyPresent
    $provName = [string]$probe.aiProvider
    $provEnv = [string]$probe.aiProviderKeyEnv
    $keysFound = (@($probe.aiKeysFound) -join ', ')
    $aiDetail = if ($aiOk) {
        'present: ' + $keysFound + ' (source: ' + $probe.aiKeySource + ') - values deliberately NOT displayed'
    } else {
        'ABSENT - the ' + $LBL_ZH_TRANSLATE + ' / AI ' + $LBL_AI_COPY + ' features cannot call the model'
    }
    if ($provName) { $aiDetail = 'provider=' + $provName + $(if ($provEnv) { ' (key env: ' + $provEnv + ')' } else { '' }) + ' | ' + $aiDetail }
    Add-Item 'AI / Chinese-translation channel key present (presence only)' $aiOk $aiDetail `
        ('Either set the key in the Hermes app (Providers / API keys - the UI writes it for you), or add ONE line to <Root>\.env: ' + $(if ($provEnv) { $provEnv } else { 'DASHSCOPE_API_KEY / DEEPSEEK_API_KEY' }) + '=<your key>. It is never shipped in the package and never printed here.')
}

# ---------------------------------------------------------------- summary
$passed = @($script:Items | Where-Object { $_.Ok }).Count
$total = $script:Items.Count
$allOk = ($passed -eq $total)

Write-Host ''
Write-Host '====================================================================='
Write-Host ' WHAT EACH ITEM MEANS'
Write-Host '====================================================================='
Write-Host ' - "Backend is mounted" needs BOTH: a live local port answering, and a.'
Write-Host '   gui.log line "Mounted plugin API routes: /api/plugins/takealot-erp/".'
Write-Host '   A bare 401 alone only proves SOME Hermes backend is up (the route is'
Write-Host '   session-token protected and never reveals plugin names), so the log'
Write-Host '   line is what actually names the plugin.'
Write-Host ' - hashes are compared against MANIFEST.md5, which is also the package'
Write-Host '   inventory (payload + extension).'
Write-Host ' - the Seller Key is only ever shown masked; the AI key only as present'
Write-Host '   or absent. No credential is written to disk or to this output.'
Write-Host ''
foreach ($item in ($script:Items | Where-Object { -not $_.Ok })) {
    Write-Host (' FAILED: ' + $item.Label)
    Write-Host ('         ' + $item.Detail)
    if ($item.Advice) { Write-Host ('         -> ' + $item.Advice) }
}
if (-not $allOk) { Write-Host '' }

if ($allOk) {
    Write-Host ('RESULT {0}/{1} PASS' -f $passed, $total)
} else {
    Write-Host ('RESULT {0}/{1} FAIL' -f $passed, $total)
}
Write-Host ''
if ($allOk) { exit 0 } else { exit 1 }
