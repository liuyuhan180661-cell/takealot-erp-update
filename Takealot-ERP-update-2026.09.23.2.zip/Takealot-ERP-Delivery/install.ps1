<#
  install.ps1 - place the Takealot ERP delivery package on this machine.

  Idempotent: re-running it is safe. Anything it overwrites is backed up first.
  It NEVER touches the customer's own data:
      <Root>\plugins\takealot-erp\state\   is preserved as-is (Seller Key, settings,
                                           collection box, crawl cache live there)
  It NEVER writes or prints a Seller Key or any other credential.

  Usage:
      powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1
      powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1 -Root "C:\fake\hermes"
      powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1 -Root "C:\fake\hermes" -ExtDir "C:\fake\ext"

  Params:
      -Root      Hermes home. Default: %LOCALAPPDATA%\hermes
      -ExtDir    Where the unpacked browser extension is placed.
                 Default: <Root>\Takealot-Assistant-Extension
      -Source    The unpacked delivery package root (the folder holding payload\).
                 Default: the folder this script lives in.
      -Proxy     Placeholder value pre-filled into <Root>\.env as TAKEALOT_API_PROXY.
                 Default: http://127.0.0.1:7890  (the customer MUST replace it with
                 their own egress proxy - see INSTALL.md step 4)
      -SkipExtension   Do not touch the extension folder.

  Exit code 0 = installed (all copied files verified against MANIFEST.md5).
  Exit code 1 = something failed; read the printed lines.

  ASCII ONLY ON PURPOSE (PowerShell 5.1 reads .ps1 as ANSI/GBK).
#>
param(
    [string]$Root = "$env:LOCALAPPDATA\hermes",
    [string]$ExtDir = '',
    [string]$Source = '',
    [string]$Proxy = 'http://127.0.0.1:7890',
    [switch]$SkipExtension
)

$ErrorActionPreference = 'Stop'
$script:Problems = @()

# Chinese UI labels, composed from code points so THIS FILE stays pure ASCII.
# (PowerShell 5.1 reads a .ps1 as ANSI/GBK: a literal non-ASCII byte inside a
#  string would break the parser and report an error far from the real line.)
function CN { param([int[]]$CodePoint) -join ($CodePoint | ForEach-Object { [char]$_ }) }
$LBL_STORE_SETTINGS = CN 0x591A, 0x5E97, 0x94FA, 0x8BBE, 0x7F6E          # duo dian pu she zhi
$LBL_SET_ACTIVE     = CN 0x8BBE, 0x4E3A, 0x5F53, 0x524D                  # she wei dang qian
$LBL_TAKEALOT       = CN 0x54, 0x61, 0x6B, 0x65, 0x61, 0x6C, 0x6F, 0x74, 0x20, 0x8FD0, 0x8425
$LBL_ASSISTANT      = CN 0x8FD0, 0x8425, 0x52A9, 0x624B
$LBL_SAVE           = CN 0x4FDD, 0x5B58
$PLUGIN_ID = 'takealot-erp'

if (-not $Source) { $Source = Split-Path -Parent $MyInvocation.MyCommand.Path }
$Source = (Resolve-Path -LiteralPath $Source).Path
$Payload = Join-Path $Source 'payload'
if (-not $ExtDir) { $ExtDir = Join-Path $Root 'Takealot-Assistant-Extension' }

$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$BackupRoot = Join-Path $Root ('backups\takealot-erp-delivery-' + $Stamp)

function Say { param([string]$m) Write-Host $m }
function Step { param([string]$m) Write-Host ''; Write-Host ('--- ' + $m) }
function Ok { param([string]$m) Write-Host ('    OK   ' + $m) }
function Warn { param([string]$m) Write-Host ('    WARN ' + $m) }
function Bad { param([string]$m) Write-Host ('    FAIL ' + $m); $script:Problems += $m }

function Copy-Tree {
    param([string]$From, [string]$To)
    if (-not (Test-Path -LiteralPath $To)) { New-Item -ItemType Directory -Force -Path $To | Out-Null }
    # NOTE: -Path (not -LiteralPath) so the wildcard is expanded.
    Copy-Item -Path (Join-Path $From '*') -Destination $To -Recurse -Force
}

# ---------------------------------------------------------------- banner
Say ''
Say '====================================================================='
Say ' Takealot ERP - INSTALL'
Say '====================================================================='
Say (' Hermes home (Root) : {0}' -f $Root)
Say (' Package source     : {0}' -f $Source)
Say (' Extension folder   : {0}' -f $ExtDir)
Say (' Proxy placeholder  : {0}' -f $Proxy)
Say (' Backup root        : {0}' -f $BackupRoot)

# ---------------------------------------------------------------- 0. sanity
Step '0/8  Checking the package itself'
foreach ($p in @('payload\hermes-home\plugins\takealot-erp\plugin.yaml',
                 'payload\hermes-home\plugins\takealot-erp\dashboard\plugin_api.py',
                 'payload\hermes-home\plugins\takealot-erp\dashboard\crawler.py',
                 'payload\hermes-home\desktop-plugins\takealot-erp\plugin.js',
                 'payload\hermes-home\skills\takealot-erp-operator\SKILL.md',
                 'MANIFEST.md5')) {
    $full = Join-Path $Source $p
    if (Test-Path -LiteralPath $full) { Ok ('found ' + $p) } else { Bad ('missing from the package: ' + $p) }
}
if ($script:Problems.Count -gt 0) {
    Say ''
    Say 'The package is incomplete - aborting before touching anything.'
    Say 'RESULT 0/0 FAIL'
    exit 1
}

# ---------------------------------------------------------------- 1. backups
Step '1/8  Backing up anything with the same name'
$backupPlan = @(
    @{ From = (Join-Path $Root ('plugins\' + $PLUGIN_ID)); Label = 'plugins\takealot-erp' },
    @{ From = (Join-Path $Root ('desktop-plugins\' + $PLUGIN_ID)); Label = 'desktop-plugins\takealot-erp' },
    @{ From = (Join-Path $Root ('skills\' + $PLUGIN_ID + '-operator')); Label = 'skills\takealot-erp-operator' }
)
if (-not $SkipExtension) { $backupPlan += @{ From = $ExtDir; Label = 'extension' } }

$didBackup = $false
foreach ($item in $backupPlan) {
    if (Test-Path -LiteralPath $item.From) {
        if (-not $didBackup) {
            New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null
            $didBackup = $true
        }
        $dest = Join-Path $BackupRoot $item.Label
        $parent = Split-Path -Parent $dest
        if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
        Copy-Item -LiteralPath $item.From -Destination $dest -Recurse -Force
        Ok ('backed up {0} -> {1}' -f $item.From, $dest)
    } else {
        Say ('    ----  no existing {0} (nothing to back up)' -f $item.Label)
    }
}
if ($didBackup) {
    Say ('    Backup root: {0}' -f $BackupRoot)
    Say '    To undo this install: close the Hermes app, delete the new folders, and copy the backups back.'
} else {
    Say '    nothing pre-existing - this looks like a first install'
}

# ---------------------------------------------------------------- 2. backend half
Step '2/8  Backend half  ->  plugins\takealot-erp'
$dstPlugin = Join-Path $Root ('plugins\' + $PLUGIN_ID)
$srcPlugin = Join-Path $Payload ('hermes-home\plugins\' + $PLUGIN_ID)
$stateDir = Join-Path $dstPlugin 'state'
$statePreserved = $false

if (Test-Path -LiteralPath $stateDir) { $statePreserved = $true }

if (Test-Path -LiteralPath $dstPlugin) {
    # Remove the previous deployment so no stale file survives, but NEVER the
    # customer's state\ folder (Seller Key, settings, collection box, cache).
    Get-ChildItem -LiteralPath $dstPlugin -Force | Where-Object { $_.Name -ne 'state' } | ForEach-Object {
        Remove-Item -LiteralPath $_.FullName -Recurse -Force
    }
    Say '    cleared the previous deployment (state\ preserved)'
} else {
    New-Item -ItemType Directory -Force -Path $dstPlugin | Out-Null
}
Copy-Tree -From $srcPlugin -To $dstPlugin
New-Item -ItemType Directory -Force -Path $stateDir | Out-Null
$nFiles = @(Get-ChildItem -LiteralPath $dstPlugin -Recurse -File).Count
Ok ('copied the backend half ({0} files) to {1}' -f $nFiles, $dstPlugin)
if ($statePreserved) {
    Ok ('preserved the existing state\ folder ({0} entries) - your Seller Key and settings are untouched' -f @(Get-ChildItem -LiteralPath $stateDir -Force).Count)
} else {
    Ok 'created an empty state\ folder (it will fill up on first use)'
}

# ---------------------------------------------------------------- 3. UI half
Step '3/8  UI half  ->  desktop-plugins\takealot-erp\plugin.js'
$dstUi = Join-Path $Root ('desktop-plugins\' + $PLUGIN_ID)
New-Item -ItemType Directory -Force -Path $dstUi | Out-Null
$srcUi = Join-Path $Payload ('hermes-home\desktop-plugins\' + $PLUGIN_ID + '\plugin.js')
Copy-Item -LiteralPath $srcUi -Destination (Join-Path $dstUi 'plugin.js') -Force
Ok ('placed plugin.js at ' + (Join-Path $dstUi 'plugin.js'))
Say '    (the desktop app picks this up on its own and hot-reloads on save)'

# ---------------------------------------------------------------- 4. agent half
Step '4/8  Agent half (skills)  ->  skills\*'
$dstSkill = Join-Path $Root ('skills\' + $PLUGIN_ID + '-operator')
New-Item -ItemType Directory -Force -Path $dstSkill | Out-Null
$srcSkill = Join-Path $Payload ('hermes-home\skills\' + $PLUGIN_ID + '-operator\SKILL.md')
Copy-Item -LiteralPath $srcSkill -Destination (Join-Path $dstSkill 'SKILL.md') -Force
Ok ('placed SKILL.md at ' + (Join-Path $dstSkill 'SKILL.md'))
Say '    (this is the USER skills door - the copy inside plugins\takealot-erp\skills\ is NOT auto-loaded)'
# Every EXTRA skill shipped in the payload is installed too (e.g. the model-channel
# setup skill). Without this loop the payload could carry a skill that step 8 then
# reports as an md5 mismatch - shipped but never installed.
$srcSkillsRoot = Join-Path $Payload 'hermes-home\skills'
if (Test-Path -LiteralPath $srcSkillsRoot) {
    foreach ($sd in @(Get-ChildItem -LiteralPath $srcSkillsRoot -Directory)) {
        if ($sd.Name -eq ($PLUGIN_ID + '-operator')) { continue }
        $dstDir = Join-Path $Root ('skills\' + $sd.Name)
        New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
        Copy-Item -Path (Join-Path $sd.FullName '*') -Destination $dstDir -Recurse -Force
        Ok ('placed extra skill: ' + $sd.Name)
    }
}

# ---------------------------------------------------------------- 5. config.yaml
Step '5/8  Enabling the plugin in config.yaml (plugins.enabled)'
$configPath = Join-Path $Root 'config.yaml'
if (-not (Test-Path -LiteralPath $configPath)) {
    # No config yet: write a minimal one, exactly as Hermes itself would.
    $minimal = @()
    $minimal += 'plugins:'
    $minimal += '  enabled:'
    $minimal += ('    - ' + $PLUGIN_ID)
    [System.IO.File]::WriteAllLines($configPath, $minimal, (New-Object System.Text.UTF8Encoding($false)))
    Ok ('no config.yaml existed - created one with plugins.enabled: [' + $PLUGIN_ID + ']')
} else {
    New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null
    Copy-Item -LiteralPath $configPath -Destination (Join-Path $BackupRoot 'config.yaml') -Force
    $bytes = [System.IO.File]::ReadAllBytes($configPath)
    $hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $text = [System.IO.File]::ReadAllText($configPath, [System.Text.Encoding]::UTF8)
    $eol = if ($text -match "`r`n") { "`r`n" } else { "`n" }
    $lines = [System.Collections.Generic.List[string]]::new()
    foreach ($l in ($text -split "`r?`n")) { $lines.Add($l) }
    $hadTrailingNewline = $text.EndsWith("`n")

    $already = $false
    $patched = $false
    $pluginsIdx = -1
    $enabledIdx = -1
    $pluginsIndent = -1

    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^plugins:\s*(#.*)?$') { $pluginsIdx = $i; $pluginsIndent = 0; break }
    }
    if ($pluginsIdx -ge 0) {
        for ($i = $pluginsIdx + 1; $i -lt $lines.Count; $i++) {
            $l = $lines[$i]
            if ($l.Trim() -eq '') { continue }
            if ($l -match '^(\s*)') { $ind = $Matches[1].Length } else { $ind = 0 }
            if ($ind -le $pluginsIndent) { break }          # left the plugins: block
            if ($l -match '^(\s*)enabled\s*:\s*(.*)$') {
                $enabledIdx = $i
                $inline = $Matches[2].Trim()
                if ($inline -ne '' -and $inline -notlike '#*') {
                    # inline form:  enabled: [a, b]   or   enabled: []
                    if ($inline -match '^\[(.*)\]$') {
                        $body = $Matches[1].Trim()
                        $items = @()
                        if ($body -ne '') { $items = $body -split ',' | ForEach-Object { $_.Trim().Trim("'").Trim('"') } | Where-Object { $_ } }
                        if ($items -contains $PLUGIN_ID) {
                            $already = $true
                        } else {
                            $items += $PLUGIN_ID
                            $newLine = ('{0}enabled: [{1}]' -f $Matches[1], ($items -join ', '))
                            $lines[$i] = $newLine
                            $patched = $true
                        }
                    } else {
                        Warn ('plugins.enabled has an unexpected shape on line {0}: "{1}"' -f ($i + 1), $inline)
                        Warn 'not touching it - add this line yourself:  plugins.enabled must contain takealot-erp'
                    }
                } else {
                    # block list form (or empty)
                    $itemIndent = $Matches[1].Length + 2
                    $enabledIndent = $Matches[1].Length
                    $insertAt = $i + 1
                    $lastItem = -1
                    for ($j = $i + 1; $j -lt $lines.Count; $j++) {
                        $lj = $lines[$j]
                        if ($lj.Trim() -eq '') { continue }
                        if ($lj -match '^(\s*)') { $indj = $Matches[1].Length } else { $indj = 0 }
                        if ($indj -le $enabledIndent) { break }
                        if ($lj -match ('^\s*-\s*' + [regex]::Escape($PLUGIN_ID) + '\s*$')) { $already = $true; break }
                        if ($lj -match '^\s*-\s') { $lastItem = $j; $insertAt = $j + 1 }
                    }
                    if (-not $already) {
                        $lines.Insert($insertAt, ('{0}- {1}' -f (' ' * $itemIndent), $PLUGIN_ID))
                        $patched = $true
                    }
                }
                break
            }
        }
        if ($enabledIdx -lt 0) {
            # plugins: exists but has no enabled: key yet
            $lines.Insert($pluginsIdx + 1, '  enabled:')
            $lines.Insert($pluginsIdx + 2, ('    - ' + $PLUGIN_ID))
            $patched = $true
        }
        if ($enabledIdx -lt 0 -and -not $patched) { $enabledIdx = $pluginsIdx }
    } else {
        # no plugins: block at all
        if ($lines.Count -gt 0 -and $lines[$lines.Count - 1].Trim() -ne '') { }
        $lines.Add('plugins:')
        $lines.Add('  enabled:')
        $lines.Add(('    - ' + $PLUGIN_ID))
        $patched = $true
    }

    if ($already) {
        Ok ('plugins.enabled already contains ' + $PLUGIN_ID + ' - left every other entry untouched')
    } elseif ($patched) {
        $out = ($lines -join $eol)
        if ($hadTrailingNewline -or $true) { $out = $out + $eol }
        [System.IO.File]::WriteAllText($configPath, $out, (New-Object System.Text.UTF8Encoding($hasBom)))
        Ok ('added ' + $PLUGIN_ID + ' to plugins.enabled (other entries untouched)')
        Say ('    backup of the previous config.yaml: ' + (Join-Path $BackupRoot 'config.yaml'))
    } else {
        Bad 'could not add takealot-erp to plugins.enabled - edit config.yaml by hand (see INSTALL.md step 3)'
    }
    # prove it reads back
    try {
        $check = [System.IO.File]::ReadAllText($configPath, [System.Text.Encoding]::UTF8)
        $m = [regex]::Matches($check, '(?m)^\s*-?\s*' + [regex]::Escape($PLUGIN_ID) + '\s*$')
        if ($m.Count -gt 0) { Ok 'verified: config.yaml now mentions takealot-erp' } else { Bad 'verification failed - config.yaml does not mention takealot-erp' }
    } catch { Warn ('could not re-read config.yaml: ' + $_.Exception.Message) }
    # Collapse duplicates: an earlier bug (PowerShell reuses $Matches, so the list scan broke on the
    # first item) appended a second entry on every run. Keep the first, drop the rest.
    try {
        $cur = [System.IO.File]::ReadAllLines($configPath, [System.Text.Encoding]::UTF8)
        $kept = New-Object System.Collections.Generic.List[string]
        $seenOne = $false
        $dropped = 0
        foreach ($l in $cur) {
            if ($l -match ('^(\s*)-\s*' + [regex]::Escape($PLUGIN_ID) + '\s*$')) {
                if ($seenOne) { $dropped++ ; continue }
                $seenOne = $true
            }
            $kept.Add($l)
        }
        if ($dropped -gt 0) {
            [System.IO.File]::WriteAllLines($configPath, $kept, (New-Object System.Text.UTF8Encoding($hasBom)))
            Ok ('removed {0} duplicate takealot-erp entr(y/ies) from plugins.enabled' -f $dropped)
        }
        $final = [System.IO.File]::ReadAllText($configPath, [System.Text.Encoding]::UTF8)
        $n = ([regex]::Matches($final, ('(?m)^\s*-\s*' + [regex]::Escape($PLUGIN_ID) + '\s*$'))).Count
        if ($n -eq 1) { Ok 'plugins.enabled lists takealot-erp exactly once' }
        else { Bad ('plugins.enabled lists takealot-erp {0} times (expected exactly 1)' -f $n) }
    } catch { Warn ('could not normalise plugins.enabled: ' + $_.Exception.Message) }
}

# ---------------------------------------------------------------- 6. .env proxy
Step '6/8  Pre-filling the egress proxy placeholder in .env'
$envPath = Join-Path $Root '.env'
if (Test-Path -LiteralPath $envPath) {
    $envText = [System.IO.File]::ReadAllText($envPath, [System.Text.Encoding]::UTF8)
} else {
    $envText = ''
}
$hasProxy = [bool]([regex]::IsMatch($envText, '(?m)^\s*TAKEALOT_API_PROXY\s*='))
if ($hasProxy) {
    $cur = ([regex]::Match($envText, '(?m)^\s*TAKEALOT_API_PROXY\s*=\s*(.*)$')).Groups[1].Value.Trim()
    Ok ('TAKEALOT_API_PROXY is already set to "{0}" - left as-is, NOT overwritten' -f $cur)
} else {
    if ($envText -ne '' -and -not $envText.EndsWith("`n")) { $envText = $envText + "`r`n" }
    $envText = $envText + ('TAKEALOT_API_PROXY=' + $Proxy + "`r`n")
    if (Test-Path -LiteralPath $envPath) { New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null; Copy-Item -LiteralPath $envPath -Destination (Join-Path $BackupRoot '.env') -Force }
    [System.IO.File]::WriteAllText($envPath, $envText, (New-Object System.Text.UTF8Encoding($false)))
    Ok ('wrote TAKEALOT_API_PROXY={0} into {1}' -f $Proxy, $envPath)
    Warn ('"{0}" is a PLACEHOLDER. The customer MUST replace it with their own working egress proxy, then restart the Hermes app. selfcheck.ps1 tells you whether your egress works.' -f $Proxy)
}

# ---------------------------------------------------------------- 7. extension
Step '7/8  Browser extension folder'
if ($SkipExtension) {
    Warn 'skipped (-SkipExtension)'
} else {
    $srcExt = Join-Path $Payload 'extension\Takealot-Assistant-Extension'
    if (-not (Test-Path -LiteralPath $srcExt)) {
        Bad ('extension missing from the package: ' + $srcExt)
    } else {
        New-Item -ItemType Directory -Force -Path $ExtDir | Out-Null
        Copy-Tree -From $srcExt -To $ExtDir
        $nExt = @(Get-ChildItem -LiteralPath $ExtDir -Recurse -File).Count
        Ok ('copied the extension ({0} files) to {1}' -f $nExt, $ExtDir)
        Say '    this is only the FOLDER - the browser still has to load it (manual item 1)'
    }
}

# ---------------------------------------------------------------- 8. verify hashes
Step '8/8  Verifying every copied file against MANIFEST.md5'
$manifestPath = Join-Path $Source 'MANIFEST.md5'
$checked = 0
$mismatch = 0
foreach ($line in ([System.IO.File]::ReadAllLines($manifestPath, [System.Text.Encoding]::UTF8))) {
    if ($line.Trim() -eq '' -or $line.TrimStart().StartsWith('#')) { continue }
    if ($line -notmatch '^([0-9a-fA-F]{32})\s\s(.+)$') { continue }
    $want = $Matches[1].ToLower()
    $rel = $Matches[2].Trim()
    $target = $null
    if ($rel.StartsWith('hermes-home/')) {
        $target = Join-Path $Root ($rel.Substring('hermes-home/'.Length) -replace '/', '\')
    } elseif ($rel.StartsWith('extension/') -and -not $SkipExtension) {
        $sub = $rel.Substring('extension/Takealot-Assistant-Extension/'.Length)
        $target = Join-Path $ExtDir ($sub -replace '/', '\')
    } else { continue }
    if (-not (Test-Path -LiteralPath $target)) { Bad ('missing after copy: ' + $target); $mismatch++; continue }
    $got = (Get-FileHash -LiteralPath $target -Algorithm MD5).Hash.ToLower()
    $checked++
    if ($got -ne $want) { Bad ('md5 mismatch: {0} (want {1} got {2})' -f $target, $want, $got); $mismatch++ }
}
if ($mismatch -eq 0) { Ok ('all {0} shipped files verified (md5 == MANIFEST.md5)' -f $checked) }

# ---------------------------------------------------------------- manual items
Say ''
Say '====================================================================='
Say ' INSTALL DONE.  THREE THINGS STILL NEED A HUMAN.'
Say '====================================================================='
Say ''
Say '  1) LOAD THE EXTENSION (no script can do this)'
Say ('     Open Chrome or Edge -> chrome://extensions (or edge://extensions)')
Say '     -> turn on Developer mode -> Load unpacked -> pick this folder:'
Say ('         ' + $ExtDir)
Say ('     A blue up-arrow icon "' + $LBL_TAKEALOT + ' ' + $LBL_ASSISTANT + '" appears. If you re-run install.ps1')
Say '     later, hit the reload arrow on the extension card afterwards.'
Say ''
Say '  2) ENTER THE SELLER KEY (never shipped in the package, on purpose)'
Say ('     Open the Hermes app -> ' + $LBL_TAKEALOT + ' (the ERP page) -> leave it running once')
Say ('     so the backend creates its state folder -> ' + $LBL_STORE_SETTINGS + ' -> paste the')
Say ('     Seller X-API-Key -> ' + $LBL_SAVE + ' -> then ' + $LBL_SET_ACTIVE + ' on that row.')
Say '     NOTE: issuing a new key in the Takealot seller portal REVOKES the old one.'
Say '     The key is encrypted at rest with Windows DPAPI (needs pywin32 - precheck.ps1'
Say '     tells you whether it is present).'
Say ''
Say '  3) START THE LOCAL BRIDGE (the data channel for the extension)'
Say ('     Double-click: ' + (Join-Path $Root 'plugins\takealot-erp\dashboard\bridge\start_bridge.bat'))
Say '     It must stay open while you use the extension. It serves 127.0.0.1:18790 only.'
Say ''
Say '  Then: the customer replaces the proxy placeholder in .env (step 6 above) with'
Say '  their own working egress, restarts the Hermes app, and runs selfcheck.ps1.'
Say ''
if ($script:Problems.Count -gt 0) {
    Say ('RESULT FAILED - {0} problem(s):' -f $script:Problems.Count)
    foreach ($p in $script:Problems) { Say ('  - ' + $p) }
    Say ''
    exit 1
} else {
    Say 'RESULT 8/8 OK'
    Say ''
    exit 0
}
