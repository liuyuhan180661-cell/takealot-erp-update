<#
  precheck.ps1 - READ-ONLY pre-installation environment check for the
  Takealot ERP delivery package (Hermes desktop host, Windows).

  Nothing is written or changed by this script. It only reads.

  Usage:
      powershell -NoProfile -ExecutionPolicy Bypass -File precheck.ps1
      powershell -NoProfile -ExecutionPolicy Bypass -File precheck.ps1 -Root "C:\path\to\fake\hermes"

  Exit code: 0 if every check passed, 1 if one or more checks failed.
  The final line of output is:  RESULT <passed>/<total>

  ASCII ONLY ON PURPOSE: Windows PowerShell 5.1 reads a .ps1 as ANSI/GBK, so a
  single non-ASCII byte inside a string literal breaks the parser and reports a
  misleading error far from the real line.
#>
param(
    [string]$Root = "$env:LOCALAPPDATA\hermes"
)

$ErrorActionPreference = 'Continue'
$script:Results = @()

function Add-Result {
    param(
        [string]$Id,
        [string]$Label,
        [ValidateSet('PASS','WARN','FAIL','INFO')][string]$Level,
        [string]$Detail
    )
    $script:Results += [pscustomobject]@{ Id = $Id; Label = $Label; Level = $Level; Detail = $Detail }
    Write-Host ("  [{0,-4}] {1}" -f $Level, $Label)
    if ($Detail) { Write-Host ("         {0}" -f $Detail) }
}

function Test-Tcp {
    param([string]$Host_, [int]$Port, [int]$TimeoutMs = 7000)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $client.BeginConnect($Host_, $Port, $null, $null)
        if (-not $iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) { return $false }
        $client.EndConnect($iar)
        return $true
    } catch {
        return $false
    } finally {
        try { $client.Close() } catch { }
    }
}

function Get-EgressIp {
    foreach ($url in @('https://ifconfig.me/ip', 'https://ip.sb', 'https://ipinfo.io/ip')) {
        try {
            $resp = Invoke-WebRequest -Uri $url -TimeoutSec 8 -UseBasicParsing
            $text = ($resp.Content -replace '\s+', ' ').Trim()
            if ($text) { return @{ Ok = $true; Ip = $text; Source = $url } }
        } catch { }
    }
    return @{ Ok = $false; Ip = ''; Source = '' }
}

Write-Host ''
Write-Host '====================================================================='
Write-Host ' Takealot ERP - PRE-INSTALL ENVIRONMENT CHECK (read-only)'
Write-Host '====================================================================='
Write-Host (" Root (Hermes home) : {0}" -f $Root)
Write-Host (" Checked at         : {0}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'))
Write-Host (" Checked by         : {0}" -f "$env:USERDOMAIN\$env:USERNAME")
Write-Host ''

# ---------------------------------------------------------------- 1. OS
Write-Host '[1/12] Operating system and architecture'
try {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    $arch = $os.OSArchitecture
    $ver = "{0} (build {1})" -f $os.Caption, $os.BuildNumber
    $is64 = [Environment]::Is64BitOperatingSystem
    if ($is64) {
        Add-Result 'os' 'Windows version and architecture' 'PASS' ("{0} / {1} / 64-bit process capable" -f $ver, $arch)
    } else {
        Add-Result 'os' 'Windows version and architecture' 'FAIL' ("{0} / {1} - Hermes needs 64-bit Windows" -f $ver, $arch)
    }
} catch {
    Add-Result 'os' 'Windows version and architecture' 'FAIL' ("could not query OS: {0}" -f $_.Exception.Message)
}

# ---------------------------------------------------------------- 2. PowerShell
Write-Host ''
Write-Host '[2/12] PowerShell version'
$psv = $PSVersionTable.PSVersion
if ($psv.Major -ge 5) {
    Add-Result 'powershell' 'PowerShell version' 'PASS' ("{0} ({1})" -f $psv.ToString(), $PSVersionTable.PSEdition)
} else {
    Add-Result 'powershell' 'PowerShell version' 'FAIL' ("{0} - the delivery scripts need PowerShell 5.1 or newer" -f $psv.ToString())
}

# ---------------------------------------------------------------- 3. Hermes home
Write-Host ''
Write-Host '[3/12] Hermes installation directory'
if (Test-Path -LiteralPath $Root) {
    Add-Result 'hermes_home' 'Hermes home directory exists' 'PASS' $Root
} else {
    Add-Result 'hermes_home' 'Hermes home directory exists' 'FAIL' ("not found: {0} - install the Hermes desktop app first" -f $Root)
}
$agentDir = Join-Path $Root 'hermes-agent'
if (Test-Path -LiteralPath $agentDir) {
    Add-Result 'hermes_agent' 'Hermes source tree (hermes-agent)' 'PASS' $agentDir
} else {
    Add-Result 'hermes_agent' 'Hermes source tree (hermes-agent)' 'FAIL' ("not found: {0} - the desktop app is not installed (or -Root points at the wrong place)" -f $agentDir)
}

# ---------------------------------------------------------------- 4. Hermes version
Write-Host ''
Write-Host '[4/12] Hermes version'
$hermesExe = Join-Path $Root 'bin\hermes.exe'
if (-not (Test-Path -LiteralPath $hermesExe)) { $hermesExe = Join-Path $Root 'hermes-agent\venv\Scripts\hermes.exe' }
if (Test-Path -LiteralPath $hermesExe) {
    try {
        $verText = (& $hermesExe --version 2>&1 | Out-String).Trim()
        $first = ($verText -split "`r?`n")[0]
        Add-Result 'hermes_version' 'Hermes CLI reports a version' 'PASS' ("{0} -> {1}" -f $hermesExe, $first)
    } catch {
        Add-Result 'hermes_version' 'Hermes CLI reports a version' 'WARN' ("found {0} but --version failed: {1}" -f $hermesExe, $_.Exception.Message)
    }
} else {
    Add-Result 'hermes_version' 'Hermes CLI reports a version' 'WARN' ("no hermes.exe under {0} - cannot read the version (not fatal for the plugin itself)" -f $Root)
}

# ---------------------------------------------------------------- 5. venv python
Write-Host ''
Write-Host '[5/12] Bundled Python (hermes-agent venv)'
$venvPy = Join-Path $Root 'hermes-agent\venv\Scripts\python.exe'
$script:VenvOk = $false
if (Test-Path -LiteralPath $venvPy) {
    try {
        $pyVer = (& $venvPy -c "import sys;print(sys.version.split()[0])" 2>&1 | Out-String).Trim()
        Add-Result 'venv_python' 'Bundled venv python runs' 'PASS' ("{0} -> Python {1}" -f $venvPy, $pyVer)
        $script:VenvOk = $true
    } catch {
        Add-Result 'venv_python' 'Bundled venv python runs' 'FAIL' ("{0} exists but does not run: {1}" -f $venvPy, $_.Exception.Message)
    }
} else {
    Add-Result 'venv_python' 'Bundled venv python runs' 'FAIL' ("not found: {0} - the plugin backend cannot be served" -f $venvPy)
}

# ---------------------------------------------------------------- 6. fastapi
Write-Host ''
Write-Host '[6/12] Backend dependency: fastapi'
if ($script:VenvOk) {
    try {
        $fa = (& $venvPy -c "import fastapi,starlette;print('fastapi '+fastapi.__version__)" 2>&1 | Out-String).Trim()
        if ($LASTEXITCODE -eq 0 -and $fa -match 'fastapi') {
            Add-Result 'fastapi' 'fastapi importable in the venv' 'PASS' $fa
        } else {
            Add-Result 'fastapi' 'fastapi importable in the venv' 'FAIL' ("import failed: {0}" -f $fa)
        }
    } catch {
        Add-Result 'fastapi' 'fastapi importable in the venv' 'FAIL' $_.Exception.Message
    }
} else {
    Add-Result 'fastapi' 'fastapi importable in the venv' 'FAIL' 'skipped: no working venv python (see check 5)'
}

# ---------------------------------------------------------------- 7. pywin32 (RED LINE)
Write-Host ''
Write-Host '[7/12] RED LINE - pywin32 (win32crypt) for encrypted Seller Key storage'
if ($script:VenvOk) {
    try {
        $wc = (& $venvPy -c "import win32crypt;print('win32crypt OK')" 2>&1 | Out-String).Trim()
        if ($LASTEXITCODE -eq 0 -and $wc -match 'win32crypt OK') {
            Add-Result 'win32crypt' 'pywin32 (win32crypt) available' 'PASS' ("{0} - Seller Key is encrypted at rest with Windows DPAPI (current user only)" -f $wc)
        } else {
            Add-Result 'win32crypt' 'pywin32 (win32crypt) available' 'FAIL' ("MISSING - {0}. Without it the Seller Key would be written to state\stores.json AS PLAINTEXT. Fix: {1} -m pip install pywin32" -f $wc, $venvPy)
        }
    } catch {
        Add-Result 'win32crypt' 'pywin32 (win32crypt) available' 'FAIL' ("MISSING ({0}) - the Seller Key would be stored as plaintext" -f $_.Exception.Message)
    }
} else {
    Add-Result 'win32crypt' 'pywin32 (win32crypt) available' 'FAIL' 'skipped: no working venv python (see check 5) - treat as MISSING until proven otherwise'
}

# ---------------------------------------------------------------- 8. port 18790
Write-Host ''
Write-Host '[8/12] Local bridge port 18790'
$owner = $null
try {
    $conns = Get-NetTCPConnection -LocalPort 18790 -State Listen -ErrorAction Stop
    if ($conns) { $owner = ($conns | Select-Object -First 1).OwningProcess }
} catch { }
if ($null -eq $owner) {
    $net = (netstat -ano | Select-String -Pattern 'LISTENING' | Select-String -Pattern ':18790\s')
    if ($net) { $owner = (($net[0].ToString() -split '\s+') | Where-Object { $_ } | Select-Object -Last 1) }
}
if ($null -eq $owner) {
    Add-Result 'port_18790' 'Port 18790 is free for the local bridge' 'PASS' 'nothing is listening on 127.0.0.1:18790'
} else {
    $pname = ''
    try { $pname = (Get-Process -Id ([int]$owner) -ErrorAction Stop).ProcessName } catch { $pname = 'unknown' }
    Add-Result 'port_18790' 'Port 18790 is free for the local bridge' 'FAIL' ("already in use by PID {0} ({1}) - free it, or start the bridge with a different --port and change the extension's gatewayUrl" -f $owner, $pname)
}

# ---------------------------------------------------------------- 9. browser
Write-Host ''
Write-Host '[9/12] Chrome or Edge (required to load the unpacked extension)'
$browsers = @()
foreach ($pair in @(
        @('Chrome', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe'),
        @('Chrome', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe'),
        @('Edge', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe'),
        @('Edge', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe'))) {
    try {
        $p = (Get-ItemProperty -Path $pair[1] -ErrorAction Stop).'(default)'
        if ($p -and (Test-Path -LiteralPath $p)) { $browsers += ("{0} ({1})" -f $pair[0], $p) }
    } catch { }
}
foreach ($guess in @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe")) {
    if (Test-Path -LiteralPath $guess) {
        $tag = if ($guess -match 'msedge') { 'Edge' } else { 'Chrome' }
        $browsers += ("{0} ({1})" -f $tag, $guess)
    }
}
$browsers = $browsers | Sort-Object -Unique
if ($browsers.Count -gt 0) {
    Add-Result 'browser' 'Chrome or Edge detected' 'PASS' (($browsers | Select-Object -First 3) -join ' | ')
} else {
    Add-Result 'browser' 'Chrome or Edge detected' 'FAIL' 'neither Chrome nor Edge found - the extension cannot be loaded without one of them'
}

# ---------------------------------------------------------------- 10. connectivity
Write-Host ''
Write-Host '[10/12] Network reachability and egress IP'
$targets = @(
    @('portal.nousresearch.com', 443, 'Nous Portal (subscription / model access)'),
    @('seller-api.takealot.com', 443, 'Takealot Seller API (order/stock writes)'),
    @('api.takealot.com', 443, 'Takealot public API (crawl/valuation)')
)
foreach ($t in $targets) {
    $h = $t[0]; $p = $t[1]; $label = $t[2]
    if (Test-Tcp -Host_ $h -Port $p) {
        $httpNote = ''
        try {
            $r = Invoke-WebRequest -Uri ("https://{0}/" -f $h) -TimeoutSec 10 -UseBasicParsing -ErrorAction Stop
            $httpNote = ("HTTP {0}" -f [int]$r.StatusCode)
        } catch {
            $code = $null
            try { $code = [int]$_.Exception.Response.StatusCode } catch { }
            if ($code) { $httpNote = ("HTTP {0} (any HTTP answer means reachable; 401/403 is normal without credentials)" -f $code) }
            else { $httpNote = ("TCP only - HTTP probe said: {0}" -f $_.Exception.Message) }
        }
        Add-Result ("net_" + $h) ("Reachable: {0} ({1})" -f $h, $label) 'PASS' ("TCP 443 connected; {0}" -f $httpNote)
    } else {
        Add-Result ("net_" + $h) ("Reachable: {0} ({1})" -f $h, $label) 'FAIL' 'TCP 443 did not connect within 7s (DNS failure, firewall, or wrong egress)'
    }
}
$ip = Get-EgressIp
if ($ip.Ok) {
    Add-Result 'egress_ip' 'Current public egress IP' 'PASS' ("{0}  (from {1})" -f $ip.Ip, $ip.Source)
} else {
    Add-Result 'egress_ip' 'Current public egress IP' 'WARN' 'could not determine the egress IP (no answer from ifconfig.me / ip.sb / ipinfo.io) - ask the customer for it'
}

# ---------------------------------------------------------------- 11. disk
Write-Host ''
Write-Host '[11/12] Free disk space on the installation volume'
try {
    $full = [System.IO.Path]::GetFullPath($Root)
    $driveLetter = $full.Substring(0, 2)
    $di = New-Object System.IO.DriveInfo($driveLetter)
    $freeGb = [math]::Round($di.AvailableFreeSpace / 1GB, 2)
    $totalGb = [math]::Round($di.TotalSize / 1GB, 2)
    if ($freeGb -ge 2) {
        Add-Result 'disk' 'Free disk space' 'PASS' ("{0} has {1} GB free of {2} GB (package needs ~30 MB, plus room for state and crawls)" -f $driveLetter, $freeGb, $totalGb)
    } else {
        Add-Result 'disk' 'Free disk space' 'FAIL' ("{0} has only {1} GB free - free at least 2 GB before installing" -f $driveLetter, $freeGb)
    }
} catch {
    Add-Result 'disk' 'Free disk space' 'WARN' ("could not read drive info: {0}" -f $_.Exception.Message)
}

# ---------------------------------------------------------------- 12. execution policy
Write-Host ''
Write-Host '[12/12] PowerShell execution policy'
try {
    $eff = Get-ExecutionPolicy
    $list = (Get-ExecutionPolicy -List | Out-String).Trim()
    if ($eff -eq 'Restricted' -or $eff -eq 'AllSigned') {
        Add-Result 'execp' 'PowerShell execution policy' 'WARN' ("effective policy is '{0}' - run the delivery scripts with: powershell -NoProfile -ExecutionPolicy Bypass -File <script>.ps1" -f $eff)
    } else {
        Add-Result 'execp' 'PowerShell execution policy' 'PASS' ("effective policy is '{0}'" -f $eff)
    }
} catch {
    Add-Result 'execp' 'PowerShell execution policy' 'WARN' $_.Exception.Message
}

# ---------------------------------------------------------------- summary
$passed = @($script:Results | Where-Object { $_.Level -eq 'PASS' }).Count
$warned = @($script:Results | Where-Object { $_.Level -eq 'WARN' }).Count
$failed = @($script:Results | Where-Object { $_.Level -eq 'FAIL' }).Count
$total = $script:Results.Count

Write-Host ''
Write-Host '---------------------------------------------------------------------'
Write-Host ' MANUAL ITEMS (these three cannot be done by a script) - current probe'
Write-Host '---------------------------------------------------------------------'
$extDir = Join-Path $Root 'Takealot-Assistant-Extension'
$extState = if (Test-Path -LiteralPath (Join-Path $extDir 'manifest.json')) { 'folder present, but whether the browser has it LOADED cannot be read from the command line - look at chrome://extensions yourself' } else { 'folder NOT present yet - install.ps1 places it' }
Write-Host ("  1) Load the unpacked extension  : {0}" -f $extState)

$storesJson = Join-Path $Root 'plugins\takealot-erp\state\stores.json'
if (Test-Path -LiteralPath $storesJson) {
    try {
        $raw = [System.IO.File]::ReadAllText($storesJson, [System.Text.Encoding]::UTF8)
        $obj = $raw | ConvertFrom-Json
        $bound = @($obj.stores | Where-Object { $_.'_key' -and $_.'_key'.Trim() }).Count
        $enc = @($obj.stores | Where-Object { $_.'_key' -and $_.'_key'.StartsWith('dpapi:') }).Count
        Write-Host ("  2) Enter the Seller Key         : {0} store row(s) bound, {1} of them encrypted at rest (dpapi:). Masked key material is printed by selfcheck.ps1 - never in plain text." -f $bound, $enc)
    } catch {
        Write-Host ("  2) Enter the Seller Key         : stores.json present but unreadable: {0}" -f $_.Exception.Message)
    }
} else {
    Write-Host '  2) Enter the Seller Key         : no state\stores.json yet - nothing is bound (nothing installed, or not started once)'
}

Write-Host ''
Write-Host ("RESULT {0}/{1}" -f $passed, $total)
Write-Host ("  PASS {0}   WARN {1}   FAIL {2}" -f $passed, $warned, $failed)
if ($failed -gt 0) {
    Write-Host '  Blocking items:'
    foreach ($r in ($script:Results | Where-Object { $_.Level -eq 'FAIL' })) {
        Write-Host ("    - {0}: {1}" -f $r.Label, $r.Detail)
    }
    Write-Host '  Fix the blocking items above, then re-run precheck.ps1.'
} else {
    Write-Host '  No blocking item. Continue with install.ps1.'
}
Write-Host ''

if ($failed -gt 0) { exit 1 } else { exit 0 }
