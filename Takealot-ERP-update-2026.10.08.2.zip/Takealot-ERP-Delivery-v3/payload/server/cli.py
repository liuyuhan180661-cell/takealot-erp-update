#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""`erp` 命令行 —— ERP 的通用入口层（形态 v3 · P2）。

**这是「召唤启动」的唯一实现**：桌面图标、任何 agent（Hermes / Claude Code / Codex / Cursor）、
人手工敲命令，走的都是这一份代码。谁都不许自己拼端口、自己 spawn 服务。

    erp open              起服务（没起就起）+ 开工作台窗口（默认浏览器）
    erp open --app        用 Chrome/Edge 的 --app 模式开一个无地址栏窗口（更像 App）
    erp open --no-window  只把服务起起来（给定时任务/自检用）
    erp status            端口/PID/版本/数据目录（退出码：0 在跑 / 3 没跑）
    erp stop              SIGTERM 停服务并确认端口真的关了
    erp doctor            端到端自检（9 项），客户机可自证，退出码即结论
    erp route "打开工作台"  中文词表 → 确定性硬指令（换任何宿主行为一致，不靠模型猜）
    erp shortcut          生成桌面入口（macOS：~/Applications/…工作台.command，本地生成不带 quarantine）
    erp serve             前台跑服务（调试用）

只依赖标准库：status/stop/route/shortcut 在没有 fastapi 的机器上也能用（只有 open/serve 需要）。
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import signal
import socket
import subprocess
import sys
import textwrap
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path



def force_utf8_stdio() -> None:
    """把 stdout/stderr 钉成 UTF-8 —— Windows 上不然会炸。

    客户机上这个 CLI 多数是**重定向执行**（ssh / 计划任务 / .cmd 管道），
    Python 此时按 locale（中文 Windows = cp936/gbk）编码输出：
      · 打印中文或 replace 出来的 U+FFFD → UnicodeEncodeError: 'gbk' codec can't encode ...
      · MCP 走 stdio 时更严重：协议要求 UTF-8，cp936 会让宿主直接读不到 JSON
    真机（Windows 10 中文版）踩过，装到第 6 步就崩。
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:
            pass


force_utf8_stdio()


def _bootstrap_ca() -> None:
    """把包内的 CA 信任库钉成进程级 ``SSL_CERT_FILE``（v3 自建 venv 默认没有信任库）。

    为什么必须有：v3 是独立服务端，跑在包内自建 venv 里；macOS 的 Homebrew Python
    ``ssl.get_default_verify_paths().cafile`` 是 None、也没有 certifi，而**裸
    urlopen 的默认 context 只认它**。少了这一层，抓取 / AI 文案 / 自更新这些没走
    自定义 context 的 HTTPS 全在 TLS 握手失败（表现成「抓不到 / 更新坏了」，且极易
    被误读成出口被 Cloudflare 403）。只 setdefault：客户显式设的 SSL_CERT_FILE /
    TAKEALOT_CA_BUNDLE 仍然优先；子进程经 utf8_env() 继承 environ，一处设置全链路生效。
    """
    try:
        import certifi

        ca = certifi.where()
    except Exception:
        return
    if os.path.isfile(ca):
        os.environ.setdefault("SSL_CERT_FILE", ca)
        os.environ.setdefault("REQUESTS_CA_BUNDLE", ca)


_bootstrap_ca()

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import app as srv  # noqa: E402  （同目录的服务端模块：VERSION / ErpHome / running_instance / pick_port …）

HOME = srv.ErpHome
SERVICE = srv.SERVICE
VERSION = srv.VERSION
BUILD = getattr(srv, "BUILD", "")
API_PREFIX = srv.API_PREFIX
PY = sys.executable

EXIT_OK = 0
EXIT_FAIL = 1
EXIT_NOT_RUNNING = 3

#: 中文词表（跟产品走，不跟宿主走）。命中即给**确定性指令**，各宿主行为一致。
#: 允许用 <ERP_HOME>/routing_words.json 覆盖/扩充（词表随使用演化），格式同下。
DEFAULT_ROUTING = {
    "version": 3,
    "note": ("words = 子串命中；groups = 组内每个词都要出现（中文语序无关：把工作台打开 也能命中 打开+工作台 那一组）。"
             "顺序有意义：**写意图在最前**（改价/改库存 里含「价/库存」这类词，先命中才不会落到读意图上）。"),
    "intents": [
        # ① 写意图放最前：红线是「写在界面」，词表只负责把人引到界面，绝不给任何写接口
        {"id": "write-ui-only", "command": "erp open",
         "words": ["改价", "调价", "降价", "涨价", "跟价改价", "批量改价", "改库存", "改数量",
                   "库存改成", "价格改成", "上架", "发布商品", "发 loadsheet", "发loadsheet", "loadsheet"],
         "groups": [["价格", "改成"], ["库存", "改成"], ["帮我", "改"], ["帮我", "上架"], ["把", "上架"]],
         "instruction": ("**写入不在对话里做**（产品红线）：执行 erp open 打开工作台，并告诉用户"
                         "「改价 / 改库存 / 上架 / 发 loadsheet 在工作台界面里做，每笔写入都留审计」。"
                         "绝不调用任何写接口，也不要教用户绕过界面。")},
        # ② 判定类：该跟卖还是建档 = **只读判定**（v2 有、v3 丢了落点）
        #    放在写意图之后：问句里的"要不要上架"先被问句守卫挡掉，再落到这里
        {"id": "route-verdict", "command": "erp_route_verdict",
         "words": ["跟卖还是建档", "建档还是跟卖", "该跟卖", "该建档", "要不要建档", "需要建档", "要建档吗",
                   "能不能跟卖", "该不该跟卖", "走跟卖还是", "该走哪条", "哪条路", "上架方式", "怎么上架",
                   "该不该上架", "要不要上架", "能不能上架", "需要上架吗", "跟卖判定", "建档判定",
                   "该不该新建", "要不要新建", "要不要发offer", "要不要建offer", "上架还是跟卖"],
         "groups": [["跟卖", "建档"], ["该不该", "跟卖"], ["要不要", "上架"], ["该不该", "上架"]],
         "instruction": ("调 MCP 只读工具 erp_route_verdict（target=商品链接 / PLID… / TSIN…），"
                         "把判定和依据原样转述。**不要**把这个词当成写操作，也不要自己拍板。")},
        {"id": "open", "command": "erp open",
         "words": ["打开工作台", "打开中台", "启动工作台", "开工作台", "起工作台", "启动服务",
                   "打开 erp", "打开erp", "打开 takealot", "打开takealot", "打开界面", "打开后台"],
         "groups": [["打开", "工作台"], ["打开", "中台"], ["启动", "工作台"], ["开", "工作台"], ["起", "工作台"],
                    ["进入", "工作台"], ["打开", "erp"], ["打开", "takealot"], ["工作台", "打开"]],
         "instruction": "执行：erp open（起服务并开工作台窗口）。不要自己拼 URL 或端口。"},
        {"id": "status", "command": "erp status",
         "words": ["工作台状态", "erp 状态", "erp状态", "端口多少"],
         "groups": [["服务", "在跑"], ["服务", "没起"], ["工作台", "状态下"], ["工作台", "在吗"], ["服务", "状态"]],
         "instruction": "执行：erp status（打印端口/PID/版本，退出码 0=在跑、3=没跑）。"},
        {"id": "stop", "command": "erp stop",
         "words": ["停掉工作台", "关闭工作台", "停止服务", "关掉 erp", "关掉erp", "把工作台关了"],
         "groups": [["工作台", "关"], ["服务", "停"], ["erp", "关"], ["工作台", "停"]],
         "instruction": "执行：erp stop（停服务并确认端口关闭）。先跟用户确认，停了界面就用不了。"},
        {"id": "doctor", "command": "erp doctor",
         "words": ["工作台自检", "erp 自检", "erp自检", "环境自检", "体检", "检查环境"],
         "groups": [["哪里", "不通"], ["自检", "工作台"], ["检查", "环境"], ["诊断", "工作台"]],
         "instruction": "执行：erp doctor（13 项端到端自检，退出码即结论）。"},

        # ③ 定时任务 / 更新 / 抓取：**自然语言就是入口**（任务跑在客户机自己的服务里，不依赖任何外部机器）
        # 开关放在"列表"前面：`关掉巡检任务` 里同时含「巡检任务」，先命中开关才不会落到列表上（顺序有意义）
        {"id": "jobs-toggle", "command": "erp job enable|disable <id>",
         "words": ["启用自动跟价", "开启跟价", "启用跟价", "把自动跟价启用", "关掉巡检任务", "关掉巡检",
                   "停掉定时任务", "关闭任务", "启用任务", "停用任务", "打开日报", "把巡检打开"],
         "groups": [["任务", "开"], ["任务", "关"], ["任务", "关掉"], ["巡检", "打开"], ["巡检", "关"],
                    ["巡检", "关掉"], ["跟价", "开"], ["跟价", "启用"]],
         "instruction": ("执行：erp job enable <id> / erp job disable <id>（id 从 erp job list 里取，不要猜）。"
                         "**写价任务（buybox-round）要有跟价授权**：在对话里问用户一句，同意后先 "
                         "`erp repricing authorize --store <店> [--min/--max/--interval]` 再 enable；"
                         "没授权时 enable 会被拒并提示这条路 —— 照着做，**绝不偷偷开**。")},
        {"id": "jobs-tune", "command": "erp job set <id> --interval N --args \"...\"",
         "words": ["巡查频率", "抓取间隔", "多久巡一次", "多久抓一次", "抢回频率", "改成每", "间隔改成",
                   "快一点抢", "慢一点抢"],
         "groups": [["频率", "改"], ["间隔", "改"], ["多久", "巡"], ["每一", "分钟"]],
         "instruction": ("先问清用户要**多快**（多少分钟一轮）与要**多快抢回**，再执行 "
                         "`erp job set buybox-round --interval <分钟> --args \"--stale-hours 4 --refresh-held <N>\"`。"
                         "**默认 refresh-held 40**（全店约 10 小时覆盖）；要更快就调大（200 ≈ 2 小时，"
                         "代价是每轮多 200 次公开页抓取）。**别写死**：客户端的 agent 可以按需要随机/自适应调。"
                         "铁律不变：写价决策所用的行必须是新鲜的（卡龄 ≤ --stale-hours），"
                         "绝不能拿旧卡判断「买盒还在我们手上」。")},
        {"id": "jobs-list", "command": "erp job list",
         "words": ["定时任务", "有哪些任务", "任务列表", "任务状态", "巡检任务", "定时跑什么", "都跑哪些",
                   "任务都在跑", "任务还在跑"],
         "groups": [["任务", "列表"], ["定时", "任务"], ["任务", "状态"], ["下次", "跑"], ["任务", "跑"]],
         "instruction": ("执行：erp job list（任务跑在本机服务里，不依赖任何外部机器；输出里有"
                         "「调度线程：在跑（N 秒前还在跳）」这种心跳证据）。原样转述，别自己编任务名或时间。")},
        {"id": "jobs-run", "command": "erp job run <id>",
         "words": ["跑一次", "现在就跑", "立刻巡检", "手动跑一次", "马上执行", "帮我跑一遍", "跑一下巡检",
                   "跑一下物流", "跑一下日报", "跑一下订单"],
         "groups": [["跑", "一次"], ["现在", "跑"], ["立刻", "执行"], ["跑", "巡检"], ["跑", "一遍"]],
         "instruction": ("先 erp job list 拿 id（不要猜 id），再 erp job run <id>。退出码：0=没事、"
                         "1=有要处理的（不是故障）、>=2=真失败。把脚本输出原样转述。")},
        {"id": "update", "command": "erp update",
         "words": ["检查更新", "有没有新版本", "升级一下", "更新到最新版", "升级到最新版", "升级到新版",
                   "拉新版本", "升级 erp", "升级erp"],
         "groups": [["更新", "检查"], ["新", "版本"], ["升级", "一下"], ["升级", "版本"], ["升级", "最新"]],
         "instruction": ("先 erp update --check 看有没有新版；有新版再 erp update（会自动校验 sha256，"
                         "校验不过拒装）。升级会重启服务、工作台短暂不可用 —— 先跟用户说一声。")},
        {"id": "crawl", "command": "erp job run crawl-pull",
         "words": ["启动爬虫", "爬一下", "定时抓取", "刷新目录", "重抓竞品", "拉取商品数据", "抓取数据"],
         "groups": [["抓", "数据"], ["爬虫", "启动"], ["目录", "刷新"], ["抓", "一下"]],
         "instruction": ("执行：erp job run crawl-pull（只读：刷公开页/目录缓存，不动平台数据）。"
                         "抓不到就说抓不到，绝不用估算值代替。")},
        {"id": "crawl-product", "command": "erp_crawl_product",
         "words": ["爬取", "扒一下", "抓这个商品", "抓一下这个商品", "取数一下", "弄下来", "扒这个商品",
                   "这个商品的数据", "抓单个商品", "爬一下这个商品"],
         "groups": [["爬", "链接"], ["扒", "商品"], ["抓", "PLID"], ["取数", "商品"]],
         "instruction": ("调 MCP 只读工具 erp_crawl_product（target=链接 / PLID… / TSIN…）：抓公开页并给销量推算。"
                         "抓不到就如实说抓不到，不要用估算值顶替。")},
        {"id": "order-patrol", "command": "erp job run order-patrol",
         "words": ["订单巡检", "有没有异常单", "亏损单巡检", "看下有没有要发货的"],
         "groups": [["订单", "巡检"], ["异常", "单"]],
         "instruction": "执行：erp job run order-patrol（只读：待发货 / 亏损单 / 窗口汇总）。数字照实转述。"},
        {"id": "po-tracking", "command": "erp job run po-tracking",
         "words": ["po 单跟踪", "po单跟踪", "送仓单跟踪", "po 进度", "送货单到期", "货什么时候到仓"],
         "groups": [["po", "跟踪"], ["送仓", "跟踪"], ["到仓", "什么时候"]],
         "instruction": "执行：erp job run po-tracking（只读：逾期 / 临期 PO，口径 daysToDue<0=逾期）。"},

        # ④ 读意图：指到具体的 MCP 只读工具（读在对话）。数字一律来自接口，不自己算
        {"id": "read-overview", "command": "erp_overview",
         "words": ["今天营收", "营收多少", "营业额", "今天几单", "今天多少单", "单量多少", "经营总览",
                   "今天卖了多少", "赚了多少", "利润多少", "净利率", "卖得怎么样", "卖得如何",
                   "这个月卖", "业绩怎么样", "经营情况"],
         "groups": [["营收", "多少"], ["今天", "单"], ["今天", "营收"], ["总览", "看"], ["这个月", "卖"]],
         "instruction": "调 MCP 读工具 erp_overview（只读，带 storeId）。数字照实转述，不自己算、不编。"},
        {"id": "read-orders", "command": "erp_orders",
         "words": ["看下订单", "订单明细", "最近订单", "订单列表", "亏损单", "净利多少", "待发货",
                   "还没发货", "未发货", "要发货", "哪些订单", "发货了没", "有没有单",
                   # v2 词表里这些说法能命中、v3 丢了
                   "我的订单", "销量", "卖了", "卖了多少", "多少单", "出单", "销售额",
                   "最近30天", "近30天", "最近三十天"],
         "groups": [["订单", "看"], ["订单", "多少"], ["订单", "列表"], ["订单", "发货"],
                    ["哪些", "发货"], ["订单", "处理"], ["订单", "找"], ["销量", "搜"]],
         "instruction": "调 MCP 读工具 erp_orders（只读）。要更细的逐单扣减，请用户去工作台「订单与净利」点那一行。"},
        {"id": "read-products", "command": "erp_products",
         "words": ["库存还剩", "还有多少货", "商品目录", "在售商品", "零库存", "缺主图", "缺条码",
                   "库存低", "库存偏低", "快没货", "缺货", "库存偏少",
                   # v2 词表里这些说法能命中、v3 丢了
                   "我的商品", "我的产品", "商品有哪些", "有哪些商品", "有多少款", "哪些款"],
         "groups": [["库存", "多少"], ["商品", "目录"], ["在售", "多少"], ["商品", "库存"],
                    ["库存", "偏"], ["商品", "有哪些"], ["商品", "几款"]],
         "instruction": "调 MCP 读工具 erp_products（只读）。改价/改库存请去工作台界面（见写意图）。"},
        {"id": "read-finance", "command": "erp_finance",
         "words": ["对账", "结算", "平台扣费", "财务", "账单", "疑似多收", "实结",
                   # v2 词表里这些说法能命中、v3 丢了（老客户的原话，真机回归）
                   "余额", "流水", "手续费", "到账", "月结", "打了多少款", "扣了多少钱"],
         "groups": [["账单", "对"], ["平台", "扣了多少"], ["流水", "看"]],
         "instruction": "调 MCP 读工具 erp_finance（只读）。费用口径见 skill 的费率说明，别自己估。"},
        {"id": "read-collection", "command": "erp_collection",
         "words": ["采集箱", "跟卖池", "选品"],
         "groups": [["采集箱", "有"], ["跟卖池", "多少"]],
         "instruction": "调 MCP 读工具 erp_collection（只读）。上架动作在工作台界面做。"},
        {"id": "read-listings", "command": "erp_listings",
         "words": ["上架草稿", "草稿箱", "待上架", "草稿列表", "上架准备", "listing草稿", "listing 草稿"],
         "groups": [["草稿", "看"], ["草稿", "准备"], ["草稿", "怎么样"], ["草稿", "几条"], ["草稿", "有"]],
         "instruction": "调 MCP 只读工具 erp_listings（上架草稿箱：草稿/必填属性缺口）。**只读**，上架动作在工作台界面做。"},
        {"id": "read-fulfilment", "command": "erp_fulfilment",
         "words": ["履约", "入仓", "出库", "在途", "补货", "集货", "收货", "发货批次", "po 单", "po单"],
         "groups": [["履约", "看"], ["入仓", "多少"], ["出库", "多少"]],
         "instruction": ("调 MCP 只读工具 erp_fulfilment（履约闭环：送仓单/出库批次/在途）。"
                         "送仓单**超时预警**走物流巡查（patrol-logistics），两者别混。")},
        {"id": "read-diagnostics", "command": "erp_diagnostics",
         "words": ["读不到", "取不到", "连不通", "为什么没有数据", "报错是怎么回事", "拿不到"],
         "groups": [["没有", "数据"], ["接口", "失败"]],
         "instruction": "调 MCP 读工具 erp_diagnostics（只读）：出口通道 / Seller API / 密钥 / 公开通道逐项带证据。不要猜原因。"},

        # ③ 专项：指向对应 skill 的脚本（物流/买盒是各自 skill 的唯一执行入口）
        {"id": "patrol-logistics", "command": "skill: takealot-erp-logistics-patrol",
         "words": ["物流巡查", "送仓单", "要超时", "退货", "签收", "要马上处理", "物流有哪些",
                   "哪些要处理", "物流要处理"],
         "groups": [["物流", "巡查"], ["送仓", "超时"], ["有", "退货"], ["物流", "处理"], ["送仓单", "处理"]],
         "instruction": ("物流/送仓单/退货是**只读**：加载 takealot-erp-logistics-patrol，跑它自带的 "
                         "logistics_patrol.py 并原样转述输出（退出码 0=没有要马上处理的）。不要自己算单量。")},
        {"id": "repricing-authorize", "command": "erp repricing authorize",
         "words": ["授权跟价", "跟价授权", "帮我盯价", "盯价抢回", "抢回购物车", "自动跟价", "同意跟价",
                   "开启跟价"],
         "groups": [["跟价", "授权"], ["盯价", "开"], ["购物车", "抢"]],
         "instruction": ("跟价是**对话授权**：先用一句话把范围说清楚问用户 —— 「要不要我帮你盯价、丢了买盒就按"
                         "规则压价抢回来？下探 R{小}~R{大}、每 {N} 小时一轮」，得到明确同意后执行 "
                         "`erp repricing authorize --store <店铺id> [--min 1] [--max 50] [--interval 2]`，"
                         "再 `erp job enable buybox-round` 开任务。**金额/范围要用户点头，不要自己定**；"
                         "没得到同意就不要授权。想手动看一轮：`erp job run buybox-round`。")},
        {"id": "repricing-revoke", "command": "erp repricing revoke",
         "words": ["停止跟价", "撤回跟价", "撤回授权", "别跟价了", "不要跟价了", "关掉跟价", "取消授权"],
         "groups": [["跟价", "停"], ["跟价", "撤"], ["授权", "取消"]],
         "instruction": ("执行 `erp repricing revoke`（撤回授权）+ `erp job disable buybox-round`（停任务）。"
                         "已调出去的价格**不会自动变回来**，要还原得手工改价 —— 跟用户说清楚这一点。")},
        {"id": "watch-buybox", "command": "skill: takealot-erp-buybox-watch",
         "words": ["盯盘", "买盒", "守价", "自动跟价", "抢回购物车"],
         "groups": [["24", "小时"], ["盯着", "价格"], ["帮", "守"]],
         "instruction": ("买盒守护按 takealot-erp-buybox-watch 走：**先问用户**（范围/间隔要用户点头）→ "
                         "`erp repricing authorize …` → `erp job enable buybox-round`。"
                         "写价只能由 repricing_round.py 执行（唯一写入口，每轮留账本 + 平台回读）；"
                         "离线时它会明确报「看门狗没跑」。")},
        {"id": "read-competitor", "command": "erp open（工作台「竞品监控」）",
         "words": ["竞品监控", "竞品情况", "跟卖人数", "竞品价"],
         "groups": [["竞品", "多少"], ["竞品", "看"]],
         "instruction": ("竞品快照在公开页抓取缓存里：执行 erp open 打开工作台「竞品监控」，"
                         "或用工作台里的「重抓竞品数据」。抓不到就说抓不到，不要用估算值代替。")},
        {"id": "compliance-ui", "command": "erp open",
         "words": ["合规检测", "禁用词", "违禁词", "能不能上架"],
         "groups": [["标题", "合规"], ["文案", "合规"]],
         "instruction": "合规检测在工作台「合规检测」模块里做（本地词库，文案不外传）：执行 erp open 并指路。"}
    ]
}


# ---------------------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------------------

def out(payload: dict, as_json: bool, text: str = "") -> None:
    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    elif text:
        print(text)


#: 本机回环调用**永远绕过系统代理**：国内机器普遍挂着 Clash/公司代理，
#: 一旦让 urllib 走系统的 proxy 设置，127.0.0.1 的请求会被代理拦成 502（实测踩到）。
_LOOPBACK_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def http_json(url: str, token: str | None = None, timeout: float = 8.0, method: str = "GET"):
    req = urllib.request.Request(url, method=method)
    if token:
        req.add_header("X-ERP-Token", token)
    try:
        with _LOOPBACK_OPENER.open(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8") or "null")
    except urllib.error.HTTPError as exc:
        try:
            return exc.code, json.loads(exc.read().decode("utf-8") or "null")
        except Exception:
            return exc.code, None
    except Exception as exc:
        return 0, {"error": str(exc)}


def utf8_env(**extra: str) -> dict:
    """子进程环境：强制 UTF-8（PYTHONUTF8 / PYTHONIOENCODING）。

    Windows 中文版的 locale 是 cp936/gbk：不加这两个变量，pip、venv、服务端、MCP 子进程
    的输出/日志会在中文上炸（真机第 6 步 UnicodeEncodeError）。
    """
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env.update(extra)
    return env


def port_open(port: int, timeout: float = 1.2) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(timeout)
        return s.connect_ex(("127.0.0.1", port)) == 0


def running(home: HOME) -> dict:
    """在跑的实例信息（以端口探活为准，不看 runtime.json 是否存在）。

    必须同时**认家**：端口上有应答不等于"是本 home 的服务"。同一台机器跑过两个数据目录
    （测试机、升级期新旧并存）时，只看"端口有应答"会把别人的服务认成自己的 ——
    界面拿到的是别人的 token 与别人的店铺数据（真机踩到：新装的那份报"已启动"，
    端口/pid 却是另一个 home 的）。
    """
    info = home.read_runtime()
    port = info.get("port")
    if isinstance(port, int) and port > 0:
        status, body = http_json("http://127.0.0.1:{0}/healthz".format(port), timeout=2.0)
        if status == 200 and isinstance(body, dict) and body.get("ok"):
            if str(body.get("erpHome") or info.get("erpHome") or "") == str(home.root):
                return {**info, **body, "running": True}
            # 应答的是**另一个数据目录**的实例：占着端口，但不是我们的
            return {**info, "running": False, "portBusyByOther": True,
                    "otherHome": body.get("erpHome")}
        if port_open(port):
            return {**info, "running": False, "portBusyByOther": True}
    return {"running": False}


def wait_own_instance(home: HOME, timeout: float = 40.0) -> dict:
    """等**本 home 自己**的服务起来，返回它的信息（等不到返回空 dict）。

    为什么不用"等请求的那个端口有应答"：服务端在端口被占时会自动漂到 18792/18793…
    （``pick_port``）。只等原端口，就会把**占着那个端口的别人**当成本次新起的实例，
    于是 CLI 报的端口/pid 是别人的，open 出来的界面也连到别人的店铺。
    判据：本 home 的 runtime.json 有 port + 该端口 /healthz 的 erpHome 就是本 home。
    """
    deadline = time.time() + timeout
    expected = str(home.root)
    while time.time() < deadline:
        info = home.read_runtime()
        port = info.get("port")
        if isinstance(port, int) and port > 0:
            status, body = http_json("http://127.0.0.1:{0}/healthz".format(port), timeout=2.0)
            if status == 200 and isinstance(body, dict) and body.get("ok") \
                    and str(body.get("erpHome") or info.get("erpHome") or "") == expected:
                return {**info, **body, "running": True}
        time.sleep(0.5)
    return {}


def wheelhouse_binary_tags(wh: Path) -> tuple[set, set]:
    """从 wheelhouse 的文件名读出**二进制轮子**支持的（解释器标签, 平台标签）。

    纯 Python 轮子（``py3-none-any``）谁都能装、不构成限制；卡人的只有平台轮子
    （pydantic_core 这类：`cp312-cp312-win_amd64.whl`）。这里只读文件名，不引第三方库。
    """
    py_tags: set = set()
    plat_tags: set = set()
    try:
        for whl in wh.glob("*.whl"):
            parts = whl.stem.split("-")
            if len(parts) < 5:
                continue
            py, abi, plat = parts[-3], parts[-2], parts[-1]
            if py == "py3" and abi == "none" and plat == "any":
                continue
            py_tags.update(py.split("."))
            plat_tags.update(plat.split("."))
    except OSError:
        pass
    return py_tags, plat_tags


def python_matrix_doc(payload: Path) -> Path:
    """客户机自检用文档的位置（包里在包根，源码树里在 docs/）。"""
    for cand in (payload.parent / "PYTHON-MATRIX.md", payload / "docs" / "PYTHON-MATRIX.md"):
        if cand.is_file():
            return cand
    return payload.parent / "PYTHON-MATRIX.md"


def interpreter_tag() -> str:
    return "cp{0}{1}".format(sys.version_info.major, sys.version_info.minor)


def interpreter_tags_of(exe: str) -> tuple[str, str]:
    """问**任意一个**解释器要它的（解释器标签, 平台标签）。

    为什么要问别人：决定 pip 能不能装的是 **venv 里那个** 解释器，不是跑 cli.py 的这个。
    返空串=问不出来（不是解释器 / 32 位崩了 / 被截断）——调用方必须把它当成"不可用"。
    """
    code = ("import sys, sysconfig;"
            "v = sys.version_info;"
            "t = 'cp%d%d' % (v[0], v[1]);"
            "t += 't' if sysconfig.get_config_var('Py_GIL_DISABLED') else '';"
            "print(t);"
            "print(sysconfig.get_platform().replace('-', '_'))")
    try:
        cp = subprocess.run([str(exe), "-c", code], capture_output=True, text=True,
                            encoding="utf-8", errors="replace", env=utf8_env(), timeout=30)
    except Exception:
        return "", ""
    lines = [x.strip() for x in (cp.stdout or "").splitlines() if x.strip()]
    if cp.returncode == 0 and len(lines) >= 2:
        return lines[0], lines[1]
    return "", ""


def _tag_ok(tag: str, want: set) -> bool:
    """这个标签与轮子声明的标签集合兼容吗。空集合 = 不约束（纯 Python 轮子）。"""
    if not want:
        return True
    if not tag:
        return False
    if tag in want:
        return True
    # macOS 平台标签带系统小版本（解释器 macosx_10_9_x86_64 vs 轮子 macosx_10_12_x86_64）：
    # 只比最后一节（架构），别把好好的解释器判成不匹配 —— 真正的门是 pip 自己那道。
    return tag.split("_")[-1] in {w.split("_")[-1] for w in want}


def python_candidates() -> list[str]:
    """机器上可能存在的解释器路径（只列不判，探测交给 pick_interpreter）。"""
    out: list[str] = []
    if os.name == "nt":
        roots = [Path(os.environ.get("LOCALAPPDATA") or "") / "Programs" / "Python",
                 Path(os.environ.get("ProgramFiles") or ""),
                 Path("C:\\")]
        for root in roots:
            try:
                for d in sorted((p for p in root.glob("Python3*") if p.is_dir()), reverse=True):
                    for exe in (d / "python.exe", d / "python3.exe"):
                        if exe.is_file():
                            out.append(str(exe))
            except OSError:
                pass
        for ver in ("3.12", "3.13", "3.11", "3.10"):
            try:
                cp = subprocess.run(["py", "-" + ver, "-c", "import sys; print(sys.executable)"],
                                    capture_output=True, text=True, timeout=20, env=utf8_env())
                exe = (cp.stdout or "").strip()
                if cp.returncode == 0 and exe:
                    out.append(exe)
            except Exception:
                pass
    else:
        for name in ("python3.12", "python3.13", "python3.11", "python3.10", "python3"):
            found = shutil.which(name)
            if found:
                out.append(found)
    return out


def pick_interpreter(cands: list[str], want_py: set, want_plat: set) -> tuple[str, str, str]:
    """挑一个与包内二进制轮子对得上的解释器 → (exe, 解释器标签, 平台标签)。

    都不匹配时返回**第一个能被识别**的（好让上层把"这台机器上是什么"如实打出来）。
    探测不出来的候选不参与"匹配"判定 —— 否则一个坏掉/被截断的 python.exe 会被当成合格的。
    """
    seen: set[str] = set()
    first: tuple[str, str, str] | None = None
    for exe in cands:
        if not exe or exe in seen:
            continue
        seen.add(exe)
        t, p = interpreter_tags_of(exe)
        if t and first is None:
            first = (exe, t, p)
        if t and _tag_ok(t, want_py) and _tag_ok(p, want_plat):
            return exe, t, p
    return first or ("", "", "")


def service_python(home: HOME) -> Path | str:
    """服务端该用哪个解释器：**已装的 venv 优先**。

    为什么钉死它：v3 的解释器由"谁拉起服务"决定（老形态是 Hermes 原地加载，固定）。
    venv 里才有 fastapi/uvicorn 和 CA 信任库（certifi），用系统 python 拉起 =
    起不来、或跑在一个没有信任库的解释器上（这两类故障都真机踩过）。venv 不存在
    （开发树里直接跑）才退回当前解释器。
    """
    py = home.root / "venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    return py if py.is_file() else PY


def spawn_server(home: HOME, port: int, extra: list[str] | None = None) -> int:
    """把服务端起成后台进程（脱离当前会话），日志进 ERP_HOME/logs/server.out。"""
    home.ensure()
    log_path = home.logs / "server.out"
    cmd = [str(service_python(home)), str(HERE / "app.py"), "--port", str(port), "--erp-home", str(home.root)] + (extra or [])
    fh = open(log_path, "ab")
    # 子进程一律 UTF-8：Windows 中文版默认 cp936，服务端日志/JSON 会编码炸（真机踩过）
    # cwd 用 ERP_HOME 而不是 server/：Windows 不让删"别的进程当前目录"，占了 server/ 就会卡住升级
    kw = {"stdout": fh, "stderr": fh, "stdin": subprocess.DEVNULL, "cwd": str(home.root),
          "env": utf8_env()}
    if os.name == "posix":
        kw["start_new_session"] = True  # 脱离终端：关掉终端窗口服务不死
        return subprocess.Popen(cmd, **kw).pid

    # Windows 常驻的两个前提：
    #   DETACHED_PROCESS        —— 不依赖控制台
    #   CREATE_BREAKAWAY_FROM_JOB —— **从 ssh 会话/宿主所在的 Job 里逃出来**
    # 少了 breakaway，会话一断整个进程树被回收：表现是「装完自检 13/13，重连一次服务就没了」
    # （真机踩过：21:44 起来，ssh 一断即死）。宿主 Job 不允许 breakaway 时会 ACCESS_DENIED，
    # 那就退一步照常起 —— 客户双击 .cmd 这条路本来就没有 Job 问题。
    base_flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
    breakaway = getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0x01000000)
    try:
        return subprocess.Popen(cmd, creationflags=base_flags | breakaway, **kw).pid
    except OSError:
        return subprocess.Popen(cmd, creationflags=base_flags, **kw).pid


def wait_health(port: int, timeout: float = 40.0) -> dict | None:
    t0 = time.time()
    while time.time() - t0 < timeout:
        status, body = http_json("http://127.0.0.1:{0}/healthz".format(port), timeout=2.0)
        if status == 200 and isinstance(body, dict):
            return body
        time.sleep(0.35)
    return None


def ensure_server(home: HOME, port: int) -> tuple[dict, bool]:
    """没起就起，起了就直接用。返回 (实例信息, 是否本次新起)。"""
    info = running(home)
    if info.get("running"):
        return info, False
    if info.get("portBusyByOther"):
        port = srv.pick_port(port + 1)
    spawn_server(home, port)
    info_new = wait_own_instance(home)
    if not info_new:
        tail = ""
        try:
            tail = "\n".join((home.logs / "server.out").read_text(errors="replace").splitlines()[-12:])
        except OSError:
            pass
        raise SystemExit("服务端起不来（{0} 秒内没有本 home 的 /healthz）。"
                         "端口段可能被别的实例/程序占着。日志尾部：\n{1}".format(40, tail))
    return info_new, True


# ---------------------------------------------------------------------------
# 开窗口
# ---------------------------------------------------------------------------

# 开窗口与浏览器探测只有一份实现（server/platform_ui.py）：服务端自己的入口端点也要用
import platform_ui  # noqa: E402

browser_candidates = platform_ui.browser_candidates
open_window = platform_ui.open_window


# ---------------------------------------------------------------------------
# 词表路由
# ---------------------------------------------------------------------------

def routing_table(home: HOME) -> dict:
    """内置词表 + ERP_HOME/routing_words.json 覆盖（用户/客户都能自己加词，不必改代码）。"""
    table = json.loads(json.dumps(DEFAULT_ROUTING))
    override = home.root / "routing_words.json"
    try:
        if override.is_file():
            extra = json.loads(override.read_text(encoding="utf-8"))
            by_id = {i["id"]: i for i in table["intents"]}
            for intent in extra.get("intents", []):
                if intent.get("id") in by_id:
                    cur = by_id[intent["id"]]
                    cur["words"] = sorted(set(cur.get("words", [])) | set(intent.get("words", [])))
                    if intent.get("instruction"):
                        cur["instruction"] = intent["instruction"]
                else:
                    table["intents"].append(intent)
    except Exception as exc:
        table["overrideError"] = str(exc)
    return table


#: 问句标记：写意图的**弱表达**遇到它们就不算写（v2 的 _QUESTION，形态迁移时丢了）。
_QUESTION_WORDS = ("该不该", "要不要", "能不能", "可不可以", "是不是", "应不应该", "为什么", "为啥",
                   "怎么", "如何", "需要吗", "吗", "呢", "？", "?")

#: 否定上下文：「不要抓取 / 别采集 / 先别扒 / 不用取数」不是抓取请求（v2 的 _NEGATION_RE）。
#: 负向断言只挂在单字「别」上（挡掉「类别 / 特别 / 分别 / 个别」这类假否定）；多字否定词
#: （不要/先别/不用…）不需要断言，否则「这个不要存进采集箱」会被「个+别？」误伤。
_NEGATION_RE = re.compile(
    r"(?:不要|不需要|暂不|暂时不|先不|无需|不许|先别|不用"
    r"|(?<![类特分别个])别)"
    r"\s*[^\s，。！？,]{0,4}?(抓|爬|扒|撸|采集|取数|弄下来|搜|查|存进|加进|放进|下载|刷新|重抓|重刷|拉取)")

#: 带这些动词的意图在否定句里整条跳过（触发词里含它就跳过：宁可少注入，不要做反事）。
_FETCH_VERBS = ("抓", "爬", "扒", "撸", "采集", "取数", "刷新", "重抓", "重刷", "拉取", "弄下来", "下载")


def _guard_blocks(intent_id: str, via: str, matched: str, question: bool, negated: bool) -> bool:
    """问句 / 否定守卫：True = 这条意图不该命中（见 route() 的说明）。"""
    if negated and any(v in matched for v in _FETCH_VERBS):
        return True
    if intent_id == "write-ui-only" and via == "word" and question:
        return True
    return False


def route(text: str, home: HOME) -> dict:
    """确定性路由：words 子串命中，或 groups 里某一组的所有词都出现（中文语序无关）。

    两道守卫（v2 有、形态迁移时丢了，真机回归就在这里）：
      · **问句守卫**：写意图里的**弱表达**（上架/改价/loadsheet 这类词）出现在问句里不算写 ——
        「这个商品要不要上架？」是在问判定，不是让人去改价；只有命令式（组命中，如「把价格改成」）
        才无条件算写。
      · **否定守卫**：句子里有否定（「先别爬一下」「不要抓取数据」「暂时别刷新目录」）时，
        带抓取/搜索动词的意图整条跳过 —— 用户明确说别做，不要注入任何抓取指令。
    """
    table = routing_table(home)
    needle = (text or "").strip().lower()
    raw = text or ""
    question = any(w in raw for w in _QUESTION_WORDS)
    negated = bool(_NEGATION_RE.search(raw))
    hits = []
    for intent in table["intents"]:
        matched = None
        via = "word"
        for word in intent.get("words", []):
            if word.lower() in needle:
                matched = "词「{0}」".format(word)
                break
        if not matched:
            via = "group"
            for group in intent.get("groups", []):
                if group and all(str(w).lower() in needle for w in group):
                    matched = "组「{0}」".format("+".join(group))
                    break
        if not matched:
            continue
        if _guard_blocks(intent["id"], via, matched, question, negated):
            continue
        hits.append({"intent": intent["id"], "matched": matched, "command": intent["command"],
                     "instruction": intent["instruction"]})
    if not hits:
        return {"matched": False, "query": text, "intents": [i["id"] for i in table["intents"]],
                "instruction": ("词表没命中：**不要猜**。按三分法处理 —— "
                                "① 问数据（营收/订单/库存/财务/采集箱）→ 调对应的 MCP 只读工具（erp_overview / erp_orders / "
                                "erp_products / erp_finance / erp_collection / erp_diagnostics）；"
                                "② 要写入（改价/改库存/上架/发 loadsheet）→ 红线：**只在工作台界面做**，执行 erp open 并指路；"
                                "③ 运维（起/停/状态/自检）→ erp open / erp status / erp stop / erp doctor。")}
    return {"matched": True, "query": text, "intent": hits[0]["intent"], "command": hits[0]["command"],
            "matchedWord": hits[0]["matched"], "instruction": hits[0]["instruction"],
            "allHits": hits}


# ---------------------------------------------------------------------------
# 自检（doctor）
# ---------------------------------------------------------------------------

def doctor_rows(home: HOME) -> list[tuple[str, str, str]]:
    """13 项端到端自检的**事实采集**（打印/MCP/自检面板都调这一份，不许各写一套）。

    返回 [(level, name, detail)]，level ∈ ok / warn（可选件缺失，不影响可用）/ fail（必须修）。
    """
    rows: list[tuple[str, str, str]] = []

    def add(ok: bool, name: str, detail: str = "", level: str | None = None) -> None:
        rows.append((level or ("ok" if ok else "fail"), name, detail))

    info = running(home)

    # 1) 服务端进程
    add(info.get("running"), "服务端在跑（端口探活）",
        "http://127.0.0.1:{0}/ pid={1} v{2}".format(info.get("port"), info.get("pid"), info.get("version"))
        if info.get("running") else ("端口被别的进程占着" if info.get("portBusyByOther") else "没在跑：erp open 起一个"))

    # 2) runtime.json 与实例一致
    rt = home.read_runtime()
    add(bool(rt) and rt.get("port") == info.get("port"), "runtime.json 与实际实例一致",
        "port={0} token={1}".format(rt.get("port"), "有" if rt.get("token") else "缺"))

    token = str(rt.get("token") or "")
    port = info.get("port")
    base = "http://127.0.0.1:{0}".format(port) if port else ""

    # 3) 带 token 打核心 API
    if info.get("running"):
        status, body = http_json(base + API_PREFIX + "/health", token=token)
        add(status == 200, "带 token 打核心 API → 200", "HTTP {0}".format(status))
        status_401, _ = http_json(base + API_PREFIX + "/health")
        add(status_401 == 401, "无 token 打核心 API → 401（鉴权真的在起作用）", "HTTP {0}".format(status_401))
    else:
        add(False, "带 token 打核心 API → 200", "服务端没跑")
        add(False, "无 token 打核心 API → 401（鉴权真的在起作用）", "服务端没跑")

    # 4) 核心文件 + sha256 与 runtime.json 记录一致（防"半新半旧"部署）
    core = srv.core_fingerprint()
    recorded = (rt.get("core") or {}).get("sha256")
    same = bool(core.get("sha256")) and (not recorded or recorded == core.get("sha256"))
    add(bool(core.get("sha256")), "核心 plugin_api.py 在位", "{0} 字节".format(core.get("bytes")))
    add(same, "核心 sha256 与运行时记录一致（没被悄悄换过）",
        "现在 {0}… vs 记录 {1}…".format(str(core.get("sha256"))[:12], str(recorded)[:12]) if recorded else "runtime.json 里没有记录")

    # 5) 前端资产
    ui = srv.ui_dir(home)
    need = ["index.html", "plugin.js", "host.js", "shell.js", "app.css",
            "vendor/react.js", "vendor/jsx.js", "vendor/rdom.js", "vendor/query.js", "vendor/app.css"]
    missing = [n for n in need if not (ui / n).is_file()]
    add(not missing, "工作台前端资产齐（10 件）", "在 {0}{1}".format(ui, ("，缺：" + ", ".join(missing)) if missing else ""))

    # 6) 密钥库（磁盘上不许是明文）
    backend = (info.get("atRestBackend") or "?").lower()
    add(backend not in ("plaintext", "?", ""), "密钥库可用（Key 不落明文）", backend)

    # 7) 数据目录可写
    try:
        probe = home.state / ".write-probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        add(True, "数据目录可写", str(home.state))
    except Exception as exc:
        add(False, "数据目录可写", str(exc))

    # 8) 桌面入口
    entry = desktop_entry_path()
    entry_ok, entry_detail = entry.is_file(), ""
    if entry_ok:
        # 光看文件在没用：入口可能指向已被清掉的解压目录（真机验收踩过）——要它引用的解释器与 cli.py 都在
        body = entry.read_text(encoding="utf-8", errors="replace")
        refs = re.findall(r'"([^"]+)"', body)
        missing_refs = [r for r in refs if ("python" in r.lower() or r.endswith("cli.py")) and not Path(r).exists()]
        entry_ok = not missing_refs
        entry_detail = str(entry) if entry_ok else "入口指向的文件已不存在（重新装一次或跑 erp shortcut）：" + "、".join(missing_refs)
    add(entry_ok, "桌面入口在位（可有可无）",
        entry_detail if entry_ok else (entry_detail or "没生成：erp shortcut 建一个双击就用的入口（不影响命令行/agent 启动）"),
        level="ok" if entry_ok else "warn")

    # 9) Hermes 侧栏入口（装了宿主机才有这项；缺了不影响工作台本身，所以是 warn 不是 fail）
    h_plugin = desktop_plugins_dir() / LAUNCHER_PLUGIN_NAME / "plugin.js"
    if h_plugin.is_file():
        add(True, "Hermes 侧栏入口在位", str(h_plugin))
    elif hermes_home().is_dir():
        add(False, "Hermes 侧栏入口", "没装：erp entry --host hermes --write（装完宿主左侧栏出现「Takealot ERP」）", level="warn")
    else:
        add(True, "Hermes 侧栏入口（这台机器没装 Hermes）", "不影响：命令行 erp open / 桌面图标照样用")

    # 10) Codex 入口：技能 + MCP 段（同样只 warn；被配置管理器重写是常见事，给的是修复命令）
    c_dir = codex_skills_dir() / "takealot-erp-operator"
    c_cfg = Path.home() / ".codex" / "config.toml"
    c_body = c_cfg.read_text(encoding="utf-8", errors="replace") if c_cfg.is_file() else ""
    c_mcp = "[mcp_servers.takealot-erp]" in c_body
    c_ref = str(home.root) in c_body
    if (c_dir / "SKILL.md").is_file() and c_mcp and c_ref:
        add(True, "Codex 入口在位（技能 + MCP 段指向本 ERP_HOME）", str(c_dir))
    elif (Path.home() / ".codex").is_dir():
        why = "技能缺" if not (c_dir / "SKILL.md").is_file() else (
            "MCP 段缺（被配置管理器重写过？）" if not c_mcp else "MCP 段没指向本 ERP_HOME")
        add(False, "Codex 入口", "{0} → 重跑：erp entry --host codex --write".format(why), level="warn")
    else:
        add(True, "Codex 入口（这台机器没装 Codex）", "不影响：命令行 erp open / 桌面图标照样用")

    # 11) 浏览器（--app 档位是否可用）
    cands = browser_candidates()
    add(bool(cands), "找到 Chromium 系浏览器（--app 档位可用）",
        "、".join(c[0] for c in cands) if cands else "没装 Chrome/Edge —— 回落系统默认浏览器，不影响可用性",
        level="ok" if cands else "warn")

    return rows


def doctor(home: HOME, as_json: bool = False) -> int:
    rows = doctor_rows(home)
    fails = [r for r in rows if r[0] == "fail"]
    warns = [r for r in rows if r[0] == "warn"]
    passed = len(rows) - len(fails) - len(warns)
    ok_all = not fails
    if as_json:
        print(json.dumps({"ok": ok_all, "passed": passed, "warn": len(warns), "failed": len(fails),
                          "total": len(rows),
                          "checks": [{"level": lv, "ok": lv == "ok", "name": n, "detail": d} for lv, n, d in rows]},
                         ensure_ascii=False, indent=2))
    else:
        print("── erp doctor（{0}）".format(home.root))
        mark = {"ok": "PASS", "warn": "WARN", "fail": "FAIL"}
        for lv, name, detail in rows:
            print("  {0} {1}{2}".format(mark[lv], name, ("  — " + detail) if detail else ""))
        print("\n  RESULT {0}/{1} PASS{2}{3}".format(
            passed, len(rows),
            "，" + str(len(warns)) + " 项提示" if warns else "",
            "" if ok_all else "，{0} 项必须修".format(len(fails))))
    return EXIT_OK if ok_all else EXIT_FAIL



# ---------------------------------------------------------------------------
# 一键安装（erp setup）—— 客户机上的唯一安装动作
# ---------------------------------------------------------------------------

def _require_core(p: Path) -> Path:
    """核心代码在不在。**装之前就查** —— 装到一半才发现缺核心，会把好好的实例弄成残废
    （开发树的 plugin/dashboard/plugin_api.py 要靠打包步骤搬到 server/core/，直接拿开发树
    当 payload 跑 setup，就会装出一个起不来的服务；这个坑真踩过）。"""
    for rel in (("server", "core", "plugin_api.py"), ("plugin", "dashboard", "plugin_api.py")):
        if (p.joinpath(*rel)).is_file():
            return p
    raise SystemExit(
        "这个 payload 里没有核心代码（找不到 server/core/plugin_api.py，也找不到 plugin/dashboard/plugin_api.py）。\n"
        "  · 交付包：用 <包>/payload\n"
        "  · 开发树：先用 build.sh 打包，再用 build/Takealot-ERP-Delivery-v3/payload\n"
        "  **没有动你的实例**（宁可不装，也不装出个残废）")


def _payload_dir(explicit: str | None) -> Path:
    """payload 根：交付包里就是 <pkg>/payload，开发树里就是 source/。两处结构相同。"""
    if explicit:
        return _require_core(Path(explicit).expanduser().resolve())
    cand = SERVER_DIR.parent
    if (cand / "server" / "app.py").is_file():
        return _require_core(cand)
    raise SystemExit("找不到 payload（期望里面有 server/app.py）：用 --source 指一下")


def _copy_tree(src: Path, dst: Path) -> int:
    """拷贝并**清掉**会污染客户机的杂物（__pycache__/.DS_Store/*.bak）。返回文件数。

    Windows 的坑（真机踩过）：目标目录若正被别的进程当**当前目录**，`rmtree` 删不掉、
    `copytree` 又报 FileExistsError/WinError 183 —— 于是「重装/升级」整步失败。
    所以这里：先尽力清 → 清不干净就**逐文件覆盖**（保留能写的、跳过锁住的），保证升级能走完。
    """
    ignore = shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo", ".DS_Store", "Thumbs.db", "*.bak", "*.bak-*", "*.log")
    if dst.exists():
        shutil.rmtree(dst, ignore_errors=True)
    try:
        shutil.copytree(src, dst, ignore=ignore)
    except (FileExistsError, PermissionError, OSError):
        # 目录还在（被占用 / 只读）→ 合并式覆盖，逐个文件来
        dst.mkdir(parents=True, exist_ok=True)
        for item in src.rglob("*"):
            rel = item.relative_to(src)
            if any(part in ("__pycache__",) or part.endswith((".pyc", ".pyo", ".bak", ".log")) or part == ".DS_Store"
                   for part in rel.parts):
                continue
            target = dst / rel
            try:
                if item.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(item, target)
            except OSError:
                continue                      # 个别文件被占用：跳过，不因此判整装失败
    return sum(1 for p in dst.rglob("*") if p.is_file())


def _sha256(path: Path) -> str:
    import hashlib

    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write_install_manifest(home: HOME, payload: Path, copied: list[str]) -> Path:
    """记下装了什么、每个文件多大/什么哈希 —— 自检与将来自更新都靠它。"""
    files = {}
    for rel in copied:
        p = home.root / rel
        if p.is_file():
            files[rel] = {"sha256": _sha256(p), "bytes": p.stat().st_size}
    manifest = {
        "service": SERVICE, "version": VERSION, "build": BUILD,
        "installedAt": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "source": str(payload), "erpHome": str(home.root), "files": files,
    }
    out = home.root / "install.json"
    out.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def installed_files(home: HOME) -> list[str]:
    """安装清单里记的相对路径（没装过就是空）。"""
    try:
        data = json.loads((home.root / "install.json").read_text(encoding="utf-8"))
        return sorted(data.get("files", {}).keys())
    except Exception:
        return []


def cmd_setup(args, home: HOME) -> int:
    """一键装工作台：建 venv → 装依赖（可离线）→ 拷文件进 ERP_HOME → 桌面入口 → 自检。

    客户机上只有这一个安装动作（Mac/Linux 走 install.sh，它内部就是调这里）。
    幂等：重复跑不会破坏 state/（state 只属于用户数据，永不被安装覆盖）。
    """
    payload = _payload_dir(args.source)
    steps: list[dict] = []

    def step(name: str, ok: bool, detail: str = "") -> None:
        steps.append({"step": name, "ok": ok, "detail": detail})
        print("  {0} {1}{2}".format("OK  " if ok else "FAIL", name, ("  — " + detail) if detail else ""))

    home.ensure()
    print("── erp setup（{0} → {1}）".format(payload, home.root))

    # 0) 解释器 ↔ 包内轮子 先对表（别等装依赖失败了才说）
    #    轮子分平台：Windows 用 wheelhouse-win（pydantic-core 这类是平台二进制轮子，版本/位数错必失败）
    default_wh = payload / ("wheelhouse-win" if os.name == "nt" else "wheelhouse")
    if not default_wh.is_dir():
        default_wh = payload / "wheelhouse"
    wheelhouse = (Path(args.wheelhouse).expanduser() if args.wheelhouse else default_wh)
    want_py, want_plat = wheelhouse_binary_tags(wheelhouse) if wheelhouse.is_dir() else (set(), set())
    wh_desc = "解释器 {0} / 平台 {1}".format("/".join(sorted(want_py)) or "any",
                                            "/".join(sorted(want_plat)) or "any")

    # 1) venv —— 解释器必须与包内二进制轮子对得上，否则 pip 只会回一句
    #    "No matching distribution found"，客户看不懂（真机踩过：客户机上 PATH 里的 python 是
    #    3.14.0a1 win32，包是 cp312 win_amd64）。而且**venv 一旦建错就会一直被复用** ——
    #    建好再换 Python 重跑也没用（这条也是真机踩到的死胡同），所以建错的必须重建。
    venv_dir = home.root / "venv"
    py = venv_dir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    argv0 = Path(sys.executable).resolve() if sys.executable else None

    def venv_health() -> tuple[bool, str]:
        """这个 venv 真的能用吗。

        判据必须**看盘上的事实**，不能只看"python.exe 还在"：真机踩过 —— 重建时旧 venv 被
        "删了一半"（脚本自己正跑在那个 venv 里，Windows 删不掉正在使用的 python.exe），
        结果只剩 `venv/Scripts/python.exe` 一个壳、`pyvenv.cfg` 都没了；安装器却把
        "解释器跑不起来"当成 OK 打出来，接着 pip 报 `failed to locate pyvenv.cfg`。
        """
        if not py.exists():
            return False, "没有 venv"
        if not (venv_dir / "pyvenv.cfg").is_file():
            return False, "缺 pyvenv.cfg（venv 被删了一半）"
        t, p = interpreter_tags_of(str(py))
        if not t:
            return False, "解释器跑不起来"
        if not (_tag_ok(t, want_py) and _tag_ok(p, want_plat)):
            return False, "{0} / {1} 与包内组件不匹配".format(t, p)
        return True, "{0} / {1}".format(t, p)

    if args.skip_deps:
        cands = [args.python or "", sys.executable]
    else:
        cands = [args.python or "", sys.executable] + python_candidates()
    base, base_py, base_plat = pick_interpreter(cands, want_py, want_plat)
    if not args.skip_deps and want_py and not (_tag_ok(base_py, want_py) and _tag_ok(base_plat, want_plat)):
        step("解释器与包内轮子对表", False,
             "{0} = {1} / {2}".format(base or "(没找到 python)", base_py or "?", base_plat or "?"))
        print("  包内离线轮子只覆盖：{0}".format(wh_desc))
        print("  这台机器上挑到的是：{0}".format(base or "(没有可用的 python)"))
        # 从轮子标签里读出想要的 Python 版本（cp312 → 3.12），把修复命令写成可直接粘的
        want_ver = ""
        for t in sorted(want_py):
            digits = t[2:].rstrip("t") if t.startswith("cp") else ""
            if digits.isdigit() and len(digits) >= 2:
                want_ver = "{0}.{1}".format(digits[0], digits[1:])
                break
        if os.name == "nt":
            # 实测：winget 在这类机器上会打印"成功安装"但磁盘/注册表里什么都没有 —— 不给 winget
            print("  装一个对的 Python（PowerShell 逐条粘；镜像已实测可用）：")
            if want_ver in ("", "3.12"):
                print('    $u = "https://mirrors.aliyun.com/python-release/windows/python-3.12.10-amd64.exe"')
                print('    curl.exe -fsSL --max-time 600 -o "$env:TEMP\\py312.exe" $u')
                print('    (Get-Item "$env:TEMP\\py312.exe").Length     # 期望 26964224')
                print('    Start-Process "$env:TEMP\\py312.exe" -ArgumentList '
                      "'/quiet','InstallAllUsers=0','PrependPath=1','Include_launcher=1','Include_test=0' -Wait")
                print('    & "$env:LOCALAPPDATA\\Programs\\Python\\Python312\\python.exe" -V     # 期望 Python 3.12.10')
                print("  （镜像不通就换官方原站同文件：python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe）")
            else:
                print("    包内离线轮子要的是 Python {0}（64 位）—— 装对应版本，别装别的；".format(want_ver))
                print("    镜像目录：https://mirrors.aliyun.com/python-release/windows/（挑 {0}.x 的 -amd64.exe）".format(want_ver))
            print("  装完直接重跑本安装器即可（它会自己挑到，并把先前建坏的环境重建）")
        else:
            print("  装一个对的 Python：brew install python@{0}".format(want_ver or "3.12"))
        print("  说明文档：{0}".format(python_matrix_doc(payload)))
        return EXIT_FAIL

    ok_venv, why_venv = venv_health()
    if ok_venv or args.skip_deps:
        step("venv（自包含，不依赖任何 agent 宿主的解释器）", True,
             "{0}｜{1}".format(py, why_venv))
    else:
        if py.exists():
            print("   ! 已有的 venv 不能用（{0}）→ 重建（state/ 不动）".format(why_venv))
        # 自己删自己：本进程就跑在这个待删的 venv 里时，Windows 删不掉正在使用的 python.exe，
        # 只会"删一半"（真机踩到）→ 先换一个 venv 外的解释器重新执行自己，再回来重建。
        if py.exists() and argv0 and venv_dir.resolve() in argv0.parents:
            outside = [c for c in cands if c and not str(c).lower().startswith(str(venv_dir.resolve()).lower())]
            alt, alt_t, alt_p = pick_interpreter(outside + python_candidates(), want_py, want_plat)
            if alt and _tag_ok(alt_t, want_py) and _tag_ok(alt_p, want_plat):
                print("   ! 本安装器正跑在待重建的环境里（{0}）→ 换用 {1} 重新执行".format(argv0, alt))
                try:
                    os.execv(alt, [alt, str(Path(__file__).resolve())] + sys.argv[1:])
                except Exception as exc:
                    step("重建 venv", False, "换解释器重新执行失败：{0}".format(exc))
                    return EXIT_FAIL
            else:
                step("重建 venv", False, "本安装器跑在待重建的 venv 里，且机器上找不到另一个可用的 Python")
                print("  处理：用系统 Python（Python312 的 python.exe）直接跑一次本安装器的 setup，或先删掉 {0} 再重跑".format(venv_dir))
                return EXIT_FAIL
        if py.exists():
            shutil.rmtree(venv_dir, ignore_errors=True)
        if py.exists():
            step("重建 venv", False, "旧 venv 删不干净（多半被正在运行的进程占用）：{0}".format(py))
            print("  处理：关掉工作台（或任务管理器里占用它的进程）后重跑；也可手动删 {0} 再重跑".format(venv_dir))
            return EXIT_FAIL
        if not base:
            step("建 venv", False, "机器上找不到可用的 Python（要 3.10+）")
            return EXIT_FAIL
        cp = subprocess.run([base, "-m", "venv", str(venv_dir)], capture_output=True, text=True,
                            encoding="utf-8", errors="replace", env=utf8_env())
        if cp.returncode != 0:
            step("建 venv", False, (cp.stderr or cp.stdout)[-300:])
            return EXIT_FAIL
        # 建完必须**验真**：pyvenv.cfg 在、解释器跑得起来、标签匹配 —— 不然就是那个"只剩壳"的假 OK
        ok2, why2 = venv_health()
        step("venv（自包含，不依赖任何 agent 宿主的解释器）", ok2,
             "{0}｜{1}".format(py, why2 if not ok2 else "{0}（解释器 {1}）".format(why2, base)))
        if not ok2:
            return EXIT_FAIL

    # 2) 依赖（离线优先：包内 wheelhouse；wheelhouse 已在第 0 步算好）
    req = payload / "server" / "requirements.txt"
    if args.skip_deps:
        step("装依赖", True, "跳过（--skip-deps）")
    elif not req.is_file():
        step("装依赖", False, "包内没有 server/requirements.txt")
        return EXIT_FAIL
    else:
        # 环境预检（给客户的 agent 看的）：本包自带的二进制轮子只覆盖特定解释器/架构，
        # 对不上时 pip 只会说 "No matching distribution found"，客户看不懂 —— 先把话说清楚。
        bin_py, bin_plat = wheelhouse_binary_tags(wheelhouse)
        env_hint = ""
        # 判据要用 **venv 里那个** 解释器（跑 pip 的是它），不是跑 cli.py 的这个
        run_t, run_p = interpreter_tags_of(str(py))
        if bin_py and not (_tag_ok(run_t, bin_py) and _tag_ok(run_p, bin_plat)):
            env_hint = ("本包的离线轮子覆盖 {0}，venv 里的解释器是 {1} / {2} —— "
                        "多半装不上；照 {3} 检查/补装对应 Python 再来").format(
                wh_desc, run_t or "问不出来", run_p or "?",
                python_matrix_doc(payload))
            print("   ⚠ {0}".format(env_hint))
        cmd = [str(py), "-m", "pip", "install", "--disable-pip-version-check", "-q", "-r", str(req)]
        offline = args.offline or wheelhouse.is_dir()
        if offline and wheelhouse.is_dir():
            cmd += ["--no-index", "--find-links", str(wheelhouse)]
        elif args.index_url:
            cmd += ["--index-url", args.index_url]
        cp = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", env=utf8_env())
        if cp.returncode != 0 and offline and not args.offline:
            # wheelhouse 不匹配本机（换了平台/版本）→ 老实退回联网装，并把原因说出来
            print("   （wheelhouse 装不上，回退联网：{0}）".format((cp.stderr or "")[-160:]))
            cmd = [str(py), "-m", "pip", "install", "--disable-pip-version-check", "-q", "-r", str(req)]
            if args.index_url:
                cmd += ["--index-url", args.index_url]
            cp = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", env=utf8_env())
        mode = "离线（包内 wheelhouse）" if (offline and wheelhouse.is_dir() and "--no-index" in cmd) else "联网"
        step("装依赖（{0}）".format(mode), cp.returncode == 0, (cp.stdout or cp.stderr or "").strip()[-200:])
        if cp.returncode != 0:
            print("\n装依赖失败。**先别改代码，这是环境问题**：")
            print("  · 本包离线轮子支持的组合：解释器 {0}，平台 {1}".format(
                "/".join(sorted(bin_py)) or "（无平台轮子）", "/".join(sorted(bin_plat)) or "any"))
            print("  · 当前解释器：{0}　{1}".format(sys.version.split()[0], sys.platform))
            print("  · 照这份文档检查并补装对应 Python，然后重跑安装：{0}".format(python_matrix_doc(payload)))
            return EXIT_FAIL

    # 3) 拷文件（server / ui / agent / cli）
    # **先停服务再拷**：Windows 上服务进程的 CWD 就是 ERP_HOME/server，不停掉这一级目录
    # 既删不掉也建不了（重装/升级会直接失败）。顺带保证"跑的一定是新代码"。
    if running(home).get("running"):
        stop_service(home)
        print("   （安装：先停掉在跑的服务，换成新文件后再起）")
    copied: list[str] = []
    for name in ("server", "ui", "agent", "cli", "plugin-launcher"):
        src = payload / name
        if not src.is_dir():
            continue
        _copy_tree(src, home.root / name)
        copied += [str(p.relative_to(home.root)) for p in (home.root / name).rglob("*") if p.is_file()]
    # 命令入口必须是可执行的：`cli/erp` 在源码/包里是普通文件权限，不显式 chmod 的话 macOS 客户
    # 跑 `~/.takealot-erp/cli/erp doctor` 直接 permission denied（真机踩到；技能里就是让 agent 这么用）。
    if os.name == "posix":
        for shim in ("cli/erp",):
            p = home.root / shim
            if p.is_file():
                try:
                    p.chmod(0o755)
                except OSError:
                    pass
    step("安装文件进 ERP_HOME", bool(copied), "{0} 个文件".format(len(copied)))
    # 定时任务清单：装完就有（服务里内置调度器按它跑）。已存在则不动 —— 排期是用户自己的。
    jobs_note = install_default_jobs(home)
    step("定时任务清单（客户机自带调度，不依赖任何外部机器）", True, jobs_note)

    man = write_install_manifest(home, payload, copied)
    step("安装清单", man.is_file(), str(man))

    # 4) .env 占位（客户自己填出口/Key；已存在就不动）
    env_file = home.root / ".env"
    if not env_file.is_file():
        env_file.write_text(
            "# Takealot ERP 配置（只填密钥与出口，别的都在 config.yaml / 界面里）\n"
            "# 出口代理：留空=直连。国内机器一般填本机代理，例如 http://127.0.0.1:7890\n"
            "TAKEALOT_API_PROXY=\n"
            "# AI 文案/估值用的模型 Key（可选；不填则相关功能关闭，不会编数据）\n"
            "DEEPSEEK_API_KEY=\n",
            encoding="utf-8")
        step(".env 占位", True, str(env_file))
    else:
        step(".env 占位", True, "已存在，保留不动")

    # 4.5) v2 → v3 数据迁移（幂等）。**升级路径的关键一步**：v2 的 Seller Key / 店铺 /
    #      采集箱 / 缓存都在 Hermes 主目录下，v3 的数据目录是 ERP_HOME —— 是两个地方。
    #      不搬 = 客户升级完是空店，得重新录 Key（一家店只有一个有效 Key）。
    #      幂等规则：v3 已有 stores.json 就不动（要强行合并用 --force-migrate）；
    #      没发现 v2 数据就静默跳过；迁移失败**不阻断安装**（v2 数据还在原地，可复跑）。
    src_state = v2_state_dir()
    mig = home.root / "scripts" / "migrate_v2_state.py"
    # 脚本在包里的位置有两种：交付包根（<pkg>/migrate_v2_state.py，与 install.sh 同级）
    # 与源码树 scripts/（<payload>/scripts/migrate_v2_state.py）—— 两处都找，别假设。
    mig_src = next((p for p in (payload / "migrate_v2_state.py",
                                payload.parent / "migrate_v2_state.py",
                                payload / "scripts" / "migrate_v2_state.py")
                    if p.is_file()), None)
    try:
        if mig_src is not None and not mig.is_file():
            mig.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(mig_src, mig)
    except Exception:
        pass
    if not src_state.is_dir():
        step("v2 数据迁移", True, "跳过：没发现 v2 数据（{0}）".format(src_state))
    elif not mig.is_file():
        step("v2 数据迁移", False, "包内缺 migrate_v2_state.py；v2 数据仍在 {0}".format(src_state))
    elif (home.root / "state" / "stores.json").is_file() and not getattr(args, "force_migrate", False):
        step("v2 数据迁移", True, "跳过：v3 已有 stores.json（要合并：erp setup --force-migrate）")
    else:
        cp = subprocess.run([str(py), str(mig), "--from", str(src_state), "--to", str(home.root)],
                            capture_output=True, text=True, encoding="utf-8", errors="replace", env=utf8_env())
        tail = [l for l in (cp.stdout or cp.stderr or "").strip().splitlines() if l.strip()]
        step("v2 数据迁移（Seller Key / 店铺 / 采集箱）", cp.returncode == 0,
             (tail[-1][:160] if tail else "已合并"))
        if cp.returncode != 0:
            print("   （迁移失败不阻断安装；v2 数据仍在 {0}，修好后可复跑 erp setup）".format(src_state))

    # 5) 桌面入口（指向**装好的**那份：ERP_HOME/venv + ERP_HOME/server/cli.py）
    if args.no_shortcut:
        step("桌面入口", True, "跳过（--no-shortcut）")
    elif not _may_write_global_entry(home):
        step("桌面入口", True, "跳过：ERP_HOME 在临时目录（测试/通道安装不动用户的全局入口）")
    else:
        entry = make_shortcut(home, args.port)
        step("桌面入口（双击即用）", entry.is_file(), str(entry))

    # 5.5) Windows：登录自启（服务必须跑在用户会话里，否则窗口看不到、DPAPI 也解不开）
    if sys.platform == "win32":
        if _throwaway_home(home):
            step("登录自启", True, "跳过：ERP_HOME 在临时目录")
        else:
            res = ensure_windows_autostart(home)
            step("登录自启（用户会话；开机/双击都看得到窗口）", bool(res.get("ok")), str(res.get("detail", "")))
    # 5.6) macOS：登录自启（LaunchAgent）。定时任务跑在服务里 → 服务不随登录回来 = 任务没了。
    elif sys.platform == "darwin":
        if _throwaway_home(home):
            step("登录自启", True, "跳过：ERP_HOME 在临时目录")
        else:
            res = ensure_mac_autostart(home, args.port)
            step("登录自启（LaunchAgent；服务+定时任务开机自恢复）", bool(res.get("ok")), str(res.get("detail", "")))

    # 6) 起服务（装完即可用；装之前在跑的必须**重启**，否则跑的还是旧代码）
    if args.no_start:
        step("起服务", True, "跳过（--no-start）")
    else:
        was_running = running(home).get("running")
        if was_running:
            stop_service(home)
        # 再来一轮"清扫同 home 的所有实例"：反复 setup/自启会留下多个实例，
        # 它们会互相删 runtime.json、把端口占成 18791/18792/18793…（实测：Mac 上就这样把自己搞乱过）。
        left = stop_strays(home)
        if left:
            step("清掉残留实例（同一个数据目录）", True, "停掉了 {0} 个：{1}".format(
                len(left), ", ".join(str(p) for p in left)))
        installed_cli = home.root / "server" / "cli.py"
        runner = str(py) if py.exists() else (args.python or sys.executable)
        cp = subprocess.run([runner, str(installed_cli), "--erp-home", str(home.root), "--port", str(args.port),
                             "open", "--no-window"], capture_output=True, text=True,
                            encoding="utf-8", errors="replace", env=utf8_env())
        tail = (cp.stdout or cp.stderr).strip().splitlines()
        step("起服务（装完即可用{0}）".format("，已重启" if was_running else ""), cp.returncode == 0,
             (("刚换过文件 → 必须重启，让运行的就是新装的；" if was_running else "") +
              (tail[-1][:110] if tail else "")))

    # 6.4) 退休 v2 的宿主侧两半（老桌面插件 + 老 Hermes 插件）：它们指向的后端已经不在，
    #      留着就是两个侧栏项 + 一个报错的旧入口（客户会以为"工作流没被覆盖"）。改名备份，不删。
    if args.no_plugin:
        step("退休 v2 宿主残留", True, "跳过（--no-plugin）")
    elif _throwaway_home(home):
        step("退休 v2 宿主残留", True, "跳过：ERP_HOME 在临时目录（测试不动宿主）")
    else:
        retired = retire_v2_host_assets()
        step("退休 v2 宿主残留（老插件改名备份，不删）", True, "；".join(retired) or "没有 v2 残留")
        legacy_tasks = retire_legacy_windows_tasks()
        if legacy_tasks:
            step("清理老版本遗留的 Windows 计划任务", True, "；".join(legacy_tasks))

    # 6.5) 宿主侧入口插件（用户要有地方点进来：Hermes 侧栏项）
    if args.no_plugin:
        step("宿主入口插件", True, "跳过（--no-plugin）")
    elif hermes_home().is_dir() or os.environ.get("HERMES_HOME"):
        res = install_launcher_plugin(home, write=True)
        step("宿主入口插件（Hermes 侧栏「Takealot ERP」）", bool(res.get("ok") and res.get("written")),
             res.get("target") or res.get("detail") or ""
             + ("" if hermes_home().is_dir() else "（HERMES_HOME 指定的目录还不存在，已按指定路径创建）"))
    else:
        step("宿主入口插件", True, "这台机器没有 Hermes（{0} 不存在）—— 只用命令行/桌面入口即可".format(hermes_home()))

    # 6.6) 宿主技能 —— **客户机上 agent 的工作流**（升级必须换新，否则老用户还在按旧技能跑）
    if not args.no_plugin:
        hermes_here = hermes_home().is_dir() or bool(os.environ.get("HERMES_HOME"))
        codex_here = (Path.home() / ".codex").is_dir() or codex_skills_dir().is_dir()
        if hermes_here:
            res = install_skill_into("hermes", home, write=True)
            step("宿主技能（Hermes，覆盖式刷新）", bool(res.get("ok")), res.get("detail") or "")
        if codex_here:
            res = install_skill_into("codex", home, write=True)
            step("宿主技能（Codex，符号链接 → 产品升级自动跟新）", bool(res.get("ok")), res.get("detail") or "")
            res2 = write_codex_agents_block(home)
            step("Codex AGENTS 片段（受管区块，自动换新）", bool(res2.get("ok")), res2.get("detail") or "")
        if not hermes_here and not codex_here:
            step("宿主技能（Hermes/Codex）", True,
                 "这台机器没有 Hermes/Codex 技能目录 —— 跳过（技能文本仍随包在 ERP_HOME/agent/skills）")

    # 7) 自检
    print("\n── 装完自检")
    code = doctor(home, as_json=False)
    ok = all(s["ok"] for s in steps) and code == EXIT_OK
    out({"ok": ok, "erpHome": str(home.root), "version": VERSION, "steps": steps,
         "nextSteps": ["填 ERP_HOME/.env 里的出口代理（用代理才需要）",
                       "双击桌面入口或跑 erp open，在界面里绑定店铺 Seller Key",
                       "agent 侧挂 MCP：erp mcp config --host hermes|codex --write"]},
        getattr(args, "json", False),
        "装完了：{0}\n下一步：① 填 {1} 的出口代理（只有用代理才需要）② 打开工作台绑店铺 Key ③ 挂 MCP".format(
            home.root, env_file))
    return EXIT_OK if ok else EXIT_FAIL


# ---------------------------------------------------------------------------
# 桌面入口 / 开机常驻
# ---------------------------------------------------------------------------

def core_path() -> Path:
    """核心 plugin_api.py 的路径（跟着服务端的解析走，别两处各写一份）。"""
    return srv.CORE_API


def ensure_windows_autostart(home: HOME) -> dict:
    """Windows：写一个**无空格路径**的启动器 + 注册登录自启（HKCU Run）。

    为什么要它：Windows 上服务必须在**已登录用户会话**里跑，否则
    ① GUI 窗口用户看不见（会话 0 起的 Edge 不会显示）；② DPAPI 在同用户下才解得开。
    ssh/服务宿主起的进程默认落在会话 0 —— 真机踩过「点了没反应、服务却说已打开」。
    自启指向 ERP_HOME\\start-workbench.cmd（路径无空格，计划任务/注册表都不用再引号嵌套）。
    """
    starter = home.root / "start-workbench.cmd"
    runner = installed_runner(home)
    if not runner:
        return {"ok": False, "detail": "还没装好（缺 venv 或 server/cli.py）"}
    content = (
        "@echo off\r\n"
        "rem Takealot ERP: start the server in the logged-on session and open the workbench.\r\n"
        '"{python}" "{cli}" open --app --port 18791\r\n'
    ).format(python=runner[0], cli=runner[1])
    try:
        starter.write_text(content, encoding="ascii", newline="")
    except OSError as exc:
        return {"ok": False, "detail": str(exc)[:120]}
    cp = subprocess.run(["reg", "add", r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run",
                         "/v", "TakealotERP", "/t", "REG_SZ", "/d", str(starter), "/f"],
                        capture_output=True, text=True, encoding="utf-8", errors="replace")
    return {"ok": cp.returncode == 0, "detail": "{}（登录自启 → {}）".format(starter, "HKCU Run")}


# ---------------------------------------------------------------------------
# 自更新（给「已经装机的用户」升级用）
# ---------------------------------------------------------------------------
#: 公开更新通道（GitHub 上放 update.json 与包体）。多通道 = 国内 raw 被墙/DNS 抽风时逐个降级。
#: 环境变量 ERP_UPDATE_CHANNEL 或 --channel 可覆盖；file:// 也支持（离线自测就是这么跑的）。
UPDATE_CHANNELS = (
    "https://raw.githubusercontent.com/liuyuhan180661-cell/takealot-erp-update/main/",
    # 实时反代（国内可达且**不留缓存**）：raw 被墙/DNS 抽风，或 raw 与 jsDelivr 都被 CDN 缓存压住时，
    # 靠它拿到**刚发布**的版本。真机实测（Windows，刚推完 5 分钟）：raw 与 jsDelivr 都还报旧版本，
    # gh-proxy / ghfast 已经是新版本 —— 没有这条，客户会被判定"没有更新"，修复等于没发出去。
    "https://gh-proxy.com/https://raw.githubusercontent.com/liuyuhan180661-cell/takealot-erp-update/main/",
    "https://ghfast.top/https://raw.githubusercontent.com/liuyuhan180661-cell/takealot-erp-update/main/",
    # jsDelivr 走 CDN：省流量，但**分支(@main)解析会滞后十几小时**（purge 也清不掉），只能放最后兜底。
    "https://cdn.jsdelivr.net/gh/liuyuhan180661-cell/takealot-erp-update@main/",
)


def _channel_urls(channel: str | None = None) -> list[str]:
    if channel:
        return [channel.rstrip("/") + "/"]
    env = (os.environ.get("ERP_UPDATE_CHANNEL") or "").strip()
    if env:
        return [env.rstrip("/") + "/"]
    return list(UPDATE_CHANNELS)


def _http_get(url: str, timeout: float = 30.0) -> bytes:
    """取一个 URL。file:// 也支持（离线自测）。

    代理/中间人环境（Clash TUN、企业 TLS 检查）会让 Python 的证书校验失败 ——
    这是**客户机真会遇到**的情况：报 SSL: CERTIFICATE_VERIFY_FAILED，看着像"更新坏了"。
    两条出路：
      · 正规：把中间人的根证书给 Python（`SSL_CERT_FILE=/path/ca.pem`）—— 默认就会被读到；
      · 逃生口：`ERP_UPDATE_INSECURE=1` 显式关掉校验（会**大声提醒**；包体仍必须过 sha256，
        所以拿到的东西还是被指纹锁住的 —— 但仍建议优先用上面那条）。
    """
    if url.startswith("file://"):
        return Path(url[7:]).read_bytes()
    req = urllib.request.Request(url, headers={
        "User-Agent": "takealot-erp-updater",
        # CDN（jsDelivr 这类）会把 update.json 缓存十几个小时：刚发布的新版本客户看不到，
        # 报「没有更新」—— 修复就白发了。请求端显式要新鲜副本。
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    })
    kw: dict = {"timeout": timeout}
    if os.environ.get("ERP_UPDATE_INSECURE") == "1":
        import ssl
        kw["context"] = ssl._create_unverified_context()
        print("⚠️ ERP_UPDATE_INSECURE=1：这次不校验证书（包体仍会对 sha256）")
    with urllib.request.urlopen(req, **kw) as resp:  # noqa: S310 - 通道是固定配置项
        return resp.read()


def _cache_bust(url: str) -> str:
    """给 http(s) URL 加一个变化的时间戳，逼中间 CDN 回源。

    **file:// 绝不能加**：查询串会被当成文件名的一部分，离线自测/内网通道直接读不到
    （出包闸门当场抓到过）。镜像里的 `ERP_UPDATE_CHANNEL=file://...` 就是这条路。
    """
    if url.startswith("file://"):
        return url
    return "{0}{1}cb={2}".format(url, "&" if "?" in url else "?", int(time.time()))


def _version_key(text: str) -> tuple:
    """版本号比较键：``2026.10.07.4`` → ``(2026, 10, 7, 4)``。

    只比"相等/不等"会在通道版本比本地旧时（回滚、或本机当面装了更新的包）反过来提示
    "可更新" → **降级**。取数字段比大小最稳（也容忍 ``v`` 前缀、多余后缀）。
    """
    return tuple(int(x) for x in re.findall(r"\d+", str(text or "")))


def _installed_build(home: HOME) -> str:
    try:
        data = json.loads((home.root / "install.json").read_text(encoding="utf-8"))
        return str(data.get("build") or data.get("version") or "")
    except Exception:
        return ""


def cmd_update(args, home: HOME) -> int:
    """检查/应用更新：取通道清单 → 比对构建号 → 下载 → **校验 sha256** → 用新包的 setup 覆盖安装。

    纪律：**校验不过就拒装**（拒装时磁盘上什么都不动）；比不出新旧就明说，不猜。
    """
    import hashlib
    import shutil
    import tempfile
    import zipfile

    manifest, used, errors = None, "", []
    for base in _channel_urls(getattr(args, "channel", "") or None):
        try:
            manifest = json.loads(_http_get(_cache_bust(base + "update.json"), timeout=25).decode("utf-8"))
            used = base
            break
        except Exception as exc:
            errors.append("{0} -> {1}".format(base, str(exc)[:70]))
    if not manifest:
        out({"ok": False, "error": "通道都取不到 update.json", "tried": errors}, getattr(args, "json", False),
            "取不到更新清单（" + "；".join(errors[:2]) + "）")
        return EXIT_FAIL

    remote = str(manifest.get("version") or "")
    local = _installed_build(home)
    payload = manifest.get("payload") or {}
    zip_name = str(payload.get("name") or "")
    want_sha = str(payload.get("sha256") or "")
    info = {"ok": True, "channel": used, "local": local, "remote": remote,
            "notes": manifest.get("notes") or "", "zip": zip_name, "sha256": want_sha}
    if args.check and remote == local:
        out(info, args.json, "已是最新（{0}）".format(local or remote))
        return EXIT_OK
    # 版本号只比"相等"是不够的：通道回滚、或本机装了更新的包（比如当面给的 zip）时，
    # 远端比本地**旧**，裸比不相等就会提示"可更新"并真的把旧包装上（降级）。按数字段比大小。
    if not getattr(args, "force", False) and _version_key(remote) and _version_key(local) \
            and _version_key(remote) < _version_key(local):
        info["downgrade"] = True
        out(info, args.json, "通道没有更新的版本（本地 {0} ≥ 通道 {1}）—— 不动；要强制重装加 --force".format(local, remote))
        return EXIT_OK
    if not zip_name:
        out({"ok": False, "error": "update.json 缺 payload.name"}, args.json, "更新清单不完整")
        return EXIT_FAIL
    if remote == local and not getattr(args, "force", False) and not args.check:
        out(info, args.json, "已是最新（{0}）—— 要强制重装加 --force".format(local or remote))
        return EXIT_OK
    # `--check` 到这里就够了：**别去下那 8.5MB 包体**。
    # 实测踩过：check 也走完整下载，国内 raw 卡满 120 秒才回落到 gh-proxy —— 一个"只看一眼"的动作
    # 要等两分钟，agent 自愈时"先 dry-run 再 apply"就变得很贵。真正的校验（sha256/逐文件）属于 apply。
    if args.check:
        info["downloadNeeded"] = True
        info["size"] = payload.get("size")
        out(info, args.json, "可更新：{0} → {1}（{2}，{3} 字节，未下载）".format(
            local or "?", remote, zip_name, payload.get("size") or "?"))
        return EXIT_OK

    tmp = Path(tempfile.mkdtemp(prefix="erp-update-"))
    # 顺手清掉历史遗留的临时下载目录（更新中断/被杀时会留下；真机上攒了 6 个）
    try:
        import time as _t
        for stale in Path(tempfile.gettempdir()).glob("erp-update-*"):
            if stale.is_dir() and (_t.time() - stale.stat().st_mtime) > 6 * 3600:
                shutil.rmtree(stale, ignore_errors=True)
    except Exception:
        pass
    zip_path = tmp / zip_name
    # 包体从**所有**通道里挑第一个"下得下来且 sha256 对得上"的：
    # 国内网络常见 raw 取 update.json（小文件）能过、8MB 包体被掐断（真机实测 Remote end closed），
    # 只认 manifest 那条通道就会把升级卡死。每一份都过 sha256，安全底线不变。
    # 每个通道有**自己的预算**（120s）：网络停滞时要尽快轮到下一个通道，不能让用户干等十几分钟
    # （真机实测：raw 停滞 + 900s 超时 = 更新像死了一样挂着，服务和界面都停在旧版）。
    BODY_TIMEOUT = 120.0
    body_candidates = [used] + [u for u in _channel_urls(getattr(args, "channel", "") or None) if u != used]
    digest, body_used, dl_errors, mismatch = "", "", [], None
    for cand in body_candidates:
        try:
            # 带 cb：CDN 压着旧字节时换个 URL 强制回源（真正的底线仍是下面的 sha256）
            zip_path.write_bytes(_http_get(_cache_bust(cand + zip_name), timeout=BODY_TIMEOUT))
        except Exception as exc:
            dl_errors.append("{0} -> {1}".format(cand, str(exc)[:60]))
            continue
        got = hashlib.sha256(zip_path.read_bytes()).hexdigest()
        if want_sha and got != want_sha:
            mismatch = (cand, got)
            dl_errors.append("{0} -> sha256 不匹配".format(cand))
            continue
        digest, body_used = got, cand
        break
    if not digest:
        if mismatch:
            out({"ok": False, "error": "sha256 不匹配 —— 已拒装", "want": want_sha, "got": mismatch[1],
                 "tried": dl_errors}, args.json,
                "⚠️ 校验不过，**没有安装**（want {0}… got {1}…）".format(want_sha[:12], mismatch[1][:12]))
        else:
            out({"ok": False, "error": "下载失败: " + "；".join(dl_errors[:3]), "tried": dl_errors}, args.json,
                "下载失败（每个通道都试过了）：" + "；".join(dl_errors[:3]))
        return EXIT_FAIL
    info["downloadedSha256"] = digest
    info["bodyChannel"] = body_used
    if args.check:
        out(info, args.json, "可更新：{0} → {1}（{2}）".format(local or "?", remote, zip_name))
        return EXIT_OK

    try:
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(tmp / "x")
        cands = list((tmp / "x").rglob("payload/server/cli.py"))
        if not cands:
            out({"ok": False, "error": "包结构不对：找不到 payload/server/cli.py"}, args.json, "包结构不对，已中止")
            return EXIT_FAIL
        new_cli, new_payload = cands[0], cands[0].parents[1]
        runner = str(PY) if Path(PY).is_file() else sys.executable
        cp = subprocess.run([runner, str(new_cli), "setup", "--source", str(new_payload),
                             "--erp-home", str(home.root), "--port", str(args.port), "--offline"],
                            capture_output=True, text=True, encoding="utf-8", errors="replace", env=utf8_env())
        ok = cp.returncode == 0
        tail = (cp.stdout or cp.stderr or "").splitlines()
        info.update({"applied": ok, "exit": cp.returncode,
                     "selfCheck": next((l.strip() for l in tail if "RESULT" in l), "")})
        if not ok:
            # **失败必须看得见**：以前提示"上面是它的输出"，但那几行压根没打印过 —— 升级半路死掉时
            # 用户/agent 只看到一句"更新失败"，无从下手（真机就是这么被藏住的）。
            info["setupOutput"] = tail[-15:]
            print("── 新包 setup 输出（最后 {0} 行）:".format(min(15, len(tail))))
            for line in tail[-15:]:
                print("   " + line)
        out(info, args.json, "{0}：{1} → {2}｜{3}".format(
            "已更新" if ok else "更新失败（新包 setup 报错，上面是它的输出）", local or "?", remote, info["selfCheck"]))
        return EXIT_OK if ok else EXIT_FAIL
    finally:
        # 正常失败/异常也会清掉临时目录（被硬杀属于无法捕获的情况，由下次更新时 >6h 的清扫兜底 ——
        # 真机上攒了 6 个 erp-update-* 就是这条路径漏的）
        shutil.rmtree(tmp, ignore_errors=True)


# ---------------------------------------------------------------------------
# 定时任务（内置调度器的本地控制口）
# ---------------------------------------------------------------------------
#: 客户机装完就有的默认任务。**只读的两个默认开**；写价的默认**停用**（红：没明确授权不许自动写）。
DEFAULT_JOBS = {
    "schema": 1,
    "note": "定时任务的排期（改这里下次 tick 生效）。脚本在 server/jobs/ 里，随升级更新；本文件是你的配置，升级不会覆盖。",
    "jobs": [
        {
            "id": "logistics-patrol",
            "name": "物流巡查（送仓/签收/退货）",
            "kind": "read",
            "script": "logistics_patrol.py",
            "args": ["--days", "7"],
            "schedule": {"kind": "cron", "cron": "30 8,15 * * *"},
            "enabled": True,
            "timeoutSec": 900,
        },
        {
            "id": "buybox-report",
            "name": "买盒盯盘日报",
            "kind": "read",
            "script": "buybox_report.py",
            "args": ["--hours", "24"],
            "schedule": {"kind": "cron", "cron": "0 9 * * *"},
            "enabled": True,
            "timeoutSec": 900,
        },
        {
            "id": "order-patrol",
            "name": "订单巡检（待发货 / 亏损单）",
            "kind": "read",
            "script": "order_patrol.py",
            "args": ["--days", "7"],
            "schedule": {"kind": "cron", "cron": "0 8 * * *"},
            "enabled": True,
            "timeoutSec": 900,
        },
        {
            "id": "po-tracking",
            "name": "PO / 送仓单跟踪（逾期与临期）",
            "kind": "read",
            "script": "po_tracking.py",
            "args": ["--days", "7"],
            "schedule": {"kind": "cron", "cron": "30 9 * * *"},
            "enabled": True,
            "timeoutSec": 900,
        },
        {
            "id": "crawl-pull",
            "name": "定时抓取（刷新公开页/目录缓存）",
            "kind": "read",
            "script": "crawl_pull.py",
            "schedule": {"kind": "interval", "minutes": 360},
            "enabled": True,
            "timeoutSec": 1800,
        },
        {
            "id": "buybox-round",
            "name": "买盒盯盘巡检（会改价 —— 需明确授权）",
            "kind": "write",
            "requiresAuthorization": True,
            "script": "repricing_round.py",
            # 新鲜度是抢回时效的关键：要动的行卡龄 >4h 就先重抓；每轮再轮转刷 40 个占优行
            # （丢盒发现延迟 = 在售行数 / 40 × 轮间隔 ≈ 200/40×2h = 10 小时；想更快就调大 refresh-held）
            "args": ["--stale-hours", "4", "--refresh-held", "40"],
            "schedule": {"kind": "interval", "minutes": 120},
            "enabled": False,
            "timeoutSec": 1800,
            "note": (
                "默认停用。它会在授权范围内自动改价 —— 开启前必须："
                "① 工作台里明确授权一次自动跟价（授权是逐店的、升级安装不继承）；"
                "② 这个版本上写价路径还没移植完（v3 跑会 ABORT exit 2），移植并验收后再开。"
            ),
        },
    ],
}


def _jobs_file(home: HOME) -> Path:
    return home.root / "jobs" / "jobs.json"


def install_default_jobs(home: HOME, force: bool = False) -> str:
    """把默认任务清单放进去。

    规则（升级安全）：
      · 没有 → 整份写入；
      · 已有 → **只补缺的 id**（版本升级带来的新任务要能到老装机上），
        **绝不动用户已有的开关/排期**（他关掉的就是要关掉的），更不会因为升级就把写价任务打开；
      · --force 才整份重置（诊断用）。
    """
    path = _jobs_file(home)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or force:
        path.write_text(json.dumps(DEFAULT_JOBS, ensure_ascii=False, indent=2), encoding="utf-8")
        return ("已写入 " if not force else "已重置 ") + str(path)

    try:
        cur = json.loads(path.read_text(encoding="utf-8")) or {}
    except Exception:
        return "已有清单读不懂（没动它，请人工看一眼）：" + str(path)
    jobs = cur.get("jobs") if isinstance(cur, dict) else None
    if not isinstance(jobs, list):
        return "已有清单格式不对（没动它）：" + str(path)
    have = {str(j.get("id")) for j in jobs if isinstance(j, dict)}
    added = [j for j in DEFAULT_JOBS["jobs"] if str(j.get("id")) not in have]
    if not added:
        return "已是最新（{0} 个任务，未改动）".format(len(jobs))
    jobs.extend(json.loads(json.dumps(added)))   # 深拷贝，别把常量污染了
    cur["jobs"] = jobs
    cur.setdefault("schema", 1)
    _write_jobs_file(path, cur)
    return "补了 {0} 个新任务：{1}（原有的开关/排期一个没动）".format(
        len(added), "、".join(str(j.get("id")) for j in added))


def _write_jobs_file(path: Path, data: dict) -> None:
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _scheduler(home: HOME):
    srv_dir = str(home.root / "server")
    if srv_dir not in sys.path:
        sys.path.insert(0, srv_dir)
    import scheduler as _s
    return _s


def cmd_job(args, home: HOME) -> int:
    """定时任务：list / run <id> / enable|disable <id> / logs [id] / install-defaults。

    走本地文件（jobs.json + state/jobs_status.json），不依赖服务在跑 —— 服务不在也能看、也能手动跑一轮。
    真正"按点自动跑"的是常驻服务里的调度线程；这里是同一个类的手动入口，口径一致。
    """
    S = _scheduler(home)
    sched = S.Scheduler(home.root, python=sys.executable)
    act = args.job_action

    if act == "install-defaults":
        msg = install_default_jobs(home, force=bool(args.force))
        out({"ok": True, "detail": msg, "file": str(_jobs_file(home))}, args.json, msg)
        return EXIT_OK

    if act in ("enable", "disable"):
        items = sched.jobs()
        hit = False
        for j in items:
            if str(j.get("id")) == args.job_id:
                if act == "enable" and j.get("kind") == "write" and not _watch_authorized(home):
                    out({"ok": False, "id": args.job_id, "error": "还没授权跟价：先问用户同不同意",
                         "howTo": "问一句「要不要我帮你盯价、丢了买盒就按规则压价抢回来？范围/间隔说清楚」；"
                                  "同意后执行 erp repricing authorize --store <店> --min <小> --max <大>"},
                        args.json,
                        "⚠️ 没开：这是会改价的任务，先问用户是否授权 →（同意后）erp repricing authorize --store <店>")
                    return EXIT_FAIL
                j["enabled"] = act == "enable"
                hit = True
        if not hit:
            out({"ok": False, "error": "没有这个任务: " + str(args.job_id)}, args.json, "没有这个任务")
            return EXIT_FAIL
        sched.write_jobs(items)
        out({"ok": True, "id": args.job_id, "enabled": act == "enable"}, args.json,
            "{0}：{1}".format(args.job_id, "已启用" if act == "enable" else "已停用"))
        return EXIT_OK

    if act == "set":
        items = sched.jobs()
        hit = None
        for j in items:
            if str(j.get("id")) == args.job_id:
                hit = j
        if hit is None:
            out({"ok": False, "error": "没有这个任务: " + str(args.job_id)}, args.json, "没有这个任务")
            return EXIT_FAIL
        changed = []
        if args.interval is not None:
            hit["schedule"] = {"kind": "interval", "minutes": float(args.interval)}
            changed.append("排期=每 {0:g} 分钟".format(float(args.interval)))
        if args.cron:
            hit["schedule"] = {"kind": "cron", "cron": str(args.cron)}
            changed.append("排期=cron {0}".format(args.cron))
        if args.args:
            import shlex as _shlex
            hit["args"] = _shlex.split(args.args)
            changed.append("参数=" + args.args)
        if args.timeout:
            hit["timeoutSec"] = int(args.timeout)
            changed.append("超时={0}s".format(int(args.timeout)))
        if not changed:
            out({"ok": False, "error": "什么都没改：给 --interval / --cron / --args / --timeout 之一"},
                args.json, "什么都没改（给一个要改的值）")
            return EXIT_FAIL
        sched.write_jobs(items)
        out({"ok": True, "id": args.job_id, "changed": changed, "job": hit}, args.json,
            "{0}：{1}（已写进 jobs.json，下一轮 tick 生效）".format(args.job_id, "；".join(changed)))
        return EXIT_OK

    if act == "run":
        jobs = [j for j in sched.jobs() if str(j.get("id")) == args.job_id]
        if not jobs:
            out({"ok": False, "error": "没有这个任务: " + str(args.job_id)}, args.json, "没有这个任务")
            return EXIT_FAIL
        res = sched.run_job(jobs[0], manual=True)
        tail = ""
        try:
            tail = Path(res.get("logFile", "")).read_text(encoding="utf-8", errors="replace")
        except Exception:
            pass
        if args.json:
            out(res, True)
        else:
            print(tail or (res.get("summary") or ""))
            print("\n退出码 {0}｜{1}".format(res.get("exitCode"), "OK" if res.get("ok") else "非 0（看上面）"))
        return EXIT_OK if res.get("ok") else EXIT_FAIL

    if act == "logs":
        recs = sched.status()["jobs"]
        if args.job_id:
            recs = [r for r in recs if r["id"] == args.job_id]
            if not recs:
                out({"ok": False, "error": "没有这个任务"}, args.json, "没有这个任务")
                return EXIT_FAIL
        if args.json:
            out({"ok": True, "jobs": recs}, True)
            return EXIT_OK
        for r in recs:
            print("— {0}（{1}）".format(r.get("name"), r["id"]))
            print("   排期 {0}｜上次 {1}｜退出码 {2}｜{3}".format(
                r.get("scheduleText"), (r.get("lastRunAt") or "还没跑过"), r.get("lastExitCode"),
                (r.get("lastLogFile") or "")))
            if r.get("alert"):
                print("   告警 {0}".format(r["alert"]))
            if r.get("lastSummary"):
                print("   摘要 {0}".format(r["lastSummary"][:160]))
        return EXIT_OK

    # list（默认）
    st = sched.status()
    if args.json:
        out(st, True)
        return EXIT_OK
    print("定时任务（跑在**本机服务**里，不依赖别的机器；{} 个）".format(len(st["jobs"])))
    print("调度线程：{0}｜tick {1}s｜清单 {2}".format(
        ("在跑（{0}）".format(st.get("runningWhy")) if st["running"] else "没跑 —— " + str(st.get("runningWhy") or "服务没起")),
        st["tickSeconds"], st["jobsFile"]))
    for r in st["jobs"]:
        print("  [{0}] {1}｜{2}｜{3}".format(
            "开" if r["enabled"] else "停", r["id"], r["scheduleText"],
            ("下次 " + r["nextRunAt"][:16]) if r.get("nextRunAt") else "不排期"))
        print("        上次：{0}（退出码 {1}）".format(r.get("lastRunAt") or "还没跑过", r.get("lastExitCode")))
        if r.get("alert"):
            print("        " + r["alert"])
    return EXIT_OK


# ---------------------------------------------------------------------------
# 跟价授权（**对话授权**：agent 问一句，用户同意即可 —— 不再要求去界面点）
# ---------------------------------------------------------------------------
def _watch_file(home: HOME) -> Path:
    return home.state / "repricing_watch.json"


def _watch_authorized(home: HOME) -> bool:
    try:
        return bool((json.loads(_watch_file(home).read_text(encoding="utf-8")) or {}).get("authorized"))
    except Exception:
        return False


def cmd_repricing(args, home: HOME) -> int:
    """跟价授权与状态：status / authorize / revoke。

    为什么是对话授权：跟价抢购物车必须**闭环**（丢盒 → 立刻压价抢回），
    卡一层"必须去界面点一下"就永远晚一步 —— 客户要的是 agent 问一句、用户说"行"就开跑。
    授权仍然**有边界、有记录、可撤回**：范围（店/最小-最大下探/底价/单轮上限）写进
    state/repricing_watch.json，脚本每轮都按它算，且只走后端唯一写价路径（逐条审计 + 回读）。
    """
    path = _watch_file(home)
    cur = {}
    if path.is_file():
        try:
            cur = json.loads(path.read_text(encoding="utf-8")) or {}
        except Exception:
            cur = {}
    act = args.repricing_action

    if act == "revoke":
        cur["authorized"] = False
        cur["revokedAt"] = dt_stamp()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(cur, ensure_ascii=False, indent=2), encoding="utf-8")
        out({"ok": True, "authorized": False, "file": str(path)}, args.json,
            "已撤回跟价授权（正在跑的价不再自动变；要还原就手工改价）")
        return EXIT_OK

    if act == "authorize":
        stores = [s.strip() for s in (args.store or "").split(",") if s.strip()]
        if not stores:
            info = running(home)
            sid = ""
            try:
                _st, got = http_json("http://127.0.0.1:{0}{1}/settings".format(
                    info.get("port"), API_PREFIX), home.read_runtime().get("token"))
                sid = str((got or {}).get("activeStoreId") or "")
            except Exception:
                sid = ""
            if not sid:
                out({"ok": False, "error": "不知道给哪家店跟价：用 --store <店铺id> 指定（或先在界面选定店铺）"},
                    args.json, "缺店铺：加 --store <店铺id>")
                return EXIT_FAIL
            stores = [sid]
        lo = float(args.min if args.min is not None else cur.get("minUndercut") or 1)
        hi = float(args.max if args.max is not None else cur.get("maxUndercut") or 50)
        if not (0 < lo <= hi):
            out({"ok": False, "error": "下探范围不合法：0 < min <= max"}, args.json, "下探范围不合法")
            return EXIT_FAIL
        data = {
            "authorized": True, "authorizedAt": dt_stamp(), "authorizedVia": "conversation",
            "authorizedNote": str(args.note or "agent 已在对话里征得用户同意"),
            "intervalHours": float(args.interval if args.interval is not None else cur.get("intervalHours") or 2),
            "minUndercut": lo, "maxUndercut": hi,
            "floorPrice": args.floor if args.floor is not None else cur.get("floorPrice"),
            "ceilingPrice": args.ceiling if args.ceiling is not None else cur.get("ceilingPrice"),
            "maxChangesPerRun": int(args.max_changes if args.max_changes is not None
                                    else cur.get("maxChangesPerRun") or 10),
            "autoEnabled": True, "storeIds": stores,
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        out({"ok": True, **data, "file": str(path)}, args.json,
            "已授权跟价：店铺 {0}｜下探 R{1}~R{2}｜每 {3} 小时一轮｜单轮上限 {4} 条\n"
            "下一步：erp job enable buybox-round（开自动跟价任务）；撤回：erp repricing revoke".format(
                ", ".join(stores), lo, hi, data["intervalHours"], data["maxChangesPerRun"]))
        return EXIT_OK

    # status（默认）
    ledger = home.state / "repricing_watch_log.md"
    tail = ""
    if ledger.is_file():
        lines = [l for l in ledger.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()]
        tail = "\n".join(lines[-8:])
    if args.json:
        out({"ok": True, "authorized": bool(cur.get("authorized")), "config": cur,
             "ledger": str(ledger), "ledgerTail": tail}, True)
        return EXIT_OK
    if cur.get("authorized") is True:
        print("跟价：**已授权**（{0}，{1}）".format(cur.get("authorizedAt"), cur.get("authorizedVia") or ""))
        print("  店铺 {0}｜下探 R{1}~R{2}｜每 {3} 小时｜单轮上限 {4}｜底价 {5}｜封顶 {6}".format(
            ", ".join(cur.get("storeIds") or []), cur.get("minUndercut"), cur.get("maxUndercut"),
            cur.get("intervalHours"), cur.get("maxChangesPerRun"), cur.get("floorPrice"), cur.get("ceilingPrice")))
    else:
        print("跟价：**未授权**（脚本会 ABORT，一个价都不写）")
        print("  要开：先问用户同意 → erp repricing authorize --store <店铺id> --min 1 --max 50")
    print("  账本：{0}".format(ledger))
    if tail:
        print("  最近几行：")
        for l in tail.splitlines():
            print("    " + l)
    return EXIT_OK


def dt_stamp() -> str:
    import datetime as _dt
    return _dt.datetime.now().astimezone().replace(microsecond=0).isoformat()


def desktop_entry_path() -> Path:
    """桌面入口路径。ERP_ENTRY_DIR 可覆盖（自动化测试/多环境不污染 ~/Applications）。"""
    override = (os.environ.get("ERP_ENTRY_DIR") or "").strip()
    if override:
        d = Path(override).expanduser()
        return d / ("Takealot ERP 工作台.command" if sys.platform == "darwin" else "Takealot ERP 工作台")
    if sys.platform == "darwin":
        return Path.home() / "Applications" / "Takealot ERP 工作台.command"
    if sys.platform == "win32":  # pragma: no cover - Windows 真机验证
        # 桌面可能被 OneDrive 重定向（`%USERPROFILE%\Desktop` 就成空目录了）→ 按存在性挑
        up = os.environ.get("USERPROFILE") or str(Path.home())
        for cand in (os.path.join(up, "Desktop"),
                     os.path.join(os.environ.get("OneDrive") or "", "Desktop"),
                     os.path.join(os.environ.get("OneDrive") or "", "桌面")):
            if cand and Path(cand).is_dir():
                return Path(cand) / "Takealot ERP 工作台.cmd"
        return Path(up) / "Desktop" / "Takealot ERP 工作台.cmd"
    return Path.home() / ".local" / "share" / "applications" / "takealot-erp.desktop"


def installed_runner(home: HOME) -> tuple[Path, Path] | None:
    """装好的那份 (解释器, cli.py) —— 存在就用它（桌面入口必须指向它）。

    为什么要专门判：交付包解压出来的 payload 目录（下载目录/临时目录）**随时会被清掉**，
    入口若指向那里，用户一清就双击失效（真机验收当场挖到的 bug）。
    """
    py = home.root / "venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    cli = home.root / "server" / "cli.py"
    return (py, cli) if py.is_file() and cli.is_file() else None


def v2_state_dir() -> Path:
    """老形态（Hermes 插件）的 state 目录 —— v2 的 Seller Key / 店铺 / 采集箱都在这里。

    v2 装在 Hermes 主目录下（Windows ``%LOCALAPPDATA%\\hermes``、macOS/Linux
    ``~/.hermes``），v3 换成了 ERP_HOME（Windows ``%LOCALAPPDATA%\\TakealotERP``、
    macOS ``~/.takealot-erp``）——**不是同一个地方**，所以升级必须显式搬一次，
    否则客户升级后是空店，得重新录 Key（而一家店只有一个有效 Key）。
    """
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
        return base / "hermes" / "plugins" / "takealot-erp" / "state"
    return Path.home() / ".hermes" / "plugins" / "takealot-erp" / "state"


def _throwaway_home(home: HOME) -> bool:
    """ERP_HOME 落在临时目录 = 测试/通道安装 —— 不许它覆盖用户的全局入口。

    桌面入口和 LaunchAgent 都是**单一全局文件**（macOS：``~/Applications/Takealot ERP
    工作台.command`` 与 ``~/Library/LaunchAgents/com.takealot.erp.plist``）。真机踩过：
    一次带临时 ``--erp-home`` 的安装把这两个文件改写成指向
    ``/private/var/folders/…/T/erp-chan-…``，临时目录一被清理，自启与桌面图标双双变
    死链（launchd 状态 = 退出码 2），而用户从界面上完全看不出来。
    """
    try:
        root = Path(home.root).resolve()
    except Exception:
        return False
    text = str(root)
    if "erp-update" in text or "erp-chan" in text or "erp-home" in text:
        return True
    try:
        import tempfile

        tmp = Path(tempfile.gettempdir()).resolve()
        return root == tmp or tmp in root.parents
    except Exception:
        return False


def _may_write_global_entry(home: HOME) -> bool:
    """能不能写用户那**一份全局**桌面入口。

    临时 ERP_HOME（测试/通道安装）不许动它 —— 真机踩过：一次带临时 ``--erp-home`` 的
    安装把 ``~/Applications/Takealot ERP 工作台.command`` 与 LaunchAgent 一起改写成临时
    目录，清理后双双变死链。但测试若显式给了 ``ERP_ENTRY_DIR``（写进沙箱目录），那是它
    自己的地盘，照写（P5 闸门就是这么跑客户机的第一次安装的）。
    """
    if not _throwaway_home(home):
        return True
    return bool((os.environ.get("ERP_ENTRY_DIR") or "").strip())


def v2_host_asset_dirs() -> list[Path]:
    """v2 留在宿主里的两半：老桌面插件（ID=``takealot-erp``）与老 Hermes 插件。

    升级到 v3 后这两半指向的后端已经不在（它们的接口是 Hermes 插件 API，不是 v3 的
    常驻服务端），留着就是"两个侧栏项 + 一个报错的旧入口"，客户会以为工作流没被覆盖。
    """
    root = hermes_home()
    return [root / "desktop-plugins" / "takealot-erp", root / "plugins" / "takealot-erp"]


def retire_v2_host_assets() -> list[str]:
    """把 v2 的宿主侧两半**改名备份**（不直接删），返回做了什么的说明。

    只改名不删：客户想回退/取证都还在（``*.v2-retired``）。改名后宿主就加载不到了，
    新装的 ``takealot-erp-launcher`` 不会被旧那条盖住。
    """
    done: list[str] = []
    for path in v2_host_asset_dirs():
        if not path.is_dir():
            continue
        target = path.with_name(path.name + ".v2-retired")
        try:
            if target.exists():
                done.append("{0}（早就退休过）".format(path.name))
                continue
            path.rename(target)
            done.append("{0} → {1}".format(path.name, target.name))
        except Exception as exc:  # pragma: no cover - 权限/占用
            done.append("{0}（改名失败：{1}）".format(path.name, exc))
    return done


def retire_legacy_windows_tasks() -> list[str]:
    """Windows：清掉老版本留下的「打开死端口」计划任务（如 ``\\LaunchTakealot`` → 127.0.0.1:18789）。

    这类任务只做 ``cmd /c start http://127.0.0.1:1878x``：每次登录都弹一个打不开的浏览器页，
    客户看着像坏了。**只在任务动作确实指向本产品的老回环端口时才删**（避免误删同名的第三方任务），
    macOS/Linux 不适用 → 返回空。
    """
    if sys.platform != "win32":  # pragma: no cover - 只有 Windows 有
        return []
    done: list[str] = []
    try:
        q = subprocess.run(["schtasks", "/query", "/fo", "csv", "/v"],
                           capture_output=True, text=True, timeout=45)
    except Exception as exc:  # pragma: no cover
        return ["查询计划任务失败：{0}".format(exc)]
    names: set = set()
    for line in (q.stdout or "").splitlines():
        if "LaunchTakealot" not in line:
            continue
        m = re.search(r'"\\(LaunchTakealot[^"]*)"', line)
        if m:
            names.add(m.group(1))
    for name in sorted(names):
        try:
            xml = subprocess.run(["schtasks", "/query", "/tn", name, "/xml", "ONE"],
                                 capture_output=True, text=True, timeout=30)
            body = (xml.stdout or "") + (xml.stderr or "")
            if not re.search(r"127\.0\.0\.1:18(7|8)\d\d", body):
                done.append("{0}（要打开的不是本产品端口，留着不动）".format(name))
                continue
            d = subprocess.run(["schtasks", "/delete", "/tn", name, "/f"],
                               capture_output=True, text=True, timeout=30)
            if d.returncode == 0:
                done.append("{0}（老自启项指向死端口 → 已删）".format(name))
            else:
                done.append("{0}（删失败：{1}）".format(name, ((d.stderr or d.stdout) or "").strip()[:80]))
        except Exception as exc:  # pragma: no cover
            done.append("{0}（处理失败：{1}）".format(name, exc))
    return done


def make_shortcut(home: HOME, port: int) -> Path:
    """生成"双击即用"的桌面入口。

    macOS 用 .command（纯文本 + 可执行位）。**必须是本机生成**：下载来的文件会带
    com.apple.quarantine，Gatekeeper 会拦；本机生成的不带那个标记，双击直接跑。
    指向：装好的那份（ERP_HOME/venv + ERP_HOME/server/cli.py）优先，开发树才退回当前解释器。
    """
    target = desktop_entry_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    runner = installed_runner(home)
    if runner:
        python_bin, cli = runner[0], runner[1]
    else:
        python_bin, cli = Path(PY), Path(__file__).resolve()

    if sys.platform == "win32":  # pragma: no cover - Windows 真机验证
        # Windows 的「双击即用」是 .cmd（.lnk 得用 COM，.cmd 够用且可读可改）。
        # 内容**必须纯 ASCII**：cmd.exe 在 GBK 代码页下会把中文批注读成乱码甚至截断命令。
        cmd_batch = (
            "@echo off\r\n"
            "rem Takealot ERP workbench - generated on this machine by `erp shortcut`\r\n"
            "setlocal\r\n"
            'set "ERP_HOME={erp_home}"\r\n'
            '"{python}" "{cli}" open --app --port {port} %*\r\n'
            "if errorlevel 1 (\r\n"
            "  echo.\r\n"
            "  echo Failed to open the workbench. Run this file from a terminal to see the error.\r\n"
            "  pause\r\n"
            ")\r\n"
        ).format(erp_home=home.root, python=python_bin, cli=cli, port=port)
        target.write_text(cmd_batch, encoding="ascii", newline="")
        return target

    script = textwrap.dedent("""\
        #!/bin/bash
        # Takealot ERP 工作台 —— 由 `erp shortcut` 本机生成（不带 quarantine，双击可用）
        # 双击 = 起服务（没起才起）+ 开工作台窗口。想改窗口形态：把 --app 去掉就回落默认浏览器。
        set -e
        export ERP_HOME="{erp_home}"
        exec "{python}" "{cli}" open --app --port {port} "$@"
        """).format(erp_home=home.root, python=python_bin, cli=cli, port=port)
    target.write_text(script, encoding="utf-8")
    target.chmod(0o755)
    # 万一这棵树是从压缩包解出来的，主动清一次 quarantine（有就清，没有就算了）
    if sys.platform == "darwin":
        subprocess.run(["xattr", "-d", "com.apple.quarantine", str(target)],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return target


def launch_agent_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / "com.takealot.erp.plist"


def ensure_mac_autostart(home: HOME, port: int) -> dict:
    """macOS 开机常驻：写用户级 LaunchAgent 并加载（免 sudo）。

    为什么必须有：服务里跑着调度器（定时任务）—— 服务不随登录回来，客户的定时任务就不存在了。
    新系统用 `launchctl bootstrap gui/<uid>`；老系统没有就回落到 `load -w`。
    """
    path = make_launch_agent(home, port)
    uid = os.getuid()
    try:
        subprocess.run(["launchctl", "bootout", "gui/{0}".format(uid), str(path)],
                       capture_output=True, text=True, timeout=30)
        cp = subprocess.run(["launchctl", "bootstrap", "gui/{0}".format(uid), str(path)],
                            capture_output=True, text=True, timeout=30)
        if cp.returncode != 0:
            cp = subprocess.run(["launchctl", "load", "-w", str(path)],
                                capture_output=True, text=True, timeout=30)
        detail = (cp.stderr or cp.stdout or "").strip().splitlines()
        return {"ok": cp.returncode == 0, "path": str(path),
                "detail": "{0}（{1}）".format(path, "已加载" if cp.returncode == 0 else (detail[-1][:120] if detail else "加载失败"))}
    except Exception as exc:
        return {"ok": False, "path": str(path), "detail": "{0}（加载异常：{1}）".format(path, exc)}


def make_launch_agent(home: HOME, port: int) -> Path:
    """开机常驻（macOS：用户级 LaunchAgent，免管理员、不需要 sudo）。

    只起服务、不开窗口；窗口由人/agent 按需 `erp open`。

    必须是**前台 `serve`**，不能写 `open --no-window`：后者自己 fork 出后台进程就退出，
    launchd 认为这个 job 干完了，会把整个进程组一起收走，服务几分钟后神秘消失
    （实测：心跳刚写过 1 秒就没了）。让 launchd 直接托管 serve，服务就活得跟 job 一样久。
    KeepAlive 只在**失败退出**时重启（不无限重启；宁可让人看见失败，也不要静默循环）。
    """
    path = launch_agent_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    # 指向**装好的那份**（ERP_HOME/venv + ERP_HOME/server/cli.py）：交付包解压出来的
    # payload 目录（下载目录/临时目录）随时会被清掉，plist 若指向那里，用户一清开机
    # 自启就死了（真机踩到：plist 指 /private/var/folders/…/T/erp-update-…，launchd
    # 状态 = 退出码 2，服务再也不随登录回来，定时任务全停）。
    runner = installed_runner(home)
    if runner:
        python_bin, cli_path = runner[0], runner[1]
    else:
        python_bin, cli_path = Path(PY), Path(__file__).resolve()
    plist = textwrap.dedent("""\
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0">
        <dict>
          <key>Label</key><string>com.takealot.erp</string>
          <key>ProgramArguments</key>
          <array>
            <string>{python}</string>
            <string>{cli}</string>
            <string>serve</string>
            <string>--port</string><string>{port}</string>
          </array>
          <key>EnvironmentVariables</key>
          <dict><key>ERP_HOME</key><string>{erp_home}</string></dict>
          <key>RunAtLoad</key><true/>
          <key>KeepAlive</key>
          <dict><key>SuccessfulExit</key><false/></dict>
          <key>ThrottleInterval</key><integer>30</integer>
          <key>StandardOutPath</key><string>{logs}/launchagent.out</string>
          <key>StandardErrorPath</key><string>{logs}/launchagent.err</string>
        </dict>
        </plist>
        """).format(python=python_bin, cli=cli_path, port=port, erp_home=home.root, logs=home.logs)
    path.write_text(plist, encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# 子命令
# ---------------------------------------------------------------------------

def cmd_open(args, home: HOME) -> int:
    info, started = ensure_server(home, args.port)
    url = "http://127.0.0.1:{0}/".format(info.get("port"))
    result = {"ok": True, "started": started, "port": info.get("port"), "pid": info.get("pid"),
              "version": info.get("version"), "url": url, "erpHome": str(home.root)}
    if not args.no_window:
        result["window"] = open_window(url, "app" if args.app else "browser")
    out(result, args.json,
        ("已启动" if started else "已在跑") + " · 工作台 " + url +
        ("（新起 pid {0}）".format(info.get("pid")) if started else "（pid {0}）".format(info.get("pid"))) +
        ("" if args.no_window else " · 窗口：" + json.dumps(result.get("window", {}), ensure_ascii=False)))
    return EXIT_OK


def cmd_status(args, home: HOME) -> int:
    info = running(home)
    if not info.get("running"):
        payload = {"ok": False, "running": False, "erpHome": str(home.root),
                   "portBusyByOther": bool(info.get("portBusyByOther"))}
        out(payload, args.json, "工作台没在跑（{0}）".format(home.root) +
            ("；注意端口 {0} 被别的进程占着".format(info.get("port")) if info.get("portBusyByOther") else ""))
        return EXIT_NOT_RUNNING
    payload = {"ok": True, "running": True, "port": info.get("port"), "pid": info.get("pid"),
               "version": info.get("version"), "coreVersion": info.get("coreVersion"),
               "uptimeSec": info.get("uptimeSec"), "startedAt": info.get("startedAt"),
               "erpHome": info.get("erpHome"), "stateDir": info.get("stateDir"),
               "atRestBackend": info.get("atRestBackend"), "url": "http://127.0.0.1:{0}/".format(info.get("port")),
               "tokenPresent": bool((home.read_runtime() or {}).get("token"))}
    out(payload, args.json,
        "工作台在跑 · http://127.0.0.1:{0}/ · pid {1} · 服务端 v{2} 核心 v{3} · 已运行 {4}s · 密钥库 {5}".format(
            info.get("port"), info.get("pid"), info.get("version"), info.get("coreVersion"),
            info.get("uptimeSec"), info.get("atRestBackend")))
    return EXIT_OK


def stop_service(home: HOME) -> dict:
    """停服务并确认端口真的关了。返回 {ok, stopped, pid, port, detail}（cmd_stop 与 setup 共用）。"""
    info = running(home)
    if not info.get("running"):
        return {"ok": True, "stopped": False, "detail": "本来就没在跑"}
    pid = int(info.get("pid") or 0)
    port = info.get("port")
    if pid <= 0:
        return {"ok": False, "stopped": False, "detail": "runtime.json 里没有 pid", "port": port}
    try:
        if os.name == "nt":
            # Windows 没有真信号：os.kill(pid, SIGTERM) 实际就是 TerminateProcess（硬杀），
            # 服务里的收尾钩子（含停本地桥的那段）根本不会跑；而 Windows 杀父进程**不会**连子进程，
            # 于是挂在服务下面的桥会变成孤儿继续占着 18790（Windows 真机实测）。/T = 连子进程一起收。
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                           capture_output=True, timeout=20)
        else:
            os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    except Exception:
        pass
    t0 = time.time()
    while time.time() - t0 < 15 and port and port_open(port):
        time.sleep(0.3)
    still = bool(port) and port_open(port)
    if not still:
        try:
            home.runtime_file.unlink(missing_ok=True)
        except OSError:
            pass
    return {"ok": not still, "stopped": not still, "pid": pid, "port": port,
            "detail": "已停" if not still else "发了 SIGTERM 但端口还在听：查 pid {0}".format(pid)}


def _stray_instances(home: HOME) -> list[int]:
    """找出**同一个 ERP_HOME 的其它实例**（cmdline 里带这个数据目录的 python 进程）。

    为什么要有：反复 setup / 自启 / 升级会留下老实例继续占着端口（老进程没有新路由），
    症状是"工具调 /jobs 拿 404""服务明明在跑却像新的没生效" —— 真机踩到过（客户机的 agent 当场指出）。
    """
    me = os.getpid()
    # 不能杀的名单里还要加上**父进程**：`cli.py update` → 新包的 `cli.py setup` → 到这里，
    # 父进程的命令行恰好含 `<home>/server/cli.py`。杀掉它 = 把正在跑的升级流程掐死
    # （真机踩到：文件换完、服务已停，后面的"起服务"再没跑到 → 客户升级完服务是死的、也没有任何报错）。
    protected = {me}
    try:
        protected.add(os.getppid())
    except Exception:
        pass
    srv_dir = str(home.root / "server")
    # 判据（每次都是真机踩出来的）：
    #   ① argv[0] 必须是 python 解释器；② argv 里必须出现**该 home 下的具体脚本绝对路径**；
    #   ③ `cli.py` 只有 **serve** 子命令才算"在跑的服务" —— update/status/doctor/job/route 这些是
    #      **客户端调用**，按脚本路径一刀切会把正在执行的命令自己当成残留杀掉。
    scripts = [os.path.join(srv_dir, n) for n in ("app.py", "mcp_server.py")]
    # 本地桥（18790）也挂在本 home 下：老版本停服务时它会变孤儿（Windows 上杀父进程不连子进程），
    # 端口被它占着会让新实例起不来、扩展采集的数据也进不了账 —— 一起扫。
    scripts.append(os.path.join(srv_dir, "bridge", "erp_bridge.py"))
    serve_only = os.path.join(srv_dir, "cli.py") + " serve"

    def is_instance(cmdline: str) -> bool:
        return any(s in cmdline for s in scripts) or serve_only in cmdline
    found: list[int] = []
    try:
        if os.name == "nt":
            cp = subprocess.run(["wmic", "process", "where", "name like '%python%'",
                                 "get", "ProcessId,CommandLine"],
                                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20)
            for line in (cp.stdout or "").splitlines():
                line = line.strip()
                if not line or "python" not in line.lower():
                    continue
                parts = line.split()
                if parts and parts[-1].isdigit() and int(parts[-1]) not in protected \
                        and is_instance(line):
                    found.append(int(parts[-1]))
        else:
            cp = subprocess.run(["ps", "ax", "-o", "pid=,command="], capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=20)
            for line in (cp.stdout or "").splitlines():
                line = line.strip()
                if not line:
                    continue
                pid_s, _, cmd = line.partition(" ")
                argv0 = cmd.split()[0] if cmd.split() else ""
                pythonish = "python" in os.path.basename(argv0).lower()
                if argv0.endswith(".exe"):
                    pythonish = "python" in os.path.basename(argv0).lower()
                if pythonish and pid_s.isdigit() and int(pid_s) not in protected \
                        and is_instance(cmd):
                    found.append(int(pid_s))
    except Exception:
        pass
    return sorted(set(found))


def stop_strays(home: HOME, signal_first: bool = True) -> list[int]:
    """把同 home 的残留实例停掉（先温和、1 秒后强杀）。返回处理掉的 pid 列表。"""
    import signal as _signal
    import time as _time
    killed = []
    for pid in _stray_instances(home):
        try:
            if signal_first:
                os.kill(pid, _signal.SIGTERM)
        except Exception:
            pass
    if signal_first:
        _time.sleep(1.2)
    for pid in _stray_instances(home):
        try:
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, timeout=20)
            else:
                os.kill(pid, _signal.SIGKILL)
            killed.append(pid)
        except Exception:
            pass
    return killed


def cmd_stop(args, home: HOME) -> int:
    info = running(home)
    if not info.get("running"):
        strays = stop_strays(home)
        out({"ok": True, "stopped": False, "detail": "本来就没在跑", "staleKilled": strays}, args.json,
            "本来就没在跑" + ("；顺手清掉 {0} 个残留实例".format(len(strays)) if strays else ""))
        return EXIT_OK
    pid = int(info.get("pid") or 0)
    port = info.get("port")
    if pid <= 0:
        out({"ok": False, "stopped": False, "detail": "runtime.json 里没有 pid，只能靠端口确认",
             "port": port}, args.json, "拿不到 pid：runtime.json 里没写 pid")
        return EXIT_FAIL
    res = stop_service(home)
    strays = stop_strays(home)
    res["staleKilled"] = strays
    # 本地桥（18790）也是这次实例的一部分：它没退干净同样算没停干净（Windows 上踩过孤儿桥）
    bridge_port = int(os.environ.get("ERP_BRIDGE_PORT") or 18790)
    bridge_free = not port_open(bridge_port)
    res["bridgePortFree"] = bridge_free
    out(res, args.json,
        ("已停（pid {0}，端口 {1} 已关闭".format(res.get("pid"), res.get("port")) if res.get("stopped")
         else "没停下来：{0}".format(res.get("detail")))
        + ("；本地桥 {0} 已随之释放）".format(bridge_port) if bridge_free
           else "；⚠ 本地桥 {0} 还在听，可能另有实例占着".format(bridge_port))
        + ("" if res.get("stopped") else "")
        + ("；另外清掉了 {0} 个残留实例（{1}）—— 它们占着端口会让「服务明明在跑却不认新版本」".format(
            len(strays), ", ".join(str(p) for p in strays)) if strays else ""))
    return EXIT_OK if res.get("ok") else EXIT_FAIL


def cmd_route(args, home: HOME) -> int:
    res = route(args.text, home)
    if args.json:
        print(json.dumps(res, ensure_ascii=False, indent=2))
    else:
        print(res["instruction"])
        if res.get("matched"):
            print("命中：{0} → {1}".format(res.get("matchedWord"), res.get("command")))
    return EXIT_OK if res.get("matched") else EXIT_FAIL


def cmd_shortcut(args, home: HOME) -> int:
    entry = make_shortcut(home, args.port)
    payload = {"ok": True, "entry": str(entry), "executable": os.access(entry, os.X_OK),
               "erpHome": str(home.root)}
    if args.agent:
        payload["launchAgent"] = str(make_launch_agent(home, args.port))
    out(payload, args.json,
        "桌面入口已生成：{0}\n双击 = 起服务 + 开窗口（--app 档位；没装 Chrome/Edge 会自动回落默认浏览器）".format(entry) +
        ("\n开机常驻已写入：{0}（launchctl load 它即可生效）".format(payload["launchAgent"]) if args.agent else ""))
    return EXIT_OK


MCP_SERVER = HERE / "mcp_server.py"
LAUNCHER_PLUGIN_NAME = "takealot-erp-launcher"


def hermes_home() -> Path:
    """Hermes 的家目录（桌面插件的落脚点）。"""
    env = (os.environ.get("HERMES_HOME") or "").strip()
    return Path(env).expanduser() if env else Path.home() / ".hermes"


def desktop_plugins_dir() -> Path:
    if sys.platform == "win32":  # pragma: no cover - Windows 阶段验证
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "hermes" / "desktop-plugins"
    return hermes_home() / "desktop-plugins"


def plugin_source(home: HOME) -> Path | None:
    """入口插件的真源：装好的那份（ERP_HOME/plugin-launcher）优先，源码树兜底。"""
    for cand in (home.root / "plugin-launcher" / "plugin.js",   # 装好的那份
                 HERE.parent / "plugin-launcher" / "plugin.js"):  # 源码树/包内 payload
        if cand.is_file():
            return cand
    return None


def install_launcher_plugin(home: HOME, write: bool = True) -> dict:
    """把宿主侧「启动入口」插件装进 Hermes 的桌面插件目录（形态 v3 的入口就靠它）。"""
    src = plugin_source(home)
    if src is None:
        return {"ok": False, "detail": "包内没有 plugin-launcher/plugin.js"}
    target_dir = desktop_plugins_dir() / LAUNCHER_PLUGIN_NAME
    target = target_dir / "plugin.js"
    info = {"ok": True, "source": str(src), "target": str(target), "host": "hermes",
            "note": "Hermes 里会出现侧栏项「Takealot ERP」+ 命令面板项「Takealot: 打开工作台」"}
    if not write:
        info["written"] = False
        return info
    try:
        target_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)
        info["written"] = True
        info["bytes"] = target.stat().st_size
    except OSError as exc:
        info.update({"ok": False, "written": False, "detail": str(exc)})
    return info


AGENTS_BLOCK_HEAD = "<!-- takealot-erp:start -->"
AGENTS_BLOCK_TAIL = "<!-- takealot-erp:end -->"


def write_codex_agents_block(home: HOME) -> dict:
    """把产品 AGENTS 片段写进 Codex 的 AGENTS.md —— **受管区块**（幂等替换，不会越贴越多）。

    为什么必须受管：v2 是"让用户自己把这段话追加进去"；升级后**旧片段还在** →
    agent 按旧口径做事（写价要先界面授权、定时任务用 Hermes cron…）——这正是"工作流没被覆盖"。
    现在用 <!-- takealot-erp:start/end --> 夹住，每次 setup/升级**整块替换**。
    """
    src = None
    for cand in (home.root / "agent" / "AGENTS.md", HERE.parent / "agent" / "AGENTS.md"):
        if cand.is_file():
            src = cand
            break
    if src is None:
        return {"ok": False, "detail": "包里没有 agent/AGENTS.md"}
    try:
        target = Path.home() / ".codex" / "AGENTS.md"
        target.parent.mkdir(parents=True, exist_ok=True)
        block = "{0}\n{1}\n{2}\n".format(AGENTS_BLOCK_HEAD, src.read_text(encoding="utf-8").strip(),
                                          AGENTS_BLOCK_TAIL)
        old = target.read_text(encoding="utf-8", errors="replace") if target.is_file() else ""
        if AGENTS_BLOCK_HEAD in old and AGENTS_BLOCK_TAIL in old:
            head, _, rest = old.partition(AGENTS_BLOCK_HEAD)
            _, _, tail = rest.partition(AGENTS_BLOCK_TAIL)
            new, mode = head + block + tail, "替换受管区块"
        else:
            new = (old.rstrip() + "\n\n" if old.strip() else "") + block
            mode = "新增受管区块"
        if new != old:
            target.write_text(new, encoding="utf-8")
        return {"ok": True, "mode": mode, "file": str(target),
                "detail": "{0}：{1}".format(mode, target)}
    except Exception as exc:
        return {"ok": False, "detail": "{0}: {1}".format(type(exc).__name__, exc)}


def codex_skills_dir() -> Path:
    """Codex 的用户技能目录（官方文档：$HOME/.agents/skills；Codex 会跟随符号链接）。"""
    env = (os.environ.get("AGENTS_HOME") or "").strip()
    base = Path(env).expanduser() if env else Path.home()
    return base / ".agents" / "skills"


#: 随包发给客户机的产品技能 —— **客户机上 agent 的"工作流"就是这些技能 + MCP 工具面**。
#: 升级时必须一起换新，否则老用户的 agent 还在按旧技能跑（旧命令、旧红线、旧授权口径）。
PRODUCT_SKILLS = ("takealot-erp-operator", "takealot-erp-buybox-watch", "takealot-erp-logistics-patrol",
                  "takealot-erp-selfheal")


def product_skill_dir(home: HOME, name: str = "takealot-erp-operator") -> Path | None:
    """产品技能目录（SKILL.md 所在）：装好的那份优先，源码树兜底。"""
    for cand in (home.root / "agent" / "skills" / name,
                 HERE.parent / "agent" / "skills" / name,
                 HERE.parent / "plugin" / "skills" / name):
        if (cand / "SKILL.md").is_file():
            return cand
    return None


def install_skill_into(host: str, home: HOME, write: bool = True, names=None) -> dict:
    """把**产品技能**装到宿主的技能目录（Hermes = 用户技能目录；Codex = ~/.agents/skills）。

    语义（决定"老用户升级能不能换掉旧工作流"）：
      · Hermes：**复制并覆盖**（先删目标再拷）→ 升级一次就换新 ✓
      · Codex：**符号链接**指向产品目录（官方跟随符号链接）→ 产品升级 → 技能自动跟新 ✓
        （Windows 上建符号链接要权限，失败就回落成复制 —— 至少内容是新的）
    缺技能如实报，但不让 setup 失败（老机器可能没装这个宿主）。
    """
    names = list(names or PRODUCT_SKILLS)
    done, missing, targets = [], [], []
    for name in names:
        src = product_skill_dir(home, name)
        if src is None:
            missing.append(name)
            continue
        target_dir = (hermes_home() / "skills" / name) if host == "hermes" else (codex_skills_dir() / name)
        targets.append(target_dir)
        if not write:
            done.append(name + "（未写）")
            continue
        try:
            target_dir.parent.mkdir(parents=True, exist_ok=True)
            if target_dir.exists() or target_dir.is_symlink():
                if target_dir.is_symlink() or target_dir.is_file():
                    target_dir.unlink()
                else:
                    shutil.rmtree(target_dir)
            if host == "codex":
                try:
                    os.symlink(str(src), str(target_dir), target_is_directory=True)
                except Exception:
                    shutil.copytree(src, target_dir)   # Windows 没权限建链接 → 至少把新内容拷进去
            else:
                shutil.copytree(src, target_dir)
            done.append(name)
        except Exception as exc:
            missing.append("{0}（{1}）".format(name, str(exc)[:60]))
    info = {"ok": bool(done), "host": host, "installed": done, "missing": missing,
            "written": bool(done),
            "target": str(targets[0].parent) if targets else "",
            "detail": "已刷新 {0} 个技能：{1}".format(len(done), "、".join(done))
                      + ("；缺：{0}".format("、".join(missing)) if missing else "")}
    return info


CODEX_MCP_BLOCK_HEAD = "[mcp_servers.takealot-erp]"


def install_codex_mcp(home: HOME) -> dict:
    """在 Codex 的 config.toml 里维护 `[mcp_servers.takealot-erp]`，指向**装好的那份**。

    为什么必须指向 ERP_HOME 而不是源码树：客户机没有源码树；源码一挪端点就废。
    幂等：按段落删除后重写（先备份），重复跑结果一样。
    """
    cfg = Path.home() / ".codex" / "config.toml"
    py = home.root / "venv" / "bin" / "python"
    if os.name == "nt":
        py = home.root / "venv" / "Scripts" / "python.exe"
    server = home.root / "server" / "mcp_server.py"
    for p in (py, server):
        if not p.exists():
            return {"ok": False, "host": "codex", "target": str(cfg), "detail": "缺文件：{0}".format(p)}

    block = (
        "# Takealot ERP（由 `erp entry --host codex --write` 维护；改成源码路径会随源码失效）\n"
        "{head}\ncommand = {py}\nargs = [{srv}]\nstartup_timeout_sec = 60\n\n"
        "[mcp_servers.takealot-erp.env]\nERP_HOME = {home}\n"
    ).format(head=CODEX_MCP_BLOCK_HEAD, py=json.dumps(str(py)), srv=json.dumps(str(server)),
             home=json.dumps(str(home.root)))

    try:
        cfg.parent.mkdir(parents=True, exist_ok=True)
        old = cfg.read_text(encoding="utf-8") if cfg.is_file() else ""
        if block in old:
            return {"ok": True, "host": "codex", "written": False, "target": str(cfg),
                    "detail": "已经指向装好的那份，未改动"}
        # 删掉旧的 takealot-erp 两段（[mcp_servers.takealot-erp] 与 .env）
        lines = old.splitlines(keepends=True)
        kept, skip = [], False
        for ln in lines:
            if ln.strip() == CODEX_MCP_BLOCK_HEAD:
                skip = True
                continue
            if ln.strip() == "[mcp_servers.takealot-erp.env]":
                skip = True
                continue
            if skip and ln.startswith("[") and ln.strip() not in (CODEX_MCP_BLOCK_HEAD, "[mcp_servers.takealot-erp.env]"):
                skip = False
            if skip:
                continue
            kept.append(ln)
        body = "".join(kept).rstrip("\n")
        if old:
            shutil.copy2(cfg, str(cfg) + ".bak")
        cfg.write_text((body + "\n" if body else "") + ("\n" if body else "") + block, encoding="utf-8")
        return {"ok": True, "host": "codex", "written": True, "target": str(cfg),
                "detail": "已指向 ERP_HOME 装好的那份（原文件留 .bak）"}
    except OSError as exc:
        return {"ok": False, "host": "codex", "target": str(cfg), "detail": str(exc)}


def install_codex_agents_md(home: HOME) -> dict:
    """把 AGENTS.md 片段追加到 Codex 的全局指令（带标记、幂等、先备份）。"""
    src = home.root / "agent" / "AGENTS.md"
    if not src.is_file():
        src = HERE.parent / "agent" / "AGENTS.md"
    if not src.is_file():
        return {"ok": False, "detail": "找不到 AGENTS.md 片段"}
    marker = "Takealot ERP（工作台）"
    target = Path.home() / ".codex" / "AGENTS.md"
    body = src.read_text(encoding="utf-8")
    existing = target.read_text(encoding="utf-8") if target.is_file() else ""
    if marker in existing:
        return {"ok": True, "written": False, "detail": "{0} 里已经有 Takealot 段落，未重复追加".format(target)}
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        if existing:
            shutil.copy2(target, str(target) + ".bak")
        with open(target, "a", encoding="utf-8") as fh:
            fh.write(("\n" if existing and not existing.endswith("\n") else "") + body)
        return {"ok": True, "written": True, "target": str(target), "detail": "已追加（原文件留了 .bak）"}
    except OSError as exc:
        return {"ok": False, "detail": str(exc)}


def cmd_entry(args, home: HOME) -> int:
    """`erp entry --host hermes|codex [--write]`：装该宿主的入口。

    入口形态按宿主能力来（都已核实过官方文档）：
      Hermes：左侧栏插件（桌面插件目录，热加载）+ 用户技能
      Codex ：技能目录 `~/.agents/skills`（官方 Agent Skills 标准，符号链接）+ AGENTS.md 片段
              —— 注意 Codex 的旧 custom prompts 已被官方弃用，别再用那条路
    """
    written = args.write
    result = {"ok": True, "host": args.host, "erpHome": str(home.root), "steps": []}

    def add_step(res: dict) -> None:
        result["steps"].append(res)
        if not res.get("ok", True):
            result["ok"] = False

    if args.host == "hermes":
        add_step(install_launcher_plugin(home, write=written))
        add_step(install_skill_into("hermes", home, write=written))
    else:
        add_step(install_skill_into("codex", home, write=written))
        if written:
            add_step(install_codex_mcp(home))
            add_step(install_codex_agents_md(home))
        else:
            result["steps"].append({"host": "codex", "target": str(Path.home() / ".codex" / "AGENTS.md"),
                                    "note": "加 --write 会把 AGENTS.md 片段追加进去（幂等、先备份）"})

    human = "\n".join("  {0} {1} → {2}".format("已装" if s.get("written") else "目标",
                                              s.get("host") or s.get("target") or "",
                                              s.get("target") or s.get("detail") or "") for s in result["steps"])
    out(result, args.json,
        "入口（{0}）{1}：\n{2}\n宿主侧还有一层入口：MCP 工具（任何支持 MCP 的 host 都能用 erp_workbench_open）".format(
            args.host, "已安装" if written else "只是打印，加 --write 才写", human))
    return EXIT_OK if result["ok"] else EXIT_FAIL


def cmd_plugin(args, home: HOME) -> int:
    """`erp plugin --host hermes [--write]`：装/更新宿主入口插件（默认只打印目标路径）。"""
    res = install_launcher_plugin(home, write=args.write)
    out(res, args.json,
        ("已安装入口插件 → {0}".format(res["target"]) if res.get("written")
         else "入口插件目标：{0}（加 --write 才写）".format(res.get("target")))
        + "\n" + str(res.get("note") or res.get("detail") or ""))
    return EXIT_OK if res.get("ok") else EXIT_FAIL


def cmd_mcp(args, home: HOME) -> int:
    """`erp mcp serve` 跑 stdio 协议层；`erp mcp config --host X` 打印该宿主该写什么。

    默认**只打印不写入**：客户机上的 agent 配置是客户的东西，改之前要人点头（--write 才动手）。
    """
    if args.mcp_cmd == "serve":
        # 直接把 stdio 交给协议层（同一个进程，宿主看到的是它自己 spawn 的 server）
        env = dict(os.environ)
        env["ERP_HOME"] = str(home.root)
        return subprocess.call([PY, str(MCP_SERVER)], env=env)

    host = args.host or "codex"
    snippet_codex = (
        "# ~/.codex/config.toml（或项目级 .codex/config.toml）——追加即可\n"
        "[mcp_servers.takealot-erp]\n"
        'command = "{python}"\n'
        'args = ["{mcp}"]\n'
        'startup_timeout_sec = 60\n'
        "\n"
        "[mcp_servers.takealot-erp.env]\n"
        'ERP_HOME = "{erp_home}"\n'
    ).format(python=PY, mcp=MCP_SERVER, erp_home=home.root)
    snippet_hermes = ("hermes mcp add takealot-erp --command {python} --args {mcp} --env ERP_HOME={home}\n"
                      "# 加完用这两条确认：hermes mcp list / hermes mcp test takealot-erp\n").format(
        python=PY, mcp=MCP_SERVER, home=home.root)

    payload = {"ok": True, "host": host, "mcpServer": str(MCP_SERVER), "python": PY, "erpHome": str(home.root),
               "snippet": snippet_codex if host == "codex" else snippet_hermes}

    if args.write:
        if host == "codex":
            cfg = Path(args.codex_config or (Path.home() / ".codex" / "config.toml"))
            existing = cfg.read_text(encoding="utf-8") if cfg.is_file() else ""
            if "[mcp_servers.takealot-erp]" in existing:
                payload.update({"written": False, "detail": "{0} 里已经有这一段了，没动它".format(cfg)})
            else:
                cfg.parent.mkdir(parents=True, exist_ok=True)
                with open(cfg, "a", encoding="utf-8") as fh:
                    fh.write(("\n" if existing and not existing.endswith("\n") else "") + snippet_codex)
                payload.update({"written": True, "config": str(cfg)})
        else:
            cmd = [PY, str(MCP_SERVER)]
            # `hermes mcp add` 会问「Enable all N tools? [Y/n/select]」——非交互环境必须喂个 y，
            # 否则它自己打印 "Cancelled." 然后什么都没写（实测踩到）。
            # 先删后加：重装/换路径时不希望它报"已存在"（幂等；没有这条时 remove 失败也无所谓）
            subprocess.run(["hermes", "mcp", "remove", "takealot-erp"], capture_output=True, text=True, encoding="utf-8", errors="replace")
            # ⚠ `--args` 会吞掉它后面的所有参数（help 里写着 "must be the last option"），
            # 所以 --env 必须写在 --args **之前**，否则 ERP_HOME 会变成 server 的 argv 而不是环境变量
            # （实测踩到：配置里看着像成功了，其实 env 没生效，只是碰巧默认路径相同才没炸）。
            cp = subprocess.run(["hermes", "mcp", "add", "takealot-erp", "--command", PY,
                                 "--env", "ERP_HOME={0}".format(home.root),
                                 "--args", str(MCP_SERVER)],
                                input="y\n", capture_output=True, text=True, encoding="utf-8", errors="replace")
            payload.update({"written": cp.returncode == 0, "config": "hermes mcp",
                            "detail": (cp.stdout + cp.stderr).strip()[-400:]})

    out(payload, args.json,
        "给 {0} 的配置（{1}）：\n{2}".format(host, "已写入" if payload.get("written") else "只是打印，加 --write 才写",
                                        payload["snippet"]))
    return EXIT_OK


def cmd_serve(args, home: HOME) -> int:
    """前台常驻 —— 给 launchd（macOS）/ 计划任务（Windows）/ ``--foreground`` 用。

    **"已经有实例在跑"= 成功**（翻成退出码 0）：KeepAlive 只看退出码，如果这里报失败，
    自启会每 30 秒重启一次、永远循环（真机实测 launchd 的 LastExitStatus=768，就是
    app.main 返回的 3）。真正的崩溃仍然是非零退出，launchd 照旧会把它拉起来。
    """
    code = srv.main(["--port", str(args.port), "--erp-home", str(home.root)] + (["--verbose"] if args.verbose else []))
    if code == srv.EXIT_ALREADY_RUNNING:
        print("已经有实例在跑（本 ERP_HOME）—— serve 按成功退出，交给它继续服务")
        return EXIT_OK
    return code


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="erp", description="Takealot ERP —— 常驻服务端 + 工作台（形态 v3）")
    ap.add_argument("--erp-home", default=None, help="数据目录（默认平台标准位置，也可用 ERP_HOME）")
    ap.add_argument("--port", type=int, default=srv.DEFAULT_PORT, help="默认 18791")
    ap.add_argument("--json", action="store_true", help="输出机器可读 JSON（给 agent / 脚本用）")
    sub = ap.add_subparsers(dest="cmd")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--json", action="store_true", dest="json_sub", help="输出机器可读 JSON")
    # 子命令后面也能写 --port / --erp-home（脚本、.command、agent 都习惯这么写）；
    # default=SUPPRESS 很关键：否则子解析器的默认值会盖掉顶层已解析出来的值。
    common.add_argument("--erp-home", default=argparse.SUPPRESS)
    common.add_argument("--port", type=int, default=argparse.SUPPRESS)

    p = sub.add_parser("open", help="起服务并开工作台窗口", parents=[common])
    p.add_argument("--no-window", action="store_true", help="只起服务，不开窗口")
    p.add_argument("--app", action="store_true", help="用 Chrome/Edge 的 --app 模式开无地址栏窗口")

    sub.add_parser("status", help="看是否在跑（退出码 0=在跑，3=没跑）", parents=[common])
    sub.add_parser("stop", help="停掉服务", parents=[common])

    sub.add_parser("doctor", help="13 项端到端自检", parents=[common])
    upd = sub.add_parser("update", help="检查/应用更新（通道 → 校验 sha256 → 覆盖安装）", parents=[common])
    upd.add_argument("--check", action="store_true", help="只看有没有新版，不下载安装")
    upd.add_argument("--apply", action="store_true",
                     help="应用更新（v3 的默认行为就是应用；此开关仅为兼容 v2 selfupdate.py 的写法，等同不加）")
    upd.add_argument("--channel", default="", help="临时指定通道（支持 file://，离线自测用）")
    upd.add_argument("--force", action="store_true", help="构建号相同也重装一次")
    jb = sub.add_parser("job", help="定时任务：list / run <id> / enable|disable <id> / logs [id]", parents=[common])
    jb.add_argument("job_action", nargs="?", default="list",
                    choices=["list", "run", "enable", "disable", "logs", "install-defaults", "set"])
    jb.add_argument("job_id", nargs="?", default="")
    jb.add_argument("--force", action="store_true", help="install-defaults 时覆盖已有清单")
    jb.add_argument("--interval", type=float, default=None, help="set：改成每 N 分钟一轮")
    jb.add_argument("--cron", default="", help="set：改成 cron 表达式（如 '30 8,15 * * *'）")
    jb.add_argument("--args", default="", help="set：替换脚本参数（如 '--stale-hours 4 --refresh-held 40'）")
    jb.add_argument("--timeout", type=int, default=None, help="set：单轮超时秒")
    rp = sub.add_parser("repricing", help="跟价授权：status / authorize / revoke（对话授权，agent 问一句即可）",
                        parents=[common])
    rp.add_argument("repricing_action", nargs="?", default="status", choices=["status", "authorize", "revoke"])
    rp.add_argument("--store", default="", help="店铺 id（可逗号分隔；不给则用界面当前选中的店）")
    rp.add_argument("--interval", type=float, default=None, help="几小时一轮（默认 2）")
    rp.add_argument("--min", type=float, default=None, help="最小下探金额（默认 1）")
    rp.add_argument("--max", type=float, default=None, help="最大下探金额（默认 50）")
    rp.add_argument("--floor", type=float, default=None, help="底价熔断（低于它不写）")
    rp.add_argument("--ceiling", type=float, default=None, help="封顶价（高于它不写）")
    rp.add_argument("--max-changes", type=int, default=None, help="单轮最多写几条（默认 10）")
    rp.add_argument("--note", default="", help="授权备注（谁会话里同意的，留个痕）")

    r = sub.add_parser("route", help="中文词表 → 确定性指令", parents=[common])
    r.add_argument("text", help='例如："打开工作台"')

    s = sub.add_parser("shortcut", help="生成桌面入口（可选开机常驻）", parents=[common])
    s.add_argument("--agent", action="store_true", help="同时写 macOS LaunchAgent（用户级，免管理员）")

    en = sub.add_parser("entry", help="装宿主侧入口（hermes=侧栏插件 / codex=技能+AGENTS.md）", parents=[common])
    en.add_argument("--host", choices=["hermes", "codex"], default="hermes")
    en.add_argument("--write", action="store_true", help="真的写进宿主（默认只打印目标）")

    pl = sub.add_parser("plugin", help="装宿主侧入口插件（Hermes 侧栏项）", parents=[common])
    pl.add_argument("--host", choices=["hermes"], default="hermes")
    pl.add_argument("--write", action="store_true", help="真的写进宿主插件目录（默认只打印目标）")

    st = sub.add_parser("setup", help="一键装（建 venv/装依赖/拷文件/桌面入口/自检）", parents=[common])
    st.add_argument("--source", default=None, help="payload 目录（默认自动识别：交付包 payload/ 或源码树 source/）")
    st.add_argument("--wheelhouse", default=None, help="离线 wheel 目录（默认 <payload>/wheelhouse）")
    st.add_argument("--offline", action="store_true", help="只从 wheelhouse 装，不联网")
    st.add_argument("--index-url", default=None, help="pip 源（国内可指镜像）")
    st.add_argument("--skip-deps", action="store_true", help="跳过依赖安装（依赖已就绪时）")
    st.add_argument("--force-migrate", action="store_true",
                    help="v3 已有 stores.json 时也再合并一次 v2 数据（默认跳过）")
    st.add_argument("--no-shortcut", action="store_true", help="不建桌面入口")
    st.add_argument("--no-start", action="store_true", help="装完不起服务（默认会起，装完即可用）")
    st.add_argument("--no-plugin", action="store_true", help="不装宿主侧入口插件（默认装到 Hermes）")
    st.add_argument("--python", default=None, help="用哪个解释器建 venv（默认当前）")

    m = sub.add_parser("mcp", help="MCP 接口层（serve / 打印宿主配置）", parents=[common])
    m.add_argument("mcp_cmd", nargs="?", default="config", choices=["serve", "config"])
    m.add_argument("--host", choices=["codex", "hermes"], default="codex", help="给哪个宿主生成配置")
    m.add_argument("--write", action="store_true", help="真的写进宿主配置（默认只打印）")
    m.add_argument("--codex-config", default=None, help="Codex config.toml 路径（默认 ~/.codex/config.toml）")

    v = sub.add_parser("serve", help="前台跑服务（调试）", parents=[common])
    v.add_argument("--verbose", action="store_true")
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    # 两种位置都认：`erp --json status` 与 `erp status --json`（后者对脚本/agent 更自然）
    args.json = bool(getattr(args, "json", False) or getattr(args, "json_sub", False))
    if getattr(args, "port", None) is None:
        args.port = srv.DEFAULT_PORT
    if getattr(args, "erp_home", None) is None:
        args.erp_home = None
    home = HOME(Path(args.erp_home) if args.erp_home else srv.default_erp_home())
    if not args.cmd:
        build_parser().print_help()
        return EXIT_OK
    handler = {
        "open": cmd_open, "status": cmd_status, "stop": cmd_stop,
        "doctor": lambda a, h: doctor(h, a.json), "route": cmd_route,
        "shortcut": cmd_shortcut, "serve": cmd_serve, "mcp": cmd_mcp, "setup": cmd_setup,
        "plugin": cmd_plugin, "entry": cmd_entry, "update": cmd_update, "job": cmd_job,
        "repricing": cmd_repricing,
    }[args.cmd]
    try:
        return handler(args, home)
    except SystemExit as exc:
        raise
    except KeyboardInterrupt:
        return EXIT_FAIL


if __name__ == "__main__":
    raise SystemExit(main())
