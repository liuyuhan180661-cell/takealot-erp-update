"""Takealot ERP — Hermes plugin backend (dashboard half).

Mounted by ``hermes_cli.web_server_dashboard._mount_plugin_api_routes`` at
``/api/plugins/takealot-erp/``. Exports ``router = APIRouter()``.

Design rules (see CONTRACT.md, authoritative):

* stdlib + fastapi only; ``openpyxl`` used when importable, otherwise a real
  ``.xlsx`` is written with ``zipfile`` + minimal OOXML.
* Money math is a faithful port of the OpenClaw ERP core:
  ``core/fee_matrix.js``, ``core/dc_logistics.js``, ``core/profit_engine.js``.
* ZERO MOCK DATA (CONTRACT v7). Every number in a response comes from one of
  exactly four real sources: the Seller API (``/sales``, ``/offers``,
  ``/balances``, ``/transactions``, ``/shipments``), the public-page crawler
  cache, the static platform reference tables under ``dashboard/data/``, or the
  customer's own local state (collection box / drafts / rules / price log).
  A path that cannot reach real data returns ``ok:false``/``empty:true`` with a
  reason (``requires``/``note``/``hint``) — never an invented number, never a
  silently-substituted sample row. ``mode`` is ``live`` (Seller API),
  ``local`` (customer's own state) or an error/empty marker.
* A live Seller ``X-API-Key`` never leaves the backend (masked in responses,
  sanitized in error strings); a failed call is reported as a failure, not
  papered over with fallback rows.
* No module-level network calls, no background threads, no blocking at import:
  the JSON data files and state files are read lazily on first use.
"""

from __future__ import annotations

import functools
import hashlib
import importlib.util
import json
import logging
import datetime as _dt
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timedelta, timezone
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from fastapi import APIRouter, Body

log = logging.getLogger("hermes.plugin.takealot_erp")

router = APIRouter()


def _startup_warm() -> None:
    """Warm every bound store's catalogue shortly after the backend boots.

    Cold /offers builds cost ~30s on a 1300-offer account and used to sit ON the event loop:
    the first click after a restart looked dead and starved the app's health/WS probes (which is
    what killed the gateway). Daemon thread, short delay for config/state to settle, failures
    swallowed.
    """
    def worker() -> None:
        try:
            time.sleep(3.0)
            for store in _stores():
                if not isinstance(store, dict):
                    continue
                sid = str(store.get("id") or "")
                if sid and _key_configured(sid):
                    _WARM_AT[sid] = 0.0  # first warm ignores the 60s per-store guard
                    _prewarm_offers(sid)
                    # 总览那一屏还要 sales / orders / shipments 三路真接口（实测合计 ~8s，
                    # 全是冷取数），也在这里先热掉，否则后端刚起来后的第一次轮询就得干等。
                    for warm in (_sales_rows, _order_rows, _shipments_rows):
                        try:
                            warm(sid)
                        except Exception:
                            pass
        except Exception:
            pass
    try:
        threading.Thread(target=worker, name="tk-startup-warm", daemon=True).start()
    except Exception:
        pass

VERSION = "1.1.0"
API_BASE = "https://marketplace-api.takealot.com/v1"
VAT_RATE = 0.15
DEEPSEEK_BASE = "https://api.deepseek.com/v1"
DEEPSEEK_MODEL = "deepseek-chat"
HTTP_TIMEOUT = 20

DASHBOARD_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = DASHBOARD_DIR.parent
DATA_DIR = DASHBOARD_DIR / "data"
STATE_DIR = PACKAGE_DIR / "state"
EXPORT_DIR = STATE_DIR / "exports"

_LOCK = threading.Lock()


# --------------------------------------------------------------------------
# Money math — 官方 Takealot 费率 + 真店账单验证过的计费模型
#
# 费率来源：dashboard/data/takealot_fees_official.json
#   由官方文档生成（2025_Success_Fee_Pricing.pdf 105 页 / Takealot_Pricing_Schedule.pdf
#   12 页），生成脚本 scripts/build_fee_data.py —— 不要手改 JSON。
#
# 计费模型（真店 store-2，2026-09-23，7 笔已计费订单 + /transactions 流水逐笔核对）：
#   成功费实扣 = 售价(含 VAT) x 类目费率 x 1.15    如 R379 x 10% x 1.15 = R43.58
#   履约费实扣 = 官方价目表金额(不含 VAT) x 1.15   如 R45 x 1.15 = R51.75 / R33 -> 37.95 / R60 -> 69.00
#   跨仓罚金   = R20 x 1.15 = R23.00
#   月订阅费   = R400 x 1.15 = R460.00
#   官方文档原文：成功费按「含 VAT 售价」的百分比计算；其余费用为不含 VAT 金额，
#   实际计收时按含 VAT 入账（/transactions 每笔 charge-* 的 vat_multiplier = 0.15）。
#
#   VAT 不从卖家「到手」里另扣：/transactions 把买家支付的含税全额记入卖家
#   （payment-customer-order = 1499.00 对 R1499 的标价，vat_multiplier = 0.00）。
#   所以 VAT 只嵌在平台收费里，不作为独立扣项。跨境的 VAT 由平台代收代缴，
#   卖家侧不出现缴纳动作 —— 这一点是真店流水的事实，不是推断。
# --------------------------------------------------------------------------

FEE_DATA_FILE = "takealot_fees_official.json"

#: 平台所有收费按含 VAT 入账（官方价目表金额为不含 VAT 值）
FEE_VAT_MULTIPLIER = 1.0 + VAT_RATE

#: 官方价目表没有列「最低成功费」，真店导出也证明平台不设下限：
#: 一笔 R39 的订单实收成功费 5.38（= 39 × 12% × 1.15，不含 VAT 仅 R4.68），低于 R5。
#: 所以本工具**不再套用任何下限**；这个常量只留给 /meta/fees 说明用。
MIN_SUCCESS_FEE = 5.00
MIN_SUCCESS_FEE_NOTE = ("官方价目表未列明最低成功费；商家后台 Orders Detailed 导出里 "
                        "R39 的订单实收 5.38（不含 VAT 4.68），证明平台不设下限，"
                        "本工具因此也不套用下限。")

#: 结算/成本配置的默认值文件（客户可在 state/profit_config.json 覆盖，见 profit_config()）
PROFIT_DEFAULTS_FILE = "profit_defaults.json"

#: 旧版「宽口径类目名」-> 官方主类目（仅作为最后一级兜底，命中时会标注 source）
LEGACY_CATEGORY_ALIASES: Dict[str, str] = {
    "consumer electronics": "TV & Audio",
    "computers & tablets": "Computers & Laptops",
    "cellphones & wearables": "Mobile",
    "audio & headphones": "Audio",
    "home & kitchen": "Homeware",
    "large appliances": "Large Appliances",
    "small domestic appliances": "Small Appliances",
    "fashion & apparel": "Clothing & Footwear",
    "shoes & footwear": "Clothing & Footwear",
    "luggage & bags": "Luggage & Travel",
    "beauty & personal care": "Beauty",
    "health & wellness": "Health",
    "toys & baby": "Toys",
    "automotive & motor accessories": "Automotive",
    "sports & outdoors": "Sport",
    "office, stationery & books": "Stationery",
    "diy, tools & garden": "DIY & Automotive",
    "general merchandise": "Non-Perishable",
}

#: 商品词 -> 官方子类目（按使用演化：命中不了就把词加进来，别改官方费率）
SUCCESS_FEE_SYNONYMS: Sequence[Tuple[str, str, str]] = (
    ("graphics card", "Computer Components", "Graphics Card"),
    ("motherboard", "Computer Components", "Motherboard"),
    ("power supply", "Computer Components", "Power Supplies"),
    ("ssd", "Data Storage", "Harddrive"),
    ("hard drive", "Data Storage", "Harddrive"),
    ("usb flash", "Data Storage", "USB Flash Devices"),
    ("memory card", "Laptop Accessories", "Memory Cards"),
    ("laptop bag", "Laptop Accessories", "Bags & Cases"),
    ("mouse pad", "Laptop Accessories", "Other"),
    ("tablet", "Mobile", "Tablets & E-readers"),
    ("cellphone", "Mobile", "Cellphones"),
    ("smartphone", "Mobile", "Cellphones"),
    ("sim card", "Mobile", "Airtime & Contracts"),
    ("smart watch", "Wearable", "Other"),
    ("fitness tracker", "Wearable", "Health Tracker Devices"),
    ("makeup", "Beauty", "Cosmetics"),
    ("eyelash", "Beauty", "Cosmetics"),
    ("eyeshadow", "Beauty", "Cosmetics"),
    ("lipstick", "Beauty", "Cosmetics"),
    ("nail polish", "Beauty", "Cosmetics"),
    ("perfume", "Beauty", "Fragrances"),
    ("fragrance", "Beauty", "Fragrances"),
    ("shampoo", "Hair Care", "Shampoo"),
    ("hair dryer", "Hair Care", "Electrical Beauty"),
    ("straightener", "Hair Care", "Electrical Beauty"),
    ("moisturiser", "Skin Care", "Moisturisers"),
    ("moisturizer", "Skin Care", "Moisturisers"),
    ("sunscreen", "Skin Care", "Other"),
    # ↓ 2026-09-23 用商家后台 Orders Detailed 导出反推补的词（见
    #   scripts/validate_against_portal_export.py：导出里这 7 个 SKU 的费率是
    #   laser engraver 10% / nail file 14% / teasing comb 12% / EV charging cable 10%
    #   / portable steamer 10% / massage slimming 11% / laptop battery 10%）
    ("laser engraver", "DIY & Automotive", "Tools & Machinery"),
    ("laser cutter", "DIY & Automotive", "Tools & Machinery"),
    ("nail file", "Cosmetics", "Nails"),
    ("manicure", "Cosmetics", "Nails"),
    ("rat tail comb", "Hair Care", "Styling Tools"),
    ("teasing comb", "Hair Care", "Styling Tools"),
    ("hair comb", "Hair Care", "Styling Tools"),
    ("ev charging", "Automotive", "Automotive Parts & Accessories"),
    ("charging cable", "Automotive", "Automotive Parts & Accessories"),
    ("steamer", "Small Appliances", "Small Household Appliances"),
    ("massage", "Health", "Health Care Devices"),
    ("laptop battery", "Laptop Accessories", "Batteries"),
    ("notebook battery", "Laptop Accessories", "Batteries"),
    ("replacement battery", "Laptop Accessories", "Batteries"),
    ("battery compatible", "Laptop Accessories", "Batteries"),
    ("car key", "Automotive", "Automotive Parts & Accessories"),
    ("key shell", "Automotive", "Automotive Parts & Accessories"),
    ("diagnostic", "Automotive", "Automotive Parts & Accessories"),
    ("ediabas", "Automotive", "Automotive Parts & Accessories"),
    ("obd", "Automotive", "Automotive Parts & Accessories"),
    ("brake pad", "Automotive", "Automotive Parts & Accessories"),
    ("wiper", "Automotive", "Automotive Parts & Accessories"),
    ("headlight", "Automotive", "Automotive Parts & Accessories"),
    ("wheel bearing", "Automotive", "Automotive Parts & Accessories"),
    ("spare part", "Automotive", "Automotive Parts & Accessories"),
    ("workshop", "Automotive", "Workshop & Maintenance"),
    ("motorcycle", "Automotive", "Motorcycle Parts & Accessories"),
    ("laptop", "Computers & Laptops", "Laptops"),
    ("desktop pc", "Desktop Computers & Workstations", "Desktop Computers"),
    ("monitor", "Computer Monitors & Accessories", "Computer Monitors"),
    ("router", "Networking", "Access Points & Routers"),
    ("headphone", "Audio", "Headphones & Headsets"),
    ("earphone", "Audio", "Headphones & Headsets"),
    ("speaker", "Audio", "Speakers"),
    ("earbud", "Audio", "Headphones & Headsets"),
    ("power bank", "Laptop Accessories", "Power Banks"),
    ("charger", "Laptop Accessories", "Chargers & Adapters"),
    ("phone case", "Electronic Accessories", "Cellular Accessories"),
    ("screen protector", "Smart Accessories", "Screen Protectors"),
    ("kettle", "Small Appliances", "Small Kitchen Appliances"),
    ("toaster", "Small Appliances", "Small Kitchen Appliances"),
    ("blender", "Small Appliances", "Small Kitchen Appliances"),
    ("air fryer", "Small Appliances", "Small Kitchen Appliances"),
    ("coffee machine", "Small Appliances", "Small Kitchen Appliances"),
    ("microwave", "Large Appliances", "Microwaves & Cookers"),
    ("fridge", "Large Appliances", "Fridges & Freezers"),
    ("washing machine", "Large Appliances", "Washing & Drying"),
    ("dishwasher", "Large Appliances", "Dishwashers"),
    ("cookware", "Homeware", "Kitchen"),
    ("cutlery", "Homeware", "Kitchen"),
    ("bedding", "Bedroom", "Inners & Pillows"),
    ("pillow", "Bedroom", "Inners & Pillows"),
    ("duvet", "Bedroom", "Inners & Pillows"),
    ("towel", "Homeware", "Bathroom"),
    ("curtain", "Homeware", "Home Decor"),
    ("rug", "Homeware", "Home Decor"),
    ("wall clock", "Homeware", "Home Decor"),
    ("led strip", "Homeware", "Home Decor"),
    ("tent", "Camping & Outdoor", "Tents & Shelters"),
    ("sleeping bag", "Camping & Outdoor", "Sleeping"),
    ("backpack", "Storage & Packs", "Storage Bags, Boxes & Liners"),
    ("flashlight", "Lighting & Gadgets", "Headlamps"),
    ("torch", "Lighting & Gadgets", "Spot Lights"),
    ("garden hose", "Garden, Pool & Patio", "Garden & Outdoor Consumables"),
    ("pool", "Garden, Pool & Patio", "Pool & Spa"),
    ("drill", "DIY & Automotive", "Tools & Machinery"),
    ("screwdriver", "DIY & Automotive", "Tools & Machinery"),
    ("tool set", "DIY & Automotive", "Tools & Machinery"),
    ("paint", "Homeware", "Paint & Supplies"),
    ("stationery", "Stationery", "General Stationery"),
    ("notebook", "Stationery", "Paper"),
    ("pen", "Stationery", "Writing & Drawing Tools"),
    ("printer", "Printers, Scanner, Copier", "Printers"),
    ("ink cartridge", "Office Consumables", "Ink"),
    ("toner", "Office Consumables", "Toner"),
    ("office chair", "Office Furniture & Storage", "Chairs & Seating"),
    ("desk", "Office Furniture & Storage", "Tables & Desks"),
    ("toy", "Toys", "Other"),
    ("puzzle", "Toys", "Games & Puzzles"),
    ("board game", "Toys", "Games & Puzzles"),
    ("doll", "Toys", "Indoor Play"),
    ("leash", "Pets", "Equipment & Accessories"),
    ("cat litter", "Pets", "Pet Care Supplies"),
    ("dog food", "Pets", "Food & Treats"),
    ("nappy", "Baby", "Nappies & Changing"),
    ("diaper", "Baby", "Nappies & Changing"),
    ("baby bottle", "Baby", "Mom & Baby Care"),
    ("stroller", "Baby", "Baby Equipment & Furniture"),
    ("t-shirt", "Clothing & Footwear", "Mens Clothing"),
    ("sneaker", "Clothing & Footwear", "Footwear"),
    ("handbag", "Luggage & Travel", "Handbags & Wallets"),
    ("suitcase", "Luggage & Travel", "Luggage"),
    ("necklace", "Jewellery & Watches", "Jewellery"),
    ("bracelet", "Jewellery & Watches", "Jewellery"),
    ("wrist watch", "Jewellery & Watches", "Watches"),
    ("dumbbell", "Sport", "Equipment"),
    ("yoga mat", "Sport", "Equipment"),
    ("bicycle", "Sport", "Equipment"),
    ("supplement", "Health", "Health FMCG"),
    ("vitamin", "Health", "Health FMCG"),
    ("thermometer", "Health", "Health Care Devices"),
    ("massager", "Health", "Personal Care Devices"),
    ("camera lens", "Cameras & Lenses", "Lenses"),
    ("action camera", "Action Cams & Drones", "Action Cameras"),
    ("drone", "Action Cams & Drones", "Drones"),
    ("guitar", "Instruments", "Guitars"),
    ("keyboard piano", "Instruments", "Keyboards"),
    ("game console", "Games", "Consoles"),
    ("video game", "Games", "Game-Software"),
    ("gaming chair", "Gaming Accessories", "Gaming Chairs"),
    ("book", "Books", "Trade Books"),
    ("dvd", "Music & DVD", "Movies"),
)

#: 履约费（DC）行使用的官方分类分组 —— 官方表按「标准/大件/超大」和类目分组定价
FULFILMENT_GROUP_RULES: Sequence[Tuple[str, str]] = (
    ("non-perishable", "nonPerishableHouseholdLiquor"),
    ("non perishable", "nonPerishableHouseholdLiquor"),
    ("liquor", "nonPerishableHouseholdLiquor"),
    ("spirits", "nonPerishableHouseholdLiquor"),
    ("wine", "nonPerishableHouseholdLiquor"),
    ("beer", "nonPerishableHouseholdLiquor"),
    ("household cleaning", "nonPerishableHouseholdLiquor"),
    ("grocery", "nonPerishableHouseholdLiquor"),
    ("groceries", "nonPerishableHouseholdLiquor"),
    ("stationery", "stationeryPetsBabyHealthBeautyBathroom"),
    ("pencil", "stationeryPetsBabyHealthBeautyBathroom"),
    ("eyelash", "stationeryPetsBabyHealthBeautyBathroom"),
    ("manicure", "stationeryPetsBabyHealthBeautyBathroom"),
    ("nail polish", "stationeryPetsBabyHealthBeautyBathroom"),
    ("nail file", "stationeryPetsBabyHealthBeautyBathroom"),
    ("hair", "stationeryPetsBabyHealthBeautyBathroom"),
    ("comb", "stationeryPetsBabyHealthBeautyBathroom"),
    ("massage", "stationeryPetsBabyHealthBeautyBathroom"),
    ("steamer", "mobileComputersElectronics"),
    ("pets", "stationeryPetsBabyHealthBeautyBathroom"),
    ("baby", "stationeryPetsBabyHealthBeautyBathroom"),
    ("beauty", "stationeryPetsBabyHealthBeautyBathroom"),
    ("cosmetic", "stationeryPetsBabyHealthBeautyBathroom"),
    ("makeup", "stationeryPetsBabyHealthBeautyBathroom"),
    ("luxury beauty", "stationeryPetsBabyHealthBeautyBathroom"),
    ("personal care", "stationeryPetsBabyHealthBeautyBathroom"),
    ("health", "stationeryPetsBabyHealthBeautyBathroom"),
    ("bathroom", "stationeryPetsBabyHealthBeautyBathroom"),
    ("mobile", "mobileComputersElectronics"),
    ("cellphone", "mobileComputersElectronics"),
    ("tablet", "mobileComputersElectronics"),
    ("computer", "mobileComputersElectronics"),
    ("laptop", "mobileComputersElectronics"),
    ("smart home", "mobileComputersElectronics"),
    ("smart audio", "mobileComputersElectronics"),
    ("smart energy", "mobileComputersElectronics"),
    ("appliance", "mobileComputersElectronics"),
    ("audio", "mobileComputersElectronics"),
    ("video", "mobileComputersElectronics"),
    ("television", "mobileComputersElectronics"),
    ("certified pre-owned", "mobileComputersElectronics"),
    # 电脑/数码零部件（官方把 Computer Components 归在这一组）
    ("graphics card", "mobileComputersElectronics"),
    ("gpu", "mobileComputersElectronics"),
    ("motherboard", "mobileComputersElectronics"),
    ("cpu", "mobileComputersElectronics"),
    ("ram", "mobileComputersElectronics"),
    ("ssd", "mobileComputersElectronics"),
    ("hard drive", "mobileComputersElectronics"),
    ("memory card", "mobileComputersElectronics"),
    ("monitor", "mobileComputersElectronics"),
    ("keyboard", "mobileComputersElectronics"),
    ("mouse", "mobileComputersElectronics"),
    ("desktop", "mobileComputersElectronics"),
    ("notebook", "mobileComputersElectronics"),
    ("phone", "mobileComputersElectronics"),
    ("headphone", "mobileComputersElectronics"),
    ("earphone", "mobileComputersElectronics"),
    ("earbud", "mobileComputersElectronics"),
    ("speaker", "mobileComputersElectronics"),
    ("soundbar", "mobileComputersElectronics"),
    ("projector", "mobileComputersElectronics"),
    ("power bank", "mobileComputersElectronics"),
    ("charger", "mobileComputersElectronics"),
)

#: 官方履约费表里「All other categories」那一档的键：清单之外的类目都归这一档
FULFILMENT_OTHER_GROUP = "allOtherCategories"


def _r(value: Any, nd: int = 2) -> float:
    """JS ``Number(x.toFixed(nd))`` — half-away-from-zero, not banker's rounding."""
    try:
        num = float(value)
    except (TypeError, ValueError):
        return 0.0
    if num != num or num in (float("inf"), float("-inf")):
        return 0.0
    q = Decimal(1).scaleb(-nd)
    return float(Decimal(repr(num)).quantize(q, rounding=ROUND_HALF_UP))


def fee_reference() -> Dict[str, Any]:
    """官方费率表（官方 PDF 生成的数据文件）；读不到就返回空 dict，绝不编数。"""
    data = _load_data(FEE_DATA_FILE, {})
    return data if isinstance(data, dict) else {}


def fee_reference_meta() -> Dict[str, Any]:
    ref = fee_reference()
    meta = ref.get("_meta") if isinstance(ref, dict) else None
    return meta if isinstance(meta, dict) else {}


def _official_success_rules() -> Dict[str, List[Dict[str, Any]]]:
    ref = fee_reference()
    section = ref.get("successFees") if isinstance(ref, dict) else None
    rules = (section or {}).get("mainCategories") if isinstance(section, dict) else None
    return rules if isinstance(rules, dict) else {}


def _modal_rate(rules: List[Dict[str, Any]]) -> Optional[float]:
    """主类目众数费率（子类目匹配不上时的兜底，会在 source 里标明）。"""
    counts: Dict[float, int] = {}
    for rule in rules or []:
        try:
            rate = float(rule.get("rate"))
        except (TypeError, ValueError):
            continue
        counts[rate] = counts.get(rate, 0) + 1
    if not counts:
        return None
    best = max(counts.items(), key=lambda kv: (kv[1], kv[0]))
    return best[0]


def _parse_price_condition(condition: Optional[str]) -> Optional[Tuple[str, float]]:
    """Parse the PDF's own wording: ``if price <= R2999`` -> (``<=``, 2999.0)."""
    if not condition:
        return None
    match = re.search(r"price\s*(<=|>=|<|>)\s*R?\s*([\d\s]+)", str(condition))
    if not match:
        return None
    try:
        amount = float(match.group(2).replace(" ", ""))
    except ValueError:
        return None
    return match.group(1), amount


def _condition_holds(condition: Optional[str], price: Optional[float]) -> Optional[bool]:
    """True/False when the condition can be evaluated, None when price is unknown."""
    parsed = _parse_price_condition(condition)
    if parsed is None:
        return True
    if price is None or price <= 0:
        return None
    operator, threshold = parsed
    if operator == "<=":
        return price <= threshold
    if operator == ">=":
        return price >= threshold
    if operator == "<":
        return price < threshold
    return price > threshold


#: 类目未知时的占位标签 —— 它必须永远不参与费率匹配（否则 "General Merchandise"
#: 会被官方子类目 "Merchandise" 命中，凭空得到一个 15% 的费率）
CATEGORY_UNKNOWN_LABEL = "General Merchandise"

#: 官方费率表里的通用子类目名：出现在几乎任何类目路径里，不能作为归类依据
GENERIC_SUB_NAMES = {
    "other", "accessories", "merchandise", "equipment", "consumables", "components",
    "tools", "sets", "cases", "cables", "video", "audio", "beauty", "baby", "pets",
    "toys", "sport", "health", "stationery", "lighting", "furniture", "kitchen",
    "bathroom", "bedding", "batteries", "chargers", "display", "adapters", "protectors",
    "stands", "mounts", "covers", "sleeves", "bags", "clothing", "footwear", "parts",
    "appliances", "hardware", "media", "software", "games", "craft", "decor", "storage",
    "blankets", "cleaning & repairs",
}


def _category_parts(*parts: Any) -> List[str]:
    """过滤掉空值与「未知」占位标签，剩下的才是真类目线索。"""
    out: List[str] = []
    for part in parts:
        text = str(part or "").strip()
        if not text or text.lower() == CATEGORY_UNKNOWN_LABEL.lower():
            continue
        out.append(text)
    return out


def resolve_success_fee(category: Optional[str] = None, price: Optional[float] = None,
                        title: Optional[str] = None, department: Optional[str] = None,
                        category_path: Optional[str] = None) -> Dict[str, Any]:
    """把商品归到官方成功费子类目，返回费率 + 命中依据（命中不了就说命中不了）。

    ``rate`` 为 None 表示「未匹配到官方子类目」——调用方必须把它显示成未知，
    不要用默认费率冒充。
    """
    rules = _official_success_rules()
    path_hay = " ".join(_category_parts(category_path, category, department)).lower()
    full_hay = " ".join(_category_parts(path_hay, title)).lower()
    if not full_hay.strip():
        return {"rate": None, "source": "empty-input", "note": "没有类目/标题信息，无法归类目费率。"}

    def match_official(hay: str) -> Optional[Dict[str, Any]]:
        """官方子类目名最长命中（官方文档用词优先）。

        通用词（Other / Accessories / Equipment…）不参与命中：它们出现在几乎任何
        类目路径里，放进来只会把「Automotive > … > Car Key Accessories」这种路径
        误判成某个 Accessories 子类目。这些情形交给商品词表处理。
        """
        best: Optional[Tuple[int, str, Dict[str, Any]]] = None
        for main, rows in rules.items():
            for rule in rows:
                sub = str(rule.get("sub") or "")
                key = sub.lower()
                if len(sub) < 6 or key in GENERIC_SUB_NAMES:
                    continue
                if key in hay and (best is None or len(sub) > best[0]):
                    best = (len(sub), main, rule)
        if best is None:
            return None
        _length, main, rule = best
        holds = _condition_holds(rule.get("condition"), price)
        if holds is False:
            return None
        return {"rate": float(rule["rate"]), "mainCategory": main,
                "subCategory": rule.get("sub"), "condition": rule.get("condition"),
                "source": "subcategory-name",
                "note": "类目文本里直接出现官方子类目「{0}」（{1}）".format(rule.get("sub"), main)}

    # 1) 类目路径/部门里的官方子类目名 —— 这是平台的元数据，优先于标题里的商品词
    hit = match_official(path_hay) if path_hay.strip() else None
    if hit:
        return hit

    # 2) 商品词表（最长优先，随使用演化）
    for needle, main, sub in sorted(SUCCESS_FEE_SYNONYMS, key=lambda row: -len(row[0])):
        if needle in full_hay and main in rules:
            for rule in rules[main]:
                if str(rule.get("sub") or "").lower() == sub.lower():
                    holds = _condition_holds(rule.get("condition"), price)
                    if holds is not False:
                        return {"rate": float(rule["rate"]), "mainCategory": main,
                                "subCategory": rule.get("sub"), "condition": rule.get("condition"),
                                "source": "synonym:" + needle,
                                "note": "按商品词「{0}」归到 {1} > {2}".format(needle, main, rule.get("sub"))}

    # 3) 标题里也出现官方子类目名（没有类目路径时的兜底）
    hit = match_official(full_hay)
    if hit:
        return hit

    # 4) 官方主类目名命中 -> 该主类目众数费率（明确标注是兜底）
    for main, rows in rules.items():
        if str(main).lower() in full_hay:
            rate = _modal_rate(rows)
            if rate is not None:
                return {"rate": rate, "mainCategory": main, "subCategory": None,
                        "condition": None, "source": "main-category-modal",
                        "note": ("只匹配到主类目「{0}」，用该主类目众数费率 {1:.1f}%"
                                 "（子类目未知，可能与实际差 1-3 个百分点）").format(main, rate * 100.0)}

    # 5) 旧版宽口径类目名 -> 官方主类目众数费率
    for needle, main in sorted(LEGACY_CATEGORY_ALIASES.items(), key=lambda kv: -len(kv[0])):
        if needle in full_hay and main in rules:
            rate = _modal_rate(rules[main])
            if rate is not None:
                return {"rate": rate, "mainCategory": main, "subCategory": None,
                        "condition": None, "source": "legacy-alias:" + needle,
                        "note": ("旧口径类目「{0}」近似对应官方「{1}」，取众数费率 {2:.1f}%"
                                 "（近似值，建议按真实子类目复核）").format(needle, main, rate * 100.0)}

    return {"rate": None, "source": "unmatched",
            "note": "未匹配到官方成功费子类目：不给费率，也不拿默认费率冒充。"}


def get_category_fee_rate(category: Optional[str]) -> float:
    """兼容旧签名：只返回费率；未匹配时返回 0.0（调用方应改用 resolve_success_fee 拿依据）。"""
    info = resolve_success_fee(category=category)
    rate = info.get("rate")
    return float(rate) if rate is not None else 0.0


def calculate_success_fee(selling_price: float, category: Optional[str],
                          price: Optional[float] = None, title: Optional[str] = None,
                          category_path: Optional[str] = None) -> Dict[str, Any]:
    """成功费：费基 = 官方文档口径的「含 VAT 售价」；实扣 = 费基 x 费率 x 1.15。"""
    info = resolve_success_fee(category=category, price=price if price else selling_price,
                               title=title, category_path=category_path)
    rate = info.get("rate")
    price_value = float(selling_price or 0)
    if rate is None:
        return {
            "category": category or "",
            "rate": None, "ratePercent": None,
            "feeAmount": None, "feeExVat": None, "vatOnFee": None,
            "rateSource": info.get("source"), "note": info.get("note"),
            "mainCategory": info.get("mainCategory"), "subCategory": info.get("subCategory"),
            "minApplied": False, "basis": info.get("note") or "类目费率未知",
        }
    fee_ex = _r(price_value * rate)
    # 不套用最低成功费：真店导出里 R39 的订单实收 5.38（不含 VAT 4.68），平台不设下限。
    min_applied = False
    charged = _r(fee_ex * FEE_VAT_MULTIPLIER)
    return {
        "category": info.get("subCategory") or info.get("mainCategory") or (category or ""),
        "rate": rate,
        "ratePercent": "{0:.1f}%".format(rate * 100.0),
        "feeAmount": charged,          # 平台实扣（含 VAT）
        "feeExVat": fee_ex,
        "vatOnFee": _r(charged - fee_ex),
        "rateSource": info.get("source"),
        "mainCategory": info.get("mainCategory"),
        "subCategory": info.get("subCategory"),
        "condition": info.get("condition"),
        "minApplied": min_applied,
        "note": info.get("note"),
        "basis": ("成功费 = 售价(含VAT) {0:.2f} x {1:.1f}% = {2:.2f}（不含VAT），"
                  "平台按含 VAT 入账 = {3:.2f}").format(price_value, rate * 100.0, fee_ex, charged)
                 + ("；" + MIN_SUCCESS_FEE_NOTE if min_applied else ""),
    }


def calculate_volumetric_weight(length_cm: float, width_cm: float, height_cm: float) -> float:
    if not length_cm or not width_cm or not height_cm:
        return 0.0
    return _r((float(length_cm) * float(width_cm) * float(height_cm)) / 5000.0, 3)


def _fulfilment_rows() -> Dict[str, Any]:
    ref = fee_reference()
    section = ref.get("fulfilmentFees") if isinstance(ref, dict) else None
    return section if isinstance(section, dict) else {}


def _fulfilment_group(hay: str) -> Optional[str]:
    """按官方履约费表的类目分组归类。关键词按词边界匹配，允许 s / es 复数。"""
    for needle, key in FULFILMENT_GROUP_RULES:
        if re.search(r"(?<![a-z])" + re.escape(needle) + r"(?:e?s)?(?![a-z])", hay):
            return key
    return None


def _size_tier_for_volume(volume_cm3: Optional[float]) -> Optional[str]:
    if volume_cm3 is None or volume_cm3 <= 0:
        return None
    rows = _fulfilment_rows().get("sizeTiers") or []
    for row in rows:
        low = row.get("volumeMinCm3")
        high = row.get("volumeMaxCm3")
        if low is not None and volume_cm3 < float(low):
            continue
        if high is not None and volume_cm3 > float(high):
            continue
        return str(row.get("size"))
    return None


def _weight_band_for(weight_kg: Optional[float]) -> Optional[str]:
    if weight_kg is None:
        return None
    for row in _fulfilment_rows().get("weightBands") or []:
        low = row.get("minKg")
        high = row.get("maxKg")
        if low is not None and weight_kg <= float(low):
            continue
        if high is not None and weight_kg > float(high):
            continue
        return str(row.get("band"))
    return None


def calculate_dc_fulfillment_fee(params: Dict[str, Any]) -> Dict[str, Any]:
    """履约费（DC 出库费）：官方按「包装体积 cm³ + 重量档 + 类目分组」定价，不含 VAT。

    实扣 = 官方金额 x 1.15。旧版按体积重/5000 + 仓库系数估算是自造费率，已删除；
    官方价目表里没有仓库附加系数，所以这里不再乘任何系数。
    """
    params = params if isinstance(params, dict) else {}
    weight_kg: Optional[float]
    try:
        raw_weight = params.get("weightKg")
        weight_kg = float(raw_weight) if raw_weight not in (None, "") else None
    except (TypeError, ValueError):
        weight_kg = None
    try:
        length = float(params.get("lengthCm") or 0)
        width = float(params.get("widthCm") or 0)
        height = float(params.get("heightCm") or 0)
    except (TypeError, ValueError):
        length = width = height = 0.0
    volume = _r(length * width * height, 1) if (length and width and height) else None
    hay = " ".join(_category_parts(*[params.get(key) for key in
                                     ("category", "categoryPath", "department", "title")])).lower()
    group_key = _fulfilment_group(hay)
    size_tier = _size_tier_for_volume(volume)
    band = _weight_band_for(weight_kg)

    rows = _fulfilment_rows()
    published: Optional[float] = None
    group_label: Optional[str] = None
    if size_tier == "Standard":
        groups = {str(g.get("key")): g for g in (rows.get("standardCategoryGroups") or [])}
        resolved_key = group_key
        group_note = None
        if not resolved_key and hay.strip():
            # 官方表是穷尽的：不在具名类目组里的都归「All other categories」，不是猜
            resolved_key = FULFILMENT_OTHER_GROUP
            group_note = ("未命中官方具名类目组（非易腐/家清/酒类、文具/宠物/母婴/美妆/个护/健康/卫浴、"
                          "数码家电），按官方「All other categories」档计价")
        if resolved_key and resolved_key in groups:
            group = groups[resolved_key]
            published = (group.get("fees") or {}).get(band) if band else None
            group_label = str(group.get("label"))
        elif band:
            # 完全没有类目信息时不能猜 R22/R33/R45/R60 的哪一档：给出区间并标注
            options = sorted({float((g.get("fees") or {}).get(band))
                              for g in (rows.get("standardCategoryGroups") or [])
                              if (g.get("fees") or {}).get(band) is not None})
            note_range = "R {0}".format(" / R ".join("{0:g}".format(v) for v in options)) if options else ""
            return {
                "warehouse": str(params.get("warehouse") or ""),
                "tier": "Standard (≤35 000 cm³，类目分组未匹配)",
                "sizeTier": size_tier, "weightBand": band, "categoryGroup": None,
                "volumeCm3": volume, "chargeableWeightKg": weight_kg,
                "fulfillmentFeeExVatZar": None, "vatOnFeeZar": None, "fulfillmentFeeZAR": None,
                "feeCandidatesExVat": options,
                "feeSource": "category-group-unmatched",
                "note": ("包装体积落在 Standard(≤35 000 cm³)，但完全没有类目信息，"
                         "官方该档在不同类目组是 {0}（不含 VAT）：不给单一数字，"
                         "请补类目后确认。").format(note_range),
            }
    elif size_tier and band:
        published = (rows.get("rows") or {}).get(size_tier, {}).get(band)
        group_label = "按体积档（与类目分组无关）"

    if published is None:
        missing = []
        if volume is None:
            missing.append("包装尺寸（长x宽x高 cm）")
        if band is None:
            missing.append("重量（kg）")
        return {
            "warehouse": str(params.get("warehouse") or ""),
            "tier": None, "sizeTier": size_tier, "weightBand": band, "categoryGroup": group_key,
            "volumeCm3": volume, "chargeableWeightKg": weight_kg,
            "fulfillmentFeeExVatZar": None, "vatOnFeeZar": None, "fulfillmentFeeZAR": None,
            "feeSource": "missing-input",
            "note": "缺 {0}：官方履约费按体积档+重量档定价，缺输入就不给数字。".format("、".join(missing) or "有效输入"),
        }

    charged = _r(float(published) * FEE_VAT_MULTIPLIER)
    return {
        "warehouse": str(params.get("warehouse") or ""),
        "tier": "{0} / {1}".format(size_tier, band),
        "sizeTier": size_tier, "weightBand": band,
        "categoryGroup": group_key, "categoryGroupLabel": group_label,
        "volumeCm3": volume,
        "actualWeightKg": weight_kg, "chargeableWeightKg": weight_kg,
        "dimensions": "{0:g} x {1:g} x {2:g} cm".format(length, width, height) if volume else "",
        "fulfillmentFeeExVatZar": _r(published),
        "vatOnFeeZar": _r(charged - float(published)),
        "fulfillmentFeeZAR": charged,          # 平台实扣（含 VAT）
        "feeSource": "official-table",
        "note": ("官方履约费 R {0:g}（不含 VAT）x 1.15 = R {1:.2f}（含 VAT，平台实扣）"
                 "{2}").format(float(published), charged,
                               "；" + group_note if group_note else ""),
    }


def profit_config() -> Dict[str, Any]:
    """结算参数：默认值来自 data/profit_defaults.json，客户可用 state/profit_config.json 覆盖。

    汇损系数默认 0.20（客户口径：XT 结汇大约在这个量级），可自行改；
    汇率不预置猜测值 —— 客户填多少就是多少，没填就算不出来。
    """
    defaults = _load_data(PROFIT_DEFAULTS_FILE, {})
    defaults = defaults if isinstance(defaults, dict) else {}
    override = _read_state("profit_config.json", {})
    override = override if isinstance(override, dict) else {}
    merged = dict(defaults)
    merged.update({k: v for k, v in override.items() if v not in (None, "")})
    return merged


def _money_or_none(value: Any) -> Optional[float]:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def calculate_order_profit(order: Dict[str, Any]) -> Dict[str, Any]:
    """单件利润：售价 - 平台费用（含 VAT 实扣）- 成本（含汇损与头程）。

    与真店账单一致的扣项：成功费、履约费、（可选）跨仓费/仓储费。VAT 不作为独立
    扣项 —— 它只嵌在平台收费里，且平台把买家支付的含税全额记给卖家。
    """
    order = order if isinstance(order, dict) else {}
    config = profit_config()
    selling_price = _money_or_none(order.get("sellingPrice")) or 0.0
    category = str(order.get("category") or "")
    title = str(order.get("productTitle") or order.get("title") or "")

    fee_result = calculate_success_fee(selling_price, category or None, price=selling_price,
                                       title=title,
                                       category_path=str(order.get("categoryPath") or ""))
    dc_result = calculate_dc_fulfillment_fee({
        "weightKg": order.get("weightKg"),
        "lengthCm": order.get("lengthCm"),
        "widthCm": order.get("widthCm"),
        "heightCm": order.get("heightCm"),
        "category": category,
        "categoryPath": order.get("categoryPath") or category,
        "department": order.get("department"),
        "title": title,
        "warehouse": order.get("warehouse"),
    })

    # ── 成本项：商品成本（ZAR 或 RMB÷汇率）＋ 汇损 ＋ 头程物流 ────────────────
    cost_currency = str(order.get("costCurrency") or config.get("costCurrency") or "ZAR").upper()
    cost_rmb = _money_or_none(order.get("costRmb"))
    cogs_zar_input = _money_or_none(order.get("cogsCost"))
    exchange_rate = _money_or_none(order.get("exchangeRateZarPerRmb"))
    if exchange_rate is None:
        exchange_rate = _money_or_none(config.get("exchangeRateZarPerRmb"))
    exchange_loss = _money_or_none(order.get("exchangeLossCoeff"))
    if exchange_loss is None:
        exchange_loss = _money_or_none(config.get("exchangeLossCoeff"))
    if exchange_loss is None:
        exchange_loss = 0.0
    head_logistics = _money_or_none(order.get("headLogisticsZar")) or 0.0
    inbound = _money_or_none(order.get("inboundFreight")) or 0.0

    product_cost_zar: Optional[float] = None
    exchange_loss_zar = 0.0
    needs_exchange_rate = False
    if cost_currency == "RMB" and cost_rmb:
        if exchange_rate:
            product_cost_zar = _r(cost_rmb / exchange_rate)
            exchange_loss_zar = _r(product_cost_zar * exchange_loss)
        else:
            needs_exchange_rate = True
            product_cost_zar = None
    elif cogs_zar_input is not None:
        product_cost_zar = _r(cogs_zar_input)

    # ── 平台费用（全部为平台实扣的含 VAT 金额）──────────────────────────────
    success_fee = fee_result.get("feeAmount")
    dc_fee = dc_result.get("fulfillmentFeeZAR")
    cross_dc = bool(order.get("crossDcTransfer"))
    cross_dc_fee = None
    if cross_dc:
        ibt_rows = fee_reference().get("autoIbtPenaltyFees") or {}
        tier = None
        target = dc_result.get("sizeTier")
        band = dc_result.get("weightBand")
        for row in (ibt_rows.get("tiers") or []):
            if str(row.get("size")) == str(target):
                tier = row
                break
        if tier and band:
            published_ibt = (tier.get("fees") or {}).get(band)
            if published_ibt is not None:
                cross_dc_fee = _r(float(published_ibt) * FEE_VAT_MULTIPLIER)

    known_fees: List[Optional[float]] = [success_fee, dc_fee]
    if cross_dc:
        known_fees.append(cross_dc_fee)
    fees_complete = all(value is not None for value in known_fees)
    fees_total = _r(sum(float(value) for value in known_fees if value is not None))

    costs_complete = product_cost_zar is not None and not needs_exchange_rate
    cost_total = None
    if costs_complete:
        cost_total = _r(float(product_cost_zar or 0.0) + exchange_loss_zar + head_logistics + inbound)

    net_profit = None
    margin = None
    if fees_complete and costs_complete and selling_price > 0:
        net_profit = _r(selling_price - fees_total - float(cost_total or 0.0))
        margin = _r((net_profit / selling_price) * 100, 1)

    rate = fee_result.get("rate")
    break_even = None
    recommended_20 = None
    if rate is not None and costs_complete and dc_fee is not None:
        fixed = float(cost_total or 0.0) + float(dc_fee) + float(cross_dc_fee or 0.0)
        denom = 1.0 - rate * FEE_VAT_MULTIPLIER          # 成功费按含 VAT 计入
        if denom > 0:
            break_even = _r(fixed / denom)
        denom20 = denom - 0.20
        if denom20 > 0:
            recommended_20 = _r(fixed / denom20)

    # ── 逐项明细：界面直接照这个渲染，每一项都带依据 ─────────────────────────
    breakdown: List[Dict[str, Any]] = [{
        "key": "sellingPrice", "label": "买家支付（售价，含 VAT）",
        "amount": _r(selling_price), "sign": 1,
        "basis": "平台把含税全额记给卖家（/transactions payment-customer-order 原值）",
    }]
    breakdown.append({
        "key": "successFee", "label": "成功费（含 VAT）",
        "amount": success_fee, "sign": -1,
        "exVat": fee_result.get("feeExVat"), "vat": fee_result.get("vatOnFee"),
        "ratePercent": fee_result.get("ratePercent"),
        "basis": fee_result.get("basis"),
    })
    breakdown.append({
        "key": "dcFee", "label": "履约费 DC（含 VAT）",
        "amount": dc_fee, "sign": -1,
        "exVat": dc_result.get("fulfillmentFeeExVatZar"), "vat": dc_result.get("vatOnFeeZar"),
        "basis": dc_result.get("note"),
    })
    if cross_dc:
        breakdown.append({
            "key": "crossDcFee", "label": "跨仓费 Auto IBT（含 VAT）",
            "amount": cross_dc_fee, "sign": -1,
            "basis": "官方 Auto IBT 罚金表 x 1.15（真店实测 R20 x 1.15 = R23.00）",
        })
    if product_cost_zar is not None:
        breakdown.append({
            "key": "productCost", "label": "商品成本（ZAR）",
            "amount": product_cost_zar, "sign": -1,
            "basis": ("RMB {0:g} / 汇率 {1:g} = R {2:.2f}").format(cost_rmb or 0, exchange_rate or 0, product_cost_zar)
                     if cost_currency == "RMB" and exchange_rate else "客户填写的 ZAR 成本",
        })
    if exchange_loss_zar:
        breakdown.append({
            "key": "exchangeLoss", "label": "汇损（XT 结汇系数 {0:.0%}）".format(exchange_loss),
            "amount": exchange_loss_zar, "sign": -1,
            "basis": "商品成本 x 汇损系数（客户可在 state/profit_config.json 调整，默认 0.20）",
        })
    if head_logistics:
        breakdown.append({"key": "headLogistics", "label": "头程物流（ZAR）",
                          "amount": _r(head_logistics), "sign": -1, "basis": "客户填写"})
    if inbound:
        breakdown.append({"key": "inboundFreight", "label": "入仓运费（ZAR）",
                          "amount": _r(inbound), "sign": -1, "basis": "客户填写"})

    warnings: List[str] = []
    if not fees_complete:
        warnings.append("平台费用不全（" + "；".join(
            part for part in [
                fee_result.get("note") if success_fee is None else "",
                dc_result.get("note") if dc_fee is None else "",
                "跨仓费未定" if cross_dc and cross_dc_fee is None else "",
            ] if part) + "）：不给到手金额。")
    if needs_exchange_rate:
        warnings.append("成本按 RMB 记录但没有汇率：请填 XT 结汇汇率（state/profit_config.json 的 "
                        "exchangeRateZarPerRmb），填之前不给到手金额。")
    if not costs_complete and not needs_exchange_rate and product_cost_zar is None:
        warnings.append("没有商品成本记录：到手金额留空（绝不按比例编成本）。")
    if net_profit is not None and net_profit < 0:
        warnings.append("按当前售价与成本，单件亏损 R {0:.2f}。".format(abs(net_profit)))

    return {
        "orderId": order.get("orderId") or "",
        "productTitle": title,
        "sku": order.get("sku") or "",
        "tsin": order.get("tsin") or "",
        "category": category or fee_result.get("category") or "",
        "categoryPath": order.get("categoryPath") or "",
        "warehouse": dc_result.get("warehouse") or "",
        "sellingPrice": _r(selling_price),
        "successFee": success_fee,
        "successFeeExVat": fee_result.get("feeExVat"),
        "successFeeVat": fee_result.get("vatOnFee"),
        "successFeeRate": fee_result.get("ratePercent"),
        "successFeeRateSource": fee_result.get("rateSource"),
        "successFeeNote": fee_result.get("note"),
        "mainCategory": fee_result.get("mainCategory"),
        "subCategory": fee_result.get("subCategory"),
        "dcFulfillmentFee": dc_fee,
        "dcFeeExVat": dc_result.get("fulfillmentFeeExVatZar"),
        "dcFeeVat": dc_result.get("vatOnFeeZar"),
        "dcTier": dc_result.get("tier"),
        "dcTierSource": dc_result.get("feeSource"),
        "dcNote": dc_result.get("note"),
        "dcFeeCandidatesExVat": dc_result.get("feeCandidatesExVat"),
        "volumeCm3": dc_result.get("volumeCm3"),
        "chargeableWeightKg": dc_result.get("chargeableWeightKg"),
        "crossDcFee": cross_dc_fee,
        "platformFeesTotal": fees_total if fees_complete else None,
        "platformFeesComplete": fees_complete,
        "cogsCost": _r(product_cost_zar) if product_cost_zar is not None else None,
        "costCurrency": cost_currency,
        "costRmb": _r(cost_rmb) if cost_rmb else None,
        "exchangeRateZarPerRmb": exchange_rate,
        "exchangeLossCoeff": exchange_loss,
        "exchangeLossZar": exchange_loss_zar,
        "needsExchangeRate": needs_exchange_rate,
        "inboundFreight": _r(inbound),
        "headLogisticsZar": _r(head_logistics),
        "totalCostsZar": cost_total,
        "totalDeductionsZar": _r(fees_total + float(cost_total or 0.0)) if (fees_complete and costs_complete) else None,
        "netProfit": net_profit,
        "toHandZar": net_profit,
        "profitMarginPercent": margin,
        "isLoss": bool(net_profit is not None and net_profit < 0),
        "breakEvenPrice": break_even,
        "recommendedPrice20": recommended_20,
        "vatZar": None,
        "vatNote": ("VAT 不作为独立扣项：平台把买家支付的含税全额记给卖家，"
                    "VAT 只嵌在平台收费里（每笔 charge-* 含 15%）。跨境 VAT 由平台代收代缴。"),
        "warning": " ".join(warnings) or None,
        "warnings": warnings,
        "breakdown": breakdown,
        "basis": ("到手 = 售价(含VAT) - 平台费用(成功费+履约费[+跨仓费]，均为含 VAT 实扣) "
                  "- 商品成本 - 汇损 - 头程物流"),
        "feeReference": {
            "file": FEE_DATA_FILE,
            "successFeeBase": fee_reference_meta().get("successFeeBase"),
            "vatRate": VAT_RATE,
            "source": fee_reference_meta().get("source"),
        },
    }


# --------------------------------------------------------------------------
# 订单口径（真实 Seller API /sales）—— 本文件不内置任何示例订单 / 示例商品。
#
# 2026-09-20 实测（真店 store-2，/sales 分页共 83 行）：行字段只有
#   order_id, order_item_id, sku, quantity, selling_price, success_fee,
#   fulfillment_fee, courier_collection_fee, stock_transfer_fee, total_fees,
#   sale_status, sales_region, stock_source_region, order_date, tsin_id, offer_id
# 且 83 行里只有 3 行已计费（total_fees != 0）—— 平台费用滞后于结算。
#
# 写死的口径（每个响应都回显 basis，便于逐单对账）：
#   营收   = Σ(售价 x 数量)            —— /sales 原值
#   平台费 = Σ total_fees              —— 平台真正已计的费
#   净利   = 营收 - 平台费              —— 未扣采购成本（Seller API 不提供 COGS）
#   我方核算成功费 = 类目费率 x 售价    —— 只在类目已知时给数字，未知则 null + 原因
# 拿不到依据的字段一律 null，绝不填 0 冒充。
# --------------------------------------------------------------------------

ORDER_BASIS = (
    "营收 = Σ(售价 x 数量)（/sales 原值）；平台费 = Σ total_fees（平台已计费部分，"
    "滞后于结算，实测真店 83 行中仅 3 行已计费）；净利 = 营收 - 平台费（未扣采购成本，"
    "Seller API 不提供 COGS）；我方核算成功费只在类目已知时给出。"
)

#: /sales 的 sale_status -> UI 规范状态标签（纯标签映射，不动任何数值口径）
SALE_STATUS_LABELS: Dict[str, str] = {
    "new lead time order": "Awaiting Shipment",
    "confirmed shipment": "Awaiting Shipment",
    "shipped shipment": "Shipped",
    "shipped to customer": "Delivered",
    "collected": "Collected",
    "returned": "Returned",
    "cancelled": "Cancelled",
    "canceled": "Cancelled",
}


def _canonical_sale_status(value: Any) -> str:
    """平台原始 sale_status -> UI 规范状态；不认识的原始值原样返回（不猜）。"""
    raw = str(value or "").strip()
    return SALE_STATUS_LABELS.get(raw.lower(), raw)


#: 历史种子行清单：这些 id / SKU 是旧版本的内置示例数据写进 state 的，首次读到时清掉
#: （见 _purge_legacy_seed_rows）。客户自己新增的行不在清单里，一条都不会丢。
SEED_ROW_IDS: Dict[str, List[str]] = {
    "collection.json": ["COL-1001", "COL-1002", "COL-1003", "COL-1004", "COL-1005", "COL-1006"],
    "drafts.json": ["DRF-2001", "DRF-2002", "DRF-2003", "DRF-2004"],
    "competitors.json": ["TSIN-8492019", "TSIN-7382910", "TSIN-9182374", "TSIN-5524183", "TSIN-6612233"],
    "price_log.json": ["TKL-AUDIO-01", "TKL-AUTO-09", "TKL-HOME-14", "TKL-KITCH-33", "TKL-ELEC-52",
                       "TKL-POWER-01", "TKL-DIY-07", "TKL-SPORT-22", "TKL-TOY-11", "TKL-PET-06"],
    "rules.json": ["TKL-AUDIO-01", "TKL-AUTO-09", "TKL-HOME-14", "TKL-KITCH-33", "TKL-ELEC-52"],
}

#: 只有「在种子清单里」且「写入时间早于交付日」的行才算种子（双条件，杜绝误删）
SEED_CUTOFF = "2026-09-18"

#: 需要"标识 + 时间"双重判定的文件：这些文件的行 id 是通用序号（COL-1001 / DRF-2001），
#: 客户以后自己新增时完全可能再撞上同一个 id，所以必须带上时间条件；
#: rules.json / price_log.json 是按 SKU 索引的，SKU 命中种子清单本身就足以证明是旧种子行
#: （真实店铺的 SKU 形如 HGNEW0821093050988 / 9902290491593，不可能等于 TKL-AUDIO-01）。
SEED_STRICT_FILES = ("collection.json", "drafts.json", "competitors.json")

_SEED_STRIPPED: Dict[str, int] = {}
_SEED_STRIP_DONE: set = set()


def _purge_legacy_seed_rows(name: str) -> Any:
    """读 state 文件，并把旧版本写入的种子行清掉（只清一次，留审计）。

    删除条件是两个，必须同时成立：
      1) 行的 id / tsin / sku 在 SEED_ROW_IDS[name] 里；
      2) 行的写入时间戳早于 SEED_CUTOFF。
    因此客户在交付后自己新增的行（如 COL-1007+）永远保留。
    """
    data = _read_state(name, None)
    if data is None:
        return [] if name != "rules.json" else {}
    seeds = SEED_ROW_IDS.get(name) or []
    if not seeds or name in _SEED_STRIP_DONE:
        return data
    removed: List[str] = []
    strict = name in SEED_STRICT_FILES
    if isinstance(data, list):
        keep: List[Any] = []
        for row in data:
            if not isinstance(row, dict):
                keep.append(row)
                continue
            # 行的任何一个标识字段命中种子清单即算种子行（订单日志用 tsin、草稿用 id…）
            keys = [str(row.get(field) or "") for field in ("id", "tsin", "sku", "plid", "sourceUrl")]
            hit = next((k for k in keys if k and k in seeds), None)
            stamp = str(row.get("addedAt") or row.get("updatedAt") or row.get("trackedAt") or "")
            if hit and (not strict or not stamp or stamp[:10] < SEED_CUTOFF):
                removed.append(hit)
                continue
            keep.append(row)
        if removed:
            _write_state(name, keep)
        data = keep
    elif isinstance(data, dict):
        for key in list(data):
            row = data.get(key)
            stamp = str((row or {}).get("updatedAt") or "") if isinstance(row, dict) else ""
            if str(key) in seeds and (not strict or not stamp or stamp[:10] < SEED_CUTOFF):
                removed.append(str(key))
                del data[key]
        if removed:
            _write_state(name, data)
    _SEED_STRIP_DONE.add(name)
    if removed:
        _SEED_STRIPPED[name] = _SEED_STRIPPED.get(name, 0) + len(removed)
        hist = _read_state("seed_migration.json", {})
        hist = dict(hist) if isinstance(hist, dict) else {}
        hist[name] = {"removed": removed, "at": _iso_now(),
                      "rule": "id in SEED_ROW_IDS AND written before " + SEED_CUTOFF}
        _write_state("seed_migration.json", hist)
        log.info("takealot-erp: stripped %d seed row(s) from %s: %s", len(removed), name, removed)
    return data



def _normalize_status(value: Any) -> str:
    """Canonical compare key for an order status.

    The UI filters with snake_case ids (`awaiting_shipment`) while rows carry the
    Takealot label (`Awaiting Shipment`); normalising BOTH sides here keeps the
    filter honest without forcing either vocabulary on the other.
    """
    return " ".join(re.split(r"[\s_\-]+", str(value or "").strip().lower())).strip()


SALES_ROWS_TTL = 60.0        # /sales 行缓存（按店）：一个页面里多次派生分析只取一次
_SALES_ROWS_BY_STORE: Dict[str, Dict[str, Any]] = {}


def _sales_rows(store_id: Any = None, allow_fetch: bool = True, force: bool = False) -> Dict[str, Any]:
    """该店真实的 /sales 行 + 取数状态（按店缓存 60 秒）。

    没有 Key、店铺未知、或接口失败 -> rows 为空 + error + requires，绝不返回替代数据。
    """
    info = _effective_store(store_id)
    sid = str(info.get("storeId") or "")
    bucket = _SALES_ROWS_BY_STORE.setdefault(sid or "__none__", {
        "at": 0.0, "rows": [], "error": None, "truncated": False, "fetched": False,
        "storeId": sid, "storeName": info.get("storeName") or "", "requires": None})
    now = time.time()
    if not force and bucket.get("fetched") and (now - float(bucket.get("at") or 0)) < SALES_ROWS_TTL:
        return bucket
    if not sid:
        bucket.update({"at": now, "rows": [], "fetched": True, "truncated": False,
                       "error": "没有可用店铺：先在「多店铺设置」绑定并选定一家店",
                       "requires": "storeId"})
        return bucket
    if not _key_configured(sid):
        bucket.update({"at": now, "rows": [], "fetched": True, "truncated": False,
                       "error": "店铺 {0} 未绑定 Seller X-API-Key：读不到 /sales".format(sid),
                       "requires": "Seller Key"})
        return bucket
    if not allow_fetch:
        bucket.update({"error": bucket.get("error") or "订单缓存为空（本次进程还没取过一次 /sales）",
                       "requires": None})
        return bucket
    rows, err, truncated = _fetch_live_sales(sid)
    bucket.update({"at": now, "rows": rows, "error": err, "truncated": truncated, "fetched": True,
                   "storeId": sid, "storeName": info.get("storeName") or ""})
    return bucket


def _order_rows(store_id: Any = None) -> List[Dict[str, Any]]:
    """真实订单行 = Seller API /sales x 本店商品目录 x 客户本地成本记录。

    字段名是 UI 契约（CONTRACT /orders），但每一个值都有来源：
      - 订单号 / SKU / TSIN / 数量 / 售价 / 日期 / 区域 / 状态：/sales 原值
      - 标题 / 类目 / 重量：本店 /offers 目录 + 公开页抓取缓存
      - 平台费 / 成功费 / 履约费：/sales 原值（total_fees / success_fee / fulfillment_fee…）
      - 我方核算成功费：类目费率 x 售价，只在类目已知时给数
      - 成本：只认客户本地记录（采集箱/规则里的 cost），没有就是 None
    """
    data = _sales_rows(store_id)
    context = _catalog_items(store_id=store_id)
    by_sku = {str(i.get("sku") or ""): i for i in (context.get("items") or [])}
    costs = _cost_map()
    rows: List[Dict[str, Any]] = []
    for sale in data.get("rows") or []:
        sku = str(sale.get("sku") or "")
        item = by_sku.get(sku) or {}
        enrichment = item.get("enrichment") if isinstance(item.get("enrichment"), dict) else {}
        price = _r(sale.get("selling_price") or 0)
        qty = int(sale.get("quantity") or 1) or 1
        gross = _r(price * qty)
        fees = _r(sale.get("total_fees") or 0)
        success = _r(sale.get("success_fee") or 0)
        dc = _r(_r(sale.get("fulfillment_fee") or 0) + _r(sale.get("courier_collection_fee") or 0)
                + _r(sale.get("stock_transfer_fee") or 0))
        expected: Optional[float] = None
        rate_known = False
        rate_note = ""
        if item and price:
            try:
                comm = _commission({"selling_price": price}, item)
                amount = comm.get("amount")
                expected = _r(amount) if amount is not None else None
                rate_known = amount is not None
                rate_note = "{0} · {1}".format(comm.get("ratePercent") or "未匹配",
                                               "类目已归到官方子类目" if rate_known else "类目未匹配官方价目表")
            except Exception:  # pragma: no cover - defensive
                expected = None
        cost = costs.get(sku)
        net = _r(gross - fees)
        warning = ""
        if not fees:
            warning = ("平台尚未对本单计费（/sales total_fees = 0，费用滞后于结算）："
                       "净利只按已计费口径算，最终以「财务与对账」的 /transactions 流水为准。")
        elif not rate_known:
            warning = "类目未知：算不出「我方核算成功费」，逐单差额不可比。"
        rows.append({
            "orderId": str(sale.get("order_id") or ""),
            "orderItemId": str(sale.get("order_item_id") or ""),
            "sku": sku,
            "tsin": "TSIN{0}".format(sale.get("tsin_id")) if sale.get("tsin_id") else "",
            "title": str(item.get("title") or ""),
            "category": str(enrichment.get("categoryPath") or ""),
            "status": _canonical_sale_status(sale.get("sale_status")),
            "saleStatus": str(sale.get("sale_status") or ""),
            "orderDate": str(sale.get("order_date") or "")[:10],
            "orderDateRaw": str(sale.get("order_date") or ""),
            "warehouse": str(sale.get("stock_source_region") or sale.get("sales_region") or ""),
            "salesRegion": str(sale.get("sales_region") or ""),
            "quantity": qty,
            "sellingPrice": gross,
            "unitPrice": price,
            "successFee": success,
            "successFeeRate": rate_note if rate_known else None,
            "expectedSuccessFee": expected if rate_known else None,
            "dcFee": dc,
            "dcTier": None,
            "chargeableWeightKg": item.get("weightKg"),
            "cogs": _r(cost) if cost else None,
            "costKnown": cost is not None,
            "inboundFreight": None,
            "supplyCost": _r(cost) if cost else None,
            "platformDeductions": fees,
            "feesCharged": bool(fees),
            # /sales 的分项原值（detail 里逐项展示，别只给一个合并数）
            "billedFulfillmentFee": _r(sale.get("fulfillment_fee") or 0),
            "billedCourierFee": _r(sale.get("courier_collection_fee") or 0),
            "billedStockTransferFee": _r(sale.get("stock_transfer_fee") or 0),
            "vatIncludedZAR": _r(gross / 1.15 * 0.15) if gross else None,
            # 预估扣减：类目未知时按默认费率估算（明确标注是估算，不是平台已计费）
            "estimatedSuccessFee": _r(expected * qty) if expected is not None else None,
            "estimateBasis": ("{0} x 售价 x 数量 = 估算成功费（估算，非平台计费）".format(rate_note)
                              if expected is not None else ""),
            "feesBilled": bool(fees or success or dc),
            "billedDcFee": dc,
            "feeRateKnown": rate_known,
            "netProfit": net,
            "marginPercent": _r(net / gross * 100, 1) if gross else None,
            "isLoss": net < 0,
            "breakEvenPrice": None,
            "recommendedPrice20": None,
            "warning": warning,
            "basis": ORDER_BASIS,
            "storeId": str(data.get("storeId") or ""),
            "storeName": str(data.get("storeName") or ""),
        })
    rows.sort(key=lambda r: (r.get("orderDateRaw") or "", r.get("orderId") or ""), reverse=True)
    return rows



# 旧的 BuyBox / 竞品内置示例商品清单、以及竞品分析内置数据库已删除：
# 候选来自本店真实 /offers，竞品历史只来自公开页抓取缓存（state/velocity_cache.json）。

# Compliance seed (core/mock_data.js + category_rules.js + plugin.js RISK_WORDS)
RISK_WORDS: List[str] = [
    "apple", "nike", "samsung", "oem", "100% original", "best seller", "cure", "medical grade",
]
HIGH_RISK_BRANDS: List[str] = [
    "Apple", "Samsung", "Sony", "Bose", "Dyson", "Nike", "Adidas", "Stanley Cup", "Lego",
    "Xiaomi", "JBL", "Rolex", "Anker",
]
SENSITIVE_TERMS: List[str] = [
    "original", "genuine replacement", "fda certified", "military grade", "cure", "anti-covid",
    "100% cure", "patented replica",
]
PROHIBITED_WORDS: List[str] = [
    "best", "cheapest", "hot sale", "100% genuine", "free shipping", "top quality",
    "super sale", "original factory", "warranty included", "guaranteed", "buy now",
    "special offer", "lowest price", "top seller", "limited offer",
]

# 旧的采集箱种子清单已删除：采集箱从空开始，只显示客户自己采集的行。
# 历史种子行由 _purge_legacy_seed_rows('collection.json') 在首次读到时清掉（见 SEED_ROW_IDS）。

# 旧的上架草稿种子清单已删除：草稿只来自客户自己的动作
# （采集箱转草稿 / 上架编排保存 / 预填）。历史种子行由 _purge_legacy_seed_rows 清掉。


_FEATURE_FILLER: List[str] = [
    "Built from quality-checked materials for daily use in South African homes.",
    "Ready to ship from a local warehouse with tracked courier delivery nationwide.",
    "Simple setup with no specialist tools required; instructions included in the box.",
    "Backed by a supplier warranty and easy returns handled through Takealot.",
    "Packed to arrive in perfect condition and ready to use straight away.",
]


# 旧的"确定性假图片 URL"助手已删除：抓不到图片就留空 + 明确提示，不占位。


def _features_from_attributes(title: Any, attributes: Any, subtitle: Any = None,
                              min_len: int = 200) -> str:
    """Deterministic ≥200-char Key Selling Features built from real field values."""
    lines: List[str] = []
    if title:
        lines.append("- {0}".format(str(title).strip()))
    if subtitle:
        lines.append("- {0}".format(str(subtitle).strip()))
    if isinstance(attributes, dict):
        for name, value in attributes.items():
            if value not in (None, ""):
                lines.append("- {0}: {1}".format(name, value))
    text = "\n".join(lines)
    filler_index = 0
    while len(text) < min_len and filler_index < len(_FEATURE_FILLER):
        text += "\n- " + _FEATURE_FILLER[filler_index]
        filler_index += 1
    return text


def _draft_upgrade(draft: Dict[str, Any]) -> Dict[str, Any]:
    """补齐草稿的扩展字段 —— 只用草稿自身 + 平台规则表，不再从种子行借数据。"""
    if not isinstance(draft, dict):
        return draft
    out = dict(draft)

    def missing(key: str) -> bool:
        return out.get(key) in (None, "", [], {})

    if missing("sku"):
        out["sku"] = out.get("tsin") or out.get("id") or ""
    if missing("productType"):
        out["productType"] = "Single"
    if missing("variantGroup"):
        out["variantGroup"] = ""
    if missing("features"):
        out["features"] = _features_from_attributes(
            out.get("title"), out.get("attributes"), out.get("subtitle")
        )
    if missing("whatsInTheBox"):
        out["whatsInTheBox"] = ""
    if missing("images"):
        out["images"] = []
    if missing("videoUrl"):
        out["videoUrl"] = ""
    if missing("warrantyType"):
        out["warrantyType"] = DEFAULT_WARRANTY_TYPE
    if missing("warrantyPeriod"):
        out["warrantyPeriod"] = DEFAULT_WARRANTY_MONTHS
    category_path = str(out.get("categoryPath") or out.get("category") or "")
    segments = _split_path(category_path)
    if missing("mainCategory"):
        resolved = _resolve_catalog_category(category_path)
        out["mainCategory"] = resolved.get("mainCategory") or (segments[0] if segments else "")
    if missing("lowestCategory"):
        out["lowestCategory"] = _norm_path(category_path)
    if missing("storeId"):
        store = _store_row(_store_data().get("activeStoreId")) or {}
        out["storeId"] = store.get("id") or ""
    if missing("storeName"):
        store = _store_row(out.get("storeId")) or _store_row(_store_data().get("activeStoreId")) or {}
        out["storeName"] = store.get("name") or ""
    if missing("status"):
        out["status"] = "draft"
    if not isinstance(out.get("variants"), dict):
        # 老草稿只有 variantThemes/variants（数组，采集箱转入 / prefill 造出来的就是这么存的）
        # → 迁移进新变体模型；空形状=无变体单品。
        legacy_rows = out.get("variants")
        legacy_themes = [str(t).strip() for t in (out.get("variantThemes") or [])
                         if str(t or "").strip()][:2] if isinstance(out.get("variantThemes"), list) else []
        out["variants"] = _variant_model_normalize({
            "axes": [{"key": t, "label": t, "columnName": t, "required": True} for t in legacy_themes],
            "rows": [v for v in legacy_rows if isinstance(v, dict)] if isinstance(legacy_rows, list) else [],
        })
    if missing("attributes"):
        attributes: Dict[str, Any] = {}
        if category_path.strip():
            attributes["Takealot Category Path"] = category_path
            resolved = _resolve_catalog_category(category_path)
            for field in _attribute_fields(str(resolved.get("loadsheetId") or ""))[:20]:
                name = field.get("name")
                if name and field.get("required"):
                    attributes.setdefault(str(name), "")
        out["attributes"] = attributes
    if missing("updatedAt"):
        out["updatedAt"] = _iso_now()
    if missing("price"):
        out["price"] = 0
    if missing("qty"):
        out["qty"] = 1
    compliance = out.get("compliance")
    if not isinstance(compliance, dict):
        compliance = {"hits": []}
    if not isinstance(compliance.get("hits"), list):
        compliance["hits"] = []
    out["compliance"] = compliance
    return out



# --------------------------------------------------------------------------
# Helpers: determinism, state files, masking
# --------------------------------------------------------------------------

# 旧的确定性伪随机数助手（哈希取模生成金额/评分/评论数）已删除。
# 所有调用点改为真实值，或 None + 人话原因。


def _now() -> datetime:
    return datetime.now()


def _iso_now() -> str:
    return _now().strftime("%Y-%m-%d %H:%M")


def _server_time() -> str:
    return _now().strftime("%Y-%m-%dT%H:%M:%S")


def _ensure_state_dir() -> Path:
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return STATE_DIR



# ---------------------------------------------------------------------------
# 密钥静态加密 (at-rest)
#
# The Seller X-API-Key is the one secret this plugin holds, and one seller has a
# single valid key (issuing a new one kills the old). Storing it as plaintext in
# ``state/stores.json`` is not acceptable for delivery: the file is readable by
# anything running as this user, and every backup/copy of it leaks the key.
#
# Everything above this layer keeps working with the PLAINTEXT key in memory; the
# file boundary is the only place that knows about the ciphertext. Windows DPAPI
# (``win32crypt``) scopes the ciphertext to the current user account, which is the
# best available protection without asking the operator for another password.
# When DPAPI is unavailable the value is stored as-is and the store row says so —
# never a fake "encrypted" marker.
_ENC_PREFIX = "dpapi:"
_ENC_KEYS = "_key"


def _crypt_available() -> bool:
    try:
        import win32crypt  # noqa: F401
    except Exception:
        return False
    return True


def _key_protect(value: Any) -> Any:
    """plaintext (in memory) → stored form (on disk)."""
    if not isinstance(value, str) or not value.strip():
        return value
    if value.startswith(_ENC_PREFIX):
        return value
    try:
        import base64
        import win32crypt

        blob = win32crypt.CryptProtectData(value.encode("utf-8"), "takealot-erp", None, None, None, 0)
        if isinstance(blob, tuple):  # some pywin32 builds return (description, blob)
            blob = blob[-1]
        return _ENC_PREFIX + base64.b64encode(bytes(blob)).decode("ascii")
    except Exception as exc:  # pragma: no cover - platform dependent
        log.warning("takealot-erp: key at-rest encryption unavailable (%s); storing as-is", exc)
        return value


def _key_unprotect(value: Any) -> Any:
    """stored form (on disk) → plaintext (in memory)."""
    if not isinstance(value, str) or not value.startswith(_ENC_PREFIX):
        return value
    try:
        import base64
        import win32crypt

        out = win32crypt.CryptUnprotectData(base64.b64decode(value[len(_ENC_PREFIX):]), None, None, None, 0)
        if isinstance(out, tuple):
            out = out[-1]
        return bytes(out).decode("utf-8")
    except Exception as exc:  # pragma: no cover - wrong user / corrupted blob
        log.warning("takealot-erp: cannot decrypt a stored key (%s) — re-enter it in 设置 · 店铺", exc)
        return ""


def _transform_store_keys(data: Any, fn) -> Any:
    """Apply ``fn`` to every ``_key`` inside a stores payload (copy, never in place)."""
    if not isinstance(data, dict):
        return data
    import copy as _copy

    out = _copy.deepcopy(data)
    for row in out.get("stores") or []:
        if isinstance(row, dict) and isinstance(row.get(_ENC_KEYS), str):
            row[_ENC_KEYS] = fn(row[_ENC_KEYS])
    return out


def _store_keys_need_migration() -> bool:
    """True when the file still holds a plaintext key (legacy write)."""
    raw = _read_state_raw("stores.json", None)
    if not isinstance(raw, dict):
        return False
    for row in raw.get("stores") or []:
        if isinstance(row, dict):
            key = row.get(_ENC_KEYS)
            if isinstance(key, str) and key.strip() and not key.startswith(_ENC_PREFIX):
                return True
    return False


def _read_state_raw(name: str, default: Any) -> Any:
    path = STATE_DIR / name
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def _read_state(name: str, default: Any) -> Any:
    path = STATE_DIR / name
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return default
    if name == "stores.json":
        data = _transform_store_keys(data, _key_unprotect)
    return data


def _write_state(name: str, data: Any) -> None:
    _ensure_state_dir()
    if name == "stores.json":
        # only the file ever sees ciphertext
        data = _transform_store_keys(data, _key_protect)
    path = STATE_DIR / name
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        with _LOCK:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
    except OSError as exc:  # pragma: no cover - disk level failure
        log.warning("takealot-erp: cannot write state %s: %s", name, exc)


# 旧的"state 缺失时自动灌种子"助手已删除：state 为空就是空，不再补任何样例数据。


def _mask(secret: Optional[str]) -> str:
    if not secret:
        return ""
    tail = secret[-4:] if len(secret) >= 4 else secret
    return "TKL" + "\u2022" * 4 + tail


_KEY_RE = re.compile(
    r"(?i)(x-api-key|api[_-]?key|authorization|bearer|token)\s*[:=]?\s*[A-Za-z0-9._\-]{6,}"
)


def _sanitize(text: Any) -> str:
    """Strip anything key-shaped out of error strings before they reach the UI."""
    out = str(text or "")
    for secret in _all_secrets():
        if secret and len(secret) >= 8:
            out = out.replace(secret, _mask(secret))
    return _KEY_RE.sub(r"\1=***", out)


# --------------------------------------------------------------------------
# Credentials (.env / state) — the Seller key never leaves the backend
# --------------------------------------------------------------------------

def _env_candidates() -> List[Path]:
    cands: List[Path] = []
    home = os.environ.get("HERMES_HOME")
    if home:
        cands.append(Path(home) / ".env")
    local = os.environ.get("LOCALAPPDATA")
    if local:
        cands.append(Path(local) / "hermes" / ".env")
    cands.append(Path.home() / ".hermes" / ".env")
    return cands


def _load_env_file() -> Dict[str, str]:
    for path in _env_candidates():
        try:
            if not path.is_file():
                continue
            data: Dict[str, str] = {}
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    key, _, value = line.partition("=")
                    data[key.strip()] = value.strip().strip('"').strip("'")
            if data:
                return data
        except OSError:
            continue
    return {}


def _deepseek_key() -> Optional[str]:
    key = os.environ.get("DEEPSEEK_API_KEY")
    if key:
        return key.strip()
    return _load_env_file().get("DEEPSEEK_API_KEY") or None


def _llm_key() -> Optional[str]:
    """当前生效的 LLM Key —— 跟随 Hermes 配置的 provider（阿里千问/DeepSeek/Agnes…）。"""
    try:
        return _spec_llm_channel()[0]
    except Exception:
        return _deepseek_key()


def _llm_base_model() -> Tuple[str, str]:
    """(base_url, model) —— 跟随 Hermes 配置的 provider；拿不到退回 DeepSeek 默认值。"""
    try:
        ch = _spec_llm_channel()
        if ch[0] and ch[1]:
            return ch[1], (ch[2] or DEEPSEEK_MODEL)
    except Exception:
        pass
    return DEEPSEEK_BASE, DEEPSEEK_MODEL


def _store_data() -> Dict[str, Any]:
    default = {
        "activeStoreId": "store-apex-direct",
        "stores": [
            {
                "id": "store-apex-direct",
                "name": "Apex Direct (Pty) Ltd",
                "region": "ZA",
                "_key": "",
                "status": "unverified",
                "createdAt": "2026-09-15 09:00",
                "lastChecked": "",
                "note": "Default test store (no key bound). Paste the Seller X-API-Key to read this shop's real data.",
            }
        ],
    }
    data = _read_state("stores.json", None)
    if not isinstance(data, dict) or not isinstance(data.get("stores"), list) or not data["stores"]:
        data = default
        _write_state("stores.json", data)
    elif _store_keys_need_migration():
        # first run after the at-rest fix: rewrite the legacy plaintext file encrypted
        _write_state("stores.json", data)
        log.info("takealot-erp: migrated state/stores.json key(s) to at-rest encryption")
    return data


def _public_store(row: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": row.get("id", ""),
        "name": row.get("name", ""),
        "keyMasked": _mask(row.get("_key") or ""),
        "status": row.get("status", "unverified"),
        "region": row.get("region", "ZA"),
        "createdAt": row.get("createdAt", ""),
        "lastChecked": row.get("lastChecked", ""),
        "note": row.get("note", ""),
    }


def _active_store() -> Dict[str, Any]:
    data = _store_data()
    stores = data.get("stores") or []
    active_id = data.get("activeStoreId")
    for row in stores:
        if row.get("id") == active_id:
            return row
    return stores[0] if stores else {}


def _store_key_for(store_id: Any = None) -> Tuple[Optional[str], Optional[str], Dict[str, Any]]:
    """``(key, error, store_row)`` for a request scoped to a store.

    ``store_id`` empty → the ACTIVE store (the historical behaviour, so every
    existing caller keeps working). A concrete ``storeId`` resolves THAT store's
    own key — writes must never silently land on a different account than the one
    the caller named (CONTRACT v6: two stores are bound server-side).
    """
    wanted = str(store_id or "").strip()
    if not wanted or wanted in ("active", "*"):
        row = _active_store() or {}
        return ((row.get("_key") or "").strip() or None), None, row
    row = _store_row(wanted)
    if row is None:
        return None, "店铺 {0} 不存在：state/stores.json 里没有这个 storeId".format(wanted), {}
    key = (row.get("_key") or "").strip()
    if not key:
        return None, "店铺 {0}（{1}）未绑定 Seller X-API-Key：无法写入，请先在「设置 · 店铺」里配置。".format(
            wanted, row.get("name") or ""), row
    return key, None, row


def _store_label(store_id: Any = None) -> Dict[str, Any]:
    """``{storeId, storeName, storeScoped}`` for a write response."""
    wanted = str(store_id or "").strip()
    active = _active_store() or {}
    if not wanted or wanted in ("active", "*"):
        return {"storeId": str(active.get("id") or ""), "storeName": str(active.get("name") or ""),
                "storeScoped": False, "activeStoreId": str(active.get("id") or "")}
    row = _store_row(wanted) or {}
    return {"storeId": str(row.get("id") or wanted), "storeName": str(row.get("name") or ""),
            "storeScoped": True, "activeStoreId": str(active.get("id") or "")}


def _seller_key(store_id: Any = None) -> Optional[str]:
    """The Seller X-API-Key a request must use — ONE resolution path for every endpoint.

    ``store_id`` names the bound store (``?storeId=`` / request body); empty = the active
    store, which keeps every historical caller working. A bound store without a key
    resolves to None on purpose: borrowing another store's key is exactly the cross-store
    data leak that must never happen once two shops are bound.
    """
    return _store_key_for(store_id)[0]


def _unresolved_store_error(store_id: Any) -> Optional[Dict[str, Any]]:
    """A non-empty storeId that is not bound must FAIL — never fall back to another shop.

    `''` / 'active' / 'all' keep their meaning (unset -> active store; 'all' -> aggregate),
    so the UI's "no store picked yet" case is unaffected. Anything else that does not
    resolve to a bound store returns an explicit error instead of silently showing a
    different store's numbers (independent acceptance flagged the silent fallback).
    """
    sid = str(store_id or "").strip()
    if not sid or sid in ("active", "*", "all"):
        return None
    eff = _effective_store(sid)
    if eff.get("resolved", True):
        return None
    return {
        "ok": False,
        "mode": "live",
        "empty": True,
        "items": [],
        "storeId": "",
        "requestedStoreId": sid,
        "error": "店铺 {0} 不存在或未绑定：拒绝回退到其它店铺的数据".format(sid),
        "hint": "到「多店铺设置」确认 storeId，或在顶栏/左栏选择一家已绑定的店铺后重试。",
        "resolved": False,
    }


def _effective_store(store_id: Any = None) -> Dict[str, Any]:
    """The store a request is scoped to: the requested one, else the active store.

    Always returns ``storeId``/``storeName`` + ``storeScoped`` so every response can say
    WHICH shop it describes (an unknown storeId is reported, never silently swapped).
    """
    active = _active_store() or {}
    wanted = str(store_id or "").strip()
    if not wanted or wanted in ("active", "*", "all"):
        return {"storeId": str(active.get("id") or ""), "storeName": str(active.get("name") or ""),
                "storeScoped": False, "requestedStoreId": None, "resolved": True,
                "activeStoreId": str(active.get("id") or "")}
    row = _store_row(wanted)
    if row is None:
        return {"storeId": str(active.get("id") or ""), "storeName": str(active.get("name") or ""),
                "storeScoped": False, "requestedStoreId": wanted, "resolved": False,
                "activeStoreId": str(active.get("id") or ""),
                "note": "请求的 storeId {0} 不存在：已回退到激活店铺 {1}（不会静默混用两家店的数据）。".format(
                    wanted, active.get("name") or active.get("id") or "—")}
    return {"storeId": str(row.get("id") or ""), "storeName": str(row.get("name") or ""),
            "storeScoped": True, "requestedStoreId": wanted, "resolved": True,
            "activeStoreId": str(active.get("id") or ""),
            "keyConfigured": bool((row.get("_key") or "").strip())}


def _all_secrets() -> List[str]:
    secrets = [(_active_store().get("_key") or "")]
    for row in (_store_data().get("stores") or []):
        secrets.append(row.get("_key") or "")
    for name in ("DEEPSEEK_API_KEY", "DASHSCOPE_API_KEY", "ALIBABA_CODING_PLAN_API_KEY",
                 "AGNES_NEW_KEY", "AGNES_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY",
                 "GEMINI_API_KEY", "GOOGLE_API_KEY", "XAI_API_KEY", "MOONSHOT_API_KEY",
                 "ZAI_API_KEY", "MINIMAX_API_KEY", "MINIMAX_CN_API_KEY", "OPENROUTER_API_KEY"):
        value = os.environ.get(name) or _load_env_file().get(name)
        if value and str(value).strip():
            secrets.append(str(value).strip())
    _resolved = _llm_key()
    if _resolved:
        secrets.append(_resolved)
    return [s for s in secrets if s]


def _key_configured(store_id: Any = None) -> bool:
    return bool(_seller_key(store_id))


# --------------------------------------------------------------------------
# Live HTTP (urllib, 20s, X-API-Key) — failures degrade to demo, never 500
# --------------------------------------------------------------------------

BROWSER_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"


def _live_proxy_url() -> Optional[str]:
    """Egress for the Seller API — same ladder the crawler uses.

    Cloudflare fronts marketplace-api too, and it rejects the delivery box's own
    ISP egress outright (403 challenge before the key is even looked at), so the
    Seller API MUST honour the configured proxy or every live call fails while the
    crawler — which does honour it — looks fine.
    """
    try:
        module = _crawler()
        if module is not None:
            value = module.proxy_url()
            if value:
                return value
    except Exception:
        pass
    value = os.environ.get("TAKEALOT_API_PROXY", "").strip()
    if value:
        return value
    cfg = (_store_data().get("crawler") or {})
    return str(cfg.get("proxy") or "").strip() or None


def _live_opener() -> urllib.request.OpenerDirector:
    proxy = _live_proxy_url()
    proxy_handler = urllib.request.ProxyHandler({"http": proxy, "https": proxy} if proxy else {})
    return urllib.request.build_opener(proxy_handler)


def _api_request(method: str, endpoint: str, query: Optional[Dict[str, Any]] = None,
                 body: Optional[Dict[str, Any]] = None, store_id: Any = None,
                 meta: Optional[Dict[str, Any]] = None,
                 timeout: Optional[float] = None) -> Tuple[Optional[Any], Optional[str]]:
    """Seller API call.

    ``store_id`` scopes the call to a specific bound store's key ('' = active store,
    the historical behaviour). ``meta`` (a dict the caller owns) receives the raw
    diagnostics — ``status`` / ``raw`` / ``endpoint`` — so a write path can report the
    platform's answer verbatim (CONTRACT v6 §B: never invent, never 500).
    """
    key, key_error, store_row = _store_key_for(store_id)
    if not key:
        return None, key_error or "no Seller X-API-Key configured"
    url = API_BASE + endpoint
    if query:
        clean = {k: v for k, v in query.items() if v not in (None, "")}
        if clean:
            # doseq=True: the spec's array params (expands/fields) must repeat the key.
            # Without it Python's repr leaks into the URL (expands=['a', 'b']) -> HTTP 400.
            url += "?" + urllib.parse.urlencode(clean, doseq=True)
    headers = {
        "X-API-Key": key,
        "Accept": "application/json",
        "Accept-Language": "en-ZA,en;q=0.9",
        "User-Agent": BROWSER_UA,
    }
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    if meta is not None:
        meta.update({"method": method.upper(), "endpoint": endpoint, "url": url,
                     "storeId": str((store_row or {}).get("id") or store_id or ""),
                     "storeName": str((store_row or {}).get("name") or ""),
                     "sentBody": body})
    try:
        with _live_opener().open(req, timeout=float(timeout or HTTP_TIMEOUT)) as resp:
            raw = resp.read().decode("utf-8", "replace")
        if meta is not None:
            meta.update({"status": resp.status, "raw": raw[:4000]})
        if not raw.strip():
            return {}, None
        return json.loads(raw), None
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", "replace")[:200]
        except Exception:
            detail = ""
        if meta is not None:
            meta.update({"status": exc.code, "raw": detail})
        return None, _sanitize("Takealot API {0}: {1}".format(exc.code, detail or exc.reason))
    except Exception as exc:
        if meta is not None:
            meta.update({"status": None, "raw": "{0}: {1}".format(type(exc).__name__, exc)})
        return None, _sanitize("{0}: {1}".format(type(exc).__name__, exc))


# --------------------------------------------------------------------------
# Data files (lazy, cached) — data/*.json copied from the OpenClaw ERP
# --------------------------------------------------------------------------

_DATA_CACHE: Dict[str, Any] = {}


def _load_data(name: str, default: Any) -> Any:
    if name in _DATA_CACHE:
        return _DATA_CACHE[name]
    path = DATA_DIR / name
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError) as exc:
        log.warning("takealot-erp: data file %s unavailable (%s)", name, exc)
        data = default
    _DATA_CACHE[name] = data
    return data


def _category_nodes() -> List[List[Any]]:
    data = _load_data("takealot-categories.json", {})
    nodes = data.get("nodes") if isinstance(data, dict) else None
    if not isinstance(nodes, list):
        return []
    return [n for n in nodes if isinstance(n, list) and len(n) == 2]


def _loadsheet_names() -> Dict[str, str]:
    data = _load_data("takealot-categories.json", {})
    ls = data.get("loadsheets") if isinstance(data, dict) else None
    return ls if isinstance(ls, dict) else {}


def _loadsheet_nodes() -> Dict[str, List[int]]:
    data = _load_data("takealot-categories.json", {})
    lsn = data.get("loadsheetNodes") if isinstance(data, dict) else None
    return lsn if isinstance(lsn, dict) else {}


def _brand_names() -> List[str]:
    # 37k+ 条的重建实测 10ms/次，而它被 compliance_check 每行调一次 → 1322 行白花 13 秒。
    # 数据文件随插件发布、进程内没有写入路径，所以缓存整个进程生命周期是对的。
    cached = _DATA_CACHE.get("__brand_names__")
    if isinstance(cached, list):
        return cached
    data = _load_data("takealot-brands.json", {})
    brands = data.get("brands") if isinstance(data, dict) else None
    if not isinstance(brands, list):
        return []
    out = []
    for entry in brands:
        if isinstance(entry, list) and len(entry) >= 2 and isinstance(entry[1], str):
            out.append(entry[1])
        elif isinstance(entry, str):
            out.append(entry)
    _DATA_CACHE["__brand_names__"] = out
    return out


def _brand_index() -> Dict[str, str]:
    """lowercased brand token -> canonical brand name (lazy, cached)."""
    if "__brand_index__" in _DATA_CACHE:
        return _DATA_CACHE["__brand_index__"]
    index: Dict[str, str] = {}
    for name in _brand_names():
        clean = name.strip()
        if len(clean) < 3 or clean.isdigit():
            continue
        index.setdefault(clean.lower(), clean)
    _DATA_CACHE["__brand_index__"] = index
    return index


def _attribute_loadsheets() -> Dict[str, Any]:
    data = _load_data("takealot-attributes.json", {})
    ls = data.get("loadsheets") if isinstance(data, dict) else None
    return ls if isinstance(ls, dict) else {}


def _attribute_fields(loadsheet_id: str) -> List[Dict[str, Any]]:
    ls = _attribute_loadsheets_all()
    entry = ls.get(str(loadsheet_id))
    if not isinstance(entry, dict):
        return []
    fields = entry.get("fields")
    if not isinstance(fields, dict):
        return []
    recommended = _loadsheet_attribute_groups(loadsheet_id)
    defaults = entry.get("template_defaults") if isinstance(entry.get("template_defaults"), dict) else {}
    out = []
    for fid, meta in fields.items():
        if not isinstance(meta, dict):
            continue
        options = meta.get("options")
        hint = meta.get("description") or ""
        if isinstance(options, list) and options:
            preview = []
            for opt in options[:6]:
                if isinstance(opt, list) and opt:
                    preview.append(str(opt[0]))
                else:
                    preview.append(str(opt))
            hint = (hint + " Options: " + ", ".join(preview)).strip()
        required = bool(meta.get("isRequired"))
        unit = defaults.get("{0}.unit".format(fid))
        if unit is None:
            unit = defaults.get(re.sub(r"\.(value|height|width|length)$", ".unit", str(fid)))
        out.append(
            {
                "name": meta.get("displayName") or str(fid).split(".")[-1],
                "fieldId": fid,
                "type": meta.get("fieldType") or "Text",
                "required": required,
                "hint": hint[:400],
                "group": "required" if required else (recommended.get(str(fid)) or "optional"),
                "unit": unit or "",
            }
        )
    out.sort(key=lambda f: (not f["required"], f["name"].lower()))
    return out


# --------------------------------------------------------------------------
# Derived analytics — 全部来自真实取数，没有任何内置示例行：
#   /sales（订单）、/offers（本店目录）、/balances + /transactions（钱）、
#   /shipments（送仓单）、state/velocity_cache.json（公开页抓取）、客户自己的 state。
# --------------------------------------------------------------------------

SHIPMENTS_TTL = 300.0     # /shipments 行缓存（按店）：总览的 PO 逾期预警用它，5 分钟只取一次
_SHIPMENTS_BY_STORE: Dict[str, Dict[str, Any]] = {}

# 真实财务载荷（/balances + /transactions + /sales）的按店 60 秒缓存：
# /financial、对账、月度汇总、结算单共用同一次取数。
FIN_LIVE_TTL = 60.0
_FIN_LIVE_BY_STORE: Dict[str, Dict[str, Any]] = {}


def _shipments_rows(store_id: Any = None, allow_fetch: bool = True) -> Dict[str, Any]:
    """该店真实送仓单（/shipments）；没有 Key / 取不到 -> rows 空 + error，不补数据。"""
    info = _effective_store(store_id)
    sid = str(info.get("storeId") or "")
    bucket = _SHIPMENTS_BY_STORE.setdefault(sid or "__none__",
                                            {"at": 0.0, "rows": [], "error": None, "fetched": False,
                                             "requires": None})
    now = time.time()
    if bucket.get("fetched") and (now - float(bucket.get("at") or 0)) < SHIPMENTS_TTL:
        return bucket
    if not sid or not _key_configured(sid):
        bucket.update({"at": now, "fetched": True, "rows": [],
                       "error": "店铺未绑定 Seller X-API-Key：读不到 /shipments（送仓单）",
                       "requires": "Seller Key"})
        return bucket
    if not allow_fetch:
        return bucket
    rows, err, _truncated = _fetch_shipments(sid)
    bucket.update({"at": now, "rows": rows, "error": err, "fetched": True, "requires": None})
    return bucket


def _financial_live_cached(store_id: Any = None, allow_fetch: bool = True) -> Dict[str, Any]:
    """`_financial_live_payload` 的按店 60 秒缓存（真实 /balances + /transactions + /sales）。"""
    info = _effective_store(store_id)
    sid = str(info.get("storeId") or "")
    if not sid:
        return {"ok": False, "mode": "live", "error": "没有可用店铺：先在「多店铺设置」绑定并选定一家店",
                "requires": "storeId"}
    bucket = _FIN_LIVE_BY_STORE.setdefault(sid, {"at": 0.0, "value": None})
    now = time.time()
    cached = bucket.get("value")
    if cached is not None and (now - float(bucket.get("at") or 0)) < FIN_LIVE_TTL:
        return cached
    if not _key_configured(sid):
        value = {"ok": False, "mode": "live", "storeId": sid, "storeName": info.get("storeName"),
                 "error": "店铺 {0} 未绑定 Seller X-API-Key：无法读取 /balances 与 /transactions".format(sid),
                 "requires": "Seller Key"}
        bucket.update({"at": now, "value": value})
        return value
    if not allow_fetch and cached is None:
        return {"ok": False, "mode": "live", "storeId": sid, "storeName": info.get("storeName"),
                "error": "本次进程还没取过一次真实财务数据（打开「财务与对账」后即会缓存 60 秒）",
                "requires": "open /financial"}
    value = _financial_live_payload(sid)
    bucket.update({"at": now, "value": value})
    return value


def _days_since(value: Any) -> Optional[int]:
    text = str(value or "")[:10]
    if not text:
        return None
    try:
        return (_now().date() - datetime.strptime(text, "%Y-%m-%d").date()).days
    except ValueError:
        return None


def _blended_net_ratio(rows: Optional[List[Dict[str, Any]]] = None) -> Optional[float]:
    """净利/营收比（真实行）；没有营收就没有比例 —— 返回 None，不编。"""
    rows = _order_rows() if rows is None else rows
    revenue = sum(float(r.get("sellingPrice") or 0) for r in rows)
    if not revenue:
        return None
    return _r(sum(float(r.get("netProfit") or 0) for r in rows) / revenue, 4)


def _trend(days: int = 14, rows: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """近 N 天逐日汇总（/sales 的 order_date 原值聚合）。

    返回 {date, units, orders, lines, revenue, platformFees, netProfit}；
    当天没有订单就是全 0 —— 任何一天都不可能出现「无订单却有金额」。
    """
    rows = _order_rows() if rows is None else rows
    by_date: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        day = str(r.get("orderDate") or "")[:10]
        if day:
            by_date.setdefault(day, []).append(r)
    latest = max(list(by_date) + [_now().strftime("%Y-%m-%d")])
    try:
        end = datetime.strptime(latest, "%Y-%m-%d")
    except ValueError:
        end = _now()
    out: List[Dict[str, Any]] = []
    for offset in range(days - 1, -1, -1):
        day = (end - timedelta(days=offset)).strftime("%Y-%m-%d")
        day_rows = by_date.get(day, [])
        out.append({
            "date": day,
            "units": sum(int(r.get("quantity") or 0) for r in day_rows),
            "orders": len({str(r.get("orderId") or "") for r in day_rows if r.get("orderId")}),
            "lines": len(day_rows),
            "revenue": _r(sum(float(r.get("sellingPrice") or 0) for r in day_rows)),
            "platformFees": _r(sum(float(r.get("platformDeductions") or 0) for r in day_rows)),
            "netProfit": _r(sum(float(r.get("netProfit") or 0) for r in day_rows)),
        })
    return out


def _fee_breakdown(rows: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """费用构成 —— 只列真实取到的字段（/sales 的费用列），每一项都写清来源。"""
    rows = _order_rows() if rows is None else rows

    def total(key: str) -> float:
        return _r(sum(float(r.get(key) or 0) for r in rows))

    pending = len([r for r in rows if not r.get("feesCharged")])
    return [
        {"label": "平台已计费合计 (/sales total_fees)", "amount": total("platformDeductions"),
         "source": "/sales.total_fees", "pendingRows": pending},
        {"label": "成功费 (/sales success_fee)", "amount": total("successFee"), "source": "/sales.success_fee"},
        {"label": "履约+配送+调拨费 (/sales fulfillment+courier+transfer)", "amount": total("dcFee"),
         "source": "/sales.fulfillment_fee + courier_collection_fee + stock_transfer_fee"},
        {"label": "VAT 15%（含税价内含，按售价推算，非平台扣款）",
         "amount": _r(sum(float(r.get("sellingPrice") or 0) - float(r.get("sellingPrice") or 0) / (1 + VAT_RATE)
                          for r in rows)),
         "source": "本地按含税价推算"},
    ]


def _alerts(rows: Optional[List[Dict[str, Any]]] = None, store_id: Any = None) -> List[Dict[str, Any]]:
    """预警 —— 每一条都由一个真实条件推导，并带 evidence（推导依据）。

    条件：亏损单（已计费口径）/ 订单待发货（超 48h 升级）/ 在售商品缺类目（费用核算给不出数）/
    在售但库存为 0 / 送仓 PO 逾期。命中为空就是空数组 —— 没有种子日志，也没有假告警。
    """
    rows = _order_rows(store_id) if rows is None else rows
    alerts: List[Dict[str, Any]] = []

    losses = [r for r in rows if r.get("isLoss")]
    if losses:
        worst = sorted(losses, key=lambda r: float(r.get("netProfit") or 0))[0]
        alerts.append({
            "level": "error",
            "title": "亏损单 {0} 张".format(len(losses)),
            "detail": "最差 {0}：售价 R {1}，平台已计费 R {2}，净 R {3}。".format(
                worst.get("orderId"), worst.get("sellingPrice"),
                worst.get("platformDeductions"), worst.get("netProfit")),
            "evidence": {"orders": [r.get("orderId") for r in losses[:10]], "basis": ORDER_BASIS},
        })

    awaiting = [r for r in rows if str(r.get("status") or "") == "Awaiting Shipment"]
    if awaiting:
        stale = [r for r in awaiting if (_days_since(r.get("orderDate")) or 0) >= 2]
        alerts.append({
            "level": "warn" if stale else "info",
            "title": "{0} 张订单待发货（其中 {1} 张已超 48h）".format(len(awaiting), len(stale)),
            "detail": "平台状态原文：{0}；超期订单：{1}".format(
                ", ".join(sorted({str(r.get("saleStatus") or "") for r in awaiting})) or "—",
                ", ".join(str(r.get("orderId")) for r in stale[:8]) or "无"),
            "evidence": {"statuses": sorted({str(r.get("saleStatus") or "") for r in awaiting})},
        })

    context = _catalog_items(store_id=store_id)
    items = context.get("items") or []
    offers = context.get("offers") or {}
    if items:
        missing_category = [i for i in items
                            if not str((i.get("enrichment") or {}).get("categoryPath") or "").strip()]
        if missing_category:
            alerts.append({
                "level": "warn",
                "title": "{0} 个在售商品缺类目".format(len(missing_category)),
                "detail": "缺类目 -> 「我方核算成功费」算不出来，逐单费用核对不可比。示例：{0}".format(
                    ", ".join(str(i.get("sku")) for i in missing_category[:5])),
                "evidence": {"endpoint": "/products/enrich", "limit": ENRICH_MAX,
                             "skus": [i.get("sku") for i in missing_category[:10]]},
            })
        zero_stock = [i for i in items
                      if i.get("sellable") and int((i.get("stock") or {}).get("totalAvailable") or 0) <= 0]
        if zero_stock:
            alerts.append({
                "level": "warn",
                "title": "{0} 个在售商品库存为 0".format(len(zero_stock)),
                "detail": "可售但仓库可用量为 0：买家能下单却发不出货。示例：{0}".format(
                    ", ".join(str(i.get("sku")) for i in zero_stock[:5])),
                "evidence": {"skus": [i.get("sku") for i in zero_stock[:10]], "source": "/offers stock expands"},
            })
    elif offers.get("error"):
        alerts.append({
            "level": "info",
            "title": "商品目录不可用，缺类目/零库存两类预警跳过",
            "detail": str(offers.get("error"))[:300],
            "evidence": {"requires": offers.get("requires"), "mode": offers.get("mode")},
        })

    shipments = _shipments_rows(store_id)
    if shipments.get("error") is None:
        overdue = []
        for row in shipments.get("rows") or []:
            po = _po_row(row, str(_effective_store(store_id).get("storeId") or ""), "")
            if po.get("actionable") and po.get("daysToDue") is not None and po["daysToDue"] < 0:
                overdue.append(po)
        if overdue:
            worst = sorted(overdue, key=lambda r: r["daysToDue"])[0]
            alerts.append({
                "level": "error",
                "title": "{0} 张送仓 PO 已逾期".format(len(overdue)),
                "detail": "最急 {0}（{1}，截止 {2}，逾期 {3} 天）。".format(
                    worst.get("po"), worst.get("typeLabel"), worst.get("dueDate"), -worst["daysToDue"]),
                "evidence": {"pos": [{"po": r.get("po"), "dueDate": r.get("dueDate"), "daysToDue": r.get("daysToDue")}
                                     for r in overdue[:10]]},
            })
    elif shipments.get("error"):
        alerts.append({
            "level": "info",
            "title": "送仓 PO 逾期预警不可用",
            "detail": str(shipments.get("error"))[:300],
            "evidence": {"requires": shipments.get("requires")},
        })
    return alerts


def _bb_row(listing: Dict[str, Any], rules: Dict[str, Any]) -> Dict[str, Any]:
    """一行 BuyBox 候选：本店价来自 /offers，竞品价/BuyBox 归属来自公开页抓取缓存。"""
    competitors = [c for c in (listing.get("competitors") or []) if _price_of((c or {}).get("price"))]
    lowest = min((_price_of(c.get("price")) for c in competitors), default=None)
    if lowest is None:
        lowest = _price_of(listing.get("lowestCompetitorPrice"))
    competitor_seller = ""
    if competitors:
        competitor_seller = str(min(competitors, key=lambda c: _price_of(c.get("price"))).get("sellerName") or "")
    my_price = _price_of(listing.get("myPrice"))
    floor = _price_of(rules.get("floorPrice"))
    if floor is None:
        floor = _price_of(listing.get("floorPrice"))
    ceiling = _price_of(rules.get("ceilingPrice"))
    crawl = listing.get("crawl") if isinstance(listing.get("crawl"), dict) else {}
    crawled_once = bool(crawl.get("cached"))
    target: Optional[float] = None
    action = "no_data"
    raise_plan: Dict[str, Any] = {}
    note = ("公开页还没有这个商品的抓取记录：在本模块点「补竞品数据」抓一次（每轮有预算上限），"
            "才知道竞品价与 BuyBox 归属（不猜）。"
            if not lowest and listing.get("hasBuybox") is None
            else "平台 /offers 不提供竞品价，也没有公开页抓取记录：先点「补竞品数据」。")
    if lowest and my_price is not None:
        wanted = _r(max(floor or 0.0, lowest - 1.00))
        if floor is not None and wanted < floor:
            action = "floor_guard"
            note = "竞品 R {0} 已低于底价 R {1}，维持现价保护利润（熔断生效）。".format(lowest, floor)
        elif my_price > wanted:
            action, target = "reprice", wanted
            note = "比 {0} 低 R 1.00 抢回 BuyBox（目标价 R {1}）。".format(competitor_seller or "最低竞品", target)
        else:
            # 已不高于目标价 → 这就是「优势抬价」的入口：只在**确实持有 BuyBox + 有竞品参考 +
            # 数据不陈旧**时抬一步（+3%），上界 min(最低竞品−0.01, 上限价)。不满足就照实说明原因，
            # 而不是静默 hold —— 操作员要能看懂"为什么它可以抬/不能抬"。
            plan = _raise_target(my_price, lowest, ceiling, listing.get("hasBuybox"),
                                 crawl.get("ageDays"), rules.get("rrp"))
            if plan.get("proposed"):
                action, target = "raise", plan["proposed"]
                note = plan["note"] + "（抬价要在界面上确认后才写回）"
            else:
                action, target = "hold", wanted
                note = "已不高于目标价 R {0}，无需跟价；".format(wanted) + (plan.get("blockReason") or "")
            raise_plan = plan
    elif crawled_once:
        # 抓过公开页、但页面上没有第三方报价 = 独家在售，不是「缺数据」。
        # 混在 no_data 里会让操作员反复点「补竞品数据」（点了也没用），必须分开说。
        holder = listing.get("buyboxWinner") or ""
        owned = listing.get("hasBuybox")
        action = "no_competitor"
        note = ("公开页已抓：没有第三方卖家报价（独家在售），本轮无需跟价；"
                + ("BuyBox 归我方持有。" if owned is True
                   else ("当前 BuyBox 在 {0} 手上。".format(holder) if (owned is False and holder)
                         else "BuyBox 归属未知。"))
                + "（想复核可以再抓一次，但价格不会因此变化。）")
    return {
        "sku": listing.get("sku"),
        "tsin": listing.get("tsin"),
        "plid": listing.get("plid"),
        "barcode": listing.get("barcode"),
        "title": listing.get("productTitle"),
        "myPrice": my_price,
        "competitorPrice": lowest,
        "competitorSeller": competitor_seller or "—",
        "sellerCount": listing.get("sellerCount"),
        "floorPrice": floor,
        "ceilingPrice": ceiling,
        "targetPrice": target,
        "gap": _r(my_price - lowest) if (my_price is not None and lowest) else None,
        "hasBuybox": listing.get("hasBuybox"),
        "buyboxKnown": isinstance(listing.get("hasBuybox"), bool),
        "autoReprice": bool(rules.get("auto", listing.get("autoRepriceActive", False))),
        "action": action,
        "raiseRoom": raise_plan.get("room"),
        "raiseUpper": raise_plan.get("upper"),
        "raiseStepPercent": raise_plan.get("stepPercent") if action == "raise" else None,
        "raiseBlockReason": (raise_plan.get("blockReason") if (action == "hold" and raise_plan) else None),
        "note": note,
        "lastChecked": _iso_now(),
        "priceSource": ("crawl-cache" if crawl.get("cached") else ("offers" if my_price else "none")),
        "crawl": crawl or None,
        "storeId": listing.get("storeId"),
        "storeName": listing.get("storeName"),
    }


def _rules_map() -> Dict[str, Dict[str, Any]]:
    """客户自己维护的跟价规则（state/rules.json）。没有就是空 —— 不再预置 5 条示例规则。"""
    data = _purge_legacy_seed_rows("rules.json")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(data, dict):
        for key, row in data.items():
            if isinstance(row, dict):
                out[str(key)] = row
    elif isinstance(data, list):
        for row in data:
            if isinstance(row, dict) and row.get("sku"):
                out[str(row["sku"])] = row
    return out


def _candidates(store_id: Any = None, limit: int = 0) -> List[Dict[str, Any]]:
    """BuyBox 候选 —— 来自本店真实 /offers（只取可售 + 有价格的）。

    竞品价 / BuyBox 归属来自公开页抓取缓存（crawler 的 product.offers /
    seller.isBuyboxHolder）；没有抓取记录的行显示为 null + note，不再有内置示例清单。
    """
    context = _catalog_items(store_id=store_id)
    offers = context.get("offers") or {}
    entries = context.get("entries") or {}
    rules = _rules_map()
    sid = str(offers.get("storeId") or _effective_store(store_id).get("storeId") or "")
    store_name = str(offers.get("storeName") or _effective_store(store_id).get("storeName") or "")
    out: List[Dict[str, Any]] = []
    for item in context.get("items") or []:
        if not item.get("sellable"):
            continue
        price = _price_of(item.get("price"))
        if not price:
            continue
        card = _cached_card(item.get("plid") or "", entries) if item.get("plid") else {}
        product = card.get("product") if isinstance(card.get("product"), dict) else {}
        seller = product.get("seller") if isinstance(product.get("seller"), dict) else {}
        raw_offers = product.get("offers") if isinstance(product.get("offers"), list) else []
        competitors = []
        for offer in raw_offers:
            if not isinstance(offer, dict):
                continue
            competitors.append({"sellerName": offer.get("sellerName") or offer.get("seller") or "",
                                "price": _price_of(offer.get("price")),
                                "stock": offer.get("stock")})
        listing = {
            "sku": item.get("sku"),
            "tsin": item.get("tsin"),
            "plid": item.get("plid"),
            "barcode": item.get("barcode"),
            "productTitle": item.get("title"),
            "myPrice": price,
            "floorPrice": None,
            "hasBuybox": seller.get("isBuyboxHolder") if seller else None,
            "buyboxWinner": str(seller.get("name") or ""),
            "competitors": competitors,
            "lowestCompetitorPrice": _price_of(product.get("lowestCompetitorPrice")),
            "sellerCount": product.get("sellerCount"),
            "autoRepriceActive": False,
            "crawl": {"cached": bool(product), "fetchedAt": card.get("fetchedAt"),
                      "stale": bool(card.get("stale"))} if product else {"cached": False},
            "storeId": sid,
            "storeName": store_name,
        }
        out.append(_bb_row(listing, rules.get(str(item.get("sku") or ""), {})))
    if limit and limit > 0:
        return out[:limit]
    return out


def _price_log() -> List[Dict[str, Any]]:
    """调价/写入日志 —— 只读客户自己的 state（历史种子行读到时清掉）。"""
    data = _purge_legacy_seed_rows("price_log.json")
    return [row for row in data if isinstance(row, dict)] if isinstance(data, list) else []


def _collection() -> List[Dict[str, Any]]:
    """采集箱 —— 只装客户自己采集的行（无种子；历史种子行读到时清掉）。"""
    data = _purge_legacy_seed_rows("collection.json")
    return [row for row in data if isinstance(row, dict)] if isinstance(data, list) else []


def _drafts() -> List[Dict[str, Any]]:
    """上架草稿 —— 只装客户自己保存的草稿（无种子）。"""
    data = _purge_legacy_seed_rows("drafts.json")
    rows = [row for row in data if isinstance(row, dict)] if isinstance(data, list) else []
    return [_draft_upgrade(item) for item in rows]


def _collection_row(item: Dict[str, Any]) -> Dict[str, Any]:
    profit = calculate_order_profit(
        {
            "orderId": item.get("id", ""),
            "productTitle": item.get("title", ""),
            "sku": item.get("id", ""),
            "tsin": item.get("tsin", ""),
            "category": item.get("category", ""),
            "categoryPath": item.get("categoryPath") or item.get("category", ""),
            "department": item.get("department"),
            "sellingPrice": float(item.get("estSalePrice") or 0),
            "cogsCost": float(item.get("cost") or 0),
            # 头程运费只认客户自己填的值：以前这里用 cost*0.18 估算，属于编数，已删除
            "inboundFreight": float(item.get("inboundFreight") or 0),
            "costCurrency": item.get("costCurrency"),
            "costRmb": item.get("costRmb"),
            "exchangeRateZarPerRmb": item.get("exchangeRateZarPerRmb"),
            "weightKg": item.get("weightKg"),
            "lengthCm": item.get("lengthCm"),
            "widthCm": item.get("widthCm"),
            "heightCm": item.get("heightCm"),
            "warehouse": item.get("warehouse", "JHB"),
        }
    )
    row = {
        "id": item.get("id", ""),
        "title": item.get("title", ""),
        "tsin": item.get("tsin", ""),
        "barcode": item.get("barcode", ""),
        "brand": item.get("brand", ""),
        "category": item.get("category", ""),
        "sourceUrl": item.get("sourceUrl", ""),
        "imageUrl": item.get("imageUrl", ""),
        "cost": float(item.get("cost") or 0),
        "estSalePrice": float(item.get("estSalePrice") or 0),
        "estProfit": profit["netProfit"],
        "estMargin": profit["profitMarginPercent"],
        # 利润核算明细（界面下拉直接用这一块渲染：成功费/履约费/成本/汇损/头程/到手）
        "profit": {
            "sellingPrice": profit.get("sellingPrice"),
            "successFee": profit.get("successFee"),
            "successFeeExVat": profit.get("successFeeExVat"),
            "successFeeVat": profit.get("successFeeVat"),
            "successFeeRate": profit.get("successFeeRate"),
            "successFeeRateSource": profit.get("successFeeRateSource"),
            "successFeeNote": profit.get("successFeeNote"),
            "dcFee": profit.get("dcFulfillmentFee"),
            "dcFeeExVat": profit.get("dcFeeExVat"),
            "dcFeeVat": profit.get("dcFeeVat"),
            "dcTier": profit.get("dcTier"),
            "dcTierSource": profit.get("dcTierSource"),
            "dcNote": profit.get("dcNote"),
            "dcFeeCandidatesExVat": profit.get("dcFeeCandidatesExVat"),
            "volumeCm3": profit.get("volumeCm3"),
            "platformFeesTotal": profit.get("platformFeesTotal"),
            "platformFeesComplete": profit.get("platformFeesComplete"),
            "cogsCost": profit.get("cogsCost"),
            "exchangeLossCoeff": profit.get("exchangeLossCoeff"),
            "exchangeLossZar": profit.get("exchangeLossZar"),
            "headLogisticsZar": profit.get("headLogisticsZar"),
            "costCurrency": profit.get("costCurrency"),
            "costRmb": profit.get("costRmb"),
            "exchangeRateZarPerRmb": profit.get("exchangeRateZarPerRmb"),
            "needsExchangeRate": profit.get("needsExchangeRate"),
            "totalCostsZar": profit.get("totalCostsZar"),
            "toHandZar": profit.get("toHandZar"),
            "netProfit": profit.get("netProfit"),
            "marginPercent": profit.get("profitMarginPercent"),
            "isLoss": profit.get("isLoss"),
            "breakEvenPrice": profit.get("breakEvenPrice"),
            "recommendedPrice20": profit.get("recommendedPrice20"),
            "breakdown": profit.get("breakdown"),
            "warnings": profit.get("warnings"),
            "vatNote": profit.get("vatNote"),
            "basis": profit.get("basis"),
        },
        "status": item.get("status", "pending"),
        "addedAt": item.get("addedAt", ""),
        # 一键上架的结果（平台 201 回读后落盘）：界面显示「已在 N 家店上架」
        "listedStores": item.get("listedStores") if isinstance(item.get("listedStores"), list) else [],
        "listedAt": item.get("listedAt") or "",
        "note": item.get("note", ""),
        "lastAnalyzedAt": item.get("lastAnalyzedAt", ""),
        "assignedStoreId": item.get("assignedStoreId"),
        "assignedStoreName": item.get("assignedStoreName"),
        "storeName": item.get("assignedStoreName"),
        "crawl": item.get("crawl"),
        # CONTRACT v4 backfill markers: the PLID the row resolves to and when
        # /collection/refresh last wrote images/full text/category into this row.
        "plid": item.get("plid") or "",
        "refreshedAt": item.get("refreshedAt"),
        # ── 跟卖池 vs 新建草稿（用户 2026-09-20 认可的设计）────────────────
        # intent=follow 的行在平台上已存在，只能改价格与库存；intent=new 的行
        # 平台没有（或商家不想跟卖），必须走独立草稿箱。
        "intent": item.get("intent") or "follow",
        "state": item.get("state") or "pool",
        "draftId": item.get("draftId"),
        "source": item.get("source"),
        "price": float(item.get("estSalePrice") or 0),
        "stock": item.get("stock"),
        # 界面的唯一依据：可改的字段 = 平台侧（价格/库存）+ 我方核算输入（成本/币种/汇率/汇损/头程/重量/尺寸）。
        # 后者只是个本地账本，平台看不到，却是费率条件的输入（履约费按体积 cm³ 档定价）。
        "editableFields": list(COLLECTION_WRITABLE_FIELDS),
        # 这些是 listing 内容，跟卖改不了（平台侧锁死）
        "listingFields": list(COLLECTION_LISTING_FIELDS),
        "rule": "跟卖不可修改 listing 内容（标题/图片/描述/类目/条码），只能改价格与库存；"
                "成本/币种/汇率/汇损/头程/重量/尺寸是本地的核算输入，随时可改",
        # 核算输入的原值（界面表单回填用；重量/尺寸决定履约费档位）
        "accounting": {
            "cost": item.get("cost"),
            "costCurrency": item.get("costCurrency"),
            "costRmb": item.get("costRmb"),
            "exchangeRateZarPerRmb": item.get("exchangeRateZarPerRmb"),
            "exchangeLossCoeff": item.get("exchangeLossCoeff"),
            "headLogisticsZar": item.get("headLogisticsZar"),
            "weightKg": item.get("weightKg"),
            "lengthCm": item.get("lengthCm"),
            "widthCm": item.get("widthCm"),
            "heightCm": item.get("heightCm"),
            "volumeCm3": (_r((item.get("lengthCm") or 0) * (item.get("widthCm") or 0)
                             * (item.get("heightCm") or 0), 1) or None),
            "dimensionSource": item.get("dimensionSource"),
            "dimensionRaw": item.get("dimensionRaw"),
        },
    }
    # CONTRACT v4: every 采集箱 row also carries the collected image set, the full
    # crawled text, the category path and a working 上架/跟卖 target. Cache-first and
    # local — this never adds a network call to a plain /collection read.
    try:
        row.update(_collection_row_media(item))
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("takealot-erp: collection media attach failed: %s", exc)
        row.update({
            "images": [item.get("imageUrl")] if item.get("imageUrl") else [],
            "imageUrl": item.get("imageUrl", ""),
            "description": "",
            "descriptionLen": 0,
            "categoryPath": item.get("category", ""),
            "productTargetUrl": "",
            "sellRoute": {},
        })
    if not isinstance(row.get("crawl"), dict):
        row["crawl"] = item.get("crawl")
    return row


def _competitor_rows() -> List[Dict[str, Any]]:
    """竞品监控列表 —— 只装客户自己跟踪的 TSIN（历史种子行读到时清掉）。"""
    data = _purge_legacy_seed_rows("competitors.json")
    return [row for row in data if isinstance(row, dict)] if isinstance(data, list) else []


def _crawl_entry_for(target: Any) -> Dict[str, Any]:
    """公开页抓取缓存里与该 target（TSIN/PLID/SKU）对应的那一条真实记录。"""
    module = _crawler()
    if module is None:
        return {}
    try:
        entries = module.cache_load()
    except Exception:  # pragma: no cover - defensive
        return {}
    if not isinstance(entries, dict) or not entries:
        return {}
    digits = _plid_of(target)
    if digits and isinstance(entries.get(digits), dict):
        return entries[digits]
    needle = str(target or "").strip().lower()
    for key, entry in entries.items():
        if not isinstance(entry, dict):
            continue
        product = entry.get("product") if isinstance(entry.get("product"), dict) else {}
        candidates = [str(key), str(entry.get("plid") or ""), str(product.get("tsin") or ""),
                      str(product.get("plid") or ""), str(product.get("url") or "")]
        if needle and any(needle == c.strip().lower() for c in candidates):
            return entry
        if digits and any(digits == _plid_of(c) for c in candidates if c):
            return entry
    return {}


def _competitor_snapshot(tsin: str, tracked_at: Optional[str] = None,
                         live: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """竞品快照 —— 只用公开页的真实抓取记录 + 本店 offer 匹配结果。

    没有抓取记录时 priceHistory 是空数组 + note，不再用伪随机数造 12 个历史点。
    """
    entry = _crawl_entry_for(tsin)
    product = entry.get("product") if isinstance(entry.get("product"), dict) else {}
    seller = product.get("seller") if isinstance(product.get("seller"), dict) else {}
    sales = entry.get("sales") if isinstance(entry.get("sales"), dict) else {}
    price = _price_of(product.get("price"))
    history: List[Dict[str, Any]] = []
    stored = entry.get("priceHistory")
    if isinstance(stored, list):
        history = [h for h in stored if isinstance(h, dict)]
    if entry and price:
        history = history + [{
            "date": str(entry.get("fetchedAt") or "")[:16],
            "price": price,
            "reviews": product.get("reviews"),
            "transport": entry.get("transport"),
            "source": "crawl-snapshot",
        }]
    own_price = _price_of((live or {}).get("selling_price")) or _price_of((live or {}).get("price"))
    lowest = _price_of(product.get("lowestCompetitorPrice"))
    note = ""
    if not entry:
        note = "暂无历史快照，点「采集」开始记录"
    elif not history:
        note = "该抓取记录里没有价格字段"
    return {
        "tsin": tsin,
        "title": product.get("title") or "",
        "brand": product.get("brand") or "",
        "category": product.get("categoryPath") or product.get("category") or "",
        "myPrice": own_price,
        "buyboxPrice": price,
        "buyboxSeller": str(seller.get("name") or ""),
        "hasBuybox": seller.get("isBuyboxHolder") if seller else None,
        "offersCount": product.get("sellerCount"),
        "lowestOffer": lowest,
        "offerSpread": _r(price - lowest) if (price and lowest) else None,
        "estMonthlySales": sales.get("estimated_monthly_sales") or product.get("estimatedMonthlySales"),
        "estVelocityNote": (entry.get("rateNote") or sales.get("rateNote")
                            or "公开页评论增量反推，来源见 crawl.rateSource"),
        "reviews": product.get("reviews"),
        "rating": product.get("rating"),
        "priceHistory": history,
        "trackedAt": tracked_at or entry.get("fetchedAt") or None,
        "source": "crawl-cache" if entry else "none",
        "crawl": {"cached": bool(entry), "fetchedAt": entry.get("fetchedAt"),
                  "ageDays": entry.get("ageDays"), "transport": entry.get("transport"),
                  "rateSource": entry.get("rateSource")} if entry else {"cached": False},
        "liveError": (live or {}).get("liveError"),
        "note": note,
    }


_RECONCILE_CACHE: Dict[str, Dict[str, Any]] = {}
RECONCILE_TTL = 120.0


def _reconcile(store_id: Any = None, allow_fetch: bool = True) -> Dict[str, Any]:
    """费用核对 —— 平台已计费（/sales total_fees）vs 我方核算（类目费率 x 售价）。

    只在「类目已知」的订单行上比较；取不到真实数据时 totalOverchargedZAR = null
    （不是 0），并写明原因，绝不编一个差异金额。
    """
    info = _effective_store(store_id)
    sid = str(info.get("storeId") or "")
    key = sid or "__none__"
    cached = _RECONCILE_CACHE.get(key)
    if cached and (time.time() - float(cached.get("at") or 0)) < RECONCILE_TTL:
        return cached["value"]
    if not sid or not _key_configured(sid):
        value = {"ok": False, "available": False, "requires": "Seller Key",
                 "totalAuditedRows": 0, "discrepancyCount": 0, "totalOverchargedZAR": None,
                 "discrepancies": [], "status": "无法对账",
                 "note": "未绑定 Seller X-API-Key：读不到 /sales 与 /transactions，所以不给任何差异金额。"}
        _RECONCILE_CACHE[key] = {"at": time.time(), "value": value}
        return value
    live = _financial_live_cached(sid, allow_fetch=allow_fetch)
    if not live.get("ok"):
        value = {"ok": False, "available": False, "requires": live.get("requires") or "Seller Key",
                 "totalAuditedRows": 0, "discrepancyCount": 0, "totalOverchargedZAR": None,
                 "discrepancies": [], "status": "无法对账",
                 "note": "{0}（打开「财务与对账」后会自动重试）".format(live.get("error") or "实时财务数据不可用")}
        if not allow_fetch:
            return value
        _RECONCILE_CACHE[key] = {"at": time.time(), "value": value}
        return value
    rated = int((live.get("orders") or {}).get("ratedLines") or 0)
    rows = [r for r in (live.get("varianceRows") or []) if r.get("variance") is not None]
    discrepancies = sorted(rows, key=lambda r: -abs(float(r.get("variance") or 0)))
    total = _r(sum(abs(float(r.get("variance") or 0)) for r in discrepancies))
    value = {
        "ok": True, "available": True, "storeId": sid, "storeName": live.get("storeName"),
        "totalAuditedRows": rated,
        "discrepancyCount": len(discrepancies),
        "totalOverchargedZAR": total if discrepancies else (0.0 if rated else None),
        "discrepancies": discrepancies[:50],
        "status": ("发现扣费差异" if discrepancies
                   else ("本期账单干净" if rated else "暂无可核对的订单费用（类目未知或费用未结算）")),
        "balances": live.get("balances"),
        "ledger": {"rows": (live.get("ledger") or {}).get("rows"),
                   "credits": (live.get("ledger") or {}).get("credits"),
                   "debits": (live.get("ledger") or {}).get("debits"),
                   "net": (live.get("ledger") or {}).get("net")},
        "needsCategory": live.get("needsCategory"),
        "anomalies": live.get("anomalies") or [],
        "basis": ("逐单比较：平台已计费 /sales.total_fees vs 类目费率 x 售价；"
                  "只在类目已知的行上比较；最终以 /transactions 流水为准"),
        "note": ("没有任何「疑似多收」时返回 0.0 只代表已计费口径下无差异；"
                 "费用滞后与未计费的行会被明确排除（见 orders 块的 ratedLines/truncated）"),
        "errors": live.get("errors"),
    }
    _RECONCILE_CACHE[key] = {"at": time.time(), "value": value}
    return value


def _month_bounds(month: str) -> Tuple[str, str]:
    year, mon = (str(month or "").split("-") + ["", ""])[:2]
    if not (year.isdigit() and mon.isdigit()):
        return "", ""
    first = datetime(int(year), int(mon), 1)
    nxt = datetime(int(year) + (1 if int(mon) == 12 else 0), 1 if int(mon) == 12 else int(mon) + 1, 1)
    return first.strftime("%Y-%m-%d"), (nxt - timedelta(days=1)).strftime("%Y-%m-%d")


def _months(store_id: Any = None) -> List[Dict[str, Any]]:
    """月度汇总 —— 真实 /transactions 流水 + /sales 按月聚合（不再是按比例缩放的假月份）。"""
    live = _financial_live_cached(store_id)
    if not live.get("ok"):
        return []
    out: List[Dict[str, Any]] = []
    for slot in live.get("months") or []:
        by_type = {str(k): float(v or 0) for k, v in (slot.get("byType") or {}).items()}
        fees = _r(sum(abs(v) for k, v in by_type.items() if "charge" in k.lower()))
        out.append({
            "month": slot.get("month"),
            "sales": _r(slot.get("salesGross") or 0),
            "salesRows": slot.get("salesRows") or 0,
            "fees": fees,
            "net": _r(slot.get("net") or 0),
            "credits": _r(slot.get("credits") or 0),
            "debits": _r(slot.get("debits") or 0),
            "txCount": slot.get("txCount") or 0,
            "byType": by_type,
            "basis": "销售额 = /sales 当月合计；费用 = 当月 charge-* 流水合计；净额 = 贷方 - 借方（真实流水）",
        })
    return out


def _statements(store_id: Any = None) -> List[Dict[str, Any]]:
    """结算单视图 —— 按真实流水月份聚合。

    平台不通过 API 提供结算单号，所以单号是本地标签（LEDGER-YYYYMM），已在 basis 里注明。
    """
    live = _financial_live_cached(store_id)
    if not live.get("ok"):
        return []
    current = _now().strftime("%Y-%m")
    out: List[Dict[str, Any]] = []
    for slot in live.get("months") or []:
        month = str(slot.get("month") or "")
        by_type = {str(k): float(v or 0) for k, v in (slot.get("byType") or {}).items()}

        def sum_like(*needles: str) -> float:
            return _r(sum(abs(v) for k, v in by_type.items() if any(n in k.lower() for n in needles)))

        start, end = _month_bounds(month)
        out.append({
            "statementId": "LEDGER-{0}".format(month.replace("-", "")) if month else "",
            "periodStart": start,
            "periodEnd": end,
            "grossSales": _r(slot.get("salesGross") or 0),
            "salesRows": slot.get("salesRows") or 0,
            "successFees": sum_like("success"),
            "dcFees": sum_like("fulfillment", "courier", "delivery", "shipment"),
            "storageFees": sum_like("storage"),
            "advertising": sum_like("advert", "ads"),
            "netPayout": _r(slot.get("net") or 0),
            "credits": _r(slot.get("credits") or 0),
            "debits": _r(slot.get("debits") or 0),
            "txCount": slot.get("txCount") or 0,
            "status": "已结算" if (month and month < current) else "结算中",
            "basis": "按 /transactions 流水月份聚合；单号是本地标签（平台结算单号 API 不提供）",
        })
    return out


def _financial_summary(store_id: Any = None) -> Dict[str, Any]:
    """财务汇总 —— 营收/费用来自真实 /sales，余额与流水来自 /balances + /transactions。"""
    rows = _order_rows(store_id)
    live = _financial_live_cached(store_id)
    gross = _r(sum(float(r.get("sellingPrice") or 0) for r in rows))
    fees = _r(sum(float(r.get("platformDeductions") or 0) for r in rows))
    rec = _reconcile(store_id, allow_fetch=False)
    out: Dict[str, Any] = {
        "grossSales": gross if rows else None,
        "platformFees": fees if rows else None,
        "netPayout": _r(gross - fees) if rows else None,
        "overcharged": rec.get("totalOverchargedZAR"),
        "currency": "ZAR",
        "orders": {"lines": len(rows), "orders": len({r.get("orderId") for r in rows}),
                   "feesChargedLines": len([r for r in rows if r.get("feesCharged")])},
        "basis": ORDER_BASIS,
        "note": ("营收/平台费是 /sales 已计费口径（费用滞后于结算）；余额与流水见 balances/ledger"
                 "（来自 /balances + /transactions）。"),
    }
    if live.get("ok"):
        bal = live.get("balances") or {}
        lg = live.get("ledger") or {}
        out["balances"] = {"current": bal.get("current"), "available": bal.get("available"),
                           "heldBack": bal.get("heldBack"), "consistent": bal.get("consistent")}
        out["ledger"] = {"rows": lg.get("rows"), "credits": lg.get("credits"),
                         "debits": lg.get("debits"), "net": lg.get("net")}
        out["monthCount"] = len(live.get("months") or [])
        out["anomalies"] = live.get("anomalies") or []
    else:
        out["liveError"] = live.get("error")
        out["requires"] = live.get("requires") or "Seller Key"
    return out


def _order_detail(order_id: str, store_id: Any = None) -> Optional[Dict[str, Any]]:
    row = next((r for r in _order_rows(store_id) if str(r.get("orderId")) == str(order_id)), None)
    if not row:
        return None
    _price = float(row.get("sellingPrice") or 0)
    _vat = row.get("vatIncludedZAR")
    lines = [
        {"kind": "revenue", "label": "售价 x 数量（含 VAT 15%）", "amount": _price,
         "note": ("其中 VAT 约 R {0}（南非 15%，已含在售价里、平台代收，不是你被扣的钱）".format(_vat)
                  if _vat is not None else "售价含 VAT（南非 15%），平台代收")},
        {"kind": "billed", "label": "平台已计费合计（Takealot 结算时才计费）",
         "amount": -float(row.get("platformDeductions") or 0)},
        {"kind": "billed", "label": "  ├ 成功费 / 佣金（success_fee）",
         "amount": -float(row.get("successFee") or 0)},
        {"kind": "billed", "label": "  ├ 履约费 / DC（fulfillment_fee）",
         "amount": -float(row.get("billedFulfillmentFee") or 0)},
        {"kind": "billed", "label": "  ├ 配送费（courier_collection_fee）",
         "amount": -float(row.get("billedCourierFee") or 0)},
        {"kind": "billed", "label": "  └ 调拨费（stock_transfer_fee）",
         "amount": -float(row.get("billedStockTransferFee") or 0)},
    ]
    _est = row.get("estimatedSuccessFee")
    if _est is not None and not row.get("feesBilled"):
        lines.append({"kind": "estimate", "label": "预估成功费 / 佣金（按费率估算）",
                      "amount": -float(_est), "note": str(row.get("estimateBasis") or "")})
        lines.append({"kind": "estimate", "label": "预估 DC 履约费（按体积重 + 区域档位）",
                      "amount": None,
                      "note": "本单没有本地包装尺寸/重量记录，算不出数字（在「选品分析」填了才会给）——不拿 0 冒充"})
        lines.append({"kind": "estimate", "label": "预估净额（售价 x 数量 − 预估佣金）",
                      "amount": _r(_price - float(_est))})
    if row.get("costKnown"):
        lines.append({"kind": "cost", "label": "采购成本（本地记录）",
                      "amount": -float(row.get("cogs") or 0)})
        lines.append({"kind": "cost", "label": "头程分摊（本地记录）",
                      "amount": -float(row.get("inboundFreight") or 0)})
    lines.append({"kind": "net", "label": "净额（营收 − 平台已计费）", "amount": row["netProfit"]})
    if row.get("costKnown"):
        _net_c = _r(float(row.get("netProfit") or 0) - float(row.get("cogs") or 0)
                    - float(row.get("inboundFreight") or 0))
        lines.append({"kind": "net", "label": "扣成本后净利（净额 − 采购 − 头程）", "amount": _net_c})
    detail = dict(row)
    detail["lines"] = lines
    detail["note"] = ("口径：{0}".format(ORDER_BASIS)
                      if not row.get("warning") else "{0} 口径：{1}".format(row["warning"], ORDER_BASIS))
    detail["breakEvenNote"] = ("保本价 / 20% 目标价需要采购成本 + 体积重：本单"
                               + ("有本地成本记录，可在「选品分析」里算。" if row.get("costKnown")
                                  else "没有本地成本记录（采集箱 cost / 规则成本都没有），所以不给数字。"))
    return detail



# --------------------------------------------------------------------------
# Compliance engine
# --------------------------------------------------------------------------

def _compliance_seed_words() -> List[Dict[str, Any]]:
    # 每行都会走一次（_local_join → compliance_check），所以结果必须缓存：它只依赖常量 +
    # 随插件发布的数据文件，进程内没有写入路径。
    cached = _DATA_CACHE.get("__compliance_seed__")
    if isinstance(cached, list):
        return cached
    words: List[Dict[str, Any]] = []
    seen = set()

    def add(word: str, kind: str, severity: str, advice: str) -> None:
        key = word.lower()
        if key in seen:
            return
        seen.add(key)
        words.append({"word": word, "kind": kind, "severity": severity, "advice": advice})

    for word in HIGH_RISK_BRANDS:
        add(word, "\u5546\u6807", "high",
            "Registered trade mark. Do not use it in the title, bullets or images unless you are an authorised reseller with written approval.")
    for word in RISK_WORDS:
        low = word.lower()
        if low in ("cure", "medical grade"):
            add(word, "\u533b\u7597\u5ba3\u79f0", "high",
                "Medical / therapeutic claim. Remove it: Takealot rejects unproven health claims and SAPHRA may act.")
        elif low in ("oem", "100% original"):
            add(word, "\u4fb5\u6743", "high",
                "Implies OEM / counterfeit provenance. Replace with the actual manufacturer name and model.")
        elif low == "best seller":
            add(word, "\u7edd\u5bf9\u5316\u7528\u8bed", "medium",
                "Absolute claim. Takealot style guide bans unverifiable superlatives in listing copy.")
        else:
            add(word, "\u5546\u6807", "high",
                "Protected brand token. Verify supplier authorisation before publishing.")
    for word in SENSITIVE_TERMS:
        low = word.lower()
        if low in ("cure", "anti-covid", "100% cure", "fda certified"):
            add(word, "\u533b\u7597\u5ba3\u79f0", "high",
                "Health / certification claim that requires documentary proof. Remove it before submitting.")
        elif low in ("military grade", "patented replica"):
            add(word, "\u4fb5\u6743", "high",
                "Unsubstantiated specification / replica wording. Rewrite with measurable facts.")
        else:
            add(word, "\u7edd\u5bf9\u5316\u7528\u8bed", "medium",
                "Vague authenticity wording. State the exact model, condition and warranty instead.")
    for word in PROHIBITED_WORDS:
        add(word, "\u7edd\u5bf9\u5316\u7528\u8bed", "low",
            "Promotional filler banned by the Takealot style guide. Cut it from the title and bullets.")
    brand_list = _brand_names()
    if brand_list:
        step = max(1, len(brand_list) // 60)
        for name in brand_list[::step][:60]:
            clean = (name or "").strip()
            if len(clean) < 3:
                continue
            add(clean, "\u5546\u6807", "medium",
                "Listed in the Takealot brand register. Confirm you hold distribution rights for this brand.")
    _DATA_CACHE["__compliance_seed__"] = words
    return words


_SEVERITY_WEIGHT = {"high": 34, "medium": 16, "low": 7}
_SEVERITY_ADVICE = {
    "\u5546\u6807": "Run the brand authorisation letter through Seller Support before publishing.",
    "\u7edd\u5bf9\u5316\u7528\u8bed": "Rewrite with measurable facts (capacity, material, certification number).",
    "\u533b\u7597\u5ba3\u79f0": "Drop the medical claim \u2014 Takealot and SAPHRA treat it as a prohibited health claim.",
    "\u4fb5\u6743": "Replace provenance wording with the real manufacturer, model and condition.",
}


def compliance_check(text: str, category: Optional[str] = None) -> Dict[str, Any]:
    body = (text or "").strip()
    lowered = body.lower()
    hits: List[Dict[str, Any]] = []
    seen = set()

    def push(word: str, kind: str, severity: str, advice: str) -> None:
        marker = (word.lower(), kind)
        if marker in seen:
            return
        seen.add(marker)
        hits.append({"word": word, "kind": kind, "severity": severity, "advice": advice})

    seed = _compliance_seed_words()
    for entry in seed:
        if entry["word"].lower() in lowered:
            push(entry["word"], entry["kind"], entry["severity"], entry["advice"])

    index = _brand_index()
    tokens = re.findall(r"[A-Za-z0-9][A-Za-z0-9&'\-]{2,}", body)
    for token in tokens[:400]:
        canonical = index.get(token.lower())
        if canonical and canonical not in HIGH_RISK_BRANDS:
            push(canonical, "\u5546\u6807", "medium",
                 "Registered Takealot brand. Confirm distribution rights for this brand.")

    hits = hits[:40]
    score = min(100, sum(_SEVERITY_WEIGHT.get(h["severity"], 8) for h in hits))
    verdict = "block" if score >= 60 else ("warn" if score >= 25 else "pass")
    suggestions: List[str] = []
    for hit in hits:
        advice = _SEVERITY_ADVICE.get(hit["kind"], "Review the wording before submitting the listing.")
        if advice not in suggestions:
            suggestions.append(advice)
    if not suggestions:
        suggestions.append("No risk words detected. Keep the title under 75 characters and the subtitle under 110.")
    return {
        "hits": hits,
        "score": score,
        "verdict": verdict,
        "suggestions": suggestions,
        "category": category or "General Merchandise",
        "textLength": len(body),
    }


# --------------------------------------------------------------------------
# XLSX writer (zipfile + minimal OOXML — openpyxl is optional)
# --------------------------------------------------------------------------

# Official new-listing Loadsheet engine — faithful port of
# /Users/fly/openlisting/packages/shared/src/takealotLoadsheet.ts
# (LOADSHEET_COLUMNS, WARRANTY_TYPES, IMAGE_COLUMN_COUNT, normalizeTakealotImage,
#  isTakealotAssignedBarcode, isYouTube, buildLoadsheetRow, buildLoadsheetRows).
# The `header` strings below are the single source of truth for the .xlsx column
# set: Takealot matches its template row by exact header text.

WARRANTY_TYPES: List[str] = ["Limited", "Full", "Lifetime", "Supplier"]
DEFAULT_WARRANTY_TYPE = "Supplier"
DEFAULT_WARRANTY_MONTHS = 12
IMAGE_COLUMN_COUNT = 20
TAKEALOT_IMG_SIZE = "zoom"

LOADSHEET_COLUMNS: List[Dict[str, Any]] = [
    {"key": "sku", "header": "Your Own SKU", "note": "你的内部 SKU（可选，便于对账）"},
    {"key": "productType", "header": "Product Type", "note": "Single / Variant Parent / Variant Child"},
    {"key": "variantGroup", "header": "Variant Group (Parent SKU)", "note": "变体父/子行共享的父 SKU（链接同一 listing）"},
    {"key": "mainCategory", "header": "Main Category", "required": True, "note": "全局类目树主类目"},
    {"key": "lowestCategory", "header": "Lowest Category", "required": True, "note": "最末级类目节点"},
    {"key": "title", "header": "Title", "required": True, "maxLen": 75, "note": "品牌+品名+型号+变体+数量，≤75 字符"},
    {"key": "subtitle", "header": "Subtitle", "maxLen": 110, "note": "≤110 字符，可选"},
    {"key": "features", "header": "Key Selling Features", "required": True, "minLen": 200, "note": "特性+规格，≥200 字符"},
    {"key": "brand", "header": "Brand", "note": "仅当产品/包装有品牌 logo 时填"},
    {"key": "barcode", "header": "Barcode", "maxLen": 20, "note": "GTIN/EAN-13/ISBN-13，无则留空"},
    {"key": "whatsInTheBox", "header": "What's in the Box", "note": "每行一项，如 '1 X Item'"},
    {"key": "videoLink", "header": "Video Link", "note": "仅 YouTube URL"},
    {"key": "warrantyType", "header": "Warranty Type", "required": True, "note": " / ".join(WARRANTY_TYPES)},
    {"key": "warrantyPeriod", "header": "Warranty Period", "required": True, "note": "6–180 月（Lifetime 需 ≥60）"},
]

_IMAGE_COLUMN_NOTE = "JPEG/PNG · 600–5000px · ≤10MB · 公网 http(s) URL"


def image_column_keys(count: int = IMAGE_COLUMN_COUNT) -> List[str]:
    return ["image{0}".format(i + 1) for i in range(count)]


def image_columns(count: int = IMAGE_COLUMN_COUNT) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for i, key in enumerate(image_column_keys(count)):
        out.append({
            "key": key,
            "header": "Product Image 1 (Cover)" if i == 0 else "Product Image {0}".format(i + 1),
            "required": i == 0,
            "note": _IMAGE_COLUMN_NOTE,
        })
    return out


def all_loadsheet_columns(count: int = IMAGE_COLUMN_COUNT) -> List[Dict[str, Any]]:
    """Fixed columns + image columns, spliced in just before `Video Link`."""
    cols = [dict(c) for c in LOADSHEET_COLUMNS]
    idx = next((i for i, c in enumerate(cols) if c["key"] == "videoLink"), len(cols))
    return cols[:idx] + image_columns(count) + cols[idx:]


def loadsheet_headers(count: int = IMAGE_COLUMN_COUNT) -> List[str]:
    return [c["header"] for c in all_loadsheet_columns(count)]


def normalize_takealot_image(url: Any) -> Any:
    """`{size}` template and 404-ing WxH variants → the named `zoom` token."""
    if not url or not isinstance(url, str):
        return url
    if "{size}" in url:
        return url.replace("{size}", TAKEALOT_IMG_SIZE)

    def _repl(match: Any) -> str:
        pre, size, ext = match.group(1), match.group(2), match.group(3)
        return pre + (TAKEALOT_IMG_SIZE if re.match(r"^\d+x\d+$", size, re.I) else size) + ext

    return re.sub(r"(covers_images/[a-f0-9]+/s-)([^./]+)(\.\w+)", _repl, url, count=1, flags=re.I)


def is_youtube(url: Any) -> bool:
    return bool(re.match(r"^(https?://)?(www\.)?(youtube\.com/watch\?v=|youtu\.be/)[\w-]+",
                         str(url or "").strip(), re.I))


def is_takealot_assigned_barcode(barcode: Any) -> bool:
    """`MPTALX…` placeholders belong to an existing catalogue item — never a new listing."""
    return bool(re.match(r"^MPTALX[\w-]*", str(barcode or "").strip(), re.I))


def _loadsheet_column(key: str) -> Optional[Dict[str, Any]]:
    return next((c for c in LOADSHEET_COLUMNS if c["key"] == key), None)


def build_loadsheet_row(inp: Dict[str, Any], image_count: int = IMAGE_COLUMN_COUNT) -> Dict[str, Any]:
    """input → {values, attributes, errors, warnings}. Problems are returned, never raised."""
    inp = inp if isinstance(inp, dict) else {}
    values: Dict[str, str] = {}
    errors: List[str] = []
    warnings: List[str] = []

    def put(key: str, raw: Any, col: Optional[Dict[str, Any]]) -> None:
        value = ("" if raw is None else str(raw)).strip()
        if col and col.get("maxLen") and len(value) > int(col["maxLen"]):
            warnings.append("{0} 超 {1} 字符（{2}），已截断".format(col["header"], col["maxLen"], len(value)))
            value = value[: int(col["maxLen"])]
        if col and col.get("minLen") and value and len(value) < int(col["minLen"]):
            warnings.append("{0} 不足 {1} 字符（{2}），Takealot 可能打回".format(col["header"], col["minLen"], len(value)))
        if col and col.get("required") and not value:
            errors.append("缺必填：{0}".format(col["header"]))
        values[key] = value

    put("sku", inp.get("sku"), _loadsheet_column("sku"))
    put("mainCategory", inp.get("mainCategory"), _loadsheet_column("mainCategory"))
    put("lowestCategory", inp.get("lowestCategory"), _loadsheet_column("lowestCategory"))
    leaf = str(inp.get("lowestCategory") or "").strip()
    if leaf:
        leaf_index = _catalog_leaf_index()
        known = leaf_index.get("names") or set()
        if known:
            path_leaf = ""
            category_path = str(inp.get("categoryPath") or "")
            if category_path:
                path_leaf = category_path.split(">")[-1].strip().lower()
            if leaf.lower() not in known and path_leaf not in known:
                errors.append(
                    "类目「{0}」不是末级节点：Lowest Category 必须落到末级（部门 > … > 末级类目），"
                    "否则装载表会被打回。用「部门 → 装载表 → 末级类目」三列选一次即可。".format(leaf)
                )
    put("title", inp.get("title"), _loadsheet_column("title"))
    put("subtitle", inp.get("subtitle"), _loadsheet_column("subtitle"))
    put("features", inp.get("features"), _loadsheet_column("features"))
    put("brand", inp.get("brand"), _loadsheet_column("brand"))

    barcode = str(inp.get("barcode") or "").strip()
    if barcode and is_takealot_assigned_barcode(barcode):
        warnings.append("条码 {0} 是 Takealot 生成的占位码（非 GS1），新品刊登不可复用，已留空由 Takealot 生成".format(barcode))
        values["barcode"] = ""
    else:
        put("barcode", barcode, _loadsheet_column("barcode"))

    put("whatsInTheBox", inp.get("whatsInTheBox"), _loadsheet_column("whatsInTheBox"))

    video = str(inp.get("videoUrl") or "").strip()
    if video and not is_youtube(video):
        warnings.append("视频链接非 YouTube，已忽略（Takealot 仅接受 YouTube）")
        values["videoLink"] = ""
    else:
        values["videoLink"] = video

    warranty_type = str(inp.get("warrantyType") or DEFAULT_WARRANTY_TYPE)
    if warranty_type not in WARRANTY_TYPES:
        warnings.append("保修类型 {0} 不在官方枚举内，已用 {1}".format(warranty_type, DEFAULT_WARRANTY_TYPE))
        warranty_type = DEFAULT_WARRANTY_TYPE
    values["warrantyType"] = warranty_type
    months_raw = inp.get("warrantyPeriodMonths")
    try:
        months = int(months_raw) if months_raw not in (None, "") else DEFAULT_WARRANTY_MONTHS
    except (TypeError, ValueError):
        months = DEFAULT_WARRANTY_MONTHS
    if months < 6 or months > 180:
        warnings.append("保修期 {0} 月超出 6–180 范围，已归一到 {1}".format(months, DEFAULT_WARRANTY_MONTHS))
        months = DEFAULT_WARRANTY_MONTHS
    if warranty_type == "Lifetime" and months < 60:
        warnings.append("Lifetime 保修期应 ≥60 月，已提升到 60")
        months = 60
    values["warrantyPeriod"] = str(months)

    images: List[str] = []
    seen: set = set()
    for raw in (inp.get("images") or []):
        url = normalize_takealot_image(str(raw or "").strip())
        if not isinstance(url, str) or not re.match(r"^https?://", url, re.I):
            continue
        if url in seen:
            continue
        seen.add(url)
        images.append(url)
    images = images[:image_count]
    for i, key in enumerate(image_column_keys(image_count)):
        values[key] = images[i] if i < len(images) else ""
    if not images:
        errors.append("缺必填：主图（至少 1 张公网图片 URL）")

    raw_attributes = inp.get("attributes")
    attributes = dict(raw_attributes) if isinstance(raw_attributes, dict) else {}
    if not values.get("productType"):
        values["productType"] = "Single"

    return {"values": values, "attributes": attributes, "errors": errors, "warnings": warnings}


def build_loadsheet_rows(inp: Dict[str, Any], image_count: int = IMAGE_COLUMN_COUNT) -> List[Dict[str, Any]]:
    """No variant axis → 1 Single row; otherwise 1 parent + N child rows."""
    inp = inp if isinstance(inp, dict) else {}
    themes = [str(t).strip() for t in (inp.get("variantThemes") or []) if str(t or "").strip()][:2]
    variants = [
        v for v in (inp.get("variants") or [])
        if isinstance(v, dict) and any(str(x or "").strip() for x in (v.get("values") or []))
    ]
    if not themes or not variants:
        row = build_loadsheet_row(inp, image_count)
        row["values"]["productType"] = "Single"
        return [row]

    parent_sku = (str(inp.get("sku") or inp.get("title") or "PARENT").strip() or "PARENT")[:60]
    rows: List[Dict[str, Any]] = []

    parent_input = dict(inp)
    parent_input["barcode"] = ""
    parent = build_loadsheet_row(parent_input, image_count)
    parent["values"]["productType"] = "Variant Parent"
    parent["values"]["variantGroup"] = parent_sku
    rows.append(parent)

    for idx, variant in enumerate(variants):
        axis: Dict[str, str] = {}
        for i, theme in enumerate(themes):
            variant_values = variant.get("values") or []
            axis[theme] = str(variant_values[i] if i < len(variant_values) else "").strip()
        child_input = dict(inp)
        child_input["sku"] = str(variant.get("sku") or "{0}-{1}".format(parent_sku, idx + 1)).strip()
        child_input["barcode"] = variant.get("barcode")
        variant_images = variant.get("images") or []
        if variant_images:
            child_input["images"] = variant_images
        child_attributes = dict(inp.get("attributes") or {})
        child_attributes.update(axis)
        child_input["attributes"] = child_attributes
        child = build_loadsheet_row(child_input, image_count)
        child["values"]["productType"] = "Variant Child"
        child["values"]["variantGroup"] = parent_sku
        for i, theme in enumerate(themes):
            variant_values = variant.get("values") or []
            if not str(variant_values[i] if i < len(variant_values) else "").strip():
                child["errors"].append("变体 {0} 缺「{1}」值".format(idx + 1, theme))
        rows.append(child)

    return rows


def _xml_escape(value: Any) -> str:
    return (
        str(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _col_letter(idx: int) -> str:
    letters = ""
    idx += 1
    while idx:
        idx, rem = divmod(idx - 1, 26)
        letters = chr(65 + rem) + letters
    return letters


def _sheet_xml(headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> str:
    parts = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>']
    parts.append(
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
    )
    parts.append("<sheetData>")
    all_rows = [list(headers)] + [list(r) for r in rows]
    for r_idx, row in enumerate(all_rows, start=1):
        parts.append('<row r="{0}">'.format(r_idx))
        for c_idx, value in enumerate(row):
            ref = "{0}{1}".format(_col_letter(c_idx), r_idx)
            if value is None or value == "":
                parts.append('<c r="{0}"/>'.format(ref))
            elif isinstance(value, bool):
                parts.append('<c r="{0}" t="inlineStr"><is><t>{1}</t></is></c>'.format(ref, _xml_escape(value)))
            elif isinstance(value, (int, float)):
                parts.append('<c r="{0}"><v>{1}</v></c>'.format(ref, value))
            else:
                parts.append(
                    '<c r="{0}" t="inlineStr"><is><t xml:space="preserve">{1}</t></is></c>'.format(
                        ref, _xml_escape(value)
                    )
                )
        parts.append("</row>")
    parts.append("</sheetData></worksheet>")
    return "".join(parts)


def _write_xlsx_sheets(path: Path, sheets: Sequence[Dict[str, Any]]) -> int:
    """Write a multi-worksheet .xlsx (``[{name, headers, rows}]``) with no third-party deps.

    openpyxl is optional and frequently absent on the target box, so the fallback has to
    build a valid multi-sheet package itself: content types + workbook + rels + sheetN.xml.
    Every sheet is still produced by ``_sheet_xml`` — only the packaging changes.
    """
    sheets = [sh for sh in sheets if sh and isinstance(sh.get("headers"), (list, tuple))]
    if not sheets:
        return 0
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        import openpyxl  # type: ignore

        wb = openpyxl.Workbook()
        for idx, sh in enumerate(sheets):
            ws = wb.active if idx == 0 else wb.create_sheet()
            ws.title = str(sh.get("name") or "Sheet{0}".format(idx + 1))[:31]
            ws.append([str(h) for h in sh.get("headers") or []])
            for row in sh.get("rows") or []:
                ws.append(list(row))
        wb.save(str(path))
        return path.stat().st_size
    except Exception:
        pass

    def esc(text: Any) -> str:
        return (str(text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

    overrides = "".join(
        '<Override PartName="/xl/worksheets/sheet{0}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'.format(i + 1)
        for i in range(len(sheets))
    )
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        + overrides +
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
        '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
        '</Types>'
    )
    root_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
        '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/package/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
        '</Relationships>'
    )
    sheet_tags = "".join(
        '<sheet name="{0}" sheetId="{1}" r:id="rId{1}"/>'.format(esc(str(sh.get("name") or "Sheet{0}".format(i + 1))[:31]), i + 1)
        for i, sh in enumerate(sheets)
    )
    workbook = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<sheets>' + sheet_tags + '</sheets></workbook>'
    )
    wb_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        + "".join('<Relationship Id="rId{0}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{0}.xml"/>'.format(i + 1) for i in range(len(sheets)))
        + '<Relationship Id="rId{0}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'.format(len(sheets) + 1)
        + '</Relationships>'
    )
    styles = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>'
        '<fills count="1"><fill><patternFill patternType="none"/></fill></fills>'
        '<borders count="1"><border/></borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>'
        '</styleSheet>'
    )
    core = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        '<dc:creator>Takealot ERP (Hermes plugin)</dc:creator>'
        '<dc:title>Takealot Reconciliation</dc:title>'
        '</cp:coreProperties>'
    )
    app = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
        'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
        '<Application>Hermes Takealot ERP</Application></Properties>'
    )
    with zipfile.ZipFile(str(path), "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", root_rels)
        zf.writestr("xl/workbook.xml", workbook)
        zf.writestr("xl/_rels/workbook.xml.rels", wb_rels)
        zf.writestr("xl/styles.xml", styles)
        for i, sh in enumerate(sheets):
            zf.writestr("xl/worksheets/sheet{0}.xml".format(i + 1),
                        _sheet_xml(list(sh.get("headers") or []), list(sh.get("rows") or [])))
        zf.writestr("docProps/core.xml", core)
        zf.writestr("docProps/app.xml", app)
    return path.stat().st_size


def _write_xlsx(path: Path, headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> int:
    """Write a real, openable .xlsx without third-party dependencies."""
    try:
        import openpyxl  # type: ignore

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Loadsheet"
        ws.append(list(headers))
        for row in rows:
            ws.append(list(row))
        path.parent.mkdir(parents=True, exist_ok=True)
        wb.save(str(path))
        return path.stat().st_size
    except Exception:
        pass

    path.parent.mkdir(parents=True, exist_ok=True)
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
        '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
        "</Types>"
    )
    root_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
        '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
        "</Relationships>"
    )
    workbook = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<sheets><sheet name="Loadsheet" sheetId="1" r:id="rId1"/></sheets></workbook>'
    )
    workbook_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        "</Relationships>"
    )
    styles = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>'
        '<fills count="1"><fill><patternFill patternType="none"/></fill></fills>'
        '<borders count="1"><border/></borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>'
        "</styleSheet>"
    )
    core = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        "<dc:creator>Takealot ERP (Hermes plugin)</dc:creator>"
        "<dc:title>Takealot Product Loadsheet</dc:title>"
        "</cp:coreProperties>"
    )
    app = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
        'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
        "<Application>Hermes Takealot ERP</Application></Properties>"
    )
    with zipfile.ZipFile(str(path), "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", root_rels)
        zf.writestr("xl/workbook.xml", workbook)
        zf.writestr("xl/_rels/workbook.xml.rels", workbook_rels)
        zf.writestr("xl/styles.xml", styles)
        zf.writestr("xl/worksheets/sheet1.xml", _sheet_xml(headers, rows))
        zf.writestr("docProps/core.xml", core)
        zf.writestr("docProps/app.xml", app)
    return path.stat().st_size


# --------------------------------------------------------------------------
# Draft ⇄ Loadsheet plumbing (draft object → official row input)
# --------------------------------------------------------------------------

def _variant_input_from_draft(draft: Dict[str, Any]) -> Dict[str, Any]:
    """草稿 → 变体装载表输入（轴列名 / 每行的轴值数组 / 每行自己的 SKU·条码·图片）。

    兼容老形状：`variantThemes:[轴名]` + `variants:[{values:[…]}]`（采集箱转入 / prefill
    造出来的草稿就是这么存的）自动迁移进新模型，不丢已填的变体。
    """
    draft = draft if isinstance(draft, dict) else {}
    model = _variant_model_normalize(draft.get("variants"))
    if not model["theme"] and not model["axes"]:
        legacy_themes = [str(t).strip() for t in (draft.get("variantThemes") or [])
                         if str(t or "").strip()][:2] if isinstance(draft.get("variantThemes"), list) else []
        legacy_rows = [v for v in (draft.get("variants") or []) if isinstance(v, dict)] \
            if isinstance(draft.get("variants"), list) else []
        if legacy_themes:
            model["axes"] = [{"key": t, "label": t, "columnName": t, "required": True}
                             for t in legacy_themes]
        if legacy_rows:
            model["rows"] = [_variant_row_normalize(v) for v in legacy_rows]
    axes = model["axes"]
    ordered: List[Dict[str, Any]] = []
    for row in model["rows"]:
        values = row.get("values") or {}
        aligned: List[str] = []
        for i, axis in enumerate(axes):
            key = str(axis.get("key") or "")
            if key in values:
                aligned.append(str(values.get(key) or ""))
            else:
                aligned.append(str(values.get(str(i)) or ""))     # 旧形状：按位置对齐
        ordered.append({"values": aligned, "sku": row.get("sku") or "",
                        "barcode": row.get("barcode") or "", "images": list(row.get("images") or [])})
    return {
        # 官方装载表列名：轴列名前缀就是官方字段名（Variant.attribute.* / color.*）
        "variantThemes": [str(a.get("columnName") or a.get("key") or "") for a in axes],
        "variants": ordered,
        "variantTheme": model["theme"],
        "variantThemeLabel": model["themeLabel"],
        "variantCustomName": model["customName"],
        "variantCustomNames": model["customNames"],
        "variantAxes": axes,
        "variantRows": model["rows"],
    }


def _loadsheet_input_from_draft(draft: Dict[str, Any]) -> Dict[str, Any]:
    draft = draft if isinstance(draft, dict) else {}
    attributes = draft.get("attributes")
    if not isinstance(attributes, dict):
        attributes = {}
    out = {
        "sku": draft.get("sku") or draft.get("id") or "",
        "mainCategory": draft.get("mainCategory") or "",
        "lowestCategory": draft.get("lowestCategory") or draft.get("categoryPath") or draft.get("category") or "",
        "title": draft.get("title") or "",
        "subtitle": draft.get("subtitle") or "",
        "features": draft.get("features") or "",
        "whatsInTheBox": draft.get("whatsInTheBox") or draft.get("inTheBox") or "",
        "brand": draft.get("brand") or "",
        "barcode": draft.get("barcode") or "",
        "images": draft.get("images") if isinstance(draft.get("images"), list) else [],
        "videoUrl": draft.get("videoUrl") or draft.get("videoLink") or "",
        "warrantyType": draft.get("warrantyType") or DEFAULT_WARRANTY_TYPE,
        "warrantyPeriodMonths": draft.get("warrantyPeriod") or draft.get("warrantyMonths") or DEFAULT_WARRANTY_MONTHS,
        "attributes": {str(k): str(v) for k, v in attributes.items()},
    }
    out.update(_variant_input_from_draft(draft))
    return out
    out.update(_variant_input_from_draft(draft))
    return out


def _loadsheet_export_plan(inputs: List[Dict[str, Any]],
                           image_count: int = IMAGE_COLUMN_COUNT) -> Dict[str, Any]:
    """drafts → {headers, attributeColumns, table, built} with the official column set."""
    cols = all_loadsheet_columns(image_count)
    attribute_columns: List[str] = []
    built: List[Dict[str, Any]] = []
    for draft in inputs:
        for row in build_loadsheet_rows(_loadsheet_input_from_draft(draft), image_count):
            built.append(row)
            for name in (row.get("attributes") or {}):
                if name not in attribute_columns:
                    attribute_columns.append(name)
    headers = [c["header"] for c in cols] + attribute_columns
    table: List[List[Any]] = []
    for row in built:
        line: List[Any] = [row["values"].get(c["key"], "") for c in cols]
        line += [row["attributes"].get(name, "") for name in attribute_columns]
        table.append(line)
    return {"headers": headers, "attributeColumns": attribute_columns, "table": table, "built": built}


def _strict_loadsheet_flags(inp: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Portal-blocking breaches that the port itself reports as warnings
    (truncate / blank-and-continue). The pre-flight validator promotes them to
    blocking errors so the operator fixes the row instead of shipping it."""
    flags: List[Dict[str, Any]] = []

    def flag(code: str, field: str, message: str) -> None:
        flags.append({"code": code, "field": field, "level": "error", "message": message})

    title = str(inp.get("title") or "").strip()
    if len(title) > 75:
        flag("TITLE_TOO_LONG", "Title", "Title 超过 75 字符（{0}），新品刊登会被打回".format(len(title)))
    subtitle = str(inp.get("subtitle") or "").strip()
    if len(subtitle) > 110:
        flag("SUBTITLE_TOO_LONG", "Subtitle", "Subtitle 超过 110 字符（{0}）".format(len(subtitle)))
    features = str(inp.get("features") or "").strip()
    if features and len(features) < 200:
        flag("FEATURES_TOO_SHORT", "Key Selling Features",
             "Key Selling Features 不足 200 字符（{0}），新品刊登会被 QC 打回".format(len(features)))
    barcode = str(inp.get("barcode") or "").strip()
    if barcode and is_takealot_assigned_barcode(barcode):
        flag("MPTALX_BARCODE", "Barcode",
             "Barcode {0} 是 Takealot 生成的占位码（非 GS1），不可用于新品刊登".format(barcode))
    elif len(barcode) > 20:
        flag("BARCODE_TOO_LONG", "Barcode", "Barcode 超过 20 字符（{0}）".format(len(barcode)))
    video = str(inp.get("videoUrl") or "").strip()
    if video and not is_youtube(video):
        flag("VIDEO_NOT_YOUTUBE", "Video Link", "Video Link 非 YouTube，Takealot 只接受 YouTube 链接")
    months_raw = inp.get("warrantyPeriodMonths")
    try:
        months = int(months_raw) if months_raw not in (None, "") else DEFAULT_WARRANTY_MONTHS
    except (TypeError, ValueError):
        months = -1
    if months < 6 or months > 180:
        flag("WARRANTY_RANGE", "Warranty Period", "Warranty Period {0} 不在 6–180 月范围".format(months))
    elif str(inp.get("warrantyType") or "") == "Lifetime" and months < 60:
        flag("WARRANTY_LIFETIME_MIN", "Warranty Period", "Lifetime 保修期需 ≥60 月")
    flags.extend(_variant_flags(inp))
    return flags


# --------------------------------------------------------------------------
# Catalogue picker — departments → loadsheets → leaf nodes
# (data/takealot-categories.json: departments, loadsheets, deptLoadsheets,
#  loadsheetNodes, nodes)
# --------------------------------------------------------------------------

def _split_path(path: Any) -> List[str]:
    return [s.strip() for s in re.split(r"\s*(?:->|>)\s*", str(path or "")) if s.strip()]


def _norm_path(path: Any) -> str:
    return " -> ".join(_split_path(path))


def _slug(text: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(text or "").lower()).strip("-") or "dept"


def _catalog_index() -> Dict[str, Any]:
    if "__catalog_index__" in _DATA_CACHE:
        return _DATA_CACHE["__catalog_index__"]
    by_id: Dict[int, Dict[str, Any]] = {}
    by_leaf: Dict[str, List[Dict[str, Any]]] = {}
    for node in _category_nodes():
        try:
            node_id = int(node[0])
        except (TypeError, ValueError, IndexError):
            continue
        segments = _split_path(node[1])
        entry = {
            "nodeId": node_id,
            "path": _norm_path(node[1]),
            "name": segments[-1] if segments else str(node[1]),
            "segments": segments,
        }
        by_id[node_id] = entry
        by_leaf.setdefault(entry["name"].lower(), []).append(entry)
    index = {"byId": by_id, "byLeaf": by_leaf}
    _DATA_CACHE["__catalog_index__"] = index
    return index


def _node_loadsheet_map() -> Dict[int, str]:
    if "__node_loadsheet__" in _DATA_CACHE:
        return _DATA_CACHE["__node_loadsheet__"]
    reverse: Dict[int, str] = {}
    for loadsheet_id, node_ids in _loadsheet_nodes().items():
        for node_id in node_ids or []:
            try:
                reverse.setdefault(int(node_id), str(loadsheet_id))
            except (TypeError, ValueError):
                continue
    _DATA_CACHE["__node_loadsheet__"] = reverse
    return reverse


def _loadsheet_department_map() -> Dict[str, str]:
    if "__loadsheet_dept__" in _DATA_CACHE:
        return _DATA_CACHE["__loadsheet_dept__"]
    data = _load_data("takealot-categories.json", {})
    mapping: Dict[str, str] = {}
    dept_loadsheets = data.get("deptLoadsheets") if isinstance(data, dict) else None
    if isinstance(dept_loadsheets, dict):
        for department, loadsheet_ids in dept_loadsheets.items():
            for loadsheet_id in loadsheet_ids or []:
                mapping.setdefault(str(loadsheet_id), str(department))
    _DATA_CACHE["__loadsheet_dept__"] = mapping
    return mapping


def _catalog_departments() -> List[Dict[str, Any]]:
    if "__catalog_departments__" in _DATA_CACHE:
        return _DATA_CACHE["__catalog_departments__"]
    data = _load_data("takealot-categories.json", {})
    raw_departments = data.get("departments") if isinstance(data, dict) else None
    dept_loadsheets = data.get("deptLoadsheets") if isinstance(data, dict) else {}
    names = _loadsheet_names()
    nodes = _loadsheet_nodes()
    out: List[Dict[str, Any]] = []
    covered: set = set()
    for name in (raw_departments or []):
        name = str(name)
        loadsheets = []
        for loadsheet_id in ((dept_loadsheets or {}).get(name) or []):
            sid = str(loadsheet_id)
            covered.add(sid)
            loadsheets.append({
                "id": sid,
                "name": names.get(sid, "Loadsheet " + sid),
                "leafCount": len(nodes.get(sid) or []),
            })
        out.append({
            "id": _slug(name),
            "name": name,
            "loadsheets": loadsheets,
            "leafCount": sum(item["leafCount"] for item in loadsheets),
        })
    orphan_ids = [sid for sid in names if sid not in covered]
    if orphan_ids:
        loadsheets = [{
            "id": sid,
            "name": names.get(sid, "Loadsheet " + sid),
            "leafCount": len(nodes.get(sid) or []),
        } for sid in sorted(orphan_ids)]
        out.append({
            "id": "other",
            "name": "Other / 未归类",
            "loadsheets": loadsheets,
            "leafCount": sum(item["leafCount"] for item in loadsheets),
        })
    _DATA_CACHE["__catalog_departments__"] = out
    return out


def _department_of(needle: Any) -> Optional[Dict[str, Any]]:
    want = str(needle or "").strip().lower()
    if not want:
        return None
    departments = _catalog_departments()
    for department in departments:
        if want in (str(department["id"]).lower(), str(department["name"]).lower()):
            return department
    for department in departments:
        if want in str(department["name"]).lower() or want in str(department["id"]).lower():
            return department
    return None


_LEAF_INDEX: Dict[str, Any] = {"at": 0.0, "names": set(), "paths": set()}


def _catalog_leaf_index(ttl: float = 600.0) -> Dict[str, Any]:
    """Cached set of every 末级 leaf name/path in the bundled category tree.

    `Lowest Category` must be an actual leaf: a department such as "Toys & Baby" is
    non-empty yet still rejected by Takealot, so validation has to check membership,
    not just presence. Crawls often resolve only the department, which is exactly the
    case this catches.
    """
    now = time.time()
    if _LEAF_INDEX["names"] and (now - _LEAF_INDEX["at"]) < ttl:
        return _LEAF_INDEX
    names: set = set()
    paths: set = set()
    try:
        for leaf in _catalog_leaves():
            name = str(leaf.get("name") or "").strip().lower()
            path = str(leaf.get("path") or "").strip().lower()
            if name:
                names.add(name)
            if path:
                paths.add(path)
    except Exception:
        pass
    _LEAF_INDEX.update({"at": now, "names": names, "paths": paths})
    return _LEAF_INDEX


def _catalog_leaves(loadsheet_id: str = "", department: str = "") -> List[Dict[str, Any]]:
    """Leaf rows of one loadsheet, of every loadsheet in a department, or of the whole tree."""
    index = _catalog_index()
    node_map = _node_loadsheet_map()
    names = _loadsheet_names()
    wanted: List[str] = []
    scoped = bool(str(loadsheet_id or "").strip() or str(department or "").strip())
    if str(loadsheet_id or "").strip():
        wanted = [str(loadsheet_id).strip()]
    elif str(department or "").strip():
        dept = _department_of(department)
        wanted = [item["id"] for item in (dept or {}).get("loadsheets", [])]
        if dept is None:
            return []
    items: List[Dict[str, Any]] = []
    if scoped:
        for loadsheet in wanted:
            for raw_id in (_loadsheet_nodes().get(loadsheet) or []):
                try:
                    node_id = int(raw_id)
                except (TypeError, ValueError):
                    continue
                entry = index["byId"].get(node_id)
                if entry is None:
                    continue
                items.append({
                    "path": entry["path"],
                    "name": entry["name"],
                    "nodeId": node_id,
                    "loadsheetId": loadsheet,
                    "loadsheetName": names.get(loadsheet, ""),
                })
        return items
    for node in _category_nodes():
        try:
            node_id = int(node[0])
        except (TypeError, ValueError, IndexError):
            continue
        entry = index["byId"].get(node_id)
        if entry is None:
            continue
        loadsheet = node_map.get(node_id) or ""
        items.append({
            "path": entry["path"],
            "name": entry["name"],
            "nodeId": node_id,
            "loadsheetId": loadsheet,
            "loadsheetName": names.get(loadsheet, "") if loadsheet else "",
        })
    return items


def _resolve_catalog_category(category_path: Any) -> Dict[str, Any]:
    """Crawl breadcrumb path → the catalogue leaf + its loadsheet/department."""
    segments = _split_path(category_path)
    if not segments:
        return {}
    index = _catalog_index()
    candidates = index["byLeaf"].get(segments[-1].lower()) or []
    best: Optional[Dict[str, Any]] = None
    best_score = -1
    for candidate in candidates:
        cand = candidate["segments"]
        common = 0
        while (common < len(cand) and common < len(segments)
               and cand[len(cand) - 1 - common].lower() == segments[len(segments) - 1 - common].lower()):
            common += 1
        if common > best_score or (common == best_score and best is not None and len(cand) < len(best["segments"])):
            best, best_score = candidate, common
    if best is None:
        return {}
    loadsheet = _node_loadsheet_map().get(best["nodeId"]) or ""
    return {
        "nodeId": best["nodeId"],
        "path": best["path"],
        "name": best["name"],
        "matchedSegments": best_score,
        "loadsheetId": loadsheet,
        "loadsheetName": _loadsheet_names().get(loadsheet, "") if loadsheet else "",
        "mainCategory": _loadsheet_department_map().get(loadsheet) or segments[0],
    }


def _loadsheet_attribute_groups(loadsheet_id: str) -> Dict[str, str]:
    """fieldId → 'recommended' for the fields any category of this loadsheet recommends."""
    entry = _attribute_loadsheets_all().get(str(loadsheet_id))
    groups: Dict[str, str] = {}
    if not isinstance(entry, dict):
        return groups
    categories = entry.get("categories")
    if isinstance(categories, dict):
        for category in categories.values():
            if not isinstance(category, dict):
                continue
            for fid in (category.get("recommendeds") or []):
                groups.setdefault(str(fid), "recommended")
    return groups


# --------------------------------------------------------------------------
# 新建 Listing — crawl/cache → ready-to-save draft + route verdict
# --------------------------------------------------------------------------

_BARCODE_ATTRS = ("barcode", "gtin", "ean", "isbn", "upc", "product code", "sku code")


def _unescape_attribute(value: Any) -> str:
    """Takealot's product_information strings carry markdown escapes (5 x T\\-Shirts)."""
    text = str(value or "")
    text = re.sub(r"\\([-\\(\)\[\]\._\*#])", r"\1", text)
    return re.sub(r"\s+", " ", text).strip()


def _fit_text(text: Any, limit: int) -> Tuple[str, bool]:
    """Trim to `limit` on a word boundary; returns (value, was_truncated)."""
    value = str(text or "").strip()
    if len(value) <= limit:
        return value, False
    cut = value[:limit]
    if " " in cut:
        head = cut.rsplit(" ", 1)[0].strip()
        if len(head) >= max(20, limit // 2):
            cut = head
    return cut.rstrip(" ,;:-"), True


def _product_attribute_pairs(product: Dict[str, Any]) -> List[Dict[str, str]]:
    pairs: List[Dict[str, str]] = []
    for entry in (product.get("attributes") or []):
        if not isinstance(entry, dict):
            continue
        name = _unescape_attribute(entry.get("name"))
        value = _unescape_attribute(entry.get("value"))
        if not name or not value:
            continue
        if name.lower() in ("categories", "category"):
            continue
        if name.lower() in ("what's in the box", "whats in the box", "in the box"):
            continue
        pairs.append({"name": name, "value": value})
    return pairs


def _product_barcode(product: Dict[str, Any], pairs: List[Dict[str, str]]) -> str:
    candidate = str(product.get("barcode") or "").strip()
    if not candidate:
        data_layer = product.get("dataLayer") if isinstance(product.get("dataLayer"), dict) else {}
        candidate = str(data_layer.get("barcode") or "").strip()
    if not candidate:
        for pair in pairs:
            # 官方 CreateOfferRequest 的 pattern 是 ^[a-zA-Z0-9-_/.]+$，最短实见 6 位（RFID3P）；
            # 以前限制成 ^[A-Za-z0-9-]{8,20}$，把短条码和带 _ / . 的合法条码全漏了。
            if pair["name"].lower() in _BARCODE_ATTRS and re.match(r"^[A-Za-z0-9\-_/.]{4,25}$", pair["value"]):
                candidate = pair["value"]
                break
    return candidate


#: 公开页上「尺寸」类属性名（Takealot 商品页用 Assembled Dimensions 这一档）
_DIMENSION_ATTRS = ("dimensions", "assembled dimensions", "product dimensions",
                    "package dimensions", "packaging dimensions", "item dimensions",
                    "box dimensions", "product size")
#: 公开页上「重量」类属性名
_WEIGHT_ATTRS = ("weight", "product weight", "package weight", "item weight",
                 "gross weight", "net weight", "shipping weight")


def _parse_dimension_value(value: Any) -> Optional[Dict[str, float]]:
    """``13 x 5 x 5 cm`` / ``51.0 x 57.0 x 7.0 cm`` -> 长宽高（cm）。认得 mm / m / inch。"""
    text = str(value or "").lower().replace(",", ".")
    nums = re.findall(r"\d+(?:\.\d+)?", text)
    if len(nums) < 3:
        return None
    length, width, height = (float(x) for x in nums[:3])
    if "mm" in text:
        length, width, height = length / 10.0, width / 10.0, height / 10.0
    elif "cm" not in text and "inch" not in text and '"' not in text and re.search(r"\bm\b", text):
        length, width, height = length * 100.0, width * 100.0, height * 100.0
    elif "inch" in text or '"' in text:
        length, width, height = length * 2.54, width * 2.54, height * 2.54
    if not all(v > 0 for v in (length, width, height)):
        return None
    return {"lengthCm": _r(length, 1), "widthCm": _r(width, 1), "heightCm": _r(height, 1)}


def _parse_weight_value(value: Any) -> Optional[float]:
    """``1.2 kg`` / ``450 g`` / ``2 lb`` -> kg。"""
    text = str(value or "").lower().replace(",", ".")
    match = re.search(r"(\d+(?:\.\d+)?)\s*(kgs?|kilograms?|grams?|g|lbs?|pounds?)", text)
    if not match:
        return None
    amount = float(match.group(1))
    unit = match.group(2)
    if unit.startswith("lb") or unit.startswith("pound"):
        amount *= 0.45359237
    elif not unit.startswith("k"):
        amount /= 1000.0
    return _r(amount, 3) if amount > 0 else None


def _product_dimensions(pairs: List[Dict[str, str]]) -> Dict[str, Any]:
    """从公开页属性里取包装尺寸/重量。

    官方履约费按「体积 cm³ 档 × 重量档 × 类目分组」定价，所以体积/重量就是费率条件
    的输入。公开页只有一部分商品写了 Assembled Dimensions（实测 3/20），取不到就留空，
    由用户/模板补 —— 不猜。
    """
    out: Dict[str, Any] = {"lengthCm": None, "widthCm": None, "heightCm": None,
                           "volumeCm3": None, "weightKg": None, "source": None, "raw": None,
                           "volumeSource": None, "weightSource": None}
    for pair in pairs or []:
        if not isinstance(pair, dict):
            continue
        name = str(pair.get("name") or "").strip().lower()
        value = pair.get("value")
        if out["lengthCm"] is None and name in _DIMENSION_ATTRS:
            dims = _parse_dimension_value(value)
            if dims:
                out.update(dims)
                out["volumeSource"] = "public-card({0})".format(pair.get("name"))
                out["raw"] = str(value)
        if out["weightKg"] is None and name in _WEIGHT_ATTRS:
            kg = _parse_weight_value(value)
            if kg:
                out["weightKg"] = kg
                out["weightSource"] = "public-card({0})".format(pair.get("name"))
    if out["lengthCm"] and out["widthCm"] and out["heightCm"]:
        out["volumeCm3"] = _r(out["lengthCm"] * out["widthCm"] * out["heightCm"], 1)
    out["source"] = out["volumeSource"] or out["weightSource"]
    return out


def _product_warranty(pairs: List[Dict[str, str]]) -> Tuple[str, int]:
    warranty_type = DEFAULT_WARRANTY_TYPE
    months = DEFAULT_WARRANTY_MONTHS
    for pair in pairs:
        if "warranty" not in pair["name"].lower():
            continue
        value = pair["value"]
        for candidate in WARRANTY_TYPES:
            if re.search(r"\b{0}\b".format(candidate), value, re.I):
                warranty_type = candidate
                break
        match = re.search(r"(\d+)\s*(?:month|maand)", value, re.I)
        if match:
            months = int(match.group(1))
        break
    if months < 6 or months > 180:
        months = DEFAULT_WARRANTY_MONTHS
    if warranty_type == "Lifetime" and months < 60:
        months = 60
    return warranty_type, months


def _box_contents(product: Dict[str, Any], pairs: List[Dict[str, str]], title: Any) -> str:
    raw = ""
    for entry in (product.get("attributes") or []):
        if not isinstance(entry, dict):
            continue
        name = _unescape_attribute(entry.get("name")).lower()
        if name in ("what's in the box", "whats in the box", "in the box"):
            raw = str(entry.get("value") or "")
            break
    if not raw:
        for pair in pairs:
            if "box" in pair["name"].lower():
                raw = pair["value"]
                break
    lines: List[str] = []
    for chunk in re.split(r"(?:\\n|\n|;|\|)", raw):
        chunk = _unescape_attribute(chunk)
        if not chunk:
            continue
        normalised = re.sub(r"^\s*(\d+)\s*[xX×]\s*", r"\1 X ", chunk)
        if not re.match(r"^\d+\s*X\s", normalised):
            normalised = "1 X " + normalised
        lines.append(normalised)
    if not lines:
        lines = ["1 X {0}".format(_fit_text(title, 60)[0] or "Item")]
    return "\n".join(lines[:8])


def _product_image_urls(product: Dict[str, Any]) -> List[str]:
    raw = product.get("images")
    if not isinstance(raw, list) or not raw:
        raw = [product.get("image") or product.get("imageUrl") or ""]
    out: List[str] = []
    seen: set = set()
    for url in raw:
        normalised = normalize_takealot_image(str(url or "").strip())
        if not isinstance(normalised, str) or not re.match(r"^https?://", normalised, re.I):
            continue
        if normalised in seen:
            continue
        seen.add(normalised)
        out.append(normalised)
    return out


def _features_from_product(product: Dict[str, Any], pairs: List[Dict[str, str]],
                           min_len: int = 200) -> str:
    lines: List[str] = []
    title = str(product.get("title") or "").strip()
    subtitle = str(product.get("subtitle") or "").strip()
    if title:
        lines.append("- {0}".format(title))
    if subtitle:
        lines.append("- {0}".format(subtitle))
    for pair in pairs[:10]:
        lines.append("- {0}: {1}".format(pair["name"], pair["value"]))
    rating = product.get("rating")
    reviews = product.get("reviews") or product.get("reviewCount")
    if rating and reviews:
        lines.append("- Rated {0}/5 by {1} verified Takealot shoppers.".format(rating, reviews))
    stock = product.get("stock") if isinstance(product.get("stock"), dict) else {}
    warehouses = stock.get("warehouses") or []
    delivery = stock.get("deliveryDays")
    if warehouses:
        lines.append("- Dispatched from {0} with delivery in {1} working days.".format(
            ", ".join(str(w) for w in warehouses[:3]), delivery or "2-5"))
    category_path = str(product.get("categoryPath") or "").strip()
    if category_path:
        lines.append("- Category: {0}.".format(category_path.replace(" > ", " > ")))
    text = "\n".join(lines)
    filler_index = 0
    while len(text) < min_len and filler_index < len(_FEATURE_FILLER):
        text += "\n- " + _FEATURE_FILLER[filler_index]
        filler_index += 1
    while len(text) < min_len:
        text += "\n- Supplied ready for the Takealot marketplace with a compliant pack-shot set."
    return text


# The own-offers index is cached PER STORE (``_OFFER_INDEX_BY_STORE``, addendum 2 §2).


_OFFER_INDEX_BY_STORE: Dict[str, Dict[str, Any]] = {}


def _offer_index_cache(store_id: Any = None) -> Dict[str, Any]:
    """The per-store own-offers index bucket (addendum 2 §2: keyed by store id)."""
    info = _effective_store(store_id)
    return _OFFER_INDEX_BY_STORE.setdefault(info["storeId"] or "__none__", {
        "at": 0.0, "byPlid": {}, "byTsin": {}, "byBarcode": {}, "count": 0, "error": None,
        "storeId": info["storeId"], "storeName": info["storeName"]})


def _seller_offers_index(ttl: float = 60.0, store_id: Any = None) -> Dict[str, Any]:
    """The seller's OWN offers **for one store**, indexed for matching, cached ≤``ttl``.

    Keyed by store id (``{"store-2": {...}, "store-apex-direct": {...}}``): switching the
    store must never serve the other shop's offers. Reads the same per-store full-offer
    cache the catalogue uses, so it costs nothing extra when the store was just read.
    """
    info = _effective_store(store_id)
    index = _offer_index_cache(store_id)
    now = time.time()
    if index.get("at") and (now - float(index["at"])) < ttl:
        return index
    fresh: Dict[str, Any] = {"at": now, "byPlid": {}, "byTsin": {}, "byBarcode": {}, "count": 0,
                             "error": None, "storeId": info["storeId"], "storeName": info["storeName"]}
    if not _key_configured(store_id):
        fresh["error"] = "no Seller X-API-Key configured for store {0}".format(info["storeId"] or "—")
        index.update(fresh)
        return index
    listing = _rows_for_store(store_id)
    rows = listing.get("rows") or []
    for offer in rows:
        if not isinstance(offer, dict):
            continue
        record = {
            "offerId": offer.get("offer_id"),
            "sku": offer.get("sku"),
            "barcode": offer.get("barcode"),
            "status": offer.get("status"),
            "price": offer.get("selling_price"),
            "title": offer.get("title"),
            "disabledBySeller": offer.get("disabled_by_seller"),
            "disabledByTakealot": offer.get("disabled_by_takealot"),
        }
        plid = _plid_of(offer.get("productline_id"))
        tsin = _plid_of(offer.get("tsin_id") or offer.get("tsin"))
        barcode = str(offer.get("barcode") or "").strip().lower()
        if plid:
            fresh["byPlid"][plid] = record
        if tsin:
            fresh["byTsin"][tsin] = record
        if barcode:
            fresh["byBarcode"][barcode] = record
    fresh["count"] = len(rows)
    if not rows:
        fresh["error"] = listing.get("error") or "该店铺的 offer 列表为空"
    index.update(fresh)
    return index


def _match_seller_offer(product: Dict[str, Any], target: Any = None,
                        store_id: Any = None) -> Dict[str, Any]:
    """Match a crawled product (or a bare target) against the seller's own offers.

    Returns ``{matched, key, offer, offerCount, error}``. ``key`` names the evidence
    that matched (``plid`` / ``tsin`` / ``barcode``) so the UI can explain itself.
    """
    index = _seller_offers_index(store_id=store_id)
    product = product or {}
    candidates = (
        ("plid", _plid_of(product.get("plid") or target), "byPlid"),
        ("tsin", _plid_of(product.get("tsin")), "byTsin"),
        ("barcode", str(product.get("barcode") or "").strip().lower(), "byBarcode"),
    )
    for key, value, bucket in candidates:
        if value and value in index.get(bucket, {}):
            return {"matched": True, "key": key, "offer": index[bucket][value],
                    "offerCount": index.get("count"), "error": index.get("error")}
    return {"matched": False, "key": None, "offer": None,
            "offerCount": index.get("count"), "error": index.get("error")}


def _route_verdict(product: Dict[str, Any], crawl: Dict[str, Any], target: Any,
                   store_id: Any = None) -> Dict[str, Any]:
    plid = _plid_of(product.get("plid") or product.get("tsin") or target)
    transport = str(crawl.get("transport") or "")

    # Strongest evidence first: the seller's OWN offer. A match here means the product
    # is already listed on this account, so the correct action is 跟卖 (update the
    # offer), never a new Loadsheet — a new one collides with the existing catalogue
    # entry and gets rejected.
    owned = _match_seller_offer(product, target, store_id)
    if owned["matched"]:
        offer = owned["offer"] or {}
        price = offer.get("price")
        status = str(offer.get("status") or "").strip()
        return {
            "route": "offer",
            "exists": True,
            "routeSource": "seller-offers",
            "matchKey": owned["key"],
            "sellerOffer": offer,
            "routeReason": (
                "你已经在卖这个商品（匹配依据：{0}；自有 SKU {1}，Offer {2}，状态 {3}{4}）—— "
                "走跟卖，修正库存/价格即可，不要新建 Product Information Loadsheet。"
            ).format(
                {"plid": "PLID", "tsin": "TSIN", "barcode": "条码"}.get(owned["key"], owned["key"]),
                offer.get("sku") or "—",
                offer.get("offerId") or "—",
                status or "—",
                "，售价 R{0}".format(price) if price not in (None, "", 0) else "，售价为空（该 Offer 当前不可售，先修好价格/库存再上）",
            ),
            "nextStep": "PATCH /offers/by_sku/{0}（改价或改库存）；状态为 not_buyable/0 价格时先补齐再上架。".format(
                offer.get("sku") or "<sku>"),
        }

    catalog_hit = bool(plid) and not product.get("demo") and transport in ("proxy", "direct", "ingest")
    erp_hit = False
    if not catalog_hit and plid:
        erp_hit = any(_plid_of(row.get("tsin")) == plid for row in _order_rows()) or \
            any(_plid_of(item.get("tsin") or item.get("sourceUrl")) == plid for item in _collection())
    if catalog_hit:
        return {
            "route": "offer",
            "exists": True,
            "routeSource": "public-catalog",
            "routeReason": (
                "该商品已存在于 Takealot 目录（{0}，公开页已确认）：走跟卖 Offer 通道 —— 用条码/TSIN 直接建 Offer 即可，"
                "不需要 Product Information Loadsheet。".format(plid or target or "")
            ),
            "nextStep": "POST /offers（Seller API，按 barcode 或 TSIN 跟卖）；Loadsheet 仅在该商品确实为新目录项时使用。",
        }
    if erp_hit:
        # A local row is NOT proof the product is on Takealot: blocking 建档 here made every
        # product that ever passed through 采集箱 impossible to list. Report it and let the
        # operator decide (the barcode decides: an existing TSIN means 跟卖).
        return {
            "route": "loadsheet",
            "exists": False,
            "routeSource": "erp-records",
            "routeReason": (
                "本地有该商品的记录（采集箱/订单，{0}），但这次没有从公开页确认它在 Takealot 上。"
                "如果它确实已在平台上（哪怕别人在卖），应当跟卖而不是新建；只有全新目录项才用装载表。"
            ).format(plid or target or ""),
            "nextStep": ("先确认条码：已有 TSIN → POST /offers 跟卖；没有 → 用 Product Information Loadsheet 新建。"
                         "点「补全」抓一次公开页可以直接把这个判断做实。"),
            "warning": "本地记录不等于平台在售：建档前请确认条码是否已存在。",
        }
    return {
        "route": "loadsheet",
        "exists": False,
        "routeSource": "none",
        "routeReason": (
            "Takealot 目录中未找到该商品：属新品，必须用 Product Information Loadsheet 建档"
            "（上传 Seller Portal → Add Products → Request New Catalogue，走人工 QC）。"
        ),
        "nextStep": "补齐必填字段后 POST /listings/loadsheet 导出 .xlsx，再上传 Seller Portal。",
    }


def _draft_from_product(product: Dict[str, Any], crawl: Dict[str, Any], target: Any,
                        store: Dict[str, Any], warnings: List[str],
                        payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    payload = payload or {}
    plid = _plid_of(product.get("plid") or product.get("tsin") or target)
    pairs = _product_attribute_pairs(product)
    category_path = str(product.get("categoryPath") or "").strip()
    resolved = _resolve_catalog_category(category_path)
    title, trimmed = _fit_text(product.get("title"), 75)
    if trimmed:
        warnings.append("标题超 75 字符已按词边界截断（Loadsheet Title 硬上限 75）。")
    subtitle, subtitle_trimmed = _fit_text(product.get("subtitle"), 110)
    if subtitle_trimmed:
        warnings.append("副标题超 110 字符已按词边界截断（Subtitle 上限 110）。")
    barcode = _product_barcode(product, pairs)
    barcode_assigned = bool(barcode) and is_takealot_assigned_barcode(barcode)
    if barcode_assigned:
        warnings.append("采集到的条码 {0} 是 Takealot 占位码（非 GS1），新品刊登不可复用，已留空。".format(barcode))
    warranty_type, warranty_months = _product_warranty(pairs)
    images = _product_image_urls(product)
    if not images:
        warnings.append("采集数据里没有可用图片：图片列留空，请在面板补主图（不生成占位假图）。")
    if not barcode:
        warnings.append(
            "采集数据没有 GS1 条码：跟卖(Offer)通道用 TSIN 作为 identifier；若走 Loadsheet 建档，"
            "需自备 GS1/EAN-13 或留空由 Takealot 生成。"
        )
    attributes: Dict[str, str] = {}
    for pair in pairs:
        attributes.setdefault(pair["name"], pair["value"])
    if resolved.get("loadsheetId"):
        try:
            for field in _attribute_fields(str(resolved["loadsheetId"]))[:60]:
                if field.get("required") and not field.get("name") in attributes:
                    attributes.setdefault(field["name"], "")
        except Exception:  # pragma: no cover - defensive
            pass
    if category_path:
        attributes.setdefault("Takealot Category Path", category_path)

    variants = product.get("variants")
    variant_themes: List[str] = []
    variant_rows: List[Dict[str, Any]] = []
    if isinstance(variants, list) and variants:
        axis = variants[0] if isinstance(variants[0], dict) else {}
        axis_title = str(axis.get("title") or axis.get("type") or "").strip()
        options = [str(opt.get("label")).strip() for opt in (axis.get("options") or [])
                   if isinstance(opt, dict) and str(opt.get("label") or "").strip()]
        if axis_title and options:
            variant_themes = [axis_title]
            base_sku = str(product.get("sku") or "TL-{0}".format(plid or "NEW"))
            variant_rows = [{"values": [option], "sku": "{0}-{1}".format(base_sku, option.replace(" ", "")),
                             "barcode": "", "images": []} for option in options[:12]]

    money = _analysis_money(payload, product, _find_collection_item(target) or {})
    price = float(money.get("priceBand", {}).get("recommended") or product.get("price") or 0)
    qty = int(payload.get("qty") or 10)
    features = _features_from_product(product, pairs)
    compliance = compliance_check(" ".join([title, subtitle, str(product.get("brand") or "")]),
                                  resolved.get("mainCategory") or product.get("categoryL1"))
    draft = {
        "id": "DRF-{0}".format(plid or _now().strftime("%Y%m%d%H%M%S")),
        "sku": str(product.get("sku") or "TL-{0}".format(plid or "NEW")),
        "productType": "Variant Parent" if variant_rows else "Single",
        "variantGroup": str(product.get("sku") or "TL-{0}".format(plid or "NEW")) if variant_rows else "",
        "title": title,
        "subtitle": subtitle,
        "features": features,
        "brand": str(product.get("brand") or ""),
        "barcode": "" if barcode_assigned else barcode,
        "whatsInTheBox": _box_contents(product, pairs, title),
        "images": images[:IMAGE_COLUMN_COUNT],
        "videoUrl": "",
        "warrantyType": warranty_type,
        "warrantyPeriod": warranty_months,
        "category": _canonical_category(product.get("categoryL1"), category_path,
                                        product.get("department"), title),
        "categoryPath": category_path,
        "mainCategory": resolved.get("mainCategory") or (product.get("categoryL1") or "")
                        or ((_split_path(category_path) or [""])[0]),
        # Lowest Category is the LEAF NODE NAME, not the path: a non-leaf value is
        # rejected on submit (see the leaf check in the loadsheet row builder), and a
        # crawl often resolves only the department.
        "lowestCategory": (_split_path(resolved.get("path") or category_path) or [""])[-1],
        "storeId": store.get("id") or "",
        "storeName": store.get("name") or "",
        "attributes": attributes,
        "price": _r(price),
        "qty": qty,
        "status": "draft",
        "updatedAt": _iso_now(),
        "compliance": {"hits": [hit["word"] for hit in compliance.get("hits") or []],
                       "verdict": compliance.get("verdict")},
        "tsin": product.get("tsin") or ("PLID" + plid if plid else ""),
        "plid": product.get("plid") or ("PLID" + plid if plid else ""),
        "marketPrice": _r(product.get("price") or 0),
        "priceBand": money.get("priceBand"),
        "nodeId": resolved.get("nodeId"),
        "loadsheetId": resolved.get("loadsheetId"),
        "loadsheetName": resolved.get("loadsheetName"),
        "categoryAttributes": _attribute_fields(str(resolved.get("loadsheetId") or ""))[:40],
    }
    if variant_themes:
        draft["variantThemes"] = variant_themes
        draft["variants"] = variant_rows
    return draft


def _prefill_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    target = payload.get("target") or payload.get("plid") or payload.get("url") or payload.get("tsin") or ""
    crawl = _crawl_target(target, force=bool(payload.get("force")))
    product = crawl.get("product") if isinstance(crawl.get("product"), dict) else None
    warnings: List[str] = []
    if not product:
        # 抓不到就是抓不到：返回真实失败原因，绝不拿 ERP 记录/样例拼一个不存在的商品
        return {
            "ok": False, "empty": True, "mode": str(crawl.get("mode") or "blocked"),
            "target": target, "route": None, "exists": None,
            "product": None, "draft": None, "warnings": [],
            "crawl": {"mode": crawl.get("mode"), "transport": crawl.get("transport"),
                      "cached": bool(crawl.get("cached")), "stale": crawl.get("stale"),
                      "fetchedAt": crawl.get("fetchedAt"), "error": crawl.get("error"),
                      "hint": crawl.get("hint")},
            "error": crawl.get("error") or "公开页未取到该商品",
            "requires": "公开页可访问（或 /crawler/ingest 投放原始 JSON）",
            "hint": crawl.get("hint") or CRAWLER_HINT_STATIC,
            "note": "上架预填只认真实抓取结果：抓不到就不生成草稿。",
        }
    product = dict(product)
    mode = str(crawl.get("mode") or "live")
    product["crawlMode"] = mode
    product["transport"] = crawl.get("transport")
    product["cached"] = bool(crawl.get("cached"))
    product["stale"] = crawl.get("stale")
    store = _store_row(payload.get("storeId")) or _store_row(_store_data().get("activeStoreId")) or {}
    verdict = _route_verdict(product, crawl, target)
    draft = _draft_from_product(product, crawl, target, store, warnings, payload)
    draft["listingRoute"] = verdict["route"]
    pairs = _product_attribute_pairs(product)
    barcode = _product_barcode(product, pairs)
    if not product.get("brand"):
        warnings.append("采集数据没有品牌信息：Brand 列可留空（仅当产品或包装有品牌 logo 时才填）。")
    result = {
        "ok": True,
        "mode": mode,
        "target": target,
        "route": verdict["route"],
        "exists": verdict["exists"],
        "routeSource": verdict["routeSource"],
        "routeReason": verdict["routeReason"],
        "nextStep": verdict["nextStep"],
        "matchKey": verdict.get("matchKey"),
        "sellerOffer": verdict.get("sellerOffer"),
        "crawl": {
            "mode": mode,
            "transport": crawl.get("transport"),
            "cached": bool(crawl.get("cached")),
            "stale": crawl.get("stale"),
            "fetchedAt": crawl.get("fetchedAt"),
            "error": crawl.get("error"),
            "hint": crawl.get("hint"),
            "sales": crawl.get("sales"),
            "windows": crawl.get("windows"),
        },
        "product": {
            "plid": product.get("plid"),
            "tsin": product.get("tsin"),
            "title": product.get("title"),
            "subtitle": product.get("subtitle"),
            "brand": product.get("brand"),
            "barcode": barcode,
            "barcodeAssigned": bool(barcode) and is_takealot_assigned_barcode(barcode),
            "categoryPath": product.get("categoryPath"),
            "images": _product_image_urls(product),
            "attributes": pairs,
            "price": _r(product.get("price") or 0),
            "rating": product.get("rating"),
            "reviewCount": product.get("reviews") or product.get("reviewCount"),
            "sellerCount": product.get("sellerCount"),
            "stock": product.get("stock"),
            "url": product.get("url"),
        },
        "catalog": {
            "nodeId": draft.get("nodeId"),
            "path": draft.get("lowestCategory"),
            "mainCategory": draft.get("mainCategory"),
            "loadsheetId": draft.get("loadsheetId"),
            "loadsheetName": draft.get("loadsheetName"),
        },
        "draft": draft,
        "warnings": warnings,
    }
    if not crawl.get("ok"):
        result["hint"] = crawl.get("hint")
    return result


# --------------------------------------------------------------------------
# Collections / drafts mutations
# --------------------------------------------------------------------------

# （固定的假标题池已删除：标题只来自客户输入 / URL slug / 真实抓取）


def _derive_tsin(url_or_tsin: str) -> str:
    """URL / TSIN / PLID -> 规范标识；解析不出来就返回空串（以前会哈希编一个假 PLID）。"""
    match = re.search(r"(PLID\d{5,}|TSIN-?\d{4,}|\d{7,10})", url_or_tsin or "", re.I)
    if match:
        token = match.group(1).upper()
        return token if token.startswith("TSIN") else "PLID" + re.sub(r"\D", "", token)
    return ""


def _derive_title(payload: Dict[str, Any]) -> str:
    """标题只来自客户输入或 URL slug；两者都没有就留空（不再从固定标题池里挑一个）。"""
    explicit = (payload.get("title") or "").strip()
    if explicit:
        return explicit
    url = (payload.get("url") or "").strip()
    if url:
        slug = urllib.parse.urlparse(url).path.rstrip("/").split("/")[-1]
        slug = re.sub(r"[-_]+", " ", urllib.parse.unquote(slug)).strip()
        slug = re.sub(r"^(p|dp)$", "", slug, flags=re.I).strip()
        if len(slug) >= 8 and not slug.isdigit():
            return " ".join(w.capitalize() if w.islower() else w for w in slug.split())[:120]
    return ""


def _derive_category(title: str) -> str:
    lowered = title.lower()
    rules = [
        (("earbud", "headphone", "audio", "speaker"), "Audio & Headphones"),
        (("charger", "power bank", "usb", "cable", "phone"), "Cellphones & Wearables"),
        (("kitchen", "knife", "utensil", "cookware"), "Home & Kitchen"),
        (("car ", "tyre", "automotive", "mount"), "Automotive & Motor Accessories"),
        (("laptop", "desk", "office", "stationery"), "Office, Stationery & Books"),
        (("yoga", "fitness", "camping", "outdoor"), "Sports & Outdoors"),
        (("toy", "kids", "baby", "blocks"), "Toys & Baby"),
        (("vacuum", "appliance", "kettle"), "Small Domestic Appliances"),
        (("tool", "garden", "drill"), "DIY, Tools & Garden"),
        (("lamp", "light", "pillow", "organiser", "bathroom"), "Home & Kitchen"),
    ]
    for needles, category in rules:
        if any(n in lowered for n in needles):
            return category
    return "General Merchandise"


def _add_collection_item(payload: Dict[str, Any], crawl: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """把客户采集的一行写进采集箱 —— 每个字段都来自客户输入或真实抓取结果。

    以前这里会给缺失字段编数（成本/售价/条码/图片），现在缺就是缺：
    cost/estSalePrice 为 0，barcode/imageUrl 为空，并写进 missing[] 让 UI 提示补录。
    """
    items = _collection()
    existing = {str(i.get("id")) for i in items}
    url = (payload.get("url") or "").strip()
    tsin = (payload.get("tsin") or "").strip() or _derive_tsin(url)
    product = crawl.get("product") if isinstance(crawl, dict) and crawl.get("mode") == "live" else None
    product = product if isinstance(product, dict) else None
    # 公开页属性 → 条码 + 包装尺寸/重量（官方履约费按体积档定价，尺寸就是费率条件的输入）
    card_pairs = _product_attribute_pairs(product) if product else []
    card_dims = _product_dimensions(card_pairs) if product else {}
    card_barcode = _product_barcode(product, card_pairs) if product else ""
    title = (payload.get("title") or "").strip() or _derive_title(payload)
    if product and product.get("title") and not (payload.get("title") or "").strip():
        title = str(product["title"])[:120]
    category = ((payload.get("category") or "").strip()
                or str((product or {}).get("categoryPath")
                       or ((product or {}).get("category") or {}).get("path") or "").strip())
    try:
        cost = float(payload.get("cost") or 0)
    except (TypeError, ValueError):
        cost = 0.0
    try:
        price = float(payload.get("price") or 0)
    except (TypeError, ValueError):
        price = 0.0
    if not price:
        price = float((product or {}).get("price") or 0)
    seq = len(items) + 1001
    while "COL-{0}".format(seq) in existing:
        seq += 1
    store_id = str(payload.get("storeId") or "").strip() or None
    store = _store_row(store_id)
    barcode = str(payload.get("barcode") or (product or {}).get("barcode") or card_barcode or "").strip()
    image_url = str(payload.get("imageUrl") or (product or {}).get("image") or "").strip()
    missing = [name for name, value in (("cost", cost), ("barcode", barcode), ("image", image_url),
                                        ("category", category), ("title", title)) if not value]
    item = {
        "id": "COL-{0}".format(seq),
        "title": title,
        "tsin": (product or {}).get("tsin") or tsin,
        "barcode": barcode,
        "brand": (payload.get("brand") or (product or {}).get("brand") or "").strip(),
        "category": category,
        "sourceUrl": url or (product or {}).get("url") or ("https://www.takealot.com/p/{0}".format(tsin) if tsin.startswith("PLID") else ""),
        "imageUrl": image_url,
        "cost": _r(cost),
        "estSalePrice": _r(price),
        # ── 利润核算字段（新增：成本币种、RMB 成本、汇率、汇损系数、头程运费）──
        "costCurrency": str(payload.get("costCurrency") or "ZAR").upper()[:3],
        "costRmb": float(payload.get("costRmb") or 0),
        "exchangeRateZarPerRmb": float(payload.get("exchangeRateZarPerRmb") or 0) or None,
        "exchangeLossCoeff": float(payload.get("exchangeLossCoeff") or 0) or None,
        "headLogisticsZar": float(payload.get("headLogisticsZar") or 0) or None,
        "weightKg": payload.get("weightKg") or (product or {}).get("weightKg") or card_dims.get("weightKg") or None,
        "lengthCm": payload.get("lengthCm") or card_dims.get("lengthCm") or None,
        "widthCm": payload.get("widthCm") or card_dims.get("widthCm") or None,
        "heightCm": payload.get("heightCm") or card_dims.get("heightCm") or None,
        # 尺寸/重量的来源（界面要能说清是抓来的还是人填的）；取不到就是 None
        "dimensionSource": card_dims.get("source") if not payload.get("lengthCm") else "user-input",
        "dimensionRaw": card_dims.get("raw"),
        "warehouse": (str(payload.get("warehouse") or "").upper() or None),
        "status": "pending",
        "addedAt": _iso_now(),
        "note": (payload.get("note") or "").strip(),
        "missing": missing,
        "assignedStoreId": str(store.get("id")) if store else None,
        "assignedStoreName": store.get("name") if store else None,
    }
    if isinstance(crawl, dict):
        item["crawl"] = {
            "mode": crawl.get("mode"),
            "transport": crawl.get("transport"),
            "monthlySales": (crawl.get("sales") or {}).get("estimated_monthly_sales") if isinstance(crawl.get("sales"), dict) else None,
            "rate": crawl.get("rate"),
            "sellerCount": (product or {}).get("sellerCount"),
            "fetchedAt": crawl.get("fetchedAt"),
            "cached": bool(crawl.get("cached")),
        }
    # 跟卖池语义（用户 2026-09-20）：新建采集行默认 intent=follow、state=pool；
    # 商家可显式标 intent=new（平台上没有 → 之后走草稿箱）。stock 只认商家填的值。
    item["intent"] = str(payload.get("intent") or item.get("intent") or "follow").strip() or "follow"
    if item["intent"] not in ("follow", "new"):
        item["intent"] = "follow"
    item["state"] = str(item.get("state") or "pool")
    item["source"] = str(payload.get("source") or item.get("source") or "erp")
    if payload.get("stock") not in (None, ""):
        try:
            item["stock"] = int(float(payload.get("stock")))
        except (TypeError, ValueError):
            pass
    items.insert(0, item)
    _write_state("collection.json", items)
    return item


def _promote_collection(ids: List[str], store_id: Optional[str] = None) -> Dict[str, Any]:
    items = _collection()
    drafts = _drafts()
    wanted = {str(i) for i in ids} if ids else {str(i.get("id")) for i in items}
    store = _store_row(store_id)
    created: List[Dict[str, Any]] = []
    touched: List[str] = []
    for item in items:
        if str(item.get("id")) not in wanted:
            continue
        item_store = store or _item_store(item)
        draft = {
            "id": "DRF-{0}".format(str(item.get("id")).replace("COL-", "2")),
            "title": item.get("title", ""),
            "subtitle": item.get("note", "")[:110],
            "brand": item.get("brand", ""),
            "barcode": item.get("barcode", ""),
            "tsin": item.get("tsin", ""),
            "category": item.get("category", ""),
            "categoryPath": item.get("category", ""),
            "attributes": {},
            "price": float(item.get("estSalePrice") or 0),
            "qty": 1,
            "status": "draft",
            # 新建草稿箱语义：来源可追溯（从哪条采集行转来的），
            # state=drafting 表示"还没编辑完、可以随时继续"。
            "state": "drafting",
            "source": "collection:{0}".format(item.get("id")),
            "fromCollection": str(item.get("id")),
            "updatedAt": _iso_now(),
            "compliance": {"hits": []},
            "storeId": str(item_store.get("id")) if item_store else None,
            "storeName": item_store.get("name") if item_store else None,
        }
        # A collection row only carries the department ("Toys & Baby"); the loadsheet
        # needs a leaf node, so take the resolved path from the crawl cache and split it
        # into Main Category (department) + Lowest Category (leaf name).
        crawl_product = (_cached_crawl_for_item(item) or {}).get("product") or {}
        if not crawl_product:
            # The velocity cache stores a slim summary; the full card (with the resolved
            # category) comes from the crawler's own cache via a cache-only pull.
            crawl_module = _crawler()
            plid_hint = _plid_of(item.get("sourceUrl") or item.get("tsin") or "")
            if crawl_module is not None and plid_hint:
                try:
                    cached = crawl_module.pull("PLID{0}".format(plid_hint), cached_only=True) or {}
                    crawl_product = cached.get("product") or {}
                except Exception:  # pragma: no cover - defensive
                    crawl_product = {}
        nested = crawl_product.get("category") if isinstance(crawl_product.get("category"), dict) else {}
        path = str(
            crawl_product.get("categoryPath")
            or nested.get("path")
            or " > ".join(nested.get("names") or [])
            or item.get("category")
            or ""
        ).strip()
        if path:
            resolved_cat = _resolve_catalog_category(path)
            if resolved_cat.get("path"):
                path = str(resolved_cat.get("path"))
            segments = _split_path(path)
            if segments:
                draft["categoryPath"] = path
                draft["mainCategory"] = resolved_cat.get("mainCategory") or segments[0]
                draft["lowestCategory"] = segments[-1]
        draft = _draft_upgrade(draft)
        created.append(draft)
        # 采集行留痕：转出后 state=promoted + draftId（不删行，保留历史与去重依据）
        item["state"] = "promoted"
        item["draftId"] = draft.get("id")
        item["promotedAt"] = _iso_now()
        touched.append(str(item.get("id")))
        drafts = [d for d in drafts if d.get("id") != draft["id"]]
        drafts.insert(0, draft)
        item["status"] = "promoted"
        if item_store is not None:
            item["assignedStoreId"] = str(item_store.get("id"))
            item["assignedStoreName"] = item_store.get("name")
    if created:
        _write_state("collection.json", items)
        _write_state("drafts.json", drafts)
        # 唯一的"采集箱 → 新建草稿箱"通道：两侧都留痕，交付时可自证改过什么
        _collection_audit({"action": "collection/promote", "ids": touched,
                           "drafts": [d.get("id") for d in created]})
    return {"created": created, "count": len(created), "conflicts": _collection_conflicts(items)}


# --------------------------------------------------------------------------
# Endpoint helper: never 500, never an empty module
# --------------------------------------------------------------------------

def _fallback(shape: Dict[str, Any]) -> Callable[[], Dict[str, Any]]:
    def factory() -> Dict[str, Any]:
        return json.loads(json.dumps(shape))

    return factory


def _safe(fn: Callable[[], Any], fallback: Callable[[], Dict[str, Any]]) -> Any:
    try:
        return fn()
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("takealot-erp: endpoint error: %s", exc, exc_info=True)
        payload = fallback()
        payload["mode"] = "error"
        payload["ok"] = False
        payload["error"] = _sanitize(exc)
        return payload


# --------------------------------------------------------------------------
# Crawler module (dashboard/crawler.py) — public-API transport ladder,
# 留评率→销量 estimation and AI valuation. Loaded by file location so the
# plugin works whether the gateway imports this file as a package module or
# straight from its path. Never touches the Seller X-API-Key.
# --------------------------------------------------------------------------

def _load_crawler() -> Any:
    path = DASHBOARD_DIR / "crawler.py"
    try:
        if not path.is_file():
            return None
        spec = importlib.util.spec_from_file_location("hermes_takealot_erp_crawler", str(path))
        if spec is None or spec.loader is None:
            return None
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        if hasattr(module, "set_state_dir"):
            module.set_state_dir(STATE_DIR)
        return module
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("takealot-erp: crawler module unavailable: %s", exc)
        return None


CRAWLER = _load_crawler()
CRAWLER_ERROR = None if CRAWLER else "dashboard/crawler.py is missing or failed to import"


#: Static hint attached to the crawler fallback payloads. Kept I/O-free because
#: ``_fallback({...})`` arguments are evaluated at import time.
CRAWLER_HINT_STATIC = (
    "公网出口被 Cloudflare 拦截时仍有三条取数路径：1) 设置 TAKEALOT_API_PROXY "
    "指向 Takealot 接受的出口代理；2) POST /crawler/ingest 推入原始 JSON；"
    "3) 把原始 JSON 放进后端 state/ingest/*.json 投放目录（/crawler/status 与 /crawler/pull 会自动吸收）。"
)


def _crawler() -> Any:
    return CRAWLER


def _crawler_unavailable() -> Dict[str, Any]:
    return {
        "ok": False,
        "mode": "blocked",
        "error": CRAWLER_ERROR or "crawler module unavailable",
        "hint": "Backend is missing dashboard/crawler.py — redeploy the plugin package.",
    }


def _empty_windows() -> Dict[str, Any]:
    return {"total": 0, "reviews_7d": 0, "reviews_30d": 0, "reviews_90d": 0, "reviews_180d": 0, "pagesFetched": 0, "truncated": False}


# 旧的"抓不到公开页就编一个商品"（假价格/假评分/假评论数/假竞品价）已删除。
# 抓取失败一律返回真实失败原因（HTTP 状态 / Cloudflare 挑战 / 404 / 超时）+ ok:false。


def _crawl_target(target: Any, force: bool = False, cached_only: bool = False) -> Dict[str, Any]:
    module = _crawler()
    if module is None:
        return _crawler_unavailable()
    try:
        return module.pull(target, force=force, cached_only=cached_only)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("takealot-erp: crawl failed: %s", exc)
        return {
            "ok": False,
            "mode": "blocked",
            "transport": "blocked",
            "cached": False,
            "target": target,
            "product": None,
            "windows": None,
            "rate": None,
            "sales": None,
            "error": _sanitize(exc),
            "hint": module.hint() if hasattr(module, "hint") else "",
        }


# --------------------------------------------------------------------------
# Multi-store helpers — one collection box shared by every store
# --------------------------------------------------------------------------

def _stores() -> List[Dict[str, Any]]:
    return [s for s in (_store_data().get("stores") or []) if isinstance(s, dict)]


def _public_store_list() -> List[Dict[str, Any]]:
    active = _store_data().get("activeStoreId")
    return [
        {"id": s.get("id", ""), "name": s.get("name", ""), "active": s.get("id") == active}
        for s in _stores()
    ]


def _public_store_list_row(store: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": store.get("id", ""),
        "name": store.get("name", ""),
        "active": store.get("id") == _store_data().get("activeStoreId"),
        "status": store.get("status", "unverified"),
        "region": store.get("region", "ZA"),
        "keyMasked": _mask(store.get("_key") or ""),
    }


def _store_row(store_id: Any) -> Optional[Dict[str, Any]]:
    if not store_id:
        return None
    for row in _stores():
        if str(row.get("id")) == str(store_id):
            return row
    return None


def _item_store(item: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    return _store_row(item.get("assignedStoreId"))


def _row_store_id(row: Any) -> str:
    """一行数据真正属于哪家店。

    真实行自带 storeId（/sales 是拿哪家的 Key 取的）；兼容旧调用点传进来的
    订单号字符串 —— 那样只能回落在只有一家店时的唯一答案，多店时返回空串
    （宁可不归属，也不用哈希把订单随机分给某家店）。
    """
    if isinstance(row, dict):
        return str(row.get("storeId") or row.get("assignedStoreId") or "")
    stores = _stores()
    if len(stores) == 1:
        return str(stores[0].get("id") or "")
    return ""


def _store_rows(rows: Any, store_id: Any = None,
                key_names: Sequence[str] = ("storeId", "assignedStoreId", "store_id")) -> Tuple[List[Any], Dict[str, Any]]:
    """Local rows of ONE store (addendum 2 §3).

    Rows that carry no store stay visible so nothing disappears (they used to belong to
    whatever store was active when they were written); the scope block says how many of
    those were included. No ``storeId`` → the 汇总 view, everything visible.
    """
    info = _effective_store(store_id)
    listing = [row for row in (rows or [])]
    scope = {"storeId": info["storeId"], "storeName": info["storeName"],
             "scopedFromActive": not info["storeScoped"], "requestedStoreId": info["requestedStoreId"],
             "filtered": False, "unassignedIncluded": 0}
    wanted = str(store_id or "").strip()
    if not wanted or wanted in ("all", "*", "active"):
        return listing, scope
    keep: List[Any] = []
    unassigned = 0
    for row in listing:
        if not isinstance(row, dict):
            keep.append(row)
            continue
        value = ""
        for key in key_names:
            if row.get(key):
                value = str(row.get(key))
                break
        if not value:
            unassigned += 1
            keep.append(row)
        elif value == info["storeId"]:
            keep.append(row)
    scope.update({"filtered": True, "unassignedIncluded": unassigned})
    return keep, scope


def _wants_all_stores(requested: Any = None) -> bool:
    """True when the caller asked for the cross-store view ('' / 'all' / '*')."""
    return str(requested or "").strip() in ("", "all", "*")


def _explicit_all_stores(requested: Any = None) -> bool:
    """True only when the caller EXPLICITLY asked for the cross-store view ('all' / '*').

    ``''`` means "unset" — the UI sends it before the operator ever picks a store — so
    account-scoped live endpoints fall back to the active store there (and report which
    store they used) instead of refusing. Refusing on ``''`` made the live modules look
    empty on a fresh install.
    """
    return str(requested or "").strip() in ("all", "*")


def _aggregate_catalog(store_id: Any = "") -> Dict[str, Any]:
    """Merge every bound store's catalogue for the 汇总 view (rows tagged per store).

    Each store keeps its own per-store cache bucket, so merging cannot leak one shop's
    offer list into another's; a store whose Seller call fails is reported instead of
    being silently dropped.
    """
    stores = _stores()
    merged: List[Dict[str, Any]] = []
    per_store: List[Dict[str, Any]] = []
    offline_first = None
    for row in stores:
        sid = str(row.get("id") or "")
        context = _catalog_items(store_id=sid)
        offers = context.get("offers") or {}
        if offline_first is None:
            offline_first = offers
        items = []
        for item in context.get("items") or []:
            tagged = dict(item)
            tagged["storeId"] = sid
            tagged["storeName"] = str(row.get("name") or sid)
            items.append(tagged)
        merged.extend(items)
        per_store.append({
            "storeId": sid,
            "storeName": str(row.get("name") or sid),
            "count": len(items),
            "mode": offers.get("mode"),
            "error": offers.get("error"),
            "keyConfigured": bool((row.get("_key") or "").strip()),
        })
    base = dict(offline_first or {})
    base["items"] = merged
    base["mapped"] = len(merged)
    base["aggregate"] = True
    return {"items": merged, "offers": base, "perStore": per_store}


def _scope_store_id(requested: Any = None) -> str:
    """Resolve the storeId a request is scoped to ('' = no scoping)."""
    wanted = str(requested or "").strip()
    if not wanted:
        return ""
    if wanted in ("all", "*"):
        return ""
    return wanted


def _collection_conflicts(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """同一 TSIN 分派到多个店铺 = 自有店铺互相跟卖（内耗）→ conflicts[]."""
    by_tsin: Dict[str, List[Dict[str, Any]]] = {}
    for item in items:
        store = _item_store(item)
        if not store:
            continue
        by_tsin.setdefault(str(item.get("tsin") or ""), []).append({"store": store, "item": item})
    conflicts: List[Dict[str, Any]] = []
    for tsin, rows in by_tsin.items():
        names: List[str] = []
        ids: List[str] = []
        for row in rows:
            name = str(row["store"].get("name") or row["store"].get("id") or "")
            if name and name not in names:
                names.append(name)
            item_id = str(row["item"].get("id") or "")
            if item_id and item_id not in ids:
                ids.append(item_id)
        if len(names) > 1:
            conflicts.append(
                {
                    "tsin": tsin,
                    "stores": names,
                    "itemIds": ids,
                    "detail": "同一 TSIN 已分派到 {0} 个自有店铺，属于自己跟自己抢 BuyBox（内耗），建议只保留一个店铺。".format(len(names)),
                }
            )
    return conflicts


def _numeric(values: List[Any]) -> List[float]:
    """只留真数字。毛利率/净利在缺重量·尺寸或汇率时是 ``None``（工具会显示「未定」）——

    直接 ``sum()`` 会把整个采集箱打成 500，而「缺尺寸」恰恰是常态（公开页只有少数商品写了
    Assembled Dimensions），所以每个聚合点都必须先过滤。
    """
    return [float(v) for v in values if isinstance(v, (int, float)) and not isinstance(v, bool)]


def _store_stats(items: List[Dict[str, Any]], rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Per-store aggregates for the 采集箱."""
    buckets: Dict[str, List[Dict[str, Any]]] = {}
    for item, row in zip(items, rows):
        store = _item_store(item)
        key = str(store.get("id")) if store else "__unassigned__"
        buckets.setdefault(key, []).append(row)
    out = []
    for key, bucket in buckets.items():
        store = _store_row(key) if key != "__unassigned__" else None
        costs = _numeric([r.get("cost") for r in bucket])
        margins = _numeric([r.get("estMargin") for r in bucket])
        profits = _numeric([r.get("estProfit") for r in bucket])
        out.append(
            {
                "storeId": key if key != "__unassigned__" else None,
                "storeName": (store or {}).get("name") or "未分派",
                "count": len(bucket),
                "totalCost": _r(sum(costs)),
                "avgMargin": _r(sum(margins) / len(margins), 1) if margins else 0.0,
                "marginRows": len(margins),
                "estProfit": _r(sum(profits)),
                "pending": sum(1 for r in bucket if r["status"] == "pending"),
                "ready": sum(1 for r in bucket if r["status"] == "ready"),
                "promoted": sum(1 for r in bucket if r["status"] == "promoted"),
            }
        )
    out.sort(key=lambda r: (-int(r["count"]), str(r["storeName"])))
    return out


def _crawl_index() -> Dict[str, Dict[str, Any]]:
    """plid → cached velocity summary (one file read, no network)."""
    module = _crawler()
    if module is None:
        return {}
    try:
        return {entry.get("plid"): entry for entry in module.cache_items(limit=400)}
    except Exception:  # pragma: no cover - defensive
        return {}


def _cached_crawl_for_item(item: Dict[str, Any]) -> Dict[str, Any]:
    """The cached crawl record for a collection item, matched by PLID or TSIN digits.

    A collection row is keyed by TSIN while the velocity cache is keyed by PLID, so a
    naive dict lookup misses; match on any of the identifiers either side carries.
    """
    index = _crawl_index()
    wanted = {_plid_of(item.get("plid")), _plid_of(item.get("tsin")), _plid_of(item.get("sourceUrl"))}
    wanted.discard("")
    if not wanted or not index:
        return {}
    for key, entry in index.items():
        product = (entry or {}).get("product") or {}
        have = {_plid_of(key), _plid_of(product.get("plid")), _plid_of(product.get("tsin"))}
        have.discard("")
        if wanted & have:
            return entry or {}
    return {}


def _item_crawl_summary(item: Dict[str, Any], index: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    plid = _plid_of(item.get("tsin") or item.get("sourceUrl") or "")
    entry = index.get(plid) if plid else None
    if not entry:
        return {
            "plid": plid,
            "cached": False,
            "monthlySales": None,
            "rate": None,
            "fetchedAt": None,
            "transport": None,
            "note": "尚无速度缓存：调用 /crawler/pull 或把原始 JSON 放进 state/ingest/。",
        }
    return {
        "plid": plid,
        "cached": True,
        "monthlySales": entry.get("sales"),
        "rate": entry.get("rate"),
        "rateSource": entry.get("rateSource"),
        "title": entry.get("title"),
        "price": entry.get("price"),
        "sellerCount": entry.get("sellerCount"),
        "fetchedAt": entry.get("fetchedAt"),
        "transport": entry.get("transport"),
        "fresh": entry.get("fresh"),
    }


def _plid_of(target: Any) -> str:
    """Bare numeric PLID from a TSIN/URL/PLID ('' when not resolvable)."""
    match = re.search(r"(?:PLID)?(\d{5,10})", str(target or ""), re.I)
    return match.group(1) if match else ""


def _dig_crawl(row: Dict[str, Any]) -> bool:
    """True when the row carries a cached crawl result."""
    crawl = row.get("crawl")
    return bool(isinstance(crawl, dict) and crawl.get("cached"))


# --------------------------------------------------------------------------
# Fee / price-band money math for the AI valuation (£: /ai/listing-analysis)
# --------------------------------------------------------------------------

_CATEGORY_ALIASES: Dict[str, str] = {
    "fashion": "Fashion & Apparel",
    "apparel": "Fashion & Apparel",
    "shoes": "Shoes & Footwear",
    "footwear": "Shoes & Footwear",
    "luggage": "Luggage & Bags",
    "bags": "Luggage & Bags",
    "beauty": "Beauty & Personal Care",
    "personal care": "Beauty & Personal Care",
    "health": "Health & Wellness",
    "baby": "Toys & Baby",
    "toddler": "Toys & Baby",
    "toys": "Toys & Baby",
    "home": "Home & Kitchen",
    "kitchen": "Home & Kitchen",
    "homeware": "Home & Kitchen",
    "appliances": "Small Domestic Appliances",
    "large appliances": "Large Appliances",
    "automotive": "Automotive & Motor Accessories",
    "sports": "Sports & Outdoors",
    "outdoors": "Sports & Outdoors",
    "office": "Office, Stationery & Books",
    "stationery": "Office, Stationery & Books",
    "books": "Office, Stationery & Books",
    "diy": "DIY, Tools & Garden",
    "tools": "DIY, Tools & Garden",
    "garden": "DIY, Tools & Garden",
    "pets": "General Merchandise",
    "electronics": "Consumer Electronics",
    "audio": "Audio & Headphones",
    "headphones": "Audio & Headphones",
    "cellphones": "Cellphones & Wearables",
    "wearables": "Cellphones & Wearables",
    "computers": "Computers & Tablets",
    "tablets": "Computers & Tablets",
}


def _canonical_category(*hints: Any) -> str:
    hay = " ".join(str(h) for h in hints if h).lower()
    if not hay:
        return "General Merchandise"
    # 优先命中官方费率表的子类目/主类目名（官方文档用词），再退到旧口径别名
    best: Optional[str] = None
    for main, rows in _official_success_rules().items():
        for rule in rows:
            sub = str(rule.get("sub") or "")
            if len(sub) >= 3 and sub.lower() in hay and (best is None or len(sub) > len(best)):
                best = sub
        if str(main).lower() in hay and (best is None or len(main) > len(best)):
            best = main
    if best:
        return best
    for needle, name in _CATEGORY_ALIASES.items():
        if needle in hay:
            return name
    return "General Merchandise"


def _analysis_money(payload: Dict[str, Any], product: Dict[str, Any], item: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """费用矩阵 + 保本价/20% 目标价（金额算法本身是权威的，输入必须是真实值）。

    采购成本只认客户输入或本地记录（采集箱 cost）；没有成本就不给保本价/目标价
    （以前会用哈希编一个 45~320 的成本，属于造假，已删除）。
    """
    item = item or {}
    price = float(product.get("price") or item.get("estSalePrice") or 0)
    try:
        cost = float(payload.get("cost") or item.get("cost") or 0)
    except (TypeError, ValueError):
        cost = 0.0
    try:
        freight = float(payload.get("freight") or item.get("inboundFreight") or 0)
    except (TypeError, ValueError):
        freight = 0.0
    category = _canonical_category(
        product.get("categoryL1"),
        product.get("categoryPath"),
        product.get("department"),
        product.get("title"),
        item.get("category"),
    )
    dc = calculate_dc_fulfillment_fee(
        {
            "weightKg": payload.get("weightKg") or item.get("weightKg"),
            "lengthCm": payload.get("lengthCm") or item.get("lengthCm"),
            "widthCm": payload.get("widthCm") or item.get("widthCm"),
            "heightCm": payload.get("heightCm") or item.get("heightCm"),
            "warehouse": payload.get("warehouse") or item.get("warehouse") or "JHB",
            # 履约费的类目分组也要拿到同一套类目线索，否则会误报「类目未匹配」
            "category": category,
            "categoryPath": product.get("categoryPath") or item.get("category") or category,
            "department": product.get("department"),
            "title": str(product.get("title") or item.get("title") or ""),
        }
    )
    fee = calculate_success_fee(price, category or None, price=price,
                                title=str(product.get("title") or item.get("title") or ""))
    rate = fee.get("rate")
    dc_fee = dc.get("fulfillmentFeeZAR")
    supply_cost = _r(cost + freight)
    fixed_cost = float(dc_fee or 0.0) + supply_cost

    floor = None
    recommended = None
    if rate is not None and dc_fee is not None:
        denom = 1.0 - rate * FEE_VAT_MULTIPLIER       # 成功费按含 VAT 计入
        if denom > 0:
            floor = _r(fixed_cost / denom)
        denom20 = denom - 0.20
        if denom20 > 0:
            recommended = _r(fixed_cost / denom20)

    def net_at(target_price: float) -> Optional[float]:
        if rate is None or dc_fee is None:
            return None
        # 不套最低成功费（平台无下限，见 MIN_SUCCESS_FEE_NOTE）
        success = _r(_r(target_price * rate) * FEE_VAT_MULTIPLIER)
        return _r(target_price - success - dc_fee - supply_cost)

    net_recommended = (net_at(recommended) if recommended is not None
                       and net_at(recommended) is not None else None)
    margin_recommended = (_r((net_recommended / recommended) * 100, 1) if (recommended and net_recommended is not None)
                          else None)
    net_current = net_at(price) if (price and cost) else None
    notes: List[str] = []
    if not cost:
        notes.append("没有采购成本记录（面板成本 / 采集箱 cost 都为空）：保本价与 20% 目标价不给数字。")
    if not price:
        notes.append("没有售价：价格相关的推算全部留空。")
    if rate is None:
        notes.append("类目费率未匹配官方价目表：" + str(fee.get("note") or ""))
    if dc_fee is None:
        notes.append("履约费未定：" + str(dc.get("note") or ""))
    notes.append("VAT 不作为独立扣项：平台把买家支付的含税全额记给卖家，"
                 "VAT 只嵌在平台收费里（官方金额 x1.15 入账）。")
    fee_breakdown = [
        {"label": "成功费（{0}）".format(fee.get("ratePercent") or "类目未匹配"),
         "amount": fee.get("feeAmount"), "exVat": fee.get("feeExVat"),
         "vat": fee.get("vatOnFee"), "note": fee.get("note")},
        {"label": "履约费 DC（含 VAT）", "amount": dc_fee,
         "exVat": dc.get("fulfillmentFeeExVatZar"), "vat": dc.get("vatOnFeeZar"),
         "note": dc.get("note")},
    ]
    if cost:
        fee_breakdown.insert(0, {"label": "采购成本 (COGS)", "amount": _r(cost)})
    if freight:
        fee_breakdown.insert(1, {"label": "头程物流 (Inbound Freight)", "amount": _r(freight)})
    return {
        "cost": _r(cost) if cost else None,
        "costKnown": bool(cost),
        "freight": _r(freight) if freight else None,
        "supplyCost": supply_cost if cost else None,
        "category": fee.get("category") or category,
        "successRate": rate,
        "successRateSource": fee.get("rateSource"),
        "successFee": fee.get("feeAmount"),
        "successFeeExVat": fee.get("feeExVat"),
        "successFeeNote": fee.get("note"),
        "dcFee": dc_fee,
        "dcFeeExVat": dc.get("fulfillmentFeeExVatZar"),
        "dcTier": dc.get("tier"),
        "dcNote": dc.get("note"),
        "dcFeeCandidatesExVat": dc.get("feeCandidatesExVat"),
        "chargeableWeightKg": dc.get("chargeableWeightKg"),
        "volumeCm3": dc.get("volumeCm3"),
        "vatRate": VAT_RATE,
        "vatNote": "VAT 不作为独立扣项（嵌在平台收费里，官方金额 x1.15 入账）",
        "price": _r(price) if price else None,
        "priceBand": {"floor": floor, "recommended": recommended, "current": _r(price) if price else None},
        "netPerUnitAtRecommended": net_recommended,
        "netPerUnitAtCurrent": net_current,
        "marginAtRecommended": margin_recommended,
        "feeBreakdown": fee_breakdown,
        "notes": notes,
        "basis": ("官方费率表（data/" + FEE_DATA_FILE + "）：成功费 = 售价(含VAT) x 类目费率 x 1.15，"
                  "履约费 = 官方档位金额 x 1.15；成本/运费只认客户输入或本地采集记录。"),
    }


# --------------------------------------------------------------------------
# READ endpoints
# --------------------------------------------------------------------------

@router.get("/health")
def health() -> Dict[str, Any]:
    def build() -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "ok": True,
            "mode": "local",
            "keyConfigured": _key_configured(),
            "apiBase": API_BASE,
            "activeStore": _active_store().get("name", ""),
            "version": VERSION,
            "serverTime": _server_time(),
            "proxy": _live_proxy_url(),
            "crawlerLoaded": CRAWLER is not None,
            "diagnostics": "/api/plugins/takealot-erp/diagnostics",
        }
        if payload["keyConfigured"]:
            data, err = _api_request("GET", "/status")
            if err is None:
                payload["mode"] = "live"
                payload["seller"] = data if isinstance(data, dict) else {}
            else:
                payload["live_error"] = err
        return payload

    return _safe(build, _fallback({
        "ok": True, "mode": "local", "keyConfigured": False, "apiBase": API_BASE,
        "activeStore": "", "version": VERSION, "serverTime": "",
    }))


PERF_LIGHT_LIMIT_S = 3.0      # 轻请求超过这个秒数 = 事件循环/线程池被堵死（客户原始故障）
PERF_JOIN_WARM_S = 20.0        # 默认（用现有缓存）最多等重请求这么久
PERF_JOIN_COLD_S = 120.0       # ?perfHeavy=1 强制冷缓存重建：等得更久，拿到完整实测数字


def _perf_probe(store_id: Any = None, samples: int = 5, force_cold: bool = False) -> Dict[str, Any]:
    """性能与事件循环自检：一条线程跑重请求，同时量轻请求耗时。

    重请求 = 该店 /offers 全量 + 映射后的商品目录（真店 1300+ offer 时最重，
    ?perfHeavy=1 会强制冷缓存重建，就是 /products 的冷构建）；
    轻请求 = 直接调用内部处理函数 meta_fees()（不联网，纯看事件循环/线程池是否被堵）。
    轻请求 > PERF_LIGHT_LIMIT_S 判 fail；没有 Key 的机器降级为 info（安全跳过）。
    """
    import threading as _threading
    info = _effective_store(store_id)
    sid = str(info.get("storeId") or "")
    if not sid or not _key_configured(sid):
        return {"ok": True, "level": "info", "skipped": True,
                "detail": "跳过：店铺未绑定 Seller X-API-Key（没有可打的重请求）",
                "evidence": {"requires": "Seller Key", "storeId": sid, "storeName": info.get("storeName")},
                "hint": "绑定 Key 后会实测「重请求进行中轻请求的耗时」"}
    result: Dict[str, Any] = {}

    def heavy() -> None:
        started = time.time()
        try:
            _offer_rows(sid, force=bool(force_cold))
            if force_cold:
                _OFFERS_BY_STORE.pop(sid, None)
                _CATALOG_BY_STORE.pop(sid, None)
                _offer_rows(sid, force=True)
            _catalog_items(store_id=sid)
            result["heavyError"] = None
        except Exception as exc:  # pragma: no cover - defensive
            result["heavyError"] = _sanitize(exc)
        result["heavySeconds"] = round(time.time() - started, 2)

    worker = _threading.Thread(target=heavy, name="tk-perf-probe", daemon=True)
    worker.start()
    light: List[float] = []
    for _ in range(max(1, min(int(samples or 5), 60))):
        t0 = time.time()
        try:
            meta_fees()
        except Exception:  # pragma: no cover - defensive
            pass
        light.append(round(time.time() - t0, 4))
        if not worker.is_alive():
            break
    worker.join(timeout=(PERF_JOIN_COLD_S if force_cold else PERF_JOIN_WARM_S))
    worst = max(light) if light else None
    heavy_s = result.get("heavySeconds")
    ok = bool(worst is not None and worst <= PERF_LIGHT_LIMIT_S)
    detail = "重请求 {0}，其间轻请求 /health 路径(worst) {1}（{2} 次采样）".format(
        ("{0}s".format(heavy_s) if heavy_s is not None else "仍在进行（超过等待上限 {0}s）".format(
            PERF_JOIN_COLD_S if force_cold else PERF_JOIN_WARM_S)),
        ("{0}s".format(worst) if worst is not None else "n/a"),
        len(light))
    return {"ok": ok, "level": "pass" if ok else "fail", "skipped": False,
            "detail": detail,
            "evidence": {"heavySeconds": heavy_s, "lightSeconds": worst, "lightSamples": len(light),
                         "lightSamplesAll": light, "heavyFinished": not worker.is_alive(),
                         "heavyError": result.get("heavyError"), "forcedCold": bool(force_cold),
                         "limitSeconds": PERF_LIGHT_LIMIT_S,
                         "basis": ("同进程：线程跑 /products 的 /offers+目录构建（重请求），"
                                   "主线程调处理函数 meta_fees()（轻请求，不联网）")},
            "hint": "" if ok else ("轻请求超过 {0}s：事件循环/线程池被重请求堵死了"
                                   "（端点必须写成普通 def 走线程池，不能写成协程端点）").format(PERF_LIGHT_LIMIT_S)}


@router.get("/diagnostics")
def diagnostics(storeId: str = "", perfHeavy: bool = False) -> Dict[str, Any]:
    """环境自检：换机部署时先把"哪里不通"一次说清楚，附带可复制的报告文本。"""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store

    def build() -> Dict[str, Any]:
        import importlib.util as _ilu
        import os as _os
        import time as _time

        checks: List[Dict[str, Any]] = []

        def add(cid: str, label: str, ok: bool, detail: str = "", evidence: Any = None, hint: str = "",
                level: str = "fail") -> None:
            """``level`` = fail（阻断）/ warn（功能降级）/ info（正常但暂无数据）。"""
            real = bool(ok) or level in ("warn", "info")
            checks.append({"id": cid, "label": label, "ok": real, "level": level if not ok else "pass",
                           "detail": detail, "evidence": evidence, "hint": hint})

        # 1) 后端真的挂上了（能应答这个请求本身即证明），并报告版本 / API 基址
        add("backend", "后端插件已挂载", True, "version {0} · apiBase {1}".format(VERSION, API_BASE))

        # 2) xlsx 导出依赖：装了 openpyxl 才是"真 xlsx"，否则走内置 OOXML 写盘
        has_openpyxl = bool(_ilu.find_spec("openpyxl"))
        add("openpyxl", "Excel 导出依赖 openpyxl", has_openpyxl,
            "已安装：导出为真 .xlsx" if has_openpyxl else "未安装：导出改用内置 OOXML 写盘（仍可打开）",
            hint="" if has_openpyxl else "想用 openpyxl：在 hermes-agent 的 venv 里 pip install openpyxl",
            level="warn")

        # 3) state 目录可写（写一条探针文件再删）
        writable = False
        try:
            _ensure_state_dir()
            probe = STATE_DIR / ".diagnostics-probe"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink()
            writable = True
        except Exception as exc:  # pragma: no cover
            add("state_dir", "state 目录可写", False, str(exc), hint="检查目录权限 / 磁盘空间：{0}".format(STATE_DIR))
        if writable:
            add("state_dir", "state 目录可写", True, str(STATE_DIR))

        # 4) 出口代理配置（这台机器直连会被 Cloudflare 403，必须配可用出口）
        proxy = _live_proxy_url()
        add("proxy", "出口代理已配置", bool(proxy), proxy or "未配置（TAKEALOT_API_PROXY / stores.json 的 crawler.proxy 都为空）",
            hint="" if proxy else "在服务端设置环境变量 TAKEALOT_API_PROXY=http://host:port（或写入 stores.json 的 crawler.proxy），然后重启后端")

        # 5) 每个已绑定店的 Seller API 实测（原话错误，Key 打码）
        stores = _stores()
        rows = []
        for row in stores:
            sid = str(row.get("id") or "")
            name = str(row.get("name") or "")
            masked = _mask(row.get("_key") or "")
            if not (row.get("_key") or "").strip():
                rows.append({"storeId": sid, "storeName": name, "key": masked, "ok": False,
                             "detail": "未绑定 Seller Key", "evidence": None})
                continue
            started = time.time()
            data, err = _api_request("GET", "/status", store_id=sid)
            ms = int((time.time() - started) * 1000)
            rows.append({"storeId": sid, "storeName": name, "key": masked,
                         "ok": err is None, "ms": ms,
                         "detail": "Seller API v1 应答正常" if err is None else "调用失败",
                         "evidence": err, "seller": data if err is None else None})
        live_ok = [r for r in rows if r.get("ok")]
        add("seller", "Seller API 可用（{0}/{1} 个店）".format(len(live_ok), len(rows)), bool(live_ok) and len(live_ok) == len(rows),
            "；".join("{0} {1}".format(r["storeName"] or r["storeId"], "OK" if r.get("ok") else "失败") for r in rows) or "未绑定任何店铺",
            evidence=[r for r in rows if not r.get("ok")] or None,
            hint="")

        # 6) 公开爬取通道实测（决定评论/销量推算能否工作）
        public = {"ok": False, "transport": None, "evidence": None}
        if CRAWLER is None:
            add("public", "公开爬取通道", False, "crawler.py 未能导入", evidence=CRAWLER_ERROR,
                hint="dashboard/crawler.py 缺失或语法错误：后端目录里应同时有 plugin_api.py 与 crawler.py")
        else:
            try:
                data, err, transport = CRAWLER.fetch_product(getattr(CRAWLER, "PUBLIC_PROBE_PLID", "PLID96730174"))
                public = {"ok": err is None and bool(data), "transport": transport, "evidence": err}
                add("public", "公开爬取通道", public["ok"],
                    "实测商品页通过 {0} 取回，transport={1}".format("代理" if transport == "proxy" else ("直连" if transport == "direct" else transport), transport)
                    if public["ok"] else "取不到公开商品页",
                    evidence=err,
                    hint="" if public["ok"] else "这条失败通常是出口问题（Cloudflare 403）× 也可能目标商品被下架：换一个 PLID 再试，仍失败就换出口")
            except Exception as exc:  # pragma: no cover
                add("public", "公开爬取通道", False, str(exc))
                public["evidence"] = str(exc)

        # 7) 密钥静态加密状态（磁盘上不该是明文）
        raw = _read_state_raw("stores.json", {}) or {}
        raw_rows = [r for r in (raw.get("stores") or []) if isinstance(r, dict) and (r.get("_key") or "").strip()]
        enc = [bool(str(r.get("_key") or "").startswith(_ENC_PREFIX)) for r in raw_rows]
        add("key_at_rest", "密钥已加密存储（磁盘）", all(enc) if enc else True,
            "{0}/{1} 个 Key 为密文（Windows DPAPI，仅当前账号可解）".format(sum(1 for x in enc if x), len(enc)) if enc else "未绑定 Key",
            hint="" if all(enc) or not enc else "存在明文 Key：重启一次后端会自动迁移为密文；若仍为明文说明 DPAPI 不可用（非 Windows 或缺 pywin32）")

        # 8) 两个半边是否都在位（后端在，不代表 UI 半边存在）
        # STATE_DIR = <HERMES_HOME>/plugins/takealot-erp/state → parents[2] IS <HERMES_HOME>
        ui_half = ""
        try:
            candidate = STATE_DIR.parents[2] / "desktop-plugins" / "takealot-erp" / "plugin.js"
            ui_half = str(candidate) if candidate.exists() else ""
        except Exception:
            ui_half = ""
        plugin_files = []
        pkg_root = STATE_DIR.parent
        for rel in ("dashboard/plugin_api.py", "dashboard/crawler.py", "dashboard/manifest.json", "plugin.yaml"):
            plugin_files.append((rel, (pkg_root / rel).exists()))
        add("halves", "插件两半都在位", bool(ui_half) and all(ok for _, ok in plugin_files),
            "UI: {0} · 后端: {1}".format(os.path.basename(ui_half) if ui_half else "缺失",
                                     ", ".join(k for k, ok in plugin_files if ok) or "缺失"),
            evidence=[k for k, ok in plugin_files if not ok] + ([] if ui_half else ["desktop-plugins/takealot-erp/plugin.js"]),
            hint="" if ui_half else r"UI 半边应放在 %LOCALAPPDATA%\hermes\desktop-plugins\takealot-erp\plugin.js（自动生效、存盘热重载）")

        # 9) 当前数据快照（让人一眼看出取数是否真的通）
        catalog_count = None
        try:
            info = _offers_cache(storeId or None)
            catalog_count = len(info.get("items") or [])
        except Exception:
            catalog_count = None
        if catalog_count:
            add("data", "当前店铺商品数（缓存）", True, "已缓存 {0} 个 offer".format(catalog_count))
        elif catalog_count == 0:
            add("data", "当前店铺商品数（缓存）", True, "缓存为空（首次打开商品管理会自动拉取；也可点「刷新」）",
                level="info")
        else:
            add("data", "当前店铺商品数（缓存）", False, "缓存不可用",
                hint="商品管理里点一次刷新；若刷新也失败，看上面的 Seller API / 出口检查项")

        # 10) 性能与事件循环：一条线程跑重请求，同时量轻请求耗时（> 3s 判 fail）
        perf = _perf_probe(storeId, force_cold=bool(perfHeavy))
        add("perf", "性能与事件循环", perf.get("ok"), perf.get("detail") or "",
            evidence=perf.get("evidence"), hint=perf.get("hint") or "",
            level=str(perf.get("level") or "warn"))

        passed = sum(1 for c in checks if c["level"] == "pass")
        warned = sum(1 for c in checks if c["level"] == "warn")
        failed = [c for c in checks if c["level"] == "fail"]
        infos = sum(1 for c in checks if c["level"] == "info")
        stamp = _server_time()
        line = {"pass": "PASS", "warn": "WARN", "info": "INFO", "fail": "FAIL"}
        lines = ["Takealot ERP 环境自检 · {0}".format(stamp),
                 "后端 {0} · 激活店 {1} · 出口 {2}".format(VERSION, (_active_store() or {}).get("name") or "—", proxy or "未配置"),
                 "结果：{0} 通过 · {1} 警告 · {2} 失败{3}".format(passed, warned, len(failed), "（{0} 项暂无数据）".format(infos) if infos else ""),
                 ""]
        for c in checks:
            lines.append("[{0}] {1} — {2}".format(line.get(c["level"], "INFO"), c["label"], c.get("detail") or ""))
            if c["level"] in ("fail", "warn") and c.get("evidence") is not None:
                lines.append("       证据：{0}".format(str(c["evidence"])[:400]))
            if c["level"] in ("fail", "warn") and c.get("hint"):
                lines.append("       建议：{0}".format(c["hint"]))
        lines.append("")
        lines.append("性能：{0}".format(perf.get("detail") or "未测"))
        if rows:
            lines.append("")
            lines.append("店铺：")
            for r in rows:
                lines.append("  - {0}（{1}）Key {2} · {3}{4}".format(
                    r.get("storeName") or r.get("storeId"), r.get("storeId"), r.get("key"),
                    "OK" if r.get("ok") else "失败", "" if r.get("ok") else " · " + str(r.get("evidence"))[:200]))

        # ── 交付自证四项（2026-09-20 交付日新增）─────────────────────────────
        # 这几项是"客户机上可自证"的一部分：NL 能力/桥/CDP 都不该靠口头说明。
        try:
            pkg_tools = PACKAGE_DIR / "tools.py"
            if pkg_tools.is_file():
                tsrc = pkg_tools.read_text(encoding="utf-8", errors="replace")
                n_tools = tsrc.count("register_tool(") + tsrc.count("TOOLS = (")
                add("agent_tools", "Agent 工具面（自然语言可读 ERP）",
                    True, "tools.py 存在（约 {0} 处工具定义）".format(n_tools),
                    hint="对话里可读：总览/订单/库存/财务/履约/采集箱/上架草稿/市场行情/抓取单个商品")
            else:
                add("agent_tools", "Agent 工具面（自然语言可读 ERP）", False,
                    "缺少 tools.py：对话里无法直接读 ERP（只能用界面）",
                    hint="把交付包里的 plugins\\takealot-erp\\tools.py 放到插件目录并重启 App",
                    level="warn")
            init_py = PACKAGE_DIR / "__init__.py"
            isrc = init_py.read_text(encoding="utf-8", errors="replace") if init_py.is_file() else ""
            routed = "pre_llm_call" in isrc
            add("intent_router", "自然语言意图路由（不靠模型猜）", True if routed else False,
                "已注册 pre_llm_call 钩子 + 中文动词表" if routed else "未注册 pre_llm_call：意图靠模型自行判断",
                hint="" if routed else "把交付包里的 __init__.py/tools.py 放好后重启 App；审计见 state\\agent_intent_audit.jsonl",
                level="warn" if not routed else "fail")
        except Exception as exc:  # pragma: no cover - 诊断项自己不许把诊断搞挂
            add("agent_tools", "Agent 工具面自检", False, "检查异常：{0}".format(str(exc)[:120]), level="warn")

        # 本地桥（扩展的数据通道）：只探一次 127.0.0.1:18790，不通就是没启
        try:
            import socket as _sock
            probe = _sock.socket()
            probe.settimeout(1.5)
            bridge_up = probe.connect_ex(("127.0.0.1", 18790)) == 0
            probe.close()
            add("bridge", "本地桥 18790（扩展↔ERP）", bridge_up,
                "在监听" if bridge_up else "未监听",
                hint="" if bridge_up else "双击 plugins\\takealot-erp\\dashboard\\bridge\\start_bridge.bat 启桥（扩展的同步/采集要用它）",
                level="warn" if not bridge_up else "fail")
        except Exception as exc:
            add("bridge", "本地桥 18790（扩展↔ERP）", False, "探测失败：{0}".format(str(exc)[:80]), level="warn")

        # CDP：后端看不见浏览器，不许给假 OK —— 如实说"要在扩展里看"
        add("ext_cdp", "扩展 CDP 抓取（可选权限）", True,
            "需在浏览器扩展里授权后启用（后端无法代查）",
            hint="扩展详情页 → 权限 → 开启 CDP；未开启时抓取走 DOM/公开接口，结果里会标 transport",
            level="info")

        return {"ok": not failed, "storeId": storeId or "", "checkedAt": stamp,
                "version": VERSION, "proxy": proxy, "apiBase": API_BASE,
                "summary": {"total": len(checks), "passed": passed, "warned": warned,
                            "failed": len(failed), "info": infos},
                "checks": checks, "stores": rows, "public": public, "report": "\n".join(lines)}

    return _safe(build, _fallback({"ok": False, "summary": {"total": 0, "passed": 0, "failed": 0},
                                   "checks": [], "stores": [], "report": ""}))


@router.get("/meta/fees")
def meta_fees() -> Dict[str, Any]:
    """官方费率表原样返回（成功费按主类目->子类目、履约费按体积档x重量档x类目分组）。"""
    def build() -> Dict[str, Any]:
        ref = fee_reference()
        return {
            "vatRate": VAT_RATE,
            "vatRule": ("官方价目表金额为不含 VAT；平台每笔收费按含 VAT 入账（x1.15）。"
                        "VAT 不作为卖家的独立扣项。"),
            "successFeeBase": "sellingPriceIncludingVat",
            "categoryRates": {
                main: [{"sub": row.get("sub"), "rate": row.get("rate"),
                        "ratePercent": "{0:.1f}%".format(float(row.get("rate") or 0) * 100),
                        "condition": row.get("condition")}
                       for row in rows]
                for main, rows in _official_success_rules().items()
            },
            "fulfilmentFees": ref.get("fulfilmentFees"),
            "storageFees": ref.get("storageFees"),
            "autoIbtPenaltyFees": ref.get("autoIbtPenaltyFees"),
            "otherFees": ref.get("otherFees"),
            "minSuccessFee": {"amount": MIN_SUCCESS_FEE, "official": False, "note": MIN_SUCCESS_FEE_NOTE},
            "meta": fee_reference_meta(),
            "source": "data/" + FEE_DATA_FILE,
        }
    return _safe(build, _fallback({"vatRate": VAT_RATE, "categoryRates": {}, "meta": {},
                                   "source": "data/" + FEE_DATA_FILE,
                                   "note": "官方费率数据文件读不到：" + FEE_DATA_FILE}))


@router.get("/meta/catalog")
def meta_catalog() -> Dict[str, Any]:
    """Departments → loadsheets → leaf counts (the 新建 Listing category picker)."""
    def build() -> Dict[str, Any]:
        departments = _catalog_departments()
        return {
            "departments": departments,
            "totalDepartments": len(departments),
            "totalNodes": len(_category_nodes()),
            "totalLoadsheets": len(_loadsheet_names()),
            "totalLeaves": sum(int(d.get("leafCount") or 0) for d in departments),
            "source": "data/takealot-categories.json",
            "note": "主类目 → 装载表 → 叶子类目；loadsheet 参数用 loadsheets[].id。",
        }

    return _safe(build, _fallback({"departments": [], "totalDepartments": 0, "totalNodes": 0}))


# --------------------------------------------------------------------------
# 类目中文翻译 + 磁盘缓存（用户 2026-09-20）
#
# 规则：
#   1) 首次遇到没翻过的类目名 → 后台线程调 LLM 翻 → 原子写 state/category_zh.json；
#      二次请求直接命中缓存，**不触发任何翻译**，也**不刷新**已有译文。
#   2) 没有 LLM Key 时宁可返回 nameZh=null 并说明原因，绝不自己编中文。
#   3) 写：临时文件 + os.replace，全程持锁；读：内存副本 + mtime 失效。
# --------------------------------------------------------------------------

ZH_CACHE_FILE = "category_zh.json"
ZH_BATCH_MAX = 40        # 提示词硬规则：一次最多 40 条
ZH_WANT_MAX = 200        # 一次预热/翻译请求最多处理多少条
ZH_HTTP_TIMEOUT = max(HTTP_TIMEOUT, 60)
ZH_NO_KEY_REASON = "未配置 LLM Key，不编造译文"

_ZH_MEM: Dict[str, Any] = {"mtime": None, "entries": {}}
_ZH_MEM_LOCK = threading.Lock()
_ZH_WRITE_LOCK = threading.Lock()
_ZH_INFLIGHT: Dict[str, int] = {}     # 正在翻的英文原文（去重，避免重复打 LLM）
_ZH_INFLIGHT_LOCK = threading.Lock()


def _zh_cache_path() -> Path:
    return STATE_DIR / ZH_CACHE_FILE


def _zh_provider() -> str:
    """中译缓存/展示用的通道标识（跟着实际用的 provider 走，换模型缓存自动失效）。"""
    try:
        ch = _spec_llm_channel()
        if ch[0]:
            return "{0}:{1}".format(ch[3] or "llm", ch[2] or DEEPSEEK_MODEL)
    except Exception:
        pass
    return "deepseek:" + DEEPSEEK_MODEL


def _zh_load() -> Dict[str, str]:
    """读缓存：带内存副本 + mtime 失效 —— 磁盘没变就不重新解析整个 JSON。"""
    path = _zh_cache_path()
    try:
        mtime = path.stat().st_mtime_ns
    except OSError:
        mtime = None
    with _ZH_MEM_LOCK:
        if mtime is None:
            _ZH_MEM["mtime"] = None
            _ZH_MEM["entries"] = {}
            return {}
        if _ZH_MEM["mtime"] == mtime:
            return dict(_ZH_MEM["entries"])
    entries: Dict[str, str] = {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        if isinstance(raw, dict) and isinstance(raw.get("entries"), dict):
            for src, dst in raw["entries"].items():
                if str(src).strip() and str(dst).strip():
                    entries[str(src)] = str(dst)
    except (OSError, ValueError):
        entries = {}
    with _ZH_MEM_LOCK:
        _ZH_MEM["mtime"] = mtime
        _ZH_MEM["entries"] = entries
        return dict(entries)


def _zh_read_disk() -> Dict[str, str]:
    """绕过内存副本直接读磁盘（合并前用，避免把并发写入的增量覆盖掉）。"""
    path = _zh_cache_path()
    try:
        with open(path, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
    except (OSError, ValueError):
        return {}
    if not isinstance(raw, dict) or not isinstance(raw.get("entries"), dict):
        return {}
    return {str(k): str(v) for k, v in raw["entries"].items()
            if str(k).strip() and str(v).strip()}


def _zh_merge(pairs: Dict[str, str]) -> Dict[str, str]:
    """把新译文并进缓存并原子落盘。缓存只增不改：已有译文永不覆盖。"""
    clean = {str(k): str(v) for k, v in (pairs or {}).items()
             if str(k).strip() and str(v).strip()}
    if not clean:
        return _zh_load()
    _ensure_state_dir()
    path = _zh_cache_path()
    with _ZH_WRITE_LOCK:
        base = _zh_read_disk() or _zh_load()
        for key, value in clean.items():
            if key not in base:
                base[key] = value          # 只补缺，不刷新
        payload = {
            "updatedAt": _iso_now(),
            "provider": _zh_provider(),
            "entries": base,
        }
        tmp = path.with_suffix(path.suffix + ".tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, indent=2)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, path)
        except OSError as exc:  # pragma: no cover - disk level failure
            log.warning("takealot-erp: cannot write zh cache: %s", exc)
        # 写完立刻让内存副本失效，下一次读一定回磁盘。
        with _ZH_MEM_LOCK:
            _ZH_MEM["mtime"] = None
            _ZH_MEM["entries"] = {}
    return _zh_load()


def _zh_llm_call(texts: List[str]) -> Dict[str, str]:
    """一次最多 ZH_BATCH_MAX 条的批量翻译。没有 Key / 调用失败 → {}（绝不编造）。"""
    key = _llm_key()
    _llm_b, _llm_m = _llm_base_model()
    batch = [str(t).strip() for t in (texts or []) if str(t or "").strip()][:ZH_BATCH_MAX]
    if not key or not batch:
        return {}
    prompt = (
        "You translate Takealot (South Africa) marketplace category names into "
        "Simplified Chinese for a seller's admin UI.\n"
        "Rules you MUST follow:\n"
        "- Only translate the category names. Keep brand names, model numbers, "
        "sizes, units and trade abbreviations exactly as written "
        "(Apple, iPhone, 4K, USB-C, 4Pcs, Anti-Glare ... stay as-is).\n"
        "- Never change, expand, reorder or drop the English input.\n"
        "- Output a JSON array of strings ONLY: same length, same order as the input.\n"
        "Input (JSON array): " + json.dumps(batch, ensure_ascii=False)
    )
    body = json.dumps({
        "model": _llm_m,
        "messages": [
            {"role": "system",
             "content": "You translate marketplace category names. Reply with JSON only."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.1,
        "max_tokens": 2000,
    }).encode("utf-8")
    req = urllib.request.Request(
        _llm_b + "/chat/completions",
        data=body,
        headers={
            "Authorization": "Bearer " + key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=ZH_HTTP_TIMEOUT) as resp:
            raw = resp.read().decode("utf-8", "replace")
        content = json.loads(raw)["choices"][0]["message"]["content"]
        match = re.search(r"\[[\s\S]*\]", content)
        parsed = json.loads(match.group(0) if match else content)
    except Exception as exc:
        log.warning("takealot-erp: zh translate call failed: %s", exc)
        return {}
    if not isinstance(parsed, list):
        return {}
    out: Dict[str, str] = {}
    for src, dst in zip(batch, parsed):
        if not isinstance(dst, str):
            continue
        text = dst.strip()
        # 只收真的中文译文：空串、原样回英文、没有汉字的，一律丢弃 ——
        # 宁可留 null（界面显示英文），也不把英文当译文写进缓存。
        if not text or text == src or not re.search(r"[\u4e00-\u9fff]", text):
            continue
        out[src] = text
    return out


def _zh_translate_texts(texts: List[str]) -> Dict[str, str]:
    """翻一批（跳过已缓存 / 已在翻的）→ 原子写缓存 → 返回本次新增的译文。"""
    entries = _zh_load()
    todo: List[str] = []
    for item in (texts or []):
        src = str(item or "").strip()
        if not src or src in entries or src in todo:
            continue
        todo.append(src)
    with _ZH_INFLIGHT_LOCK:
        started = [t for t in todo if t not in _ZH_INFLIGHT]
        for t in started:
            _ZH_INFLIGHT[t] = 1
    if not started:
        return {}
    added: Dict[str, str] = {}
    try:
        for i in range(0, len(started), ZH_BATCH_MAX):
            added.update(_zh_llm_call(started[i:i + ZH_BATCH_MAX]))
    finally:
        with _ZH_INFLIGHT_LOCK:
            for t in started:
                _ZH_INFLIGHT.pop(t, None)
    if added:
        _zh_merge(added)
    return added


def _zh_spawn(texts: List[str]) -> bool:
    """后台线程补翻译 —— 端点请求绝不因此阻塞。"""
    work = [str(t).strip() for t in (texts or []) if str(t or "").strip()]
    if not work:
        return False
    threading.Thread(target=_zh_translate_texts, args=(work,),
                     name="takealot-zh-translate", daemon=True).start()
    return True


def _zh_inflight_missing(texts: List[str]) -> List[str]:
    with _ZH_INFLIGHT_LOCK:
        return [t for t in texts if t not in _ZH_INFLIGHT]


def _zh_wanted_segments(items: List[Dict[str, Any]]) -> List[str]:
    """一页类目行里出现过的所有路径段（去重、保序）—— 每段单独翻，品牌名原样。"""
    wanted: List[str] = []
    for item in items or []:
        for seg in _split_path((item or {}).get("path")):
            if seg and seg not in wanted:
                wanted.append(seg)
    return wanted


def _zh_decorate(items: List[Dict[str, Any]]) -> Dict[str, Any]:
    """给一页类目行贴中文；缺的丢给后台线程翻。返回顶层 zh 摘要。"""
    wanted = _zh_wanted_segments(items)
    entries = _zh_load()
    missing = [t for t in wanted if t not in entries]
    keyed = bool(_llm_key())
    started = False
    if missing and keyed:
        pending = _zh_inflight_missing(missing)
        if pending:
            started = _zh_spawn(pending)
        reason = ("已启动后台翻译（{0} 条未命中）".format(len(missing))
                  if started else "翻译任务已在后台进行")
    elif missing:
        reason = ZH_NO_KEY_REASON
    else:
        reason = "全部命中缓存，未触发翻译"
    for item in items or []:
        segs = _split_path((item or {}).get("path"))
        leaf = str((item or {}).get("name") or (segs[-1] if segs else ""))
        item["nameZh"] = entries.get(leaf) or None
        # 路径里还没翻到的段保持英文原样 —— 宁可显示英文，也不编一个中文出来。
        item["pathZh"] = " -> ".join(entries.get(s, s) for s in segs) if segs else None
        item["zhMissing"] = [s for s in segs if s not in entries]
    return {
        "cached": len(wanted) - len(missing),
        "missing": len(missing),
        "translating": bool(started),
        "reason": reason,
        "provider": _zh_provider() if keyed else None,
        "batchMax": ZH_BATCH_MAX,
    }


@router.get("/meta/categories")
def meta_categories(q: str = "", limit: int = 20, department: str = "", loadsheet: str = "",
                    zh: int = 0) -> Dict[str, Any]:
    def build() -> Dict[str, Any]:
        leaves = _catalog_leaves(loadsheet, department)
        needle = (q or "").strip().lower()
        cap = max(1, min(int(limit or 20), 500))
        items = []
        matched = 0
        for leaf in leaves:
            path = str(leaf.get("path") or "")
            if needle and needle not in path.lower():
                continue
            matched += 1
            if len(items) < cap:
                items.append({
                    "path": path,
                    "name": leaf.get("name") or (path.split(" -> ")[-1].strip() if " -> " in path else path),
                    "nodeId": leaf.get("nodeId"),
                    "loadsheetId": leaf.get("loadsheetId") or "",
                    "loadsheetName": leaf.get("loadsheetName") or "",
                })
        # zh=1：命中缓存的直接贴中文；没命中的回 null + 摘要，后台线程补翻，
        # 本次请求不会被翻译阻塞（没有 LLM Key 时明确不翻，也不编）。
        zh_block = _zh_decorate(items) if int(zh or 0) else None
        # A needle with no hit returns EMPTY, never unrelated rows: the catalog
        # holds Takealot category names, so a product word ("earbuds") legitimately
        # misses and the UI must be able to say so.
        total = matched if needle else len(leaves)
        dept = _department_of(department) if department else None
        return {
            "total": total,
            "items": items,
            "department": dept.get("name") if dept else (department or ""),
            "departmentId": dept.get("id") if dept else "",
            "loadsheetId": str(loadsheet or ""),
            "loadsheetName": _loadsheet_names().get(str(loadsheet or ""), ""),
            "zh": zh_block,
        }

    return _safe(build, _fallback({"total": 0, "items": []}))


# ---------------------------------------------------------------------------
# 属性按类目（taxonomy_id）—— CONTRACT v9
#
# 官方把"必填"挂在**叶子类目**上（loadsheets[id].categories[taxonomyId].requirements），
# 不是挂在装载表上（fields[].isRequired 在我们数据里全为 false，不可用）。所以属性面板
# 必须拿到用户选中的 taxonomyId 才能说"哪些必填"。未收录的类目**绝不兜底**到别的模板。
# ---------------------------------------------------------------------------

ATTR_INGEST_FILE = "attributes_templates.json"


def _attribute_ingested() -> Dict[str, Any]:
    """扩展从商家后台抓到、经本地桥写进来的模板（ingested 覆盖 bundled）。"""
    data = _read_state(ATTR_INGEST_FILE, {})
    loadsheets = (data or {}).get("loadsheets") if isinstance(data, dict) else None
    return loadsheets if isinstance(loadsheets, dict) else {}


def _attribute_loadsheets_all() -> Dict[str, Any]:
    merged: Dict[str, Any] = dict(_attribute_loadsheets() or {})
    for lid, node in _attribute_ingested().items():
        if isinstance(node, dict) and isinstance(node.get("fields"), dict):
            merged[str(lid)] = node
    return merged


_ATTR_INDEX: Dict[str, Any] = {"sig": None, "index": {}}


def _attr_taxonomy_index() -> Dict[str, str]:
    """taxonomy_id → loadsheet_id 反查（真实数据自建；文件变了自动失效）。"""
    all_ls = _attribute_loadsheets_all()
    sig = "{0}|{1}".format(len(all_ls), os.path.getmtime(STATE_DIR / ATTR_INGEST_FILE)
                           if (STATE_DIR / ATTR_INGEST_FILE).exists() else 0)
    if _ATTR_INDEX["sig"] == sig and _ATTR_INDEX["index"]:
        return _ATTR_INDEX["index"]
    index: Dict[str, str] = {}
    for lid, node in all_ls.items():
        for tax in (node.get("categories") or {}):
            index.setdefault(str(tax), str(lid))
    _ATTR_INDEX.update({"sig": sig, "index": index})
    return index


# --------------------------------------------------------------------------
# 变体主题（Takealot 官方 Variant Theme）                          VARIANT-THEMES-PATCH-v1
#
# 用户 2026-09-20：变体逻辑是「先选主题 → 主题决定出现哪些属性列 → 每个变体行有
# 自己的 SKU / GS1 条码 / 图片 URL → 导出展开成 1 父行 + N 子行」。
#
# 数据诚实红线：主题 / 轴 / options **只来自 dashboard/data/takealot-attributes.json**：
#   * 轴列名 = 官方字段名。`Variant.attribute.*` 取自 loadsheets[id].variant_fields；
#     `color.*`（颜色轴）取自 loadsheets[id].categories[taxonomyId].requirements
#     以及同级的 requiresColour 标记（数据里颜色轴就是这两个来源，variant_fields 里没有它）。
#   * options 原样取该字段的官方候选（形状 [[label, code, sort], …]）。
#     该字段在数据里没有候选列表 → options=[] + reason，**绝不预置颜色/年龄段候选**。
#   * 取不到装载表数据 → 轴 resolved=false + reason，主题结构照列，字段与候选给空。
# --------------------------------------------------------------------------

VARIANT_CUSTOM_AXIS_MAX = 2

# 主题轴 → 官方候选字段名（按优先级逐个在该装载表里找真实存在的那个）。
VARIANT_AXIS_FIELD_IDS: Dict[str, List[str]] = {
    # 颜色轴：官方在类目 requirements 里挂 color.name / color.main / color.secondary，
    # 并用 requiresColour 标是否必填。这些字段不在 variant_fields 里（没有候选列表）。
    "colour": ["color.name", "color.main", "color.secondary"],
    # 尺寸轴：不同装载表的尺寸字段确实不同（鞋子=shoe_sizes、床=bed_size、
    # 服装=clothing_size_*、通用=product_size / size_in_cm.value），按「越通用越靠前」排。
    "size": [
        "Variant.attribute.product_size",
        "Variant.attribute.size_in_cm.value",
        "Variant.attribute.clothing_size_eu_uk",
        "Variant.attribute.clothing_size_symbol",
        "Variant.attribute.shoe_sizes",
        "Variant.attribute.bed_size",
        "Variant.attribute.helmet_size",
        "Variant.attribute.paper_size",
        "Variant.attribute.door_sizes",
        "Variant.attribute.pack_size",
    ],
    "packed_quantity": ["Variant.attribute.packed_quantity"],
    "kids_age": ["Variant.attribute.kids_age"],
}

VARIANT_AXIS_LABELS: Dict[str, str] = {
    "colour": "颜色 Colour",
    "size": "尺寸 Size",
    "packed_quantity": "包装数量 Packed Quantity for Variant",
    "kids_age": "年龄范围 Age Range for Children",
}

# 主题下拉（顺序与文案照参考图；"无变体（单品）" 是空 key）
VARIANT_THEMES: List[Dict[str, Any]] = [
    {"key": "", "label": "无变体（单品）", "axes": [], "needsCustomName": False},
    {"key": "colour", "label": "颜色 Colour", "axes": ["colour"], "needsCustomName": False},
    {"key": "size", "label": "尺寸 Size", "axes": ["size"], "needsCustomName": False},
    {"key": "colour_size", "label": "颜色 + 尺寸 Colour & Size",
     "axes": ["colour", "size"], "needsCustomName": False},
    {"key": "packed_qty", "label": "包装数量 Packed Quantity for Variant",
     "axes": ["packed_quantity"], "needsCustomName": False},
    {"key": "colour_packed_qty", "label": "颜色 + 包装数量 Packed Quantity for Variant and Colour",
     "axes": ["colour", "packed_quantity"], "needsCustomName": False},
    {"key": "age", "label": "儿童年龄范围 Age Range for Children",
     "axes": ["kids_age"], "needsCustomName": False},
    {"key": "colour_age", "label": "年龄范围 + 颜色 Age Range and Colour",
     "axes": ["colour", "kids_age"], "needsCustomName": False},
    {"key": "custom", "label": "自定义 Custom（自己填轴名）", "axes": [], "needsCustomName": True},
]

VARIANT_THEME_RULE = ("按 Takealot 官方逻辑：先选【变体主题】，主题决定下面出现哪些属性列"
                      "（颜色=受控下拉、包装数量=数字、年龄段=候选）。留空=无变体单品。"
                      "导出时自动展开成 1 父行 + N 变体子行。")


def _variant_theme_def(theme_key: Any) -> Optional[Dict[str, Any]]:
    key = str(theme_key or "").strip()
    return next((t for t in VARIANT_THEMES if str(t.get("key")) == key), None)


def _variant_input_type(field_type: Any, options: List[Dict[str, Any]]) -> str:
    ft = str(field_type or "")
    if options and ft in ("Dropdown", "MultiDropdown"):
        return "select"
    if ft in ("Integer", "Float"):
        return "number"
    return "text"


def _variant_requirement_fields(loadsheet_id: str) -> set:
    """该装载表**所有类目** requirements 里出现过的字段名（真实数据；做颜色轴等兜底证据）。"""
    cache_key = "__variant_req_fields__{0}".format(loadsheet_id)
    if cache_key in _DATA_CACHE:
        return _DATA_CACHE[cache_key]
    node = _attribute_loadsheets_all().get(str(loadsheet_id))
    found: set = set()
    if isinstance(node, dict):
        for entry in (node.get("categories") or {}).values():
            if isinstance(entry, dict):
                for fid in (entry.get("requirements") or []):
                    found.add(str(fid))
                if entry.get("requiresColour"):
                    found.add("color.name")
    _DATA_CACHE[cache_key] = found
    return found


def _variant_axis_def(axis_key: str, loadsheet_id: str, node: Any, entry: Any) -> Dict[str, Any]:
    """一个主题轴 → 官方数据里的真实列（列名 / 候选 / 类型 / 来源）。取不到就空 + reason。"""
    label = VARIANT_AXIS_LABELS.get(axis_key, axis_key)
    candidates = VARIANT_AXIS_FIELD_IDS.get(axis_key) or []
    base = {
        "key": axis_key, "label": label, "columnName": "", "fieldId": "",
        "displayName": "", "fieldType": "", "inputType": "text",
        "options": [], "optionCount": 0, "required": True,
        "requiredInCategory": None, "resolved": False, "source": "none", "reason": "",
    }
    if not isinstance(node, dict):
        base["reason"] = ("取不到装载表 {0} 的属性数据（takealot-attributes.json 里没有该装载表）"
                          "→ 列名与候选给空，不猜。").format(loadsheet_id or "（未选）")
        return base

    variant_fields = node.get("variant_fields") if isinstance(node.get("variant_fields"), dict) else {}
    req_ids = [str(x) for x in ((entry or {}).get("requirements") or [])] if isinstance(entry, dict) else []
    requires_colour = bool((entry or {}).get("requiresColour")) if isinstance(entry, dict) else False
    in_loadsheet_reqs = _variant_requirement_fields(loadsheet_id)

    for field_id in candidates:
        meta = variant_fields.get(field_id)
        if not isinstance(meta, dict) and field_id not in in_loadsheet_reqs:
            continue
        options = _attr_normalize_options(meta.get("options")) if isinstance(meta, dict) else []
        required_in_cat: Optional[bool] = None
        if entry is not None:
            required_in_cat = bool(field_id in req_ids or (axis_key == "colour" and requires_colour))
        if isinstance(meta, dict):
            source = "loadsheets.{0}.variant_fields['{1}']".format(loadsheet_id, field_id)
        else:
            source = "loadsheets.{0}.categories[].requirements['{1}']".format(loadsheet_id, field_id)
        if options:
            reason = ""
        elif isinstance(meta, dict) and str(meta.get("fieldType") or "") in ("Integer", "Float"):
            reason = ("官方字段 {0} 是 {1}（数值列），数据里没有候选下拉 → 数字输入。"
                      ).format(field_id, meta.get("fieldType"))
        elif isinstance(meta, dict):
            reason = ("官方字段 {0}（{1}）在数据里没有 options 候选 → 自由输入，不预置候选。"
                      ).format(field_id, (meta.get("fieldType") or "未标类型"))
        else:
            reason = ("官方数据里 {0} 只出现在类目的 requirements 里（装载表 variant_fields 中没有它，"
                      "也就没有候选列表）→ 自由输入，不预置候选。").format(field_id)
        return {
            "key": axis_key, "label": label, "columnName": field_id, "fieldId": field_id,
            "displayName": str((meta or {}).get("displayName") or ""),
            "fieldType": str((meta or {}).get("fieldType") or ""),
            "inputType": _variant_input_type((meta or {}).get("fieldType"), options),
            "options": options, "optionCount": len(options), "required": True,
            "requiredInCategory": required_in_cat, "resolved": True,
            "source": source, "reason": reason,
        }

    base["reason"] = ("装载表 {0} 的 variant_fields 与类目 requirements 里都没有「{1}」对应的官方字段"
                      "（候选：{2}）→ 不给列名与候选；请改用「自定义」主题手填轴名。"
                      ).format(loadsheet_id, label, ", ".join(candidates))
    return base


@router.get("/meta/variant-themes")
def meta_variant_themes(loadsheetId: str = "", taxonomyId: str = "") -> Dict[str, Any]:
    """变体主题下拉 + 每个轴的官方来源（列名 / 候选 / 是否必填）。全部来自真实数据。"""

    def build() -> Dict[str, Any]:
        tax = str(taxonomyId or "").strip()
        ls_id = str(loadsheetId or "").strip()
        if not ls_id and tax:
            ls_id = str(_attr_taxonomy_index().get(tax) or "")
        names = _loadsheet_names()
        all_ls = _attribute_loadsheets_all()
        node = all_ls.get(ls_id) if ls_id else None
        entry: Any = None
        if isinstance(node, dict) and tax:
            entry = (node.get("categories") or {}).get(tax)
        data_available = isinstance(node, dict)
        warnings: List[str] = []
        if not ls_id:
            warnings.append("未选装载表/末级类目：主题结构照列，但每个轴的官方列名与候选给空"
                            "（在左侧选一次末级类目即自动取到）。")
        elif not data_available:
            warnings.append("装载表 {0} 的属性数据不在 takealot-attributes.json 里"
                            "（数据包只覆盖 7 张表）→ 轴字段与候选给空，不猜。".format(ls_id))
        if tax and ls_id and data_available and not isinstance(entry, dict):
            warnings.append("类目 {0} 不在装载表 {1} 的类目清单里：轴仍按该装载表的官方字段解析，"
                            "但「该类目是否必填」无法判定。".format(tax, ls_id))

        themes: List[Dict[str, Any]] = []
        for preset in VARIANT_THEMES:
            axes = [_variant_axis_def(k, ls_id, node, entry) for k in preset.get("axes") or []]
            themes.append({
                "key": preset["key"],
                "label": preset["label"],
                "axes": axes,
                "needsCustomName": bool(preset.get("needsCustomName")),
                "axisCount": len(axes),
            })
        unresolved = [a for t in themes for a in t["axes"] if not a["resolved"]]
        return {
            "ok": True,
            "mode": "local",
            "loadsheetId": ls_id,
            "loadsheetName": names.get(ls_id, ""),
            "taxonomyId": tax or None,
            "taxonomyName": (entry or {}).get("name") if isinstance(entry, dict) else "",
            "taxonomyPath": _category_path_of(tax) if tax else None,
            "taxonomyMatched": bool(isinstance(entry, dict)),
            "dataAvailable": data_available,
            "themes": themes,
            "customAxisMax": VARIANT_CUSTOM_AXIS_MAX,
            "rule": VARIANT_THEME_RULE,
            "warnings": warnings,
            "unresolvedAxes": len(unresolved),
            "source": ("dashboard/data/takealot-attributes.json · loadsheets[{0}].variant_fields"
                       " + loadsheets[{1}].categories[{2}].requirements/requiresColour"
                       ).format(ls_id or "-", ls_id or "-", tax or "-"),
            "generatedAt": _iso_now(),
        }

    return _safe(build, _fallback({"ok": False, "themes": [], "warnings": [], "mode": "local"}))


# ── 变体模型（草稿里的形状）────────────────────────────────────────────────
# {theme, themeLabel, customName, customNames, axes:[{key,label,columnName,required}],
#  rows:[{values:{轴键:值}, sku, barcode, images:[url,…]}]}
# 空形状 = 无变体单品。

def _variant_row_normalize(raw: Any) -> Dict[str, Any]:
    raw = raw if isinstance(raw, dict) else {}
    values: Dict[str, str] = {}
    values_raw = raw.get("values")
    if isinstance(values_raw, dict):
        for key, value in values_raw.items():
            values[str(key)] = "" if value is None else str(value).strip()
    elif isinstance(values_raw, list):        # 旧形状：按轴顺序的数组
        for i, value in enumerate(values_raw):
            values[str(i)] = "" if value is None else str(value).strip()
    images_raw = raw.get("images")
    if isinstance(images_raw, str):
        images_raw = images_raw.split("\n")
    images: List[str] = []
    for url in (images_raw or []):
        text = str(url or "").strip()
        if text:
            images.append(text)
    return {
        "values": values,
        "sku": str(raw.get("sku") or "").strip(),
        "barcode": str(raw.get("barcode") or "").strip(),
        "images": images,
    }


def _variant_model_normalize(raw: Any) -> Dict[str, Any]:
    """变体模型归一（容错 + 老形状兼容）。只认上面那份键，多余的一律不落库。"""
    raw = raw if isinstance(raw, dict) else {}
    theme = str(raw.get("theme") or "").strip()
    preset = _variant_theme_def(theme)
    custom_names: List[str] = []
    if isinstance(raw.get("customNames"), list):
        custom_names = [str(n).strip() for n in raw["customNames"] if str(n or "").strip()]
    elif str(raw.get("customName") or "").strip():
        custom_names = [s.strip() for s in re.split(r"[+/&,]", str(raw["customName"])) if s.strip()]
    custom_names = custom_names[:VARIANT_CUSTOM_AXIS_MAX]

    axes: List[Dict[str, Any]] = []
    for axis in (raw.get("axes") or []):
        if not isinstance(axis, dict):
            continue
        key = str(axis.get("key") or "").strip()
        if not key:
            continue
        column = str(axis.get("columnName") or axis.get("fieldId") or key).strip()
        axes.append({
            "key": key,
            "label": str(axis.get("label") or key).strip(),
            "columnName": column or key,
            "required": axis.get("required") is not False,
        })
    if not axes and preset and preset.get("axes"):
        # 没带轴元数据（接口直填/老客户端）→ 用主题预设的轴键兜底（键=列名）
        axes = [{"key": k, "label": VARIANT_AXIS_LABELS.get(k, k), "columnName": k, "required": True}
                for k in preset["axes"]]
    if not axes and theme == "custom":
        axes = [{"key": n, "label": n, "columnName": n, "required": True} for n in custom_names]

    rows = [_variant_row_normalize(r) for r in (raw.get("rows") or []) if isinstance(r, dict)]
    rows = [r for r in rows if any(r["values"].values()) or r["images"] or r["sku"] or r["barcode"]]
    return {
        "theme": theme,
        "themeLabel": str(raw.get("themeLabel") or (preset or {}).get("label") or "").strip(),
        "customName": custom_names[0] if custom_names else "",
        "customNames": custom_names,
        "axes": axes,
        "rows": rows,
    }


def _variant_flags(inp: Dict[str, Any]) -> List[Dict[str, Any]]:
    """变体校验（选了主题但没有变体行 / 缺必填轴 / 同轴值重复 / 自定义没轴名 / 图片 URL 非法）。"""
    flags: List[Dict[str, Any]] = []

    def flag(code: str, field: str, message: str) -> None:
        flags.append({"code": code, "field": field, "level": "error", "message": message})

    axes = [a for a in (inp.get("variantAxes") or []) if isinstance(a, dict) and str(a.get("key") or "")]
    rows = [r for r in (inp.get("variantRows") or []) if isinstance(r, dict)]
    theme = str(inp.get("variantTheme") or "")
    filled = [r for r in rows if any(str(v or "").strip() for v in (r.get("values") or {}).values())]

    if theme == "custom" and not [n for n in (inp.get("variantCustomNames") or []) if str(n or "").strip()]:
        flag("VARIANT_CUSTOM_AXIS_NAME_MISSING", "Variant Theme",
             "变体主题选了「自定义 Custom」，但没有填轴名：自定义轴的列名就是轴名，必须给（最多 {0} 个）"
             .format(VARIANT_CUSTOM_AXIS_MAX))
    if axes and not filled:
        flag("VARIANT_THEME_WITHOUT_ROWS", "Variant Theme",
             "已选变体主题（{0}）但没有变体行：导出需要 1 父行 + N 子行，请至少加 1 个变体"
             .format(theme or inp.get("variantThemeLabel") or "已配置轴"))
    if filled and not axes:
        flag("VARIANT_ROWS_WITHOUT_AXES", "Variant Theme",
             "有 {0} 个变体行，但没有变体主题/轴：轴值无法落到装载表列，请先选变体主题".format(len(filled)))

    seen_values: Dict[str, int] = {}
    seen_sku: Dict[str, int] = {}
    for idx, row in enumerate(filled):
        values = row.get("values") or {}
        signature: List[str] = []
        for axis in axes:
            key = str(axis.get("key") or "")
            raw = str(values.get(key) or "").strip()
            signature.append(raw.lower())
            if not raw and axis.get("required") is not False:
                flag("VARIANT_AXIS_MISSING", "Variant " + str(axis.get("label") or key),
                     "变体 {0} 缺「{1}」值（轴列 {2}）".format(
                         idx + 1, axis.get("label") or key, axis.get("columnName") or key))
        key_sig = "|".join(signature)
        if key_sig and any(signature):
            if key_sig in seen_values:
                flag("VARIANT_ROW_DUPLICATE", "Variant Rows",
                     "变体 {0} 与变体 {1} 的轴值完全相同（{2}）：同一父 SKU 下不允许重复变体"
                     .format(idx + 1, seen_values[key_sig], " / ".join(signature)))
            else:
                seen_values[key_sig] = idx + 1
        sku = str(row.get("sku") or "").strip()
        if sku:
            if sku in seen_sku:
                flag("VARIANT_DUPLICATE_SKU", "Variant SKU",
                     "变体 {0} 与变体 {1} 用了同一个 SKU「{2}」".format(idx + 1, seen_sku[sku], sku))
            else:
                seen_sku[sku] = idx + 1
        for url in (row.get("images") or []):
            if not re.match(r"^https?://\S+$", str(url or ""), re.I):
                flag("VARIANT_IMAGE_URL_INVALID", "Variant Image",
                     "变体 {0} 的图片 URL 非法：{1}（每行一个公网 http(s) URL）"
                     .format(idx + 1, str(url)[:60]))
    return flags


def _category_path_of(taxonomy_id: Any) -> Optional[str]:
    """taxonomy id → 官方类目路径（nodes 里就是 [id, 'A -> B']）。"""
    try:
        wanted = int(str(taxonomy_id).strip())
    except (TypeError, ValueError):
        return None
    for node in _category_nodes():
        try:
            if int(node[0]) == wanted:
                return str(node[1])
        except (TypeError, ValueError, IndexError):
            continue
    return None


def _attr_normalize_options(raw: Any) -> List[Dict[str, Any]]:
    """官方 options 是 [[label, code, sort], …]；统一成 [{label, code}]，其它形状原样透传。"""
    out: List[Dict[str, Any]] = []
    for item in raw or []:
        if isinstance(item, (list, tuple)) and item:
            out.append({"label": str(item[0]), "code": str(item[1]) if len(item) > 1 else None})
        elif isinstance(item, dict):
            out.append({"label": str(item.get("label") or item.get("name") or ""),
                        "code": str(item.get("value") or item.get("code") or "")})
        else:
            out.append({"label": str(item), "code": None})
    return [o for o in out if o["label"]]


def _attr_item(node: Dict[str, Any], field_id: str, required: bool) -> Dict[str, Any]:
    fields = node.get("fields") or {}
    vfields = node.get("variant_fields") or {}
    units = node.get("template_defaults") or {}
    fld = fields.get(field_id) or vfields.get(field_id) or {}
    unit = units.get(field_id + ".unit")
    if not unit:
        for key in (field_id + ".unit", field_id.replace("Attribute.", "Attribute.") + ".unit"):
            if key in units:
                unit = units[key]
                break
    return {
        "fieldId": field_id,
        "displayName": fld.get("displayName") or field_id.split(".")[-1].replace("_", " ").title(),
        "fieldType": fld.get("fieldType"),
        "options": _attr_normalize_options(fld.get("options")),
        "description": fld.get("description"),
        "unit": unit,
        "required": bool(required),
        "isVariant": field_id.startswith("Variant."),
        "defined": bool(fld),
    }


def _attr_note_uncovered(ls_id: str, ls_name: str) -> str:
    return ("装载表 {0}{1} 的属性模板未收录（我们只有 7/36 个装载表的模板，数据包 _meta 自述\"全量36装载表待采集\"）。"
            "不做跨类目兜底：同步办法是在商家后台页面用扩展的「同步类目属性模板」抓一次"
            "（seller-api /v1/loadsheets/templates，需要页面登录会话），"
            "或 POST /meta/attributes/ingest 直接灌入。").format(
                ls_id, ("（" + ls_name + "）") if ls_name else "")


@router.post("/meta/categories/translate")
def meta_categories_translate(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """批量翻译类目名并写缓存（给 UI 预热用）。

    body 二选一：
      * {"texts": ["Computers", "Gaming PC", ...]}        显式给文本；
      * {"loadsheet": "106", "limit": 40, "q": "gaming"}  按类目树取一批。
    默认后台线程翻（不阻塞响应）；`wait: true` 时等翻完再返回（测试/命令行用）。
    没有 LLM Key → translating=false + reason，绝不返回编出来的中文。
    """
    payload = body or {}

    def build() -> Dict[str, Any]:
        texts: List[str] = []

        def push(value: Any) -> None:
            src = str(value or "").strip()
            if src and src not in texts:
                texts.append(src)

        raw = payload.get("texts")
        if isinstance(raw, list):
            for item in raw:
                push(item)
        elif isinstance(raw, str):
            push(raw)
        if not texts:
            loadsheet = str(payload.get("loadsheet") or "").strip()
            department = str(payload.get("department") or "").strip()
            needle = str(payload.get("q") or "").strip().lower()
            limit = max(1, min(int(payload.get("limit") or ZH_BATCH_MAX), ZH_WANT_MAX))
            for leaf in _catalog_leaves(loadsheet, department):
                path = str((leaf or {}).get("path") or "")
                if needle and needle not in path.lower():
                    continue
                for seg in _split_path(path):
                    push(seg)
                if len(texts) >= limit:
                    break
            texts = texts[:limit]

        cached_before = _zh_load()
        pending = [t for t in texts if t not in cached_before]
        keyed = bool(_llm_key())
        wait = bool(payload.get("wait"))
        added: Dict[str, str] = {}
        translating = False
        if pending and keyed:
            if wait:
                added = _zh_translate_texts(pending)
            else:
                translating = _zh_spawn(_zh_inflight_missing(pending) or pending)
        entries = _zh_load()
        if not pending or not keyed:
            reason = ZH_NO_KEY_REASON if not keyed else "全部命中缓存，未触发翻译"
        elif wait:
            reason = "已同步翻译 {0} 条".format(len(added))
        else:
            reason = "已启动后台翻译（{0} 条未命中）".format(len(pending))
        return {
            "ok": True,
            "requested": len(texts),
            "cached": len(texts) - len(pending),
            "missing": len(pending),
            "added": len(added),
            "translating": bool(translating),
            "wait": wait,
            "reason": reason,
            "provider": _zh_provider() if keyed else None,
            "batchMax": ZH_BATCH_MAX,
            "entries": {t: entries.get(t) for t in texts},
            "mode": "local",
        }

    return _safe(build, _fallback({
        "ok": False, "requested": 0, "cached": 0, "missing": 0, "added": 0,
        "translating": False, "entries": {}, "mode": "local",
    }))


LIVE_SALES_PAGE_LIMIT = 100


LIVE_SALES_MAX_ROWS = 1000


LIVE_SALES_MAX_PAGES = 12


INBOUND_MAX_ROWS = 400


INBOUND_MAX_PAGES = 8


def _fetch_live_sales(store_id: str, limit_rows: int = LIVE_SALES_MAX_ROWS) -> Tuple[List[Dict[str, Any]], Optional[str], bool]:
    """Page ``/sales`` (continuation_token) up to a bounded row cap. Returns (rows, error, truncated)."""
    rows: List[Dict[str, Any]] = []
    token: Optional[str] = None
    for _page in range(LIVE_SALES_MAX_PAGES):
        query: Dict[str, Any] = {"limit": LIVE_SALES_PAGE_LIMIT}
        if token:
            query["continuation_token"] = token
        data, err = _api_request("GET", "/sales", query, store_id=store_id, timeout=45.0)
        if err:
            return rows, err, False
        if not isinstance(data, dict):
            break
        batch = data.get("items") if isinstance(data.get("items"), list) else []
        for row in batch:
            if isinstance(row, dict):
                rows.append(row)
        token = data.get("continuation_token")
        if not token or not batch or len(rows) >= limit_rows:
            return rows, None, bool(token) and len(rows) >= limit_rows
    return rows, None, bool(token)


def _fetch_shipments(store_id: str, limit_rows: int = INBOUND_MAX_ROWS) -> Tuple[List[Dict[str, Any]], Optional[str], bool]:
    """Page ``/shipments`` (PO records) with a bounded row cap."""
    rows: List[Dict[str, Any]] = []
    token: Optional[str] = None
    for _page in range(INBOUND_MAX_PAGES):
        query: Dict[str, Any] = {"limit": 100}
        if token:
            query["continuation_token"] = token
        data, err = _api_request("GET", "/shipments", query, store_id=store_id, timeout=45.0)
        if err:
            return rows, err, False
        if not isinstance(data, dict):
            break
        batch = data.get("items") if isinstance(data.get("items"), list) else []
        for row in batch:
            if isinstance(row, dict):
                rows.append(row)
        token = data.get("continuation_token")
        if not token or not batch or len(rows) >= limit_rows:
            return rows, None, bool(token) and len(rows) >= limit_rows
    return rows, None, bool(token)


def _live_order_row(sale: Dict[str, Any], item: Optional[Dict[str, Any]], store_id: str, store_name: str) -> Dict[str, Any]:
    """One ``/sales`` line as the UI reads it, with our own fee expectation alongside."""
    price = _r(sale.get("selling_price") or 0)
    qty = int(sale.get("quantity") or 1)
    platform_fees = _r(sale.get("total_fees") or 0)
    success = _r(sale.get("success_fee") or 0)
    fulfillment = _r(sale.get("fulfillment_fee") or 0)
    courier = _r(sale.get("courier_collection_fee") or 0)
    transfer = _r(sale.get("stock_transfer_fee") or 0)
    expected = None
    rate_known = False
    rate_note = ""
    if item and price:
        try:
            # _commission reads the price off the offer dict, so hand it the SALE's price
            # (the catalogue item keeps its price under `price`, not under a nested `offer`).
            comm = _commission({"selling_price": price}, item)
            amount = comm.get("amount")
            expected = _r(amount) if amount is not None else None
            rate_known = amount is not None
            rate_note = "{0} · {1}".format(comm.get("ratePercent") or "未匹配",
                                           "类目已归到官方子类目" if rate_known else "类目未匹配官方价目表")
        except Exception:
            expected = None
    gross = _r(price * qty)
    return {
        "orderId": str(sale.get("order_id") or ""),
        "orderItemId": str(sale.get("order_item_id") or ""),
        "sku": str(sale.get("sku") or ""),
        "tsin": "TSIN{0}".format(sale.get("tsin_id")) if sale.get("tsin_id") else "",
        "offerId": sale.get("offer_id"),
        "title": (item or {}).get("title") or "",
        "quantity": qty,
        "sellingPrice": price,
        "gross": gross,
        "saleStatus": str(sale.get("sale_status") or ""),
        "orderDate": str(sale.get("order_date") or ""),
        "salesRegion": str(sale.get("sales_region") or ""),
        "stockSourceRegion": str(sale.get("stock_source_region") or ""),
        "platformFees": platform_fees,
        "successFee": success,
        "fulfillmentFee": fulfillment,
        "courierFee": courier,
        "stockTransferFee": transfer,
        "expectedSuccessFee": expected if rate_known else None,
        "feeVariance": _r(platform_fees - expected) if (expected is not None and rate_known) else None,
        "estimatedSuccessFee": _r(expected * qty) if expected is not None else None,
        "estimateBasis": ("{0} x 售价 x 数量 = 估算成功费（估算，非平台计费）".format(rate_note)
                          if expected is not None else ""),
        "feesBilled": bool(platform_fees or success or fulfillment or courier or transfer),
        "feeRateKnown": rate_known,
        "feeRateNote": rate_note,
        "net": _r(gross - (platform_fees if platform_fees else (expected or 0))),
        "storeId": store_id,
        "storeName": store_name,
    }


def _po_row(row: Dict[str, Any], sid: str, store_name: str) -> Dict[str, Any]:
    due = str(row.get("due_date") or "")
    days = None
    if due:
        try:
            days = (datetime.strptime(due, "%Y-%m-%d").date() - _now().date()).days
        except ValueError:
            days = None
    kind = str(row.get("shipment_type") or "").lower()
    label = {"customer_order": "客户订单送仓", "replenishment": "补货送仓", "mixed": "混合（客户订单+补货）"}.get(kind, kind or "—")
    branch = {"customer_order": "outbound", "replenishment": "inbound", "mixed": "mixed"}.get(kind, "other")
    ref = str(row.get("reference") or "")
    ref_region = ref_date = ""
    ref_seq = None
    mm = re.match(r"PO-(\d+)-(\d{2})/(\d{2})/(\d{4})-([A-Z]{3})-(\d+)", ref)
    if mm:
        ref_region = mm.group(5)
        ref_date = "{0}-{1}-{2}".format(mm.group(4), mm.group(3), mm.group(2))
        ref_seq = int(mm.group(6))
    state = str(row.get("purchase_order_state") or "")
    state_label = {
        "shipped": "已发运", "received_full_quantity": "已收全量", "received_partial_quantity": "部分收货",
        "cancelled": "已取消", "created": "待发运", "pending": "待发运", "in_transit": "在途",
    }.get(state.lower(), state or "—")
    return {
        "shipmentId": row.get("shipment_id"),
        "po": row.get("purchase_order_number"),
        "reference": row.get("reference") or "",
        "type": kind, "typeLabel": label,
        "state": state,
        "region": str(row.get("destination_region") or ""),
        "facilityId": row.get("destination_facility_id"),
        "dueDate": due, "daysToDue": days,
        "createdAt": str(row.get("created_at") or ""),
        "shipped": bool(row.get("shipped")),
        "cancelled": bool(row.get("cancelled")),
        "archived": bool(row.get("archived")),
        "storeId": sid, "storeName": store_name,
        "branch": branch, "refRegion": ref_region, "refDate": ref_date, "refSeq": ref_seq,
        "stateLabel": state_label,
        # 只有"未发运且未取消"才是真正要动作的 PO
        "actionable": (not bool(row.get("cancelled"))) and (not bool(row.get("shipped"))) and state.lower() not in ("cancelled", "received", "closed"),
    }


def _count_by(rows: List[Dict[str, Any]], pick) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for r in rows:
        key = str(pick(r) or "未标注")
        out[key] = out.get(key, 0) + 1
    return out


@router.get("/meta/attributes")
def meta_attributes(category: str = "", loadsheet: str = "", taxonomyId: str = "") -> Dict[str, Any]:
    """按类目给属性：必填 = 该 taxonomy 的官方 requirements；未收录显式说明，不兜底。"""

    def build() -> Dict[str, Any]:
        names = _loadsheet_names()
        all_ls = _attribute_loadsheets_all()
        wanted = (category or "").strip()
        tax = str(taxonomyId or "").strip()
        ls_id: Optional[str] = None

        # 1) 有 taxonomyId → 直接反查（最权威）
        if tax:
            ls_id = _attr_taxonomy_index().get(tax)
        # 2) 显式指定 loadsheet
        if ls_id is None and (loadsheet or "").strip():
            candidate = str(loadsheet).strip()
            if candidate in names or candidate in all_ls:
                ls_id = candidate
        # 3) 只有类目名 → 用旧路径解析（保持兼容），但仍然要求 taxonomyId 才能给必填
        if ls_id is None and wanted:
            low = wanted.lower()
            for ls_key, ls_name in names.items():
                if str(ls_name).lower() == low:
                    ls_id = str(ls_key)
                    break
            if ls_id is None:
                for ls_key, ls_name in names.items():
                    if low and (low in str(ls_name).lower() or str(ls_name).lower() in low):
                        ls_id = str(ls_key)
                        break
            if ls_id is None:
                for node in _category_nodes():
                    if low in str(node[1]).lower():
                        ls_id = _attr_taxonomy_index().get(str(node[0]))
                        if ls_id:
                            break

        if ls_id is None:
            return {
                "ok": True, "covered": False, "fields": [], "required": [], "optional": [],
                "loadsheetId": None, "loadsheetName": "", "taxonomyId": tax or None,
                "counts": {"required": 0, "optional": 0},
                "note": "无法从类目解析出装载表：请在「上架编排」里选定叶子类目（或其 taxonomyId）。",
                "source": "none",
            }

        node = all_ls.get(str(ls_id))
        ls_name = names.get(str(ls_id), "")
        if not isinstance(node, dict):
            return {"ok": True, "covered": False, "fields": [], "required": [], "optional": [],
                    "loadsheetId": ls_id, "loadsheetName": ls_name, "taxonomyId": tax or None,
                    "counts": {"required": 0, "optional": 0},
                    "note": _attr_note_uncovered(str(ls_id), str(ls_name)),
                    "source": "none", "syncable": True}

        cats = node.get("categories") or {}
        resolved_from = None
        # 只给了类目名/路径时：用官方 nodes（taxonomy id ↔ 路径）自动解析出 taxonomyId。
        # 这是真实映射（不是猜），但要在返回里标明来源，方便界面校对。
        if not tax and wanted and cats:
            low = wanted.lower()
            best = None
            for node_row in _category_nodes():
                try:
                    nid = int(node_row[0])
                except (TypeError, ValueError, IndexError):
                    continue
                path = str(node_row[1])
                if nid in {int(k) for k in cats.keys() if str(k).isdigit()} and low in path.lower():
                    # 越长的匹配越具体（'Play Swings' 优于 'Swings'）
                    if best is None or len(path) < len(best[1]):
                        best = (nid, path)
            if best is not None:
                tax = str(best[0])
                resolved_from = "path:" + best[1]
                ls_id = _attr_taxonomy_index().get(tax) or ls_id
                node = all_ls.get(str(ls_id)) or node
                cats = node.get("categories") or {}
        if not tax:
            return {"ok": True, "covered": True, "needsTaxonomy": True, "fields": [],
                    "required": [], "recommended": [], "optional": [],
                    "loadsheetId": ls_id, "loadsheetName": ls_name, "taxonomyId": None,
                    "counts": {"required": 0, "optional": 0},
                    "note": ("必填清单是按**叶子类目**给的（官方向 taxonomy_id 挂 requirements）——"
                             "请传入 taxonomyId 才能列出必填项；只给装载表是列不出必填的。"),
                    "source": "bundled" if str(ls_id) in (_attribute_loadsheets() or {}) else "ingested"}

        entry = cats.get(str(tax))
        if not isinstance(entry, dict):
            return {"ok": True, "covered": False, "fields": [], "required": [], "optional": [],
                    "loadsheetId": ls_id, "loadsheetName": ls_name, "taxonomyId": tax,
                    "counts": {"required": 0, "optional": 0},
                    "note": ("类目 {0} 不在装载表 {1} 的类目清单里：不猜属性（可能选错了类目或该表未收录该类目）。").format(tax, ls_id),
                    "source": "bundled" if str(ls_id) in (_attribute_loadsheets() or {}) else "ingested"}

        raw_reqs = [str(x) for x in (entry.get("requirements") or [])]
        req_ids = [x for x in raw_reqs if not x.startswith("Images.")]
        image_reqs = [x for x in raw_reqs if x.startswith("Images.")]
        rec_ids = [str(x) for x in (entry.get("recommendeds") or [])]
        rec_ids = [x for x in rec_ids if x not in set(req_ids) and not x.startswith("Images.")]
        all_fields = node.get("fields") or {}
        optional_ids = [k for k in all_fields if k not in set(req_ids) and k not in set(rec_ids)]
        required = [_attr_item(node, fid, True) for fid in req_ids]
        recommended = [dict(_attr_item(node, fid, False), recommended=True) for fid in rec_ids]
        optional = [_attr_item(node, fid, False) for fid in optional_ids]
        missing_defs = [i["fieldId"] for i in required if not i["defined"]]
        return {
            "ok": True,
            "covered": True,
            "needsTaxonomy": False,
            "loadsheetId": ls_id,
            "loadsheetName": ls_name,
            "taxonomyId": tax,
            "taxonomyName": entry.get("name"),
            "taxonomyPath": _category_path_of(tax),
            "taxonomyResolvedFrom": resolved_from,
            "required": required,
            # 官方把"建议"也给了（recommendeds）：单列出来，界面折叠在选填里但标"推荐"
            "recommended": recommended,
            "optional": optional,
            # 旧 UI 读 fields；保持向后兼容（必填在前）
            "fields": (required + recommended + optional)[:400],
            "imageRequired": image_reqs,
            # 官方给的类目级元信息（比"数一下 Images.* 有几张"更权威）
            "minimumImages": entry.get("minimumImages"),
            "requiresColour": entry.get("requiresColour"),
            "titleTemplateId": entry.get("title_template_id"),
            "counts": {"required": len(required), "recommended": len(recommended),
                       "optional": len(optional), "undefinedRequired": len(missing_defs)},
            "source": "ingested" if str(ls_id) not in (_attribute_loadsheets() or {}) else "bundled",
            "basis": ("必填清单 = loadsheets[{0}].categories[{1}].requirements（官方向叶子类目挂的必填），"
                      "不是装载表级 isRequired（数据里全为 false）").format(ls_id, tax),
            "note": None if not missing_defs else ("有 {0} 个必填字段在模板里没有定义（如 {1}）："
                                                   "界面要如实标注，不要给假控件。").format(len(missing_defs), missing_defs[:3]),
        }

    return _safe(build, _fallback({"ok": False, "covered": False, "fields": [], "required": [],
                                   "optional": [], "loadsheetId": None}))


@router.post("/meta/attributes/ingest")
def meta_attributes_ingest(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """接收扩展从商家后台抓到的模板（桥转发或直接调用），落 state/attributes_templates.json。"""
    payload = body or {}

    def build() -> Dict[str, Any]:
        incoming = payload.get("loadsheets") if isinstance(payload.get("loadsheets"), dict) else payload
        keep: Dict[str, Any] = {}
        if isinstance(incoming, dict):
            for lid, node in incoming.items():
                if isinstance(node, dict) and isinstance(node.get("fields"), dict):
                    keep[str(lid)] = node
        if not keep:
            return {"ok": False, "error": "没有可用的 loadsheets{id:{fields:{...}}}",
                    "accepted": 0, "mode": "local"}
        data = _read_state(ATTR_INGEST_FILE, {})
        data = data if isinstance(data, dict) else {}
        merged = dict(data.get("loadsheets") or {})
        before = len(merged)
        merged.update(keep)
        out = {
            "_meta": {
                "source": str(payload.get("source") or "extension"),
                "updatedAt": _iso_now(),
                "loadsheetsCovered": len(merged),
                "note": "由商家后台页面会话抓取（seller-api /v1/loadsheets/templates），非编造",
            },
            "loadsheets": merged,
        }
        _write_state(ATTR_INGEST_FILE, out)
        _ATTR_INDEX["sig"] = None  # 让反查索引立即失效
        return {"ok": True, "accepted": len(keep), "totalLoadsheets": len(merged),
                "added": sorted(set(merged) - set(data.get("loadsheets") or {})) if before else sorted(keep),
                "loadsheetIds": sorted(keep.keys())[:40], "mode": "local",
                "stateFile": str(STATE_DIR / ATTR_INGEST_FILE)}

    return _safe(build, _fallback({"ok": False, "accepted": 0, "mode": "local"}))



@router.get("/fulfilment")
def fulfilment(storeId: str = "", limit: int = 200, withStock: bool = False) -> Dict[str, Any]:
    """履约闭环：入仓（送仓单）→ 分仓库存 → 出库批次（客户订单 PO）→ 订单明细。"""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        sid = str(storeId or "").strip()
        if _explicit_all_stores(sid) and len(_stores()) > 1:
            return {"ok": False, "mode": "live",
                    "error": "履约闭环不支持汇总：每家的送仓单与订单是独立账号数据，请选定一家店铺",
                    "storeId": "", "stages": {}, "linkage": {}}
        if not sid:
            sid = str((_active_store() or {}).get("id") or "")
        row = _store_row(sid) or {}
        if not (row.get("_key") or "").strip():
            return {"ok": False, "mode": "local", "error": "店铺 {0} 未绑定 Seller Key：无法读取送仓单与订单".format(sid),
                    "storeId": sid, "stages": {}, "linkage": {}}
        store_name = str(row.get("name") or sid)

        ship_rows, ship_err, ship_trunc = _fetch_shipments(sid)
        pos = [_po_row(r, sid, store_name) for r in ship_rows]
        inbound_pos = [r for r in pos if r["branch"] in ("inbound", "mixed")]
        outbound_pos = [r for r in pos if r["branch"] in ("outbound", "mixed")]

        def _sum(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
            act = [r for r in rows if r["actionable"]]
            return {
                "total": len(rows), "actionable": len(act),
                "overdue": len([r for r in act if (r.get("daysToDue") is not None and r["daysToDue"] < 0)]),
                "dueSoon": len([r for r in act if (r.get("daysToDue") is not None and 0 <= r["daysToDue"] <= 7)]),
                "byRegion": _count_by(rows, lambda r: r.get("refRegion") or r.get("region") or "未标注"),
                "byState": _count_by(rows, lambda r: r.get("stateLabel") or "—"),
            }

        # 库存：卖家仓（Leadtime 直邮）vs Takealot DC（按区域）
        # 分页拉全量 /offers 在真店要 ~30 秒，界面请求等不起 —— 默认只用缓存，
        # 显式 withStock=1（界面的「补全库存」按钮）才允许真去抓。
        zero = lambda: {"available": 0, "receiving": 0, "onWay": 0, "sold30": 0}
        stock: Dict[str, Any] = {**zero(), "byRegion": [], "seller": zero(), "takealot": zero(),
                                 "offersWithInbound": 0, "regionCount": 0, "cached": False, "note": ""}
        stock_error = None
        items_by_sku: Dict[str, Dict[str, Any]] = {}
        cache_bucket = _offers_cache(sid)
        skip_stock = not (bool(withStock) or bool(cache_bucket.get("items")))
        if skip_stock:
            stock["note"] = ("库存未计算：本店商品列表缓存为空，而拉全量 /offers 需要约 30 秒（真店 1300+ 条）。"
                             "点「补全库存」抓一次，之后 60 秒内的查询都很快；先打开「商品管理」也会顺带把它变热。")
        try:
            if skip_stock:
                raise StopIteration
            ctx = _catalog_items(store_id=sid)
            for item in ctx.get("items") or []:
                items_by_sku[str(item.get("sku") or "")] = item
                touched = False
                for reg in ((item.get("stock") or {}).get("regions") or []):
                    wh = str(reg.get("warehouse") or "").lower()
                    region_name = str(reg.get("region") or "").strip()
                    bucket = "seller" if wh == "seller" else "takealot"
                    label = "卖家仓（Leadtime 直邮发货）" if bucket == "seller" else (region_name or "Takealot DC（未标区域）")
                    slot = None
                    for cand in stock["byRegion"]:
                        if cand["region"] == label:
                            slot = cand
                            break
                    if slot is None:
                        slot = {"region": label, "warehouse": bucket, **zero()}
                        stock["byRegion"].append(slot)
                    for key in ("available", "receiving", "onWay", "sold30"):
                        val = int(reg.get(key) or 0)
                        slot[key] += val
                        stock[key] += val
                        stock[bucket][key] += val
                    if int(reg.get("onWay") or 0) or int(reg.get("receiving") or 0):
                        touched = True
                if touched:
                    stock["offersWithInbound"] += 1
            stock["byRegion"].sort(key=lambda x: (-(x["available"] + x["onWay"]), x["region"]))
            stock["regionCount"] = len([r for r in stock["byRegion"] if r["warehouse"] == "takealot"])
            stock["cached"] = True
            stock["note"] = "库存来自该店 /offers 缓存（60 秒 TTL，或刚在商品管理看过）"
        except StopIteration:
            pass  # 缓存为空且未要求补全：保持 cached=false + note，绝不阻塞 PO/订单
        except Exception as exc:  # pragma: no cover
            stock_error = str(exc)

        # 订单（真实 /sales）
        sale_rows, sales_err, sales_trunc = _fetch_live_sales(sid)
        orders = [_live_order_row(sl, items_by_sku.get(str(sl.get("sku") or "")), sid, store_name) for sl in sale_rows]
        orders.sort(key=lambda r: str(r.get("orderDate") or ""), reverse=True)
        by_status: Dict[str, int] = {}
        by_region: Dict[str, int] = {}
        for o in orders:
            by_status[o["saleStatus"] or "未标注"] = by_status.get(o["saleStatus"] or "未标注", 0) + 1
            by_region[o["salesRegion"] or "未标注"] = by_region.get(o["salesRegion"] or "未标注", 0) + 1

        # 批次 ↔ 订单：按（区域+日期）近似对齐（/sales 没有 PO 字段）
        po_index: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
        for r in outbound_pos:
            key = (str(r.get("refRegion") or ""), str(r.get("refDate") or ""))
            po_index.setdefault(key, []).append(r)
        order_index: Dict[Tuple[str, str], Dict[str, Any]] = {}
        for o in orders:
            key = (str(o.get("salesRegion") or ""), str(o.get("orderDate") or "")[:10])
            slot = order_index.setdefault(key, {"orders": 0, "units": 0, "value": 0.0, "statuses": {}})
            slot["orders"] += 1
            slot["units"] += int(o.get("quantity") or 0)
            slot["value"] += float(o.get("net") or 0)
            slot["statuses"][o["saleStatus"]] = slot["statuses"].get(o["saleStatus"], 0) + 1
        matched, unmatched = [], []
        for key in sorted(set(list(po_index.keys()) + list(order_index.keys()))):
            region, day = key
            pos_here = po_index.get(key) or []
            ords = order_index.get(key)
            row_out = {
                "region": region, "date": day,
                "po": pos_here[0].get("po") if pos_here else None,
                "poCount": len(pos_here),
                "poTypes": sorted({r.get("typeLabel") for r in pos_here if r.get("typeLabel")}),
                "poState": pos_here[0].get("stateLabel") if pos_here else None,
                "poShipped": pos_here[0].get("shipped") if pos_here else None,
                "poDueDate": pos_here[0].get("dueDate") if pos_here else None,
                "orders": (ords or {}).get("orders", 0), "units": (ords or {}).get("units", 0),
                "netValue": _r((ords or {}).get("value", 0.0)),
                "statuses": (ords or {}).get("statuses", {}),
            }
            if pos_here and ords:
                row_out["link"] = "matched"
                matched.append(row_out)
            elif ords:
                row_out["link"] = "orders-only"
                row_out["note"] = "该日期/区域有订单，但送仓单列表里没有对应 PO（可能已归档，或尚未生成集货单）"
                unmatched.append(row_out)
            else:
                row_out["link"] = "po-only"
                row_out["note"] = "只有 PO 没有订单明细（该批次可能只含补货，或订单已超出 /sales 返回范围）"
                unmatched.append(row_out)
        return {
            "ok": True, "mode": "live", "storeId": sid, "storeName": store_name, "checkedAt": _iso_now(),
            "stages": {
                "inbound": {"summary": _sum(inbound_pos), "pos": inbound_pos[:60]},
                "stock": stock,
                "outbound": {"summary": _sum(outbound_pos), "pos": outbound_pos[:60]},
                "orders": {
                    "summary": {
                        "total": len(orders), "units": sum(int(o.get("quantity") or 0) for o in orders),
                        "gross": _r(sum(float(o.get("gross") or 0) for o in orders)),
                        "net": _r(sum(float(o.get("net") or 0) for o in orders)),
                        "byStatus": by_status, "byRegion": by_region,
                    },
                    "items": orders[: max(1, min(int(limit or 200), 400))],
                },
            },
            "linkage": {
                "basis": "区域 + 日期（近似对齐，非外键）",
                "matchedKeys": len(matched), "unmatchedKeys": len(unmatched),
                "matched": matched[:40], "unmatched": unmatched[:40],
                "note": ("/sales 的订单行里没有任何 PO 字段（实测 0/83），而 /shipments/{id} 详情不含行项，"
                         "所以批次与订单只能按「区域+日期」对齐：对上的可以按批次看货，对不上的会单独列出，"
                         "不要把它当成严格的批次归属。"),
            },
            "errors": {"shipments": ship_err, "sales": sales_err, "stock": stock_error},
            "partial": {"stockSkipped": skip_stock, "withStock": bool(withStock)},
            "truncated": {"shipments": ship_trunc, "sales": sales_trunc},
            "hint": ("入仓与出仓是同一套 /shipments：replenishment=补货入仓、customer_order=客户订单出库、"
                     "mixed=同一趟集货两者都有。预约送货时段（Booking Slot）没有 API，只能在 Seller Portal 操作；"
                     "PO 号、目的地区域、截止日、发运状态、收货状态都能读。"),
            "portal": "https://seller.takealot.com/",
        }
    return _safe(build, _fallback({"ok": False, "stages": {}, "linkage": {}}))


@router.get("/orders/live")
def orders_live(storeId: str = "", q: str = "", status: str = "", limit: int = 200) -> Dict[str, Any]:
    """真实订单（Seller API ``/sales``）：客户在 Seller Portal 上看到的那批。"""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        sid = str(storeId or "").strip()
        if _explicit_all_stores(sid) and len(_stores()) > 1:
            return {"ok": False, "mode": "live", "error": "实时订单不支持汇总：请选定一家店铺（每家的订单是独立账号数据）",
                    "items": [], "summary": {}, "storeId": ""}
        if not sid:
            sid = str((_active_store() or {}).get("id") or "")
        row = _store_row(sid) or {}
        if not (row.get("_key") or "").strip():
            return {"ok": False, "mode": "local", "error": "店铺 {0} 未绑定 Seller Key：无法读取实时订单".format(sid),
                    "items": [], "summary": {}, "storeId": sid}
        sales, err, truncated = _fetch_live_sales(sid)
        if err:
            return {"ok": False, "mode": "live", "error": err, "items": [], "summary": {}, "storeId": sid,
                    "storeName": row.get("name") or sid}
        ctx = _catalog_items(store_id=sid)
        by_sku = {str(i.get("sku") or ""): i for i in (ctx.get("items") or [])}
        store_name = str(row.get("name") or sid)
        rows = [_live_order_row(sale, by_sku.get(str(sale.get("sku") or "")), sid, store_name) for sale in sales]
        needle = (q or "").strip().lower()
        want_status = (status or "").strip().lower()
        if needle:
            rows = [r for r in rows if needle in " ".join([r["orderId"], r["sku"], r["title"], r["saleStatus"]]).lower()]
        if want_status:
            rows = [r for r in rows if want_status in r["saleStatus"].lower()]
        rows.sort(key=lambda r: r["orderDate"], reverse=True)
        try:
            cap = max(1, min(int(limit), 1000))
        except (TypeError, ValueError):
            cap = 200
        page = rows[:cap]
        by_status: Dict[str, int] = {}
        for r in rows:
            by_status[r["saleStatus"] or "未标注"] = by_status.get(r["saleStatus"] or "未标注", 0) + 1
        gross = _r(sum(r["gross"] for r in rows))
        fees = _r(sum(r["platformFees"] for r in rows))
        known_rows = [r for r in rows if r.get("feeRateKnown")]
        expected_total = _r(sum(r["expectedSuccessFee"] or 0 for r in known_rows))
        return {
            "ok": True, "mode": "live", "storeId": sid, "storeName": store_name,
            "currency": "ZAR", "fetched": len(sales), "total": len(rows), "count": len(page),
            "truncated": truncated,
            "summary": {
                "orders": len({r["orderId"] for r in rows}), "lines": len(rows),
                "units": sum(r["quantity"] for r in rows), "gross": gross,
                "platformFees": fees, "net": _r(gross - fees),
                "expectedSuccessFee": expected_total if known_rows else None,
                "feeVariance": _r(sum(r["feeVariance"] or 0 for r in known_rows)) if known_rows else None,
                "ratedLines": len(known_rows),
                "byStatus": by_status,
            },
            "items": page,
            "hint": ("实时订单来自 Seller API /sales（分页上限 {0} 行{1}）。平台费用字段为空说明该单尚未计费，"
                     "此时「我方核算费用」是按费用矩阵预估的，最终以 /transactions 流水为准。").format(
                LIVE_SALES_MAX_ROWS, "，已达上限（可能有更多）" if truncated else ""),
        }
    return _safe(build, _fallback({"ok": False, "mode": "live", "items": [], "summary": {}}))


def _financial_live_payload(sid: str) -> Dict[str, Any]:
    """The live reconciliation payload (shared by GET /financial/live and the exporter)."""
    row = _store_row(sid) or {}
    if not (row.get("_key") or "").strip():
        return {"ok": False, "mode": "local", "error": "店铺 {0} 未绑定 Seller Key".format(sid), "storeId": sid}
    balances_raw, bal_err = _api_request("GET", "/balances", None, store_id=sid)
    ledger_raw, tx_err = _api_request("GET", "/transactions", {"limit": 100}, store_id=sid, timeout=45.0)
    if tx_err is None and not ((ledger_raw or {}).get("items") if isinstance(ledger_raw, dict) else None):
        ledger_retry, retry_err = _api_request("GET", "/transactions", {"limit": 100}, store_id=sid, timeout=60.0)
        if not retry_err and isinstance(ledger_retry, dict) and (ledger_retry.get("items") or []):
            ledger_raw, tx_err = ledger_retry, None
        elif retry_err:
            tx_err = retry_err
    sales, sales_err, sales_truncated = _fetch_live_sales(sid)
    bal = (balances_raw or {}).get("balances") if isinstance(balances_raw, dict) else None
    bal = bal if isinstance(bal, dict) else {}
    tx_rows = [t for t in ((ledger_raw or {}).get("items") if isinstance(ledger_raw, dict) else []) or [] if isinstance(t, dict)]

    by_type: Dict[str, Dict[str, Any]] = {}
    credits = debits = 0.0
    for t in tx_rows:
        amount = _r(t.get("amount_incl_vat") or 0)
        kind = str(t.get("transaction_type") or "unknown")
        slot = by_type.setdefault(kind, {"type": kind, "count": 0, "amount": 0.0, "lastAt": ""})
        slot["count"] += 1
        slot["amount"] = _r(slot["amount"] + amount)
        stamp = str(t.get("created_at") or "")
        if stamp > slot["lastAt"]:
            slot["lastAt"] = stamp
        if amount >= 0:
            credits = _r(credits + amount)
        else:
            debits = _r(debits + abs(amount))

    ctx = _catalog_items(store_id=sid)
    by_sku = {str(i.get("sku") or ""): i for i in (ctx.get("items") or [])}
    order_expected = 0.0
    order_platform = 0.0
    rated = 0
    variance_rows = []
    for sale in sales:
        price = _r(sale.get("selling_price") or 0)
        platform = _r(sale.get("total_fees") or 0)
        item = by_sku.get(str(sale.get("sku") or ""))
        expected = None
        rate_known = False
        if item and price:
            try:
                comm = _commission({"selling_price": price}, item)
                expected = _r(comm.get("amount") or 0)
                rate_known = bool(str(comm.get("categoryPath") or "").strip())
            except Exception:
                expected = None
        order_platform = _r(order_platform + platform)
        if expected is not None and rate_known:
            rated += 1
            order_expected = _r(order_expected + expected)
            gap = _r(platform - expected)
            if abs(gap) >= 1.0:
                variance_rows.append({
                    "orderId": str(sale.get("order_id") or ""), "sku": str(sale.get("sku") or ""),
                    "sellingPrice": price, "platformFees": platform, "expected": expected, "variance": gap,
                    "note": "平台费用为 0 时多为尚未计费（结算滞后），以 /transactions 为准" if not platform else "",
                })
    variance_rows.sort(key=lambda r: -abs(r["variance"]))
    available = _r(bal.get("available") or 0)
    held = _r(bal.get("held_back") or 0)
    current = _r(bal.get("current") or 0)
    balance_ok = abs(_r(available + held) - current) < 0.02
    anomalies: List[Dict[str, Any]] = []
    if available < 0:
        anomalies.append({"kind": "负可用余额", "amount": available,
                          "detail": "可用余额为负：通常是订阅费/广告费先扣、或在途扣款；请核对 /transactions 中的 charge-* 记录。"})
    if not balance_ok:
        anomalies.append({"kind": "余额三件套不平", "amount": _r(current - (available + held)),
                          "detail": "current ≠ available + held_back，可能出现未入账的冻结/扣款。"})
    if order_platform == 0 and order_expected > 0:
        anomalies.append({"kind": "订单费用字段全为 0", "amount": order_expected,
                          "detail": "本店 {0} 行订单的 total_fees 都是 0，但按费用矩阵应约 R {1}：费用大概率滞后到流水里结算，别把 0 当免费。".format(len(sales), order_expected)})
    charges = [t for t in tx_rows if str(t.get("transaction_type") or "").startswith("charge-")]
    months = _live_months(tx_rows, sales)
    return {
        "ok": True, "mode": "live", "storeId": sid, "storeName": str(row.get("name") or sid),
        "currency": "ZAR", "checkedAt": _iso_now(),
        "balances": {"current": current, "available": available, "heldBack": held,
                     "consistent": balance_ok,
                     "note": "current = available + held_back（自检{0}）".format("通过" if balance_ok else "不通过")},
        "ledger": {"rows": len(tx_rows), "credits": credits, "debits": debits,
                   "net": _r(credits - debits), "byType": sorted(by_type.values(), key=lambda x: x["amount"]),
                   "charges": len(charges)},
        "ledgerRows": sorted(tx_rows, key=lambda t: str(t.get("created_at") or ""), reverse=True),
        "months": months,
        "monthsSource": "真实流水 /transactions 按月聚合（不再是按销售额缩放的演示数据）",
        "orders": {"rows": len(sales),
                   "gross": _r(sum(_r((sale.get("selling_price") or 0) * int(sale.get("quantity") or 1)) for sale in sales)),
                   "platformFees": order_platform,
                   "expectedSuccessFee": order_expected if rated else None,
                   "ratedLines": rated or None,
                   "variance": _r(order_platform - order_expected) if rated else None,
                   "truncated": sales_truncated,
                   "basis": "expectedSuccessFee 只统计「类目已知」的订单行；类目未知时不给数字（避免把 0 当成免费）"},
        "varianceRows": variance_rows[:50],
        "needsCategory": _ordered_skus_missing_category(sales, by_sku),
        "anomalies": anomalies,
        "errors": {"balances": bal_err, "transactions": tx_err, "sales": sales_err},
        "ledgerNote": (tx_err or ("流水为空：该账号在 /transactions 中没有记录（新账号常见），不代表没有费用——"
                                  "费用可能仍在结算中。" if not tx_rows else "")),
        "hint": ("实时对账读 /balances + /transactions + /sales：流水是平台真正扣/付的钱，订单费用字段可能滞后，"
                 "所以费用核对以流水为最终依据。"),
    }


@router.get("/financial/live")
def financial_live(storeId: str = "") -> Dict[str, Any]:
    """实时对账：余额三件套 + 交易流水分类 + 与订单侧费用的核对。"""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        sid = str(storeId or "").strip()
        if not sid:
            sid = str((_active_store() or {}).get("id") or "")
        return _financial_live_payload(sid)

    return _safe(build, _fallback({"ok": False, "mode": "live", "balances": {}, "ledger": {}, "orders": {}}))


def _ordered_skus_missing_category(sales: List[Dict[str, Any]], by_sku: Dict[str, Any]) -> Dict[str, Any]:
    """有订单、但本地抓取缓存里还没有类目的 SKU —— 定向补全它们，费用核对才能出数。

    整店 1321 个 SKU 全量抓取没必要：只有出过单的 SKU 才影响对账，先补这些。
    """
    missing: List[Dict[str, Any]] = []
    seen: set = set()
    for sale in sales:
        sku = str(sale.get("sku") or "")
        if not sku or sku in seen:
            continue
        seen.add(sku)
        item = by_sku.get(sku)
        if item is None:
            continue
        enrichment = item.get("enrichment") if isinstance(item.get("enrichment"), dict) else {}
        if str(enrichment.get("categoryPath") or "").strip():
            continue
        missing.append({"sku": sku, "title": item.get("title") or "", "tsin": item.get("tsin") or "",
                        "plid": item.get("plid") or "", "orders": 0})
    counts: Dict[str, int] = {}
    for sale in sales:
        sku = str(sale.get("sku") or "")
        if sku and any(m["sku"] == sku for m in missing):
            counts[sku] = counts.get(sku, 0) + 1
    for row in missing:
        row["orders"] = counts.get(row["sku"], 0)
    missing.sort(key=lambda r: (-r["orders"], r["sku"]))
    return {
        "count": len(missing),
        "skus": [r["sku"] for r in missing[:60]],
        "rows": missing[:60],
        "hint": ("这些 SKU 出过单但还没有类目数据，所以「我方核算费用」给不出数字。点下面按钮会用 /products/enrich "
                 "定向抓取（每次 ≤20 个，带时间预算），补完再刷新即可看到逐单差额。"),
        "enrichEndpoint": "/products/enrich",
        "enrichLimit": ENRICH_MAX,
    }


def _live_months(tx_rows: List[Dict[str, Any]], sales: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Group the REAL ledger + sales by calendar month (replaces the scaled-up fake months)."""
    buckets: Dict[str, Dict[str, Any]] = {}
    for t in tx_rows:
        month = str(t.get("created_at") or "")[:7]
        if not month:
            continue
        slot = buckets.setdefault(month, {"month": month, "credits": 0.0, "debits": 0.0, "txCount": 0,
                                          "byType": {}, "salesGross": 0.0, "salesRows": 0})
        amount = _r(t.get("amount_incl_vat") or 0)
        slot["txCount"] += 1
        if amount >= 0:
            slot["credits"] = _r(slot["credits"] + amount)
        else:
            slot["debits"] = _r(slot["debits"] + abs(amount))
        kind = str(t.get("transaction_type") or "unknown")
        slot["byType"][kind] = _r((slot["byType"].get(kind) or 0) + amount)
    for sale in sales:
        month = str(sale.get("order_date") or "")[:7]
        if not month:
            continue
        slot = buckets.setdefault(month, {"month": month, "credits": 0.0, "debits": 0.0, "txCount": 0,
                                          "byType": {}, "salesGross": 0.0, "salesRows": 0})
        slot["salesGross"] = _r(slot["salesGross"] + _r((sale.get("selling_price") or 0) * int(sale.get("quantity") or 1)))
        slot["salesRows"] += 1
    out = []
    for month in sorted(buckets, reverse=True):
        slot = buckets[month]
        slot["net"] = _r(slot["credits"] - slot["debits"])
        slot["byTypeTop"] = sorted(slot["byType"].items(), key=lambda kv: kv[1])[:4]
        out.append(slot)
    return out


@router.post("/financial/reconcile/export")
def financial_reconcile_export(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """导出对账工作簿（3 个工作表：汇总 / 逐单费用核对 / 交易流水）。"""
    payload = body or {}
    sid = str(payload.get("storeId") or "").strip()

    def build() -> Dict[str, Any]:
        if not sid:
            return {"ok": False, "error": "导出必须指明店铺（汇总视图下无法确定是哪一家）"}
        live = _financial_live_payload(sid)
        if not live.get("ok"):
            return {"ok": False, "error": live.get("error") or "实时数据不可用，无法导出", "path": "", "bytes": 0}
        store_name = live.get("storeName") or sid
        bal = live.get("balances") or {}
        lg = live.get("ledger") or {}
        od = live.get("orders") or {}
        stamp = _now().strftime("%Y-%m-%d %H:%M")
        summary_rows = [
            ["生成时间", stamp],
            ["店铺", "{0}（{1}）".format(store_name, sid)],
            ["当前余额 (current)", bal.get("current")],
            ["可用 (available)", bal.get("available")],
            ["冻结/待结 (held_back)", bal.get("heldBack")],
            ["余额自检", "通过（current = available + held_back）" if bal.get("consistent") else "不通过"],
            ["订单行数", od.get("rows")],
            ["订单销售额（含税）", od.get("gross")],
            ["平台已计费合计", od.get("platformFees")],
            ["我方核算成功费合计", od.get("expectedSuccessFee") if od.get("expectedSuccessFee") is not None else "类目未知，未核算"],
            ["费用差额", od.get("variance") if od.get("variance") is not None else "—"],
            ["流水笔数", lg.get("rows")],
            ["流水贷方合计", lg.get("credits")],
            ["流水借方合计", lg.get("debits")],
            ["流水净额", lg.get("net")],
        ]
        variance_rows = [
            [r.get("orderId"), r.get("sku"), r.get("sellingPrice"), r.get("platformFees"),
             r.get("expected"), r.get("variance"), r.get("note") or ""]
            for r in (live.get("varianceRows") or [])
        ]
        ledger_rows = [
            [t.get("created_at"), t.get("transaction_type"), t.get("amount_incl_vat"), t.get("transaction_id")]
            for t in (live.get("ledgerRows") or [])
        ]
        months = live.get("months") or []
        month_rows = [[m.get("month"), m.get("salesRows"), m.get("salesGross"), m.get("credits"),
                       m.get("debits"), m.get("net"), m.get("txCount")] for m in months]
        anomalies = live.get("anomalies") or []
        anomaly_rows = [[a.get("kind"), a.get("amount"), a.get("detail")] for a in anomalies]
        target = str(payload.get("path") or "").strip()
        if target:
            out_path = Path(target)
            if not out_path.is_absolute():
                out_path = STATE_DIR / out_path
        else:
            out_path = EXPORT_DIR / "reconcile-{0}-{1}.xlsx".format(sid, _now().strftime("%Y%m%d-%H%M%S"))
        sheets = [
            {"name": "汇总", "headers": ["项目", "值"], "rows": summary_rows + [["", ""], ["异常项", ""]] + anomaly_rows},
            {"name": "月度汇总", "headers": ["月份", "订单行", "销售额", "贷方", "借方", "净额", "流水笔数"], "rows": month_rows},
            {"name": "逐单费用核对", "headers": ["订单号", "SKU", "售价", "平台费", "我方核算", "差额", "说明"], "rows": variance_rows},
            {"name": "交易流水", "headers": ["时间", "类型", "金额", "transaction_id"], "rows": ledger_rows},
        ]
        size = _write_xlsx_sheets(out_path, sheets)
        return {"ok": bool(size), "path": str(out_path), "bytes": size, "sheets": [sh["name"] for sh in sheets],
                "rows": {sh["name"]: len(sh["rows"]) for sh in sheets}, "storeId": sid, "storeName": store_name,
                "mode": "live", "generatedAt": _iso_now(),
                "hint": "用 Excel 打开即可：4 个工作表（汇总 / 月度汇总 / 逐单费用核对 / 交易流水）。"}

    return _safe(build, _fallback({"ok": False, "path": "", "bytes": 0}))


@router.get("/overview")
def overview(storeId: str = "") -> Dict[str, Any]:
    """经营总览 —— KPI/趋势/告警/候选全部来自真实取数。

    营收/净利/趋势 = 真实 /sales 逐行求和；余额 = 真实 /balances；
    目录与 BuyBox 候选 = 真实 /offers（+ 公开页抓取缓存）；对账差异只在财务缓存热时给数。
    """
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        # 顺手在后台把商品目录缓存热起来（不阻塞本次请求）
        _prewarm_offers(storeId)
        requested = str(storeId or "").strip()
        if _explicit_all_stores(requested) and len(_stores()) > 1:
            return {"ok": False, "mode": "scoped-required", "storeId": "", "storeName": "",
                    "error": "总览不支持跨店汇总：订单与余额都是各账号独立数据，请选定一家店铺",
                    "requires": "storeId", "kpis": {}, "trend": [], "alerts": [],
                    "recentOrders": [], "buybox": [], "feeBreakdown": [], "storeStats": [],
                    "stores": _public_store_list(), "basis": ORDER_BASIS}
        info = _effective_store(storeId)
        sid = str(info.get("storeId") or "")
        sales = _sales_rows(sid)
        rows = _order_rows(sid)
        offers = _offers_cache(sid)
        bal: Dict[str, Any] = {}
        bal_err: Optional[str] = None
        if sid and _key_configured(sid):
            raw_bal, bal_err = _api_request("GET", "/balances", None, store_id=sid)
            bal = ((raw_bal or {}).get("balances") if isinstance(raw_bal, dict) else None) or {}
        candidates = _candidates(sid)
        shipments = _shipments_rows(sid)
        rec = _reconcile(sid, allow_fetch=False)
        revenue = _r(sum(float(r.get("sellingPrice") or 0) for r in rows))
        fees = _r(sum(float(r.get("platformDeductions") or 0) for r in rows))
        net = _r(sum(float(r.get("netProfit") or 0) for r in rows))
        order_ids = {str(r.get("orderId")) for r in rows if r.get("orderId")}
        known_bb = [c for c in candidates if c.get("buyboxKnown")]
        kpis = {
            "liveProducts": len(offers.get("items") or []),
            "orders": len(order_ids),
            "orderRecords": len(rows),
            "shipmentRecords": (len(shipments.get("rows") or []) if shipments.get("error") is None else None),
            "availableBalance": _r(bal.get("available")) if bal else None,
            "revenue": revenue,
            "platformFees": fees,
            "netProfit": net,
            "marginPercent": _r(net / revenue * 100, 1) if revenue else None,
            "margin": _r(net / revenue * 100, 1) if revenue else None,
            "lossOrders": sum(1 for r in rows if r.get("isLoss")),
            "lossCount": sum(1 for r in rows if r.get("isLoss")),
            "buyboxHeld": sum(1 for c in candidates if c.get("hasBuybox") is True) if known_bb else None,
            "buyboxTotal": len(candidates),
            "buyboxKnown": len(known_bb),
            "avgOrderValue": _r(revenue / len(order_ids)) if order_ids else None,
            "unitsSold": sum(int(r.get("quantity") or 0) for r in rows),
            "awaitingShipment": sum(1 for r in rows if str(r.get("status") or "") == "Awaiting Shipment"),
            "feesChargedLines": sum(1 for r in rows if r.get("feesCharged")),
            "discrepancyTotal": rec.get("totalOverchargedZAR"),
            "discrepancyKnown": bool(rec.get("available")),
        }
        mode = "live" if (sid and _key_configured(sid) and not sales.get("error")) else "empty"
        if not _key_configured(sid):
            mode = "no-key"
        payload: Dict[str, Any] = {
            "ok": bool(sid) and sales.get("error") is None,
            "mode": mode,
            "empty": not rows,
            "requires": None if rows else (sales.get("requires") or "Seller Key"),
            "kpis": kpis,
            "trend": _trend(14, rows),
            "alerts": _alerts(rows, sid),
            "recentOrders": rows[:5],
            "buybox": candidates[:5],
            "feeBreakdown": _fee_breakdown(rows),
            "stores": [_public_store_list_row(s) for s in _stores()],
            "activeStoreId": _store_data().get("activeStoreId", ""),
            "storeId": sid or None,
            "storeName": info["storeName"],
            "storeScoped": bool(requested) and info["storeScoped"],
            "resolved": info.get("resolved"),
            "scoped": False,
            "basis": ORDER_BASIS,
            "source": {"orders": "/sales", "catalogue": "/offers", "balance": "/balances",
                       "alerts": "/sales + /offers + /shipments"},
            "errors": {"sales": sales.get("error"), "balances": bal_err, "offers": offers.get("error"),
                       "shipments": shipments.get("error")},
            "storeStats": [],
        }
        if not rows:
            payload["hint"] = (sales.get("error")
                               or "本店 /sales 返回 0 行（真实接口结果）：没有订单就没有趋势/营收。")
        else:
            payload["hint"] = ("趋势/营收/净利 = /sales 逐行求和（口径见 basis）；余额 = /balances 真实值；"
                               "BuyBox 竞品价与归属只在公开页抓过该商品时才有（先点「采集」）。")
        return payload

    return _safe(build, _fallback({
        "ok": False, "mode": "error", "kpis": {}, "trend": [], "alerts": [], "recentOrders": [],
        "buybox": [], "feeBreakdown": [], "stores": [], "storeStats": [],
    }))


@router.get("/orders")
def orders(status: str = "", q: str = "", storeId: str = "") -> Dict[str, Any]:
    """订单与净利 —— 真实 Seller API /sales（逐行）+ 本店目录 + 客户本地成本记录。"""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        requested = str(storeId or "").strip()
        if _explicit_all_stores(requested) and len(_stores()) > 1:
            return {"ok": False, "mode": "scoped-required", "items": [], "total": 0, "summary": {},
                    "error": "订单不支持跨店汇总：每家的订单是独立账号数据，请选定一家店铺",
                    "requires": "storeId", "basis": ORDER_BASIS}
        info = _effective_store(storeId)
        sid = str(info.get("storeId") or "")
        sales = _sales_rows(sid)
        rows = _order_rows(sid)
        needle = (q or "").strip().lower()
        # Accept both the canonical snake_case filter id the UI sends
        # (awaiting_shipment) and the human status label stored on the row
        # (Awaiting Shipment) — otherwise a filter silently returns nothing.
        wanted = _normalize_status(status)
        items = []
        for row in rows:
            if wanted and _normalize_status(row.get("status")) != wanted:
                continue
            if needle and needle not in " ".join(
                [str(row.get("orderId") or ""), str(row.get("sku") or ""), str(row.get("tsin") or ""),
                 str(row.get("title") or ""), str(row.get("category") or ""), str(row.get("saleStatus") or "")]
            ).lower():
                continue
            items.append(row)
        revenue = _r(sum(float(r.get("sellingPrice") or 0) for r in items))
        fees = _r(sum(float(r.get("platformDeductions") or 0) for r in items))
        net = _r(sum(float(r.get("netProfit") or 0) for r in items))
        order_ids = {str(r.get("orderId")) for r in items if r.get("orderId")}
        summary = {
            "revenue": revenue,
            "fees": fees,
            "net": net,
            "margin": _r(net / revenue * 100, 1) if revenue else None,
            "lossCount": sum(1 for r in items if r.get("isLoss")),
            "awaitingShipment": sum(1 for r in items if str(r.get("status") or "") == "Awaiting Shipment"),
            "orders": len(order_ids),
            "lines": len(items),
            "units": sum(int(r.get("quantity") or 0) for r in items),
            "avgOrderValue": _r(revenue / len(order_ids)) if order_ids else None,
            "feesChargedLines": sum(1 for r in items if r.get("feesCharged")),
        }
        payload: Dict[str, Any] = {
            "ok": sales.get("error") is None,
            "mode": "live" if (sid and _key_configured(sid) and sales.get("error") is None) else (
                "no-key" if not _key_configured(sid) else "error"),
            "empty": not items,
            "requires": None if items else (sales.get("requires") or "Seller Key"),
            "total": len(items),
            "fetched": len(sales.get("rows") or []),
            "truncated": bool(sales.get("truncated")),
            "summary": summary,
            "items": items,
            "storeId": sid,
            "storeName": info["storeName"],
            "storeScoped": bool(requested) and info["storeScoped"],
            "basis": ORDER_BASIS,
            "source": "/sales（分页上限 {0} 行）".format(LIVE_SALES_MAX_ROWS),
        }
        if sales.get("error"):
            payload["error"] = sales.get("error")
            payload["hint"] = sales.get("error")
        elif not items:
            payload["hint"] = ("本店 /sales 返回 {0} 行，按当前筛选条件没有命中（真实结果，不做兜底数据）。"
                               .format(len(sales.get("rows") or [])))
        return payload

    return _safe(build, _fallback({
        "ok": False, "mode": "error", "total": 0,
        "summary": {"revenue": 0, "fees": 0, "net": 0, "margin": None, "lossCount": 0, "awaitingShipment": 0},
        "items": [],
    }))


@router.get("/orders/{order_id}")
def order_detail(order_id: str, storeId: str = "") -> Dict[str, Any]:
    """单张订单 —— 真实 /sales 行 + 本地成本记录（没有的就是 null + 原因）。"""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        info = _effective_store(storeId)
        detail = _order_detail(order_id, storeId)
        if detail is None:
            return {
                "ok": False, "empty": True, "found": False, "mode": "live",
                "orderId": order_id, "storeId": info["storeId"], "storeName": info["storeName"],
                "lines": [], "requires": "Seller Key / 与订单号匹配的店铺",
                "note": ("订单 {0} 不在该店 /sales 的返回范围里（订单只来自 Seller API，本地不存订单）。"
                         "常见原因：订单号属于另一家店，或超出分页上限 {1} 行。").format(
                             order_id, LIVE_SALES_MAX_ROWS),
            }
        detail.update({"ok": True, "found": True, "mode": "live",
                       "storeId": info["storeId"], "storeName": info["storeName"]})
        return detail

    return _safe(build, _fallback({
        "ok": False, "found": False, "lines": [], "note": "", "mode": "error",
    }))


@router.get("/financial")
def financial(q: str = "", storeId: str = "") -> Dict[str, Any]:
    """财务与对账 —— 真实 /balances + /transactions + /sales。

    月度汇总与结算单按真实流水月份聚合；API 给不出依据的数字一律 null + note。
    """
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        requested = str(storeId or "").strip()
        if _explicit_all_stores(requested) and len(_stores()) > 1:
            return {"ok": False, "mode": "scoped-required", "summary": {}, "months": [], "statements": [],
                    "reconcile": {}, "balances": {}, "ledger": {},
                    "error": "财务与对账不支持跨店汇总：余额与流水是各账号独立数据，请选定一家店铺",
                    "requires": "storeId"}
        info = _effective_store(storeId)
        sid = str(info.get("storeId") or "")
        live = _financial_live_cached(sid)
        if not live.get("ok"):
            return {
                "ok": False, "mode": "no-key", "empty": True,
                "storeId": sid, "storeName": info["storeName"],
                "requires": live.get("requires") or "Seller Key",
                "error": live.get("error") or "实时财务数据不可用",
                "summary": {"grossSales": None, "platformFees": None, "netPayout": None, "overcharged": None},
                "months": [], "statements": [], "balances": {}, "ledger": {},
                "reconcile": _reconcile(sid, allow_fetch=False),
                "hint": "绑定 Seller Key 后，这里会显示 /balances 余额、/transactions 流水与按月聚合。",
            }
        needle = (q or "").strip().lower()
        statements = _statements(sid)
        if needle:
            statements = [s for s in statements if needle in json.dumps(s, ensure_ascii=False).lower()]
        return {
            "ok": True, "mode": "live", "empty": False,
            "summary": _financial_summary(sid),
            "months": _months(sid),
            "monthsSource": "真实流水 /transactions 按月聚合（营收按 /sales 当月合计）",
            "statements": statements,
            "reconcile": _reconcile(sid),
            "balances": live.get("balances") or {},
            "ledger": live.get("ledger") or {},
            "ledgerRows": (live.get("ledgerRows") or [])[:200],
            "varianceRows": live.get("varianceRows") or [],
            "anomalies": live.get("anomalies") or [],
            "needsCategory": live.get("needsCategory") or {},
            "errors": live.get("errors") or {},
            "checkedAt": live.get("checkedAt"),
            "storeId": sid,
            "storeName": live.get("storeName") or info["storeName"],
            "storeScoped": bool(requested) and info["storeScoped"],
            "basis": ORDER_BASIS,
            "hint": ("余额/流水是 /balances + /transactions 原值；订单侧费用可能滞后，"
                     "最终以流水为准。平台不提供结算单号，结算单号是本地按月份生成的标签。"),
        }

    return _safe(build, _fallback({
        "ok": False, "mode": "error",
        "summary": {"grossSales": None, "platformFees": None, "netPayout": None, "overcharged": None},
        "months": [], "statements": [],
        "reconcile": {"totalAuditedRows": 0, "discrepancyCount": 0, "totalOverchargedZAR": None,
                      "status": "无法对账", "discrepancies": []},
    }))


@router.get("/collection")
def collection(storeId: str = "") -> Dict[str, Any]:
    # 「未分派」是**合法作用域**（未分派 ≠ 未知店铺），必须在店铺守卫之前解析；否则
    # scopeNote 里承诺的 storeId=unassigned 会被守卫当成未知店铺拒掉，那段处理未分派行的
    # 代码就成了永远走不到的死代码，界面里没有任何办法看到这些行。
    _unassigned_scope = _scope_store_id(storeId) in ("unassigned", "none", "__unassigned__")
    if not _unassigned_scope:
        _bad_store = _unresolved_store_error(storeId)
        if _bad_store:
            return _bad_store
    def build() -> Dict[str, Any]:
        items = _collection()
        index = _crawl_index()
        rows: List[Dict[str, Any]] = []
        for item in items:
            row = _collection_row(item)
            store = _item_store(item)
            row["assignedStoreId"] = str(store.get("id")) if store else None
            row["assignedStoreName"] = store.get("name") if store else None
            row["storeName"] = store.get("name") if store else None
            row["crawl"] = _item_crawl_summary(item, index)
            rows.append(row)

        scope = _scope_store_id(storeId)
        if _unassigned_scope:
            scoped_items = [i for i in items if not _item_store(i)]
            scoped_rows = [r for r in rows if not r.get("assignedStoreId")]
            scope_label = "unassigned"
        elif scope:
            # 没归属的行也要显示：它们本来就属于写入时的活跃店，只是还没分派。
            # 硬比较 assignedStoreId == scope 会把它们直接丢掉 —— 采集完的行于是在界面里
            # 凭空消失（agent 那条不带作用域的读法却看得见，两边说法就打架了）。
            # 同文件里的 _store_rows() 已经是这个约定（"rows that carry no store stay visible
            # so nothing disappears"），采集箱这里补齐，并用 unassignedIncluded 报出数量。
            scoped_items = [i for i in items
                            if str(i.get("assignedStoreId") or "") == scope or not i.get("assignedStoreId")]
            scoped_rows = [r for r in rows
                           if str(r.get("assignedStoreId") or "") == scope or not r.get("assignedStoreId")]
            scope_label = scope
        else:
            scoped_items, scoped_rows, scope_label = items, rows, None
        # 这三种读法都要给出未分派行数：只在店铺作用域里算，会让不带作用域的读法回 0，
        # 而同一次返回里的 stats.unassigned 又是真实值 —— 两个字段自相矛盾，agent 会照实
        # 报告"字段打架"，用户更糊涂。统一口径 = 本次返回的行里有多少行没有店铺归属。
        unassigned_included = sum(1 for r in scoped_rows if not r.get("assignedStoreId"))

        total_cost = _r(sum(_numeric([i.get("cost") for i in scoped_rows])))
        margins = _numeric([i.get("estMargin") for i in scoped_rows])
        stats = {
            "count": len(scoped_rows),
            "totalCost": total_cost,
            # 缺重量/尺寸或汇率的行算不出毛利率（estMargin 为 None）→ 聚合时跳过并报出有多少行
            # 算得出；以前直接 sum(margins)，一行 None 就让整个采集箱 500。
            "avgMargin": _r(sum(margins) / len(margins), 1) if margins else 0.0,
            "marginRows": len(margins),
            "pending": sum(1 for i in scoped_rows if i["status"] == "pending"),
            "ready": sum(1 for i in scoped_rows if i["status"] == "ready"),
            "promoted": sum(1 for i in scoped_rows if i["status"] == "promoted"),
            "estProfit": _r(sum(_numeric([i.get("estProfit") for i in scoped_rows]))),
            "unassigned": sum(1 for i in scoped_rows if not i.get("assignedStoreId")),
            "crawled": sum(1 for i in scoped_rows if _dig_crawl(i)),
        }
        info = _effective_store(storeId)
        return {
            "ok": True,
            "mode": "live",
            "empty": not scoped_rows,
            "note": ("采集箱为空：点「采集」把商品加进来（本版本不预置任何示例行）"
                     if not scoped_rows else None),
            "requires": None,
            "seededRowsRemoved": _SEED_STRIPPED.get("collection.json") or 0,
            "stats": stats,
            "storeStats": _store_stats(items, rows),
            "storeId": scope_label if scope_label else info["storeId"],
            "storeName": info["storeName"],
            "storeScoped": bool(scope_label) and not info["storeScoped"],
            "requestedStoreId": info["requestedStoreId"],
            "resolved": info.get("resolved"),
            "activeStoreId": _store_data().get("activeStoreId", ""),
            "stores": _public_store_list(),
            "conflicts": _collection_conflicts(items),
            "items": scoped_rows,
            # 上次「一键上架」的结果（落盘在 state/publish_last.json）：重开 App 也能回看
            "lastPublish": _read_state("publish_last.json", None),
            "unassignedIncluded": unassigned_included,
            "scopeNote": (None if not scope_label else
                          ("只显示未分派店铺的采集行（{0} 行）。".format(len(scoped_rows))
                           if _unassigned_scope else
                           "只显示店铺 {0} 的采集行：本店 {1} 行 + 未分派 {2} 行（未分派行也能看见，"
                           "要一次性看全部店铺请用 storeId=all）。".format(
                               scope_label, len(scoped_rows) - unassigned_included, unassigned_included))),
        }

    return _safe(build, _fallback({
        "mode": "error",
        "stats": {"count": 0, "totalCost": 0, "avgMargin": 0},
        "storeStats": [],
        "stores": [],
        "conflicts": [],
        "items": [],
    }))


def _draft_readiness(draft: Dict[str, Any]) -> Dict[str, Any]:
    """One draft → its loadsheet pre-flight result, compacted for a list row.

    Pure string work on the draft object, so the list can show readiness without
    validating every draft on every keystroke elsewhere in the UI.
    """
    draft = draft if isinstance(draft, dict) else {}
    try:
        inp = _loadsheet_input_from_draft(draft)
        errors: List[str] = []
        warnings: List[str] = []
        rows = build_loadsheet_rows(inp, IMAGE_COLUMN_COUNT) or []
        for row in rows:
            errors.extend(str(e) for e in (row.get("errors") or []))
            warnings.extend(str(w) for w in (row.get("warnings") or []))
        errors.extend(str(f.get("message")) for f in _strict_loadsheet_flags(inp))
    except Exception as exc:  # pragma: no cover - never break the list
        errors, warnings, rows = ["校验器异常：{0}".format(exc)], [], []
    missing: List[str] = []
    for field, label in (("title", "标题"), ("sellingPrice", "售价"), ("barcode", "条码"),
                         ("lowestCategory", "末级类目"), ("mainCategory", "主类目"),
                         ("description", "描述"), ("brand", "品牌")):
        value = draft.get(field)
        if value in (None, "", [], {}):
            missing.append(label)
    if not (draft.get("images") or draft.get("imageUrls")):
        missing.append("主图")
    return {
        "ok": not errors,
        "errors": errors[:12],
        "warnings": warnings[:12],
        "missing": missing,
        "errorCount": len(errors),
        "warningCount": len(warnings),
        "rowCount": len(rows),
        "label": "就绪" if not errors else "缺 {0} 项".format(len(errors)),
        "basis": "与 POST /listings/validate 同一套官方规则（含 portal 阻断项）",
    }


@router.get("/listings/drafts")
def listings_drafts(storeId: str = "") -> Dict[str, Any]:
    """上架草稿 —— 按店铺过滤（草稿行带 storeId，未标注的保留）。"""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        items, scope = _store_rows(_drafts(), storeId)
        rows = []
        for item in items:
            row = dict(item)
            row["readiness"] = _draft_readiness(item)
            rows.append(row)
        ready = sum(1 for r in rows if (r.get("readiness") or {}).get("ok"))
        return {"mode": "live", "empty": not rows, "items": rows,
                "storeId": scope["storeId"], "storeName": scope["storeName"],
                "storeScoped": not scope["scopedFromActive"], "filtered": scope["filtered"],
                "unassignedIncluded": scope.get("unassignedIncluded") or 0,
                "note": None if rows else "草稿箱为空：从采集箱转草稿或在「上架编排」里新建（不预置示例草稿）",
                "summary": {"drafts": len(rows), "ready": ready, "blocked": len(rows) - ready}}
    return _safe(build, _fallback({"mode": "error", "items": [], "filtered": False}))


#: /buybox 的筛选维度 —— 界面上的 pill 与此处的 key 一一对应，facets 给出各自计数。
BUYBOX_FILTERS = ("all", "actionable", "raise", "lost", "held", "floor", "nodata", "noCompetitor", "auto")
_BUYBOX_SORTS = ("gap", "myPriceDesc", "myPriceAsc", "title")
#: 一次「补竞品数据」最多抓几条：公开页抓取有流量预算，宁可按筛选结果分几轮也不一次打满。
BUYBOX_ENRICH_MAX = 40


def _buybox_match(row: Dict[str, Any], terms: List[str]) -> bool:
    """空格分词 = AND；每词在 SKU / TSIN / PLID / 条码 / 标题里找（不区分大小写）。"""
    if not terms:
        return True
    hay = " ".join(str(row.get(k) or "") for k in ("sku", "tsin", "plid", "barcode", "title")).lower()
    return all(t in hay for t in terms)


def _buybox_filter(row: Dict[str, Any], only: str) -> bool:
    """筛选。没数据可跟价的行也要能单独看（operation 上它们最需要被抓一次）。"""
    action = str(row.get("action") or "")
    if only in ("", "all"):
        return True
    if only == "actionable":
        return action == "reprice" and bool(row.get("targetPrice"))
    if only == "raise":
        # 「有抬价空间」：持有 BuyBox + 比竞品低足够多 + 有上限可依（引擎已把不满足的拦成 hold）
        return action == "raise" and bool(row.get("targetPrice"))
    if only == "lost":
        return row.get("hasBuybox") is False
    if only == "held":
        return row.get("hasBuybox") is True
    if only == "floor":
        return action == "floor_guard"
    if only == "nodata":
        # 「没抓过」才是补数据能解决的；抓过但没竞品的行属于 noCompetitor，混进来会让操作员
        # 反复点「补竞品数据」而毫无变化。
        return not bool((row.get("crawl") or {}).get("cached"))
    if only == "noCompetitor":
        return action == "no_competitor"
    if only == "auto":
        return bool(row.get("autoReprice"))
    return True


def _buybox_sort(rows: List[Dict[str, Any]], sort: str) -> List[Dict[str, Any]]:
    key = sort if sort in _BUYBOX_SORTS else "gap"
    if key == "myPriceDesc":
        return sorted(rows, key=lambda r: -(r.get("myPrice") or 0))
    if key == "myPriceAsc":
        return sorted(rows, key=lambda r: r.get("myPrice") or 0)
    if key == "title":
        return sorted(rows, key=lambda r: str(r.get("title") or "").lower())
    # gap = 我的价 − 最低竞品价：越大越亏，排最前；没有竞品价的垫底（而不是当成 0 混进来）。
    return sorted(rows, key=lambda r: -(r.get("gap") if r.get("gap") is not None else -1e9))


def _buybox_facets(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    """每个筛选维度的行数，界面 pill 上直接显示（省一次往返，也避免「看着有其实没有」）。"""
    return {key: sum(1 for r in rows if _buybox_filter(r, key)) for key in BUYBOX_FILTERS}


@router.get("/buybox")
def buybox(storeId: str = "", limit: int = 50, q: str = "", only: str = "all",
           sort: str = "gap") -> Dict[str, Any]:
    """BuyBox 跟价 —— 候选来自本店真实 /offers（可售 + 有价格）。

    带搜索（SKU/TSIN/PLID/条码/标题，空格分词 = AND）、筛选与排序：候选一多，
    操作员在表里找不到那一条，就等于「不能对单个 listing 跟价」—— 搜索不是装饰。
    """
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        info = _effective_store(storeId)
        sid = str(info.get("storeId") or "")
        all_rows = _candidates(sid)
        _cat_ctx = _catalog_items(store_id=sid)      # memo 命中，只为了拿到新鲜度（含映射层）
        terms = [t for t in str(q or "").lower().split() if t]
        matched = [r for r in all_rows if _buybox_match(r, terms)]
        filtered = [r for r in matched if _buybox_filter(r, only)]
        ordered = _buybox_sort(filtered, sort)
        known = [c for c in all_rows if c.get("buyboxKnown")]
        try:
            cap = max(1, min(int(limit or 50), 500))
        except (TypeError, ValueError):
            cap = 50
        rows = ordered[:cap]
        return {
            "ok": True,
            "mode": "live" if _key_configured(sid) else "no-key",
            "empty": not all_rows,
            "requires": None if all_rows else "Seller Key",
            "held": sum(1 for c in all_rows if c.get("hasBuybox") is True) if known else None,
            "heldKnown": len(known),
            "total": len(all_rows),
            "matched": len(matched),
            "filtered": len(filtered),
            "shown": len(rows),
            "truncated": len(rows) < len(filtered),
            "query": str(q or ""),
            "only": only if only in BUYBOX_FILTERS else "all",
            "sort": sort if sort in _BUYBOX_SORTS else "gap",
            "facets": _buybox_facets(all_rows),
            "catalog": _catalog_freshness((_cat_ctx.get("offers") or {}), _cat_ctx),
            "candidates": rows,
            "rules": list(_rules_map().values()),
            "storeId": sid,
            "storeName": info["storeName"],
            "storeScoped": not info["storeScoped"],
            "basis": ("候选 = 本店 /offers 的可售且有价商品；竞品价/BuyBox 归属 = 公开页抓取缓存"
                      "（平台 /offers 不提供这两项）"),
            "hint": ("候选很多时只显示前 {0} 条（shown/total/filtered 已区分）："
                     "用搜索框按 SKU/TSIN/PLID/标题 直接定位那一条。"
                     "想在候选表里看到「最低竞品」和「持有/丢失」，先用「采集」抓一次公开页。").format(cap),
        }

    return _safe(build, _fallback({"ok": False, "mode": "error", "held": None, "total": 0,
                                   "candidates": [], "rules": []}))


# ---------------------------------------------------------------------------
# 跟价策略（CONTRACT v7）：按店的自动调价规则 + 基于实时数据的试算/执行
# ---------------------------------------------------------------------------
STRATEGY_DEFAULT: Dict[str, Any] = {
    "enabled": False,
    "mode": "undercut_percent",  # undercut_percent | undercut_fixed | match
    "value": 1.0,                # 百分比(%) 或 固定差额(ZAR)
    "floorPrice": None,          # 绝对底价（按店默认，可被单 SKU 规则覆盖）
    "floorMarginPercent": 8.0,   # 最低净利率保护（需成本价）
    "maxChangePercent": 10.0,    # 单次最大调整幅度
    "maxChangesPerRun": 10,      # 每次最多改几个
    "minIntervalMinutes": 30,    # 同 SKU 冷却
    "respectRRP": True,          # 不超过 RRP
    "maxCandidatesPerRun": 20,   # 单轮最多取证多少个商品（爬取预算）
    "crawlBudgetSeconds": 8.0,   # 公网取证时间预算
    "minDeltaPercent": 0.5,      # 小于此幅度不动（防抖）
    # 优势抬价：只在"确实持有 BuyBox + 有竞品参考 + 数据不陈旧"时抬一步（+3%）、不越过竞品与上限。
    # 默认关；抬价的步进/冷却/每日上限/陈旧阈值是写死的常量（RAISE_*），客户只碰这个开关。
    "raiseEnabled": False,
}


def _price_of(value: Any) -> Optional[float]:
    """Tolerant price parser for crawled/public values ('' / None / junk → None)."""
    if value is None or value == "":
        return None
    if isinstance(value, dict):
        value = value.get("amount") or value.get("price") or value.get("value")
    try:
        got = float(str(value).replace(",", "").replace("R", "").strip())
    except (TypeError, ValueError):
        return None
    return got if got > 0 else None


def _strategy_file() -> Dict[str, Any]:
    data = _read_state("pricing_strategy.json", None)
    if not isinstance(data, dict):
        data = {"byStore": {}}
    if not isinstance(data.get("byStore"), dict):
        data["byStore"] = {}
    return data


def _strategy_for(store_id: Any = "") -> Dict[str, Any]:
    """该店的策略（未保存过就是默认值，绝不跨店复用）。"""
    sid = str(store_id or "").strip()
    if not sid:
        sid = str((_active_store() or {}).get("id") or "")
    saved = (_strategy_file().get("byStore") or {}).get(sid) or {}
    out = dict(STRATEGY_DEFAULT)
    out.update({k: v for k, v in saved.items() if k in STRATEGY_DEFAULT})
    out["storeId"] = sid
    out["storeName"] = str((_store_row(sid) or {}).get("name") or sid)
    out["saved"] = bool(saved)
    return out


def _num(value: Any, default: float, lo: float, hi: float) -> float:
    try:
        got = float(value)
    except (TypeError, ValueError):
        return float(default)
    return max(lo, min(hi, got))


def _last_write_ms(sku: str, store_id: str = "", action: Optional[str] = None) -> int:
    """最后一次对该 SKU 的调价时间（审计为准），用于冷却判断。

    ``action`` 过滤（"raise" / "drop"）用于抬价：抬价要更长冷却（6h），跟降只要短冷却（30min），
    两者混在一起算，抬完一次就会把正常的跟降也一起冻住。
    """
    latest = 0
    for row in _read_state("offer_writes.json", []) or []:
        if not isinstance(row, dict) or str(row.get("sku") or "") != str(sku):
            continue
        if store_id and str(row.get("storeId") or "") and str(row.get("storeId")) != store_id:
            continue
        if action and str(row.get("action") or "drop") != action:
            continue
        stamp = str(row.get("at") or "")
        parsed = None
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
            try:
                parsed = datetime.strptime(stamp, fmt)
            except ValueError:
                parsed = None
            if parsed:
                break
        if parsed:
            latest = max(latest, int(parsed.timestamp() * 1000))
    return latest


def _raises_today(store_id: str = "") -> int:
    """今天（本机日期）该店已发生的抬价次数 —— 每店每日上限用。以调价审计为准，不另存计数。"""
    today = datetime.now().strftime("%Y-%m-%d")
    count = 0
    for row in _read_state("offer_writes.json", []) or []:
        if not isinstance(row, dict) or str(row.get("action") or "drop") != "raise":
            continue
        if store_id and str(row.get("storeId") or "") and str(row.get("storeId")) != store_id:
            continue
        if str(row.get("at") or "").startswith(today):
            count += 1
    return count


def _cost_map() -> Dict[str, float]:
    """标识（SKU / PLID / TSIN / 采集行 id）→ 采购成本，只认客户本地记录。

    Seller API 不提供采购成本，所以没有本地记录就是没有（不猜、不估比例）。
    来源：state/collection.json 的 cost 字段 + state/rules.json 里的成本字段。
    """
    out: Dict[str, float] = {}
    for row in _collection():
        try:
            value = float(row.get("cost") or 0)
        except (TypeError, ValueError):
            continue
        if value <= 0:
            continue
        for key in (row.get("sku"), row.get("tsin"), row.get("plid"), row.get("id"),
                    row.get("sourceUrl")):
            text = _plid_of(key) or str(key or "").strip()
            if text:
                out.setdefault(text, value)
    for sku, rule in _rules_map().items():
        if not isinstance(rule, dict):
            continue
        raw = rule.get("cost") or rule.get("supplyCost") or rule.get("landedCost")
        try:
            value = float(raw or 0)
        except (TypeError, ValueError):
            continue
        if value > 0:
            out[str(sku)] = value
    return out


# ── 优势抬价（raising）：只在"确实持有 BuyBox + 有竞品参考 + 数据不陈旧"时抬 ──────
# 逻辑照 buybox-repricing-model 的规格：
#   触发 hasBuybox is True 且 my_price ≤ 最低竞品 − 滞后阈值(默认 R2)
#   上界 min(最低竞品 − 0.01, ceilingPrice)  ← 越过对手就丢 BuyBox；ceiling 从此真正参与决策
#   步进 每轮最多 +3%（一步跳到顶会在竞品上下横跳，还会被平台当成价格操纵）
#   冷却/上限 同 SKU 6h + 每店每日次数上限（在调用方用调价审计判）
#   无竞品参考价（独家在售）不抬价：没有锚点，抬多少都是拍脑袋
#   数据陈旧不抬：拿几天前的竞品价抬价 = 拍脑袋
# 全部参数写死在模板里（客户只碰开关），所以这里给的是常量而不是一堆配置项。
RAISE_LAG = 2.00
RAISE_STEP_PERCENT = 3.0
RAISE_COOLDOWN_MINUTES = 360
RAISE_DAILY_CAP = 20
RAISE_MAX_AGE_DAYS = 3.0


def _raise_target(current: Optional[float], lowest: Optional[float], ceiling: Optional[float] = None,
                  has_buybox: Optional[bool] = None, age_days: Optional[float] = None,
                  rrp: Optional[float] = None) -> Dict[str, Any]:
    """算一步抬价目标 + 拦截原因。**单一公式**，供 `_bb_row()` 与 `_propose_price()` 共用。"""
    cur = float(current or 0)
    low = float(lowest or 0)
    if not (low > 0):
        return {"proposed": None, "blocked": True, "blockReason": "没有最低竞品价（独家在售 / 公开页无第三方报价）→ 没有锚点，不抬价"}
    if has_buybox is None:
        return {"proposed": None, "blocked": True, "blockReason": "BuyBox 归属未知（公开页没取到）→ 不抬价，避免把销量让出去"}
    if has_buybox is not True:
        return {"proposed": None, "blocked": True, "blockReason": "当前 BuyBox 不在我方手上 → 抬价等于让出销量，只跟降不抬"}
    if not (cur > 0):
        return {"proposed": None, "blocked": True, "blockReason": "没有现价，无法计算抬价空间"}
    try:
        age = None if age_days is None else float(age_days)
    except (TypeError, ValueError):
        age = None
    if age is not None and age > RAISE_MAX_AGE_DAYS:
        return {"proposed": None, "blocked": True,
                "blockReason": "竞品数据已 {0:.1f} 天未更新（超过 {1:.0f} 天）→ 先用「补竞品数据」抓一次再抬".format(age, RAISE_MAX_AGE_DAYS)}
    if cur > low:
        return {"proposed": None, "blocked": True, "blockReason": "现价高于最低竞品 → 属于跟价（降价）分支，不是抬价场景"}

    room = low - cur
    if room <= RAISE_LAG:
        return {"proposed": None, "blocked": True, "room": _r(room),
                "blockReason": "离最低竞品只差 R {0}（不足滞后阈值 R {1}）→ 不抬，避免贴着对手来回横跳".format(_r(room), RAISE_LAG)}

    upper = low - 0.01
    ceiling_used = None
    if ceiling and float(ceiling) > 0:
        ceiling_used = float(ceiling)
        upper = min(upper, ceiling_used)
    if rrp and float(rrp) > 0:
        upper = min(upper, float(rrp))
    if upper <= cur:
        return {"proposed": None, "blocked": True, "upper": _r(upper), "ceiling": _r(ceiling_used) if ceiling_used else None,
                "blockReason": ("已触上限 R {0}（{1}）→ 不再抬".format(_r(upper), "上限价 ceilingPrice" if ceiling_used and _r(upper) == _r(ceiling_used) else "最低竞品 − R0.01"))}

    step = max(0.01, cur * RAISE_STEP_PERCENT / 100.0)
    proposed = _r(min(upper, cur + step))
    if proposed <= cur:
        return {"proposed": None, "blocked": True, "upper": _r(upper),
                "blockReason": "本轮没有可抬空间（上限 R {0} 已贴近现价）".format(_r(upper))}
    bound_src = "上限价 R {0}".format(_r(ceiling_used)) if (ceiling_used and abs(upper - ceiling_used) < 1e-9) else "最低竞品 − R0.01"
    return {
        "proposed": proposed, "blocked": False, "action": "raise", "upper": _r(upper), "room": _r(room),
        "ceiling": _r(ceiling_used) if ceiling_used else None, "stepPercent": RAISE_STEP_PERCENT,
        "note": "持有 BuyBox 且比最低竞品（R {0}）低 R {1} → 抬 R {2}（{3}%），到 R {4}；本轮上界 R {5}（{6}）".format(
            _r(low), _r(room), _r(proposed - cur), RAISE_STEP_PERCENT, _r(proposed), _r(upper), bound_src),
        "basis": "raise: hasBuybox=True, lowest={0}, current={1}, upper={2}, step={3}%".format(
            _r(low), _r(cur), _r(upper), RAISE_STEP_PERCENT),
    }


def _buybox_held_from_card(product: Dict[str, Any], store_id: Any = None) -> Optional[bool]:
    """公开页解析结果 → 我方是否持有 BuyBox（``None`` = 页面没给归属信息）。

    爬虫把持有者放在 ``seller`` 块里（``seller.isBuyboxHolder=True`` + ``seller.id/name``），
    顶层 ``isBuyboxHolder`` 实测常常是 ``None`` —— 只读顶层会永远判"归属未知"，抬价就永远不触发。
    这里只认"持有者确实是我方"（sellerId 优先，退化为店名）；认不出就返回 ``None``，
    让调用方按"不抬"处理：宁可不动，也不把销量让出去。
    """
    seller = product.get("seller") if isinstance(product.get("seller"), dict) else {}
    if not seller or not seller.get("isBuyboxHolder"):
        return None
    ident = _own_identity(store_id)
    holder_id = seller.get("id")
    if ident.get("sellerId") is not None and holder_id is not None:
        try:
            return int(ident["sellerId"]) == int(holder_id)
        except (TypeError, ValueError):
            return None
    name = str(seller.get("name") or "").strip().lower()
    if name and ident.get("names"):
        return name in ident["names"]
    return None


def _propose_price(sku: str, current: float, lowest: Optional[float], buybox: Optional[float],
                   seller_count: Optional[int], is_exclusive: bool, strategy: Dict[str, Any],
                   rule: Dict[str, Any], cost: Optional[float],
                   has_buybox: Optional[bool] = None, age_days: Optional[float] = None) -> Dict[str, Any]:
    """按策略算建议价 + 拦截原因。

    基准是**最低竞品价**（买家的选择是"谁最便宜"）：buybox 价可能就是我们自己出的，
    拿它当基准会把自己往下砍。独家/没有竞品价时明确"不调"。
    """
    if is_exclusive or not lowest or lowest <= 0:
        return {"proposed": None, "blocked": True, "reference": None,
                "blockReason": "独家在售（无其他卖家）→ 无需跟价" if (is_exclusive or not seller_count)
                else "公开页没有可用的竞品价（可能已下架或页面异常）"}
    if seller_count == 0:
        return {"proposed": None, "blocked": True, "reference": _r(lowest), "blockReason": "没有其他卖家 → 无需跟价"}

    mode = str(strategy.get("mode") or "undercut_percent")
    value = _num(strategy.get("value"), 1.0, 0.0, 90.0)
    if mode == "match":
        target = lowest
    elif mode == "undercut_fixed":
        target = lowest - value
    else:
        target = lowest * (1.0 - value / 100.0)

    # 已经比最低竞品便宜 → 不再是"跟降"场景；如果持有 BuyBox，这里就是**抬价**的入口。
    # 抬价默认关（strategy.raiseEnabled），开时也只抬一步（+3%）、不越过竞品与上限、数据陈旧不抬。
    if current and current <= lowest * (1.0 + 1e-9):
        if strategy.get("raiseEnabled"):
            raise_plan = _raise_target(current, lowest, rule.get("ceilingPrice"), has_buybox, age_days, rule.get("rrp"))
            if raise_plan.get("proposed"):
                min_delta_pct = _num(strategy.get("minDeltaPercent"), 0.5, 0.0, 20.0)
                if abs(raise_plan["proposed"] - current) <= current * min_delta_pct / 100.0:
                    return {"proposed": None, "blocked": True, "action": "hold", "reference": _r(lowest),
                            "blockReason": "抬价幅度小于 {0}%（防抖）→ 本轮不动".format(min_delta_pct)}
                out = {"proposed": raise_plan["proposed"], "blocked": False, "action": "raise",
                       "reference": _r(lowest), "ceiling": raise_plan.get("ceiling"),
                       "upper": raise_plan.get("upper"), "room": raise_plan.get("room"),
                       "note": raise_plan["note"], "basis": raise_plan.get("basis")}
                return out
            return {"proposed": None, "blocked": True, "action": "hold", "reference": _r(lowest),
                    "blockReason": raise_plan.get("blockReason") or "本轮不抬价"}
        return {"proposed": None, "blocked": True, "action": "hold", "reference": _r(lowest),
                "blockReason": "现价 R {0} 已 ≤ 最低竞品价 R {1} → 无需降价（持有 BuyBox 的价格条件已满足）；"
                               "抬价未启用（策略 raiseEnabled=false）".format(_r(current), _r(lowest))}

    # 底价保护：单 SKU 规则 → 策略底价 → 成本×(1+最低净利率)
    floor = None
    floor_src = ""
    if rule.get("floorPrice"):
        floor, floor_src = float(rule["floorPrice"]), "SKU 底价规则"
    elif strategy.get("floorPrice"):
        floor, floor_src = float(strategy["floorPrice"]), "策略底价"
    min_margin = _num(strategy.get("floorMarginPercent"), 8.0, -50.0, 90.0)
    if cost:
        margin_floor = cost / max(0.05, 1.0 - min_margin / 100.0)
        if floor is None or margin_floor > floor:
            floor, floor_src = margin_floor, "成本 + 最低净利率 {0}%".format(min_margin)
    if floor is None:
        return {"proposed": None, "blocked": True, "reference": _r(lowest),
                "blockReason": "没有底价保护：该 SKU 没有底价规则、策略也未设底价，且本地没有成本价可推算（不猜成本，先补一条底价）"}

    proposed = _r(max(target, 1.0))
    if strategy.get("respectRRP") and rule.get("rrp"):
        proposed = min(proposed, _r(rule["rrp"]))

    # 单次幅度上限：一次降不到目标就先降到上限（而不是直接拒绝）
    capped = None
    max_pct = _num(strategy.get("maxChangePercent"), 10.0, 0.1, 90.0)
    if current and current > 0:
        limit = _r(current * (1.0 - max_pct / 100.0))
        if proposed < limit:
            proposed = limit
            capped = "max_drop"

    if proposed < floor:
        return {"proposed": proposed, "blocked": True, "reference": _r(lowest), "floor": _r(floor),
                "floorSource": floor_src,
                "blockReason": "目标价 R {0} 低于保护底价 R {1}（{2}）→ 拦截，不写".format(proposed, _r(floor), floor_src or "底价")}

    min_delta = _num(strategy.get("minDeltaPercent"), 0.5, 0.0, 20.0)
    if current and abs(proposed - current) <= current * min_delta / 100.0:
        return {"proposed": proposed, "blocked": True, "reference": _r(lowest), "floor": _r(floor),
                "floorSource": floor_src,
                "blockReason": "与现价差异小于 {0}%（防抖）→ 本轮不动".format(min_delta)}

    out = {"proposed": proposed, "blocked": False, "reference": _r(lowest), "floor": _r(floor),
           "floorSource": floor_src}
    if capped:
        out["capped"] = capped
        out["note"] = "单次幅度上限 {0}%：先降到 R {1}，下一轮可继续逼近".format(max_pct, proposed)
    return out


@router.get("/buybox/strategy")
def buybox_strategy_get(storeId: str = "") -> Dict[str, Any]:
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        strategy = _strategy_for(storeId)
        return {"ok": True, "strategy": strategy, "defaults": STRATEGY_DEFAULT,
                "storeId": strategy["storeId"], "storeName": strategy["storeName"],
                "modes": [
                    {"value": "undercut_percent", "label": "低于竞价 X%"},
                    {"value": "undercut_fixed", "label": "低于竞价固定 ZAR"},
                    {"value": "match", "label": "与竞价持平"},
                ]}
    return _safe(build, _fallback({"ok": False, "strategy": dict(STRATEGY_DEFAULT)}))


@router.post("/buybox/strategy")
def buybox_strategy_save(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}

    def build() -> Dict[str, Any]:
        sid = str(payload.get("storeId") or "").strip()
        if not sid:
            return {"ok": False, "error": "跟价策略必须按店保存：缺少 storeId（汇总视图下不可配置）"}
        if _store_row(sid) is None:
            return {"ok": False, "error": "店铺 {0} 不存在".format(sid)}
        # 单 SKU 规则（可选）：底价 / RRP
        sku = str(payload.get("sku") or "").strip()
        if sku:
            rules = _rules_map()
            row = rules.get(sku) or {"sku": sku, "title": "", "auto": True}
            row["floorPrice"] = _r(payload.get("skuFloorPrice") or row.get("floorPrice") or 0)
            if payload.get("skuRrp") is not None:
                row["rrp"] = _r(payload["skuRrp"])
            row["updatedAt"] = _iso_now()
            rules[sku] = row
            _write_state("rules.json", rules)
        data = _strategy_file()
        merged = dict(STRATEGY_DEFAULT)
        merged.update({k: payload[k] for k in STRATEGY_DEFAULT if k in payload})
        merged["mode"] = str(merged.get("mode") or "undercut_percent")
        if merged["mode"] not in ("undercut_percent", "undercut_fixed", "match"):
            return {"ok": False, "error": "不认识的模式 {0}".format(merged["mode"])}
        merged["value"] = _num(merged.get("value"), 1.0, 0.0, 90.0)
        merged["floorMarginPercent"] = _num(merged.get("floorMarginPercent"), 8.0, -50.0, 90.0)
        merged["maxChangePercent"] = _num(merged.get("maxChangePercent"), 10.0, 0.1, 90.0)
        merged["maxChangesPerRun"] = int(_num(merged.get("maxChangesPerRun"), 10, 1, 200))
        merged["minIntervalMinutes"] = int(_num(merged.get("minIntervalMinutes"), 30, 0, 10080))
        merged["maxCandidatesPerRun"] = int(_num(merged.get("maxCandidatesPerRun"), 20, 1, 200))
        merged["crawlBudgetSeconds"] = _num(merged.get("crawlBudgetSeconds"), 8.0, 1.0, 120.0)
        merged["minDeltaPercent"] = _num(merged.get("minDeltaPercent"), 0.5, 0.0, 20.0)
        merged["floorPrice"] = _r(merged["floorPrice"]) if merged.get("floorPrice") not in (None, "") else None
        merged["respectRRP"] = bool(merged.get("respectRRP", True))
        merged["raiseEnabled"] = bool(merged.get("raiseEnabled", False))
        merged["enabled"] = bool(merged.get("enabled", False))
        merged["updatedAt"] = _iso_now()
        data.setdefault("byStore", {})[sid] = merged
        _write_state("pricing_strategy.json", data)
        if sku:
            # NOTE: _price_log() parses the file afresh on every call, so the entry must be
            # inserted into the SAME list that is written back — otherwise the log silently
            # never persists (a real bug caught by asserting the entry exists afterwards).
            entries = _price_log()
            entries.insert(0, {"time": _now().strftime("%H:%M:%S"), "sku": sku, "tsin": "",
                               "type": "STRATEGY", "storeId": sid,
                               "message": "保存 {0} 的 SKU 底价 R {1}".format(sku, merged.get("floorPrice") or 0)})
            _write_state("price_log.json", entries[:400])
        return {"ok": True, "strategy": _strategy_for(sid), "message": "策略已保存（仅作用于该店）"}

    return _safe(build, _fallback({"ok": False, "error": ""}))


@router.post("/buybox/run")
def buybox_run(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """按策略试算/执行一轮跟价。dryRun 默认 True（真实写入必须显式关掉）。"""
    payload = body or {}
    sid = str(payload.get("storeId") or "").strip()
    dry_run = bool(payload.get("dryRun", True))
    only = payload.get("skus")
    wanted = {str(x) for x in only} if isinstance(only, list) and only else None

    def build() -> Dict[str, Any]:
        if not sid:
            return {"ok": False, "error": "跟价必须指明店铺：汇总视图下先选定一家店（写入不能落到不确定的店）",
                    "rows": [], "summary": {}}
        if _store_row(sid) is None:
            return {"ok": False, "error": "店铺 {0} 不存在".format(sid), "rows": [], "summary": {}}
        strategy = _strategy_for(sid)
        if not strategy.get("enabled") and not dry_run:
            return {"ok": False, "error": "该店策略未启用：先保存并勾选「启用」（试算不受限制）", "rows": [], "summary": {}}
        context = _catalog_items(store_id=sid)
        items = context.get("items") or []
        rules = _rules_map()
        costs = _cost_map()
        budget = _num(strategy.get("crawlBudgetSeconds"), 8.0, 1.0, 120.0)
        cap = int(_num(strategy.get("maxCandidatesPerRun"), 20, 1, 200))
        started = time.time()

        # 候选挑选：有公开页可证的 SKU，按"离买家最近"的排（没有 BuyBox 优先，其次价差大）
        pool = []
        for it in items:
            sku = str(it.get("sku") or "")
            if not sku or (wanted and sku not in wanted):
                continue
            pool.append(it)
        pool.sort(key=lambda it: (bool(it.get("buyboxHeld")), -(it.get("price") or 0)))
        rows: List[Dict[str, Any]] = []
        crawled = 0
        for it in pool[:cap]:
            if time.time() - started > budget:
                break
            sku = str(it.get("sku") or "")
            current = float(it.get("price") or 0)
            if not current:
                continue
            rule = rules.get(sku) or {}
            buybox = lowest = None
            sellers = None
            exclusive = False
            probe_error = None
            age_days = None
            # BuyBox 归属：优先用**本次实时抓取**的解析结果（爬虫给了 isBuyboxHolder），
            # 抓取失败时才退回缓存卡片上的标记。抬价的门槛取决于它，不能拿旧事实凑。
            buybox_held = bool(it.get("buyboxHeld"))
            buybox_held_src = "cache"
            if CRAWLER is not None:
                try:
                    plid = str(it.get("plid") or "") or str(it.get("tsin") or "")
                    if not plid:
                        probe_error = "该 SKU 没有 PLID/TSIN，无法取证"
                    else:
                        raw, err, _transport = CRAWLER.fetch_product(plid)
                        crawled += 1
                        if err:
                            probe_error = err
                        elif isinstance(raw, dict):
                            # 用爬虫自己的解析器，别自己猜 JSON 结构
                            parsed = CRAWLER.parse_product(raw, plid=plid) if hasattr(CRAWLER, "parse_product") else raw
                            buybox = _price_of(parsed.get("price"))
                            lowest = _price_of(parsed.get("lowestCompetitorPrice"))
                            sellers = parsed.get("sellerCount")
                            exclusive = bool(parsed.get("isExclusive"))
                            # 持有者身份来自公开页的 seller 块（顶层 isBuyboxHolder 常为 None）
                            held_live = _buybox_held_from_card(parsed, sid)
                            if isinstance(held_live, bool):
                                buybox_held = held_live
                                buybox_held_src = "live-holder"
                            age_days = 0.0   # 刚抓的：这一刻的公开页数据
                except Exception as exc:  # pragma: no cover
                    probe_error = str(exc)
            decision = _propose_price(sku, current, lowest, buybox, sellers, exclusive, strategy, rule,
                                      costs.get(sku), has_buybox=buybox_held, age_days=age_days)
            last = _last_write_ms(sku, sid)
            cooldown_min = int(_num(strategy.get("minIntervalMinutes"), 30, 0, 10080))
            cooldown_hit = bool(last and cooldown_min and (time.time() * 1000 - last) < cooldown_min * 60000)
            status = "blocked" if decision.get("blocked") else "ready"
            reason = decision.get("blockReason") or decision.get("note") or "按策略可调"
            if status == "ready" and cooldown_hit:
                status = "blocked"
                reason = "冷却中：{0} 分钟内已调过该 SKU（避免价格抖动）".format(cooldown_min)
            if status == "ready" and not current:
                status = "blocked"
                reason = "没有现价，无法比较"
            # 抬价的两道专属闸（跟降不需要）：同 SKU 6 小时冷却 + 每店每日次数上限。
            # 一步一抬 + 冷却 + 次数上限 = 不在竞品上下横跳，也不像价格操纵。
            if status == "ready" and decision.get("action") == "raise":
                last_raise = _last_write_ms(sku, sid, action="raise")
                if last_raise and (time.time() * 1000 - last_raise) < RAISE_COOLDOWN_MINUTES * 60000:
                    status = "blocked"
                    reason = "抬价冷却中：{0} 小时内已抬过该 SKU（下一步最多 +{1}%）".format(
                        round(RAISE_COOLDOWN_MINUTES / 60.0, 1), RAISE_STEP_PERCENT)
                elif _raises_today(sid) >= RAISE_DAILY_CAP:
                    status = "blocked"
                    reason = "今日抬价次数已达上限 {0} 次（每店每日，防批量抬价）".format(RAISE_DAILY_CAP)
            rows.append({
                "sku": sku, "title": it.get("title") or "", "storeId": sid, "storeName": it.get("storeName") or strategy.get("storeName"),
                "current": _r(current), "buybox": _r(buybox) if buybox else None, "lowest": _r(lowest) if lowest else None,
                "sellerCount": sellers, "exclusive": exclusive,
                "reference": _r(decision.get("reference")) if decision.get("reference") else None,
                "proposed": _r(decision["proposed"]) if decision.get("proposed") else None,
                "delta": _r((decision["proposed"] - current)) if decision.get("proposed") else None,
                "floor": decision.get("floor"), "floorSource": decision.get("floorSource"),
                "action": decision.get("action") or ("drop" if decision.get("proposed") else "hold"),
                "ceiling": decision.get("ceiling"), "raiseRoom": decision.get("room"),
                "buyboxHeld": buybox_held, "buyboxHeldSource": buybox_held_src, "dataAgeDays": age_days,
                "cost": costs.get(sku), "status": status, "reason": reason,
                "probeError": probe_error, "capped": decision.get("capped"),
            })
        ready = [r for r in rows if r["status"] == "ready" and r.get("proposed")]
        max_changes = int(_num(strategy.get("maxChangesPerRun"), 10, 1, 200))
        to_write = ready[:max_changes] if not dry_run else []
        applied = []
        if to_write:
            for r in to_write:
                meta: Dict[str, Any] = {}
                _, err = _api_request("PATCH", "/offers/by_sku/{0}".format(r["sku"]), None,
                                      {"selling_price": int(round(r["proposed"]))}, store_id=sid, meta=meta)
                r["apiStatus"] = meta.get("status")
                r["apiError"] = err
                r["applied"] = err is None
                if err is None:
                    reread, rerr = _api_request("GET", "/offers/by_sku/{0}".format(r["sku"]), store_id=sid)
                    r["reread"] = (_price_of(((reread or {}).get("selling_price"))) if isinstance(reread, dict) else None)
                    r["rereadError"] = rerr
                applied.append(r)
                # 审计里必须留下 action：抬价的 6h 冷却与每日上限都读它，跟降不受影响。
                _append_offer_write({"type": "REPRICE", "sku": r["sku"], "storeId": sid,
                              "action": r.get("action") or "drop",
                              "request": {"selling_price": int(round(r["proposed"]))},
                              "from": r["current"], "apiStatus": meta.get("status"),
                              "ok": err is None, "source": "POST /buybox/run", "error": err or ""})
                entries = _price_log()
                entries.insert(0, {
                    "time": _now().strftime("%H:%M:%S"), "sku": r["sku"], "tsin": "", "storeId": sid,
                    "type": "REPRICE" if err is None else "BLOCKED",
                    "message": (("{0}：R {1} → R {2}（参考 R {3}，{4}）".format(
                                    "抬价" if r.get("action") == "raise" else "按策略跟价",
                                    r["current"], r["proposed"], r.get("reference") or "—", r["reason"]))
                    if err is None else "跟价失败：{0}".format(err))})
                _write_state("price_log.json", entries[:400])
            _bust_offer_caches(sid)
        summary = {
            "candidates": len(rows), "ready": len(ready), "blocked": len(rows) - len(ready),
            "written": len(applied), "dryRun": dry_run, "crawled": crawled,
            "strategy": {"mode": strategy.get("mode"), "value": strategy.get("value"),
                         "maxChangePercent": strategy.get("maxChangePercent")},
        }
        return {"ok": True, "dryRun": dry_run, "storeId": sid, "storeName": strategy.get("storeName"),
                "summary": summary, "rows": applied if to_write else rows,
                "hint": ("这是试算（未写入任何价格）。确认无误后点「执行」。" if dry_run else
                         "已按策略写入并逐条回读；被拦截的行没有发出任何请求。")}

    return _safe(build, _fallback({"ok": False, "rows": [], "summary": {}}))


@router.get("/buybox/log")
def buybox_log(storeId: str = "") -> Dict[str, Any]:
    """调价/写入日志 —— 按店铺过滤（rows 未标注店铺时保留，别把历史记录藏起来）。"""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        logs, scope = _store_rows(_price_log(), storeId)
        return {"logs": logs, "storeId": scope["storeId"], "storeName": scope["storeName"],
                "storeScoped": not scope["scopedFromActive"], "filtered": scope["filtered"],
                "unassignedIncluded": scope.get("unassignedIncluded") or 0}
    return _safe(build, _fallback({"logs": [], "filtered": False}))


@router.get("/competitor")
def competitor(storeId: str = "") -> Dict[str, Any]:
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        items, scope = _store_rows(_competitor_rows(), storeId)
        return {"mode": "live", "empty": not items, "items": items,
                "storeId": scope["storeId"], "storeName": scope["storeName"],
                "storeScoped": not scope["scopedFromActive"], "filtered": scope["filtered"],
                "unassignedIncluded": scope.get("unassignedIncluded") or 0,
                "note": None if items else "暂无历史快照，点「采集」开始记录",
                "basis": "竞品数据只来自公开页真实抓取（state/velocity_cache.json）"}
    return _safe(build, _fallback({"mode": "error", "items": [], "filtered": False}))


@router.get("/compliance/rules")
def compliance_rules(storeId: str = "") -> Dict[str, Any]:
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        scope = _effective_store(storeId)
        categories = [v for _, v in sorted(_loadsheet_names().items(), key=lambda kv: kv[1])]
        return {"words": _compliance_seed_words(), "categories": categories,
                "storeId": scope["storeId"], "storeName": scope["storeName"],
                "storeScoped": not scope["storeScoped"],
                "note": "合规词库是平台级规则，与店铺无关；此处只标注请求作用域。"}
    return _safe(build, _fallback({"words": [], "categories": []}))


@router.get("/settings")
def settings() -> Dict[str, Any]:
    def build() -> Dict[str, Any]:
        data = _store_data()
        return {
            "mode": "local",
            "keyConfigured": _key_configured(),
            "activeStoreId": data.get("activeStoreId", ""),
            "stores": [_public_store(s) for s in data.get("stores") or []],
            "dcDefaults": _dc_defaults(),
            "vatRate": VAT_RATE,
            "stateDir": str(STATE_DIR),
            "packageDir": str(PACKAGE_DIR),
        }
    return _safe(build, _fallback({
        "mode": "local", "keyConfigured": False, "activeStoreId": "", "stores": [],
        "dcDefaults": {}, "vatRate": VAT_RATE, "stateDir": str(STATE_DIR), "packageDir": str(PACKAGE_DIR),
    }))


def _dc_defaults() -> Dict[str, Any]:
    defaults = {"warehouse": "JHB", "weightKg": 0.5, "lengthCm": 25, "widthCm": 18, "heightCm": 8}
    data = _read_state("settings.json", None)
    if isinstance(data, dict) and isinstance(data.get("dcDefaults"), dict):
        merged = dict(defaults)
        merged.update(data["dcDefaults"])
        return merged
    return defaults


@router.get("/state")
def state() -> Dict[str, Any]:
    """本地状态快照 —— 全部只读客户自己的 state（不触发任何网络请求）。"""
    def build() -> Dict[str, Any]:
        sales = _sales_rows(None, allow_fetch=False)
        live = _financial_live_cached(None, allow_fetch=False)
        return {
            "mode": "live",
            "counts": {
                "orders": len(sales.get("rows") or []),
                "collection": len(_collection()),
                "drafts": len(_drafts()),
                "rules": len(_rules_map()),
                "competitors": len(_competitor_rows()),
                "logs": len(_price_log()),
                "statements": len((live.get("months") or []) if live.get("ok") else []),
                "categories": len(_category_nodes()),
                "brands": len(_brand_names()),
            },
            "ordersCached": bool(sales.get("rows")),
            "ordersNote": (None if sales.get("rows") else
                           (sales.get("error") or "本进程还没取过一次 /sales（打开总览后即会缓存 60 秒）")),
            "seedRowsRemoved": dict(_SEED_STRIPPED),
            "keyConfigured": _key_configured(),
            "stateDir": str(STATE_DIR),
            "serverTime": _server_time(),
        }
    return _safe(build, _fallback({
        "mode": "error", "counts": {"orders": 0, "collection": 0, "drafts": 0, "rules": 0,
                                    "competitors": 0},
        "keyConfigured": False,
    }))


# --------------------------------------------------------------------------
# WRITE endpoints
# --------------------------------------------------------------------------

@router.post("/collection/add")
def collection_add(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}

    def build() -> Dict[str, Any]:
        target = (payload.get("url") or payload.get("tsin") or "").strip()
        # 爬取失败绝不能丢掉商家采集的这一行：抓不到就是 crawl=null + 明确原因，
        # 行照常入库（缺的字段由 UI 提示补录）。以前这里一抛异常整行就没了。
        crawl = None
        crawl_error = None
        if target:
            try:
                crawl = _crawl_target(target)
            except Exception as exc:
                crawl_error = "{0}: {1}".format(type(exc).__name__, str(exc)[:200])
        item = _add_collection_item(payload, crawl)
        return {
            "ok": True,
            "item": _collection_row(item),
            "crawl": crawl,
            "crawlError": crawl_error,
            "conflicts": _collection_conflicts(_collection()),
            "mode": (crawl or {}).get("mode") or "local",
        }

    return _safe(build, _fallback({"ok": False, "item": None, "crawl": None, "mode": "local"}))


def _collection_audit(entry: Dict[str, Any]) -> None:
    """跟卖池的写操作审计（价格/库存/状态变更）——交付时要能自证改过什么。"""
    try:
        path = STATE_DIR / "collection_audit.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(entry, at=_iso_now()), ensure_ascii=False) + "\n")
    except Exception:
        pass


# 采集箱 = 跟卖池：平台侧（CreateOfferRequest / PatchOfferRequest）能改的只有
# barcode/sku/价格/仓库库存，标题/图片/描述/类目根本不在可写集合里。所以这里
# 也在接口层把同一规则执行一遍，并明确回绝其它字段，避免界面误以为能改内容。
#
# 但「核算输入」（成本/币种/汇率/汇损/头程/重量/尺寸）不是 listing 内容 —— 它们只存在
# 我们本地，平台根本看不到，却是费率条件的输入（履约费按体积 cm³ 档 × 重量档定价）。
# 以前把它们跟 listing 内容一起拒绝，导致界面上和自然语言里都没法给这些条件 → 显示未定。
COLLECTION_WRITABLE_FIELDS = ("price", "stock", "cost", "costCurrency", "costRmb",
                              "exchangeRateZarPerRmb", "exchangeLossCoeff", "headLogisticsZar",
                              "weightKg", "lengthCm", "widthCm", "heightCm", "warehouse", "note")
#: 采集箱里永远不可改的字段：listing 内容由平台规则锁死（跟卖不能改标题/图片/类目/条码）
COLLECTION_LISTING_FIELDS = ("title", "subtitle", "brand", "barcode", "tsin", "plid", "category",
                             "categoryPath", "imageUrl", "images", "description", "sourceUrl", "url")
COLLECTION_LISTING_RULE = ("listing 内容（标题/图片/描述/类目/条码）在平台上不可改：跟卖只能改价格与库存。"
                           "要改内容请「转入新建草稿」，走 Loadsheet 上传 + 人工 QC")
#: 采集箱可改字段 → state 行里的真实键名与类型
COLLECTION_FIELD_MAP = {
    "price": ("estSalePrice", float),
    "stock": ("stock", int),
    "cost": ("cost", float),
    "costRmb": ("costRmb", float),
    "exchangeRateZarPerRmb": ("exchangeRateZarPerRmb", float),
    "exchangeLossCoeff": ("exchangeLossCoeff", float),
    "headLogisticsZar": ("headLogisticsZar", float),
    "weightKg": ("weightKg", float),
    "lengthCm": ("lengthCm", float),
    "widthCm": ("widthCm", float),
    "heightCm": ("heightCm", float),
    "costCurrency": ("costCurrency", str),
    "warehouse": ("warehouse", str),
    "note": ("note", str),
}


@router.post("/collection/update")
def collection_update(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """改价格/库存（平台侧）+ 我方核算输入（成本/汇率/汇损/头程/重量/尺寸）。

    listing 内容（标题/图片/描述/类目/条码）一律拒绝并说明平台规则。
    """
    payload = body or {}

    def build() -> Dict[str, Any]:
        rejected = [k for k in payload.keys()
                    if k not in ("id", "ids", "storeId") + COLLECTION_WRITABLE_FIELDS]
        if rejected:
            listing_hits = [k for k in rejected if k in COLLECTION_LISTING_FIELDS]
            return {
                "ok": False,
                "error": COLLECTION_LISTING_RULE if listing_hits
                         else "不认识的字段：{0}".format("、".join(sorted(rejected))),
                "rejectedFields": sorted(rejected),
                "listingFields": sorted(listing_hits),
                "allowed": list(COLLECTION_WRITABLE_FIELDS),
                "mode": "local",
            }
        ids = payload.get("ids") if isinstance(payload.get("ids"), list) else []
        target = str(payload.get("id") or "").strip()
        if target:
            ids = [target] + [str(i) for i in ids if str(i) != target]
        if not ids:
            return {"ok": False, "error": "缺少 id", "updated": [], "mode": "local"}

        items = _collection()
        updated: List[Dict[str, Any]] = []
        changed_fields: List[str] = []
        for item in items:
            if str(item.get("id")) not in {str(i) for i in ids}:
                continue
            # state 行里的键是 estSalePrice/stock；审计要读者能看懂，就用真实键名
            watched = sorted({key for key, _ in COLLECTION_FIELD_MAP.values()})
            before = {key: item.get(key) for key in watched}
            for field, (state_key, caster) in sorted(COLLECTION_FIELD_MAP.items()):
                if payload.get(field) in (None, ""):
                    continue
                try:
                    value = caster(float(payload.get(field))) if caster in (int, float) else caster(payload.get(field)).strip()
                except (TypeError, ValueError):
                    continue
                if caster is str and not value:
                    continue
                item[state_key] = value
                if field not in changed_fields:
                    changed_fields.append(field)
            # 人填了尺寸/重量就换掉抓来的来源标记，界面才不会说「来自公开页」
            if any(payload.get(k) not in (None, "") for k in ("lengthCm", "widthCm", "heightCm")):
                item["dimensionSource"] = "user-input"
            if item.get("state") in (None, "", "promoted"):
                item["state"] = "pool" if item["state"] != "promoted" else "promoted"
            updated.append({"id": item.get("id"), "before": before,
                            "after": {key: item.get(key) for key in watched}})
        if updated:
            _write_state("collection.json", items)
        _collection_audit({"action": "collection/update", "ids": ids,
                           "fields": sorted(set(changed_fields)), "rows": updated})
        return {"ok": bool(updated), "updated": updated,
                "rows": [_collection_row(i) for i in items if str(i.get("id")) in {str(x) for x in ids}],
                "count": len(updated), "mode": "local"}

    return _safe(build, _fallback({"ok": False, "updated": [], "count": 0, "mode": "local"}))


@router.delete("/collection/{item_id}")
def collection_delete(item_id: str) -> Dict[str, Any]:
    def build() -> Dict[str, Any]:
        items = _collection()
        remaining = [i for i in items if str(i.get("id")) != str(item_id)]
        removed = len(items) - len(remaining)
        if removed:
            _write_state("collection.json", remaining)
        return {"ok": removed > 0, "removed": removed, "id": item_id, "count": len(remaining), "mode": "local"}
    return _safe(build, _fallback({"ok": False, "removed": 0, "id": item_id, "mode": "local"}))


@router.post("/collection/promote")
def collection_promote(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}
    ids = payload.get("ids") if isinstance(payload.get("ids"), list) else []
    requested = str(payload.get("storeId") or "").strip()
    store = _store_row(requested) or _store_row(_store_data().get("activeStoreId"))
    store_id = str(store.get("id")) if store else None

    def build() -> Dict[str, Any]:
        result = dict(_promote_collection(ids, store_id), ok=True, mode="local")
        result["storeId"] = store_id
        result["storeName"] = store.get("name") if store else None
        result["storeIdRequired"] = not bool(requested)
        result["storeIds"] = [str(d.get("storeId")) for d in result.get("created") or []]
        return result

    return _safe(build, _fallback({"ok": False, "created": [], "count": 0, "conflicts": [], "mode": "local"}))


@router.post("/listings/draft")
def listings_draft(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}

    def build() -> Dict[str, Any]:
        drafts = _drafts()
        draft_id = str(payload.get("id") or "").strip()
        existing = next((d for d in drafts if str(d.get("id")) == draft_id), None)
        if existing is None:
            seq = 3001
            taken = {str(d.get("id")) for d in drafts}
            while "DRF-{0}".format(seq) in taken:
                seq += 1
            existing = {
                "id": draft_id or "DRF-{0}".format(seq),
                "attributes": {},
                "status": "draft",
                "compliance": {"hits": []},
            }
            drafts.insert(0, existing)
        title = payload.get("title") or existing.get("title") or ""
        for key in (
            "title", "subtitle", "brand", "barcode", "tsin", "plid", "category", "categoryPath",
            "sku", "productType", "variantGroup", "features", "whatsInTheBox", "videoUrl",
            "warrantyType", "mainCategory", "lowestCategory", "storeId", "storeName",
        ):
            if payload.get(key) is not None:
                existing[key] = payload[key]
        if payload.get("warrantyPeriod") is not None or payload.get("warrantyMonths") is not None:
            try:
                existing["warrantyPeriod"] = int(payload.get("warrantyPeriod") or payload.get("warrantyMonths"))
            except (TypeError, ValueError):
                existing["warrantyPeriod"] = DEFAULT_WARRANTY_MONTHS
        if payload.get("price") is not None:
            existing["price"] = _r(payload["price"])
        if payload.get("qty") is not None:
            existing["qty"] = int(payload["qty"])
        if isinstance(payload.get("images"), list):
            existing["images"] = [
                normalize_takealot_image(str(url)) for url in payload["images"] if str(url or "").strip()
            ][:IMAGE_COLUMN_COUNT]
        if isinstance(payload.get("attributes"), dict):
            existing["attributes"] = {str(k): ("" if v is None else str(v)) for k, v in payload["attributes"].items()}
        if isinstance(payload.get("variantThemes"), list):
            existing["variantThemes"] = [str(t) for t in payload["variantThemes"] if str(t or "").strip()][:2]
        if isinstance(payload.get("variants"), dict):
            # 新变体模型（主题 + 轴 + 每行自己的 SKU/条码/图片）
            existing["variants"] = _variant_model_normalize(payload["variants"])
        elif isinstance(payload.get("variants"), list):
            # 老形状（轴名数组 + 行数组）→ 迁移进新模型，不丢已填的变体
            existing["variants"] = _variant_model_normalize({
                "axes": [{"key": str(t), "columnName": str(t)}
                         for t in (payload.get("variantThemes") or []) if str(t or "").strip()][:2],
                "rows": [v for v in payload["variants"] if isinstance(v, dict)],
            })
        if payload.get("status"):
            existing["status"] = payload["status"]
        if existing.get("title") and re.search(r"[A-Za-z]", str(payload.get("complianceText") or payload.get("title") or "")):
            analysis = compliance_check(
                " ".join(
                    str(existing.get(k) or "")
                    for k in ("title", "subtitle", "brand")
                ),
                existing.get("category"),
            )
            existing["compliance"] = {"hits": [h["word"] for h in analysis["hits"]], "verdict": analysis["verdict"]}
        existing["updatedAt"] = _iso_now()
        # backfill every extended field (and keep sku stable for the loadsheet writer)
        existing.update(_draft_upgrade(existing))
        _write_state("drafts.json", drafts)
        return {"ok": True, "draft": existing, "mode": "local"}

    return _safe(build, _fallback({"ok": False, "draft": None, "mode": "local"}))


@router.delete("/listings/drafts/{draft_id}")
def listings_draft_delete(draft_id: str) -> Dict[str, Any]:
    def build() -> Dict[str, Any]:
        drafts = _drafts()
        remaining = [d for d in drafts if str(d.get("id")) != str(draft_id)]
        removed = len(drafts) - len(remaining)
        if removed:
            _write_state("drafts.json", remaining)
        return {"ok": removed > 0, "removed": removed, "id": draft_id, "count": len(remaining), "mode": "local"}
    return _safe(build, _fallback({"ok": False, "removed": 0, "id": draft_id, "mode": "local"}))


@router.get("/listings/prefill")
def listings_prefill(target: str = "", force: bool = False, storeId: str = "", qty: int = 0) -> Dict[str, Any]:
    """`?target=<url|TSIN|PLID>&force=` → crawl/cache → draft + route verdict."""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    payload: Dict[str, Any] = {"target": target, "force": force, "storeId": storeId}
    if qty:
        payload["qty"] = qty
    return _safe(
        lambda: _prefill_payload(payload),
        _fallback({
            "ok": False, "mode": "local", "target": target, "route": "loadsheet", "exists": False,
            "product": {}, "draft": {}, "warnings": [],
        }),
    )


@router.post("/listings/validate")
def listings_validate(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """Pre-flight the rows against the official Loadsheet rules (never raises)."""
    payload = body or {}

    def build() -> Dict[str, Any]:
        raw_rows = payload.get("rows")
        if not isinstance(raw_rows, list) or not raw_rows:
            raw_rows = payload.get("drafts")
        drafts_in: List[Dict[str, Any]] = [row for row in (raw_rows or []) if isinstance(row, dict)]
        if not drafts_in:
            # no rows supplied: validate the stored drafts so the panel is never empty
            drafts_in = _drafts()
        strict = payload.get("strict") is not False
        image_count = int(payload.get("imageCount") or IMAGE_COLUMN_COUNT)
        columns_plan = all_loadsheet_columns(image_count)
        out_rows: List[Dict[str, Any]] = []
        attribute_names: List[str] = []
        ready = 0
        blocked = 0
        index = 0
        for draft_index, draft in enumerate(drafts_in):
            inp = _loadsheet_input_from_draft(draft)
            strict_flags = _strict_loadsheet_flags(inp) if strict else []
            for row in build_loadsheet_rows(inp, image_count):
                for name in (row.get("attributes") or {}):
                    if name not in attribute_names:
                        attribute_names.append(name)
                errors = list(row["errors"]) + [flag["message"] for flag in strict_flags]
                warnings = list(row["warnings"])
                # columns is keyed by the real .xlsx header text (what the UI shows)
                columns = {col["header"]: row["values"].get(col["key"], "") for col in columns_plan}
                columns.update({str(k): str(v) for k, v in (row.get("attributes") or {}).items()})
                ok = not errors
                if ok:
                    ready += 1
                else:
                    blocked += 1
                out_rows.append({
                    "index": index,
                    "draftIndex": draft_index,
                    "draftId": draft.get("id") or "",
                    "sku": row["values"].get("sku") or "",
                    "ok": ok,
                    "errors": errors,
                    "warnings": warnings,
                    "flags": strict_flags,
                    "productType": row["values"].get("productType") or "Single",
                    "columns": columns,
                })
                index += 1
        headers = loadsheet_headers(image_count) + attribute_names
        return {
            "ok": blocked == 0,
            "mode": "local",
            "strict": strict,
            "rows": out_rows,
            "readyCount": ready,
            "blockedCount": blocked,
            "headers": headers,
            "imageColumns": image_count,
            "checkedAt": _iso_now(),
        }

    return _safe(build, _fallback({
        "ok": False, "rows": [], "readyCount": 0, "blockedCount": 0, "headers": [],
    }))


@router.post("/listings/drafts/delete")
def listings_drafts_delete(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """批量删除草稿（逐条结果，删不存在的也如实说明）。"""
    payload = body or {}
    raw = payload.get("ids") or payload.get("id") or []
    if isinstance(raw, str):
        raw = [raw]
    wanted = {str(x).strip() for x in raw if str(x or "").strip()}

    def build() -> Dict[str, Any]:
        if not wanted:
            return {"ok": False, "error": "缺少 ids：批量删除必须指明草稿号", "deleted": [], "count": 0}
        drafts = _drafts()
        keep, results = [], []
        for draft in drafts:
            did = str(draft.get("id") or "")
            if did in wanted:
                results.append({"id": did, "deleted": True, "title": draft.get("title") or ""})
            else:
                keep.append(draft)
        for missing in wanted - {str(d.get("id") or "") for d in drafts}:
            results.append({"id": missing, "deleted": False, "error": "草稿不存在"})
        removed = len([r for r in results if r["deleted"]])
        if removed:
            _write_state("drafts.json", keep)
        return {"ok": removed > 0, "count": removed, "deleted": results,
                "remaining": len(keep), "message": "已删除 {0} 个草稿".format(removed)}

    return _safe(build, _fallback({"ok": False, "deleted": [], "count": 0}))


@router.post("/listings/duplicates")
def listings_duplicates(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """重复/冲突检测：草稿之间、与本店在售 offer、与采集箱。

    A duplicate barcode shipped as a NEW listing gets rejected by the platform
    (``cant-create-duplicate-gtin``) — that商品 should be repriced/跟卖 instead, so the
    pre-flight has to say it before the operator exports the loadsheet.
    """
    payload = body or {}
    raw = payload.get("ids") or []
    if isinstance(raw, str):
        raw = [raw]
    wanted = {str(x).strip() for x in raw if str(x or "").strip()}
    sid = str(payload.get("storeId") or "").strip()

    def build() -> Dict[str, Any]:
        drafts = [d for d in _drafts() if not wanted or str(d.get("id")) in wanted]
        groups: Dict[str, List[Dict[str, Any]]] = {}
        for draft in drafts:
            for key, label in (("barcode", "条码"), ("tsin", "TSIN"), ("title", "标题")):
                value = str(draft.get(key) or "").strip().lower()
                if not value:
                    continue
                groups.setdefault("{0}:{1}".format(label, value), []).append(
                    {"id": draft.get("id"), "title": draft.get("title"), "field": label, "value": draft.get(key)})
        within = [{"key": k.split(":", 1)[0], "value": rows[0].get("value"), "count": len(rows),
                   "drafts": [{"id": r["id"], "title": r["title"]} for r in rows]}
                  for k, rows in groups.items() if len(rows) > 1]

        # 与本店在售 offer 冲突（条码/TSIN 已在售 → 应走跟卖/改价）
        catalogue: Dict[str, Dict[str, Any]] = {}
        conflicts: List[Dict[str, Any]] = []
        try:
            ctx = _catalog_items(store_id=sid or None)
            for item in ctx.get("items") or []:
                for key in ("barcode", "tsin"):
                    value = str(item.get(key) or "").strip().lower()
                    if value:
                        catalogue.setdefault("{0}:{1}".format(key, value), item)
            for draft in drafts:
                for key, label in (("barcode", "条码"), ("tsin", "TSIN")):
                    value = str(draft.get(key) or "").strip().lower()
                    if not value:
                        continue
                    hit = catalogue.get("{0}:{1}".format(key, value))
                    if hit:
                        conflicts.append({
                            "draftId": draft.get("id"), "draftTitle": draft.get("title"),
                            "field": label, "value": draft.get(key),
                            "offerSku": hit.get("sku"), "offerStatus": hit.get("statusLabel") or hit.get("status"),
                            "advice": "该{0}本店已有在售 offer（SKU {1}）：不要新建，改用跟卖/改价（商品管理 → 批量改价，或详情里的跟卖落点）".format(label, hit.get("sku")),
                        })
                        break
        except Exception as exc:  # pragma: no cover
            conflicts.append({"draftId": "", "error": str(exc)})

        # 与采集箱重复（同 TSIN 已在采集箱）
        collection_hits: List[Dict[str, Any]] = []
        try:
            tsin_index = {str(c.get("tsin") or "").strip().lower(): c for c in _collection() if c.get("tsin")}
            for draft in drafts:
                tsin = str(draft.get("tsin") or "").strip().lower()
                if tsin and tsin in tsin_index:
                    collection_hits.append({"draftId": draft.get("id"), "tsin": draft.get("tsin"),
                                            "collectionId": (tsin_index[tsin] or {}).get("id"),
                                            "note": "采集箱里已有同一 TSIN 的记录：确认是否重复建档"})
        except Exception:
            pass
        total = len(within) + len(conflicts) + len(collection_hits)
        return {
            "ok": True, "checked": len(drafts), "total": total,
            "withinDrafts": within, "againstOffers": conflicts, "againstCollection": collection_hits,
            "clean": total == 0,
            "hint": ("条码/TSIN 已在售时，平台会以 cant-create-duplicate-gtin 拒收新建——这类商品应该改价或跟卖，"
                     "而不是走装载表新建。"),
        }

    return _safe(build, _fallback({"ok": False, "withinDrafts": [], "againstOffers": [], "againstCollection": []}))


@router.post("/listings/loadsheet")
def listings_loadsheet(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """Official new-listing Product Information Loadsheet (.xlsx)."""
    payload = body or {}

    def build() -> Dict[str, Any]:
        raw_rows = payload.get("rows")
        drafts_in: List[Dict[str, Any]] = [row for row in (raw_rows or []) if isinstance(row, dict)] \
            if isinstance(raw_rows, list) else []
        if drafts_in:
            # drafts sent inline always keep every extended default filled
            drafts_in = [_draft_upgrade(row) for row in drafts_in]
        else:
            drafts = _drafts()
            ids = payload.get("ids")
            if isinstance(ids, list) and ids:
                wanted = {str(i) for i in ids}
                drafts = [d for d in drafts if str(d.get("id")) in wanted]
            drafts_in = drafts
        if not drafts_in:
            return {
                "ok": False, "path": "", "rows": 0, "bytes": 0,
                "columns": loadsheet_headers(), "errors": ["没有可导出的草稿行（ids/rows 都为空）"],
                "mode": "local",
            }
        image_count = int(payload.get("imageCount") or IMAGE_COLUMN_COUNT)
        plan = _loadsheet_export_plan(drafts_in, image_count)
        errors: List[str] = []
        warnings: List[str] = []
        for row in plan["built"]:
            errors.extend(row["errors"])
            warnings.extend(row["warnings"])
        target = str(payload.get("path") or "").strip()
        if target:
            out_path = Path(target)
            if not out_path.is_absolute():
                out_path = STATE_DIR / out_path
        else:
            out_path = EXPORT_DIR / "loadsheet-{0}.xlsx".format(_now().strftime("%Y%m%d-%H%M%S"))
        size = _write_xlsx(out_path, plan["headers"], plan["table"])
        return {
            "ok": True,
            "path": str(out_path),
            "rows": len(plan["table"]),
            "bytes": size,
            "columns": list(plan["headers"]),
            "attributeColumns": list(plan["attributeColumns"]),
            "fixedColumns": loadsheet_headers(image_count),
            "imageColumns": image_count,
            "drafts": len(drafts_in),
            "errors": errors,
            "warnings": warnings,
            "blockedCount": sum(1 for row in plan["built"] if row["errors"]),
            "variantPlans": [
                {
                    "draftId": d.get("id") or "",
                    "theme": (d.get("variants") or {}).get("theme") or "",
                    "rows": len(build_loadsheet_rows(_loadsheet_input_from_draft(d), image_count)),
                }
                for d in drafts_in
            ],
            "mode": "local",
            "generatedAt": _iso_now(),
        }

    return _safe(build, _fallback({
        "ok": False, "path": "", "rows": 0, "bytes": 0, "columns": loadsheet_headers(), "mode": "local",
    }))


@router.post("/ai/listing-copy")
def ai_listing_copy(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}
    return _safe(lambda: _ai_listing_copy(payload), _fallback(_ai_template("", None, "en")))


_COPY_LIMIT_DEFAULTS = {"maxTitle": 75, "maxSubtitle": 110, "minFeatures": 200}

_COPY_FEATURE_LINES_ZH = [
    "- {subject}：{category} 类目现货，围绕日常使用场景做设计与用料取舍。",
    "- 规格参数：{attrs}",
    "- 材质与做工：选用稳定耐用的材料，边缘与接缝处理到位，长期使用不易变形。",
    "- 使用场景：家用、办公室与出行均可，无需专业安装，开箱即可上手。",
    "- 包装与物流：本地仓发货，带跟踪的快递配送，南非全国可达。",
    "- 售后保障：提供质保与便捷退换货支持，问题可通过 Takealot 客服发起处理。",
    "- 购买提示：下单前请核对尺寸、型号与颜色，确保与你的使用需求一致。",
]
_COPY_FEATURE_LINES_EN = [
    "- {subject}: built around a proven {category} design for stable daily performance.",
    "- Specifications: {attrs}",
    "- Materials: quality-checked components with reinforced seams and edges that hold their shape.",
    "- Use cases: home, office and travel; set up in minutes with no specialist tools required.",
    "- Delivery: dispatched from a local warehouse with a tracked courier service nationwide.",
    "- Support: backed by a supplier warranty and straightforward returns through Takealot.",
    "- Please confirm the size, model and colour against your needs before ordering.",
]


def _copy_limits(payload: Dict[str, Any]) -> Dict[str, int]:
    """Caller-supplied length limits, honoured (only absurd values are bounded)."""
    raw = payload.get("limits") if isinstance(payload.get("limits"), dict) else {}

    def resolve(key: str, default: int, low: int, high: int) -> int:
        try:
            value = int(raw.get(key))
        except (TypeError, ValueError):
            value = default
        return max(low, min(high, value))

    return {
        "maxTitle": resolve("maxTitle", _COPY_LIMIT_DEFAULTS["maxTitle"], 20, 300),
        "maxSubtitle": resolve("maxSubtitle", _COPY_LIMIT_DEFAULTS["maxSubtitle"], 20, 400),
        "minFeatures": resolve("minFeatures", _COPY_LIMIT_DEFAULTS["minFeatures"], 50, 2000),
    }


def _copy_attribute_pairs(attributes: Any) -> List[Tuple[str, str]]:
    pairs: List[Tuple[str, str]] = []
    if isinstance(attributes, dict):
        for name, value in attributes.items():
            pairs.append((str(name), str(value)))
    elif isinstance(attributes, list):
        for entry in attributes:
            if isinstance(entry, dict):
                name = entry.get("name") or entry.get("label") or entry.get("field")
                value = entry.get("value")
                if name is not None and value is not None:
                    pairs.append((str(name), str(value)))
            elif isinstance(entry, str) and entry.strip():
                if "=" in entry:
                    name, value = entry.split("=", 1)
                    pairs.append((name.strip(), value.strip()))
                else:
                    pairs.append(("Detail", entry.strip()))
    return [(name, value) for name, value in pairs if name and value]


def _bullet_lines(text: Any) -> List[str]:
    lines = []
    for raw in str(text or "").split("\n"):
        line = raw.strip()
        if not line:
            continue
        if not line.startswith("-"):
            line = "- " + line.lstrip("•*· ").strip()
        lines.append(line)
    return lines


def _copy_features(keywords: str, category: str, language: str,
                   attributes: Optional[List[Tuple[str, str]]] = None,
                   min_len: int = 200) -> str:
    """Deterministic `-`-prefixed Key Selling Features, always ≥ min_len characters."""
    subject = (keywords.split(",")[0].strip() if keywords else "") or "Product"
    attrs = "; ".join("{0}: {1}".format(name, value) for name, value in (attributes or [])[:8]) \
        or "see the product title and images for the confirmed specification set"
    pool = _COPY_FEATURE_LINES_ZH if language == "zh" else _COPY_FEATURE_LINES_EN
    lines: List[str] = []
    for template in pool:
        lines.append(template.format(subject=subject, category=category, attrs=attrs))
    text = "\n".join(lines)
    guard = 0
    while len(text) < min_len and guard < 40:
        text += "\n" + pool[-1].format(subject=subject, category=category, attrs=attrs)
        guard += 1
    return text


def _copy_box_contents(keywords: str, language: str,
                       attributes: Optional[List[Tuple[str, str]]] = None) -> str:
    subject = (keywords.split(",")[0].strip() if keywords else "") or "Product"
    lines = ["1 X {0}".format(subject)]
    if language == "zh":
        lines += ["1 X 使用说明书", "1 X 保修卡", "1 X 原厂包装盒"]
    else:
        lines += ["1 X User Manual", "1 X Warranty Card", "1 X Retail Packaging"]
    for name, value in (attributes or [])[:4]:
        if name.lower() in ("colour", "color", "size", "material", "model"):
            lines.append("1 X {0}: {1}".format(name, value))
    return "\n".join(lines)


def _ai_template(keywords: str, category: Optional[str], language: str,
                 limits: Optional[Dict[str, int]] = None,
                 attributes: Optional[List[Tuple[str, str]]] = None) -> Dict[str, Any]:
    limits = limits or dict(_COPY_LIMIT_DEFAULTS)
    max_title = int(limits.get("maxTitle") or _COPY_LIMIT_DEFAULTS["maxTitle"])
    max_subtitle = int(limits.get("maxSubtitle") or _COPY_LIMIT_DEFAULTS["maxSubtitle"])
    min_features = int(limits.get("minFeatures") or _COPY_LIMIT_DEFAULTS["minFeatures"])
    pairs = [(str(a[0]), str(a[1])) for a in (attributes or []) if isinstance(a, (tuple, list)) and len(a) == 2] \
        or _copy_attribute_pairs(attributes)
    kw_list = [k.strip() for k in re.split(r"[,;\n]", keywords or "") if k.strip()]
    subject = kw_list[0] if kw_list else "Product"
    category = category or _derive_category(subject)
    features = _copy_features(subject, category, language, pairs, min_features)
    box_contents = _copy_box_contents(subject, language, pairs)
    if language == "zh":
        title = "{0} - {1} 多功能适用款".format(subject, category.split(" ")[0])[:max_title]
        subtitle = "适合南非市场的{0}，兼顾耐用性与性价比".format(category)[:max_subtitle]
        bullets = [
            "{0}：选用经典方案，稳定耐用。".format(subject),
            "适配性：无需安装即可使用，适合日常场景。",
            "包装与发货：本地仓发货，支持快递与自提两种模式。",
            "售后：提供质保，支持退换货。",
        ]
        description = "【{0}】\n{1}\n\n优势：现货供应，从容应对南非旺季销量。".format(subject, subtitle)
    else:
        title = "{0} - {1} Durable Everyday Edition".format(subject, category.split(" ")[0])[:max_title]
        subtitle = "Reliable {0} built for South African homes and on-the-go use".format(category)[:max_subtitle]
        bullets = [
            "{0}: built around a proven design for stable daily performance.".format(subject),
            "Simple setup with no specialist tools required.",
            "Ships from a local warehouse with tracked courier delivery.",
            "Backed by a supplier warranty and easy Takealot returns.",
        ]
        description = "\n".join(
            ["**{0}**".format(subject), subtitle, ""] + ["- " + b for b in bullets]
            + ["", "Supplied ready for the Takealot marketplace with a compliant pack shot set."]
        )
    return {
        "title": title,
        "subtitle": subtitle,
        "bullets": bullets,
        "description": description,
        "keywords": kw_list[:12] or [subject],
        "features": features,
        "boxContents": box_contents,
        "featureLength": len(features),
        "limits": {"maxTitle": max_title, "maxSubtitle": max_subtitle, "minFeatures": min_features},
        "ai": False,
        "language": language,
    }


def _ai_listing_copy(payload: Dict[str, Any]) -> Dict[str, Any]:
    keywords = str(payload.get("keywords") or "").strip()
    category = payload.get("category")
    language = str(payload.get("language") or "en").lower()
    language = "zh" if language.startswith("zh") else "en"
    limits = _copy_limits(payload)
    attributes = payload.get("attributes")
    pairs = _copy_attribute_pairs(attributes)
    fallback = _ai_template(keywords, category, language, limits, pairs)
    key = _llm_key()
    _llm_b, _llm_m = _llm_base_model()
    if not key or not keywords:
        return fallback

    lang_label = "中文" if language == "zh" else "English"
    schema = '{"title":str,"subtitle":str,"bullets":[str],"features":str,"boxContents":str,"description":str,"keywords":[str]}'
    rules = (
        "Hard limits you MUST respect: title <= {0} characters, subtitle <= {1} characters, "
        "features (Key Selling Features) >= {2} characters as '- ' prefixed bullet lines, "
        "boxContents as one item per line in the form '1 X Item'. "
        "4-6 bullets, no superlatives (no best/cheapest/free shipping), no trademarked brand names "
        "unless supplied, no medical claims. Output language: {3}.\n"
        "Keywords: {4}\n"
        "Category: {5}\n"
        "Attributes: {6}"
    ).format(
        limits["maxTitle"], limits["maxSubtitle"], limits["minFeatures"], lang_label,
        keywords[:600], category or _derive_category(keywords),
        "; ".join("{0}: {1}".format(name, value) for name, value in pairs[:12]) or "(none supplied)",
    )
    prompt = (
        "You are a Takealot (South Africa) marketplace listing copywriter. "
        "Reply with JSON only: " + schema + ". " + rules
    )
    body = json.dumps(
        {
            "model": _llm_m,
            "messages": [
                {"role": "system", "content": "You write compliant Takealot marketplace listing copy."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.4,
            "max_tokens": 1400,
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        _llm_b + "/chat/completions",
        data=body,
        headers={
            "Authorization": "Bearer " + key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as resp:
            raw = resp.read().decode("utf-8", "replace")
        parsed = json.loads(raw)
        content = parsed["choices"][0]["message"]["content"]
        match = re.search(r"\{.*\}", content, re.S)
        data = json.loads(match.group(0) if match else content)
        features = "\n".join(_bullet_lines(data.get("features"))) or fallback["features"]
        if len(features) < limits["minFeatures"]:
            for line in fallback["features"].split("\n"):
                if len(features) >= limits["minFeatures"]:
                    break
                if line not in features:
                    features += "\n" + line
            guard = 0
            while len(features) < limits["minFeatures"] and guard < 30:
                features += "\n" + _COPY_FEATURE_LINES_EN[-1].format(
                    subject=keywords.split(",")[0].strip() or "Product",
                    category=(category or _derive_category(keywords)),
                    attrs="see the specification lines above")
                guard += 1
        box_contents = str(data.get("boxContents") or fallback["boxContents"]).strip()
        if not re.search(r"^\s*\d+\s*[xX]", box_contents):
            box_contents = fallback["boxContents"]
        out = {
            "title": str(data.get("title") or fallback["title"])[:limits["maxTitle"]],
            "subtitle": str(data.get("subtitle") or fallback["subtitle"])[:limits["maxSubtitle"]],
            "bullets": [str(b) for b in (data.get("bullets") or fallback["bullets"])][:8],
            "features": features,
            "boxContents": box_contents,
            "featureLength": len(features),
            "description": str(data.get("description") or fallback["description"]),
            "keywords": [str(k) for k in (data.get("keywords") or fallback["keywords"])][:20],
            "limits": limits,
            "ai": True,
            "model": _llm_m,
            "language": language,
        }
        return out
    except Exception as exc:
        fallback["ai"] = False
        fallback["ai_error"] = _sanitize("{0}: {1}".format(type(exc).__name__, exc))
        return fallback


# ── AI 文案：按「用户粘贴的参数描述（spec）」生成并回填 ────────────────────────
# 用户 2026-09-20：AI 文案卡片要给一个**大输入框**，商家把产品参数直接粘进去
# （例：微波炉 长宽高 56x45x32cm 功率 1000W 容量 25L 不锈钢内胆 带转盘），
# 后端只在这段文本里**真实出现过**的规格上写文案。
#
# 红线（验收项）：绝不编造 spec 里没有的功率/尺寸/材质/容量。三层落实：
#   1) 抽取：numericFacts 是 spec 原文里的「数字+单位」原样回显（不改写、不补全）；
#   2) 模板：模板句只使用抽到的规格，抽不到的字段留空并列入 missing；
#   3) 守卫：LLM 产出也要过 _spec_guard_text()，出现 spec 里没有的「数字+单位」
#      就删掉那一小段并在 basis / guardDropped 里点名（宁可少写，不许编）。
#
# 返回的 llm 字段：'agnes' = 真实 LLM 写出来的；'template' = 配了 Key 但调用失败，
# 回退模板；'none' = 没配 Key，模板文案且 basis 明说"未使用 AI"。

_SPEC_AGNES_BASE = "https://apihub.agnes-ai.com/v1"
_SPEC_AGNES_MODEL = "agnes-3.0-flash"
_SPEC_AGNES_KEY_ENVS = ("AGNES_NEW_KEY", "AGNES_API_KEY")
_SPEC_MAX_TITLE = 120

# 尺寸要整段抓（56x45x32cm 这种），否则单看「数字+单位」只会抓到末尾的 32cm。
_SPEC_DIM_RE = re.compile(
    r"\d+(?:[.,]\d+)?\s*[x×*X]\s*\d+(?:[.,]\d+)?(?:\s*[x×*X]\s*\d+(?:[.,]\d+)?)?"
    r"\s*(?:cm|mm|inches|inch|in)\b", re.I)
_SPEC_FACT_RE = re.compile(
    r"(\d+(?:[.,]\d+)?)\s*(kw|watts?|w|khz|hz|volts?|v|litres?|liters?|ml|l|cm|mm|kg|kilograms?"
    r"|grams?|g|lbs?|pounds?|mah|ah|amps?|amp(?:s|eres)?|hours?|hrs?|minutes?|mins?|seconds?|secs?)"
    r"\b", re.I)
_SPEC_EMOJI_RE = re.compile(
    "[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF\uFE0F\u200D\u2190-\u21FF\u2300-\u23FF]")
_SPEC_CJK_RE = re.compile("[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]")
_SPEC_PROMO_WORDS = ("best seller", "bestseller", "best", "cheapest", "cheap", "free shipping",
                     "free delivery", "sale", "hot deal", "hot sale", "discount", "buy now",
                     "promotion", "promotional", "clearance", "top quality", "hot selling")

# 单位归一：spec 写 1000W / 1000watts / 1000 W 都算同一个规格。
_SPEC_UNIT_CANON = {
    "w": "w", "watt": "w", "watts": "w", "kw": "kw",
    "hz": "hz", "khz": "khz",
    "v": "v", "volt": "v", "volts": "v",
    "l": "l", "litre": "l", "litres": "l", "liter": "l", "liters": "l", "ml": "ml",
    "cm": "cm", "mm": "mm",
    "kg": "kg", "g": "g", "gram": "g", "grams": "g", "lb": "lb", "lbs": "lb",
    "pound": "lb", "pounds": "lb",
    "mah": "mah", "ah": "ah", "amp": "a", "amps": "a", "ampere": "a", "amperes": "a",
    "hour": "h", "hours": "h", "hr": "h", "hrs": "h",
    "minute": "min", "minutes": "min", "min": "min", "mins": "min",
    "second": "s", "seconds": "s", "sec": "s", "secs": "s",
}
_SPEC_UNIT_KIND = {
    "w": "power", "kw": "power", "v": "voltage", "hz": "frequency", "khz": "frequency",
    "l": "capacity", "ml": "capacity", "cm": "length", "mm": "length",
    "kg": "weight", "g": "weight", "lb": "weight", "mah": "battery", "ah": "battery",
    "a": "current", "h": "time", "min": "time", "s": "time",
}
# 尺寸标签（中文）——只当标签剥掉，不当作家电规格。
_SPEC_LABELS = ("长宽高", "长x宽x高", "尺寸", "规格", "型号", "功率", "容量", "材质", "颜色",
                "净重", "毛重", "重量", "电压", "频率", "款号", "参数")

_SPEC_COLOURS = [("黑色", "Black"), ("白色", "White"), ("银色", "Silver"), ("灰色", "Grey"),
                 ("金色", "Gold"), ("粉色", "Pink"), ("红色", "Red"), ("蓝色", "Blue"),
                 ("绿色", "Green"), ("紫色", "Purple"), ("橙色", "Orange"), ("棕色", "Brown"),
                 ("香槟色", "Champagne"), ("black", "Black"),
                 ("white", "White"), ("silver", "Silver"), ("grey", "Grey"), ("gray", "Grey"),
                 ("gold", "Gold"), ("pink", "Pink"), ("red", "Red"), ("blue", "Blue"),
                 ("green", "Green"), ("purple", "Purple"), ("orange", "Orange"), ("brown", "Brown")]
_SPEC_MATERIALS = [("不锈钢", "Stainless Steel"), ("铝合金", "Aluminium Alloy"), ("碳纤维", "Carbon Fibre"),
                   ("塑料", "Plastic"), ("玻璃", "Glass"), ("陶瓷", "Ceramic"), ("硅胶", "Silicone"),
                   ("橡胶", "Rubber"), ("木质", "Wood"), ("木头", "Wood"), ("竹子", "Bamboo"),
                   ("铜", "Copper"), ("stainless steel", "Stainless Steel"),
                   ("aluminium", "Aluminium"), ("aluminum", "Aluminium"), ("plastic", "Plastic"),
                   ("glass", "Glass"), ("ceramic", "Ceramic"), ("silicone", "Silicone"),
                   ("wooden", "Wood"), ("carbon fibre", "Carbon Fibre"), ("carbon fiber", "Carbon Fibre")]
_SPEC_MATERIAL_TAILS = {"内胆": "Interior", "外壳": "Housing", "机身": "Body", "面板": "Panel",
                        "腔体": "Cavity", "材质": "", "material": ""}
_SPEC_FEATURES = [("带转盘", "turntable"), ("转盘", "turntable"), ("可拆卸", "removable parts"),
                  ("不粘", "non-stick coating"), ("定时", "timer"), ("遥控", "remote control"),
                  ("防干烧", "dry-boil protection"), ("数显", "digital display"),
                  ("保温", "keep-warm function"), ("静音", "quiet operation"),
                  ("节能", "energy-saving design"), ("可见窗", "visible window"),
                  ("turntable", "turntable"), ("removable", "removable parts"),
                  ("non-stick", "non-stick coating"), ("nonstick", "non-stick coating"),
                  ("timer", "timer"), ("remote control", "remote control"),
                  ("digital display", "digital display"), ("quiet", "quiet operation")]

_SPEC_NOUNS = {"微波炉": "Microwave", "烤箱": "Oven", "空气炸锅": "Air Fryer", "电饭煲": "Rice Cooker",
               "冰箱": "Refrigerator", "洗衣机": "Washing Machine", "洗碗机": "Dishwasher",
               "烧水壶": "Kettle", "电水壶": "Kettle", "水壶": "Kettle", "搅拌机": "Blender",
               "榨汁机": "Juicer", "咖啡机": "Coffee Machine", "电风扇": "Fan", "风扇": "Fan",
               "加湿器": "Humidifier", "吸尘器": "Vacuum Cleaner", "吹风机": "Hair Dryer",
               "电磁炉": "Induction Cooker", "三明治机": "Sandwich Maker", "烧烤炉": "Grill",
               "台灯": "Desk Lamp", "收纳盒": "Storage Box", "背包": "Backpack",
               "水杯": "Water Bottle", "保温杯": "Vacuum Flask", "鼠标": "Mouse", "键盘": "Keyboard",
               "充电器": "Charger", "数据线": "Charging Cable", "音箱": "Speaker", "耳机": "Earphones"}


def _spec_canon_fact(number: Any, unit: Any) -> str:
    """'1000' + 'W' → '1000w'：spec 与产出一视同仁地比对，避免大小写/空格误判。"""
    num = str(number or "").strip().replace(",", ".")
    return num + _SPEC_UNIT_CANON.get(str(unit or "").strip().lower(), str(unit or "").strip().lower())


def _spec_allowed_units(spec: str) -> Any:
    """spec 里真实出现的「数字+单位」白名单（canonical 形式），守卫生成的文案用。"""
    return {_spec_canon_fact(m.group(1), m.group(2)) for m in _SPEC_FACT_RE.finditer(str(spec or ""))}


def _spec_bad_tokens(text: str, allowed: Any) -> List[str]:
    """文案里出现、但 spec 里没有的「数字+单位」——这就是编造的规格。"""
    bad: List[str] = []
    for m in _SPEC_FACT_RE.finditer(str(text or "")):
        token = m.group(0).strip()
        if _spec_canon_fact(m.group(1), m.group(2)) not in allowed and token not in bad:
            bad.append(token)
    return bad


def _spec_strip_tokens(text: str, allowed: Any) -> Tuple[str, List[str]]:
    """只删掉编造的那一小段（标题用：整条删不可接受，标题必须有值）。"""
    out = str(text or "")
    dropped = _spec_bad_tokens(out, allowed)
    for token in dropped:
        out = out.replace(token, " ")
    if dropped:
        out = re.sub(r"[ \t]{2,}", " ", out)
        out = re.sub(r"([:;,])[ \t]*(?=[.;:,\n])", "", out)
        out = re.sub(r"[ \t]+([.;:,])", r"\1", out)
    return out.strip(), dropped


def _spec_drop_segments(text: str, allowed: Any, kind: str = "sentence") -> Tuple[str, List[str]]:
    """整句/整行删掉含编造规格的那一段（描述/卖点/盒子用：留着半句话比删掉更糟）。"""
    raw = str(text or "")
    if kind == "line":
        segments = raw.split("\n")
    else:
        segments = re.split(r"(?<=[.!?])\s+", raw)
    kept: List[str] = []
    dropped: List[str] = []
    for segment in segments:
        if not segment.strip():
            continue
        bad = _spec_bad_tokens(segment, allowed)
        if bad:
            for token in bad:
                if token not in dropped:
                    dropped.append(token)
            continue
        kept.append(segment.strip())
    sep = "\n" if kind == "line" else " "
    return sep.join(kept).strip(), dropped


def _spec_colour(text: str) -> Tuple[str, str]:
    """(spec 原文里的颜色词, 英文) —— spec 里没有就是 ('','')，绝不猜。"""
    low = text.lower()
    best: Tuple[str, str] = ("", "")
    for token, english in _SPEC_COLOURS:
        if _SPEC_CJK_RE.search(token):
            hit = token if token in text else ""
        else:
            hit = token if re.search(r"\b" + re.escape(token) + r"\b", low) else ""
        if hit and len(hit) > len(best[0]):
            best = (hit, english)
    return best


def _spec_material(text: str) -> Tuple[str, str]:
    """材质同理：只认 spec 里出现的词，连"内胆/外壳"这类词尾一起原样带出。"""
    low = text.lower()
    best: Tuple[str, str] = ("", "")
    for token, english in _SPEC_MATERIALS:
        if _SPEC_CJK_RE.search(token):
            idx = text.find(token)
        else:
            m = re.search(r"\b" + re.escape(token) + r"\b", low)
            idx = m.start() if m else -1
        if idx < 0:
            continue
        tail_raw = ""
        tail_en = ""
        after = text[idx + len(token): idx + len(token) + 8]
        for name, english_tail in _SPEC_MATERIAL_TAILS.items():
            if after.startswith(name):
                tail_raw, tail_en = name, english_tail
                break
        raw = token + tail_raw
        if len(raw) > len(best[0]):
            best = (raw, (english + (" " + tail_en if tail_en else "")).strip())
    return best


def _spec_features(text: str) -> List[Dict[str, str]]:
    """功能点：只收 spec 里真的出现的词（带转盘 → turntable 这类忠实翻译）。"""
    low = text.lower()
    out: List[Dict[str, str]] = []
    seen: List[str] = []
    for token, english in _SPEC_FEATURES:
        if english in seen:
            continue
        if _SPEC_CJK_RE.search(token):
            idx = text.find(token)
        else:
            m = re.search(r"\b" + re.escape(token) + r"\b", low)
            idx = m.start() if m else -1
        if idx > -1:
            seen.append(english)
            out.append({"raw": token, "en": english})
    return out[:6]


def _spec_subject(text: str) -> Tuple[str, str]:
    """spec 开头的产品名（'微波炉'）：只翻译词典里有的词，翻不出的不硬编。"""
    cut = len(text)
    for m in _SPEC_FACT_RE.finditer(text):
        cut = min(cut, m.start())
    for m in _SPEC_DIM_RE.finditer(text):
        cut = min(cut, m.start())
    for token, _english in _SPEC_MATERIALS + _SPEC_COLOURS + _SPEC_FEATURES:
        if _SPEC_CJK_RE.search(token):
            idx = text.find(token)
            if idx > -1:
                cut = min(cut, idx)
        else:
            m = re.search(r"\b" + re.escape(token) + r"\b", text.lower())
            if m:
                cut = min(cut, m.start())
    for label in _SPEC_LABELS:
        idx = text.find(label)
        if idx > -1:
            cut = min(cut, idx)
    head = text[:cut].strip(" ,，;；:：")
    words = [w for w in head.split() if w]
    raw = words[0] if words else ""
    english = ""
    for token, mapped in _SPEC_NOUNS.items():
        if raw and (token == raw or token in raw):
            english = mapped
            break
    if not english:
        # 头部没命中词典时，再从整段里找一次出现过的产品名（"304不锈钢微波炉"这种）。
        for token, mapped in sorted(_SPEC_NOUNS.items(), key=lambda kv: -len(kv[0])):
            if token in text:
                raw = raw or token
                english = mapped
                break
    return raw, english


def _spec_extract(spec: str) -> Dict[str, Any]:
    """spec → 规格字典。numericFacts 是原文「数字+单位」的原样回显。"""
    text = re.sub(r"\s+", " ", str(spec or "")).strip()
    dim_spans = [m.span() for m in _SPEC_DIM_RE.finditer(text)]
    facts: List[Dict[str, Any]] = []
    for m in _SPEC_DIM_RE.finditer(text):
        raw = m.group(0).strip()
        facts.append({"at": m.start(), "raw": raw, "kind": "dimensions",
                      "canon": re.sub(r"\s*[x×*X]\s*", "x", raw.lower())})
    for m in _SPEC_FACT_RE.finditer(text):
        inside = any(start <= m.start() < end for start, end in dim_spans)
        if inside:
            continue
        unit = _SPEC_UNIT_CANON.get(m.group(2).lower(), m.group(2).lower())
        facts.append({"at": m.start(), "raw": m.group(0).strip(), "kind": _SPEC_UNIT_KIND.get(unit, "other"),
                      "canon": _spec_canon_fact(m.group(1), m.group(2))})
    facts.sort(key=lambda f: f["at"])
    numeric: List[str] = []
    for f in facts:
        if f["raw"] not in numeric:
            numeric.append(f["raw"])

    def pick(kind: str) -> str:
        return next((f["raw"] for f in facts if f["kind"] == kind), "")

    colour_raw, colour_en = _spec_colour(text)
    material_raw, material_en = _spec_material(text)
    subject_raw, subject_en = _spec_subject(text)
    features = _spec_features(text)
    return {
        "spec": text,
        "dimensions": pick("dimensions"),
        "power": pick("power"),
        "capacity": pick("capacity"),
        "voltage": pick("voltage"),
        "frequency": pick("frequency"),
        "weight": pick("weight"),
        "colour": colour_raw,
        "colourEn": colour_en,
        "material": material_raw,
        "materialEn": material_en,
        "features": features,
        "subjectRaw": subject_raw,
        "subjectEn": subject_en,
        "numericFacts": numeric,
    }


def _spec_category_leaf(path: str) -> str:
    parts = [p.strip() for p in re.split(r"->|>|/", str(path or "")) if p.strip()]
    return parts[-1] if parts else ""


def _spec_clean_title(title: str) -> str:
    """Takealot 标题规则：无全大写词、无 emoji、无促销词、≤120 字符。"""
    text = _SPEC_EMOJI_RE.sub(" ", str(title or ""))
    text = re.sub(r"[\u2013\u2014|!*#~^_]+", " ", text)
    for word in _SPEC_PROMO_WORDS:
        text = re.sub(r"(?i)\b" + re.escape(word) + r"\b", " ", text)
    words: List[str] = []
    for word in text.split():
        if len(word) > 3 and word.isalpha() and word.isupper():
            word = word.capitalize()
        words.append(word)
    out = " ".join(words).strip(" ,-–")
    if len(out) > _SPEC_MAX_TITLE:
        cut = out[:_SPEC_MAX_TITLE]
        if " " in cut:
            cut = cut[:cut.rfind(" ")]
        out = cut.strip(" ,-–")
    return out


def _spec_template_copy(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """模板文案：每一句里的规格都必须能在 spec 里指出来，否则整句不写。"""
    leaf = str(ctx.get("categoryLeaf") or "").strip()
    subject = str(ctx.get("subjectEn") or "").strip() or leaf or "Product"
    subject_raw = str(ctx.get("subjectRaw") or "").strip()
    brand = str(ctx.get("brand") or "").strip()
    dims = str(ctx.get("dimensions") or "")
    power = str(ctx.get("power") or "")
    capacity = str(ctx.get("capacity") or "")
    material_en = str(ctx.get("materialEn") or "")
    material_raw = str(ctx.get("material") or "")
    colour_en = str(ctx.get("colourEn") or "")
    colour_raw = str(ctx.get("colour") or "")
    features = [f for f in (ctx.get("features") or []) if isinstance(f, dict)]

    title_bits = [brand, subject]
    if dims:
        title_bits.append(re.sub(r"\s*[x×*X]\s*", "x", dims))
    for value in (capacity, power):
        if value:
            title_bits.append(value)
    if material_en:
        title_bits.append(material_en)
    title = _spec_clean_title(" ".join(b for b in title_bits if b))

    sub_bits: List[str] = []
    if dims:
        sub_bits.append("{0} overall size".format(dims))
    if capacity:
        sub_bits.append("{0} capacity".format(capacity))
    if power:
        sub_bits.append("{0} rated power".format(power))
    if material_en:
        sub_bits.append(material_en.lower())
    subtitle = ("{0} for daily use, with {1}".format(subject, ", ".join(sub_bits[:3]))
                if sub_bits else "Reliable {0} for everyday use".format(subject))
    subtitle = subtitle[:110].strip()

    bullets: List[str] = ["{0} designed for daily use in the home.".format(subject)]
    if dims:
        bullets.append("Overall dimensions: {0}.".format(dims))
    if power:
        bullets.append("Rated power: {0}.".format(power))
    if capacity:
        bullets.append("Capacity: {0}.".format(capacity))
    if material_en:
        bullets.append("Material: {0}.".format(material_en))
    if colour_en:
        bullets.append("Colour: {0}.".format(colour_en))
    for f in features:
        bullets.append("Includes a {0}.".format(str(f.get("en") or "").strip()))
    bullets.append("Ships from a local warehouse with tracked courier delivery.")
    bullets.append("Backed by a supplier warranty and straightforward Takealot returns.")
    bullets.append("Please confirm the size, model and colour against your needs before ordering.")

    spec_lines: List[str] = []
    if dims:
        spec_lines.append("dimensions {0}".format(dims))
    if power:
        spec_lines.append("rated power {0}".format(power))
    if capacity:
        spec_lines.append("capacity {0}".format(capacity))
    if material_en:
        spec_lines.append("material {0}".format(material_en))
    if colour_en:
        spec_lines.append("colour {0}".format(colour_en))
    if spec_lines:
        spec_para = ("Confirmed specifications supplied with this product: "
                     + "; ".join(spec_lines) + ".")
    else:
        spec_para = ("No manufacturer specifications were supplied with this product, "
                     "so none are stated here.")
    feature_para = ("Included features: {0}.".format(", ".join(str(f.get("en")) for f in features))
                    if features else "")
    head = ("{0} {1}".format(brand, subject) if brand else subject).strip()
    description_parts = [
        "{0} built for everyday use.{1}".format(
            head, " Listed under {0}.".format(leaf) if leaf else ""),
        spec_para,
    ]
    if feature_para:
        description_parts.append(feature_para)
    description_parts.append(
        "Orders ship from a local warehouse with tracked courier delivery, and returns are handled "
        "through Takealot.")
    description_parts.append(
        "Only the specifications listed above were supplied by the seller; any figure that is not "
        "shown here was intentionally left out rather than estimated.")
    description = "\n\n".join(description_parts)

    box_lines = ["1 x {0}".format(subject)]
    for f in features:
        item = str(f.get("en") or "").strip()
        if item:
            box_lines.append("1 x {0}".format(item[:1].upper() + item[1:]))
    box_lines.append("1 x User Manual")
    box_lines.append("1 x Retail Packaging")
    note = ""
    if subject_raw and subject_raw != subject:
        note = "{0} → {1}".format(subject_raw, subject)
    return {
        "title": title,
        "subtitle": subtitle,
        "bullets": bullets,
        "description": description,
        "whatsInTheBox": "\n".join(box_lines),
        "subject": subject,
        "subjectRaw": subject_raw,
        "subjectNote": note,
        "specLines": spec_lines,
        "materialRaw": material_raw,
        "colourRaw": colour_raw,
    }


def _spec_llm_key() -> Optional[str]:
    """AI 文案用的 Key（没 Key 就如实返回 None，绝不用假数据顶替）。"""
    return _spec_llm_channel()[0]


# ---------------------------------------------------------------------------
# LLM 通道：优先跟随 Hermes 自己配置的 provider
#
# 客户可能用 阿里千问（DASHSCOPE_API_KEY / provider=alibaba）、DeepSeek、Agnes…
# 与其在 ERP 里逐个硬编码厂商，这里直接读 <HERMES_HOME>/config.yaml 的 model 段 +
# 该 provider 的 key 环境变量。换模型只改 Hermes 配置，ERP 不用动。
# ---------------------------------------------------------------------------

_LLM_KEY_ENV_BY_PROVIDER = {
    "alibaba": ("DASHSCOPE_API_KEY",),
    "alibaba-cn": ("DASHSCOPE_API_KEY",),
    "qwen": ("DASHSCOPE_API_KEY",),
    "dashscope": ("DASHSCOPE_API_KEY",),
    "aliyun": ("DASHSCOPE_API_KEY",),
    "alibaba-coding-plan": ("ALIBABA_CODING_PLAN_API_KEY", "DASHSCOPE_API_KEY"),
    "alibaba-coding-plan-cn": ("ALIBABA_CODING_PLAN_CN_API_KEY", "ALIBABA_CODING_PLAN_API_KEY",
                              "DASHSCOPE_API_KEY"),
    "alibaba-token-plan": ("ALIBABA_TOKEN_PLAN_API_KEY",),
    "alibaba-token-plan-cn": ("ALIBABA_TOKEN_PLAN_CN_API_KEY", "ALIBABA_TOKEN_PLAN_API_KEY"),
    "deepseek": ("DEEPSEEK_API_KEY",),
    "agnes": ("AGNES_NEW_KEY", "AGNES_API_KEY"),
    "agnes2": ("AGNES_NEW_KEY", "AGNES_API_KEY"),
    "openai": ("OPENAI_API_KEY",),
    "anthropic": ("ANTHROPIC_API_KEY",),
    "gemini": ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
    "xai": ("XAI_API_KEY",),
    "kimi": ("MOONSHOT_API_KEY", "KIMI_API_KEY"),
    "moonshot": ("MOONSHOT_API_KEY",),
    "zai": ("ZAI_API_KEY",),
    "minimax": ("MINIMAX_API_KEY",),
    "minimax-cn": ("MINIMAX_CN_API_KEY",),
    "openrouter": ("OPENROUTER_API_KEY",),
}

_LLM_BASE_BY_PROVIDER = {
    "alibaba": "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
    "alibaba-cn": "https://dashscope.aliyuncs.com/compatible-mode/v1",
    "qwen": "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
    "dashscope": "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
    "alibaba-coding-plan": "https://coding-intl.dashscope.aliyuncs.com/v1",
    "alibaba-coding-plan-cn": "https://coding.dashscope.aliyuncs.com/v1",
    "alibaba-token-plan": "https://token-plan.ap-southeast-1.maas.aliyuncs.com/compatible-mode/v1",
    "alibaba-token-plan-cn": "https://token-plan.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    "deepseek": DEEPSEEK_BASE,
    "agnes": _SPEC_AGNES_BASE,
    "agnes2": _SPEC_AGNES_BASE,
    "openai": "https://api.openai.com/v1",
    "xai": "https://api.x.ai/v1",
    "kimi": "https://api.moonshot.cn/v1",
    "zai": "https://open.bigmodel.cn/api/paas/v4",
    "minimax": "https://api.minimax.io/v1",
    "minimax-cn": "https://api.minimaxi.com/v1",
    "openrouter": "https://openrouter.ai/api/v1",
}


def _hermes_config_candidates() -> List[str]:
    """可能的 config.yaml 路径（HERMES_HOME / .env 同级 / STATE_DIR 三级上）。"""
    out: List[str] = []
    home = os.environ.get("HERMES_HOME")
    if home:
        out.append(os.path.join(home, "config.yaml"))
    for p in _env_candidates():
        out.append(os.path.join(os.path.dirname(str(p)), "config.yaml"))
    try:
        out.append(str(Path(STATE_DIR).resolve().parents[2] / "config.yaml"))
    except Exception:
        pass
    return out


def _yaml_block(text: str, key: str) -> Dict[str, Any]:
    """极简 YAML：取顶层 ``key:`` 段里的 直接子键（够用，避免强依赖 pyyaml）。"""
    out: Dict[str, Any] = {}
    lines = text.split("\n")
    start = None
    for i, raw in enumerate(lines):
        if re.match(r"^" + re.escape(key) + r"\s*:\s*$", raw):
            start = i + 1
            break
        m = re.match(r"^" + re.escape(key) + r"\s*:\s*(\S.*)$", raw)
        if m:  # 内联写法 key: {a: b} / key: value
            return {"__inline__": m.group(1).strip()}
    if start is None:
        return out
    for raw in lines[start:]:
        if raw.strip() == "" or raw.lstrip().startswith("#"):
            continue
        if not raw[0].isspace():
            break
        m = re.match(r"^\s+([A-Za-z_][A-Za-z0-9_.-]*)\s*:\s*(.*?)\s*$", raw)
        if m:
            out[m.group(1)] = m.group(2).strip().strip('"').strip("'")
    return out


def _yaml_nested(text: str, key: str) -> Dict[str, Dict[str, str]]:
    """取顶层 ``key:`` 段，解析成 {子块名: {子键: 值}}（两层，够 providers 用）。"""
    out: Dict[str, Dict[str, str]] = {}
    lines = text.split("\n")
    start = None
    for i, raw in enumerate(lines):
        if re.match(r"^" + re.escape(key) + r"\s*:\s*$", raw):
            start = i + 1
            break
    if start is None:
        return out
    cur = None
    for raw in lines[start:]:
        if raw.strip() == "" or raw.lstrip().startswith("#"):
            continue
        if not raw[0].isspace():
            break
        indent = len(raw) - len(raw.lstrip(" "))
        m = re.match(r"^\s+([A-Za-z_][A-Za-z0-9_.-]*)\s*:\s*(.*?)\s*$", raw)
        if not m:
            continue
        name, value = m.group(1), m.group(2).strip().strip('"').strip("'")
        if indent <= 2:
            cur = name
            out.setdefault(name, {})
            if value:
                out[name]["__value__"] = value
        elif cur:
            out[cur][name] = value
    return out


def _hermes_model_config() -> Dict[str, Any]:
    """读 <HERMES_HOME>/config.yaml 的 model 段 + providers 段（自定义 provider 用）。"""
    for path in _hermes_config_candidates():
        try:
            if not os.path.isfile(path):
                continue
            text = open(path, "r", encoding="utf-8", errors="replace").read()
        except Exception:
            continue
        model = _yaml_block(text, "model")
        if model:
            model["providers"] = _yaml_nested(text, "providers")
            model["__file__"] = path
            return model
    return {}


def _custom_provider_cfg(cfg: Dict[str, Any], name: str) -> Dict[str, str]:
    """``custom:<name>`` → config.yaml 里 providers.<name> 的 api / key_env。"""
    providers = cfg.get("providers")
    if not isinstance(providers, dict):
        return {}
    block = providers.get(name)
    if not isinstance(block, dict):
        return {}
    return {k: str(v) for k, v in block.items()}


def _configured_llm_channel() -> Optional[Tuple[str, str, str, str]]:
    """按 Hermes 自己配的 provider 解析 (key, base, model, label)；拿不到返回 None。"""
    cfg = _hermes_model_config()
    provider = str(cfg.get("provider") or "").strip()
    if not provider:
        return None
    envs = _load_env_file()

    def val(name: str) -> str:
        if not name:
            return ""
        return str(os.environ.get(name) or envs.get(name) or "").strip()

    low = provider.lower()
    custom = _custom_provider_cfg(cfg, low.split(":", 1)[1]) if low.startswith("custom:") else {}
    if custom:
        key_names = tuple(n for n in (custom.get("key_env"), custom.get("keyEnv")) if n)
        base_default = str(custom.get("api") or custom.get("base_url") or "").strip()
    else:
        key_names = _LLM_KEY_ENV_BY_PROVIDER.get(low) or ()
        base_default = _LLM_BASE_BY_PROVIDER.get(low, "")
    if not key_names:
        key_names = (re.sub(r"[^A-Z0-9]+", "_", low.upper()).strip("_") + "_API_KEY",)

    key = ""
    for name in key_names:
        key = val(name)
        if key:
            break
    if not key:
        return None

    base = str(cfg.get("base_url") or "").strip() or val(re.sub(r"[^A-Z0-9]+", "_", low.upper()).strip("_") + "_BASE_URL") or base_default
    if not base:
        return None

    model = str(cfg.get("default") or cfg.get("model") or "").strip()
    if not model:
        # 没写默认模型：用该 provider 的常见默认（只对少数已知厂商给，避免瞎猜）
        model = {"alibaba": "qwen3.8-max", "alibaba-cn": "qwen3.8-max", "qwen": "qwen3.8-max",
                 "dashscope": "qwen3.8-max", "deepseek": DEEPSEEK_MODEL,
                 "agnes": _SPEC_AGNES_MODEL, "agnes2": _SPEC_AGNES_MODEL}.get(low, "")
    if not model:
        return None
    return key, base, model, low


def _spec_llm_channel() -> Any:
    """解析 AI 文案要走的 LLM 通道：(key, base, model, label)。

    顺序：Agnes 环境变量/.env（原设计）→ 插件其它 AI 功能已经在用的 DeepSeek 通道。
    没有 Key 就返回 (None, None, None, None)，调用方走模板并如实标注。
    """
    # ① Hermes 自己配置的 provider（阿里千问 / DeepSeek / …）—— 换模型只改 Hermes 配置
    configured = _configured_llm_channel()
    if configured:
        return configured
    # ② 旧的 Agnes 环境变量
    for name in _SPEC_AGNES_KEY_ENVS:
        value = os.environ.get(name)
        if value and str(value).strip():
            return str(value).strip(), _SPEC_AGNES_BASE, _SPEC_AGNES_MODEL, "agnes"
    data = _load_env_file()
    for name in _SPEC_AGNES_KEY_ENVS:
        value = data.get(name)
        if value and str(value).strip():
            return str(value).strip(), _SPEC_AGNES_BASE, _SPEC_AGNES_MODEL, "agnes"
    # 回落：中译/其它 AI 功能用的 DeepSeek 通道（同一条，避免"有 Key 却报 none"）
    deepseek = _deepseek_key()
    if deepseek:
        return deepseek, DEEPSEEK_BASE, DEEPSEEK_MODEL, "deepseek"
    return None, None, None, None


def _spec_llm_copy(ctx: Dict[str, Any], template: Dict[str, Any], allowed: Any) -> Dict[str, Any]:
    """调 Agnes 生成文案（OpenAI 兼容）。只准用 spec 里的规格，产出还要过守卫。"""
    key, base, model, label = _spec_llm_channel()
    if not key:
        raise RuntimeError("no LLM key (Hermes 配置的 provider / AGNES_* / DeepSeek 都没有)")
    facts = ", ".join(ctx.get("numericFacts") or []) or "(none supplied)"
    lines = list(template.get("specLines") or []) or ["(none supplied)"]
    prompt = (
        "You are a Takealot (South Africa) marketplace listing copywriter. "
        "Write copy STRICTLY from the specification lines below — these are the only "
        "specifications that exist for this product.\n"
        "HARD RULES: never invent or estimate power, dimensions, capacity, material, colour, "
        "voltage, frequency or weight; if a specification is missing, do not mention it at all; "
        "you may only reuse these numeric facts verbatim: {0}.\n"
        "Title <= 120 characters, no ALL CAPS words, no emoji, no promotional or superlative "
        "words (best/cheapest/free shipping/sale). Subtitle <= 110 characters. "
        "description: formal English paragraphs. bullets: 4-6 plain sentences. "
        "whatsInTheBox: one item per line, every line in the exact form '1 x Item'.\n"
        "Reply with JSON only: "
        '{{"title":str,"subtitle":str,"description":str,"whatsInTheBox":str,"bullets":[str]}}\n'
        "Product: {1}\nBrand: {2}\nCategory: {3}\nConfirmation specs: {4}\nNumeric facts allowed: {5}"
    ).format(facts, ctx.get("subjectEn") or ctx.get("subjectRaw") or "Product",
             ctx.get("brand") or "(none supplied)", ctx.get("categoryLeaf") or "(none supplied)",
             "; ".join(lines), facts)
    body = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": "You write compliant Takealot marketplace listing copy."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.3,
        "max_tokens": 1200,
    }).encode("utf-8")
    req = urllib.request.Request(
        base + "/chat/completions",
        data=body,
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json",
                 "Accept": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as resp:
        raw = resp.read().decode("utf-8", "replace")
    parsed = json.loads(raw)
    content = str(parsed["choices"][0]["message"]["content"])
    match = re.search(r"\{.*\}", content, re.S)
    data = json.loads(match.group(0) if match else content)
    if not isinstance(data, dict):
        raise RuntimeError("LLM returned no JSON object")
    out = dict(template)
    applied: List[str] = []
    for field in ("title", "subtitle", "description", "whatsInTheBox"):
        value = str(data.get(field) or "").strip()
        if value:
            out[field] = value
            applied.append(field)
    bullets = [str(b).strip() for b in (data.get("bullets") or []) if str(b).strip()]
    if bullets:
        out["bullets"] = bullets[:6]
        applied.append("bullets")
    out["title"] = _spec_clean_title(out["title"])
    out["applied"] = applied
    return out


def _spec_basis(ctx: Dict[str, Any], template: Dict[str, Any]) -> List[str]:
    """依据说明：每条都能指回 spec 原文；抽不到的字段明说留空。"""
    basis: List[str] = []
    numeric = list(ctx.get("numericFacts") or [])
    if numeric:
        basis.append("spec 原文里的数字与单位（原样回显，文案只准使用这些）：" + "、".join(numeric))
    else:
        basis.append("spec 里没有出现任何「数字+单位」：文案不含任何规格数字。")
    if ctx.get("dimensions"):
        basis.append("尺寸：{0}（spec 原文，未改写）".format(ctx["dimensions"]))
    if ctx.get("power"):
        basis.append("功率：{0}（spec 原文，未改写）".format(ctx["power"]))
    if ctx.get("capacity"):
        basis.append("容量：{0}（spec 原文，未改写）".format(ctx["capacity"]))
    if ctx.get("material"):
        basis.append("材质：{0} → {1}（忠实翻译，非新增规格）".format(ctx["material"], ctx.get("materialEn")))
    if ctx.get("colour"):
        basis.append("颜色：{0} → {1}（spec 原文出现）".format(ctx["colour"], ctx.get("colourEn")))
    for f in (ctx.get("features") or []):
        basis.append("功能：{0} → {1}（spec 原文出现）".format(f.get("raw"), f.get("en")))
    if template.get("subjectNote"):
        basis.append("主体：{0}（词典翻译，原文照抄）".format(template["subjectNote"]))
    for field, label in (("colour", "颜色 Colour"), ("material", "材质 Material"),
                         ("power", "功率 Power"), ("dimensions", "尺寸 Dimensions"),
                         ("capacity", "容量 Capacity"), ("voltage", "电压 Voltage"),
                         ("weight", "重量 Weight")):
        if not ctx.get(field):
            basis.append("spec 未给出 {0}：该字段留空并列入 missing，未做任何猜测。".format(label))
    return basis


def _ai_copy_from_spec(payload: Dict[str, Any]) -> Dict[str, Any]:
    spec = str(payload.get("spec") or payload.get("specText") or payload.get("specs") or "").strip()
    category_path = str(payload.get("categoryPath") or payload.get("category") or "").strip()
    brand = str(payload.get("brand") or "").strip()
    leaf = _spec_category_leaf(category_path)
    empty = {"ok": False, "llm": "none", "llmProvider": "", "llmModel": "", "title": "", "subtitle": "",
             "description": "", "whatsInTheBox": "", "bullets": [], "features": "", "filled": [],
             "missing": ["title", "subtitle", "description", "whatsInTheBox"],
             "basis": ["spec 为空：请把产品参数描述粘贴到输入框后再生成。"],
             "specEcho": {"dimensions": "", "power": "", "capacity": "", "colour": "", "material": "",
                          "numericFacts": []},
             "guardDropped": []}
    if not spec:
        return empty

    ctx = _spec_extract(spec)
    ctx["brand"] = brand
    ctx["categoryLeaf"] = leaf
    kw_list = [str(k).strip() for k in (payload.get("keywords") or []) if str(k).strip()][:12]
    subj_note = ""
    if not (ctx.get("subjectEn") or ctx.get("subjectRaw")):
        # 参数描述里没有产品名时，用商家给的 keywords[0] 当主体名（不是规格，规格仍然只认 spec）。
        fallback_subject = ""
        for candidate in kw_list + [leaf]:
            if candidate:
                fallback_subject = candidate if candidate.isupper() else candidate[:1].upper() + candidate[1:]
                break
        if fallback_subject:
            ctx["subjectEn"] = fallback_subject
            ctx["subjectRaw"] = fallback_subject
            subj_note = fallback_subject
    allowed = _spec_allowed_units(spec)
    template = _spec_template_copy(ctx)
    basis = _spec_basis(ctx, template)
    if subj_note:
        basis.append("参数描述里没有产品名：主体名用 keywords/类目「{0}」（仅取名，规格仍只认 spec）。"
                     .format(subj_note))

    llm_state = "none"
    llm_provider = ""
    llm_model = ""
    applied: List[str] = []
    guard_dropped: List[str] = []
    copy = dict(template)
    _chan_key, _chan_base, _chan_model, _chan_label = _spec_llm_channel()
    if not _chan_key:
        llm_state = "none"
        basis.append("未配置任何 LLM Key（Hermes 配置的 provider / AGNES_NEW_KEY / AGNES_API_KEY / DeepSeek 都没有）："
                     "本次是模板文案，未使用 AI。")
    else:
        try:
            copy = _spec_llm_copy(ctx, template, allowed)
            # 如实标注实际通道（Agnes 环境变量 → DeepSeek 回落），不要硬写 agnes
            llm_state = _chan_label or "llm"
            llm_provider = _chan_label or "llm"
            llm_model = _chan_model or ""
            applied = list(copy.get("applied") or [])
            basis.append("LLM={0}（{1}）按 spec 生成；已过规格守卫：只用 spec 里出现的数字与单位。"
                         .format(llm_provider, llm_model))
        except Exception as exc:
            llm_state = "template"
            copy = dict(template)
            basis.append("LLM 调用失败（{0}）：已回退模板文案，未使用 AI 产出。".format(type(exc).__name__))

    result: Dict[str, Any] = {}
    guarded, dropped = _spec_strip_tokens(str(copy.get("title") or ""), allowed)
    result["title"] = guarded
    for token in dropped:
        if token not in guard_dropped:
            guard_dropped.append(token)
    # 标题必须有值：清洗后为空（或本来就没给）就退回模板标题。
    if not result["title"]:
        result["title"] = template["title"]
    for field, kind in (("subtitle", "sentence"), ("description", "sentence"),
                        ("whatsInTheBox", "line")):
        guarded, dropped = _spec_drop_segments(str(copy.get(field) or ""), allowed, kind)
        for token in dropped:
            if token not in guard_dropped:
                guard_dropped.append(token)
        if guarded:
            result[field] = guarded
        else:
            result[field] = template[field]
            if llm_state == "agnes":
                basis.append("{0}：LLM 产出全部含 spec 未给出的规格，已整段丢弃并回退模板。".format(field))
    # 盒子里有什么：只留官方 '1 x Item' 写法（LLM 写成 'Microwave x1' 这类一律丢掉）。
    box_lines: List[str] = []
    for line in str(result["whatsInTheBox"]).split("\n"):
        line = re.sub(r"^(\d+)\s*[Xx]\s+", r"\1 x ", line.strip())
        if re.match(r"^\d+\s*x\s+\S", line):
            box_lines.append(line)
    result["whatsInTheBox"] = "\n".join(box_lines) or template["whatsInTheBox"]
    bullets: List[str] = []
    for raw in (copy.get("bullets") or []):
        guarded, dropped = _spec_drop_segments(str(raw or ""), allowed, "sentence")
        for token in dropped:
            if token not in guard_dropped:
                guard_dropped.append(token)
        if guarded.strip():
            bullets.append(guarded.strip())
    result["bullets"] = bullets or list(template["bullets"])
    if guard_dropped:
        basis.append("守卫生效：文案里有 spec 未给出的规格，已删除这些片段 —— " + "、".join(guard_dropped))
    if llm_state == "agnes" and not applied:
        basis.append("LLM 未返回可用字段，已使用模板文案。")

    result["features"] = "\n".join("- " + b for b in bullets)
    result["title"] = result["title"][:_SPEC_MAX_TITLE].strip()

    out_fields = ("title", "subtitle", "description", "whatsInTheBox", "bullets")
    filled = [f for f in out_fields if result.get(f)]
    missing = [f for f in out_fields if not result.get(f)]
    for field, label in (("colour", "colour"), ("material", "material"), ("power", "power"),
                         ("dimensions", "dimensions"), ("capacity", "capacity"),
                         ("voltage", "voltage"), ("weight", "weight")):
        if not ctx.get(field):
            missing.append(label)
    return {
        "ok": bool(result.get("title")),
        "llm": llm_state,
        "llmProvider": llm_provider,
        "llmModel": llm_model,
        "title": result["title"],
        "subtitle": result["subtitle"],
        "description": result["description"],
        "whatsInTheBox": result["whatsInTheBox"],
        "boxContents": result["whatsInTheBox"],
        "bullets": bullets,
        "features": result["features"],
        "filled": filled,
        "missing": missing,
        "basis": basis,
        "specEcho": {
            "dimensions": ctx.get("dimensions") or "",
            "power": ctx.get("power") or "",
            "capacity": ctx.get("capacity") or "",
            "voltage": ctx.get("voltage") or "",
            "frequency": ctx.get("frequency") or "",
            "weight": ctx.get("weight") or "",
            "colour": ctx.get("colour") or "",
            "colourEn": ctx.get("colourEn") or "",
            "material": ctx.get("material") or "",
            "materialEn": ctx.get("materialEn") or "",
            "subject": ctx.get("subjectEn") or ctx.get("subjectRaw") or "",
            "features": [f.get("raw") for f in (ctx.get("features") or [])],
            "numericFacts": list(ctx.get("numericFacts") or []),
            "source": "spec（用户粘贴的参数描述，未做补全）",
        },
        "guardDropped": guard_dropped,
        "categoryPath": category_path,
        "brand": brand,
        "keywords": kw_list,
        "price": payload.get("price"),
        "language": "en",
        "generatedAt": _iso_now(),
    }


@router.post("/ai/listing-copy-from-spec")
def ai_listing_copy_from_spec(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """大输入框（用户粘贴的参数描述）→ 标题/副标题/描述/盒子里有什么。

    只使用 spec 里真实出现的规格；抽不到的字段返回空值并列入 missing。
    """
    payload = body if isinstance(body, dict) else {}
    return _safe(lambda: _ai_copy_from_spec(payload), _fallback({
        "ok": False, "llm": "none", "title": "", "subtitle": "", "description": "",
        "whatsInTheBox": "", "bullets": [], "filled": [], "missing": [],
        "basis": ["后端异常：未能按 spec 生成文案。"],
        "specEcho": {"dimensions": "", "power": "", "capacity": "", "colour": "", "material": "",
                     "numericFacts": []},
        "guardDropped": [],
    }))


@router.post("/buybox/rules")
def buybox_rules(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}

    def build() -> Dict[str, Any]:
        sku = str(payload.get("sku") or "").strip()
        if not sku:
            return {"ok": False, "error": "sku is required", "mode": "local"}
        rules = _rules_map()
        row = rules.get(sku) or {"sku": sku, "title": "", "auto": True}
        row["floorPrice"] = _r(payload.get("floorPrice") or row.get("floorPrice") or 0)
        if payload.get("ceilingPrice") is not None:
            row["ceilingPrice"] = _r(payload["ceilingPrice"])
        elif not row.get("ceilingPrice"):
            row["ceilingPrice"] = _r(row["floorPrice"] * 1.25)
        row["auto"] = bool(payload.get("auto", row.get("auto", True)))
        row["updatedAt"] = _iso_now()
        rules[sku] = row
        _write_state("rules.json", rules)
        return {"ok": True, "rule": row, "rules": list(rules.values()), "mode": "local"}

    return _safe(build, _fallback({"ok": False, "rule": None, "mode": "local"}))


@router.post("/buybox/apply")
def buybox_apply(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """跟价执行（试算/写回）。

    `skus` 限定范围；`targets` = {sku: 价格} 是**手填目标价**（优先于规则算出的目标价）——
    界面上那一列「目标价」以前只是装饰，改完价格点按钮其实发的还是规则价，操作员会以为
    自己手动跟了价。手填价仍然过底价熔断，并额外加一道偏差闸（默认 50%）防手滑。
    """
    payload = body or {}
    dry_run = bool(payload.get("dryRun", True))
    # the live PATCH must go to the store this request is scoped to (body storeId -> active)
    apply_store = str(payload.get("storeId") or payload.get("store_id") or "").strip()
    force = bool(payload.get("force"))

    def build() -> Dict[str, Any]:
        raw_targets = payload.get("targets") if isinstance(payload.get("targets"), dict) else {}
        manual = {str(k): _price_of(v) for k, v in raw_targets.items() if _price_of(v) is not None}
        skus = payload.get("skus")
        wanted = {str(s) for s in skus} if isinstance(skus, list) and skus else None
        try:
            max_dev = float(payload.get("maxDeviationPercent", 50) or 0)
        except (TypeError, ValueError):
            max_dev = 50.0
        # 候选必须来自**这次要写的那家店**：拿活跃店的候选去 PATCH 另一家店的 key，
        # 等于按 A 店的货架改了 B 店的价格（串店）。
        candidates = _candidates(apply_store or None)
        applied: List[Dict[str, Any]] = []
        skipped: List[Dict[str, Any]] = []
        logs = _price_log()
        stamp = _now().strftime("%H:%M:%S")
        for row in candidates:
            sku = str(row.get("sku") or "")
            if wanted and sku not in wanted:
                continue
            floor = _price_of(row.get("floorPrice"))
            my_price = _price_of(row.get("myPrice"))
            manual_target = manual.get(sku)
            target = manual_target if manual_target is not None else _price_of(row.get("targetPrice"))
            source = "manual" if manual_target is not None else "rule"
            # 没有目标价 = 这条还没有竞品证据（没抓过公开页）：跳过并说清原因，
            # 绝不让一条缺数据的行把整批 apply 弄崩（以前 None < None 抛异常，整批回 fallback）。
            if target is None:
                skipped.append({
                    "sku": sku, "tsin": row.get("tsin"), "source": source,
                    "reason": "没有目标价：这条还没有竞品价（先「采集」抓一次公开页），或直接在目标价列填一个数。",
                })
                continue
            entry = {
                "sku": sku,
                "tsin": row.get("tsin"),
                "fromPrice": my_price,
                "targetPrice": target,
                "floorPrice": floor,
                "dryRun": dry_run,
                "source": source,
            }
            if floor is not None and target < floor:
                entry["status"] = "blocked"
                entry["message"] = "目标价 R {0} 低于底价 R {1}，熔断保护已生效。".format(target, floor)
                log_type = "BLOCKED"
            elif (manual_target is not None and my_price and max_dev > 0
                  and abs(target - my_price) / my_price * 100.0 > max_dev and not force):
                entry["status"] = "blocked"
                entry["message"] = ("手填目标价 R {0} 相对现价 R {1} 偏差超过 {2:.0f}%（疑似手滑）；"
                                    "确认要这么改就带 force=true 再来一次。").format(target, my_price, max_dev)
                log_type = "BLOCKED"
            elif dry_run:
                entry["status"] = "dry-run"
                entry["message"] = "试算{0}：R {1} → R {2}。".format(
                    "（手填价）" if manual_target is not None else "（规则价）", row.get("myPrice"), target)
                log_type = "APPLIED"
            else:
                live_ok = True
                live_message = ""
                if _key_configured(apply_store):
                    _, err = _api_request("PATCH", "/offers/by_sku/{0}".format(sku), None,
                                          {"selling_price": target}, store_id=apply_store)
                    live_ok = err is None
                    live_message = err or ""
                entry["status"] = "applied" if live_ok else "blocked"
                entry["message"] = "已调价 R {0} → R {1}。".format(row.get("myPrice"), target) if live_ok else live_message
                log_type = "REPRICE_SUCCESS" if live_ok else "BLOCKED"
            applied.append(entry)
            logs.insert(0, {
                "time": stamp, "sku": sku, "tsin": row.get("tsin"), "type": log_type,
                "message": entry["message"],
                "storeId": apply_store or _effective_store(None)["storeId"],
            })
        changed = [e for e in applied if e.get("status") == "applied"]
        if changed and not dry_run:
            _write_state("price_log.json", logs[:80])
        apply_info = _effective_store(apply_store)
        return {
            "ok": True,
            "dryRun": dry_run,
            "applied": applied,
            "count": len(applied),
            "changed": len(changed),
            "blocked": [e for e in applied if e.get("status") == "blocked"],
            "skipped": skipped,
            "manualTargets": len(manual),
            "maxDeviationPercent": max_dev,
            "logs": logs[:20],
            "mode": "live" if (_key_configured(apply_store) and not dry_run) else "local",
            "storeId": apply_info["storeId"],
            "storeName": apply_info["storeName"],
            "storeScoped": not apply_info["storeScoped"],
            "basis": "候选与 PATCH 都限定在本次 storeId 那家店；手填目标价会覆盖规则价，仍需通过底价熔断与偏差闸。",
        }

    return _safe(build, _fallback({"ok": False, "dryRun": True, "applied": [], "count": 0, "mode": "local"}))


@router.post("/buybox/enrich")
def buybox_enrich(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """给 BuyBox 候选补竞品数据（公开页抓取），输入就是当前的筛选结果。

    为什么必须有：没有抓取缓存的行算不出目标价（action=nodata）。搜索补的是「找不到那一条」，
    这个补的是「找到了也没用」——真实店铺 1057 个 offer 里 1056 个没有公开页缓存，
    操作员看一整表「缺竞品数据」却没有任何入口去补，模块就只能当摆设。

    预算双闸：条数上限（默认 10，最大 {0}）+ 秒级时间预算（默认 25s），到点即停并说明；
    已经抓到过的行默认跳过（force=true 可重抓）。
    """.format(BUYBOX_ENRICH_MAX)
    payload = body if isinstance(body, dict) else {}
    started = time.time()

    def build() -> Dict[str, Any]:
        store_arg = str(payload.get("storeId") or payload.get("store_id") or "").strip()
        _bad_store = _unresolved_store_error(store_arg)
        if _bad_store:
            return _bad_store
        info = _effective_store(store_arg)
        sid = str(info.get("storeId") or "")
        q = str(payload.get("q") or "")
        only = str(payload.get("only") or "all")
        sort = str(payload.get("sort") or "gap")
        force = bool(payload.get("force"))
        try:
            budget = max(3.0, min(float(payload.get("budget") or 25.0), 120.0))
        except (TypeError, ValueError):
            budget = 25.0
        try:
            cap = max(1, min(int(payload.get("limit") or 10), BUYBOX_ENRICH_MAX))
        except (TypeError, ValueError):
            cap = 10

        terms = [t for t in q.lower().split() if t]
        rows = [r for r in _candidates(sid) if _buybox_match(r, terms) and _buybox_filter(r, only)]
        rows = _buybox_sort(rows, sort)
        # 只有带 PLID 的行能抓；没 PLID 的行不是失败，是这台店的 offer 映射问题，单独列出来。
        no_plid = [{"sku": r.get("sku"), "reason": "这条 offer 没有 PLID：无法定位公开页（先在商品管理刷新一次目录）"}
                   for r in rows if not r.get("plid")]
        candidates = [r for r in rows if r.get("plid")]
        # 默认只补「没有公开页记录」的行；已经抓过（含抓过但没竞品的独家行）不重复抓，
        # 否则每点一次都在烧流量去抓一批不会变的数据。要重抓就 force=true。
        pending = [r for r in candidates
                   if force or not (r.get("crawl") or {}).get("cached")]
        chosen = pending[:cap]
        deadline = started + budget
        results: List[Dict[str, Any]] = []
        failed: List[Dict[str, Any]] = []
        not_run: List[Dict[str, Any]] = []
        crawled = 0
        for row in chosen:
            raw_plid = str(row.get("plid") or "").strip()
            plid = raw_plid if raw_plid.upper().startswith("PLID") else "PLID{0}".format(raw_plid)
            if time.time() >= deadline:
                not_run.append({"sku": row.get("sku"), "plid": plid, "reason": "时间预算用尽（{0:.0f}s）".format(budget)})
                continue
            crawl = _crawl_target(plid, force=True) or {}
            product = crawl.get("product") if isinstance(crawl.get("product"), dict) else {}
            entry = {
                "sku": row.get("sku"), "plid": plid,
                "mode": crawl.get("mode"), "transport": crawl.get("transport"),
                "cached": bool(crawl.get("cached")),
                "competitorPrice": _price_of(product.get("lowestCompetitorPrice")) if product else None,
                "sellerCount": product.get("sellerCount") if product else None,
            }
            if product:
                crawled += 1
                # 抓完必须清进程内 memo（_CRAWL_MAP 默认 5s TTL），否则紧接着的重算读到的还是旧卡，
                # 界面刚点完「补竞品数据」照旧显示「缺竞品数据」。
                _crawl_map_bust()
            else:
                entry["error"] = crawl.get("error")
                failed.append({"sku": row.get("sku"), "plid": plid,
                               "reason": _sanitize(crawl.get("error")) or _sanitize(crawl.get("hint")) or "抓取无数据"})
            results.append(entry)

        # 抓完立刻用同一份缓存重算这些行的判定，把「补数据之后变成什么」如实带回去。
        after = {str(r.get("sku")): r for r in _candidates(sid)}
        for entry in results:
            row = after.get(str(entry.get("sku"))) or {}
            entry["action"] = row.get("action")
            entry["targetPrice"] = row.get("targetPrice")
            entry["hasBuybox"] = row.get("hasBuybox")
            entry["competitorPrice"] = row.get("competitorPrice")   # 与表格同一口径，不用爬取产物自己算
            entry["sellerCount"] = row.get("sellerCount") or entry.get("sellerCount")
            entry["note"] = _sanitize(row.get("note"))

        return {
            "ok": True,
            "mode": "live",
            "storeId": sid,
            "storeName": info["storeName"],
            "query": q, "only": only, "sort": sort,
            "matched": len(rows),
            "requested": len(chosen),
            "crawled": crawled,
            "unchanged": len(results) - crawled,
            "failed": failed,
            "noPlid": no_plid[:10],
            "notRun": not_run,
            "remaining": max(0, len(pending) - len(chosen)),
            "results": results,
            "budgetSeconds": budget,
            "elapsedSeconds": round(time.time() - started, 1),
            "basis": ("补数据 = 公开页（api.takealot.com）经 transport ladder 抓一次并写入速度缓存，"
                      "不碰 Seller Key、不改价；补完 action/目标价会当场重算。"
                      "预算 = 开抓下一条的截止时间，单条要翻评论页（常见 15–20s），所以总耗时可能略超预算。"),
            "hint": ("还剩 {0} 条没补：再点一次继续（每轮上限 {1} 条），或先用筛选把范围缩小到真的要跟价的那批。"
                     ).format(max(0, len(pending) - len(chosen)), BUYBOX_ENRICH_MAX),
        }

    return _safe(build, _fallback({"ok": False, "mode": "error", "results": [], "failed": []}))


@router.post("/competitor/track")
def competitor_track(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}

    def build() -> Dict[str, Any]:
        raw = str(payload.get("tsin") or payload.get("url") or "").strip()
        tsin = _derive_tsin(raw)
        if raw.upper().startswith("TSIN"):
            tsin = raw.upper()
        live = None
        live_error = None
        target_store = str(payload.get("storeId") or "").strip()
        if _key_configured(target_store):
            # There is no /offers/by_tsin endpoint (404 live) — match the seller's own
            # offers client-side, which also answers "do I already sell this?".
            match = _match_seller_offer({"tsin": tsin}, tsin, target_store)
            if match["matched"]:
                live = dict(match["offer"] or {})
                live["matchedBy"] = match["key"]
            else:
                live_error = match["error"]
        else:
            live_error = "未绑定 Seller X-API-Key：本店的 offer/价格匹配结果给不出来（快照只含公开页抓取记录）"
        snapshot = _competitor_snapshot(tsin, live=live)
        store_info = _effective_store(target_store)
        snapshot["storeId"] = store_info["storeId"]
        snapshot["storeName"] = store_info["storeName"]
        items = _competitor_rows()
        items = [i for i in items if i["tsin"] != tsin]
        items.insert(0, snapshot)
        _write_state("competitors.json", items)
        return {"ok": bool(snapshot.get("source") != "none"), "item": snapshot, "count": len(items),
                "live_error": live_error, "mode": "live",
                "empty": snapshot.get("source") == "none",
                "requires": None if snapshot.get("source") != "none" else "公开页抓取（点「采集」）",
                "storeId": store_info["storeId"], "storeName": store_info["storeName"],
                "storeScoped": not store_info["storeScoped"]}

    return _safe(build, _fallback({"ok": False, "item": None, "count": 0, "mode": "local"}))


@router.delete("/competitor/{tsin}")
def competitor_delete(tsin: str) -> Dict[str, Any]:
    def build() -> Dict[str, Any]:
        items = _competitor_rows()
        remaining = [i for i in items if str(i.get("tsin")) != str(tsin)]
        removed = len(items) - len(remaining)
        if removed:
            _write_state("competitors.json", remaining)
        return {"ok": removed > 0, "removed": removed, "tsin": tsin, "count": len(remaining), "mode": "local"}
    return _safe(build, _fallback({"ok": False, "removed": 0, "tsin": tsin, "mode": "local"}))


@router.post("/compliance/check")
def compliance_check_endpoint(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}
    info = _effective_store(payload.get("storeId") or payload.get("store_id"))
    return _safe(
        lambda: dict(
            compliance_check(str(payload.get("text") or ""), payload.get("category")),
            mode="local",
            storeId=info["storeId"],
            storeName=info["storeName"],
            storeScoped=not info["storeScoped"],
            note="合规词库是平台级规则（与店铺无关）；此处只回显请求作用域。",
        ),
        _fallback({"hits": [], "score": 0, "verdict": "pass", "suggestions": [], "mode": "local"}),
    )


@router.post("/settings/store")
def settings_store(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}

    def build() -> Dict[str, Any]:
        name = str(payload.get("name") or "").strip() or "Takealot Store"
        api_key = str(payload.get("apiKey") or "").strip()
        region = str(payload.get("region") or "ZA").upper()
        data = _store_data()
        stores = data.get("stores") or []
        store_id = str(payload.get("id") or "").strip()
        row = next((s for s in stores if str(s.get("id")) == store_id), None) if store_id else None
        if row is None:
            seq = len(stores) + 1
            taken = {str(s.get("id")) for s in stores}
            while "store-{0}".format(seq) in taken:
                seq += 1
            row = {"id": "store-{0}".format(seq), "createdAt": _iso_now(), "_key": "", "note": ""}
            stores.append(row)
        row["name"] = name
        row["region"] = region
        if api_key:
            row["_key"] = api_key
            row["note"] = "Key stored locally; sender is masked in every API response."
            status = "unverified"
            message = "Key stored. Press Test to validate it against the Marketplace API."
            if len(api_key) >= 10:
                live, err = _api_request("GET", "/status")
                if err is None:
                    status = "connected"
                    message = "Connected to Takealot Marketplace API v1."
                else:
                    status = "error"
                    message = err
            else:
                status = "error"
                message = "Key too short to be a valid Marketplace API v1 key."
            row["status"] = status
            row["lastChecked"] = _iso_now()
        else:
            row.setdefault("status", "unverified")
            message = "Store details updated without changing the key."
        data["stores"] = stores
        if payload.get("active", True):
            data["activeStoreId"] = row["id"]
        _write_state("stores.json", data)
        # 身份缓存以"空 storeId = 激活店"为键，切店/改店后立刻失效；否则 60 秒内
        # 自建·跟卖判定会拿着上一家店的身份去比。
        _IDENTITY_CACHE.clear()
        return {
            "ok": True,
            "message": message,
            "store": _public_store(row),
            "activeStoreId": data.get("activeStoreId", ""),
            "keyConfigured": _key_configured(),
            "mode": "local",
        }

    return _safe(build, _fallback({"ok": False, "store": None, "mode": "local"}))


@router.post("/settings/test")
def settings_test(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}

    def build() -> Dict[str, Any]:
        data = _store_data()
        stores = data.get("stores") or []
        store_id = str(payload.get("id") or data.get("activeStoreId") or "")
        row = next((s for s in stores if str(s.get("id")) == store_id), None) or (stores[0] if stores else None)
        if row is None:
            return {"ok": False, "message": "No store configured.", "seller": None, "mode": "local"}
        if not (row.get("_key") or _seller_key()):
            row["status"] = "unverified"
            row["lastChecked"] = _iso_now()
            _write_state("stores.json", data)
            return {
                "ok": False,
                "message": "No X-API-Key configured for {0}: this shop's live modules stay empty until a key is bound.".format(row.get("name", "")),
                "seller": None,
                "store": _public_store(row),
                "mode": "local",
            }
        live, err = _api_request("GET", "/status")
        if err is None:
            row["status"] = "connected"
            row["lastChecked"] = _iso_now()
            _write_state("stores.json", data)
            return {
                "ok": True,
                "message": "Connected to Takealot Marketplace API v1.",
                "seller": live,
                "store": _public_store(row),
                "mode": "live",
            }
        row["status"] = "error"
        row["lastChecked"] = _iso_now()
        _write_state("stores.json", data)
        return {
            "ok": False,
            "message": err,
            "seller": None,
            "store": _public_store(row),
            "mode": "local",
        }

    return _safe(build, _fallback({"ok": False, "message": "", "seller": None, "mode": "local"}))


@router.delete("/settings/store/{store_id}")
def settings_store_delete(store_id: str) -> Dict[str, Any]:
    def build() -> Dict[str, Any]:
        data = _store_data()
        stores = data.get("stores") or []
        remaining = [s for s in stores if str(s.get("id")) != str(store_id)]
        removed = len(stores) - len(remaining)
        data["stores"] = remaining
        if removed and str(data.get("activeStoreId")) == str(store_id):
            data["activeStoreId"] = remaining[0]["id"] if remaining else ""
        _write_state("stores.json", data)
        return {
            "ok": removed > 0,
            "removed": removed,
            "activeStoreId": data.get("activeStoreId", ""),
            "stores": [_public_store(s) for s in remaining],
            "mode": "local",
        }
    return _safe(build, _fallback({"ok": False, "removed": 0, "stores": [], "mode": "local"}))


@router.post("/settings/active")
def settings_active(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """Persist the store every other module is bound to."""
    payload = body or {}

    def build() -> Dict[str, Any]:
        data = _store_data()
        stores = data.get("stores") or []
        wanted = str(payload.get("storeId") or "").strip()
        row = next((s for s in stores if str(s.get("id")) == wanted), None)
        if row is None:
            return {
                "ok": False,
                "activeStoreId": data.get("activeStoreId", ""),
                "message": "未知店铺 id：{0}".format(wanted or "(空)"),
                "stores": [_public_store_list_row(s) for s in stores],
                "mode": "local",
            }
        data["activeStoreId"] = row["id"]
        _write_state("stores.json", data)
        # 身份缓存以"空 storeId = 激活店"为键，切店/改店后立刻失效；否则 60 秒内
        # 自建·跟卖判定会拿着上一家店的身份去比。
        _IDENTITY_CACHE.clear()
        return {
            "ok": True,
            "activeStoreId": row["id"],
            "store": _public_store_list_row(row),
            "stores": [_public_store_list_row(s) for s in stores],
            "message": "已把当前店铺切换为 {0}。".format(row.get("name", "")),
            "mode": "local",
        }

    return _safe(build, _fallback({"ok": False, "activeStoreId": "", "mode": "local"}))


@router.post("/collection/assign")
def collection_assign(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """`{ids:[], storeId|null}` — 分派（或解除分派）采集箱条目到某个店铺。"""
    payload = body or {}
    ids = payload.get("ids") if isinstance(payload.get("ids"), list) else []
    raw_store = payload.get("storeId")

    def build() -> Dict[str, Any]:
        items = _collection()
        wanted = {str(i) for i in ids} if ids else set()
        store = None
        if raw_store not in (None, "", "null"):
            store = _store_row(raw_store)
            if store is None:
                return {
                    "ok": False,
                    "message": "未知店铺 id：{0}".format(raw_store),
                    "items": [],
                    "stores": _public_store_list(),
                    "conflicts": _collection_conflicts(items),
                    "mode": "local",
                }
        changed: List[Dict[str, Any]] = []
        for item in items:
            if str(item.get("id")) not in wanted:
                continue
            item["assignedStoreId"] = str(store.get("id")) if store else None
            item["assignedStoreName"] = store.get("name") if store else None
            changed.append(_collection_row(item))
        if changed:
            _write_state("collection.json", items)
        rows = {str(r["id"]): r for r in changed}
        for row in rows.values():
            row["assignedStoreId"] = str(store.get("id")) if store else None
            row["assignedStoreName"] = store.get("name") if store else None
            row["storeName"] = store.get("name") if store else None
        conflicts = _collection_conflicts(items)
        matching = [c for c in conflicts if str(c.get("tsin")) in {str(r.get("tsin")) for r in changed}]
        return {
            "ok": True,
            "items": changed,
            "updated": len(changed),
            "storeId": str(store.get("id")) if store else None,
            "storeName": store.get("name") if store else None,
            "unassigned": store is None,
            "stores": _public_store_list(),
            "conflicts": conflicts,
            "conflictDetails": matching,
            "message": (
                "已分派 {0} 条到 {1}。".format(len(changed), store.get("name"))
                if store
                else "已解除 {0} 条的分派（未分派状态）。".format(len(changed))
            ),
            "mode": "local",
        }

    return _safe(build, _fallback({"ok": False, "items": [], "conflicts": [], "mode": "local"}))


# ── 一键上架（用户 2026-09-23 口径）────────────────────────────────────────────
# 一键上架 = 不分发，直接上到全部绑定店铺；已经上过的店**跳过并说明原因**。
# 要按店分发仍然走 /collection/assign（老逻辑不动）。
# 每一格（行 × 店）都走 offer_create_impl —— 与单个跟卖完全同一条校验/解析/写入/回读/审计路径。

#: 逐格结论的中文标签（界面直接用）
PUBLISH_STATUS_LABELS: Dict[str, str] = {
    "created": "已上架",
    "preview": "将上架（预览，未写入）",
    "skipped": "跳过",
    "failed": "失败",
}

#: 一次请求最多处理多少「行 × 店」（保护接口超时；超出的部分如实报 truncated）
PUBLISH_MAX_CELLS = 60

#: 上次一键上架结果落盘时保留多少行明细（够界面回看，不把 state 写胖）
PUBLISH_LAST_ITEMS = 20


def _listing_index(store_id: str) -> Dict[str, Any]:
    """该店现有 listing 的索引（barcode / TSIN / PLID / SKU → offer 行）。

    用于「店里有相同商品就跳过」。数据来自本店 live ``/offers``（与 /overview 同一份缓存）。
    取数失败时返回空索引 + error，由调用方如实说「无法确认是否已上架」，而不是当成没上过
    就去重复创建。
    """
    cache = _offer_rows(store_id)
    rows = cache.get("items") if isinstance(cache, dict) else None
    rows = rows if isinstance(rows, list) else []
    index: Dict[str, Dict[str, Any]] = {}
    for offer in rows:
        if not isinstance(offer, dict):
            continue
        for key in (str(offer.get("barcode") or "").strip().lower(),
                    _plid_of(offer.get("tsin_id")),
                    _plid_of(offer.get("productline_id")),
                    str(offer.get("sku") or "").strip().lower()):
            if key:
                index.setdefault(key, offer)
    return {"index": index, "count": len(rows),
            "error": (cache or {}).get("error"),
            "truncated": bool((cache or {}).get("truncated")),
            "storeName": (cache or {}).get("storeName")}


def _row_listing_hit(index: Dict[str, Dict[str, Any]], row: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """这一行在该店里是否已经存在（按 barcode / TSIN / SKU 任一命中）。"""
    for key in (str(row.get("barcode") or "").strip().lower(),
                _plid_of(row.get("tsin") or row.get("tsinId")),
                str(row.get("sku") or "").strip().lower()):
        if key and key in index:
            return index[key]
    return None


@router.post("/collection/publish-all")
def collection_publish_all(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """一键上架：把采集箱的行上到**全部绑定店铺**（也可只上指定几家店）。

    * 默认 ``dryRun=true``：只做校验与解析，回显每一格「将上架 / 跳过 + 原因」，不写平台；
    * ``dryRun=false``：真正 ``POST /offers``，逐格带回平台的回答（成功=201+回读，被拒=原文）；
    * 跳过原因来自平台数据：该店 live ``/offers`` 里已有同 barcode / TSIN / SKU 的 listing；
    * 成功后把结果写回采集箱行（``listedStores``），界面据此显示「已在 N 家店上架」。
    """
    payload = body if isinstance(body, dict) else {}
    ids = [str(x) for x in (payload.get("ids") or []) if str(x).strip()]
    wanted_stores = [str(x) for x in (payload.get("storeIds") or []) if str(x).strip()]
    dry_run = bool(payload.get("dryRun", True))
    try:
        stock_override = int(payload.get("stock")) if payload.get("stock") not in (None, "") else None
    except (TypeError, ValueError):
        stock_override = None

    def build() -> Dict[str, Any]:
        items = _collection()
        wanted_ids = {i for i in ids}
        selected = [i for i in items if not wanted_ids or str(i.get("id")) in wanted_ids]
        rows_all = [s for s in _stores() if isinstance(s, dict)]
        known = {str(s.get("id")) for s in rows_all}
        if wanted_stores:
            stores = [s for s in rows_all if str(s.get("id")) in set(wanted_stores)]
            unknown = [x for x in wanted_stores if x not in known]
        else:
            stores = [s for s in rows_all if _key_configured(str(s.get("id")))]
            unknown = []
        targets = []
        cells = 0
        truncated = False
        for row in selected:
            for store in stores:
                if cells >= PUBLISH_MAX_CELLS:
                    truncated = True
                    break
                cells += 1
                targets.append((row, store))
            if truncated:
                break

        indices: Dict[str, Dict[str, Any]] = {}
        for store in stores:
            sid = str(store.get("id"))
            if sid:
                indices[sid] = _listing_index(sid)

        api_calls = 0
        writes_sent = 0
        listed_map: Dict[str, List[Dict[str, Any]]] = {}
        per_row: Dict[str, Dict[str, Any]] = {}
        summary = {"created": 0, "preview": 0, "skipped": 0, "failed": 0, "partial": 0}
        for row, store in targets:
            sid = str(store.get("id"))
            sname = str(store.get("name") or sid)
            row_id = str(row.get("id"))
            entry = per_row.setdefault(row_id, {
                "id": row_id, "title": row.get("title") or "", "sku": row.get("sku") or "",
                "tsin": row.get("tsin") or "", "barcode": row.get("barcode") or "",
                "price": _r(row.get("estSalePrice") or 0), "stock": row.get("stock"),
                "stores": [],
            })
            price = row.get("estSalePrice")
            price_int = int(price) if isinstance(price, (int, float)) and float(price).is_integer() else None
            if price_int is None:
                try:
                    price_int = int(float(price)) if price not in (None, "") else None
                except (TypeError, ValueError):
                    price_int = None
            base = {"storeId": sid, "storeName": sname}
            if not price_int or price_int < 1:
                entry["stores"].append(dict(base, status="skipped",
                                            reason="采集箱这行没有可用售价（CreateOfferRequest 的 selling_price 必填，整数 ZAR ≥ 1），跳过"))
                summary["skipped"] += 1
                continue
            info = indices.get(sid) or {"index": {}, "error": None, "truncated": False}
            if info.get("error") and not info.get("count"):
                entry["stores"].append(dict(base, status="failed",
                                            reason="读不到「{0}」的 live /offers（{1}）：无法确认是否已上架，不冒重复创建的风险".format(sname, info.get("error"))))
                summary["failed"] += 1
                continue
            hit = _row_listing_hit(info["index"], row)
            if hit:
                entry["stores"].append(dict(
                    base, status="skipped",
                    reason="{0} 已上架（SKU {1}，Offer {2}），跳过".format(sname, hit.get("sku"), hit.get("offer_id")),
                    existingOfferId=hit.get("offer_id"), existingSku=hit.get("sku")))
                summary["skipped"] += 1
                continue

            request_payload: Dict[str, Any] = {
                "dryRun": dry_run,
                "storeId": sid,
                "selling_price": price_int,
            }
            if row.get("barcode"):
                request_payload["barcode"] = str(row.get("barcode"))
            if row.get("tsin"):
                request_payload["tsin"] = str(row.get("tsin"))
            stock = stock_override if stock_override is not None else row.get("stock")
            if isinstance(stock, (int, float)) and not isinstance(stock, bool):
                request_payload["seller_stock"] = int(stock)
            target = str(row.get("sku") or row.get("barcode") or row.get("tsin") or "")
            result = offer_create_impl(target, request_payload, sid, dry_run)
            api_calls += int(result.get("apiCalls") or 0)
            writes_sent += int(result.get("writesSent") or 0)
            created = result.get("createdOffer") or {}
            if dry_run:
                status = "preview" if result.get("ok") else "failed"
            else:
                status = "created" if result.get("ok") else "failed"
            summary[status] = summary.get(status, 0) + 1
            reason = None
            if status == "failed":
                reason = result.get("error") or "平台未创建 offer"
            elif status == "preview":
                reason = "预览：条码 {0}（{1}），售价 R{2}".format(
                    (result.get("request") or {}).get("barcode"),
                    (result.get("resolution") or {}).get("barcodeSource"), price_int)
            # 逐字段回读核对：创建成功 != 每个字段都落上了（实测 Apex Direct 会接受
            # seller_warehouse_stock 但回读为 []）。不把它说成「全绿」。
            applied = result.get("applied") or []
            partial = [a for a in applied if a.get("ok") is False]
            if status == "created" and partial:
                summary["partial"] += 1
                reason = "已创建（Offer {0}），但平台未接受：{1}".format(
                    created.get("offer_id"),
                    "；".join("{0} 请求 {1} / 回读 {2}".format(
                        a.get("field"), a.get("value"), a.get("actual")) for a in partial))
            entry["stores"].append(dict(
                base, status=status, reason=reason,
                offerId=created.get("offer_id"), platformSku=created.get("sku"),
                apiStatus=result.get("apiStatus"),
                barcodeUsed=(result.get("request") or {}).get("barcode"),
                barcodeSource=(result.get("resolution") or {}).get("barcodeSource"),
                applied=applied, partialApply=bool(partial)))
            if status == "created":
                listed_map.setdefault(row_id, []).append({
                    "storeId": sid, "storeName": sname, "offerId": created.get("offer_id"),
                    "sku": created.get("sku"), "price": price_int, "at": _iso_now(),
                })
                # 同一批里再来一条同条码的行，不应该重复创建
                key = str(created.get("barcode") or row.get("barcode") or "").strip().lower()
                if key:
                    info["index"][key] = created

        if listed_map and not dry_run:
            for item in items:
                extra = listed_map.get(str(item.get("id")))
                if not extra:
                    continue
                existing = item.get("listedStores") if isinstance(item.get("listedStores"), list) else []
                item["listedStores"] = existing + extra
                item["listedAt"] = _iso_now()
            _write_state("collection.json", items)

        notes: List[str] = []
        if truncated:
            notes.append("行 × 店 超过上限 {0}，本次只处理了前面的部分（剩下的请再点一次）".format(PUBLISH_MAX_CELLS))
        if not stores:
            notes.append("没有可上架的店铺：先在「多店铺设置」绑定店铺并填 Seller X-API-Key")
        if unknown:
            notes.append("未知店铺 id：{0}".format("、".join(unknown)))
        if dry_run:
            notes.append("这是预览（dryRun=true）：没有调用 POST /offers，也没有写审计日志")
        else:
            notes.append("已实际调用 POST /offers；每一格的结果与平台原文都落了审计（type OFFER_CREATE）")
        for sid, info in indices.items():
            if info.get("truncated"):
                notes.append("店铺 {0} 的 /offers 列表被安全上限截断：已上架判断可能不完整".format(sid))

        result = {
            "ok": True,
            "mode": "live",
            "dryRun": dry_run,
            "storeIds": [str(s.get("id")) for s in stores],
            "storeNames": {str(s.get("id")): str(s.get("name") or "") for s in stores},
            "rows": len(per_row),
            "cells": len(targets),
            "truncated": truncated,
            "summary": summary,
            "items": list(per_row.values()),
            "apiCalls": api_calls,
            "writesSent": writes_sent,
            # 「已上架就跳过」这一判断读了什么：每店的 listing 索引规模与取数状态
            "listingIndex": {sid: {"count": int(info.get("count") or 0),
                                   "error": info.get("error"),
                                   "truncated": bool(info.get("truncated"))}
                             for sid, info in indices.items()},
            "listingIndexSource": "各店 live /offers（缓存 ≤60s，与 /overview 同一份）",
            "audit": {"file": "state/{0}".format(OFFER_WRITES_FILE), "type": "OFFER_CREATE"},
            "notes": notes,
            "message": (("预览：将上架 {0} 格、跳过 {1} 格、失败 {2} 格"
                         if dry_run else
                         "已上架 {0} 格、跳过 {1} 格、失败 {2} 格").format(
                             summary.get("preview") or summary.get("created") or 0,
                             summary.get("skipped") or 0, summary.get("failed") or 0)
                        + ("；其中 {0} 格平台未接受部分字段".format(summary["partial"])
                           if summary.get("partial") else "")),
        }
        # 落盘「上次一键上架结果」：重开 App 也看得到，界面直接渲染这一份
        _write_state("publish_last.json", {
            "at": _iso_now(), "dryRun": dry_run, "message": result["message"],
            "summary": summary, "storeIds": result["storeIds"], "storeNames": result["storeNames"],
            "rows": result["rows"], "cells": result["cells"], "truncated": truncated,
            "listingIndex": result["listingIndex"], "notes": notes,
            "items": result["items"][:PUBLISH_LAST_ITEMS],
        })
        return result

    return _safe(build, _fallback({"ok": False, "items": [], "summary": {}, "mode": "live",
                                   "error": "一键上架内部错误"}))


@router.post("/collection/reanalyze")
def collection_reanalyze(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """`{ids:[], withAi?}` — re-crawl + re-value the selected 采集箱 rows."""
    payload = body or {}
    ids = payload.get("ids") if isinstance(payload.get("ids"), list) else []
    with_ai = bool(payload.get("withAi"))
    try:
        limit = int(payload.get("limit") or 10)
    except (TypeError, ValueError):
        limit = 10
    limit = max(1, min(limit, 10))

    def build() -> Dict[str, Any]:
        items = _collection()
        wanted = {str(i) for i in ids} if ids else {str(i.get("id")) for i in items}
        selected = [i for i in items if str(i.get("id")) in wanted][:limit]
        rows: List[Dict[str, Any]] = []
        pulled = 0
        failed = 0
        created = 0
        for item in selected:
            target = item.get("sourceUrl") or item.get("tsin")
            crawl = _crawl_target(target, force=True)
            product = crawl.get("product") if crawl.get("mode") == "live" else None
            if crawl.get("ok"):
                pulled += 1
            else:
                failed += 1
            if isinstance(product, dict):
                if product.get("price") and not item.get("estSalePrice"):
                    item["estSalePrice"] = _r(float(product["price"]))
                if product.get("title"):
                    item["title"] = str(product["title"])[:120]
                if product.get("brand"):
                    item["brand"] = product["brand"]
                if product.get("image"):
                    item["imageUrl"] = product["image"]
                if product.get("categoryPath"):
                    item["category"] = _canonical_category(product.get("categoryPath"))
                created += 1
            item["crawl"] = {
                "mode": crawl.get("mode"),
                "transport": crawl.get("transport"),
                "monthlySales": (crawl.get("sales") or {}).get("estimated_monthly_sales") if isinstance(crawl.get("sales"), dict) else None,
                "rate": crawl.get("rate"),
                "sellerCount": (product or {}).get("sellerCount"),
                "fetchedAt": crawl.get("fetchedAt"),
                "cached": bool(crawl.get("cached")),
            }
            item["lastAnalyzedAt"] = _iso_now()
            row = _collection_row(item)
            row["assignedStoreId"] = str(_item_store(item).get("id")) if _item_store(item) else None
            row["assignedStoreName"] = (_item_store(item) or {}).get("name")
            row["storeName"] = row["assignedStoreName"]
            row["crawl"] = dict(item["crawl"], windows=crawl.get("windows"), error=crawl.get("error"), hint=crawl.get("hint"))
            if with_ai:
                try:
                    row["analysis"] = _listing_analysis_payload(
                        {"target": target, "storeId": item.get("assignedStoreId"), "cost": item.get("cost"), "force": True},
                        crawl=crawl,
                        item=item,
                    )
                except Exception as exc:  # pragma: no cover - defensive
                    row["analysis"] = {"ok": False, "error": _sanitize(exc)}
            rows.append(row)
        if selected:
            _write_state("collection.json", items)
        return {
            "ok": True,
            "items": rows,
            "count": len(rows),
            "pulled": pulled,
            "failed": failed,
            "analyzed": sum(1 for r in rows if r.get("analysis")),
            "conflicts": _collection_conflicts(items),
            "hint": _crawler_hint() if failed else None,
            "mode": "local",
        }

    return _safe(build, _fallback({"ok": False, "items": [], "pulled": 0, "failed": 0, "mode": "local"}))


# --------------------------------------------------------------------------
# Crawler endpoints — public-API transport ladder (proxy → direct → blocked)
# plus drop-folder ingest (state/ingest/*.json). Never touches the Seller key.
# --------------------------------------------------------------------------

def _crawler_hint() -> str:
    module = _crawler()
    if module is None:
        return _crawler_unavailable()["hint"]
    try:
        return module.hint()
    except Exception:  # pragma: no cover - defensive
        return ""


@router.get("/crawler/status")
def crawler_status(probe: bool = False) -> Dict[str, Any]:
    def build() -> Dict[str, Any]:
        module = _crawler()
        if module is None:
            return _crawler_unavailable()
        return module.status_payload(probe=probe)

    return _safe(build, _fallback({"ok": False, "cacheEntries": 0, "hint": CRAWLER_HINT_STATIC}))


@router.get("/crawler/pull")
def crawler_pull_get(target: str = "", cachedOnly: bool = False, force: bool = False) -> Dict[str, Any]:
    """`GET /crawler/pull?target=…[&cachedOnly=1]` — cache-only when asked."""
    def build() -> Dict[str, Any]:
        module = _crawler()
        if module is None:
            return _crawler_unavailable()
        return module.pull(target, force=bool(force), cached_only=bool(cachedOnly))

    return _safe(build, _fallback({"ok": False, "mode": "blocked", "target": target, "hint": CRAWLER_HINT_STATIC}))


@router.post("/crawler/pull")
def crawler_pull(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}
    target = payload.get("target") or payload.get("url") or payload.get("plid") or payload.get("tsin") or ""
    cached_only = bool(payload.get("cachedOnly"))

    def build() -> Dict[str, Any]:
        module = _crawler()
        if module is None:
            return _crawler_unavailable()
        result = module.pull(target, force=bool(payload.get("force")), cached_only=cached_only)
        result["requestedTarget"] = target
        return result

    return _safe(build, _fallback({"ok": False, "mode": "blocked", "target": target, "hint": CRAWLER_HINT_STATIC}))


@router.post("/crawler/batch")
def crawler_batch(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}
    targets = payload.get("targets") if isinstance(payload.get("targets"), list) else []
    if not targets and payload.get("targets"):
        targets = [str(payload.get("targets"))]

    def build() -> Dict[str, Any]:
        module = _crawler()
        if module is None:
            return _crawler_unavailable()
        return module.batch_pull(
            targets,
            limit=payload.get("limit") or 10,
            force=bool(payload.get("force")),
        )

    return _safe(build, _fallback({"ok": False, "results": [], "blocked": 0, "failed": 0, "hint": CRAWLER_HINT_STATIC}))


@router.post("/crawler/ingest")
def crawler_ingest(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}

    def build() -> Dict[str, Any]:
        module = _crawler()
        if module is None:
            return _crawler_unavailable()
        result = module.ingest_payload(payload)
        result["ingestedAt"] = _iso_now()
        return result

    return _safe(build, _fallback({"ok": False, "mode": "blocked", "hint": CRAWLER_HINT_STATIC}))


@router.get("/crawler/cache")
def crawler_cache(limit: int = 50) -> Dict[str, Any]:
    def build() -> Dict[str, Any]:
        module = _crawler()
        if module is None:
            return _crawler_unavailable()
        items = module.cache_items(limit=limit)
        return {
            "ok": True,
            "count": len(items),
            "cachePath": str(STATE_DIR / module.cache_filename()),
            "cacheTtlDays": module.CACHE_TTL_DAYS,
            "transport": module.status_payload().get("transport"),
            "items": items,
        }

    return _safe(build, _fallback({"ok": False, "items": [], "count": 0}))


# --------------------------------------------------------------------------
# AI valuation — deterministic evidence first, DeepSeek second
# --------------------------------------------------------------------------

def _find_collection_item(target: Any) -> Optional[Dict[str, Any]]:
    plid = _plid_of(target)
    if not plid:
        return None
    for item in _collection():
        if _plid_of(item.get("tsin")) == plid or _plid_of(item.get("sourceUrl")) == plid:
            return item
    return None


# 旧的"抓不到公开页就用 ERP 自有记录合成一个商品"已删除：那正是假商品页的根因。
# 现在抓不到就返回 ok:false + 真实失败原因 + 空商品。


def _listing_analysis_payload(payload: Dict[str, Any], crawl: Optional[Dict[str, Any]] = None,
                              item: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    target = payload.get("target") or payload.get("plid") or payload.get("url") or payload.get("tsin") or ""
    store = _store_row(payload.get("storeId")) or _store_row(_store_data().get("activeStoreId")) or {}
    if crawl is None:
        crawl = _crawl_target(target, force=bool(payload.get("force")))
    item = item or _find_collection_item(target) or {}
    product = crawl.get("product") if isinstance(crawl.get("product"), dict) else None
    if not product:
        # 抓不到公开页就是没有商品可分析：明确失败，不合成商品、也不调 LLM 编结论
        return {
            "ok": False, "empty": True, "ai": False, "score": None, "verdict": None,
            "summary": "", "risks": [], "opportunities": [], "actions": [],
            "target": target, "product": None,
            "crawlMode": crawl.get("mode"), "transport": crawl.get("transport"),
            "error": crawl.get("error") or "公开页未取到该商品",
            "requires": "公开页可访问（或 /crawler/ingest 投放原始 JSON）",
            "hint": crawl.get("hint") or CRAWLER_HINT_STATIC,
            "note": "选品分析只认真实抓取结果：抓不到就不给结论（不用 ERP 记录拼一个商品再去问 AI）。",
        }
    product = dict(product)
    product["transport"] = crawl.get("transport")
    product["crawlMode"] = crawl.get("mode")
    windows = crawl.get("windows") if isinstance(crawl.get("windows"), dict) else None
    sales = crawl.get("sales") if isinstance(crawl.get("sales"), dict) else None
    money = _analysis_money(payload, product, item)
    module = _crawler()
    if module is None:
        return _crawler_unavailable()
    analysis = module.listing_analysis(
        product.get("plid") or target,
        store,
        product,
        windows,
        sales,
        money,
        key=payload.get("key") or _llm_key(),
        use_cache=not bool(payload.get("force")),
        force=bool(payload.get("force")),
        ai_enabled=payload.get("ai") is not False,
    )
    analysis["ok"] = True
    analysis["target"] = target
    analysis["crawlMode"] = crawl.get("mode")
    analysis["transport"] = crawl.get("transport")
    analysis["product"] = product
    analysis["windows"] = analysis.get("evidence", {}).get("windows") or windows
    if not crawl.get("ok"):
        analysis["crawlError"] = crawl.get("error")
        analysis["hint"] = crawl.get("hint")
    return analysis


@router.post("/ai/listing-analysis")
def ai_listing_analysis(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    payload = body or {}

    def build() -> Dict[str, Any]:
        info = _effective_store(payload.get("storeId") or payload.get("store_id"))
        out = _listing_analysis_payload(payload)
        if isinstance(out, dict):
            out.update({"storeId": info["storeId"], "storeName": info["storeName"],
                        "storeScoped": not info["storeScoped"]})
        return out

    return _safe(build, _fallback({
        "ok": False, "ai": False, "score": 0, "verdict": "观望", "summary": "", "risks": [],
        "opportunities": [], "actions": [], "evidence": {}, "hint": CRAWLER_HINT_STATIC,
    }))


@router.get("/ai/listing-analysis")
def ai_listing_analysis_cached(target: str = "", storeId: str = "", cachedOnly: bool = True) -> Dict[str, Any]:
    """Cache-only read of the 24 h analysis cache — never calls the LLM."""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        module = _crawler()
        if module is None:
            return _crawler_unavailable()
        store = _store_row(storeId) or _store_row(_store_data().get("activeStoreId")) or {}
        result = module.cached_analysis(target, store.get("id"))
        result["requestedTarget"] = target
        result["storeId"] = store.get("id")
        return result

    return _safe(build, _fallback({"ok": False, "ai": None, "target": target, "mode": "empty"}))


# --------------------------------------------------------------------------
# 商品管理 (CONTRACT v4) — 全店商品映射
#
# The store's own catalogue, mapped from the Seller API ``/offers`` list with the
# warehouse-stock ``expands`` (the array param only works because ``_api_request``
# repeats the key — see ``urlencode(doseq=True)``), enriched from the crawler's
# local cache (full product card + velocity cache), joined against the ERP's own
# records (上架草稿 / 采集箱 / BuyBox 调价日志 / 合规词库) and flagged for content
# completeness. Read-only: nothing here writes to Takealot.
#
#   GET  /products            the whole catalogue + stats + filters/sort/paging
#   GET  /products/stats      the same counters standalone
#   GET  /products/{sku}      one product: full text, images, attributes, local
#   POST /products/enrich     bounded cache-first crawl enrichment (≤20/call)
#   POST /collection/refresh  采集箱 image/full-text/category/sellRoute backfill
# --------------------------------------------------------------------------

OFFER_EXPANDS: Tuple[str, ...] = ("seller_warehouse_stock", "takealot_warehouse_stock")
OFFERS_TTL = 300.0
# Memo window for the MAPPED catalogue (compliance scan + crawl-card join over every offer).
# Was 5s, which meant a ~20s CPU rebuild on practically every request on a 1300-offer account.
# Writes bust this explicitly (_bust_offer_caches / _crawl_map_bust), so a window matching the
# raw offers cache is safe and removes the rebuild storm.
CATALOG_MEMO_TTL = 300.0          # the UI's filters must not hammer the Seller API
OFFERS_FAIL_TTL = 20.0     # retry sooner after a failed call
CRAWL_MAP_TTL = 5.0        # one velocity-cache file read shared by a whole request
ENRICH_MAX = 20            # contract: bounded (≤20 per call)
REFRESH_MAX = 40           # bounded collection refresh per call
# CONTRACT v6 addendum: the real shop has >1000 offers, so one `/offers` page is NOT
# the account's catalogue. Page to the end (offer_id__gt cursor) under safety caps and
# report `mapped`/`truncated` honestly instead of letting `total` become the page size.
OFFERS_PAGE_LIMIT = 1000   # the API's own per-call ceiling
OFFERS_HTTP_TIMEOUT = 45.0  # a 1000-row page with both stock expands is slow but legal
OFFERS_MAX_ROWS = 20000    # safety cap on the fetched catalogue
OFFERS_MAX_PAGES = 25      # safety cap on the pagination loop

STATUS_LABELS: Dict[str, str] = {
    "buyable": "可售",
    "not_buyable": "不可售",
    "disabled_by_seller": "卖家下架",
    "disabled_by_takealot": "平台下架",
}

MISSING_LABELS: Dict[str, str] = {
    "image": "缺主图",
    "barcode": "缺条码",
    "category": "缺类目",
    "text": "缺文案",
}

# The offers list is cached PER STORE (``_OFFERS_BY_STORE`` + ``_offers_cache()``): two
# bound shops must never share one list (addendum 2 §2).
_CRAWL_MAP: Dict[str, Any] = {"at": 0.0, "entries": {}}


# --------------------------------------------------------------------------
# 商品 Offer 写入 (CONTRACT v5) — 公共主数据 / 自建-跟卖 / 卖家可编辑参数
#
# Live-verified on this account: the Seller API can ONLY write ``selling_price`` /
# ``rrp`` / ``minimum_leadtime_days`` / ``seller_warehouse_stock`` through
# ``PATCH /offers/by_sku/{sku}`` (``additionalProperties:false`` — any other key is
# a 400). There is no 上下架 field at all and ``seller_warehouse_id`` is assigned
# by Takealot, so the write path refuses every other key locally, in Chinese,
# BEFORE it calls the API. Platform (Takealot) warehouse stock is read-only.
# --------------------------------------------------------------------------

OFFER_WRITES_FILE = "offer_writes.json"
OFFER_WRITES_MAX = 300        # audit rows kept (newest first)
SELLER_TTL = 600.0            # /seller (capabilities + identity): one call per 10 min
REGIONS_TTL = 3600.0          # /facilities/get_enabled_regions
REGION_ID_FALLBACK: Dict[str, int] = {"CPT": 1, "JHB": 3, "DBN": 6}

#: 本地可编辑字段 → Seller API PATCH 字段 + 校验规则（v5 的五个可编辑字段）
OFFER_WRITE_RULES: Dict[str, Dict[str, Any]] = {
    "selling_price": {"api": "selling_price", "label": "售价 (ZAR)", "min": 1, "max": None,
                      "unit": "R", "hint": "整数 ZAR，最低 R 1"},
    "rrp": {"api": "rrp", "label": "建议零售价 RRP (ZAR)", "min": 1, "max": None,
            "unit": "R", "hint": "整数 ZAR；API 不接受 0，清空 RRP 请在 Seller Portal 操作"},
    "seller_stock": {"api": "seller_warehouse_stock", "label": "卖家自营仓库存", "min": 0, "max": None,
                     "unit": "件", "hint": "非负整数，写的是本店 Seller Warehouse 的可用数"},
    "minimum_leadtime_days": {"api": "minimum_leadtime_days", "label": "备货期", "min": -1, "max": 30,
                              "unit": "天", "hint": "0–30 天；-1 = FBT/现货托管，原样透传"},
}

#: 只读/不可写字段 → 中文拒绝话术（绝不出现在 PATCH body 里）
UNWRITABLE_OFFER_KEYS: Dict[str, str] = {
    "status": "上下架状态：该账号未开通 API 上下架（disable_listing_enabled=false），请在 Seller Portal 操作",
    "disabled_by_seller": "上下架状态：该账号未开通 API 上下架（disable_listing_enabled=false），请在 Seller Portal 操作",
    "disabled_by_takealot": "平台下架开关：只有 Takealot 能设置，卖家不可写",
    "takealot_warehouse_stock": "Takealot 托管仓库存为只读：入仓/调仓请走 Seller Portal 或入库计划",
    "seller_warehouse_id": "卖家仓 ID 由 Takealot 分配（readOnly），不可写",
    "offer_id": "Offer ID 由平台分配（只读）",
    "sku": "SKU 由 URL 路径指定，body 里不要重复传",
    "weight_grams": "重量/尺寸属于 Listing 公共主数据，只能走 Loadsheet 人工 QC",
    "title": "标题属于 Listing 公共主数据，只能走 Loadsheet 人工 QC",
    "barcode": "条码属于 Listing 公共主数据，只能走 Loadsheet 人工 QC",
    "selling_price_inc_vat": "不认识的字段（API 只接受 selling_price / rrp / seller_stock / minimum_leadtime_days）",
}

#: FBT 仓储费档位 —— 官方按「包装体积 cm³」定档，35 天以内动销的库存免费（R0）。
#: 平台 API 不返回档位字段（``storage_fee_eligible`` 只说明该 offer 是否计入仓储计费），
#: 所以档位按 offer 自己的包装尺寸推算，金额取官方价目表（不含 VAT），
#: 依据写在 ``storageTier.basis`` 里。数据来自 data/takealot_fees_official.json。
FBT_STORAGE_TIERS: List[Dict[str, Any]] = [
    {"code": "SMALL", "label": "Small（≤60 000 cm³）", "volumeMinCm3": 0, "volumeMaxCm3": 60000,
     "monthlyFee": 4},
    {"code": "STANDARD", "label": "Standard（60 001–130 000 cm³）", "volumeMinCm3": 60001,
     "volumeMaxCm3": 130000, "monthlyFee": 12},
    {"code": "LARGE", "label": "Large（130 001–200 000 cm³）", "volumeMinCm3": 130001,
     "volumeMaxCm3": 200000, "monthlyFee": 25},
    {"code": "XL", "label": "Extra Large（200 001–275 000 cm³）", "volumeMinCm3": 200001,
     "volumeMaxCm3": 275000, "monthlyFee": 45},
    {"code": "OVERSIZE", "label": "Oversize（275 001–545 000 cm³）", "volumeMinCm3": 275001,
     "volumeMaxCm3": 545000, "monthlyFee": 150},
    {"code": "BULKY", "label": "Bulky（545 001–775 000 cm³）", "volumeMinCm3": 545001,
     "volumeMaxCm3": 775000, "monthlyFee": 250},
    {"code": "EXTRA_BULKY", "label": "Extra Bulky（> 775 000 cm³）", "volumeMinCm3": 775001,
     "volumeMaxCm3": None, "monthlyFee": 450},
]
STORAGE_TIER_NOTE = (
    "官方仓储费按包装体积 cm³ 定档，35 天以内库存周转免费（R0）；"
    "只有超龄库存（35+ 天）才按档位收费。平台 API 不提供档位字段，档位按 offer 的"
    "尺寸推算（volumetric basis），金额取官方价目表且不含 VAT。"
    "storage_fee_eligible=false 表示该 offer 当前未计入 Takealot 仓储计费。"
)
PLATFORM_STOCK_NOTE = "Takealot 托管仓库存为只读：入仓/调仓请走 Seller Portal 或入库计划"

# Both are ACCOUNT-level reads, so they are cached per store (two bound shops have
# different seller ids / capability switches — addendum 2 §2).
_SELLER_BY_STORE: Dict[str, Dict[str, Any]] = {}
_REGIONS_BY_STORE: Dict[str, Dict[str, Any]] = {}


def _seller_cache(store_id: Any = None) -> Dict[str, Any]:
    info = _effective_store(store_id)
    return _SELLER_BY_STORE.setdefault(info["storeId"] or "__none__", {
        "at": 0.0, "ttl": SELLER_TTL, "data": {}, "error": None, "source": "empty",
        "storeId": info["storeId"], "storeName": info["storeName"]})


def _regions_cache(store_id: Any = None) -> Dict[str, Any]:
    info = _effective_store(store_id)
    return _REGIONS_BY_STORE.setdefault(info["storeId"] or "__none__", {
        "at": 0.0, "ttl": REGIONS_TTL, "data": {}, "error": None, "source": "empty",
        "storeId": info["storeId"], "storeName": info["storeName"]})


def _crawl_ttl_days() -> float:
    module = _crawler()
    try:
        return float(getattr(module, "CACHE_TTL_DAYS", 5.0) or 5.0)
    except Exception:  # pragma: no cover - defensive
        return 5.0


def _crawl_entries() -> Dict[str, Dict[str, Any]]:
    """``{plid: {entry, fresh, ageDays}}`` for every cached crawl card — one file read.

    The velocity cache keeps the full product card under ``entry['product']`` (the
    ``cache_items`` projection drops it), so reading the file once and indexing it by
    PLID is both cheaper and richer than 31 ``pull(cached_only=True)`` calls.
    """
    now = time.time()
    if _CRAWL_MAP["entries"] and (now - _CRAWL_MAP["at"]) < CRAWL_MAP_TTL:
        return _CRAWL_MAP["entries"]
    module = _crawler()
    raw: Dict[str, Any] = {}
    if module is not None:
        try:
            raw = module.cache_load() or {}
        except Exception:  # pragma: no cover - defensive
            raw = {}
    ttl_days = _crawl_ttl_days()
    now_ms = now * 1000.0
    entries: Dict[str, Dict[str, Any]] = {}
    for key, entry in (raw or {}).items():
        if not isinstance(entry, dict):
            continue
        product = entry.get("product")
        if not isinstance(product, dict) or not product:
            continue
        try:
            fetched = float(entry.get("fetchedAtMs") or 0)
        except (TypeError, ValueError):
            fetched = 0.0
        age_days = ((now_ms - fetched) / 86400000.0) if fetched else 1e9
        entries[str(key)] = {"entry": entry, "fresh": age_days <= ttl_days, "ageDays": round(age_days, 3)}
    _CRAWL_MAP["at"] = now
    _CRAWL_MAP["entries"] = entries
    return entries


def _crawl_map_bust() -> None:
    """Drop the memo after a write (enrich / crawl refresh) so reads see the new card."""
    _CRAWL_MAP["at"] = 0.0
    _CRAWL_MAP["entries"] = {}
    _CATALOG_BY_STORE.clear()


def _cached_card(plid: Any, entries: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """The cached crawl card for a PLID (cache-shaped, ``cached`` False when absent)."""
    empty = {"product": {}, "windows": {}, "sales": {}, "rate": None, "rateSource": None,
             "fetchedAt": None, "transport": None, "cached": False, "fresh": False, "ageDays": None}
    number = _plid_of(plid)
    if not number:
        return empty
    entries = _crawl_entries() if entries is None else entries
    record = entries.get(number)
    if not record:
        return empty
    entry = record.get("entry") or {}
    module = _crawler()
    payload: Dict[str, Any] = {}
    if module is not None:
        try:
            payload = module.payload_from_entry(entry, "PLID" + number, cached=True) or {}
        except Exception:  # pragma: no cover - defensive
            payload = {}
    product = payload.get("product") if isinstance(payload.get("product"), dict) else entry.get("product")
    sales = payload.get("sales") if isinstance(payload.get("sales"), dict) else (entry.get("sales") or {})
    windows = payload.get("windows") if isinstance(payload.get("windows"), dict) else (entry.get("windows") or {})
    return {
        "product": product if isinstance(product, dict) else {},
        "windows": windows if isinstance(windows, dict) else {},
        "sales": sales if isinstance(sales, dict) else {},
        "rate": entry.get("rate") if entry.get("rate") is not None else sales.get("review_rate"),
        "rateSource": entry.get("rateSource") or sales.get("rateSource"),
        "fetchedAt": payload.get("fetchedAt") or entry.get("fetchedAt"),
        "transport": entry.get("transport"),
        "cached": True,
        "fresh": bool(record.get("fresh")),
        "ageDays": record.get("ageDays"),
    }


def _crawl_category_path(product: Dict[str, Any]) -> str:
    product = product if isinstance(product, dict) else {}
    category = product.get("category") if isinstance(product.get("category"), dict) else {}
    return str(
        product.get("categoryPath")
        or category.get("path")
        or " > ".join(str(x) for x in (category.get("names") or []) if x)
        or ""
    ).strip()


def _enrichment(plid: Any, card: Dict[str, Any]) -> Dict[str, Any]:
    product = card.get("product") or {}
    category = product.get("category") if isinstance(product.get("category"), dict) else {}
    description = str(product.get("description") or "").strip()
    sales = card.get("sales") or {}
    return {
        "cached": bool(card.get("cached")),
        "fresh": bool(card.get("fresh")),
        "ageDays": card.get("ageDays"),
        "fetchedAt": card.get("fetchedAt"),
        "transport": card.get("transport"),
        "categoryPath": _crawl_category_path(product),
        "categoryNames": [str(x) for x in (category.get("names") or [])],
        "department": str(product.get("department") or product.get("categoryL1") or ""),
        "rating": product.get("rating"),
        "reviews": product.get("reviews") if product.get("reviews") is not None else product.get("reviewCount"),
        "sellerCount": product.get("sellerCount"),
        "brand": str(product.get("brand") or ""),
        "subtitle": str(product.get("subtitle") or ""),
        "images": _product_image_urls(product),
        "monthlySales": sales.get("estimated_monthly_sales"),
        "dailySales": sales.get("estimated_daily_sales"),
        "rate": card.get("rate"),
        "rateSource": card.get("rateSource"),
        "windows": card.get("windows") or {},
        "descriptionLen": len(description),
        "url": str(product.get("url") or ""),
        "plid": "PLID{0}".format(_plid_of(plid)) if _plid_of(plid) else "",
    }


def _stock_cell(raw: Any, warehouse: str) -> Dict[str, Any]:
    raw = raw if isinstance(raw, dict) else {}

    def num(key: str) -> int:
        try:
            return int(float(raw.get(key) or 0))
        except (TypeError, ValueError):
            return 0

    return {
        "region": str(raw.get("region") or "").upper(),
        "warehouse": warehouse,
        "available": num("quantity_available"),
        "receiving": num("stock_in_receiving"),
        "onWay": num("stock_on_way"),
        "sold30": num("quantity_sold_30_days"),
        "coverDays": num("stock_30_days_cover"),
    }


def _offer_stock(offer: Dict[str, Any]) -> Dict[str, Any]:
    regions: List[Dict[str, Any]] = []
    for key, tag in (("seller_warehouse_stock", "seller"), ("takealot_warehouse_stock", "takealot")):
        for raw in (offer.get(key) or []):
            if isinstance(raw, dict):
                regions.append(_stock_cell(raw, tag))

    def total(field: str) -> int:
        return sum(int(r.get(field) or 0) for r in regions)

    def warehouse(field: str, tag: str) -> int:
        return sum(int(r.get(field) or 0) for r in regions if r.get("warehouse") == tag)

    return {
        "regions": regions,
        "sellerAvailable": warehouse("available", "seller"),
        "dcAvailable": warehouse("available", "takealot"),
        "totalAvailable": total("available"),
        "totalReceiving": total("receiving"),
        "totalOnWay": total("onWay"),
        "totalSold30": total("sold30"),
        "totalCoverDays": total("coverDays"),
        "warehouseCount": len({r["warehouse"] for r in regions}),
        "regionCount": len({r["region"] for r in regions if r["region"]}),
    }


def _content_flags(offer: Dict[str, Any], enrichment: Dict[str, Any], image_url: str = "") -> Dict[str, Any]:
    barcode = str(offer.get("barcode") or "").strip()
    has_image = bool(str(image_url or offer.get("image_url") or "").strip()) or bool(enrichment.get("images"))
    has_barcode = bool(barcode)
    has_category = bool(str(enrichment.get("categoryPath") or "").strip())
    has_text = bool(enrichment.get("descriptionLen"))
    flags = (("image", has_image), ("barcode", has_barcode), ("category", has_category), ("text", has_text))
    missing = [key for key, ok in flags if not ok]
    score = 100 - (30 if not has_image else 0) - (20 if not has_barcode else 0) \
        - (25 if not has_category else 0) - (25 if not has_text else 0)
    return {
        "hasImage": has_image,
        "hasBarcode": has_barcode,
        "hasCategory": has_category,
        "hasText": has_text,
        "barcodeAssigned": bool(barcode) and is_takealot_assigned_barcode(barcode),
        "missing": [MISSING_LABELS[key] for key in missing],
        "missingKeys": missing,
        "score": max(0, score),
    }


# --------------------------------------------------------------------------
# ERP-local joins (上架草稿 / 采集箱 / 调价日志 / 合规词库) — built once per request
# --------------------------------------------------------------------------

def _key_of(value: Any) -> str:
    """A join key for sku/tsin/plid/barcode: the digits when there are any, else lowercase."""
    number = _plid_of(value)
    if number:
        return number
    return str(value or "").strip().lower()


def _draft_index() -> Dict[str, Dict[str, Any]]:
    index: Dict[str, Dict[str, Any]] = {}
    for draft in _drafts():
        if not isinstance(draft, dict):
            continue
        for raw in (draft.get("tsin"), draft.get("plid"), draft.get("sku"), draft.get("id")):
            key = _key_of(raw)
            if key and key not in index:
                index[key] = draft
    return index


def _collection_index() -> Dict[str, Dict[str, Any]]:
    index: Dict[str, Dict[str, Any]] = {}
    for item in _collection():
        if not isinstance(item, dict):
            continue
        for raw in (item.get("plid"), item.get("tsin"), item.get("sourceUrl"), item.get("sku"), item.get("barcode")):
            key = _key_of(raw)
            if key and key not in index:
                index[key] = item
    return index


def _price_log_index() -> Dict[str, Dict[str, Any]]:
    """Newest 调价日志 row per SKU/TSIN (the log is written newest-first)."""
    index: Dict[str, Dict[str, Any]] = {}
    for row in _price_log():
        if not isinstance(row, dict):
            continue
        for raw in (row.get("sku"), row.get("tsin")):
            key = _key_of(raw)
            if key:
                index.setdefault(key, row)
    return index


def _local_join(offer: Dict[str, Any], drafts: Dict[str, Any], collection: Dict[str, Any],
                prices: Dict[str, Any]) -> Dict[str, Any]:
    keys = [_key_of(offer.get("productline_id")), _key_of(offer.get("tsin_id")),
            _key_of(offer.get("sku")), _key_of(offer.get("barcode"))]
    draft = next((drafts[k] for k in keys if k in drafts), None)
    item = next((collection[k] for k in keys if k in collection), None)
    price = next((prices[k] for k in keys if k in prices), None)
    compliance = compliance_check(str(offer.get("title") or ""))
    hits = [str(hit.get("word")) for hit in (compliance.get("hits") or []) if isinstance(hit, dict)]
    stamp = "{0} {1}".format(price.get("time") or "", price.get("type") or "").strip() if price else ""
    return {
        "draftId": str(draft.get("id")) if draft else None,
        "draftStatus": str(draft.get("status")) if draft else None,
        "draftPrice": float(draft.get("price") or 0) if draft else None,
        "inCollection": bool(item),
        "collectionId": str(item.get("id")) if item else None,
        "collectionStatus": str(item.get("status")) if item else None,
        "complianceHits": hits[:6],
        "complianceVerdict": compliance.get("verdict"),
        "lastPriceChange": stamp or None,
        "lastPriceMessage": str(price.get("message")) if price else None,
    }


# --------------------------------------------------------------------------
# CONTRACT v5 — 公共主数据 (master) / 自建-跟卖 (origin) / 可编辑写入 (editable)
#
# Everything here is cache/local (the ≤60 s offers cache + the crawl-card cache),
# except two TTL-cached capability reads (`/seller` 10 min, `/facilities/
# get_enabled_regions` 1 h) that never run per row.
# --------------------------------------------------------------------------

def _enabled_regions(store_id: Any = None) -> Dict[str, Any]:
    """``{code: region_id}`` from ``/facilities/get_enabled_regions`` (per store, TTL 1 h)."""
    info = _effective_store(store_id)
    cache = _regions_cache(store_id)
    now = time.time()
    if cache["data"] and (now - float(cache["at"])) < float(cache.get("ttl") or REGIONS_TTL):
        return cache
    record: Dict[str, Any] = {"at": now, "ttl": REGIONS_TTL, "data": dict(REGION_ID_FALLBACK),
                              "error": None, "source": "fallback",
                              "storeId": info["storeId"], "storeName": info["storeName"]}
    if _key_configured(store_id):
        payload, err = _api_request("GET", "/facilities/get_enabled_regions", store_id=store_id)
        rows = payload.get("regions") if isinstance(payload, dict) else None
        mapping: Dict[str, Any] = {}
        for row in (rows or []):
            if isinstance(row, dict) and row.get("code"):
                mapping[str(row["code"]).upper()] = row.get("id")
        if mapping:
            record.update({"data": mapping, "source": "live"})
        else:
            record.update({"error": err or "no enabled regions returned", "ttl": 300.0})
    cache.update(record)
    return cache


def _seller_profile(store_id: Any = None) -> Dict[str, Any]:
    """``/seller`` → identity + account capabilities for ONE store (TTL 10 min)."""
    info = _effective_store(store_id)
    cache = _seller_cache(store_id)
    now = time.time()
    if cache["data"] and (now - float(cache["at"])) < float(cache.get("ttl") or SELLER_TTL):
        return cache
    data: Dict[str, Any] = {}
    error: Optional[str] = None
    if _key_configured(store_id):
        payload, err = _api_request("GET", "/seller", store_id=store_id)
        error = err
        if isinstance(payload, dict) and payload:
            data = {
                "sellerId": payload.get("seller_id"),
                "name": str(payload.get("display_name") or payload.get("legal_name") or ""),
                "legalName": str(payload.get("legal_name") or ""),
                "leadtimeEnabled": bool(payload.get("leadtime_enabled")),
                "disableListingEnabled": bool(payload.get("disable_listing_enabled")),
                "usedGoodsEnabled": bool(payload.get("used_goods_enabled")),
                "dropShipEnabled": bool(payload.get("drop_ship_enabled")),
                "replenishmentDisabled": bool(payload.get("replenishment_disabled")),
                "accountVerified": bool(payload.get("account_verified")),
                "registrationComplete": bool(payload.get("registration_complete")),
                "onVacation": bool(payload.get("on_vacation")),
                "termsAccepted": bool(payload.get("terms_accepted")),
                "dateAdded": payload.get("date_added"),
            }
    if data:
        record = {"at": now, "ttl": SELLER_TTL, "data": data, "error": error, "source": "live",
                  "storeId": info["storeId"], "storeName": info["storeName"]}
    else:
        record = {"at": now, "ttl": 300.0, "data": {}, "error": error or "no Seller X-API-Key configured",
                  "source": "empty", "storeId": info["storeId"], "storeName": info["storeName"]}
    cache.update(record)
    return cache


def _capabilities(store_id: Any = None) -> Dict[str, Any]:
    """This STORE's account capability switches (v5 ``editable.capabilities``, per store)."""
    info = _effective_store(store_id)
    profile = _seller_profile(store_id).get("data") or {}
    return {
        "storeId": info["storeId"],
        "storeName": info["storeName"],
        "storeScoped": info["storeScoped"],
        "keyConfigured": _key_configured(store_id),
        "leadtimeEnabled": bool(profile.get("leadtimeEnabled")),
        "disableListingEnabled": bool(profile.get("disableListingEnabled")),
        "usedGoodsEnabled": bool(profile.get("usedGoodsEnabled")),
        "sellerId": profile.get("sellerId"),
        "sellerName": profile.get("name") or "",
        "source": _seller_cache(store_id).get("source"),
        "error": _seller_cache(store_id).get("error"),
        "note": ("上下架（disable_listing_enabled）与备货期（leadtime_enabled）由平台账号开关决定；"
                 "Seller API 只接受 schema 列出的可写字段，写入被拒时以平台返回为准。"
                 "实测：leadtime_enabled=false 的账号写库存数量会被平台拒绝"
                 "（HTTP 400 cant-edit-soh-leadtime-disabled）。"),
    }


def _storage_tier(offer: Dict[str, Any]) -> Dict[str, Any]:
    """FBT 仓储档位：官方按包装体积 cm³ 定档（见 ``FBT_STORAGE_TIERS``）。"""
    offer = offer if isinstance(offer, dict) else {}
    actual = float(offer.get("weight_grams") or 0) / 1000.0
    length = float(offer.get("length_cm") or 0)
    width = float(offer.get("width_cm") or 0)
    height = float(offer.get("height_cm") or 0)
    volume = _r(length * width * height, 1) if (length and width and height) else None
    tier = FBT_STORAGE_TIERS[-1]
    if volume is None:
        return {
            "code": None, "label": None, "monthlyFee": None,
            "monthlyFeeLabel": "尺寸未知：不给仓储费",
            "volumeCm3": None,
            "chargeableWeightKg": _r(actual, 3),
            "actualWeightKg": _r(actual, 3),
            "dimensionsCm": "",
            "eligible": bool(offer.get("storage_fee_eligible")),
            "freeMonthlyFee": 0.0,
            "basis": "缺包装尺寸（length/width/height cm），官方仓储费按体积档定价，缺输入不给数字。",
        }
    for row in FBT_STORAGE_TIERS:
        low = row.get("volumeMinCm3")
        high = row.get("volumeMaxCm3")
        if low is not None and volume < float(low):
            continue
        if high is not None and volume > float(high):
            continue
        tier = row
        break
    return {
        "code": tier["code"],
        "label": tier["label"],
        "monthlyFee": float(tier["monthlyFee"]),
        "monthlyFeeLabel": "R {0:.2f}/月（超龄库存）；35 天内动销 R 0".format(float(tier["monthlyFee"])),
        "freeMonthlyFee": 0.0,
        "volumeCm3": volume,
        "chargeableWeightKg": _r(actual, 3),
        "actualWeightKg": _r(actual, 3),
        "dimensionsCm": "{0:g} x {1:g} x {2:g}".format(length, width, height),
        "eligible": bool(offer.get("storage_fee_eligible")),
        "basis": "volumeCm3 = L×W×H；" + STORAGE_TIER_NOTE,
    }


def _commission(offer: Dict[str, Any], item: Dict[str, Any], card: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Success Fee（官方口径）：费率来自官方价目表；金额 = 售价(含VAT) x 费率 x 1.15。"""
    offer = offer if isinstance(offer, dict) else {}
    item = item or {}
    product = (card or {}).get("product") or {}
    enrichment = item.get("enrichment") or {}
    category_path = str(enrichment.get("categoryPath") or _crawl_category_path(product) or "")
    category = _canonical_category(category_path, product.get("department"), product.get("categoryL1"),
                                   product.get("categoryName"), product.get("category"), item.get("title"),
                                   offer.get("title"))
    price = float(offer.get("selling_price") or 0)
    title = str(offer.get("title") or item.get("title") or "")
    fee = calculate_success_fee(price, category or None, price=price, title=title,
                                category_path=category_path)
    rate = fee.get("rate")
    return {
        "category": fee.get("category") or category,
        "categoryPath": category_path,
        "mainCategory": fee.get("mainCategory"),
        "subCategory": fee.get("subCategory"),
        "rate": rate,
        "ratePercent": fee.get("ratePercent"),
        "rateSource": fee.get("rateSource"),
        "amount": fee.get("feeAmount"),
        "amountExVat": fee.get("feeExVat"),
        "vatOnFee": fee.get("vatOnFee"),
        "rawAmount": _r(price * rate) if rate is not None else None,
        "minApplied": fee.get("minApplied", False),
        "note": fee.get("note"),
        "basis": fee.get("basis"),
    }


def _draft_for(offer: Dict[str, Any], drafts: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    offer = offer if isinstance(offer, dict) else {}
    keys = [_key_of(offer.get("productline_id")), _key_of(offer.get("tsin_id") or offer.get("tsin")),
            _key_of(offer.get("sku")), _key_of(offer.get("barcode"))]
    for key in keys:
        if key and key in (drafts or {}):
            return drafts[key]
    return None


_IDENTITY_TTL = 60.0
_IDENTITY_CACHE: Dict[str, Dict[str, Any]] = {}


def _own_identity(store_id: Any = None) -> Dict[str, Any]:
    """卖家身份（判定"BuyBox 是不是我们自己"）。**每行都会问一次**，所以按店缓存。

    `_seller_profile` 自己有 10 分钟 TTL，但它每次调用都要重走一遍店铺解析（读 stores.json +
    解密钥），实测 5~12ms —— 映射 1322 行就白花十几秒。缓存键用"请求里的 storeId"（空 =
    激活店），省掉那次解析；身份只在店铺配置/资料变化时才会变，60s + 写操作显式失效足够。
    """
    key = str(store_id or "").strip() or "__active__"
    hit = _IDENTITY_CACHE.get(key)
    now = time.time()
    if hit and (now - float(hit.get("at") or 0)) < _IDENTITY_TTL:
        return dict(hit.get("data") or {})
    profile = _seller_profile(store_id).get("data") or {}
    names = [str(profile.get("name") or "").strip().lower(), str(profile.get("legalName") or "").strip().lower()]
    data = {"sellerId": profile.get("sellerId"), "names": [n for n in names if n]}
    _IDENTITY_CACHE[key] = {"at": now, "data": data}
    return dict(data)


def _origin_block(offer: Dict[str, Any], item: Dict[str, Any], card: Optional[Dict[str, Any]] = None,
                  draft: Optional[Dict[str, Any]] = None,
                  store_id: Any = None) -> Dict[str, Any]:
    """自建 vs 跟卖 — 推断，永远带依据 (`signals`) 与中文 `reason`。

    平台没有「谁建的目录项」字段，所以判据按契约 v5 §3：erp-draft（本店建档草稿）
    → no-competition（公开页无竞争）→ buybox（支持性）→ 否则跟卖；**没有抓取卡片
    且没有建档草稿时判 unknown（待定）**，绝不默认成跟卖。
    """
    offer = offer if isinstance(offer, dict) else {}
    item = item or {}
    product = (card or {}).get("product") or {}
    has_card = bool(product)
    signals: List[Dict[str, str]] = []
    holder = product.get("seller") if isinstance(product.get("seller"), dict) else {}
    identity = _own_identity(store_id)
    buybox_held = False
    if has_card:
        holder_name = str(holder.get("name") or "").strip().lower()
        buybox_held = bool(holder_name and holder_name in identity["names"])
        if not buybox_held and identity.get("sellerId") is not None and holder.get("id") is not None:
            buybox_held = identity["sellerId"] == holder.get("id")
    offer_count: Optional[int] = None
    competitor_count: Optional[int] = None
    competitor_names: List[str] = []
    if has_card:
        offers = product.get("offers") if isinstance(product.get("offers"), list) else []
        competitor_names = [str(o.get("sellerName")).strip() for o in offers
                            if isinstance(o, dict) and str(o.get("sellerName") or "").strip()]
        raw_count = product.get("competitorCount")
        if raw_count is None:
            raw_count = len(offers) if offers else product.get("sellerCount")
        try:
            competitor_count = int(raw_count or 0)
        except (TypeError, ValueError):
            competitor_count = len(competitor_names)
        raw_offers = product.get("offerCount")
        try:
            offer_count = int(raw_offers) if raw_offers is not None else competitor_count
        except (TypeError, ValueError):
            offer_count = competitor_count
    if draft:
        signals.append({"source": "erp-draft", "detail": (
            "ERP 已有该商品的建档草稿 {0}（状态 {1}，建档价 R {2}）→ 本店自建建档".format(
                draft.get("id"), draft.get("status"), draft.get("price")))})
    exclusive = bool(has_card and (competitor_count == 0 or (offer_count is not None and offer_count <= 1)))
    if exclusive:
        signals.append({"source": "no-competition", "detail": (
            "公开页只有 {0} 个报价、{1} 个竞争卖家 → 本店唯一在售（自建独家）".format(offer_count, competitor_count))})
    if has_card and buybox_held:
        signals.append({"source": "buybox", "detail": "公开页 BuyBox 归属本店（{0}）→ 支持「自建」判断".format(
            identity.get("sellerName") or holder.get("name"))})
    elif has_card and holder.get("name"):
        signals.append({"source": "buybox", "detail": "公开页 BuyBox 归属 {0}（不是本店）".format(holder.get("name"))})
    barcode = str(offer.get("barcode") or item.get("barcode") or "").strip()
    if is_takealot_assigned_barcode(barcode):
        signals.append({"source": "barcode-assigned", "detail": (
            "条码 {0} 是 Takealot 分配的目录条码（MPTALX…），说明该目录项由卖家 Loadsheet 建档上传".format(barcode))})
    if has_card and competitor_count and not draft:
        signals.append({"source": "competition", "detail": "公开页 {0} 个报价 / {1} 个竞争卖家：{2}".format(
            offer_count, competitor_count, "、".join(competitor_names[:5]) or "（公开页未给出卖家名）")})
    likely = ""
    if not has_card and not draft:
        code, label = "unknown", "待定"
        reason = ("公开页没有该商品的抓取卡片（未公开的目录项或未采集），ERP 里也没有建档草稿："
                  "无法判定是本店自建还是跟卖，故标为「待定」而不是默认跟卖。")
        if signals:
            reason += "（已有依据 {0}，但不足以定论）".format("、".join(row["source"] for row in signals))
        # 卖家侧的方向性提示（低置信）——比留空白有用，且把依据写清楚。
        label_value = str(offer.get("product_label") or "").strip()
        sku_value = str(offer.get("sku") or "").strip()
        barcode_value = str(offer.get("barcode") or "").strip()
        if label_value and sku_value:
            if label_value == sku_value:
                likely = "own"
                reason += (" 倾向自建（低置信）：该 offer 的平台标签 product_label 就是本店 SKU，"
                           "通常见于本店自己上传的目录项。")
            else:
                likely = "follow"
                reason += (" 倾向跟卖（低置信）：平台标签 product_label「{0}」不是本店 SKU（本店 {1}），"
                           "通常说明该目录项由其他卖家建立。").format(label_value, sku_value)
        if barcode_value.upper().startswith("MPTAL"):
            reason += " 条码 {0} 为 Takealot 分配码（非自有 GS1）。".format(barcode_value)
    elif draft or exclusive or (has_card and buybox_held):
        code, label = "own", "自建独家"
        if draft and not exclusive:
            reason = ("ERP 里有该商品的建档草稿 {0}（本店建档上传）→ 自建；公开页另有 {1} 个竞争卖家在该目录项上跟卖，"
                      "所以不是「独家」。").format(draft.get("id"), competitor_count)
            label = "自建独家" if exclusive else label
        elif draft:
            reason = "ERP 里有该商品的建档草稿 {0}，且公开页没有其他卖家 → 本店自建且独家。".format(draft.get("id"))
        elif exclusive:
            reason = "公开页仅本店在售（{0} 个报价 / {1} 个竞争卖家）→ 自建独家。".format(offer_count, competitor_count)
        else:
            reason = "公开页 BuyBox 归属本店（竞争卖家 {0} 家）→ 按契约判为自建（本店是目录项的原始卖家）。".format(competitor_count)
    else:
        code, label = "follow", "跟卖"
        reason = "公开页有 {0} 个竞争卖家（本店不是唯一在售）{1} → 判定为跟卖。".format(
            competitor_count, ("，其中 " + "、".join(competitor_names[:3])) if competitor_names else "")
    if code == "own" and has_card and holder.get("name") and not buybox_held:
        reason += ("（注意：公开页 BuyBox 归属 {0}，并非本店——该目录项可能还有其他卖家在售，"
                   "公开卡片里的竞争报价未被完整捕获）").format(holder.get("name"))
    return {
        "code": code,
        "label": label,
        "exclusive": bool(exclusive),
        "buyboxHeld": bool(buybox_held),
        "offerCount": offer_count,
        "competitorCount": competitor_count,
        "competitors": competitor_names[:8],
        "signals": signals,
        "reason": reason,
        "likely": likely,
        "confidence": "low" if likely else ("high" if code != "unknown" else "none"),
        "cardCached": has_card,
        "source": "inference",
        "note": "平台没有「谁建立目录项」字段：以上为按公开页与 ERP 本地记录推断，判据见 signals。",
    }


def _editable_block(offer: Dict[str, Any], item: Dict[str, Any], caps: Dict[str, Any],
                    store_id: Any = None) -> Dict[str, Any]:
    """卖家可编辑参数表（五个字段 + 每字段 writable + 账号能力）。"""
    offer = offer if isinstance(offer, dict) else {}
    item = item or {}
    has_offer = bool(offer)
    keyed = bool(caps.get("keyConfigured") and has_offer)
    price = _r(offer.get("selling_price") or 0)
    rrp = _r(offer.get("rrp") or 0)
    stock = _offer_stock(offer) if has_offer else {"sellerAvailable": 0, "dcAvailable": 0}
    warehouses = [w for w in (offer.get("seller_warehouse_stock") or []) if isinstance(w, dict)]
    warehouse_id = warehouses[0].get("seller_warehouse_id") if warehouses else None
    leadtime = offer.get("minimum_leadtime_days")
    try:
        leadtime = int(leadtime) if leadtime is not None else None
    except (TypeError, ValueError):
        leadtime = None
    status = str(offer.get("status") or ("not_on_account" if not has_offer else ""))
    leadtime_enabled = bool(caps.get("leadtimeEnabled"))
    no_offer_note = "该 SKU 不在本店 Offer 列表（无法写入），先建档/采集再改参数。"
    leadtime_note = ("-1 = FBT/现货托管（原样透传，不改写）。" if leadtime == -1 else "0–30 天。")
    if not leadtime_enabled:
        leadtime_note += " 该账号 leadtime_enabled=false（未开通 API 备货期写入），字段标为不可写；仍提交会被平台拒绝。"
    stock_note = ("写 seller_warehouse_stock=[{{seller_warehouse_id: {0}, quantity_available}}]；仓 ID 由 Takealot 分配（readOnly）。".format(warehouse_id)
                  if warehouse_id is not None else "该 offer 没有返回 seller_warehouse_stock expand（拿不到仓 ID），无法写入库存。")
    if not leadtime_enabled:
        stock_note += (" 该账号 leadtime_enabled=false（卖家自管库存未开通）：实测平台会拒绝库存数量写入"
                       "（HTTP 400 cant-edit-soh-leadtime-disabled），库存变更请走 Seller Portal。")
    fields: List[Dict[str, Any]] = [
        {"key": "selling_price", "api": "selling_price", "label": "售价 (ZAR)", "value": price,
         "kind": "int", "min": 1, "max": None, "step": 1, "unit": "R",
         "writable": bool(keyed and price >= 0),
         "note": "写 PATCH /offers/by_sku/{sku} 的 selling_price（整数 ZAR，≥1）。" if keyed else no_offer_note},
        {"key": "rrp", "api": "rrp", "label": "建议零售价 RRP (ZAR)", "value": rrp,
         "kind": "int", "min": 1, "max": None, "step": 1, "unit": "R",
         "writable": bool(keyed),
         "note": ("API 不接受 0：当前 RRP 为 0，若要写入必须 ≥1；清空/取消 RRP 请在 Seller Portal 操作。"
                  if rrp < 1 else "写 PATCH /offers/by_sku/{sku} 的 rrp（整数 ZAR，≥1）。") if keyed else no_offer_note},
        {"key": "seller_stock", "api": "seller_warehouse_stock", "label": "卖家自营仓库存", "value": int(stock.get("sellerAvailable") or 0),
         "kind": "int", "min": 0, "max": None, "step": 1, "unit": "件",
         "warehouseId": warehouse_id,
         "writable": bool(keyed and warehouse_id is not None),
         "platformRefusesWhileLeadtimeDisabled": bool(keyed and warehouse_id is not None and not leadtime_enabled),
         "note": stock_note if keyed else no_offer_note},
        {"key": "minimum_leadtime_days", "api": "minimum_leadtime_days", "label": "备货期 (天)", "value": leadtime,
         "kind": "int", "min": -1, "max": 30, "step": 1, "unit": "天",
         "writable": bool(keyed and leadtime_enabled), "note": leadtime_note},
        {"key": "status", "api": None, "label": "上下架状态", "value": status,
         "kind": "select", "min": None, "max": None, "writable": False,
         "options": [{"value": "buyable", "label": STATUS_LABELS["buyable"]},
                     {"value": "not_buyable", "label": STATUS_LABELS["not_buyable"]},
                     {"value": "disabled_by_seller", "label": STATUS_LABELS["disabled_by_seller"]},
                     {"value": "disabled_by_takealot", "label": STATUS_LABELS["disabled_by_takealot"]}],
         "note": "该账号未开通 API 上下架（disable_listing_enabled=false），请在 Seller Portal 操作"},
    ]
    return {
        "capabilities": caps,
        "fields": fields,
        "writePath": "PATCH /products/{sku} → PATCH /offers/by_sku/{sku}",
        "writableKeys": ["selling_price", "rrp", "seller_stock", "minimum_leadtime_days"],
        "note": ("只有售价 / RRP / 自营仓库存 / 备货期可写（Seller API additionalProperties:false）；"
                 "上下架与 Takealot 托管仓库存本店不可写。"),
        "offerStatus": status,
        "offerStatusLabel": STATUS_LABELS.get(status, status or "未知"),
        "dcAvailable": int(stock.get("dcAvailable") or 0),
    }


def _seller_warehouse_id(offer: Dict[str, Any]) -> Optional[Any]:
    for raw in ((offer or {}).get("seller_warehouse_stock") or []):
        if isinstance(raw, dict) and raw.get("seller_warehouse_id") is not None:
            return raw.get("seller_warehouse_id")
    return None


def _readonly_stock(offer: Dict[str, Any], store_id: Any = None) -> Dict[str, Any]:
    """双仓库存：平台托管仓（只读）vs 卖家自营仓（可写）。"""
    offer = offer if isinstance(offer, dict) else {}
    region_ids = _enabled_regions(store_id).get("data") or {}
    platform: List[Dict[str, Any]] = []
    for raw in (offer.get("takealot_warehouse_stock") or []):
        if not isinstance(raw, dict):
            continue
        cell = _stock_cell(raw, "takealot")
        platform.append({
            "region": cell["region"], "regionId": region_ids.get(cell["region"]),
            "available": cell["available"], "receiving": cell["receiving"], "onWay": cell["onWay"],
            "sold30": cell["sold30"], "coverDays": cell["coverDays"], "writable": False,
        })
    seller: List[Dict[str, Any]] = []
    for raw in (offer.get("seller_warehouse_stock") or []):
        if not isinstance(raw, dict):
            continue
        try:
            quantity = int(float(raw.get("quantity_available") or 0))
        except (TypeError, ValueError):
            quantity = 0
        seller.append({"warehouseId": raw.get("seller_warehouse_id"), "available": quantity,
                       "writable": True, "field": "seller_stock"})
    note = PLATFORM_STOCK_NOTE
    if not platform:
        note += "（该 offer 的 takealot_warehouse_stock 为空：平台没有托管库存记录）"
    if not seller:
        note += ("（该 offer 的 seller_warehouse_stock 为空：平台没有给这个 offer 分配自营仓，"
                 "所以库存字段不可写——绝不凭空造仓 ID）")
    return {
        "takealot": platform,
        "seller": seller,
        "note": note,
        "regionIds": region_ids,
        "regionSource": _regions_cache(store_id).get("source"),
        "regions": sorted({row["region"] for row in platform if row.get("region")}),
    }


def _master_block(offer: Dict[str, Any], item: Dict[str, Any], card: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """§1 Listing 映射全部目录内容（公共主数据）+ 佣金 + FBT 仓储档位。"""
    offer = offer if isinstance(offer, dict) else {}
    item = item or {}
    product = (card or {}).get("product") or {}
    enrichment = item.get("enrichment") or {}
    commission = _commission(offer, item, card)
    storage = _storage_tier(offer)
    number = _plid_of(offer.get("productline_id") or item.get("plid"))
    plid = item.get("plid") or ("PLID{0}".format(number) if number else "")
    tsin_number = _plid_of(offer.get("tsin_id") or offer.get("tsin"))
    tsin = item.get("tsin") or ("TSIN{0}".format(tsin_number) if tsin_number else "")
    barcode = str(offer.get("barcode") or item.get("barcode") or "")
    images = enrichment.get("images") or _product_image_urls(product)
    weight_grams = float(offer.get("weight_grams") or 0)
    return {
        "title": str(offer.get("title") or item.get("title") or product.get("title") or ""),
        "brand": str(enrichment.get("brand") or product.get("brand") or ""),
        "category": commission["category"],
        "categoryPath": commission["categoryPath"],
        "categoryNames": enrichment.get("categoryNames") or [],
        "department": enrichment.get("department") or str(product.get("department") or ""),
        "tsin": tsin,
        "plid": plid,
        "barcode": barcode,
        "barcodeAssigned": bool(is_takealot_assigned_barcode(barcode)),
        "offerId": offer.get("offer_id"),
        "sku": str(offer.get("sku") or item.get("sku") or ""),
        "commissionRate": commission["rate"],
        "commissionRatePercent": commission["ratePercent"],
        "commissionAmount": commission["amount"],
        "commissionCategory": commission["category"],
        "commissionMinApplied": commission["minApplied"],
        "commissionBasis": commission["basis"],
        "dimensions": item.get("dimensions") or {"lengthCm": offer.get("length_cm"), "widthCm": offer.get("width_cm"),
                                                 "heightCm": offer.get("height_cm"), "weightGrams": weight_grams},
        "weightKg": item.get("weightKg") if item.get("weightKg") is not None else _r(weight_grams / 1000.0, 3),
        "storageTier": storage,
        "rating": enrichment.get("rating") if enrichment.get("rating") is not None else product.get("rating"),
        "reviews": enrichment.get("reviews") if enrichment.get("reviews") is not None else product.get("reviews"),
        "sellerCount": enrichment.get("sellerCount") if enrichment.get("sellerCount") is not None else product.get("sellerCount"),
        "images": images,
        "publicUrl": _public_product_url(plid, str(product.get("url") or "")),
        "price": _r(offer.get("selling_price") or 0),
        "rrp": _r(offer.get("rrp") or 0),
        "discount": _r(offer.get("discount_percentage") or 0),
        "status": str(offer.get("status") or item.get("status") or ""),
        "statusLabel": item.get("statusLabel") or STATUS_LABELS.get(str(offer.get("status") or ""), "未知"),
        "listingQuality": offer.get("listing_quality"),
        "condition": offer.get("condition"),
        "label": offer.get("product_label"),
        "createdAt": offer.get("created_at") or item.get("createdAt"),
        "updatedAt": offer.get("updated_at") or item.get("updatedAt"),
        "source": "Seller API /offers + 公开页抓取缓存（公共主数据只读）",
    }


def _offer_writes() -> List[Dict[str, Any]]:
    """The write audit log (``state/offer_writes.json``, newest first)."""
    data = _read_state(OFFER_WRITES_FILE, [])
    if not isinstance(data, list):
        return []
    return [row for row in data if isinstance(row, dict)]


def _append_offer_write(entry: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows = _offer_writes()
    rows.insert(0, entry)
    rows = rows[:OFFER_WRITES_MAX]
    _write_state(OFFER_WRITES_FILE, rows)
    return rows


def _write_history(sku: Any, limit: int = 10) -> List[Dict[str, Any]]:
    key = str(sku or "").strip().lower()
    out: List[Dict[str, Any]] = []
    for row in _offer_writes():
        if str(row.get("sku") or "").strip().lower() != key:
            continue
        out.append({"at": row.get("at"), "fields": row.get("fields") or [], "ok": bool(row.get("ok")),
                    "apiStatus": row.get("apiStatus"), "request": row.get("request") or {},
                    "applied": row.get("applied") or []})
        if len(out) >= limit:
            break
    return out


def _snapshot_offer(offer: Dict[str, Any]) -> Dict[str, Any]:
    """The writable fields' current values (the write path's ``from`` side)."""
    offer = offer if isinstance(offer, dict) else {}

    def num(value: Any) -> int:
        try:
            return int(float(value or 0))
        except (TypeError, ValueError):
            return 0

    leadtime = offer.get("minimum_leadtime_days")
    try:
        leadtime = int(leadtime) if leadtime is not None else None
    except (TypeError, ValueError):
        leadtime = None
    return {
        "selling_price": num(offer.get("selling_price")),
        "rrp": num(offer.get("rrp")),
        "seller_stock": sum(num(w.get("quantity_available")) for w in (offer.get("seller_warehouse_stock") or [])
                            if isinstance(w, dict)),
        "minimum_leadtime_days": leadtime,
        "status": str(offer.get("status") or ""),
        "disabledBySeller": bool(offer.get("disabled_by_seller")),
        "disabledByTakealot": bool(offer.get("disabled_by_takealot")),
    }


def _read_offer_live(sku: Any, store_id: Any = None,
                     meta: Optional[Dict[str, Any]] = None) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """A live single-offer read with both stock expands — the write path's re-read."""
    key, key_error, _row = _store_key_for(store_id)
    if not key:
        return None, key_error or "no Seller X-API-Key configured"
    data, err = _api_request("GET", "/offers/by_sku/{0}".format(urllib.parse.quote(str(sku or ""), safe="")),
                             {"expands": list(OFFER_EXPANDS)}, store_id=store_id, meta=meta)
    if err:
        return None, err
    if isinstance(data, list):
        data = data[0] if data else None
    if not isinstance(data, dict) or not data:
        return None, "Seller API returned no offer for {0}".format(sku)
    return data, None


def _bust_offer_caches(store_id: Any = None) -> None:
    """A write must show up immediately — for THAT store (all stores when store_id is None)."""
    # 卖家身份缓存也要跟着清：它参与"自建/跟卖"判定，写操作后必须反映最新店铺状态。
    _IDENTITY_CACHE.clear()
    if str(store_id or "").strip():
        key = _effective_store(store_id)["storeId"] or "__none__"
        for bucket in (_OFFERS_BY_STORE, _CATALOG_BY_STORE, _OFFER_INDEX_BY_STORE):
            bucket.pop(key, None)
        return
    _OFFERS_BY_STORE.clear()
    _OFFER_INDEX_BY_STORE.clear()
    _CATALOG_BY_STORE.clear()


_API_STATUS_RE = re.compile(r"Takealot API (\d{3})")


def _api_status_of(err: Optional[str]) -> Optional[int]:
    match = _API_STATUS_RE.search(str(err or ""))
    return int(match.group(1)) if match else None


def _int_or_error(raw: Any, key: str) -> Tuple[Optional[int], Optional[str]]:
    """整数校验（布尔/小数/非数字都拒），中文错误信息，绝不调用 API。"""
    rule = OFFER_WRITE_RULES[key]
    label, hint = rule["label"], rule["hint"]
    if isinstance(raw, bool):
        return None, "{0}必须是整数（{1}），收到布尔值 {2!r}".format(label, hint, raw)
    number: Any = raw
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return None, "{0}不能为空（{1}）".format(label, hint)
        number = text
    try:
        if isinstance(number, str):
            value = int(number)
        elif isinstance(number, float):
            if number != int(number):
                raise ValueError("fraction")
            value = int(number)
        elif isinstance(number, int):
            value = number
        else:
            raise ValueError("type")
    except (TypeError, ValueError):
        return None, "{0}必须是整数（{1}），收到 {2!r}".format(label, hint, raw)
    if rule["min"] is not None and value < rule["min"]:
        return None, "{0}不能小于 {1}（{2}），收到 {3}".format(label, rule["min"], hint, value)
    if rule["max"] is not None and value > rule["max"]:
        return None, "{0}不能大于 {1}（{2}），收到 {3}".format(label, rule["max"], hint, value)
    if key == "minimum_leadtime_days" and value < 0 and value != -1:
        return None, "备货期只接受 -1（FBT/现货托管，原样透传）或 0–30 天，收到 {0}".format(value)
    return value, None


def _fmt_write_value(field: str, value: Any) -> str:
    if value is None:
        return "—"
    if field in ("selling_price", "rrp"):
        return "R {0}".format(value)
    if field == "seller_stock":
        return "{0} 件".format(value)
    if field == "minimum_leadtime_days":
        return "{0} 天".format(value)
    return str(value)


def _unwritable_message(key: str) -> str:
    known = UNWRITABLE_OFFER_KEYS.get(key)
    if known:
        return "该字段不可写：{0}".format(known)
    return ("该字段不可写：不认识的字段 {0}（Seller API PATCH /offers/by_sku/{{sku}} 只接受 "
            "selling_price / rrp / seller_stock / minimum_leadtime_days，additionalProperties:false）").format(key)


def _log_offer_write(sku: str, tsin: str, request_body: Dict[str, Any], applied: List[Dict[str, Any]],
                     ok: bool, err: Optional[str], kind: str = "", store_id: Any = None) -> None:
    """Mirror a human line into ``state/price_log.json`` so 财务/跟价 modules see the write.

    ``kind`` names the entry type (``BATCH_WRITE`` / ``OFFER_CREATE``); the default keeps
    the v5 wording (``PRICE_WRITE`` / ``OFFER_WRITE``).
    """
    logs = _price_log()
    parts = ["{0} {1} → {2}".format(row.get("label") or row.get("field"),
                                    _fmt_write_value(row.get("field"), row.get("from")),
                                    _fmt_write_value(row.get("field"), row.get("to"))) for row in applied]
    if not parts:
        parts = ["请求字段 " + ", ".join(request_body.keys())]
    price_changed = any(row.get("field") == "selling_price" for row in applied)
    entry_type = kind or ("PRICE_WRITE" if price_changed else "OFFER_WRITE")
    if kind == "BATCH_WRITE":
        message = "批量写入·{0}：{1}（PATCH /offers/by_sku/{2}，{3}{4}）".format(
            "改价" if price_changed else "属性变更", "；".join(parts), sku,
            "已回读确认" if ok else "平台未接受/回读不一致", ("，错误：" + err) if err else "")
    elif kind == "OFFER_CREATE":
        created_parts = ["{0} {1}".format(
            row.get("field"),
            _fmt_write_value(row.get("field"),
                             row.get("actual") if row.get("actual") is not None else row.get("value")))
            for row in applied if row.get("value") is not None or row.get("actual") is not None]
        message = "跟卖建 Offer：{0}（POST /offers，{1}{2}）".format(
            "；".join(created_parts) or "；".join(parts),
            "已创建并回读确认" if ok else "平台未接受", ("，错误：" + err) if err else "")
    else:
        message = "商品管理写入{0}：{1}（PATCH /offers/by_sku/{2}，{3}{4}）".format(
            "·改价" if price_changed else "·属性变更", "；".join(parts), sku,
            "已回读确认" if ok else "平台未接受/回读不一致", ("，错误：" + err) if err else "")
    logs.insert(0, {"time": _now().strftime("%H:%M:%S"), "sku": sku, "tsin": tsin or "",
                    "type": entry_type, "message": message,
                    "storeId": str(store_id or (_effective_store(None)["storeId"]))})
    _write_state("price_log.json", logs[:80])


# --------------------------------------------------------------------------
# The product item (the list AND the detail share this shape)
# --------------------------------------------------------------------------

def _offer_item(offer: Dict[str, Any], entries: Dict[str, Any], drafts: Dict[str, Any],
                collection: Dict[str, Any], prices: Dict[str, Any],
                card_override: Optional[Dict[str, Any]] = None,
                store_id: Any = None) -> Dict[str, Any]:
    number = _plid_of(offer.get("productline_id"))
    plid = "PLID{0}".format(number) if number else ""
    tsin_number = _plid_of(offer.get("tsin_id") or offer.get("tsin"))
    card = card_override if card_override is not None else _cached_card(plid, entries)
    enrichment = _enrichment(plid, card)
    offer_image = normalize_takealot_image(offer.get("image_url"))
    offer_image = offer_image if isinstance(offer_image, str) else ""
    images = enrichment.get("images") or []
    # the Seller API cover is http://takealot.s3… while the crawl hands back the same
    # asset over https (media.takealot.com) — prefer the one a browser will render.
    image_url = offer_image
    if images and (not offer_image or offer_image.startswith("http://")):
        image_url = images[0]
    status = str(offer.get("status") or "").strip()
    weight_grams = float(offer.get("weight_grams") or 0)
    item = {
        "sku": str(offer.get("sku") or ""),
        "offerId": offer.get("offer_id"),
        "tsin": "TSIN{0}".format(tsin_number) if tsin_number else "",
        "plid": plid,
        "barcode": str(offer.get("barcode") or ""),
        "title": str(offer.get("title") or ""),
        "imageUrl": image_url,
        "price": _r(offer.get("selling_price") or 0),
        "rrp": _r(offer.get("rrp") or 0),
        "discount": _r(offer.get("discount_percentage") or 0),
        "status": status,
        "statusLabel": STATUS_LABELS.get(status, status or "未知"),
        "sellable": status == "buyable",
        "disabledBySeller": bool(offer.get("disabled_by_seller")),
        "disabledByTakealot": bool(offer.get("disabled_by_takealot")),
        "condition": offer.get("condition"),
        "label": offer.get("product_label"),
        "listingQuality": offer.get("listing_quality"),
        "dimensions": {
            "lengthCm": offer.get("length_cm"),
            "widthCm": offer.get("width_cm"),
            "heightCm": offer.get("height_cm"),
            "weightGrams": weight_grams,
        },
        "weightKg": _r(weight_grams / 1000.0, 3),
        "wishlist": int(offer.get("total_wishlist") or 0),
        "wishlist30d": int(offer.get("wishlist_30_days") or 0),
        "returned30d": int(offer.get("quantity_returned_30_days") or 0),
        "createdAt": offer.get("created_at"),
        "updatedAt": offer.get("updated_at"),
        "leadtimeDays": offer.get("minimum_leadtime_days"),
        "vacation": bool(offer.get("affected_by_vacation")),
        "conveyable": bool(offer.get("is_conveyable")),
        "storageFeeEligible": bool(offer.get("storage_fee_eligible")),
        "stock": _offer_stock(offer),
        "enrichment": enrichment,
        "content": _content_flags(offer, enrichment, image_url),
        "local": _local_join(offer, drafts, collection, prices),
    }
    # CONTRACT v5 — 自建/跟卖 + 公共主数据（佣金 / 仓储档位）挂在每个 item 上，
    # 全部来自已有的 offer 行 + ≤60 s 缓存 + 抓取卡片缓存，不额外按行发网络请求。
    item["origin"] = _origin_block(offer, item, card, _draft_for(offer, drafts), store_id)
    item["master"] = _master_block(offer, item, card)
    return item


# 旧的"给不在本店 offer 列表里的 SKU 合成一行商品"已删除：
# /products/{sku} 现在返回显式的 not-found 载荷（found:false + 原因），UI 有对应提示。


# --------------------------------------------------------------------------
# The /offers list (≤300 s TTL, per store) — no demo catalogue any more: a store
# without a Seller key gets an honest empty list + reason, never fake offers.
# --------------------------------------------------------------------------

# （无 Key 时的示例商品目录生成器已整体删除：空列表 + 原因，见 _offer_rows）


def _offers_rows_of(payload: Any) -> List[Dict[str, Any]]:
    """The offer rows out of a ``/offers`` response (list, or a dict with ``items``)."""
    rows: List[Any] = []
    if isinstance(payload, list):
        rows = payload
    elif isinstance(payload, dict):
        for key in ("items", "offers", "data", "results"):
            if isinstance(payload.get(key), list):
                rows = payload[key]
                break
    return [row for row in rows if isinstance(row, dict)]


def _fetch_all_offers(store_id: Any = None, expands: bool = True,
                      page_limit: int = OFFERS_PAGE_LIMIT,
                      max_pages: int = OFFERS_MAX_PAGES) -> Dict[str, Any]:
    """**Every** offer on the account — paginated (CONTRACT v6 addendum).

    One page used to be enough only because the small test account has 31 offers.
    The real shop has >1000, and ``total`` was silently the page size. The cursor is
    ``offer_id__gt`` with ``order_by=offer_id`` (the API's own ascending order), with
    the server's ``continuation_token`` honoured when it is present; the loop stops on
    a short page, on 0 new rows, or at the safety caps — and says so via ``truncated``.
    """
    rows: List[Dict[str, Any]] = []
    seen: set = set()
    error: Optional[str] = None
    pages = 0
    cursor: Optional[int] = None
    token: Optional[str] = None
    while pages < max_pages:
        query: Dict[str, Any] = {"limit": page_limit, "order_by": "offer_id"}
        if expands:
            query["expands"] = list(OFFER_EXPANDS)
        if cursor is not None:
            query["offer_id__gt"] = cursor
        if token:
            query["continuation_token"] = token
        data, err = _api_request("GET", "/offers", query, store_id=store_id,
                                 timeout=OFFERS_HTTP_TIMEOUT)
        pages += 1
        if err is not None:
            error = err
            break
        page = _offers_rows_of(data)
        fresh = 0
        for row in page:
            key = str(row.get("offer_id") or "")
            if key and key in seen:
                continue
            if key:
                seen.add(key)
            rows.append(row)
            fresh += 1
            if len(rows) >= OFFERS_MAX_ROWS:
                break
        if len(rows) >= OFFERS_MAX_ROWS:
            break
        token = str((data or {}).get("continuation_token") or "") if isinstance(data, dict) else ""
        if not fresh:
            break
        ids = [int(row.get("offer_id") or 0) for row in page if str(row.get("offer_id") or "").isdigit()]
        next_cursor = max(ids) if ids else None
        if next_cursor is None or next_cursor == cursor:
            # no usable cursor in the payload: a short page means the list is complete
            if len(page) < page_limit:
                break
            break
        cursor = next_cursor
        if len(page) < page_limit and not token:
            break
    truncated = bool(len(rows) >= OFFERS_MAX_ROWS or (pages >= max_pages and len(rows) >= page_limit * max_pages))
    return {"rows": rows, "error": error, "pages": pages, "truncated": truncated,
            "mapped": len(rows), "maxRows": OFFERS_MAX_ROWS}


_OFFERS_BY_STORE: Dict[str, Dict[str, Any]] = {}


# ── 目录快照：进程重启后不必再等 51 秒 ────────────────────────────────────────
# 全店 /offers（1322 条、带两个 stock expand）实测一次 51s。以前只有进程内 memo，
# 后端一重启（应用会自动重生后端）或 memo 过期，第一个点进来的模块就要同步等它。
# 这里把成功拉到的行落盘，下次冷启动直接先端出来，再在后台刷新。
_OFFERS_SNAPSHOT_DIR = "offers_cache"


def _offers_snapshot_path(store_id: Any) -> Optional[Path]:
    """每店一份，文件名只允许安全字符 —— 脏 storeId 不许影响路径（也不许串店）。"""
    sid = re.sub(r"[^A-Za-z0-9._-]", "_", str(store_id or "").strip())
    if not sid:
        return None
    return STATE_DIR / _OFFERS_SNAPSHOT_DIR / (sid + ".json")


def _load_offers_snapshot(store_id: Any) -> Optional[Dict[str, Any]]:
    path = _offers_snapshot_path(store_id)
    if path is None or not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if not isinstance(data, dict) or not isinstance(data.get("items"), list) or not data["items"]:
        return None
    if str(data.get("storeId") or "") != str(store_id or ""):
        return None          # 快照串店 = 直接丢掉，宁慢不错
    return data


def _save_offers_snapshot(store_id: Any, payload: Dict[str, Any]) -> None:
    path = _offers_snapshot_path(store_id)
    if path is None or not payload.get("items"):
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, path)
    except Exception:
        pass


def _offers_cache(store_id: Any = None) -> Dict[str, Any]:
    """The offers-list cache bucket for ONE store (addendum 2 §2)."""
    info = _effective_store(store_id)
    return _OFFERS_BY_STORE.setdefault(info["storeId"] or "__none__", {
        "at": 0.0, "ttl": OFFERS_TTL, "items": [], "error": None, "demo": False, "mode": "empty",
        "storeId": info["storeId"], "storeName": info["storeName"], "liveAt": None})


_WARM_AT: Dict[str, float] = {}


def _prewarm_offers(store_id: Any = None) -> bool:
    """Refresh this store's ``/offers`` cache in a BACKGROUND THREAD (never blocks).

    The status-bar chip polls ``/overview`` every 60s, so hooking the warm-up there means the
    catalogue is usually already built by the time the operator opens a heavy screen (cold
    builds take ~30s on a 1300-offer account). Guarded per store so polls cannot stack threads.
    """
    try:
        info = _effective_store(store_id)
        sid = str(info.get("storeId") or "")
        if not sid:
            return False
        if not _key_configured(sid):
            return False
        cache = _offers_cache(sid)
        if cache.get("items") and (time.time() - float(cache.get("at") or 0)) < float(cache.get("ttl") or OFFERS_TTL):
            return False
        if time.time() - float(_WARM_AT.get(sid) or 0.0) < 60.0:
            return False
        _WARM_AT[sid] = time.time()
        def _warm_now(store: str) -> None:
            # both layers: the raw /offers fetch AND the expensive mapped catalogue
            # 两层都各自吞异常：后台线程往日志里打堆栈对交付是支持负担，而且没人在等它。
            try:
                _offer_rows(store, force=True)
            except Exception:
                pass
            try:
                _catalog_items(store_id=store)
            except Exception:
                pass

        threading.Thread(target=lambda: _warm_now(sid), name="tk-offers-warm", daemon=True).start()
        return True
    except Exception:
        return False


def _offer_rows(store_id: Any = None, force: bool = False) -> Dict[str, Any]:
    """The raw ``/offers`` rows (expanded stock) for ONE store — the FULL list.

    Per-store (``?storeId=`` decides which shop's key is used) and memoized ≤60 s, so the
    full-account pagination is paid once per store per window; ``mapped`` is the number
    actually fetched, ``truncated`` says whether the safety caps cut the list short
    (``total`` must never lie, and one store must never show another store's offers).
    """
    info = _effective_store(store_id)
    cache = _offers_cache(store_id)
    now = time.time()
    if not force and cache["items"] and (now - float(cache.get("at") or 0)) < float(cache.get("ttl") or OFFERS_TTL):
        return cache
    # 冷缓存：先看磁盘快照（上次成功拉到的行），有就先端出来 —— 后端刚重启/应用刚拉起时
    # 这一步把 51s 的等待变成毫秒，随后由后台线程刷新。
    if not cache["items"]:
        snap = _load_offers_snapshot(info.get("storeId"))
        if snap:
            cache.update({
                "at": float(snap.get("at") or 0.0), "ttl": OFFERS_TTL,
                "items": snap.get("items") or [], "error": None, "demo": False, "mode": "live",
                "storeId": snap.get("storeId") or info["storeId"],
                "storeName": snap.get("storeName") or info["storeName"],
                "liveAt": snap.get("liveAt"), "count": len(snap.get("items") or []),
                "mapped": snap.get("mapped"), "pages": snap.get("pages"),
                "truncated": snap.get("truncated"), "maxRows": snap.get("maxRows"),
                "fromSnapshot": True,
            })
    # 有（过期的）数据就先返回，绝不让请求路径白等一次全量拉取：后台单飞刷新。
    if not force and cache["items"]:
        st = time.time() - float(cache.get("at") or 0.0)
        if st >= float(cache.get("ttl") or OFFERS_TTL):
            refreshing = _prewarm_offers(store_id)
            out = dict(cache)
            out.update({"stale": True, "ageSeconds": round(st, 1),
                        "refreshing": bool(refreshing), "ok": True})
            return out
        return cache
    previous = list(cache["items"])
    result: Dict[str, Any] = {
        "at": now, "ttl": OFFERS_TTL, "items": [], "error": None, "demo": False, "mode": "local",
        "storeId": info["storeId"], "storeName": info["storeName"], "liveAt": cache.get("liveAt"),
    }
    if not _key_configured(store_id):
        # 没有 Key 就是空：给出明确原因，绝不返回示例目录（零模拟数据）
        result.update({"items": [], "demo": False, "ok": False, "mode": "no-key",
                       "requires": "Seller Key",
                       "error": "店铺 {0}（{1}）未绑定 Seller X-API-Key：读不到该店商品列表".format(
                           info["storeId"] or "—", info["storeName"] or "—")})
        cache.update(result)
        return cache
    fetched = _fetch_all_offers(store_id=store_id)
    rows = fetched["rows"]
    err = fetched["error"]
    if err or not rows:
        # degrade: serve the last live list for THIS store (marked degraded), never fake rows
        fallback = rows or previous
        result.update({
            "items": fallback,
            "demo": False,
            "ok": False,
            "mode": "degraded" if fallback else "error",
            "requires": None if fallback else "Seller API",
            "error": err or "Seller API returned no offers",
            "degraded": True,
            "ttl": OFFERS_FAIL_TTL,
        })
        cache.update(result)
        return cache
    result.update({"items": rows, "ok": True, "mode": "live", "liveAt": _iso_now(), "count": len(rows),
                   "mapped": len(rows), "pages": fetched["pages"], "truncated": fetched["truncated"],
                   "maxRows": fetched["maxRows"],
                   # 真拉到最新之后必须把"旧数据"的标记清干净：否则界面会一直挂着
                   # 「目录来自快照」，操作员就再也判断不出自己看的是不是刚拉的那份。
                   "stale": False, "fromSnapshot": False, "refreshing": False, "ageSeconds": 0.0})
    cache.update(result)
    # 落盘快照（只存成功拉到的真实行）：下次冷启动先用它，再后台刷新。
    _save_offers_snapshot(info.get("storeId"), {
        "at": float(cache.get("at") or time.time()), "storeId": info.get("storeId"),
        "storeName": info.get("storeName"), "liveAt": cache.get("liveAt"),
        "items": rows, "count": len(rows), "mapped": len(rows), "pages": fetched["pages"],
        "truncated": fetched["truncated"], "maxRows": fetched["maxRows"],
    })
    return cache


def _rows_for_store(store_id: Any = None, ttl: float = 60.0) -> Dict[str, Any]:
    """``{rows, error, storeId, storeName, source, mode, mapped}`` for a store-scoped read.

    Every store (active or not) goes through the same per-store offers cache, so two
    stores never share a list and never cost a second fetch inside the TTL window.
    """
    data = _offer_rows(store_id)
    info = _effective_store(store_id)
    return {"rows": data.get("items") or [], "error": data.get("error"),
            "storeId": data.get("storeId") or info["storeId"],
            "storeName": data.get("storeName") or info["storeName"],
            "source": "store-offers-cache（per-store，TTL {0}s）".format(int(ttl)),
            "mode": data.get("mode"), "demo": bool(data.get("demo")),
            "mapped": int(data.get("mapped") or len(data.get("items") or []))}


def _account_warehouse_id(store_id: Any = None) -> Dict[str, Any]:
    """The account's OWN ``seller_warehouse_id``, read from live offers — never invented.

    Every offer of this account carries the same platform-assigned warehouse id, so the
    first offer that has a ``seller_warehouse_stock`` expand answers for the account.
    """
    data = _rows_for_store(store_id)
    for row in (data.get("rows") or []):
        warehouse = _seller_warehouse_id(row)
        if warehouse is not None:
            return {"warehouseId": warehouse, "source": data.get("source"),
                    "fromSku": row.get("sku"), "storeId": data.get("storeId"),
                    "storeName": data.get("storeName"), "error": None,
                    "sampleQuantity": (row.get("seller_warehouse_stock") or [{}])[0].get("quantity_available")
                    if isinstance(row.get("seller_warehouse_stock"), list) and row.get("seller_warehouse_stock") else None}
    return {"warehouseId": None, "source": data.get("source"), "error": data.get("error")
            or "该账号的 offer 列表没有任何 seller_warehouse_stock expand：拿不到平台分配的卖家仓 ID（绝不凭空造）",
            "storeId": data.get("storeId"), "storeName": data.get("storeName")}


def _offers_for_route(store_id: Any = None) -> List[Dict[str, Any]]:
    """Own-offer rows for the 跟卖 verdict.

    Reads the warm ≤60 s cache when we have it (so /collection never pays for a
    network round-trip twice) and otherwise does one TTL-guarded fetch — a failure
    degrades to 'no own offer', never an exception. Demo rows are never treated as
    "this account really sells it".
    """
    cache = _offers_cache(store_id)
    now = time.time()
    fresh = cache["items"] and (now - float(cache.get("at") or 0)) < float(cache.get("ttl") or OFFERS_TTL)
    rows = cache["items"] if fresh else []
    if not rows and _key_configured(store_id):
        rows = _offer_rows(store_id).get("items") or []
    if cache.get("demo"):
        return []
    return [row for row in rows if isinstance(row, dict)]


def _find_offer(rows: Sequence[Dict[str, Any]], target: Any) -> Optional[Dict[str, Any]]:
    """Resolve a sku / offer_id / TSIN / PLID / barcode to this account's offer row."""
    needle = str(target or "").strip()
    if not needle:
        return None
    low = needle.lower()
    for offer in rows:
        if str(offer.get("sku") or "").strip().lower() == low:
            return offer
    for offer in rows:
        if str(offer.get("offer_id") or "").strip().lower() == low:
            return offer
    digits = _plid_of(needle)
    if digits:
        for offer in rows:
            if _plid_of(offer.get("productline_id")) == digits:
                return offer
        for offer in rows:
            if _plid_of(offer.get("tsin_id") or offer.get("tsin")) == digits:
                return offer
    for offer in rows:
        if str(offer.get("barcode") or "").strip().lower() == low:
            return offer
    return None


# --------------------------------------------------------------------------
# Filters / sort / stats
# --------------------------------------------------------------------------

def _haystack(item: Dict[str, Any]) -> str:
    enrichment = item.get("enrichment") or {}
    return " ".join([
        str(item.get("title") or ""),
        str(item.get("sku") or ""),
        str(item.get("barcode") or ""),
        str(item.get("tsin") or ""),
        str(item.get("plid") or ""),
        str(item.get("offerId") or ""),
        str(enrichment.get("categoryPath") or ""),
        str(enrichment.get("brand") or ""),
        str(item.get("label") or ""),
    ]).lower()


def _sort_items(items: List[Dict[str, Any]], sort: str) -> List[Dict[str, Any]]:
    spec = str(sort or "").strip().lower()
    explicit: Optional[bool] = None
    if spec.startswith("-"):
        explicit, spec = True, spec[1:]
    elif spec.startswith("+"):
        explicit, spec = False, spec[1:]
    if ":" in spec:
        spec, _, direction = spec.partition(":")
        direction = direction.strip()
        if direction in ("desc", "down", "-1"):
            explicit = True
        elif direction in ("asc", "up", "1"):
            explicit = False
    spec = spec or "updated"
    keys: Dict[str, Callable[[Dict[str, Any]], Any]] = {
        "title": lambda i: str(i.get("title") or "").lower(),
        "sku": lambda i: str(i.get("sku") or ""),
        "price": lambda i: float(i.get("price") or 0),
        "rrp": lambda i: float(i.get("rrp") or 0),
        "stock": lambda i: int((i.get("stock") or {}).get("totalAvailable") or 0),
        "sold30": lambda i: int((i.get("stock") or {}).get("totalSold30") or 0),
        "updated": lambda i: str(i.get("updatedAt") or ""),
        "created": lambda i: str(i.get("createdAt") or ""),
        "wishlist": lambda i: int(i.get("wishlist") or 0),
        "discount": lambda i: float(i.get("discount") or 0),
        "quality": lambda i: int(i.get("listingQuality") or 0),
        "score": lambda i: int((i.get("content") or {}).get("score") or 0),
    }
    key = keys.get(spec)
    if key is None:
        spec, key = "updated", keys["updated"]
    default_desc = spec in ("updated", "created", "stock", "sold30", "wishlist", "quality")
    desc = default_desc if explicit is None else explicit
    return sorted(items, key=key, reverse=desc)


def _filter_items(items: List[Dict[str, Any]], q: str = "", status: str = "", content: str = "",
                  stock: str = "", sort: str = "") -> List[Dict[str, Any]]:
    out = items
    needle = str(q or "").strip().lower()
    if needle:
        out = [i for i in out if needle in _haystack(i)]
    wanted = str(status or "").strip()
    if wanted:
        low = wanted.lower()
        out = [i for i in out if str(i.get("status") or "").lower() == low
               or str(i.get("statusLabel") or "") == wanted]
    spec = str(content or "").strip().lower()
    if spec:
        if spec in ("missing", "incomplete", "any", "missing-any"):
            out = [i for i in out if (i.get("content") or {}).get("missingKeys")]
        elif spec in ("complete", "ok", "full", "done"):
            out = [i for i in out if not (i.get("content") or {}).get("missingKeys")]
        else:
            key = spec.split("-", 1)[1] if spec.startswith("missing-") else spec
            if key in MISSING_LABELS:
                out = [i for i in out if key in ((i.get("content") or {}).get("missingKeys") or [])]
    spec = str(stock or "").strip().lower()
    if spec:
        def avail(row: Dict[str, Any]) -> int:
            return int((row.get("stock") or {}).get("totalAvailable") or 0)

        if spec in ("zero", "none", "out", "outofstock"):
            out = [i for i in out if avail(i) <= 0]
        elif spec in ("in", "yes", "instock", "available", "stock"):
            out = [i for i in out if avail(i) > 0]
        elif spec == "low":
            out = [i for i in out if 0 < avail(i) <= 5]
        elif spec in ("incoming", "onway", "receiving"):
            out = [i for i in out
                   if int((i.get("stock") or {}).get("totalOnWay") or 0)
                   + int((i.get("stock") or {}).get("totalReceiving") or 0) > 0]
        elif spec == "sold":
            out = [i for i in out if int((i.get("stock") or {}).get("totalSold30") or 0) > 0]
    return _sort_items(out, sort)


def _catalog_stats(items: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Counters shared by ``GET /products`` (stats block) and ``GET /products/stats``."""
    total = len(items)
    by_status: Dict[str, int] = {}
    by_category: Dict[str, int] = {}
    by_origin: Dict[str, int] = {"own": 0, "follow": 0, "unknown": 0}
    by_origin_signal: Dict[str, int] = {}
    missing = {"image": 0, "barcode": 0, "category": 0, "text": 0}
    for item in items:
        status = str(item.get("status") or "unknown")
        by_status[status] = by_status.get(status, 0) + 1
        origin = item.get("origin") if isinstance(item.get("origin"), dict) else {}
        code = str(origin.get("code") or "unknown")
        by_origin[code] = by_origin.get(code, 0) + 1
        for signal in (origin.get("signals") or []):
            name = str((signal or {}).get("source") or "")
            if name:
                by_origin_signal[name] = by_origin_signal.get(name, 0) + 1
        path = str((item.get("enrichment") or {}).get("categoryPath") or "")
        segments = _split_path(path)
        label = segments[0].strip() if segments else "未分类"
        by_category[label or "未分类"] = by_category.get(label or "未分类", 0) + 1
        for key in ((item.get("content") or {}).get("missingKeys") or []):
            if key in missing:
                missing[key] += 1
    prices = [float(i.get("price") or 0) for i in items]
    valued = [p for p in prices if p > 0]
    available = sum(int((i.get("stock") or {}).get("totalAvailable") or 0) for i in items)
    categories = [
        {"category": name, "count": count, "share": _r(count * 100.0 / total, 1) if total else 0.0}
        for name, count in sorted(by_category.items(), key=lambda kv: (-kv[1], kv[0]))
    ]
    return {
        "total": total,
        "sellable": sum(1 for i in items if i.get("sellable")),
        "notSellable": by_status.get("not_buyable", 0),
        "disabled": by_status.get("disabled_by_seller", 0) + by_status.get("disabled_by_takealot", 0),
        "disabledBySeller": by_status.get("disabled_by_seller", 0),
        "disabledByTakealot": by_status.get("disabled_by_takealot", 0),
        "missingImage": missing["image"],
        "missingBarcode": missing["barcode"],
        "missingCategory": missing["category"],
        "missingText": missing["text"],
        "zeroStock": sum(1 for i in items if int((i.get("stock") or {}).get("totalAvailable") or 0) <= 0),
        "inStock": sum(1 for i in items if int((i.get("stock") or {}).get("totalAvailable") or 0) > 0),
        "availableUnits": available,
        "sold30": sum(int((i.get("stock") or {}).get("totalSold30") or 0) for i in items),
        "enriched": sum(1 for i in items if (i.get("enrichment") or {}).get("cached")),
        "byStatus": {name: by_status[name] for name in sorted(by_status, key=lambda k: (-by_status[k], k))},
        "byOrigin": {name: by_origin.get(name, 0) for name in ("own", "follow", "unknown")},
        "byOriginSignal": {name: by_origin_signal[name] for name in sorted(by_origin_signal, key=lambda k: (-by_origin_signal[k], k))},
        "byCategory": categories,
        "value": {
            "listed": _r(sum(prices)),
            "withStock": _r(sum(float(i.get("price") or 0) * int((i.get("stock") or {}).get("totalAvailable") or 0)
                                for i in items)),
            "sellable": _r(sum(float(i.get("price") or 0) for i in items if i.get("sellable"))),
            "avgPrice": _r(sum(valued) / len(valued)) if valued else 0.0,
            "maxPrice": _r(max(prices)) if prices else 0.0,
        },
    }


_CATALOG_BY_STORE: Dict[str, Dict[str, Any]] = {}


def _catalog_items(offers: Optional[Dict[str, Any]] = None, store_id: Any = None) -> Dict[str, Any]:
    """The mapped catalogue + every join it needs, built once per request window.

    Mapping a >1300-offer account costs real CPU (compliance scan + crawl-card join per
    row), so the built context is memoized while the *same* offers list is warm
    (``offers["at"]`` identity) and for at most ``CATALOG_MEMO_TTL``; rows are handed out as
    shallow copies so a caller can hang per-request keys off them safely. Writes bust it
    explicitly via ``_bust_offer_caches()`` / ``_crawl_map_bust()``.
    """
    if offers is not None:
        return _build_catalog_items(offers, store_id)
    offers = _offer_rows(store_id)
    memo = _CATALOG_BY_STORE.setdefault(str(offers.get("storeId") or "__none__"),
                                        {"at": 0.0, "offersAt": 0.0, "ctx": {}})
    same_list = float(memo.get("offersAt") or 0) == float(offers.get("at") or 0) and bool((memo.get("ctx") or {}).get("items"))
    if same_list and (time.time() - float(memo.get("at") or 0)) < CATALOG_MEMO_TTL:
        built = dict(memo["ctx"])
        built.update({"offers": offers, "items": [dict(item) for item in memo["ctx"]["items"]],
                      "memoized": True})
        return built
    # 映射过期但 offer 行还是同一批：行数不变就先把旧映射端出去（1322 行重建实测 3.8s，
    # 让操作员干等没有意义），后台单飞重建。行真的变了才同步重建——那时旧映射是对不上的。
    if same_list:
        _prewarm_catalog_map(store_id, offers)
        built = dict(memo["ctx"])
        built.update({"offers": offers, "items": [dict(item) for item in memo["ctx"]["items"]],
                      "memoized": True, "memoStale": True,
                      "memoAgeSeconds": round(time.time() - float(memo.get("at") or 0), 1)})
        return built
    built = _build_catalog_items(offers, store_id)
    memo.update({"at": time.time(), "offersAt": offers.get("at"), "ctx": built})
    built["memoized"] = False
    return built


_CATALOG_MAP_WARM_AT: Dict[str, float] = {}


def _prewarm_catalog_map(store_id: Any = None, offers: Optional[Dict[str, Any]] = None) -> bool:
    """后台重建映射目录（单飞，每店 30s 一次）。见 ``_catalog_items`` 的说明。"""
    try:
        sid = str((offers or {}).get("storeId") or _effective_store(store_id).get("storeId") or "")
        if not sid:
            return False
        if time.time() - float(_CATALOG_MAP_WARM_AT.get(sid) or 0.0) < 30.0:
            return False
        _CATALOG_MAP_WARM_AT[sid] = time.time()

        def worker() -> None:
            try:
                rows = offers if offers is not None else _offer_rows(sid)
                built = _build_catalog_items(rows, sid)
                _CATALOG_BY_STORE[str(rows.get("storeId") or sid)] = {
                    "at": time.time(), "offersAt": rows.get("at"), "ctx": built}
            except Exception:
                pass
        threading.Thread(target=worker, name="tk-catalog-map-warm", daemon=True).start()
        return True
    except Exception:
        return False


def _build_catalog_items(offers: Dict[str, Any], store_id: Any = None) -> Dict[str, Any]:
    entries = _crawl_entries()
    drafts, collection, prices = _draft_index(), _collection_index(), _price_log_index()
    items = [_offer_item(offer, entries, drafts, collection, prices, store_id=store_id)
             for offer in (offers.get("items") or []) if isinstance(offer, dict)]
    return {"offers": offers, "items": items, "entries": entries,
            "drafts": drafts, "collection": collection, "prices": prices}


def _catalog_freshness(offers: Any, ctx: Any = None) -> Dict[str, Any]:
    """目录数据的新鲜度 —— 界面据此显示"这是 N 秒前的快照，后台正在刷新"。

    没有它，操作员看到的静默旧数据与实时数据长得一模一样（这个交付不许有"看不出是啥时候的数据"）。
    """
    data = offers if isinstance(offers, dict) else {}
    age = data.get("ageSeconds")
    if age is None and data.get("at"):
        try:
            age = round(max(0.0, time.time() - float(data.get("at") or 0)), 1)
        except (TypeError, ValueError):
            age = None
    return {
        "stale": bool(data.get("stale")),
        "ageSeconds": age,
        "refreshing": bool(data.get("refreshing")),
        "fromSnapshot": bool(data.get("fromSnapshot")),
        "liveAt": data.get("liveAt"),
        "count": data.get("count") or len(data.get("items") or []),
        # 映射层（合规扫描 + 抓取卡片 join）也会过期，它同样是"先端旧的、后台重建"，
        # 所以要跟 offer 层分开说，别让操作员以为两份数据是同一个新鲜度。
        "mappedStale": bool((ctx or {}).get("memoStale")),
        "mappedAgeSeconds": (ctx or {}).get("memoAgeSeconds"),
    }


def _store_scope(requested: Any = None) -> Dict[str, Any]:
    """The store label for a read response — and it IS the store whose key was used.

    A concrete ``storeId`` now drives the live calls too (addendum 2 §1): every read
    endpoint takes ``?storeId=`` and answers from THAT shop, falling back to
    ``activeStoreId`` when it is omitted. An unknown id is reported, never swapped.
    """
    info = _effective_store(requested)
    return {"storeId": info["storeId"], "storeName": info["storeName"],
            "scopedFromActive": not info["storeScoped"], "requestedStoreId": info["requestedStoreId"],
            "resolved": info.get("resolved"), "note": info.get("note")}


# --------------------------------------------------------------------------
# 采集箱 additions — images / full text / category / 上架-跟卖 target
# --------------------------------------------------------------------------

def _public_product_url(plid: Any, fallback: str = "") -> str:
    number = _plid_of(plid)
    if number:
        return "https://www.takealot.com/p/PLID{0}".format(number)
    return str(fallback or "")


_PLACEHOLDER_IMAGE = re.compile(r"^https://media\.takealot\.com/covers/PLID\d+/large\.jpg$", re.I)


def _sell_route(row: Dict[str, Any], product: Dict[str, Any], meta: Optional[Dict[str, Any]] = None,
                offers: Optional[Sequence[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """上架 / 跟卖 落点: 'offer' (platform listing exists) vs 'loadsheet' (new item)."""
    meta = meta or {}
    number = _plid_of(row.get("plid") or row.get("sourceUrl") or row.get("tsin"))
    plid = "PLID{0}".format(number) if number else ""
    url = _public_product_url(number, str(row.get("sourceUrl") or ""))
    rows = list(offers or [])
    own = _find_offer(rows, plid or str(row.get("sku") or "")) or _find_offer(rows, str(row.get("tsin") or "")) \
        or _find_offer(rows, str(row.get("barcode") or ""))
    if own is None and number:
        own = next((o for o in rows if _plid_of(o.get("productline_id")) == number), None)
    if own:
        return {
            "route": "offer",
            "source": "seller-offers",
            "reason": (
                "本店 Offer 已存在（SKU {0}，Offer {1}，PLID {2}，状态 {3}）：走跟卖/改价，"
                "不要新建 Product Information Loadsheet。"
            ).format(own.get("sku") or "—", own.get("offer_id") or "—", plid or "—",
                     STATUS_LABELS.get(str(own.get("status") or ""), own.get("status") or "—")),
            "targetUrl": url,
            "targetLabel": "已在售 · 去跟卖/改价",
            "targetKind": "url",
            "sku": str(own.get("sku") or ""),
            "skuLabel": str(own.get("sku") or ""),
            "offerId": own.get("offer_id"),
            "tsin": "TSIN{0}".format(_plid_of(own.get("tsin_id"))) if _plid_of(own.get("tsin_id")) else str(row.get("tsin") or ""),
        }
    if product:
        return {
            "route": "offer",
            "source": "public-catalogue",
            "reason": (
                "Takealot 公开目录已有该商品（PLID {0}，{1} 张图，描述 {2} 字）："
                "按 TSIN/条码跟卖 Offer 即可，无需 Product Information Loadsheet。"
            ).format(plid or "—", len(_product_image_urls(product)),
                     len(str(product.get("description") or ""))),
            "targetUrl": url,
            "targetLabel": "平台已在售 · 可跟卖",
            "targetKind": "url",
            "sku": str(row.get("sku") or ""),
            "tsin": str(row.get("tsin") or ""),
        }
    return {
        "route": "loadsheet",
        "source": "none",
        "reason": (
            "Takealot 公开目录与公开接口都没有该商品（{0}）：属新品，"
            "必须用 Product Information Loadsheet 建档（Seller Portal → Add Products，人工 QC）。"
        ).format(meta.get("error") or plid or "目标无法解析为 PLID"),
        "targetUrl": plid or url or str(row.get("tsin") or ""),
        "targetLabel": "新品 · 需建档",
        "targetKind": "prefill",
        "sku": str(row.get("sku") or ""),
        "tsin": str(row.get("tsin") or ""),
    }


def _crawl_card_for_row(row: Dict[str, Any], entries: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Cache-first card lookup for a 采集箱 row (never a network call)."""
    entries = _crawl_entries() if entries is None else entries
    for raw in (row.get("plid"), row.get("sourceUrl"), row.get("tsin")):
        number = _plid_of(raw)
        if number:
            card = _cached_card(number, entries)
            if card.get("product"):
                return card
    return {}


def _row_media(row: Dict[str, Any], card: Optional[Dict[str, Any]] = None,
               entries: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """The 采集箱 media block: stored values win, the crawl cache fills the gaps."""
    card = card if card is not None else _crawl_card_for_row(row, entries)
    product = card.get("product") or {}
    stored_images = [str(u) for u in (row.get("images") or []) if str(u or "").strip()]
    crawl_images = _product_image_urls(product) if product else []
    stored_main = str(row.get("imageUrl") or "").strip()
    placeholder = bool(_PLACEHOLDER_IMAGE.match(stored_main))
    if crawl_images and (not stored_images or placeholder or not stored_main):
        ordered = crawl_images + [u for u in stored_images if u not in crawl_images]
    else:
        ordered = stored_images + [u for u in crawl_images if u not in stored_images]
    images: List[str] = []
    for url in ordered:
        if url and url not in images:
            images.append(url)
    if not images and stored_main:
        # keep the legacy single-image rows populated (imageUrl stays the cover)
        images = [stored_main]
    image_url = images[0] if images else stored_main
    description = str(row.get("description") or "").strip() or str(product.get("description") or "").strip()
    category_path = str(row.get("categoryPath") or "").strip() or _crawl_category_path(product) \
        or str(row.get("category") or "")
    return {
        "images": images[:20],
        "imageUrl": image_url,
        "description": description,
        "descriptionLen": len(description),
        "categoryPath": category_path,
        "productTargetUrl": str(row.get("productTargetUrl") or "") or _public_product_url(
            row.get("plid") or row.get("sourceUrl") or row.get("tsin"), str(row.get("sourceUrl") or "")),
        "rating": product.get("rating") if product.get("rating") is not None else row.get("rating"),
        "reviews": product.get("reviews") if product.get("reviews") is not None else row.get("reviews"),
        "sellerCount": product.get("sellerCount") if product.get("sellerCount") is not None else row.get("sellerCount"),
        "plid": "PLID{0}".format(_plid_of(row.get("plid") or row.get("sourceUrl") or row.get("tsin")))
                if _plid_of(row.get("plid") or row.get("sourceUrl") or row.get("tsin")) else "",
    }


def _collection_row_media(row: Dict[str, Any], entries: Optional[Dict[str, Any]] = None,
                          offers: Optional[Sequence[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """The 采集箱 additions the UI needs on every row (CONTRACT v4).

    Cache-first: the crawl cache supplies images/full text/category, the stored row
    wins where it already has them, and the 上架/跟卖 verdict is local (own offers →
    跟卖, public catalogue hit → 跟卖, otherwise → Loadsheet 建档).
    """
    card = _crawl_card_for_row(row, entries)
    product = card.get("product") or {}
    media = _row_media(row, card)
    stored = row.get("sellRoute")
    route = stored if isinstance(stored, dict) and stored.get("route") else None
    if not route:
        route = _sell_route(row, product, None, offers if offers is not None else _offers_for_route())
    media["sellRoute"] = route
    media["sku"] = str(row.get("sku") or "").strip() or str(route.get("sku") or "")
    return media


# --------------------------------------------------------------------------
# Endpoints — 商品管理 + 采集箱 refresh
# --------------------------------------------------------------------------

@router.post("/catalog/refresh")
def catalog_refresh(payload: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
    """同步重拉全店目录（真店 1300+ offer 实测 30~55s）—— 界面「刷新目录」按钮走这里。

    stale-while-revalidate 之后，普通读请求只保证"秒开且不卡"，绝不会为最新的等一次全量：
    没有这条强制通路，操作员点「刷新」会静默地拿到同一份旧数据，看起来像按钮坏了。
    失败时保留旧行（_offer_rows 内部回滚），不会把目录清空。
    """
    store_id = payload.get("storeId") or payload.get("store_id") or ""
    _bad = _unresolved_store_error(store_id)
    if _bad:
        return _bad
    info = _effective_store(store_id)
    sid = str(info.get("storeId") or "")
    if not sid or not _key_configured(sid):
        return {"ok": False, "error": "该店未绑定 Seller X-API-Key，无法刷新目录",
                "storeId": sid, "storeName": info.get("storeName")}
    started = time.time()
    try:
        rows = _offer_rows(sid, force=True)
    except Exception as exc:  # pragma: no cover - defensive
        return {"ok": False, "error": _sanitize(exc), "storeId": sid}
    _CATALOG_BY_STORE.pop(sid, None)      # 目录本身要按新行重建
    return {"ok": True, "storeId": sid, "storeName": info.get("storeName"),
            "seconds": round(time.time() - started, 2),
            "count": len(rows.get("items") or []),
            "catalog": _catalog_freshness(rows)}


@router.get("/products")
def products(q: str = "", status: str = "", sort: str = "", content: str = "",
                   stock: str = "", limit: int = 50, offset: int = 0, storeId: str = "") -> Dict[str, Any]:
    """The store's full catalogue: Seller API ``/offers`` + 分仓库存 + 抓取补全 + ERP 本地关联."""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        try:
            page_size = max(1, min(int(limit), 200))
        except (TypeError, ValueError):
            page_size = 50
        try:
            start = max(0, int(offset))
        except (TypeError, ValueError):
            start = 0
        aggregate = _wants_all_stores(storeId) and len(_stores()) > 1
        if aggregate:
            context = _aggregate_catalog(storeId)
        else:
            context = _catalog_items(store_id=storeId)
        items = context["items"]
        offers = context["offers"]
        scope = _store_scope(storeId)
        filtered = _filter_items(items, q=q, status=status, content=content, stock=stock, sort=sort)
        page = filtered[start:start + page_size]
        payload: Dict[str, Any] = {
            "ok": True,
            "mode": offers.get("mode") or "empty",
            "storeId": scope["storeId"],
            "storeName": scope["storeName"],
            "storeScope": "all" if aggregate else "store",
            "aggregate": bool(aggregate),
            "scopedFromActive": scope.get("scopedFromActive"),
            "requestedStoreId": scope.get("requestedStoreId"),
            "total": len(items),
            "mapped": int(offers.get("mapped") or len(offers.get("items") or [])),
            "truncated": bool(offers.get("truncated")),
            "pages": offers.get("pages"),
            "catalog": _catalog_freshness(offers, context),
            "filtered": len(filtered),
            "count": len(page),
            "limit": page_size,
            "offset": start,
            "hasMore": (start + len(page)) < len(filtered),
            "filters": {"q": q, "status": status, "content": content, "stock": stock,
                        "sort": (sort or "updated")},
            "stats": _catalog_stats(items),
            "items": page,
            "liveAt": offers.get("liveAt"),
            "demo": bool(offers.get("demo")),
            "generatedAt": _iso_now(),
        }
        if offers.get("error"):
            payload["error"] = offers["error"]
        if scope.get("note"):
            payload["note"] = scope["note"]
        if aggregate:
            payload["stores"] = context.get("perStore") or []
            payload["scopeNote"] = "汇总：{0} 家店的商品目录已合并，每行标注所属店铺（{1}）。筛选与统计作用于合并后的全量。".format(
                len(payload["stores"]),
                "、".join("{0} {1} 条".format(s2.get("storeName"), s2.get("count")) for s2 in payload["stores"]))
            failed = [s2 for s2 in payload["stores"] if s2.get("error")]
            if failed:
                payload["warnings"] = ["店铺 {0} 取数失败：{1}".format(s2.get("storeName"), s2.get("error")) for s2 in failed]
        if offers.get("degraded"):
            payload["hint"] = "Seller API 调用失败：已回退到最近一次成功的商品列表（degraded，不空模块）。"
        elif offers.get("truncated"):
            payload["hint"] = ("账号商品数超过安全上限 {0} 条，列表只映射了前 {1} 条"
                               "（total/mapped 已如实区分）。").format(offers.get("maxRows"), payload.get("mapped"))
        elif offers.get("mode") == "scoped-empty":
            payload["hint"] = "店铺 {0} 未绑定 Seller X-API-Key：该店商品列表为空（不会借用其他店铺的数据）。".format(
                payload.get("storeId"))
        elif not _key_configured(storeId):
            payload["requires"] = "Seller Key"
            payload["empty"] = True
            payload["hint"] = ("未配置 Seller X-API-Key：商品列表为空（不返回任何示例商品）。"
                               "在「多店铺设置」里绑定 Key 后即为全店真实商品。")
        return payload

    return _safe(build, _fallback({
        "ok": False, "mode": "local", "total": 0, "mapped": 0, "filtered": 0, "count": 0,
        "stats": {}, "items": [],
    }))


@router.get("/products/stats")
def products_stats(storeId: str = "") -> Dict[str, Any]:
    """The catalogue counters on their own — identical numbers to ``/products``' stats block."""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        context = _catalog_items(store_id=storeId)
        scope = _store_scope(storeId)
        payload: Dict[str, Any] = {
            "ok": True,
            "mode": context["offers"].get("mode") or "empty",
            "storeId": scope["storeId"],
            "storeName": scope["storeName"],
            "generatedAt": _iso_now(),
        }
        payload.update(_catalog_stats(context["items"]))
        payload["mapped"] = int(context["offers"].get("mapped") or len(context["offers"].get("items") or []))
        payload["truncated"] = bool(context["offers"].get("truncated"))
        payload["pages"] = context["offers"].get("pages")
        payload["catalogSource"] = "Seller API /offers 全量分页（与 GET /products 的 total/stats 同源同数）"
        payload["resolved"] = scope.get("resolved")
        payload["liveAt"] = context["offers"].get("liveAt")
        if context["offers"].get("error"):
            payload["error"] = context["offers"]["error"]
        if context["offers"].get("degraded"):
            payload["hint"] = "Seller API 调用失败：统计基于最近一次成功的商品列表。"
        elif context["offers"].get("truncated"):
            payload["hint"] = ("账号商品数超过安全上限 {0} 条：统计基于已抓取的前 {1} 条"
                               "（total/mapped 已如实区分）。").format(context["offers"].get("maxRows"), payload["mapped"])
        elif context["offers"].get("mode") == "scoped-empty":
            payload["hint"] = "店铺 {0} 未绑定 Seller X-API-Key：统计为空（不会借用其他店铺的数据）。".format(
                payload.get("storeId"))
        elif not _key_configured(storeId):
            payload["requires"] = "Seller Key"
            payload["empty"] = True
            payload["hint"] = "未配置 Seller X-API-Key：统计为空（不基于任何示例目录）。"
        return payload

    return _safe(build, _fallback({"ok": False, "mode": "local", "total": 0, "mapped": 0, "byStatus": {},
                                   "byCategory": [], "value": {}}))


@router.get("/products/{sku}")
def product_detail(sku: str, refresh: bool = False, storeId: str = "") -> Dict[str, Any]:
    """One product: full crawled text, images, attributes, category, rating, velocity + ERP joins."""
    _bad_store = _unresolved_store_error(storeId)
    if _bad_store:
        return _bad_store
    def build() -> Dict[str, Any]:
        target = str(sku or "").strip()
        context = _catalog_items(store_id=storeId)
        offers = context["offers"]
        offer = _find_offer(offers.get("items") or [], target)
        number = _plid_of((offer or {}).get("productline_id") or target)
        card = _cached_card(number, context["entries"]) if number else {}
        crawl: Dict[str, Any] = {}
        if refresh and number:
            # refresh=1 may crawl live (the cache is 5 days; the UI's 抓取补全 is explicit)
            crawl = _crawl_target("PLID{0}".format(number), force=True) or {}
            live_product = crawl.get("product") if isinstance(crawl.get("product"), dict) else None
            if live_product:
                _crawl_map_bust()
                card = {
                    "product": live_product,
                    "windows": crawl.get("windows") or {},
                    "sales": crawl.get("sales") or {},
                    "rate": crawl.get("rate"),
                    "rateSource": crawl.get("rateSource"),
                    "fetchedAt": crawl.get("fetchedAt"),
                    "transport": crawl.get("transport"),
                    "cached": bool(crawl.get("cached")),
                    "fresh": True,
                    "ageDays": 0.0,
                }
        override = card if (card or {}).get("product") else None
        if offer is None:
            # 不在本店 offer 列表 = 显式 not-found：不再合成一行商品（UI 已有对应提示）
            scope = _store_scope(storeId)
            return {
                "ok": True, "found": False, "empty": True, "mode": offers.get("mode") or "empty",
                "sku": target,
                "plid": "PLID{0}".format(number) if number else "",
                "tsin": "",
                "item": {}, "detail": {"description": "", "images": [], "attributes": [], "crawl": {}},
                "local": {}, "writeHistory": [], "sellAction": {},
                "storeId": scope["storeId"], "storeName": scope["storeName"],
                "storeScoped": not scope["scopedFromActive"],
                "requestedStoreId": scope.get("requestedStoreId"),
                "catalogSize": len(offers.get("items") or []),
                "crawlCard": {"cached": bool((override or {}).get("product")),
                              "fetchedAt": (override or {}).get("fetchedAt"),
                              "title": ((override or {}).get("product") or {}).get("title"),
                              "price": ((override or {}).get("product") or {}).get("price")},
                "note": "该 SKU 不在当前店铺的 /offers 列表里（已比对本店 {0} 个 offer）。".format(
                    len(offers.get("items") or [])),
                "requires": None if _key_configured(storeId) else "Seller Key",
                "hint": ("商品管理只映射本店在售商品：要跟卖请先在「商品采集」里采集这个商品，"
                         "或核对 SKU/TSIN/barcode 是否属于本店。公开页抓取缓存里{0}该商品的记录。").format(
                    "有" if (override or {}).get("product") else "没有"),
                "generatedAt": _iso_now(),
            }
        item = _offer_item(offer, context["entries"], context["drafts"], context["collection"],
                           context["prices"], card_override=override, store_id=storeId)
        product = (override or {}).get("product") or {}
        enrichment = item.get("enrichment") or {}
        description = str(product.get("description") or "").strip()
        images = enrichment.get("images") or []
        attributes = product.get("attributes")
        if not isinstance(attributes, list) or not attributes:
            attributes = _product_attribute_pairs(product)
        category_path = str(enrichment.get("categoryPath") or "")
        transport = (override or {}).get("transport") or enrichment.get("transport")
        fetched_at = (override or {}).get("fetchedAt") or enrichment.get("fetchedAt")
        if crawl:
            crawl_meta = {
                "mode": str(crawl.get("mode") or "live"),
                "transport": crawl.get("transport"),
                "cached": bool(crawl.get("cached")),
                "fetchedAt": crawl.get("fetchedAt"),
                "error": crawl.get("error"),
                "hint": crawl.get("hint"),
                "fresh": True,
            }
        elif (override or {}).get("product") or enrichment.get("cached"):
            crawl_meta = {
                "mode": "cache",
                "transport": transport,
                "cached": True,
                "fetchedAt": fetched_at,
                "ageDays": (override or {}).get("ageDays") or enrichment.get("ageDays"),
                "fresh": bool(enrichment.get("fresh")),
                "hint": "" if description else "缓存卡片没有描述正文：点「抓取补全」(refresh=1) 现场抓取公开页面。",
            }
        else:
            crawl_meta = {
                "mode": "empty",
                "transport": None,
                "cached": False,
                "fetchedAt": None,
                "hint": "该 PLID 没有缓存卡片：点「抓取补全」(refresh=1) 现场抓取，或把原始 JSON 放进 state/ingest/。",
            }
        detail = {
            "description": description,
            "descriptionLen": len(description),
            "images": images,
            "attributes": attributes,
            "categoryPath": category_path,
            "categoryNames": enrichment.get("categoryNames") or [],
            "department": enrichment.get("department") or "",
            "subtitle": enrichment.get("subtitle") or str(product.get("subtitle") or ""),
            "brand": enrichment.get("brand") or str(product.get("brand") or ""),
            "rating": enrichment.get("rating"),
            "reviews": enrichment.get("reviews"),
            "sellerCount": enrichment.get("sellerCount"),
            "monthlySales": enrichment.get("monthlySales"),
            "rate": enrichment.get("rate"),
            "rateSource": enrichment.get("rateSource"),
            "windows": enrichment.get("windows") or {},
            "sales": (override or {}).get("sales") or {},
            "stock": product.get("stock") if isinstance(product.get("stock"), dict) else {},
            "url": enrichment.get("url") or _public_product_url(item.get("plid")),
            "crawl": crawl_meta,
        }
        detail_scope = _store_scope(storeId)
        payload: Dict[str, Any] = {
            "ok": True,
            "mode": str(crawl.get("mode")) if crawl else (offers.get("mode") or "empty"),
            "found": offer is not None,
            "storeId": detail_scope["storeId"],
            "storeName": detail_scope["storeName"],
            "storeScoped": not detail_scope["scopedFromActive"],
            "requestedStoreId": detail_scope.get("requestedStoreId"),
            "sku": target,
            "plid": item.get("plid"),
            "tsin": item.get("tsin"),
            "item": item,
            "detail": detail,
            "local": item.get("local") or {},
            "refresh": bool(refresh),
            "generatedAt": _iso_now(),
        }
        # ---- CONTRACT v5: 两个区块 + 双仓库存 + 写入历史 --------------------
        caps = _capabilities(storeId)
        live_card = card if (card or {}).get("product") else {}
        draft_row = _draft_for(offer or {}, context["drafts"])
        master = item.get("master") or _master_block(offer or {}, item, live_card)
        origin = item.get("origin") or _origin_block(offer or {}, item, live_card, draft_row, storeId)
        editable = _editable_block(offer or {}, item, caps, storeId)
        readonly = _readonly_stock(offer or {}, storeId)
        history = _write_history(item.get("sku") or target)
        local = dict(item.get("local") or {})
        local["writeHistory"] = history
        local["lastWriteAt"] = history[0]["at"] if history else None
        local["lastWriteOk"] = history[0]["ok"] if history else None
        local["writable"] = bool(offer is not None and caps.get("keyConfigured"))
        local["draftTitle"] = str((draft_row or {}).get("title") or "")
        item["master"] = master
        item["origin"] = origin
        sell_action = _sell_action(item.get("sku") or target, offer, item, caps,
                                   (card or {}).get("product") or {}, storeId)
        item["sellAction"] = sell_action
        payload.update({
            "master": master,
            "origin": origin,
            "editable": editable,
            "readonlyStock": readonly,
            "local": local,
            "writeHistory": history,
            "capabilities": caps,
            "sellAction": sell_action,
        })
        payload["hint"] = (
            "写入走 PATCH /products/{sku}（只写售价 / RRP / 自营仓库存 / 备货期，"
            "Seller API additionalProperties:false）；上下架与 Takealot 托管仓库存本店不可写。"
        )

        if crawl and not (crawl.get("product") or {}):
            payload["error"] = crawl.get("error") or "live crawl returned no product"
            payload["hint"] = crawl.get("hint") or detail["crawl"].get("hint")
        return payload

    return _safe(build, _fallback({
        "ok": False, "mode": "local", "found": False, "sku": sku,
        "item": {}, "detail": {"description": "", "images": [], "attributes": [], "crawl": {}}, "local": {},
    }))


@router.patch("/products/{sku}")
def product_write(sku: str, body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """写入本店 offer 的可写字段 — 售价 / RRP / 自营仓库存 / 备货期（CONTRACT v5 §2）。

    顺序固定：中文本地校验（失败**绝不**调用 API、也**不**写审计）→ 只把变化的可写字段
    PATCH 到 ``/offers/by_sku/{sku}`` → **重新读取** offer 做真实回读 → 审计落盘
    （``state/offer_writes.json`` + 一行人类可读的 ``state/price_log.json``）→ 打掉
    products 缓存，让列表立刻反映新价/新库存。
    """
    payload = body if isinstance(body, dict) else {}

    def build() -> Dict[str, Any]:
        target = str(sku or "").strip()
        dry_run = bool(payload.get("dryRun"))
        store_id = str(payload.get("storeId") or payload.get("store_id") or "").strip()
        store_label = _store_label(store_id)
        caps = _capabilities(store_id)
        errors: List[str] = []
        warnings: List[str] = []
        wanted: Dict[str, Any] = {}
        for key, raw in payload.items():
            if key in ("dryRun", "dry_run", "storeId", "store_id"):
                continue
            if key not in OFFER_WRITE_RULES:
                errors.append(_unwritable_message(key))
                continue
            number, error = _int_or_error(raw, key)
            if error:
                errors.append(error)
                continue
            wanted[key] = number
        if not wanted and not errors:
            errors.append("没有可写字段：body 至少要给 selling_price / rrp / seller_stock / minimum_leadtime_days 中的一个")
        base: Dict[str, Any] = {
            "ok": False, "dryRun": dry_run, "sku": target, "request": {}, "changed": [],
            "applied": [], "apiStatus": None, "offer": None, "warnings": warnings, "errors": errors,
            "error": None, "capabilities": caps, "generatedAt": _iso_now(),
            "writePath": "PATCH /products/{sku} → PATCH /offers/by_sku/{sku}",
            "writableKeys": list(OFFER_WRITE_RULES.keys()),
        }
        base.update({"storeId": store_label["storeId"], "storeName": store_label["storeName"],
                     "storeScoped": store_label["storeScoped"], "activeStoreId": store_label["activeStoreId"]})
        if errors:
            base["error"] = errors[0]
            base["hint"] = "校验未通过（中文本地校验）：没有调用 Seller API，也没有写审计日志。"
            return base
        key, key_error, _row = _store_key_for(store_id)
        if not key:
            base["error"] = key_error or "未配置 Seller X-API-Key：无法写入真实 offer。"
            base["hint"] = "在「设置 · 店铺」里配置该店铺的 Seller X-API-Key（live 模式）后再写。"
            return base
        before, read_err = _read_offer_live(target, store_id)
        if before is None:
            base["error"] = "读取本店 Offer 失败：{0}".format(read_err or target)
            base["hint"] = "只写本店在售的 offer；请确认 SKU 属于当前激活店铺（或 API 出口可用）。"
            return base
        snapshot = _snapshot_offer(before)
        tsin_number = _plid_of(before.get("tsin_id") or before.get("tsin"))
        tsin = "TSIN{0}".format(tsin_number) if tsin_number else ""
        changed: List[Dict[str, Any]] = []
        unchanged: List[str] = []
        for key in OFFER_WRITE_RULES:
            if key not in wanted:
                continue
            if wanted[key] == snapshot.get(key):
                unchanged.append(key)
                continue
            changed.append({"field": key, "api": OFFER_WRITE_RULES[key]["api"], "label": OFFER_WRITE_RULES[key]["label"],
                            "from": snapshot.get(key), "to": wanted[key]})
        if unchanged:
            warnings.append("这些字段和当前值相同，未写入：{0}".format(
                "、".join(OFFER_WRITE_RULES[k]["label"] for k in unchanged)))
        api_body: Dict[str, Any] = {}
        for row in changed:
            if row["field"] == "seller_stock":
                warehouse_id = _seller_warehouse_id(before)
                if warehouse_id is None:
                    errors.append("该 offer 的 seller_warehouse_stock expand 为空：拿不到平台分配的 seller_warehouse_id，无法写库存（绝不凭空造仓 ID）")
                    continue
                api_body["seller_warehouse_stock"] = [{"seller_warehouse_id": warehouse_id,
                                                      "quantity_available": int(row["to"])}]
            else:
                api_body[OFFER_WRITE_RULES[row["field"]]["api"]] = int(row["to"])
        base["request"] = api_body
        base["changed"] = changed
        base["current"] = snapshot
        base["tsin"] = tsin
        base["offerId"] = before.get("offer_id")
        base["errors"] = errors
        if errors:
            base["error"] = errors[0]
            base["hint"] = "校验未通过（中文本地校验）：没有调用 Seller API，也没有写审计日志。"
            return base
        if not changed:
            base.update({"ok": True, "offer": before, "applied": [], "apiStatus": None,
                         "hint": "没有需要写入的变化（值相同）：没有调用 Seller API，也没有写审计日志。"})
            return base
        if not api_body:
            base["error"] = "没有可发送的可写字段"
            base["hint"] = "校验未通过（中文本地校验）：没有调用 Seller API，也没有写审计日志。"
            return base
        if dry_run:
            base.update({"ok": True, "offer": before, "applied": [], "apiStatus": None,
                         "hint": "dryRun：只做中文本地校验并回显即将发送的请求体；没有调用 Seller API，也没有写审计日志。"})
            return base
        patch_meta: Dict[str, Any] = {}
        _, err = _api_request("PATCH", "/offers/by_sku/{0}".format(urllib.parse.quote(target, safe="")),
                              None, api_body, store_id=store_id, meta=patch_meta)
        api_status = patch_meta.get("status") or (200 if err is None else _api_status_of(err))
        after, after_err = _read_offer_live(target, store_id)
        after_snapshot = _snapshot_offer(after or {})
        applied: List[Dict[str, Any]] = []
        for row in changed:
            field = row["field"]
            actual = after_snapshot.get(field) if after is not None else None
            ok = bool(after is not None and actual == row["to"])
            entry = {"field": field, "api": row["api"], "label": row["label"], "from": row["from"],
                     "to": row["to"], "ok": ok, "actual": actual}
            entry["message"] = ("已写入并回读确认：{0} {1} → {2}".format(
                row["label"], _fmt_write_value(field, row["from"]), _fmt_write_value(field, row["to"])) if ok
                else "平台未接受或回读不一致：{0} 期望 {1}，回读为 {2}".format(
                    row["label"], _fmt_write_value(field, row["to"]), _fmt_write_value(field, actual)))
            applied.append(entry)
        if err:
            warnings.append("Seller API 返回错误：{0}".format(err))
        if after_err:
            warnings.append("写入后的回读失败：{0}（applied.actual 为回读值，None 表示没读到）".format(after_err))
        entry_ok = bool(applied) and all(row["ok"] for row in applied)
        if not entry_ok:
            warnings.append("写入未全部生效：请在 Seller Portal 复核该 offer 的当前值。")
        _append_offer_write({
            "at": _iso_now(), "atIso": _server_time(), "sku": target, "tsin": tsin,
            "offerId": before.get("offer_id"), "request": api_body,
            "fields": [row["field"] for row in changed], "changed": changed,
            "applied": applied, "apiStatus": api_status, "ok": entry_ok, "error": err,
            "dryRun": False, "mode": "live", "type": "PRICE_WRITE" if any(
                row["field"] == "selling_price" for row in changed) else "OFFER_WRITE",
            "storeId": store_label["storeId"], "storeName": store_label["storeName"],
            "source": "PATCH /products/{sku}",
        })
        _log_offer_write(target, tsin, api_body, applied, entry_ok, err, store_id=store_label["storeId"])
        _bust_offer_caches()
        base.update({
            "ok": entry_ok,
            "apiStatus": api_status,
            "offer": after if after is not None else before,
            "applied": applied,
            "error": None if entry_ok else (err or "写入后回读的值与目标不一致"),
            "hint": ("已写入并回读确认；审计写入 state/{0}，state/price_log.json 已记一行，"
                     "商品列表缓存已打掉。").format(OFFER_WRITES_FILE) if entry_ok
                    else "写入未能全部生效（见 applied/warnings）：审计已记录，请以平台返回为准。",
            "audit": {"file": "state/{0}".format(OFFER_WRITES_FILE), "ok": entry_ok,
                      "priceLog": "state/price_log.json", "cacheBusted": True},
        })
        return base

    return _safe(build, _fallback({
        "ok": False, "dryRun": True, "sku": sku, "request": {}, "applied": [], "changed": [],
        "apiStatus": None, "offer": None, "warnings": [], "error": "写入口内部错误",
    }))


# --------------------------------------------------------------------------
# CONTRACT v6 — A: 批量写入 POST /products/batch-write
#                 B: 跟卖执行 POST /products/{sku}/offer（官方 POST /offers）
#
# The single-write path (PATCH /products/{sku}) proves the rules; this section reuses
# them verbatim: every row is validated locally in Chinese FIRST (no API call at all
# while any row is invalid), then rows are applied ONE AT A TIME (shared caches +
# rate limits ⇒ never parallel), each with its own audit row, price_log line and raw
# platform answer. Offer creation follows the official CreateOfferRequest schema
# (`barcode` is required; `seller_warehouse_id` comes from the live offers expand and
# is never invented) and a refused create is audited with ok:false, never faked.
# --------------------------------------------------------------------------

BATCH_MAX_ROWS = 50          # contract: rows per call
OFFER_SKU_RE = re.compile(r"^[a-zA-Z0-9\-_/.]+$")


def _write_row_plan(index: int, row: Any) -> Dict[str, Any]:
    """Per-row LOCAL validation, entirely in Chinese, zero API calls."""
    if not isinstance(row, dict):
        return {"index": index, "sku": "", "wanted": {}, "warnings": [],
                "errors": ["第 {0} 行不是 JSON 对象（每行应为 {{sku, selling_price?, …}}）".format(index)]}
    errors: List[str] = []
    wanted: Dict[str, Any] = {}
    sku = str(row.get("sku") or "").strip()
    if not sku:
        errors.append("第 {0} 行缺少 sku（每行必须给本店的 SKU）".format(index))
    for key, raw in row.items():
        if key in ("sku", "dryRun", "dry_run", "storeId"):
            continue
        if key not in OFFER_WRITE_RULES:
            errors.append("第 {0} 行：{1}".format(index, _unwritable_message(key)))
            continue
        value, error = _int_or_error(raw, key)
        if error:
            errors.append("第 {0} 行：{1}".format(index, error))
            continue
        wanted[key] = value
    if not wanted and not errors:
        errors.append("第 {0} 行没有可写字段：至少给 selling_price / rrp / seller_stock / "
                      "minimum_leadtime_days 之一".format(index))
    return {"index": index, "sku": sku, "wanted": wanted, "errors": errors, "warnings": []}


def _diff_write_row(wanted: Dict[str, Any], snapshot: Dict[str, Any],
                    warehouse_id: Any, index: int) -> Dict[str, Any]:
    """Only CHANGED + writable fields become the PATCH body (v5 rules, reused)."""
    changed: List[Dict[str, Any]] = []
    unchanged: List[str] = []
    errors: List[str] = []
    for key in OFFER_WRITE_RULES:
        if key not in wanted:
            continue
        if wanted[key] == snapshot.get(key):
            unchanged.append(key)
            continue
        changed.append({"field": key, "api": OFFER_WRITE_RULES[key]["api"],
                        "label": OFFER_WRITE_RULES[key]["label"],
                        "from": snapshot.get(key), "to": wanted[key]})
    api_body: Dict[str, Any] = {}
    needs_warehouse = any(row["field"] == "seller_stock" for row in changed)
    if needs_warehouse and warehouse_id is None:
        errors.append("第 {0} 行：该 offer 没有 seller_warehouse_stock expand —— 拿不到平台分配的 "
                      "seller_warehouse_id，整行不写（绝不凭空造仓 ID，也绝不偷偷丢掉库存改动）".format(index))
    for row in changed:
        if row["field"] == "seller_stock":
            continue
        api_body[OFFER_WRITE_RULES[row["field"]]["api"]] = int(row["to"])
    if needs_warehouse and warehouse_id is not None:
        target = next(row["to"] for row in changed if row["field"] == "seller_stock")
        api_body["seller_warehouse_stock"] = [{"seller_warehouse_id": warehouse_id,
                                              "quantity_available": int(target)}]
    return {"changed": changed, "unchanged": unchanged, "api_body": api_body, "errors": errors}


def _changed_map(changed: List[Dict[str, Any]]) -> Dict[str, Any]:
    """``{field: {label, api, from, to}}`` — the contract's per-row ``changed`` shape."""
    return {row["field"]: {"label": row.get("label"), "api": row.get("api"),
                           "from": row.get("from"), "to": row.get("to")} for row in changed}


def _applied_rows(changed: List[Dict[str, Any]], after: Optional[Dict[str, Any]],
                  err: Optional[str], dry_run: bool = False) -> List[Dict[str, Any]]:
    """Per-field outcome, confirmed against the re-read offer (never assumed)."""
    snapshot = _snapshot_offer(after or {})
    out: List[Dict[str, Any]] = []
    for row in changed:
        field = row["field"]
        actual = snapshot.get(field) if after is not None else None
        ok = bool(after is not None and actual == row["to"])
        message = ("已写入并回读确认：{0} {1} → {2}".format(
            row["label"], _fmt_write_value(field, row["from"]), _fmt_write_value(field, row["to"])) if ok
            else "平台未接受或回读不一致：{0} 期望 {1}，回读为 {2}".format(
                row["label"], _fmt_write_value(field, row["to"]), _fmt_write_value(field, actual)))
        if dry_run:
            message = "dryRun：未发送（即将写入 {0} → {1}）".format(
                _fmt_write_value(field, row["from"]), _fmt_write_value(field, row["to"]))
        out.append({"field": field, "api": row["api"], "label": row["label"], "from": row["from"],
                    "to": row["to"], "ok": ok, "actual": actual, "message": message})
    return out


@router.post("/products/batch-write")
def products_batch_write(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """批量改价/改库存（CONTRACT v6 §A）。

    顺序固定：**整批中文本地校验**（有任何一行非法 → 一行都不发、不写审计，``apiCalls: 0``）→
    （dryRun 只回显）→ 逐行**串行** ``PATCH /offers/by_sku/{sku}`` → 每行**重新读取**回读 → 每行
    审计（``state/offer_writes.json`` + ``state/price_log.json``，type ``BATCH_WRITE``）→ 批末打掉
    商品缓存，让 ``/products`` 立刻反映新价/新库存。一行失败不影响其余行（继续跑完）。
    """
    payload = body if isinstance(body, dict) else {}

    def build() -> Dict[str, Any]:
        raw_rows = payload.get("rows")
        if not isinstance(raw_rows, list):
            raw_rows = []
        dry_run = bool(payload.get("dryRun"))
        store_id = str(payload.get("storeId") or payload.get("store_id") or "").strip()
        label = _store_label(store_id)
        api_calls = 0
        warnings: List[str] = []
        requested = len(raw_rows)
        try:
            row_cap = int(payload.get("limit") or BATCH_MAX_ROWS)
        except (TypeError, ValueError):
            row_cap = BATCH_MAX_ROWS
        row_cap = max(1, min(row_cap, BATCH_MAX_ROWS))
        rows = raw_rows[:row_cap]
        clamped = requested > len(rows)
        base: Dict[str, Any] = {
            "ok": False, "dryRun": dry_run, "mode": "live", "total": len(rows), "requested": requested,
            "clamped": clamped, "limit": row_cap, "maxRows": BATCH_MAX_ROWS,
            "changed": 0, "appliedCount": 0, "failedCount": 0, "blockedCount": 0,
            "results": [], "warnings": warnings, "errors": [], "error": None, "apiCalls": 0,
            "writesSent": 0,
            "writePath": "POST /products/batch-write → PATCH /offers/by_sku/{sku}（逐行串行）",
            "writableKeys": list(OFFER_WRITE_RULES.keys()), "generatedAt": _iso_now(),
        }
        base.update({"storeId": label["storeId"], "storeName": label["storeName"],
                     "storeScoped": label["storeScoped"], "activeStoreId": label["activeStoreId"]})
        clamp_note = ""
        if clamped:
            clamp_note = "rows 超过单次上限 {0}：本次只处理前 {0} 行（收到 {1} 行）。".format(BATCH_MAX_ROWS, requested)
            warnings.append(clamp_note)
        if not rows:
            base["error"] = "没有可处理的行：body.rows 必须是非空数组（每行 {sku, selling_price?/rrp?/seller_stock?/minimum_leadtime_days?}）"
            base["hint"] = "校验未通过（中文本地校验）：没有调用 Seller API，也没有写审计日志。"
            return base
        key, key_error, _row = _store_key_for(store_id)
        if not key:
            base["error"] = key_error or "未配置 Seller X-API-Key：无法写入真实 offer。"
            base["hint"] = "在「设置 · 店铺」里配置该店铺的 Seller X-API-Key（live 模式）后再写。"
            return base

        # ---- 1. validate EVERY row first: no API call while any row is invalid ----
        plans = [_write_row_plan(index + 1, row) for index, row in enumerate(rows)]
        invalid = [plan for plan in plans if plan["errors"]]
        results: List[Dict[str, Any]] = []
        for plan in plans:
            results.append({
                "index": plan["index"], "sku": plan["sku"], "ok": not plan["errors"],
                "errors": plan["errors"], "warnings": plan["warnings"], "changed": {}, "request": {},
                "changedFields": [], "applied": [], "apiStatus": None, "offer": None, "offerId": None,
                "tsin": "", "current": None, "blocked": bool(plan["errors"]), "error": None,
                "raw": {"patch": None, "reread": None},
            })
        if invalid:
            base["results"] = results
            base["blockedCount"] = len(invalid)
            base["failedCount"] = len(invalid)
            base["errors"] = [msg for plan in invalid for msg in plan["errors"]]
            base["error"] = base["errors"][0]
            base["hint"] = ("校验未通过（中文本地校验）：{0} 行非法，**一行都没有发送**，也没有写审计日志"
                            "（apiCalls={1}）。修正后再提交。").format(len(invalid), api_calls)
            base["apiCalls"] = api_calls
            return base

        # ---- 2. dryRun: echo the exact per-row bodies, still nothing sent ---------
        if dry_run:
            snapshot_source = _rows_for_store(store_id)
            api_calls += 1 if snapshot_source.get("source") == "live-store-scoped" else 0
            listing = {(str(row.get("sku") or "").strip().lower()): row
                       for row in (snapshot_source.get("rows") or []) if isinstance(row, dict)}
            for plan, result in zip(plans, results):
                current = listing.get(plan["sku"].lower())
                if current is None:
                    result["warnings"].append("dryRun：该 SKU 不在{0}的 offer 列表缓存里（未额外调用 API 回读）："
                                              "from 记为空，实际写入前会现场回读。".format(
                                                  label["storeName"] or label["storeId"]))
                    diff = _diff_write_row(plan["wanted"], {k: None for k in OFFER_WRITE_RULES}, None, plan["index"])
                    for row in diff["changed"]:
                        row["from"] = None
                    result["changed"] = _changed_map(diff["changed"])
                    result["changedFields"] = diff["changed"]
                    result["request"] = {OFFER_WRITE_RULES[k]["api"]: plan["wanted"][k] for k in plan["wanted"]}
                    continue
                snapshot = _snapshot_offer(current)
                warehouse_id = _seller_warehouse_id(current)
                diff = _diff_write_row(plan["wanted"], snapshot, warehouse_id, plan["index"])
                if diff["errors"]:
                    result.update({"ok": False, "blocked": True, "errors": diff["errors"],
                                   "error": diff["errors"][0]})
                    continue
                result.update({"current": snapshot, "changed": _changed_map(diff["changed"]),
                               "changedFields": diff["changed"], "request": diff["api_body"],
                               "applied": _applied_rows(diff["changed"], current, None, dry_run=True),
                               "offerId": current.get("offer_id"),
                               "tsin": "TSIN{0}".format(_plid_of(current.get("tsin_id"))) if _plid_of(current.get("tsin_id")) else "",
                               "offer": None})
                if diff["unchanged"]:
                    result["warnings"].append("这些字段和当前值相同，不会写入：{0}".format(
                        "、".join(OFFER_WRITE_RULES[k]["label"] for k in diff["unchanged"])))
            blocked = [r for r in results if r.get("blocked")]
            base.update({
                "ok": not blocked,
                "results": results,
                "changed": sum(1 for r in results if r.get("changed")),
                "appliedCount": 0,
                "blockedCount": len(blocked),
                "failedCount": len(blocked),
                "apiCalls": api_calls,
                "hint": ("{0}dryRun：只做中文本地校验并回显每一行即将发送的请求体；没有调用 Seller API 写入，"
                         "也没有写审计日志（apiCalls={1}，回读值来自 ≤60s 的 offer 列表缓存）。").format(
                             (clamp_note + " ") if clamp_note else "", api_calls),
            })
            return base

        # ---- 3. real run: sequential, one PATCH per row, continue on failure ------
        batch_id = "BW-{0}".format(_now().strftime("%Y%m%d%H%M%S"))
        applied_count = 0
        writes_sent = 0
        for plan, result in zip(plans, results):
            read_meta: Dict[str, Any] = {}
            before, read_err = _read_offer_live(plan["sku"], store_id, meta=read_meta)
            api_calls += 1
            result["raw"]["read"] = {"status": read_meta.get("status"), "endpoint": read_meta.get("endpoint")}
            if before is None:
                result.update({"ok": False, "apiStatus": read_meta.get("status"),
                               "error": "读取本店 Offer 失败：{0}".format(read_err or plan["sku"])})
                result["raw"]["readError"] = read_err
                continue
            snapshot = _snapshot_offer(before)
            warehouse_id = _seller_warehouse_id(before)
            tsin = "TSIN{0}".format(_plid_of(before.get("tsin_id") or before.get("tsin"))) \
                if _plid_of(before.get("tsin_id") or before.get("tsin")) else ""
            diff = _diff_write_row(plan["wanted"], snapshot, warehouse_id, plan["index"])
            result.update({"current": snapshot, "offerId": before.get("offer_id"), "tsin": tsin,
                           "changed": _changed_map(diff["changed"]), "changedFields": diff["changed"]})
            if diff["errors"]:
                result.update({"ok": False, "blocked": True, "errors": diff["errors"], "error": diff["errors"][0]})
                continue
            if diff["unchanged"]:
                result["warnings"].append("这些字段和当前值相同，未写入：{0}".format(
                    "、".join(OFFER_WRITE_RULES[k]["label"] for k in diff["unchanged"])))
            if not diff["api_body"]:
                result.update({"ok": True, "apiStatus": None,
                               "hint": "没有需要写入的变化（值相同）：该行没有调用 PATCH。"})
                continue
            result["request"] = diff["api_body"]
            patch_meta: Dict[str, Any] = {}
            _, patch_err = _api_request(
                "PATCH", "/offers/by_sku/{0}".format(urllib.parse.quote(plan["sku"], safe="")),
                None, diff["api_body"], store_id=store_id, meta=patch_meta)
            api_calls += 1
            writes_sent += 1
            api_status = patch_meta.get("status") or (_api_status_of(patch_err) if patch_err else 200)
            reread_meta: Dict[str, Any] = {}
            after, after_err = _read_offer_live(plan["sku"], store_id, meta=reread_meta)
            api_calls += 1
            applied = _applied_rows(diff["changed"], after, patch_err)
            row_ok = bool(applied) and all(row["ok"] for row in applied)
            if patch_err:
                result["warnings"].append("Seller API 返回错误：{0}".format(patch_err))
            if after_err:
                result["warnings"].append("写入后的回读失败：{0}".format(after_err))
            if not row_ok:
                result["warnings"].append("该行未全部生效：请在 Seller Portal 复核该 offer 的当前值。")
            result.update({
                "ok": row_ok, "apiStatus": api_status, "applied": applied,
                "offer": after if after is not None else before,
                "error": None if row_ok else (patch_err or "写入后回读的值与目标不一致"),
                "blocked": False,
                "raw": {"patch": {"status": api_status, "request": diff["api_body"],
                                  "body": (patch_meta.get("raw") or "")[:600], "error": patch_err},
                        "reread": {"status": reread_meta.get("status"),
                                   "offer": after if after is not None else None, "error": after_err}},
            })
            if row_ok:
                applied_count += 1
            _append_offer_write({
                "at": _iso_now(), "atIso": _server_time(), "sku": plan["sku"], "tsin": tsin,
                "offerId": before.get("offer_id"), "request": diff["api_body"],
                "fields": [row["field"] for row in diff["changed"]], "changed": diff["changed"],
                "applied": applied, "apiStatus": api_status, "ok": row_ok, "error": patch_err,
                "dryRun": False, "mode": "live", "type": "BATCH_WRITE", "kind": "BATCH_WRITE",
                "batchId": batch_id, "rowIndex": plan["index"], "rowsInBatch": len(rows),
                "storeId": label["storeId"], "storeName": label["storeName"],
                "from": snapshot, "to": diff["api_body"],
                "source": "POST /products/batch-write",
            })
            _log_offer_write(plan["sku"], tsin, diff["api_body"], applied, row_ok, patch_err,
                             kind="BATCH_WRITE", store_id=label["storeId"])
        _bust_offer_caches()
        blocked = [r for r in results if r.get("blocked")]
        failed = [r for r in results if not r.get("ok") and not r.get("blocked")]
        base.update({
            "ok": bool(applied_count > 0 and not blocked),
            "results": results,
            "changed": sum(1 for r in results if r.get("changed")),
            "appliedCount": applied_count,
            "failedCount": len(failed) + len(blocked),
            "blockedCount": len(blocked),
            "apiCalls": api_calls,
            "writesSent": writes_sent,
            "batchId": batch_id,
            "audit": {"file": "state/{0}".format(OFFER_WRITES_FILE), "rows": len(results),
                      "type": "BATCH_WRITE", "batchId": batch_id,
                      "priceLog": "state/price_log.json", "cacheBusted": True},
            "hint": ("{0}批量写入完成：{1}/{2} 行已回读确认，{3} 行平台未接受，{4} 行被本地校验挡下；"
                     "逐行审计已落 state/{5}（type BATCH_WRITE）+ state/price_log.json，商品列表缓存已打掉。").format(
                (clamp_note + " ") if clamp_note else "", applied_count, len(results), len(failed),
                len(blocked), OFFER_WRITES_FILE),
        })
        if blocked or failed:
            base["warnings"].append("有行未生效：见 results[].error / results[].warnings（审计已按行记录，以平台返回为准）。")
        return base

    return _safe(build, _fallback({
        "ok": False, "dryRun": False, "total": 0, "changed": 0, "appliedCount": 0, "failedCount": 0,
        "results": [], "warnings": [], "error": "批量写入口内部错误",
    }))


def _crawl_product_for(target: Any, entries: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """The cached public card for a SKU/PLID/TSIN (never a live crawl in a write path)."""
    number = _plid_of(target)
    if not number:
        return {}
    card = _cached_card(number, entries)
    return card.get("product") or {}


def _resolve_catalogue_item(sku: str, payload: Dict[str, Any], store_id: Any = None,
                            offer: Optional[Dict[str, Any]] = None,
                            card: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """``{barcode, barcodeSource, tsin, tsinSource, plid, notes[], error}`` — no invention."""
    notes: List[str] = []
    barcode = str(payload.get("barcode") or "").strip()
    barcode_source = "request.barcode" if barcode else ""
    tsin_raw = str(payload.get("tsin") or "").strip()
    # TSIN preference: the offer's own tsin_id wins (authoritative), then request.tsin,
    # then whatever digits the path SKU carries (a numeric SKU is not a TSIN — say so).
    tsin_number = _plid_of((offer or {}).get("tsin_id") or "")
    tsin_source = "own-offer.tsin_id" if tsin_number else ""
    if not tsin_number and tsin_raw:
        tsin_number, tsin_source = _plid_of(tsin_raw), "request.tsin"
    if not tsin_number and _plid_of(sku):
        tsin_number, tsin_source = _plid_of(sku), "path.sku(数字前缀，非权威 TSIN)"
    tsin = "TSIN{0}".format(tsin_number) if tsin_number else (tsin_raw or "")

    def from_offer(row: Dict[str, Any], source: str) -> None:
        nonlocal barcode, barcode_source, tsin, tsin_source
        if not barcode:
            value = str(row.get("barcode") or "").strip()
            if value:
                barcode, barcode_source = value, source
        if not tsin_source:
            number = _plid_of(row.get("tsin_id") or row.get("tsin"))
            if number:
                tsin, tsin_source = "TSIN{0}".format(number), source + ".tsin_id"

    if offer:
        from_offer(offer, "own-offer(bysku)")
    if not (barcode and tsin_source) and card:
        if not barcode:
            product_pairs = _product_attribute_pairs(card)
            value = _product_barcode(card, product_pairs)
            if value:
                barcode, barcode_source = value, "public-card(attributes)"
        if tsin:
            if not tsin_source:
                tsin_source = "public-card(PLID)"
    if not barcode or not tsin_source:
        listing = _rows_for_store(store_id)
        for row in (listing.get("rows") or []):
            if str(row.get("sku") or "").strip().lower() != sku.strip().lower():
                continue
            from_offer(row, "own-offers-list")
            break
        if not barcode and tsin_number:
            for row in (listing.get("rows") or []):
                if _plid_of(row.get("tsin_id") or row.get("tsin")) == tsin_number:
                    from_offer(row, "own-offers-list(tsin)")
                    break
        if not barcode and str(payload.get("barcode") or ""):
            barcode = str(payload["barcode"]).strip()
            barcode_source = "request.barcode"
    if not tsin_number:
        tsin_number = _plid_of(tsin)
    if barcode:
        notes.append("条码 {0}（来源：{1}）—— CreateOfferRequest 的必填字段".format(barcode, barcode_source))
    missing: List[str] = []
    if not barcode:
        missing.append("条码 barcode")
    if missing:
        return {"barcode": "", "barcodeSource": "", "tsin": tsin, "tsinSource": tsin_source,
                "plid": "PLID{0}".format(tsin_number) if tsin_number else "",
                "notes": notes, "error": (
                    "无法解析出该目录项的 **条码 barcode**（CreateOfferRequest 必填）：{0}。"
                    "请任选其一：① 在 body 里直接给 barcode（首选）；② 给一个能在本店 offer 或抓取缓存里查到的 "
                    "TSIN/PLID；③ 先对 SKU「抓取补全」再跟卖。当前 SKU={1}，TSIN={2}。").format(
                        "、".join(missing), sku or "—", tsin or "—")}
    return {"barcode": barcode, "barcodeSource": barcode_source, "tsin": tsin, "tsinSource": tsin_source,
            "plid": "PLID{0}".format(tsin_number) if tsin_number else "", "notes": notes, "error": None}


def _sell_action(sku: str, offer: Optional[Dict[str, Any]], item: Dict[str, Any], caps: Dict[str, Any],
                 card: Optional[Dict[str, Any]], store_id: Any = None) -> Dict[str, Any]:
    """``sellAction`` — whether the 跟卖 button is usable and exactly what it would send."""
    card = card or {}
    resolved = _resolve_catalogue_item(sku, {}, store_id, offer=offer, card=card)
    warehouse = _account_warehouse_id(store_id) if caps.get("keyConfigured") else {"warehouseId": None}
    own_price = int(float((offer or {}).get("selling_price") or 0))
    card_price = card.get("price")
    suggested = own_price if own_price > 0 else (int(float(card_price)) if card_price not in (None, "", 0) else None)
    if suggested is None:
        suggested = 1 if not offer else own_price + 1
    can = bool(caps.get("keyConfigured") and resolved.get("barcode"))
    if not caps.get("keyConfigured"):
        reason = "未配置该店铺的 Seller X-API-Key：无法调用 POST /offers 建 offer。"
    elif not resolved.get("barcode"):
        reason = resolved.get("error") or "拿不到条码：无法建 offer。"
    elif offer is not None and str(offer.get("barcode") or "").strip():
        reason = ("该条码本店已有 offer（SKU {0}，Offer {1}）：POST /offers 会因重复被拒，"
                  "改价/改库存请用 PATCH /products/{0}。").format(offer.get("sku"), offer.get("offer_id"))
    else:
        reason = ("可以跟卖：POST /offers 用条码 {0}（来源 {1}）建本店 offer；"
                  "库存写入平台分配的卖家仓 {2}。").format(
                      resolved.get("barcode"), resolved.get("barcodeSource"),
                      warehouse.get("warehouseId") if warehouse.get("warehouseId") is not None else "（未读到）")
    return {
        "canCreateOffer": can,
        "alreadySelling": bool(offer is not None and str(offer.get("barcode") or "").strip()),
        "reason": reason,
        "defaults": {
            "barcode": resolved.get("barcode") or "",
            "barcodeSource": resolved.get("barcodeSource") or "",
            "tsin": resolved.get("tsin") or str(item.get("tsin") or ""),
            "suggestedPrice": suggested,
            "rrp": int(float((offer or {}).get("rrp") or 0)) or None,
            "sellerStock": int(((item.get("stock") or {}).get("sellerAvailable") or 0)) if offer is not None else 0,
            "warehouseId": warehouse.get("warehouseId"),
            "warehouseSource": warehouse.get("source"),
            "leadtimeEnabled": bool(caps.get("leadtimeEnabled")),
        },
        "endpoint": "POST /products/{sku}/offer → POST /offers（CreateOfferRequest）",
        "requiredFields": ["barcode", "selling_price"],
        "hint": ("dryRun:true 先看请求体；真实执行会按 CreateOfferRequest 发送 barcode/selling_price"
                 "（+ rrp/seller_warehouse_stock/minimum_leadtime_days），并把平台的原文拒绝或创建结果写审计。"),
    }


def offer_create_impl(target: str, payload: Dict[str, Any], store_id: str,
                      dry_run: bool) -> Dict[str, Any]:
    """跟卖建 offer 的核心实现（``POST /products/{sku}/offer`` 与「一键上架」共用）。

    参数化 target / payload / store_id / dryRun 之后，单个跟卖与批量上架走**完全同一条**
    校验、解析、写入、回读、审计路径 —— 两条路径的行为不可能分叉。
    """
    payload = payload if isinstance(payload, dict) else {}
    label = _store_label(store_id)
    caps = _capabilities(store_id)
    warnings: List[str] = []
    errors: List[str] = []
    api_calls = 0
    base: Dict[str, Any] = {
        "ok": False, "dryRun": dry_run, "sku": target, "request": {}, "apiStatus": None,
        "offer": None, "created": None, "applied": [], "warnings": warnings, "errors": errors,
        "error": None, "apiCalls": 0, "writesSent": 0, "capabilities": caps, "generatedAt": _iso_now(),
        "endpoint": "POST /offers（CreateOfferRequest）",
    }
    base.update({"storeId": label["storeId"], "storeName": label["storeName"],
                 "storeScoped": label["storeScoped"], "activeStoreId": label["activeStoreId"]})

    # ---- local validation (Chinese, zero API calls while anything is illegal) --
    allowed_local = ("barcode", "tsin", "sku", "selling_price", "rrp", "seller_stock",
                     "minimum_leadtime_days", "dryRun", "dry_run", "storeId", "store_id")
    for key in payload:
        if key in allowed_local:
            continue
        errors.append(_unwritable_message(key))
    price, error = _int_or_error(payload.get("selling_price"), "selling_price")
    if error:
        errors.append("售价：{0}".format(error))
    rrp = None
    if payload.get("rrp") not in (None, ""):
        rrp, error = _int_or_error(payload.get("rrp"), "rrp")
        if error:
            errors.append("RRP：{0}".format(error))
    stock = None
    if payload.get("seller_stock") not in (None, ""):
        stock, error = _int_or_error(payload.get("seller_stock"), "seller_stock")
        if error:
            errors.append("库存：{0}".format(error))
    leadtime = None
    if payload.get("minimum_leadtime_days") not in (None, ""):
        leadtime, error = _int_or_error(payload.get("minimum_leadtime_days"), "minimum_leadtime_days")
        if error:
            errors.append("备货期：{0}".format(error))
    custom_sku = str(payload.get("sku") or "").strip()
    if custom_sku and not OFFER_SKU_RE.match(custom_sku):
        errors.append("sku 只能包含字母/数字/-_/.（官方 schema 的 pattern ^[a-zA-Z0-9-_/.]+$），收到 {0!r}".format(custom_sku))
    if price is None and not error:
        errors.append("缺少 selling_price：CreateOfferRequest 要求整数 ZAR ≥1（售价必填）。")
    if errors:
        base.update({"errors": errors, "error": errors[0],
                     "hint": "校验未通过（中文本地校验）：没有调用 Seller API，也没有写审计日志（apiCalls=0）。"})
        return base
    key, key_error, _row = _store_key_for(store_id)
    if not key:
        base.update({"error": key_error or "未配置 Seller X-API-Key：无法创建 offer。",
                     "hint": "在「设置 · 店铺」里配置该店铺的 Seller X-API-Key（live 模式）后再执行。"})
        return base

    # ---- resolve the catalogue item (barcode preferred; TSIN → barcode) -------
    own_offer = None
    if target and not str(payload.get("barcode") or "").strip():
        own_offer, _read_err = _read_offer_live(target, store_id)
        api_calls += 1 if own_offer is not None else 0
    entries = _crawl_entries()
    number = _plid_of(payload.get("tsin") or target)
    card: Dict[str, Any] = {}
    if number:
        card = _cached_card(number, entries).get("product") or {}
    resolved = _resolve_catalogue_item(target, payload, store_id, offer=own_offer, card=card)
    if resolved.get("error"):
        base.update({"errors": [resolved["error"]], "error": resolved["error"],
                     "resolution": resolved, "apiCalls": api_calls,
                     "hint": "没有调用 POST /offers，也没有写审计日志。"})
        return base
    warnings.extend(note for note in resolved.get("notes") or [] if note not in warnings)
    if own_offer is not None:
        warnings.append("本店已有一条该 SKU 的 offer（SKU {0}，Offer {1}，条码 {2}）：若条码相同，"
                        "POST /offers 很可能以「重复」被拒 —— 平台的原文回答会照实返回，"
                        "改价/改库存请用 PATCH /products/{0}。".format(
                            own_offer.get("sku"), own_offer.get("offer_id"), own_offer.get("barcode"), target))
    warehouse = _account_warehouse_id(store_id)
    if stock is not None and warehouse.get("warehouseId") is None:
        base.update({"errors": [warehouse.get("error") or "拿不到卖家仓 ID"],
                     "error": warehouse.get("error") or "拿不到卖家仓 ID",
                     "resolution": resolved, "warehouse": warehouse, "apiCalls": api_calls,
                     "hint": "库存写入需要平台分配的 seller_warehouse_id（本店 live offers 的 expand）："
                             "没有读到就不写库存，也绝不编造一个仓 ID。"})
        return base
    leadtime_note = ""
    if leadtime is not None and not caps.get("leadtimeEnabled"):
        warnings.append("该店铺 leadtime_enabled=false（未开通 API 备货期写入）：minimum_leadtime_days 未写入请求体"
                        "（平台会以 cant-edit-soh-leadtime-disabled 一类错误拒绝）。")
        leadtime_note = "dropped(leadtime_enabled=false)"
        leadtime = None

    request_body: Dict[str, Any] = {"barcode": resolved["barcode"], "selling_price": int(price)}
    if custom_sku:
        request_body["sku"] = custom_sku
    if rrp is not None:
        request_body["rrp"] = int(rrp)
    if stock is not None:
        request_body["seller_warehouse_stock"] = [{"seller_warehouse_id": warehouse["warehouseId"],
                                                 "quantity_available": int(stock)}]
    if leadtime is not None:
        request_body["minimum_leadtime_days"] = int(leadtime)
    base.update({"request": request_body, "resolution": resolved,
                 "warehouse": {"warehouseId": warehouse.get("warehouseId"), "source": warehouse.get("source"),
                               "fromSku": warehouse.get("fromSku"), "sampleQuantity": warehouse.get("sampleQuantity")},
                 "validation": {"barcode": resolved["barcode"], "barcodeSource": resolved["barcodeSource"],
                                "tsin": resolved["tsin"], "tsinSource": resolved["tsinSource"],
                                "sellingPrice": int(price), "rrp": int(rrp) if rrp is not None else None,
                                "sellerStock": int(stock) if stock is not None else None,
                                "minimumLeadtimeDays": int(leadtime) if leadtime is not None else None,
                                "leadtime": leadtime_note or ("sent" if leadtime is not None else "absent")},
                 "apiCalls": api_calls})
    if dry_run:
        base.update({"ok": True, "dryRun": True, "apiStatus": None,
                     "hint": ("dryRun：只做中文本地校验 + 解析（条码/{0}），回显即将发送的 "
                              "CreateOfferRequest 请求体；没有调用 POST /offers，也没有写审计日志。").format(
                                  resolved["barcodeSource"] or "barcode")})
        return base

    # ---- the real POST /offers -----------------------------------------------
    meta: Dict[str, Any] = {}
    data, err = _api_request("POST", "/offers", None, request_body, store_id=store_id, meta=meta)
    api_calls += 1
    base["writesSent"] = 1
    api_status = meta.get("status")
    raw_body = (meta.get("raw") or "")[:1200]
    created = data if isinstance(data, dict) and data else None
    # The live 201 body is WRAPPED: {"success": true, "errors": [], "offer": {…Offer…}}
    # (the schema documents a bare Offer — unwrap both shapes, believe the payload).
    offer_payload: Dict[str, Any] = {}
    if isinstance(created, dict):
        inner = created.get("offer")
        offer_payload = inner if isinstance(inner, dict) and inner else created
    offer: Optional[Dict[str, Any]] = None
    reread_error: Optional[str] = None
    if offer_payload:
        created_sku = str(offer_payload.get("sku") or custom_sku or "").strip()
        if created_sku:
            reread_meta: Dict[str, Any] = {}
            offer, reread_error = _read_offer_live(created_sku, store_id, meta=reread_meta)
            api_calls += 1
            base["reread"] = {"sku": created_sku, "status": reread_meta.get("status"), "error": reread_error}
        if offer is None:
            offer = offer_payload
    created_flag = bool(created is not None and err is None
                        and (api_status == 201 or bool(created.get("success"))))
    ok = bool(created_flag and offer_payload)
    payload_offer = offer or offer_payload or {}
    applied = [
        {"field": "barcode", "value": request_body.get("barcode"), "actual": payload_offer.get("barcode"),
         "ok": str(payload_offer.get("barcode") or "") == str(request_body.get("barcode") or "")},
        {"field": "sku", "value": payload_offer.get("sku"),
         "actual": payload_offer.get("sku"), "ok": bool(payload_offer.get("sku"))},
        {"field": "selling_price", "value": request_body.get("selling_price"),
         "actual": payload_offer.get("selling_price"),
         "ok": int(float(payload_offer.get("selling_price") or 0)) == int(request_body.get("selling_price") or 0)},
    ]
    if rrp is not None:
        applied.append({"field": "rrp", "value": request_body.get("rrp"),
                        "actual": payload_offer.get("rrp"),
                        "ok": int(float(payload_offer.get("rrp") or 0)) == int(rrp)})
    if stock is not None:
        actual_stock = payload_offer.get("seller_warehouse_stock") or []
        actual_qty = int(float((actual_stock[0] if actual_stock else {}).get("quantity_available") or 0)) \
            if isinstance(actual_stock, list) and actual_stock else None
        applied.append({"field": "seller_stock", "value": int(stock), "actual": actual_qty,
                        "ok": actual_qty == int(stock)})
    if leadtime is not None:
        applied.append({"field": "minimum_leadtime_days", "value": int(leadtime),
                        "actual": payload_offer.get("minimum_leadtime_days"),
                        "ok": payload_offer.get("minimum_leadtime_days") == int(leadtime)})
    created_sku = str(payload_offer.get("sku") or custom_sku or resolved["barcode"])
    tsin_label = "TSIN{0}".format(_plid_of(payload_offer.get("tsin_id"))) \
        if _plid_of(payload_offer.get("tsin_id")) else (resolved.get("tsin") or "")
    _append_offer_write({
        "at": _iso_now(), "atIso": _server_time(), "sku": created_sku, "tsin": tsin_label,
        "offerId": payload_offer.get("offer_id"), "request": request_body,
        "fields": sorted(request_body.keys()), "changed": [],
        "applied": applied, "apiStatus": api_status, "ok": ok, "error": err,
        "dryRun": False, "mode": "live", "type": "OFFER_CREATE", "kind": "OFFER_CREATE",
        "resolution": resolved, "warehouse": base.get("warehouse"),
        "rawError": raw_body if err else None, "from": None, "to": None,
        "storeId": label["storeId"], "storeName": label["storeName"],
        "source": "POST /products/{sku}/offer",
    })
    _log_offer_write(created_sku, tsin_label, request_body, applied, ok, err,
                     kind="OFFER_CREATE", store_id=label["storeId"])
    if ok:
        _bust_offer_caches(label["storeId"])
    base.update({
        "ok": ok,
        "apiStatus": api_status,
        "rawResponse": raw_body,
        "platformError": err,
        "offer": payload_offer or created,
        "created": created,
        "createdOffer": payload_offer,
        "applied": applied,
        "createdSku": created_sku,
        "createdOfferId": payload_offer.get("offer_id"),
        "apiCalls": api_calls,
        "error": None if ok else (err or "POST /offers 未返回 201（平台未创建 offer）"),
        "hint": ("已创建并回读确认（POST /offers → HTTP {0}，Offer {1}，平台分配的 SKU {2}）；审计已写 state/{3}"
                 "（type OFFER_CREATE）+ state/price_log.json，商品缓存已打掉。").format(
            api_status, payload_offer.get("offer_id"), created_sku, OFFER_WRITES_FILE) if ok
            else ("平台拒绝/未创建（HTTP {0}）：原文见 platformError / rawResponse。审计已按 ok:false 记录，"
                  "商品未被改动。").format(api_status),
        "audit": {"file": "state/{0}".format(OFFER_WRITES_FILE), "type": "OFFER_CREATE", "ok": ok,
                  "priceLog": "state/price_log.json", "cacheBusted": ok},
    })
    return base


@router.post("/products/{sku}/offer")
def product_offer_create(sku: str, body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """跟卖执行：真正的 ``POST /offers``（CONTRACT v6 §B，官方 CreateOfferRequest）。

    ``barcode`` 是官方 schema 的必填字段：body 里可以直接给，也可以给 TSIN/PLID（本店 offer 或
    抓取缓存解析），解析不出来就返回中文说明**缺什么**，绝不猜一个条码。库存写平台分配给本账号的
    ``seller_warehouse_id``（从 live offers 的 expand 读，绝不编造）。dryRun 只回显请求体；
    真实执行把平台的回答**原文**带回（成功=201 + 回读；被拒=状态码 + 原始 error body），
    并以 ``OFFER_CREATE`` 落审计（被拒也落，``ok:false``）；任何情况都不 500。
    """
    payload = body if isinstance(body, dict) else {}

    def build() -> Dict[str, Any]:
        return offer_create_impl(
            str(sku or "").strip(),
            payload,
            str(payload.get("storeId") or payload.get("store_id") or "").strip(),
            bool(payload.get("dryRun")),
        )

    return _safe(build, _fallback({
        "ok": False, "dryRun": False, "sku": sku, "request": {}, "applied": [], "apiStatus": None,
        "offer": None, "warnings": [], "error": "跟卖建 offer 内部错误",
    }))


CONTENT_RUN_MAX = 10
CONTENT_RUN_BUDGET = 75.0


def _draft_upsert(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Create/update one draft in state/drafts.json (same file 上架编排 reads)."""
    drafts = _drafts()
    draft_id = str(payload.get("id") or "").strip()
    match = None
    if draft_id:
        match = next((d for d in drafts if str(d.get("id")) == draft_id), None)
    if match is None and payload.get("sku"):
        match = next((d for d in drafts if str(d.get("sku") or "") == str(payload.get("sku"))), None)
    if match is None:
        taken = {str(d.get("id")) for d in drafts}
        seq = 3001
        while "DRF-{0}".format(seq) in taken:
            seq += 1
        match = {"id": "DRF-{0}".format(seq), "status": "draft", "attributes": {}, "compliance": {"hits": []}}
        drafts.insert(0, match)
    for key, value in payload.items():
        if value in (None, ""):
            continue
        if key == "attributes" and isinstance(value, dict):
            bag = match.get("attributes") if isinstance(match.get("attributes"), dict) else {}
            bag.update({str(k): str(v) for k, v in value.items() if v not in (None, "")})
            match["attributes"] = bag
            continue
        match[key] = value
    match["updatedAt"] = _iso_now()
    _write_state("drafts.json", drafts)
    return match


def _split_category_path(path: str) -> Tuple[str, str]:
    parts = [p.strip() for p in str(path or "").split(">") if p.strip()]
    if not parts:
        return "", ""
    return parts[0], parts[-1]


@router.post("/analytics/draft")
def analytics_draft(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """选品分析结果 → 上架草稿；已在售的商品改为指引跟卖/改价。"""
    payload = body if isinstance(body, dict) else {}

    def build() -> Dict[str, Any]:
        target = str(payload.get("target") or "").strip()
        sid = str(payload.get("storeId") or "").strip()
        dry_run = bool(payload.get("dryRun", True))
        with_copy = payload.get("withCopy") is not False
        language = "zh" if str(payload.get("language") or "en").lower().startswith("zh") else "en"
        if not target:
            return {"ok": False, "error": "缺少 target：给一个 PLID / TSIN / 商品链接"}
        pref = _prefill_payload({"target": target, "storeId": sid, "force": bool(payload.get("force"))}) or {}
        route = str(pref.get("route") or "")
        exists = bool(pref.get("exists"))
        product = pref.get("product") if isinstance(pref.get("product"), dict) else {}
        seed = pref.get("draft") if isinstance(pref.get("draft"), dict) else {}
        match = pref.get("match") if isinstance(pref.get("match"), dict) else {}
        seller_offer = pref.get("sellerOffer") if isinstance(pref.get("sellerOffer"), dict) else {}
        already_selling = exists or route == "offer"
        if already_selling and not payload.get("allowDuplicate"):
            return {
                "ok": False, "blocked": True, "route": route or "offer", "exists": True,
                "target": target, "product": product, "prefill": seed,
                "error": ("该商品本店已在售：不要用装载表新建（平台会以 cant-create-duplicate-gtin 拒收），"
                          "正确动作是跟卖/改价。"),
                "advice": {
                    "action": "跟卖 / 改价",
                    # sellerOffer is the live Offer the route verdict matched (prefill key);
                    # the draft seed SKU (TL-…) is only a generated placeholder.
                    # only name a SKU when it really is the seller's live offer; the draft
                    # seed (TL-…) is a generated placeholder and naming it would mislead
                    "sku": (seller_offer.get("sku") if seller_offer else None) or (match.get("sku") if match else None),
                    "offerId": (seller_offer.get("offerId") if seller_offer else None) or match.get("offerId") or match.get("offer_id"),
                    "offerStatus": (seller_offer.get("status") if seller_offer else None),
                    "offerPrice": (seller_offer.get("price") if seller_offer else None),
                    "where": "商品管理 → 该商品详情 → 「3. 跟卖落点」，或勾选后用「批量改价」",
                    "locate": None if ((seller_offer.get("sku") if seller_offer else None) or (match.get("sku") if match else None))
                              else "未定位到自有 SKU：在商品管理里用该 TSIN/条码搜索，或先点「补全」抓一次公开页",
                    "reason": pref.get("routeReason") or "该条码/TSIN 在本店 Offer 列表里已存在",
                },
                "warnings": pref.get("warnings") or [],
            }
        category_path = str((product.get("category") or {}).get("path") or seed.get("categoryPath") or "")
        main_category, leaf_category = _split_category_path(category_path)
        images = [str(u) for u in (product.get("images") or seed.get("images") or []) if u][:IMAGE_COLUMN_COUNT]
        attributes = product.get("attributes") if isinstance(product.get("attributes"), dict) else {}
        copy: Dict[str, Any] = {}
        if with_copy:
            try:
                copy = _ai_listing_copy({
                    "keywords": " ".join(x for x in [product.get("title") or seed.get("title"),
                                                     leaf_category, main_category] if x)[:180],
                    "category": leaf_category or category_path,
                    "language": language,
                    "attributes": attributes,
                }) or {}
            except Exception:
                copy = {}
        draft_id = ""
        readiness = None
        if not dry_run:
            draft = _draft_upsert({
                "sku": seed.get("sku") or match.get("sku"),
                "barcode": seed.get("barcode"),
                "tsin": seed.get("tsin") or product.get("tsin"),
                "plid": seed.get("plid") or product.get("plid"),
                "brand": seed.get("brand") or product.get("brand"),
                "title": str(copy.get("title") or seed.get("title") or product.get("title") or "")[:75],
                "subtitle": str(copy.get("subtitle") or seed.get("subtitle") or "")[:110],
                "features": str(copy.get("features") or seed.get("features") or ""),
                "whatsInTheBox": str(copy.get("boxContents") or seed.get("whatsInTheBox") or ""),
                "description": str(copy.get("description") or seed.get("description") or ""),
                "images": images or (seed.get("images") if isinstance(seed.get("images"), list) else []),
                "categoryPath": category_path or seed.get("categoryPath"),
                "mainCategory": seed.get("mainCategory") or main_category,
                "lowestCategory": seed.get("lowestCategory") or leaf_category,
                "price": seed.get("price"),
                "storeId": sid or None,
                "attributes": {k: v for k, v in (attributes or {}).items() if str(v).strip()},
                "status": "draft",
            })
            draft_id = str(draft.get("id") or "")
            readiness = _draft_readiness(draft)
        return {
            "ok": True, "dryRun": dry_run, "route": route or "loadsheet", "exists": exists,
            "target": target, "storeId": sid,
            "product": {"title": product.get("title") or seed.get("title") or "",
                        "categoryPath": category_path, "images": len(images),
                        "plid": product.get("plid") or seed.get("plid")},
            "copy": {"source": "ai" if str(copy.get("title") or "").strip() and _llm_key() else ("template" if copy else "none"),
                     "title": str(copy.get("title") or seed.get("title") or "")[:75],
                     "featuresLength": len(str(copy.get("features") or seed.get("features") or ""))},
            "draftId": draft_id, "readiness": readiness,
            "warnings": pref.get("warnings") or [],
            "hint": ("试算只预览，不写草稿；关掉试算会写入上架草稿（上架编排里可批量校验/导出）。"
                     "已在售商品被拦下是有意的——那种情况应该跟卖。"),
        }

    return _safe(build, _fallback({"ok": False, "blocked": False}))


@router.post("/products/content-run")
def products_content_run(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """缺内容 → 抓取 → AI 文案 → 建草稿。dryRun 默认 true（只给计划与文案预览）。"""
    payload = body if isinstance(body, dict) else {}

    def build() -> Dict[str, Any]:
        sid = str(payload.get("storeId") or "").strip()
        raw_skus = payload.get("skus") or []
        if isinstance(raw_skus, str):
            raw_skus = [raw_skus]
        wanted = [str(x).strip() for x in raw_skus if str(x or "").strip()]
        dry_run = bool(payload.get("dryRun", True))
        try:
            limit = max(1, min(int(payload.get("limit") or 5), CONTENT_RUN_MAX))
        except (TypeError, ValueError):
            limit = 5
        language = "zh" if str(payload.get("language") or "en").lower().startswith("zh") else "en"
        deadline = time.time() + CONTENT_RUN_BUDGET

        context = _catalog_items(store_id=sid or None)
        items = [i for i in (context.get("items") or []) if isinstance(i, dict)]
        if wanted:
            by_sku = {str(i.get("sku") or ""): i for i in items}
            targets = [by_sku[k] for k in wanted if k in by_sku]
            missing = [k for k in wanted if k not in by_sku]
        else:
            missing = []
            gaps = [i for i in items if (i.get("content") or {}).get("missing")]
            gaps.sort(key=lambda i: -len((i.get("content") or {}).get("missing") or []))
            targets = gaps
        targets = targets[:limit]

        rows: List[Dict[str, Any]] = []
        for item in targets:
            sku = str(item.get("sku") or "")
            card = {}
            number = _plid_of(item.get("plid") or item.get("productline_id") or item.get("tsin")) or _plid_of(sku)
            crawl_error = None
            if number and time.time() < deadline:
                try:
                    crawl = _crawl_target("PLID{0}".format(number), force=False) or {}
                    card = {"product": crawl.get("product") or {}, "transport": crawl.get("transport"),
                            "cached": bool(crawl.get("cached"))}
                    crawl_error = crawl.get("error")
                except Exception as exc:  # pragma: no cover
                    crawl_error = str(exc)
            product = card.get("product") or {}
            category_path = str((product.get("category") or {}).get("path") or
                                (item.get("enrichment") or {}).get("categoryPath") or
                                (item.get("categoryPath") or ""))
            main_category, leaf_category = _split_category_path(category_path)
            images = [str(u) for u in (product.get("images") or []) if u][:IMAGE_COLUMN_COUNT]
            if not images and item.get("imageUrl"):
                images = [str(item["imageUrl"])]
            gaps = list((item.get("content") or {}).get("missing") or [])
            attributes = product.get("attributes") if isinstance(product.get("attributes"), dict) else {}
            try:
                copy = _ai_listing_copy({
                    "keywords": " ".join(x for x in [product.get("title") or item.get("title"),
                                                     leaf_category, main_category] if x)[:180],
                    "category": leaf_category or category_path,
                    "language": language,
                    "attributes": attributes,
                })
            except Exception as exc:  # pragma: no cover
                copy = {}
                crawl_error = crawl_error or str(exc)
            title = str(copy.get("title") or product.get("title") or item.get("title") or "")[:75]
            draft_id = ""
            errors: List[str] = []
            if not dry_run:
                draft = _draft_upsert({
                    "sku": sku,
                    "barcode": item.get("barcode") or product.get("barcode"),
                    "tsin": item.get("tsin") or product.get("tsin"),
                    "plid": item.get("plid") or ("PLID{0}".format(number) if number else ""),
                    "brand": item.get("brand") or product.get("brand"),
                    "title": title,
                    "subtitle": str(copy.get("subtitle") or "")[:110],
                    "features": str(copy.get("features") or ""),
                    "whatsInTheBox": str(copy.get("boxContents") or ""),
                    "description": str(copy.get("description") or ""),
                    "images": images,
                    "categoryPath": category_path,
                    "mainCategory": main_category,
                    "lowestCategory": leaf_category,
                    "price": item.get("price"),
                    "storeId": sid or None,
                    "attributes": {k: v for k, v in (attributes or {}).items() if str(v).strip()},
                    "status": "draft",
                })
                draft_id = str(draft.get("id") or "")
                readiness = _draft_readiness(draft)
                if not readiness.get("ok"):
                    errors.append("建档后仍未就绪：" + "；".join((readiness.get("errors") or [])[:4]))
            rows.append({
                "sku": sku, "title": title, "plid": "PLID{0}".format(number) if number else "",
                "gaps": gaps, "crawled": bool(card.get("cached") is False and product), "fromCache": bool(card.get("cached")),
                "transport": card.get("transport"), "images": len(images),
                "categoryPath": category_path, "mainCategory": main_category, "lowestCategory": leaf_category,
                "copySource": "ai" if str(copy.get("title") or "").strip() and _llm_key() else "template",
                "featuresLength": len(str(copy.get("features") or "")),
                "draftId": draft_id, "errors": errors, "crawlError": crawl_error,
                "preview": {"title": title, "subtitle": str(copy.get("subtitle") or "")[:110],
                            "features": str(copy.get("features") or "")[:400]},
            })
        drafted = [r for r in rows if r.get("draftId")]
        ready_after = 0
        if not dry_run and drafted:
            drafts_now = _drafts()
            by_id = {str(d.get("id")): d for d in drafts_now}
            ready_after = sum(1 for r in drafted if (_draft_readiness(by_id.get(r["draftId"]) or {}) or {}).get("ok"))
        return {
            "ok": True, "dryRun": dry_run, "storeId": sid, "considered": len(rows),
            "summary": {
                "considered": len(rows), "drafted": len(drafted), "readyAfter": ready_after,
                "crawled": len([r for r in rows if not r.get("fromCache") and r.get("transport")]),
                "withCategory": len([r for r in rows if r.get("lowestCategory")]),
                "withImages": len([r for r in rows if r.get("images")]),
                "failed": len([r for r in rows if r.get("crawlError")]),
                "limit": limit, "max": CONTENT_RUN_MAX,
            },
            "notInCatalogue": missing,
            "rows": rows,
            "hint": ("试算只生成文案与计划、不写草稿；关掉试算会写入 state/drafts.json（上架编排里直接可见，"
                     "可用批量校验/导出）。每条草稿建完都会立刻跑一次就绪度自检。"),
        }

    return _safe(build, _fallback({"ok": False, "rows": [], "summary": {}}))


@router.post("/products/enrich")
def products_enrich(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """Bounded (≤20), cache-first crawl enrichment of N products — never 500s."""
    payload = body if isinstance(body, dict) else {}

    def build() -> Dict[str, Any]:
        raw_skus = payload.get("skus") or payload.get("items") or []
        if isinstance(raw_skus, str):
            raw_skus = [raw_skus]
        raw_skus = [str(s).strip() for s in raw_skus if str(s or "").strip()]
        force = bool(payload.get("force"))
        all_flag = bool(payload.get("all")) or not raw_skus
        try:
            wanted = max(1, min(int(payload.get("limit") or ENRICH_MAX), ENRICH_MAX))
        except (TypeError, ValueError):
            wanted = ENRICH_MAX
        try:
            budget = max(5.0, min(float(payload.get("budget") or 45.0), 120.0))
        except (TypeError, ValueError):
            budget = 45.0
        offers = _offer_rows(payload.get("storeId") or payload.get("store_id"))
        rows = [row for row in (offers.get("items") or []) if isinstance(row, dict)]
        entries = _crawl_entries()
        targets: List[Dict[str, Any]] = []
        seen: set = set()
        if raw_skus:
            for target in raw_skus:
                offer = _find_offer(rows, target)
                number = _plid_of((offer or {}).get("productline_id") or target)
                sku = str((offer or {}).get("sku") or target)
                key = number or sku.lower()
                if key in seen:
                    continue
                seen.add(key)
                targets.append({"sku": sku, "plid": "PLID{0}".format(number) if number else "",
                                "number": number, "offer": offer, "target": target})
        else:
            ordered = sorted(rows, key=lambda r: str(r.get("updated_at") or ""), reverse=True)
            ordered.sort(key=lambda r: bool(entries.get(_plid_of(r.get("productline_id"))) and not force))
            for offer in ordered:
                number = _plid_of(offer.get("productline_id"))
                if not number or number in seen:
                    continue
                seen.add(number)
                targets.append({"sku": str(offer.get("sku") or ""), "plid": "PLID{0}".format(number),
                                "number": number, "offer": offer, "target": "PLID{0}".format(number)})
        targets = targets[:wanted]
        deadline = time.time() + budget
        results: List[Dict[str, Any]] = []
        live_attempts = 0
        skipped = 0
        for entry in targets:
            result: Dict[str, Any] = {
                "sku": entry["sku"], "plid": entry["plid"], "ok": False, "error": None,
                "cached": False, "transport": None, "categoryPath": "", "images": [],
                "descriptionLen": 0, "title": str((entry["offer"] or {}).get("title") or ""),
                "rating": None, "monthlySales": None, "fetchedAt": None, "mode": None,
            }
            number = entry["number"]
            if not number:
                result["error"] = "无法从该 SKU 解析 PLID（商品不在本店 Offer 列表）"
                results.append(result)
                continue
            card = _cached_card(number, entries)
            card_product = card.get("product") or {}
            if card_product and not force:
                result.update(_enrich_result(card, "cache"))
                results.append(result)
                continue
            if offers.get("demo"):
                if card_product:
                    result.update(_enrich_result(card, "cache"))
                result["error"] = "无 Seller Key：先绑定 Key 才能抓取公开页面（不返回示例商品）"
                results.append(result)
                continue
            if time.time() >= deadline:
                skipped += 1
                result["error"] = "本轮时间预算用尽（每次≤{0}s，可再次调用继续补全）".format(int(budget))
                results.append(result)
                continue
            crawl = _crawl_target("PLID{0}".format(number), force=True) or {}
            live_attempts += 1
            product = crawl.get("product") if isinstance(crawl.get("product"), dict) else {}
            fresh_card = {
                "product": product or {},
                "windows": crawl.get("windows") or {},
                "sales": crawl.get("sales") or {},
                "rate": crawl.get("rate"),
                "rateSource": crawl.get("rateSource"),
                "fetchedAt": crawl.get("fetchedAt"),
                "transport": crawl.get("transport"),
                "cached": bool(crawl.get("cached")),
                "fresh": True,
                "ageDays": 0.0,
            }
            if product:
                _crawl_map_bust()
                result.update(_enrich_result(fresh_card, "live"))
                result["mode"] = str(crawl.get("mode") or "live")
            else:
                if card_product:
                    result.update(_enrich_result(card, "cache"))
                result["error"] = "{0}（已用缓存卡片兜底）".format(
                    crawl.get("error") or "抓取失败：公开接口没有返回该商品的卡片")
                result["transport"] = result.get("transport") or crawl.get("transport")
                result["mode"] = str(crawl.get("mode") or "blocked")
            results.append(result)
        enriched = sum(1 for row in results if row["ok"])
        failed = len(results) - enriched
        out: Dict[str, Any] = {
            "ok": True,
            "mode": offers.get("mode") or "empty",
            "requested": len(raw_skus) if raw_skus else None,
            "all": all_flag,
            "force": force,
            "considered": len(targets),
            "enriched": enriched,
            "failed": failed,
            "cached": sum(1 for row in results if row["cached"] and row["ok"]),
            "live": live_attempts,
            "skipped": skipped,
            "limitPerCall": ENRICH_MAX,
            "results": results,
            "generatedAt": _iso_now(),
        }
        if skipped:
            out["hint"] = "本轮抓到 {0} 个后时间预算用尽，再次调用会接着补全剩余 {1} 个。".format(live_attempts, skipped)
        elif offers.get("demo"):
            out["hint"] = "未配置 Seller X-API-Key：请先绑定 Key（商品目录为空，不返回示例商品）。"
        elif failed:
            out["hint"] = "抓取失败的 PLID 多为尚未公开的目录项（公开接口 404）；可改用 /crawler/ingest 投放原始 JSON。"
        return out

    return _safe(build, _fallback({
        "ok": False, "mode": "local", "enriched": 0, "failed": 0, "results": [],
        "hint": CRAWLER_HINT_STATIC,
    }))


def _enrich_result(card: Dict[str, Any], source: str) -> Dict[str, Any]:
    product = (card or {}).get("product") or {}
    images = _product_image_urls(product)
    description = str(product.get("description") or "").strip()
    return {
        "ok": bool(product),
        "error": None if product else "缓存卡片为空",
        "cached": source == "cache",
        "transport": card.get("transport"),
        "categoryPath": _crawl_category_path(product),
        "images": images,
        "imageCount": len(images),
        "descriptionLen": len(description),
        "title": str(product.get("title") or ""),
        "rating": product.get("rating"),
        "reviews": product.get("reviews"),
        "sellerCount": product.get("sellerCount"),
        "monthlySales": (card.get("sales") or {}).get("estimated_monthly_sales"),
        "fetchedAt": card.get("fetchedAt"),
        "mode": "cache" if source == "cache" else "live",
    }


@router.post("/collection/refresh")
def collection_refresh(body: Optional[Dict[str, Any]] = Body(default=None)) -> Dict[str, Any]:
    """Re-crawl 采集箱 rows (cache-first) and backfill imageUrl/images/categoryPath/description/sellRoute."""
    payload = body if isinstance(body, dict) else {}

    def build() -> Dict[str, Any]:
        ids = payload.get("ids") or payload.get("itemIds") or []
        if isinstance(ids, str):
            ids = [ids]
        wanted = {str(i) for i in ids if str(i or "").strip()}
        all_flag = bool(payload.get("all")) or not wanted
        force = bool(payload.get("force"))
        try:
            budget = max(4.0, min(float(payload.get("budget") or 30.0), 120.0))
        except (TypeError, ValueError):
            budget = 30.0
        items = _collection()
        selected = [item for item in items
                    if isinstance(item, dict) and (all_flag or str(item.get("id")) in wanted)][:REFRESH_MAX]
        entries = _crawl_entries()
        offers = _offers_for_route(payload.get("storeId") or payload.get("store_id"))
        by_plid: Dict[str, Any] = {}
        for offer in offers:
            number = _plid_of(offer.get("productline_id"))
            if number:
                by_plid.setdefault(number, offer)
        deadline = time.time() + budget
        results: List[Dict[str, Any]] = []
        dims_by_id: Dict[str, List[str]] = {}
        updated = 0
        live_attempts = 0
        skipped = 0
        for item in selected:
            number = _plid_of(item.get("plid") or item.get("sourceUrl") or item.get("tsin"))
            plid = "PLID{0}".format(number) if number else ""
            card = _crawl_card_for_row(item, entries) if number else {}
            product = card.get("product") or {}
            meta: Dict[str, Any] = {
                "mode": "cache" if product else "empty",
                "transport": card.get("transport"),
                "fetchedAt": card.get("fetchedAt"),
                "cached": bool(card.get("cached")),
                "error": None,
            }
            if not product and number and not force:
                if time.time() < deadline:
                    crawl = _crawl_target(plid, force=True) or {}
                    live_attempts += 1
                    product = crawl.get("product") if isinstance(crawl.get("product"), dict) else {}
                    meta.update({
                        "mode": str(crawl.get("mode") or "blocked"),
                        "transport": crawl.get("transport"),
                        "fetchedAt": crawl.get("fetchedAt"),
                        "cached": bool(crawl.get("cached")),
                        "error": crawl.get("error"),
                        "hint": crawl.get("hint"),
                    })
                    if product:
                        _crawl_map_bust()
                        card = {"product": product, "windows": crawl.get("windows") or {},
                                "sales": crawl.get("sales") or {}, "rate": crawl.get("rate"),
                                "rateSource": crawl.get("rateSource"),
                                "fetchedAt": crawl.get("fetchedAt"), "transport": crawl.get("transport"),
                                "cached": bool(crawl.get("cached")), "fresh": True, "ageDays": 0.0}
                else:
                    skipped += 1
                    meta["error"] = "时间预算用尽：再次调用会接着补全（每轮≤{0}s）".format(int(budget))
            item["plid"] = plid or str(item.get("plid") or "")
            media = _row_media(item, card)
            for key in ("images", "imageUrl", "description", "categoryPath", "productTargetUrl"):
                if media.get(key):
                    item[key] = media[key]
            item["description"] = str(media.get("description") or "")
            item["descriptionLen"] = len(item["description"])
            item["images"] = media.get("images") or ([item.get("imageUrl")] if item.get("imageUrl") else [])
            item["categoryPath"] = str(media.get("categoryPath") or item.get("category") or "")
            item["productTargetUrl"] = str(media.get("productTargetUrl") or "")
            if media.get("rating") is not None:
                item["rating"] = media["rating"]
            if media.get("reviews") is not None:
                item["reviews"] = media["reviews"]
            if media.get("sellerCount") is not None:
                item["sellerCount"] = media["sellerCount"]
            # 条码/包装尺寸：只在行里没有时从公开页补（用户填过的一律不覆盖）。
            # 履约费按体积 cm³ 档定价，所以尺寸/重量就是费率条件的输入；页面没写就留空，
            # 由界面「核算参数」或采集时手工补，不猜。
            if product:
                card_pairs = _product_attribute_pairs(product)
                if not item.get("barcode"):
                    card_barcode = _product_barcode(product, card_pairs)
                    if card_barcode:
                        item["barcode"] = card_barcode
                dims_backfilled = []
                card_dims = _product_dimensions(card_pairs)
                if card_dims.get("lengthCm") and not (item.get("lengthCm") and item.get("widthCm") and item.get("heightCm")):
                    item["lengthCm"] = item.get("lengthCm") or card_dims["lengthCm"]
                    item["widthCm"] = item.get("widthCm") or card_dims["widthCm"]
                    item["heightCm"] = item.get("heightCm") or card_dims["heightCm"]
                    item["dimensionSource"] = card_dims.get("volumeSource")
                    item["dimensionRaw"] = card_dims.get("raw")
                    dims_backfilled.append("lengthCm")
                if card_dims.get("weightKg") and not item.get("weightKg"):
                    item["weightKg"] = card_dims["weightKg"]
                    dims_backfilled.append("weightKg")
                if dims_backfilled:
                    dims_by_id[item.get("id")] = dims_backfilled
            if number and by_plid.get(number):
                item["sku"] = str(by_plid[number].get("sku") or item.get("sku") or "")
            route = _sell_route(item, product, meta, offers)
            item["sellRoute"] = route
            item["sku"] = str(item.get("sku") or route.get("sku") or "")
            item["refreshedAt"] = _iso_now()
            if product:
                updated += 1
            row = _collection_row(item)
            row["assignedStoreId"] = str(_item_store(item).get("id")) if _item_store(item) else None
            row["assignedStoreName"] = (_item_store(item) or {}).get("name")
            row["storeName"] = row["assignedStoreName"]
            results.append({
                "id": item.get("id"), "ok": bool(product), "updated": bool(product),
                "plid": plid, "sku": item.get("sku"), "error": meta.get("error"),
                "mode": meta.get("mode"), "transport": meta.get("transport"),
                "cached": bool(meta.get("cached")), "fetchedAt": meta.get("fetchedAt"),
                "imageUrl": item.get("imageUrl"), "images": item.get("images"),
                "imageCount": len(item.get("images") or []),
                "descriptionLen": len(item.get("description") or ""),
                "categoryPath": item.get("categoryPath"),
                "dimensionsBackfilled": dims_by_id.get(item.get("id")) or [],
                "sellRoute": route.get("route"), "sellRouteLabel": route.get("targetLabel"),
                "targetUrl": route.get("targetUrl"),
            })
        if selected:
            _write_state("collection.json", items)
        ok_count = sum(1 for row in results if row["updated"])
        out: Dict[str, Any] = {
            "ok": True,
            "mode": "live" if ok_count else "degraded",
            "requested": sorted(wanted) if wanted else None,
            "all": all_flag,
            "refreshed": len(results),
            "updated": ok_count,
            "failed": len(results) - ok_count,
            "live": live_attempts,
            "skipped": skipped,
            "imagesBackfilled": sum(1 for row in results if row["imageCount"]),
            "textsBackfilled": sum(1 for row in results if row["descriptionLen"]),
            "results": results,
            "generatedAt": _iso_now(),
        }
        if skipped:
            out["hint"] = "本轮时间预算用尽，有 {0} 行未抓取：再次调用继续。".format(skipped)
        elif out["failed"]:
            out["hint"] = ("{0} 行没有回填到全文：这些 PLID 在公开接口没有卡片"
                           "（未公开的目录项/示例数据），已回填图片列表、类目与上架落点；"
                           "可把原始 JSON 放进 state/ingest/ 后再刷新。").format(out["failed"])
        return out

    return _safe(build, _fallback({
        "ok": False, "mode": "local", "refreshed": 0, "updated": 0, "failed": 0, "results": [],
        "hint": CRAWLER_HINT_STATIC,
    }))


_startup_warm()
