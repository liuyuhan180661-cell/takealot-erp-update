#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""内置调度器 —— 让「定时任务」跑在客户机自己身上（零外部依赖）。

为什么做在服务端里，而不是 Hermes cron / 系统 crontab：
  · 服务本来就在客户机上常驻、开机自启（`erp setup` 已注册自启）→ 调度跟着它走，客户什么都不用配；
  · 不依赖 Hermes、不依赖我们的机器 —— 客户关掉我们这边，任务照跑；
  · Mac 和 Windows 同一份实现（平台差异只在"谁把服务拉起来"，那部分已经解决了）；
  · 只有一个 runner（服务自己）→ **不会两头都挂导致重复执行**。

纪律（都是踩过的）：
  · **「没有消息」只能等于「跑了、没事」**，绝不能等于「没跑成」→ 每轮都留证据文件；
    连续失败/连续离线要升级告警（🔴），不许静默（v2 时代静默 4 天就是这里翻的车）。
  · 写平台的动作（改价/改库存/上架）默认**停用**，且必须显式授权过一次才会跑（红线）。
  · 本机回环 HTTP 必须绕系统代理（Clash 等会把 127.0.0.1 拦成 502）。
  · 杀掉子进程要连子子孙孙一起杀（Windows 上 taskkill /T）。
"""
from __future__ import annotations

import datetime as dt
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

#: 每轮调度tick的间隔（秒）。任务到点了才起进程，tick 本身很便宜。
TICK_SECONDS = 20
#: 连续失败/离线多少次后升级为 🔴（默认 6 次；按 120 分钟的巡检 ≈ 12 小时）
ESCALATE_AFTER = 6
#: 单个任务默认超时（秒）—— 卡死不能拖住整个调度器
DEFAULT_TIMEOUT = 3600
#: 每个任务保留多少份历史输出
DEFAULT_KEEP = 30


def _now() -> dt.datetime:
    return dt.datetime.now().astimezone()


def _iso(t: dt.datetime | None = None) -> str:
    return (t or _now()).replace(microsecond=0).isoformat()


def _load_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


# ---------------------------------------------------------------------------
# 排期：两种写法（够用就好，不引第三方 cron 库）
# ---------------------------------------------------------------------------
def _parse_cron_field(field: str, lo: int, hi: int) -> set[int] | None:
    """支持 `*`、`a`、`a-b`、`a,b`、`*/n` 这几种写法。认不出就返回 None（不猜）。"""
    out: set[int] = set()
    for part in field.split(","):
        part = part.strip()
        if not part:
            return None
        step = 1
        if "/" in part:
            part, _, s = part.partition("/")
            if not s.isdigit() or int(s) == 0:
                return None
            step = int(s)
        if part == "*":
            lo_p, hi_p = lo, hi
        elif "-" in part:
            a, _, b = part.partition("-")
            if not (a.isdigit() and b.isdigit()):
                return None
            lo_p, hi_p = int(a), int(b)
        elif part.isdigit():
            if step == 1:
                out.add(int(part))
                continue
            lo_p, hi_p = int(part), hi
        else:
            return None
        out.update(range(lo_p, hi_p + 1, step))
    return {v for v in out if lo <= v <= hi} or None


def _cron_matches(expr: str, when: dt.datetime) -> bool:
    """`m h dom mon dow`（5 段）。支持常见写法即可；认不出返回 False（宁可不跑也不乱跑）。"""
    parts = expr.split()
    if len(parts) != 5:
        return False
    minute = _parse_cron_field(parts[0], 0, 59)
    hour = _parse_cron_field(parts[1], 0, 23)
    dom = _parse_cron_field(parts[2], 1, 31)
    mon = _parse_cron_field(parts[3], 1, 12)
    # cron 的 dow：0/7 = 周日；Python weekday() 周一=0 → 转成 cron 口径
    dow_raw = _parse_cron_field(parts[4], 0, 7)
    if minute is None or hour is None or dom is None or mon is None or dow_raw is None:
        return False
    dow = {0 if d == 7 else d for d in dow_raw}
    py_dow = (when.weekday() + 1) % 7
    return (when.minute in minute and when.hour in hour
            and when.day in dom and when.month in mon and py_dow in dow)


def due_now(job: dict, last_run: dt.datetime | None, when: dt.datetime | None = None) -> bool:
    """这个任务现在该跑吗？（interval 按分钟；cron 按表达式，同分钟内只触发一次）"""
    when = when or _now()
    sched = job.get("schedule") or {}
    kind = sched.get("kind") or ("cron" if sched.get("cron") else "interval")
    if kind == "cron":
        expr = str(sched.get("cron") or "")
        if not _cron_matches(expr, when):
            return False
        return last_run is None or (when - last_run).total_seconds() >= 60
    minutes = float(sched.get("minutes") or 0)
    if minutes <= 0:
        return False
    if last_run is None:
        return True   # 首次：服务刚起来就先跑一轮（客户立刻能看到证据，而不是等 2 小时）
    return (when - last_run).total_seconds() >= minutes * 60


def next_run_at(job: dict, last_run: dt.datetime | None, horizon_days: int = 8) -> str:
    """下一次大概什么时候跑（给界面看的，逐分钟推，认不出就空着 —— 不编）。"""
    when = _now().replace(second=0, microsecond=0) + dt.timedelta(minutes=1)
    limit = when + dt.timedelta(days=horizon_days)
    while when < limit:
        if due_now(job, last_run, when):
            return _iso(when)
        when += dt.timedelta(minutes=1)
    return ""


# ---------------------------------------------------------------------------
# 调度器本体
# ---------------------------------------------------------------------------
class Scheduler:
    def __init__(self, home: Path, python: str | None = None, log=lambda *a, **k: None):
        self.home = Path(home)
        self.jobs_file = self.home / "jobs" / "jobs.json"
        self.log_dir = self.home / "logs" / "jobs"
        self.status_file = self.home / "state" / "jobs_status.json"
        self.log = log
        self.python = python or sys.executable
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._running: set[str] = set()
        self._last: dict[str, dt.datetime] = {}
        self.started_at = _iso()

    # ---- 配置 ----
    def jobs(self, enabled_only: bool = False) -> list[dict]:
        raw = _load_json(self.jobs_file, {})
        items = raw.get("jobs") if isinstance(raw, dict) else raw
        if not isinstance(items, list):
            return []
        out = []
        for j in items:
            if not isinstance(j, dict) or not j.get("id"):
                continue
            if enabled_only and not j.get("enabled", True):
                continue
            out.append(j)
        return out

    def write_jobs(self, jobs: list[dict]) -> None:
        _write_json(self.jobs_file, {"schema": 1, "jobs": jobs})

    # ---- 状态 ----
    def status(self) -> dict:
        st = _load_json(self.status_file, {})
        if not isinstance(st, dict):
            st = {}
        out = []
        for j in self.jobs():
            jid = j["id"]
            rec = dict(st.get(jid) or {})
            last = self._last.get(jid)
            if last is None and rec.get("lastRunAt"):
                try:
                    last = dt.datetime.fromisoformat(rec["lastRunAt"])
                except Exception:
                    last = None
            rec.update({
                "id": jid,
                "name": j.get("name") or jid,
                "enabled": bool(j.get("enabled", True)),
                "schedule": j.get("schedule") or {},
                "scheduleText": _schedule_text(j),
                "kind": "write" if j.get("kind") == "write" else "read",
                "requiresAuthorization": bool(j.get("requiresAuthorization")),
                "nextRunAt": next_run_at(j, last) if j.get("enabled", True) else "",
                "running": jid in self._running,
            })
            out.append(rec)
        return {
            "ok": True,
            "running": bool(self._thread and self._thread.is_alive()),
            "startedAt": self.started_at,
            "tickSeconds": TICK_SECONDS,
            "alertAfter": ESCALATE_AFTER,
            "jobsFile": str(self.jobs_file),
            "jobs": out,
        }

    def _bump_status(self, jid: str, patch: dict) -> None:
        st = _load_json(self.status_file, {}) or {}
        rec = dict(st.get(jid) or {})
        rec.update(patch)
        st[jid] = rec
        _write_json(self.status_file, st)

    # ---- 运行一个任务 ----
    def run_job(self, job: dict, manual: bool = False) -> dict:
        jid = str(job["id"])
        with self._lock:
            if jid in self._running:
                return {"ok": False, "error": "这个任务正在跑，跳过（不并发同一个任务）"}
            self._running.add(jid)
        t0 = _now()
        # 脚本随代码走（ERP_HOME/server/jobs/，升级会自动换新），jobs.json 是用户配置
        # （ERP_HOME/jobs/jobs.json，永不被安装覆盖）→ 两处都找，先代码后用户。
        name = str(job.get("script") or "")
        script = self.home / "server" / "jobs" / name
        if not script.exists():
            script = self.home / "jobs" / name
        args = [str(a) for a in (job.get("args") or [])]
        timeout = int(job.get("timeoutSec") or DEFAULT_TIMEOUT)
        env = dict(os.environ)
        env["ERP_HOME"] = str(self.home)
        env["PYTHONUTF8"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        # 本机回环绕代理（Clash 之类会把 127.0.0.1 拦成 502）
        no_proxy = ",".join(x for x in [env.get("NO_PROXY", ""), "127.0.0.1", "localhost", "::1"] if x)
        env["NO_PROXY"] = no_proxy
        env["no_proxy"] = no_proxy

        runner = self.python
        if script.suffix == ".py" and not Path(runner).exists():
            runner = "python3"
        result: dict = {"id": jid, "name": job.get("name") or jid, "ranAt": _iso(t0), "manual": manual}
        out_text = ""
        try:
            if not script.exists():
                raise FileNotFoundError("找不到脚本：%s" % script)
            cmd = ([runner, str(script)] if script.suffix == ".py" else [str(script)]) + args
            creationflags = 0x08000000 if os.name == "nt" else 0   # CREATE_NO_WINDOW
            cp = subprocess.run(cmd, cwd=str(self.home), env=env, capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=timeout,
                                creationflags=creationflags)
            out_text = (cp.stdout or "") + (("\n[stderr]\n" + cp.stderr) if cp.stderr else "")
            result["exitCode"] = cp.returncode
        except subprocess.TimeoutExpired as exc:
            out_text = "⏱ 超时 %ss，已杀掉（任务卡死，别拖住别的任务）" % timeout
            if exc.stdout:
                out_text += "\n" + (exc.stdout if isinstance(exc.stdout, str) else exc.stdout.decode("utf-8", "replace"))
            result["exitCode"] = 124
        except Exception as exc:  # 脚本不存在 / 起不来
            out_text = "起不来：{0}: {1}".format(type(exc).__name__, exc)
            result["exitCode"] = 127

        dur = (_now() - t0).total_seconds()
        code = result.get("exitCode")
        # 退出码语义（脚本自己的约定）：0 = 无异常；**1 = 有要汇报的事**（例如有退货/有逾期 PO）；
        # >=2、124(超时)、127(起不来) 才算真失败。把 1 当失败会让告警喊狼来了 —— 然后人就无视它了。
        ok = code == 0
        needs_attention = code == 1
        offline = ("不在线" in out_text) or ("连不上" in out_text) or ("离线" in out_text)
        prev = (_load_json(self.status_file, {}) or {}).get(jid) or {}
        if offline:
            offline_streak = int(prev.get("offlineStreak") or 0) + 1
        else:
            offline_streak = 0
        fail_streak = 0 if code in (0, 1) else int(prev.get("failStreak") or 0) + 1

        stamp = t0.strftime("%Y%m%d-%H%M%S")
        jdir = self.log_dir / jid
        jdir.mkdir(parents=True, exist_ok=True)
        head = [
            "# {0}（{1}）".format(result["name"], "手动触发" if manual else "定时触发"),
            "",
            "- 时间：{0}".format(result["ranAt"]),
            "- 排期：{0}".format(_schedule_text(job)),
            "- 退出码：{0}｜耗时 {1:.1f}s".format(result.get("exitCode"), dur),
            "" if not offline else "- ⚠️ 这一轮里出现了「不在线/连不上」",
            "",
            "```",
        ]
        (jdir / (stamp + ".md")).write_text("\n".join(head) + "\n" + out_text.strip() + "\n```\n", encoding="utf-8")

        # 只留最近 N 份
        keep = int(job.get("keep") or DEFAULT_KEEP)
        olds = sorted(jdir.glob("*.md"))
        for p in olds[:-keep]:
            try:
                p.unlink()
            except Exception:
                pass

        result.update({"ok": ok, "needsAttention": needs_attention, "durationSec": round(dur, 1), "offline": offline,
                       "offlineStreak": offline_streak, "failStreak": fail_streak,
                       "logFile": str(jdir / (stamp + ".md")), "summary": _summarize(out_text)})
        self._last[jid] = t0
        self._bump_status(jid, {
            "lastRunAt": result["ranAt"], "lastExitCode": result.get("exitCode"),
            "lastOk": ok, "lastManual": manual, "lastDurationSec": result["durationSec"],
            "lastLogFile": result["logFile"], "lastSummary": result["summary"],
            "offlineStreak": offline_streak, "failStreak": fail_streak,
            "attention": needs_attention,
            "alert": _alert_text(offline_streak, fail_streak, needs_attention),
        })
        with self._lock:
            self._running.discard(jid)
        self.log("[job] {0} exit={1} {2:.1f}s{3}".format(jid, result.get("exitCode"), dur,
                                                         "（离线第 %d 次）" % offline_streak if offline else ""))
        return result

    def run_all_enabled(self) -> list[dict]:
        return [self.run_job(j, manual=True) for j in self.jobs(enabled_only=True)]

    # ---- 线程 ----
    def _loop(self) -> None:
        self.log("[scheduler] 起来：{0} 个任务，tick {1}s".format(len(self.jobs()), TICK_SECONDS))
        while not self._stop.is_set():
            try:
                for job in self.jobs(enabled_only=True):
                    jid = str(job["id"])
                    if jid in self._running:
                        continue
                    last = self._last.get(jid)
                    if last is None:
                        rec = (_load_json(self.status_file, {}) or {}).get(jid) or {}
                        try:
                            last = dt.datetime.fromisoformat(rec["lastRunAt"]) if rec.get("lastRunAt") else None
                        except Exception:
                            last = None
                    if due_now(job, last):
                        self.run_job(job)
            except Exception as exc:   # 调度器自己绝不能死
                self.log("[scheduler] tick 出错（继续跑）：{0}: {1}".format(type(exc).__name__, exc))
            self._stop.wait(TICK_SECONDS)
        self.log("[scheduler] 停了")

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="erp-scheduler", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()


def _schedule_text(job: dict) -> str:
    sched = job.get("schedule") or {}
    kind = sched.get("kind") or ("cron" if sched.get("cron") else "interval")
    if kind == "cron":
        return "cron: " + str(sched.get("cron") or "")
    minutes = float(sched.get("minutes") or 0)
    if minutes <= 0:
        return "未设排期"
    if minutes % 60 == 0:
        return "每 %d 小时" % (minutes / 60)
    return "每 %d 分钟" % minutes


def _summarize(text: str, limit: int = 400) -> str:
    """给界面看的一句话摘要：取最后一段有内容的行（不编，就是原话）。"""
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    tail = " ".join(lines[-3:]) if lines else "（脚本没有任何输出）"
    return tail[:limit]


def _alert_text(offline_streak: int, fail_streak: int, attention: bool = False) -> str:
    if offline_streak >= ESCALATE_AFTER:
        return "🔴 已连续 %d 次连不上/不在线 —— 任务实际上没在工作，看看店铺密钥或出口代理" % offline_streak
    if offline_streak > 0:
        return "⚠️ 这一轮连不上/不在线（连续 %d 次；到 %d 次升级为 🔴）" % (offline_streak, ESCALATE_AFTER)
    if fail_streak >= 3:
        return "🔴 连续 %d 次真失败（跑不起来/报错/超时），需要看一眼" % fail_streak
    if fail_streak > 0:
        return "⚠️ 上一次是真失败（连续 %d 次）" % fail_streak
    if attention:
        return "ℹ️ 上一轮有要处理的事（退出码 1，不是故障）"
    return ""
