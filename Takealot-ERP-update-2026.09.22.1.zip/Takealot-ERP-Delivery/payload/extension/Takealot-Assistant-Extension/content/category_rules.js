/**
 * Takealot 运营助手 & ERP - 类目与必填属性规则引擎
 * 关键词 -> Takealot 部门/类目 -> 表单必填属性
 * Strictly No Emojis, Commercial Standard
 */

const TakealotCategoryRules = {
  // Comprehensive Takealot Taxonomy Directory with Field Types and Options
  categories: [
    {
      id: 'cat_headphones',
      keywords: ['earphone', 'headphone', 'earbuds', 'headset', 'airpods', 'anc', 'tws', 'audio', 'earpieces'],
      department: 'Electronics',
      category: 'Audio & Visual > Headphones & Earphones',
      commissionRate: 7.5,
      mandatoryAttributes: [
        { name: 'Colour', type: 'select', options: ['Black', 'White', 'Blue', 'Grey', 'Red', 'Pink', 'Green', 'Silver'] },
        { name: 'Connectivity', type: 'select', options: ['Wireless (Bluetooth)', 'Wired (3.5mm Jack)', 'Wired (USB-C)', 'True Wireless (TWS)'] },
        { name: 'Model Number', type: 'text', placeholder: 'e.g. TKL-ANC-01' },
        { name: 'Has Microphone', type: 'select', options: ['Yes', 'No'] }
      ],
      optionalAttributes: [
        { name: 'Noise Cancelling', type: 'select', options: ['Active Noise Cancelling (ANC)', 'Environmental Noise Cancelling (ENC)', 'Passive Noise Isolation', 'None'] },
        { name: 'Battery Life', type: 'text', placeholder: 'e.g. Up to 28 Hours' },
        { name: 'Bluetooth Version', type: 'select', options: ['Bluetooth 5.4', 'Bluetooth 5.3', 'Bluetooth 5.2', 'Bluetooth 5.0'] }
      ]
    },
    {
      id: 'cat_cables',
      keywords: ['cable', 'charger', 'usb-c', 'lightning', 'type-c', 'adapter', 'power bank', 'charging cord'],
      department: 'Electronics',
      category: 'Cellphones & Wearables > Mobile Accessories > Cables & Adapters',
      commissionRate: 7.5,
      mandatoryAttributes: [
        { name: 'Cable Length', type: 'select', options: ['0.5m', '1.0m', '1.2m', '1.5m', '2.0m', '3.0m'] },
        { name: 'Connector Type', type: 'select', options: ['USB-C to USB-C', 'USB-A to USB-C', 'USB-C to Lightning', 'USB-A to Lightning', 'Micro-USB'] },
        { name: 'Colour', type: 'select', options: ['Black', 'White', 'Grey', 'Braided Silver', 'Blue'] }
      ],
      optionalAttributes: [
        { name: 'Fast Charging Support', type: 'select', options: ['Power Delivery (PD 65W+)', 'Power Delivery (PD 20W-30W)', 'Quick Charge (QC 3.0)', 'Standard 2.4A'] },
        { name: 'Power Output', type: 'text', placeholder: 'e.g. 60W / 100W Max' }
      ]
    },
    {
      id: 'cat_chargers',
      keywords: ['wall charger', 'fast charger', 'gan charger', 'wireless charger', 'charging station'],
      department: 'Electronics',
      category: 'Cellphones & Wearables > Mobile Accessories > Chargers',
      commissionRate: 7.5,
      mandatoryAttributes: [
        { name: 'Power Output (Watts)', type: 'select', options: ['20W', '30W', '45W', '65W', '100W', '120W+'] },
        { name: 'Number of Ports', type: 'select', options: ['1 Port', '2 Ports', '3 Ports', '4+ Ports'] },
        { name: 'Colour', type: 'select', options: ['Black', 'White'] }
      ],
      optionalAttributes: [
        { name: 'Charging Technology', type: 'select', options: ['GaN (Gallium Nitride)', 'Standard Silicon', 'Qi Wireless'] }
      ]
    },
    {
      id: 'cat_phone_mounts',
      keywords: ['phone mount', 'car mount', 'phone holder', 'car bracket', 'dashboard mount', 'windshield holder'],
      department: 'Automotive',
      category: 'Vehicle Electronics & Accessories > Mounts & Holders',
      commissionRate: 11.0,
      mandatoryAttributes: [
        { name: 'Mount Type', type: 'select', options: ['Air Vent Clip', 'Dashboard / Windshield Suction', 'CD Slot', 'Cup Holder', 'Magnetic Surface'] },
        { name: 'Colour', type: 'select', options: ['Black', 'Space Grey', 'Silver', 'Carbon Fiber'] },
        { name: 'Material', type: 'select', options: ['Aluminium Alloy', 'ABS Plastic', 'Silicone + Plastic', 'Zinc Alloy'] }
      ],
      optionalAttributes: [
        { name: 'Rotation Angle', type: 'select', options: ['360 Degree Swivel', '180 Degree Tilt', 'Fixed'] },
        { name: 'Compatible Phone Size', type: 'text', placeholder: 'e.g. 4.7 to 7.0 inches' }
      ]
    },
    {
      id: 'cat_fm_transmitters',
      keywords: ['fm transmitter', 'bluetooth car adapter', 'car mp3 player', 'radio adapter'],
      department: 'Automotive',
      category: 'Vehicle Electronics & Accessories > Audio Adapters',
      commissionRate: 11.0,
      mandatoryAttributes: [
        { name: 'Connectivity', type: 'select', options: ['Bluetooth 5.0 + FM', 'Bluetooth 5.3 + FM', 'AUX + FM'] },
        { name: 'Colour', type: 'select', options: ['Black', 'Grey', 'Silver'] },
        { name: 'Charging Ports', type: 'select', options: ['QC 3.0 + PD 20W', 'Dual USB-A', 'PD 30W + USB-A'] }
      ],
      optionalAttributes: [
        { name: 'Display Type', type: 'select', options: ['LED Digital Display', 'LCD Screen', 'None'] }
      ]
    },
    {
      id: 'cat_car_care',
      keywords: ['car wash', 'microfiber', 'polishing', 'car cleaning', 'drying towel', 'waxing sponge', 'detail brush'],
      department: 'Automotive',
      category: 'Car Care & Cleaning > Cleaning Tools & Cloths',
      commissionRate: 11.0,
      mandatoryAttributes: [
        { name: 'Material', type: 'select', options: ['Microfiber (80/20 Blend)', 'Chenille', 'Foam Sponge', 'Boar Hair Bristles'] },
        { name: 'Colour', type: 'select', options: ['Yellow/Grey', 'Blue', 'Black', 'Multi-Colour'] },
        { name: 'Pack Quantity', type: 'select', options: ['1 Pack', '2 Pack', '3 Pack', '5 Pack', '10 Pack'] }
      ],
      optionalAttributes: [
        { name: 'Fabric Weight (GSM)', type: 'select', options: ['300 GSM', '500 GSM', '800 GSM (Plush)', '1200 GSM (Ultra Heavy)'] }
      ]
    },
    {
      id: 'cat_kitchen_utensils',
      keywords: ['kitchen', 'cooking', 'knife', 'utensil', 'spatula', 'pan', 'pot', 'cutting board', 'baking', 'peeler', 'tongs'],
      department: 'Home & Kitchen',
      category: 'Kitchen & Dining > Cookware & Utensils',
      commissionRate: 12.0,
      mandatoryAttributes: [
        { name: 'Material', type: 'select', options: ['Food Grade Silicone', 'Stainless Steel 304', 'Natural Bamboo', 'Hardwood Beech', 'Cast Iron'] },
        { name: 'Colour', type: 'select', options: ['Black', 'Grey', 'Khaki', 'Stainless Steel Silver', 'Green'] },
        { name: 'Dishwasher Safe', type: 'select', options: ['Yes', 'No (Handwash Recommended)'] },
        { name: 'Pack Quantity', type: 'select', options: ['1 Piece', '2 Pieces', '3 Pieces', '5 Pieces Set', '12 Pieces Set'] }
      ],
      optionalAttributes: [
        { name: 'Heat Resistance', type: 'text', placeholder: 'e.g. Up to 230 C (446 F)' },
        { name: 'BPA Free', type: 'select', options: ['Yes (100% BPA Free)', 'No'] }
      ]
    },
    {
      id: 'cat_home_decor',
      keywords: ['cushion', 'pillow', 'lumbar pillow', 'rug', 'curtain', 'lamp', 'bedding', 'blanket', 'desk pad'],
      department: 'Home & Kitchen',
      category: 'Home Decor & Furniture > Soft Furnishings',
      commissionRate: 12.0,
      mandatoryAttributes: [
        { name: 'Colour', type: 'select', options: ['Black', 'Grey', 'Navy Blue', 'Beige', 'Cream', 'Charcoal'] },
        { name: 'Material', type: 'select', options: ['High Density Memory Foam', 'Breathable Mesh', 'Velvet', 'Cotton Linen', 'Polyester'] },
        { name: 'Dimensions (L x W x H)', type: 'text', placeholder: 'e.g. 45 x 38 x 12 cm' },
        { name: 'Removable Washable Cover', type: 'select', options: ['Yes', 'No'] }
      ],
      optionalAttributes: [
        { name: 'Care Instructions', type: 'text', placeholder: 'e.g. Machine wash cover cold, air dry' }
      ]
    },
    {
      id: 'cat_office_ergonomics',
      keywords: ['laptop stand', 'laptop riser', 'standing desk', 'monitor riser', 'desk converter', 'foot rest'],
      department: 'Office, Stationery & Books',
      category: 'Office Furniture > Ergonomic Desk Accessories',
      commissionRate: 11.5,
      mandatoryAttributes: [
        { name: 'Material', type: 'select', options: ['Anodized Aluminium Alloy', 'Carbon Steel', 'Natural Bamboo', 'Reinforced ABS Plastic'] },
        { name: 'Colour', type: 'select', options: ['Space Grey', 'Silver', 'Matte Black'] },
        { name: 'Adjustable Height Levels', type: 'select', options: ['6 Levels', '7 Levels', 'Infinite Stepless Adjustment', 'Fixed'] },
        { name: 'Maximum Load Capacity', type: 'text', placeholder: 'e.g. Up to 10kg' }
      ],
      optionalAttributes: [
        { name: 'Compatible Laptop Size', type: 'text', placeholder: 'e.g. 10 to 17.3 inches' },
        { name: 'With Cooling Fan', type: 'select', options: ['Yes (Dual Fans)', 'No (Passive Heat Dissipation)'] }
      ]
    },
    {
      id: 'cat_fitness',
      keywords: ['yoga', 'resistance band', 'dumbbell', 'fitness', 'gym', 'workout', 'skipping rope', 'pull up'],
      department: 'Sport & Training',
      category: 'Fitness & Gym > Exercise Equipment',
      commissionRate: 11.5,
      mandatoryAttributes: [
        { name: 'Material', type: 'select', options: ['Natural Latex', 'Cast Iron with Neoprene Coating', 'TPE Foam', 'Steel Wire with PVC'] },
        { name: 'Colour', type: 'select', options: ['Black', 'Blue', 'Purple', 'Grey', 'Pink', 'Multi-Colour Set'] },
        { name: 'Resistance Level / Weight', type: 'text', placeholder: 'e.g. 5-Band Set (10lbs - 50lbs) or 5kg Pair' }
      ],
      optionalAttributes: [
        { name: 'Target Muscle Group', type: 'text', placeholder: 'e.g. Full Body, Glutes, Arms, Core' }
      ]
    },
    {
      id: 'cat_beauty_tools',
      keywords: ['makeup brush', 'skincare', 'face roller', 'sponge', 'applicator', 'cosmetic', 'eyelash curler'],
      department: 'Beauty & Personal Care',
      category: 'Makeup > Makeup Brushes & Tools',
      commissionRate: 12.0,
      mandatoryAttributes: [
        { name: 'Colour', type: 'select', options: ['Rose Gold', 'Champagne', 'Matte Black', 'Pink'] },
        { name: 'Bristle / Head Material', type: 'select', options: ['Synthetic Fiber', 'Hydrophilic Non-Latex Sponge', 'Natural Jade Stone'] },
        { name: 'Number of Pieces', type: 'select', options: ['1 Piece', '2 Pieces', '4 Pieces', '8 Pieces Set', '14 Pieces Set'] }
      ],
      optionalAttributes: [
        { name: 'Includes Travel Case', type: 'select', options: ['Yes', 'No'] }
      ]
    },
    {
      id: 'cat_lighting',
      keywords: ['led strip', 'night light', 'desk lamp', 'solar light', 'torch', 'headlamp', 'ring light'],
      department: 'Home & Kitchen',
      category: 'Lighting > Specialty & Decorative Lighting',
      commissionRate: 12.0,
      mandatoryAttributes: [
        { name: 'Power Source', type: 'select', options: ['USB Rechargeable (Built-in Battery)', 'Solar Powered', 'AC Wall Plug', 'Battery Powered (AA/AAA)'] },
        { name: 'Light Colour Temperature', type: 'select', options: ['RGB Multi-Colour', 'Warm White (3000K)', 'Cool White (6500K)', '3 Colour Modes (Warm/Natural/Cool)'] },
        { name: 'Colour', type: 'select', options: ['White', 'Black'] }
      ],
      optionalAttributes: [
        { name: 'Control Method', type: 'select', options: ['App + Remote Control', 'Touch Sensor', 'Manual Switch'] }
      ]
    }
  ],

  // Universal Takealot Mandatory Fields across ALL categories
  universalMandatory: [
    { field: 'title', label: 'Listing Title', selector: 'input[name="title"], input#title, input[placeholder*="Title" i]' },
    { field: 'brand', label: 'Brand', selector: 'input[name="brand"], input#brand, input[placeholder*="Brand" i]' },
    { field: 'model', label: 'Model Number / Name', selector: 'input[name="model"], input#model' },
    { field: 'barcode', label: 'Barcode (EAN / UPC / GTIN)', selector: 'input[name="barcode"], input#barcode, input[placeholder*="Barcode" i]' },
    { field: 'sellingPrice', label: 'Selling Price (ZAR)', selector: 'input[name="selling_price"], input#selling_price, input[placeholder*="Price" i]' },
    { field: 'rrp', label: 'Recommended Retail Price (RRP)', selector: 'input[name="rrp"], input#rrp' },
    { field: 'leadTimeDays', label: 'Lead Time (Days)', selector: 'select[name="leadtime"], select#leadtime, input[name="leadtime"]' },
    { field: 'description', label: 'Description (HTML / Rich Text)', selector: 'textarea[name="description"], div.ql-editor, div[contenteditable="true"]' }
  ],

  // Prohibited words filter based on Takealot official styleguide
  prohibitedWords: [
    'best', 'cheapest', 'hot sale', '100% genuine', 'free shipping', 'top quality',
    'super sale', 'original factory', 'warranty included', 'guaranteed', 'buy now',
    'special offer', 'lowest price', 'top seller', 'limited offer'
  ],

  // Match best category based on product title and keywords
  matchCategory(title) {
    if (!title) return this.categories[0];
    const text = title.toLowerCase();

    for (const cat of this.categories) {
      for (const kw of cat.keywords) {
        if (text.includes(kw.toLowerCase())) {
          return cat;
        }
      }
    }

    return this.categories[0];
  },

  // Check which mandatory attributes are missing from a listing item
  validateListing(item) {
    const matchedCat = this.matchCategory(item.title);
    const missing = [];
    const warnings = [];

    if (!item.title) missing.push('Listing Title');
    // Note: Barcode is strictly optional! If not registered with GS1, leave empty for Takealot to auto-assign.
    if (!item.sellingPrice) missing.push('Selling Price');
    if (!item.images || item.images.length === 0) missing.push('At least 1 High-Res Image');

    // Title constraint checks (<= 75 chars)
    if (item.title) {
      if (item.title.length > 75) {
        warnings.push(`Title exceeds 75 characters (${item.title.length}/75). Trimming required by Takealot.`);
      }
      const textLower = item.title.toLowerCase();
      this.prohibitedWords.forEach(w => {
        if (textLower.includes(w)) {
          warnings.push(`Prohibited promotional keyword detected: "${w}"`);
        }
      });
    }

    // Subtitle constraint check (<= 110 chars)
    if (item.subtitle && item.subtitle.length > 110) {
      warnings.push(`Subtitle exceeds 110 characters (${item.subtitle.length}/110).`);
    }

    // Key Selling Features constraint check (>= 200 chars)
    if (item.features && item.features.length < 200) {
      warnings.push(`Key Selling Features must be at least 200 characters (${item.features.length}/200).`);
    }

    (matchedCat.mandatoryAttributes || []).forEach(attr => {
      const attrName = typeof attr === 'string' ? attr : attr.name;
      const val = item.attributes ? item.attributes[attrName] : null;
      const direct = item[attrName.toLowerCase()];
      if (!val && !direct) {
        missing.push(attrName);
      }
    });

    return {
      valid: missing.length === 0,
      matchedCategory: matchedCat,
      missingFields: missing,
      warnings: warnings
    };
  },

  // Formulate compliant Takealot Title: [Brand] + [Core Type / Model] + [Key Spec/Color/Size] + [Pack Count]
  // Must strictly not exceed 75 characters!
  formatCompliantTitle(brand, coreType, spec, packCount) {
    const parts = [];
    const clean = (s) => (s || '').toString().trim();

    const b = clean(brand);
    const ct = clean(coreType);
    const sp = clean(spec);
    const pc = clean(packCount);

    if (b) parts.push(b);
    if (ct) parts.push(ct);
    
    let combined = parts.join(' ');
    if (sp) {
      combined = combined ? `${combined} - ${sp}` : sp;
    }
    if (pc) {
      combined = `${combined} - ${pc}`;
    }

    // Filter out prohibited words
    let filtered = combined;
    this.prohibitedWords.forEach(w => {
      const re = new RegExp('\\b' + w + '\\b', 'gi');
      filtered = filtered.replace(re, '');
    });
    filtered = filtered.replace(/\s+/g, ' ').replace(/\s+-\s+$/, '').trim();

    // Strict 75 character truncation
    if (filtered.length > 75) {
      filtered = filtered.slice(0, 72).trim() + '...';
    }

    return filtered;
  }
};

// CommonJS and Browser dual export
if (typeof module !== 'undefined' && module.exports) {
  module.exports = TakealotCategoryRules;
}
if (typeof window !== 'undefined') {
  window.TakealotCategoryRules = TakealotCategoryRules;
}
