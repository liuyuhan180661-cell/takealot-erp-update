﻿# Takealot ERP · 交付安装说明（Windows 客户机）

**目标机器**：Windows 10 / 11 64 位（已装 **Hermes 桌面版**）
**交付形式**：一次性解压 → 三个脚本 → 两个点选人工项
**预计耗时**：15 分钟（含浏览器加载扩展）

> 这份是**安装说明**。装完之后照着同目录的 **`CHECKLIST.md`（即"点检清单"）**逐项点一遍，并把 `selfcheck.ps1` 最后那行 `RESULT n/n PASS` 回发给我们。
> （文件名用 `CHECKLIST.md` 而不是中文名，是因为交付 zip 内**不允许出现中文文件名**，否则在部分解压工具/编码下会乱码。内容就是点检清单。）

---

## 0. 这个包是什么

Hermes 桌面版是**宿主**，ERP 是它的一个插件。ERP 由三半组成，**三个位置各放一份，缺一不可**：

| 半边 | 放哪儿 | 谁去加载它 |
| --- | --- | --- |
| **UI 半边** | `%LOCALAPPDATA%\hermes\desktop-plugins\takealot-erp\plugin.js` | 桌面 App 自己认（落盘即生效、存盘热重载） |
| **后端半边** | `%LOCALAPPDATA%\hermes\plugins\takealot-erp\`（含 `dashboard\data\*.json` 约 4.7 MB） | 后端**启动时**才导入，且**只有** `config.yaml` 的 `plugins.enabled` 里列了 `takealot-erp` 才会导入 |
| **Agent 半边**（技能） | `%LOCALAPPDATA%\hermes\skills\takealot-erp-operator\SKILL.md` | Agent 的可用技能表 |
| 浏览器扩展 + 本地桥 | 扩展一个文件夹 + 插件目录里的 `dashboard\bridge\` | 浏览器"加载已解压" + 你自己双击启动 |

**两条容易踩的坑（这个包已经替你避开）**：

1. 插件包自己带的 `plugins\takealot-erp\skills\` 目录**不会**被自动加载 —— 只有可移植 Agent Plugin 包（`plugin.json`）才会。所以技能必须**单独**放到 `skills\takealot-erp-operator\`。包里的两份内容一致，`install.ps1` 会都放好。
2. 全部数据只走本机回环：插件后端和本地桥都只监听 **127.0.0.1**。**唯一对外的**是出口到 Takealot 与模型 API 的**出方向**流量。

---

## 1. 包内容清单

顶层目录只有一个 ASCII 名：`Takealot-ERP-Delivery\`

```
Takealot-ERP-Delivery\
  INSTALL.md              <- 本文件
  CHECKLIST.md            <- 点检清单（装完照着点）
  MANIFEST.md5            <- 包内每个文件的 md5 清单，也是包清单；selfcheck.ps1 拿它做比对
  precheck.ps1            <- ① 只读环境体检
  install.ps1             <- ② 安装（幂等，会先备份）
  selfcheck.ps1           <- ③ 装完自检，最后一行 RESULT n/n PASS/FAIL
  payload\
    hermes-home\                          -> 原样落到 %LOCALAPPDATA%\hermes\
      plugins\takealot-erp\
        plugin.yaml  __init__.py  README.md  VERIFICATION-v6.md
        dashboard\
          manifest.json  plugin_api.py  crawler.py
          data\takealot-attributes.json
          data\takealot-brands.json
          data\takealot-categories.json
          bridge\erp_bridge.py  bridge\start_bridge.bat  bridge\README-bridge.md
        skills\takealot-erp-operator\SKILL.md      （插件包内副本，不会自动加载，供存档）
      desktop-plugins\takealot-erp\plugin.js       （UI 半边）
      skills\takealot-erp-operator\SKILL.md        （★ 生效位置）
    extension\
      Takealot-Assistant-Extension\                （Chrome/Edge MV3 扩展，浏览器里"加载已解压"用）
```

**包里没有任何密钥。** Seller Key 与 AI Key 都不随包交付，理由见第 4 节。
**包里有 `state\` 吗？** 没有，也永远不要有 —— 那是客户自己的数据（Seller Key 密文、店铺、采集箱、缓存）。

`MANIFEST.md5` 的格式是 `md5  相对路径`，路径以 `hermes-home/` 或 `extension/Takealot-Assistant-Extension/` 开头，`install.ps1` / `selfcheck.ps1` 都按这个前缀换算真实落点。

---

## 2. 前置条件（`precheck.ps1` 会自动逐条报）

| 项 | 要求 | 不满足会怎样 |
| --- | --- | --- |
| Windows | 10 / 11 **64 位** | 装不了 |
| PowerShell | **5.1** 或更高（系统自带就够） | 脚本跑不起来 |
| Hermes 桌面版 | 已装在 `%LOCALAPPDATA%\hermes`（`hermes-agent\` 与 `bin\hermes.exe` 在位） | 没有宿主 |
| 自带 venv python | `%LOCALAPPDATA%\hermes\hermes-agent\venv\Scripts\python.exe` | 后端起不来 |
| `fastapi` | 该 venv 里能 `import fastapi` | 后端起不来 |
| **`win32crypt`（pywin32）** | 该 venv 里能 `import win32crypt` | **交付红线**：没有它，Seller Key 会以**明文**落在 `state\stores.json`。`precheck.ps1` 会显式报 FAIL。补法：`"%LOCALAPPDATA%\hermes\hermes-agent\venv\Scripts\python.exe" -m pip install pywin32` |
| 端口 **18790** | 空闲 | 本地桥起不来（扩展连不上） |
| 浏览器 | Chrome 或 Edge 任一 | 没法加载扩展 |
| 出方向连通 | `portal.nousresearch.com:443`、`seller-api.takealot.com:443`、`api.takealot.com:443` | 模型 / 订单库存 / 抓取通路不通 |
| **出口 IP** | 必须不是被 Cloudflare 拦掉的 IP；`precheck.ps1` 会**打印当前出口 IP** | Seller API 与公开接口都会 403 |
| 磁盘 | 安装盘留 ≥ 2 GB（包本体 ~5 MB，解压后 ~5.5 MB） | 写不下 state / 缓存 |
| 执行策略 | `Restricted`/`AllSigned` 也能跑 —— 用 `-ExecutionPolicy Bypass` 调用即可 | —— |

> **需要额外买 IP 吗？不需要。** 订阅（Nous Portal）是**出方向 OAuth**，本地网关和服务端全部走 **127.0.0.1 回环**，都不需要公网地址。**唯一**对出口敏感的是"到 Takealot 的出方向 IP"——那由客户自己的出口决定，见第 4 节。

---

## 3. 安装（三步走）

把 zip 解压到任意 ASCII 路径（例：`C:\Takealot-ERP-Delivery`），**不要在压缩包里直接跑**。
下面命令在 **PowerShell**（不需要管理员）里执行，先 `cd` 到解压出来的 `Takealot-ERP-Delivery\` 目录。

### 第 1 步 · 体检（只读，不改任何东西）

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\precheck.ps1
```

看最后两行：`RESULT n/n`。**只要有 FAIL，先修完再往下走**（脚本会把阻断项单独列出来）。
这一步同时会把**当前出口 IP** 打出来，先记住它。

### 第 2 步 · 安装（幂等，可重复跑）

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

它按顺序做这些事，每一步都会打印它做了什么：

1. 校验包自身完整（缺文件直接中止，不碰机器）；
2. **备份**同名目录到 `%LOCALAPPDATA%\hermes\backups\takealot-erp-delivery-<时间戳>\`：
   `plugins\takealot-erp\`、`desktop-plugins\takealot-erp\`、`skills\takealot-erp-operator\`、扩展目录、`config.yaml`、`.env`；
3. 铺**后端半边** —— 覆盖前会清掉旧部署，但**永不碰 `state\`**（Seller Key、店铺、采集箱、缓存都在里面，原地保留）；
4. 铺 **UI 半边** `plugin.js`；
5. 铺 **Agent 半边** 技能到 `skills\takealot-erp-operator\SKILL.md`（生效位置）；
6. 写 **`config.yaml` 的 `plugins.enabled`** —— 已是列表就**追加**，绝不覆盖别人的条目；
7. 把 **`TAKEALOT_API_PROXY`** 预填进 `.env`，值是本机端口**占位** `http://127.0.0.1:7890`；已存在则**不覆盖**；
8. 铺**扩展目录**；
9. 逐文件核对 md5 与 `MANIFEST.md5`。

可选参数：

```powershell
-Root "D:\hermes"                    # 改 Hermes home（默认 %LOCALAPPDATA%\hermes）
-ExtDir "C:\Users\Public\TKExt"      # 改扩展落地目录（默认 <Root>\Takealot-Assistant-Extension）
-Proxy  "http://127.0.0.1:7890"      # 改占位代理值
-SkipExtension                       # 不动扩展目录
```

装完脚本会**大字打印剩下的人工项**（就是下面第 4 节那三条）。

### 第 3 步 · 启一次 App，然后自检

1. 打开 **Hermes 桌面 App**（开始菜单 / 桌面快捷方式）。它会自己起后端；插件后端**只在启动时挂载**，所以 `config.yaml` 改完**必须重启 App**。
2. 左侧应出现 **Takealot 运营** 一行，点开是 ERP 页面。
3. 回 PowerShell：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\selfcheck.ps1
```

最后一行是 `RESULT n/n PASS` 或 `RESULT n/n FAIL`。**FAIL 时把整段输出贴回来**。
（后端起不来也能跑 —— 脚本会如实报"后端未应答"，不会假装通过。）

---

## 4. 装完剩下三件事（脚本做不了，必须人来点）

### ① 浏览器加载扩展 —— 没有静默安装这回事

1. Chrome 打开 `chrome://extensions`（Edge 打开 `edge://extensions`）；
2. 右上角打开 **开发者模式 / Developer mode**；
3. 左上角 **加载已解压的扩展程序 / Load unpacked**，选中：
   `<Root>\Takealot-Assistant-Extension`（默认 `%LOCALAPPDATA%\hermes\Takealot-Assistant-Extension`）；
4. 工具栏出现蓝色向上箭头「Takealot 运营助手」即成功。点开弹窗，状态区应显示**本地桥已连接**。

> 之后**再跑一次 `install.ps1`** 的话，记得回 `chrome://extensions` 点该扩展的**重新加载 ↻**，已打开的 takealot 页面也刷新一次。

### ② 填 Seller Key —— 包里永远不会带 Key

1. 打开 Hermes App → **Takealot 运营** 页 → 让后端跑起来一次（这样它会建出 `state\` 目录）→ 「**多店铺设置**」；
2. 粘贴 Seller **`X-API-Key`** → 保存（返回里会显示打码值 `TKL••••xxxx`，这正好证明写到了对字段）；
3. 在该行点「**设为当前**」——**绑定 ≠ 激活**，每个模块读的是"当前店铺"，不做这一步界面会像坏了。

> **⚠️ 重要**：在 Takealot 卖家后台**签发新 Key 会立刻作废旧 Key**，同一时间只有一个 Key 有效。
> Key 写盘时用 **Windows DPAPI** 加密（`dpapi:` 前缀，只有当前 Windows 账号能解）。**没有 `win32crypt` 就是明文落盘** —— 这就是 `precheck.ps1` 把它当红线的原因。

### ③ 启本地桥 —— 扩展的数据通道

双击：

```
<Root>\plugins\takealot-erp\dashboard\bridge\start_bridge.bat
```

窗口**别关**（关掉扩展就连不上）。它只用标准库、只监听 `127.0.0.1:18790`、不调用 Takealot 任何 API，只读写本机 state。
自检：浏览器打开 `http://127.0.0.1:18790/takealot/api/health` 应返回 `{"ok":true,...}`；或直接看 `selfcheck.ps1` 的第 6 项。
换端口：`python erp_bridge.py --port 18791`，同时把扩展里的 `gatewayUrl` 改成同一个端口。

### ④（严格说是第 4 件）把占位代理换成你自己的出口

`install.ps1` 只在 `.env` 里预填了**占位** `TAKEALOT_API_PROXY=http://127.0.0.1:7890`，**那不是可用值**。请把它改成**你自己**能出网的代理，例：

```
TAKEALOT_API_PROXY=http://127.0.0.1:7897
```

然后**重启 Hermes App**（环境变量只在后端启动时读一次）。

**为什么必须有出口？** Takealot 前面挂着 Cloudflare，会**直接拒掉**它不接受的 ISP 出口 IP —— 表现为 Seller API 和公开接口一起 403，而本机看什么都"正常"。这个环境里：

- **所有**对 Takealot 的请求（Seller API + 公开抓取）走**同一个**出口决策（`TAKEALOT_API_PROXY`，或 `state\stores.json` 的 `crawler.proxy`）；
- 出口的**可达性排序**由产品自己实测并如实标注：`transport = proxy` / `direct` / `blocked`，`selfcheck.ps1` 第 5 项会把结果打出来；
- 实在没有代理可用的备选（产品内建，不靠猜）：把抓好的原始 JSON 通过 `POST /crawler/ingest` 推进去，或丢进 `state\ingest\*.json` 投放目录，后端会自动吸收进 5 天速度缓存。

**AI / 中译通道**同理：它在 `.env` 里的 `DEEPSEEK_API_KEY`。没有它，中译和 AI 上架文案会**明说"未配置 LLM Key，不编造译文"**，不会瞎编。`selfcheck.ps1` 第 9 项只报**有 / 无**，不显示值。

### ⑤（这台机器有多个 profile 时才需要）把 ERP 也装到另一个 profile

Hermes 的一个 **profile 就是一个独立的 Hermes home**（官方口径：边界是 `HERMES_HOME`；默认 profile 的根是 `%LOCALAPPDATA%\hermes`，别的 profile 在其下的 `profiles\<名字>`）。插件、`skills\`、`config.yaml`、`.env`、`state\` 都是**各 profile 各一套** —— 所以本包默认只装到**默认 profile**，其它 profile 里还是旧的（或干脆没装）。

要在另一个 profile 里也用 ERP：

```powershell
# 1) 先确认路径（能看到 profile 名字就对了）
explorer "$env:LOCALAPPDATA\hermes\profiles"

# 2) 装到那个 profile（用它的名字替换 <名字>）
$env:HERMES_HOME="$env:LOCALAPPDATA\hermes\profiles\<名字>"
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\selfcheck.ps1

# 3) 以后更新也要在那个 profile 里再跑一次（更新器认 HERMES_HOME）
& "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts\python.exe" `
  "$env:HERMES_HOME\plugins\takealot-erp\delivery\selfupdate.py" --repo liuyuhan180661-cell/takealot-erp-update --apply
```

> 一句话：**装/更新是按 profile 走的**，一台机器上有几个 profile 就要跑几遍。装完记得在**那个 profile 的 App 会话里**重启一次，界面才会挂上插件。

---

## 5. 排错

| 现象 | 原因 / 怎么办 |
| --- | --- |
| 左侧没有「Takealot 运营」 | `config.yaml` 的 `plugins.enabled` 没列 `takealot-erp`，或改完没重启 App。查 `logs\gui.log` 有没有 `Mounted plugin API routes: /api/plugins/takealot-erp/` |
| 页面在，但所有数字空 | 没绑 Seller Key（只有实时数据、没有编造的样例数据），或没点「设为当前」 |
| `selfcheck` 第 1 项 FAIL，端口也连不上 | App 没开，或后端刚崩。App 会在几秒内自己重启后端；看 `logs\desktop.log` 里的 `HERMES_BACKEND_READY port=…` |
| 第 4 项显示 `at-rest=PLAINTEXT` | 红线。重启一次后端会自动迁移成密文；仍为明文说明 venv 缺 `pywin32` |
| 第 5 项 `transport=blocked` | 出口被 Cloudflare 拦。换一个出口写入 `.env`，重启 App |
| 第 6 项 FAIL | 桥没起（双击 `start_bridge.bat`）或 18790 被占（`netstat -ano \| findstr 18790`） |
| 扩展显示未连接 | 桥没起；或扩展里 `gatewayUrl` 不是 `http://127.0.0.1:18790` |
| 抓不到公开商品页 | 出口问题（403）；或目标商品已下架。换一个 PLID 再试，仍失败就换出口 |
| 想回退 | 关掉 App → 删掉新铺的目录 → 从 `backups\takealot-erp-delivery-<时间戳>\` 拷回来 |
| 另一个 profile 里还是旧版 / 没有 ERP | 装和更新都是**按 profile 走的**：设 `HERMES_HOME` 指到那个 profile 再跑一遍 `install.ps1` / `selfupdate.py`，见第 4 节 ⑤ |

---

## 6. 这份交付的边界（写在明面上）

- **私有、单机、本地部署**。没有 SaaS 假设；对外的流量只有两类：**模型 API** 与 **Takealot 官方 API**。
- 浏览器扩展**只调公开接口**，**永远不碰 Seller Key**。所有带 Key 的读写、跟价、抓取、xlsx 导出、凭据加密都在服务端（Python 半边）。
- 后端路由 `/api/plugins/*` 需要**会话 token**（App 自己下发）。所以命令行 `curl` 拿到 **401 是正常的**，那不代表插件坏了 —— `selfcheck.ps1` 同时看**日志里的挂载行**来证明插件真的挂上了。
- 本机回环端到端：插件后端、本地桥、扩展宿主都在 `127.0.0.1`。**不要把任何服务绑到 `0.0.0.0` 暴露到公网**；需要远程访问请用 VPN / SSH 隧道。
- 官方 API **不提供**：订单行明细/买家地址/物流、竞品价格与销量（只有一个 `benchmark_price`）、类目元数据（靠抓取快照）、评论与评分、对账单级对账。抓取层与扩展就是为这些存在的，别指望官方接口能替代。

---

## 7. 对话能力（自然语言）与 CDP 可选授权

### 7.1 装完之后，Hermes 对话里能读、能抓什么

装好后在 Hermes 里直接用中文说话即可。**读的能力走工具、写的能力只走界面**：

| 你会说的话（含同义词） | 会用到 |
|---|---|
| 今天怎么样 / 经营总览 / 有哪些风险 | `takealot_erp_overview` |
| 我的订单 / **帮我找一下我的订单** / 待发货 / 最近30天有多少单 | `takealot_erp_orders` |
| 我的商品 / 哪些缺货 / 库存还有多少 | `takealot_erp_products` |
| 财务 / 对账 / 结算单 / 余额 / 月报 | `takealot_erp_finance` |
| 履约 / 送仓单 / 发货到 DC / 入库了没 | `takealot_erp_fulfilment` |
| 采集箱 / 跟卖池 / 采集了什么 | `takealot_erp_collection` |
| 草稿箱 / 必填属性 / 这个类目要填什么 / 帮我写标题描述 | `takealot_erp_listings` |
| 自检 / 为什么读不到 / 抓取通道通不通 / Key 失效了？ | `takealot_erp_selfcheck` |
| **抓取 / 爬取 / 扒一下** / 采集 / 找同款 / 搜同款 / 这货多少钱 **+ 链接或 PLID/TSIN** | `takealot_crawl_product` |
| 搜一下 XX 卖多少钱 / 市场行情 / 这个品类价格区间 | `takealot_market_search` |
| 采集这个 / 存进采集箱 | `takealot_collection_add` |
| **把成本改成 30 / 汇率填成 0.25** / 重量设成 0.18 公斤 / 长宽高补上 20x15x10 / 汇损系数改成 0.25 / 头程改成 25 | `takealot_collection_update`（**只写本机账本**，平台侧一个字都不写） |
| 这个能不能跟卖 / 该跟卖还是建档 | `takealot_route_verdict` |

**边界（确定性的，不靠模型猜）**
- 句子里**有目标标识**（`https://www.takealot.com/p/…`、`PLID…`、`TSIN…`、条码）→ 走**抓取**；
- **只有关键词**（如"搜一下蓝牙耳机卖多少钱"）→ 走**市场行情搜索**（不抓具体商品）；
- 「**找**订单」「**搜**销量」里的"找/搜"是**查询**语义，不会被误判成抓取；
- 出现「**改 / 设 / 上架 / 下架 / 发布 / 改价**」→ **拒绝改数据**，只给界面里的操作路径；
  - 唯一的例外是**采集箱的核算参数**（成本 / 币种 / 汇率 / 汇损 / 头程 / 重量 / 尺寸）：这些写**你本机的账本** `state\collection.json`，平台侧一个字都不写。而且必须「**字段名 + 设置动词**」一起出现才触发 —— 单纯问「这条的成本是多少」只读不写。上架/改价这类**平台侧写入仍然只在界面上做**（「一键上架（全店）」按钮默认先预览、再二次确认）。
- 出现否定词（「先别 / 不要 / 暂时不用」+ 抓取动词）→ **不触发抓取**。

**可回溯（这是给客户的自证口径，不是口头承诺）**
每一句的判定都写进 `%LOCALAPPDATA%\hermes\plugins\takealot-erp\state\agent_intent_audit.jsonl`：
原话 → 命中规则 → 判定意图 → 期望工具 → 是否注入。用记事本打开即可看到"它为什么这么理解"。

### 7.2 CDP 抓取是**可选增强**（不开也能用）

扩展默认用 **DOM + 公开 API** 抓取。开 CDP 会更稳、字段更全（直接读页面 XHR 的原始 JSON）：

1. 浏览器打开扩展详情（`chrome://extensions` → 本扩展 → 详情）；
2. 面板上有「**启用 CDP 抓取**」开关，点它会弹出权限确认（扩展声明为 `optional_permissions`，**不点就永远没有该权限**）；
3. 允许后抓一次，结果里的 `transport` 会标 `cdp`（没开则是 `dom` 或 `api`）。

**降级顺序是固定的**：`CDP → DOM → 公开 API → blocked`，结果里**永远标注实际走的通道**，不会假装成功。
抓不到时最常见原因是**出口被 Cloudflare 挑战**（`www.takealot.com` 返回 403 挑战页）——换出口或配代理即可；
**订单/财务/库存/履约走 Seller API，不受此影响**。

